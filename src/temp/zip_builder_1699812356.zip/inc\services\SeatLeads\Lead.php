<?php

class SeatLeads_Lead extends Lead_Data {
    const SOURCE = 'Seat';
    private $clientSearch = array();
    private $addData = array();

    public function getCustomer() {
        return $this->clientSearch;
    }

    public function parse(array $data) {
        global $db;
        $lead_original_inhalt = base64_encode(json_encode($data));
        $data = json_decode_utf8($data, true);
        $externalId = $data['id'];
        if (self::checkExist($externalId, self::SOURCE)) {
            return false;
        }
        $this->clientSearch = $this->addData = array();

        $this->set('leadid', $externalId);
        $this->set('status', 0);
        $this->set('status2', $data['status']);
        $this->set('lead_original_inhalt', $lead_original_inhalt);
        $this->set('lead_origin', self::SOURCE);
        $this->set('source', self::SOURCE);
        $this->set('channel', $data['lead-source']);
        $this->set('kfzmarke', $data['brand']);
        if ($data['new-used'] === 'New') {
            $this->set('type', 'NW');
        } else {
            $this->set('type', 'GW');
        }
        $this->set('erfassungsdatum', time());
        $this->set('campaignname', self::SOURCE.' '.$data['lead-type']);
        $this->set('campaigndata', '#####'.$this->get('campaignname'));

        //$this->set('retailer', $data['dealerId']);
        $this->set('log_text', date('d.m.Y H:i:s').': Import - '.(empty($_SESSION['mitarbeiter_name2']) ? 'task' : $_SESSION['mitarbeiter_name2'])."\r\n");
        if (!empty($data['cars-of-interest'])) {
            $moidata = $data['cars-of-interest'];
            $moi = new Lead_Moi();
            $moi->setBrand(@$moidata['brand']);
            $moi->setModel(@$moidata['description']);
            $moi->setUID(@$moidata['code']); //?
            //model-year // ?
            $this->set('moidata', $moi->prepareString());
            /*if (count($data['cars-of-interest']) > 1) {
                // todo
            }*/
        }
        // Customer
        $this->clientSearch = array(
            'vorname' => @$data['first-name'],
            'name'    => @$data['last-name']
        );
        $persdata = array(
            'leer'              => null,
            'Salutation'        => null,
            'Occupation'        => null,
            'AcademicTitle'     => null,
            'Initials'          => null,
            'FirstName'         => $this->clientSearch['vorname'],
            'LinkName'          => null,
            'LastName'          => $this->clientSearch['name'],
            'SecondLastName'    => null,
            'Gender'            => null,
            'DateOfBirth'       => null,
            'LanguageCode'      => null
        );
        $this->set('persdata', implode('#####', $persdata));
        // Address
        $this->clientSearch['ort'] =  @$data['city'];
        $this->clientSearch['plz'] =  @$data['postal-code'];
        $this->clientSearch['adresse'] = @$data['street'];
        $addressdata = array(
            'leer'                => null,
            'HouseNumber'         => null,
            'HouseNumberSuffix'   => null,
            'Apartment'           => null,
            'StreetName'          => $this->clientSearch['adresse'],
            'AddressLine1'        => null,
            'AddressLine2'        => null,
            'Town'                => $this->clientSearch['ort'],
            'PostalCode'          => $this->clientSearch['plz'],
            'County'              => @$data['country'],
            'AddressType'         => null,
            'CountryCode'         => null
        );
        $this->set('addressdata', implode('#####', $addressdata));
        // Contact data
        $this->clientSearch['telefon'] = @$data['phone'];
        $this->clientSearch['email'] = @$data['email'];
        $contactdata = array(
            'leer'                             => null,
            '_TELEFON_PRIVAT_'                 => null,
            '_MOBILTELEFON_PRIVAT_'            => $this->clientSearch['telefon'],
            '_TELEFON_GESCHAEFTLICH_'          => null,
            '_MOBILTELEFON_GESCHAEFTLICH_'     => null,
            '_FAX_'                            => null,
            '_EMAIL_'                          => $this->clientSearch['email'],
            'PreferedContactDate1'             => null,
            'PreferedContactDate2'             => null,//'2. '._GEWUENSCHTED_KONTAKTDATUM_,
            'PreferedContactTime1'             => null,
            'PreferedContactTime2'             => null,//'2. '._GEWUENSCHTE_KONTAKTZEIT_,
            'ContactNumber'                    => null,//_NUMMER_,
            'OptOut'                           => null,//_OPTOUT_,
            'ContactPreferencePhone'           => null,//_BEVORZUGTE_TELEFONNUMMER_,
            'ContactPreferenceEmail'           => null,//_BEVORZUGTE_EMAIL_,
            'ContactPreferenceMail'            => null,//_BEVORZUGTE_POSTADRESSE_,
            'ContactPreferenceMobileMessaging' => null,//_BEVORZUGTE_SMS_NUMMER_
            'DataPrivacyData'                  => null
        );
        $this->set('contactdata', implode('#####', $contactdata));

        if (!empty($this->clientSearch)) {
            $clientData = Customer_SearchNew::checkExists($this->clientSearch);
            $this->set('kundennummer', $clientData['kundennummer']);
            $this->set('stammdaten_id', $clientData['stammdaten_id']);
        }
        return true;
    }
}

//"current-brand": "Opel",
// "current-model": "Astra",
// "other-considered-brand": "Volkswagen",
// "other-considered-model": "Golf",
// "lead-source": "Web",
// "power-kw-from": 100,
// "power-kw-to": 150,
// "additional-services-packages": "Maintenance Package; Extended
//Warranty",
// "fuel-type": "Gasoline",
// "transmission-type": "Automatic",
// "monthly-budget": 1500,
// "down-payment": 5000,
// "equipment-summary": "LED headlights; Leather seats; Navigation
//system",
// "preferred-financing-method": "Leasing",
// "current-financing-method": "Bank loan",
// "expected-mileage-per-year": 15000,
// "preferred-communication-channel": "Email",
// "preferred-contract-duration": 24,
// "status": "To be withdrawn",