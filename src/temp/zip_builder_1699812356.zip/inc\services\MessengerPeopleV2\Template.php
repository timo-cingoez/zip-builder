<?php
/**
 * Template class
 * MessengerPeople V2 templates implementation
 * https://app.messengerpeople.dev/settings/templates/
 *
 * Need add scope: 'templates:read templates:update templates:create' in service provider panel:
 * https://app.messengerpeople.dev/settings/oauth-apps
 *
 * @author Alexander Yurkovets <alexander.yurkovets@prof4.net>
 * 14.05.2021
 *
 * ----------- for phpstorm: ---------
 * @noinspection PhpUndefinedConstantInspection
 */

class MessengerPeopleV2_Template {

    private static $template = array();
    private static $instance;
    public $humanReadableTemplate = array(); // human readable text of the templates
    public static $sessionKeyName = 'MessengerPeopleTemplateStorage';

    public static $templateStatus = [
        'APPROVED' => _AKZEPTIERT_,
        'REJECTED' => _ABGELEHNT_,
        'PENDING' =>  _PENDING_,
    ];

    /**
     * @var MessengerPeopleV2_Api
     */
    private $api;

    /**
     * MessengerPeopleV2_Template constructor.
     */
    public function __construct(MessengerPeopleV2_Api $api) {
        $this->api = $api;
    }

    /**
     * @return MessengerPeopleV2_Template
     */
    public static function instance(MessengerPeopleV2_Api $api) {
        if (self::$instance == null) {
            self::$instance = new MessengerPeopleV2_Template($api);
        }

        return self::$instance;
    }

    /** get data template via api by name  or get full data about all templates
     * @param string|null $name
     *
     * @return false|array
     * @throws Exception
     */
    public function getDataTemplate($name = '') {
        if (!empty(self::$template[$name]) && is_object(self::$template[$name])) {
            return self::$template[$name];
        }
        //get all templates data
        $data = $this->api->getTemplates();
        if (!empty($this->api->error)) {
            throw new Exception($this->api->error);
        }
        if (is_array($data)) {
            foreach ($data as $i => $value) {
                // collect all
                if (!empty($value['name'])) {
                    self::$template[$value['name']] = $value;
                }
            }
            // data for this name
            if (!empty(self::$template[$name])) {
                return self::$template[$name];
            }
            // or full data
            return self::$template;
        }

        return false;
    }

    /** sets of the options for generate select box
     * @return string[][]
     */
    public static function selectboxOptions() {
        // todo need update old format values to new!!!

        $option = array(
            'switch' => array(
                'name' => 'placeholder is Name',
                'time' => 'placeholder is Time',
                'datetime' => 'is Date Time',
                'date' => 'is Date',
                'string' => 'is String',
                'stammdaten_id' => 'is DB "Stammdaten" ID',
            ),
            //stammdaten text fields for name
            'prefix' => array(
                'anrede'      => 'Anrede',
                'briefanrede' => 'Briefanrede'
            ),
            //stammdaten text fields for name
            'name' => array(
                'vorname'      => 'Vorname',
                'name'         => 'Name',
                'vorname.name' => 'Vorname Name',
                'anzeigename'  => 'Anzeigename'
            ),
            //datetime type: map to db datetype fields
            'datetime' => [
                'erstellt_datum' => 'Stammdaten Erstellt Datum'
            ],
            //date type: map to db stammdaten date fields
            'date' => [
                'geburtstag' => 'Geburtstage',
                'datum_neukunde' => 'Datum neukunde',
                'datum_letzterauftrag' => 'Datum letzterauftrag',
                'blacklist_datum' => 'Blacklist Datum',
                'blacklist_temp_datum' => 'Blacklist temp datum'
            ],
            'string' => [
                'string' => 'Text',
                //'manual-fill' => 'Fill manually as Text when init each mailing' //virtual -> will add in php code
            ],
            'stammdaten_id'  => [
                'stammdaten_id' => '\'Stammdaten\' ID'
            ]
        );

        foreach (range(9,20,1) as $k) {
            $option['time'][$k.':00'] = $k.':00';
            $option['time'][$k.':30'] = $k.':30';
        }

        return $option;
    }

    /** get Languages via api and return only what we uses in CRM
     * @return array|mixed
     * @throws Exception
     */
    public function getLanguages() {
        if (!empty($_SESSION[self::$sessionKeyName]['languages'])) {
            return $_SESSION[self::$sessionKeyName]['languages'];
        }
        //get languages
        $data = $this->api->getTemplatesLanguages();
        if (!empty($this->api->error)) {
            throw new Exception($this->api->error);
        }
        $languages = $provider_lang = array();
        // convert code languages like we use
        foreach ($data as $item) {
            preg_match("/zh_([a-z]{2})/i",$item['code'],$m);
            if (!empty($m[1])) {
                $provider_lang[strtolower($m[1])] = 1;
            }
            $provider_lang[$item['code']] = 1;
        }
        // we use translations only this
        $lang_files  = MessengerPeople_Language::getLangArrayFiles();
        foreach($lang_files as $file=>$name) {
            preg_match("/lang_([a-z]{2}).?\.php/",$file,$m);
            // if lang is in both sides - allow this
            if (!empty($m[1]) && $provider_lang[$m[1]] === 1 ) {
                $languages[$m[1]] = $name;
            }
        }
        if (!empty($languages)) {
            //to cache
            $_SESSION[self::$sessionKeyName]['languages'] = $languages;
        }
        return $languages;
    }

    /** get template Categories via api
     * @return array|mixed
     * @throws Exception
     */
    public function getCategories() {
        if (!empty($_SESSION[self::$sessionKeyName]['categories'])) {
            return $_SESSION[self::$sessionKeyName]['categories'];
        }
        //get languages
        $data = $this->api->getTemplateCategories();
        if (!empty($this->api->error)) {
            throw new Exception($this->api->error);
        }
        if(!empty($data)) {
            //to cache
            $_SESSION[self::$sessionKeyName]['categories'] = $data;
        }
        return $data;
    }

    /** get check is available template name via api
     * @param $name
     *
     * @return bool
     * @throws Exception
     */
    public function checkAvailable($name) {
        return $this->api->checkAvailable($name);
    }

    /** template is active? yes/no
     * @param $data
     * @param $lang
     *
     * @return string
     */
    public function isActive($data, $lang) {
        if (!empty($data['translations'][$lang]['status']) &&
            $data['translations'][$lang]['status'] === 'APPROVED'
        ) {
            return 'yes';
        }

        return 'no';
    }

    /** generate template payload by:
     *      data template from API +
     *      get placeholders positions for header & body texts +
     *      DB cfg for this name of template and positions +
     *      replace placeholders by data from stammdaten table
     * @param $leadid
     * @param $template_name
     * @param $lang
     * @param $cfg
     *
     * @return array|false
     */
    public function getPayload($leadid, $template_name, $lang, $cfg) {
        if (empty($this->template[$template_name][$lang])) {
            try {
                $data = $this->getDataTemplate($template_name);
                if (!empty($data['translations'][$lang]['buttons'])) {
                    $this->humanReadableTemplate[$template_name][$lang]['buttons'] = $data['translations'][$lang]['buttons'];
                }
//                echo '<pre>'.print_r($data,true).'</pre>';
                if ('yes' === $this->isActive($data, $lang)) {
                    $components = $this->replacePlaceholders($leadid, $data, $lang, $cfg);
                    $out = array(
                        "type" => "template",
                        "text" => "",
                        "template" => array(
                            "type" => "notification",
                            "notification" => array(
                                "name" => $template_name,
                                "language" => $lang
                            )
                        )
                    );
                    if (!empty($components)) {
                        $out['template']['notification']['components'] = $components;
                    }
                    return $out;
                }

            } catch (Exception $e) {
                //todo
                var_dump($e->getMessage());
            }
        }

        return false;
    }

    /** generate $components array for payload by:
     *      data template from API +
     *      get placeholders positions for header & body texts +
     *      DB cfg for this name of template and positions +
     *      replace placeholders by data from stammdaten table
     * @param $leadid
     * @param $data
     * @param $lang
     * @param $cfg
     *
     * @return array
     */
    private function replacePlaceholders($leadid, $data, $lang, $cfg) {
        $components = array();
        $j = 0;
        foreach (array('header','body','footer') as $position) {
            if (!empty($data['translations'][$lang][$position.'_text'])) {
                // need only for show temporary message in chat window exactly after click send
                $this->humanReadableTemplate[$data['name']][$lang][$position] = $data['translations'][$lang][$position.'_text'];
                preg_match_all('/{{(\d+)}}/i', $data['translations'][$lang][$position.'_text'], $m, PREG_PATTERN_ORDER);
                for ($i = 0; $i < count_p4n($m[1]); $i++) {
                    if ($i === 0) {
                        $components[$j] = array('type' => $position, 'parameters' => array());
                    }
                    if (!empty($m[1][$i])) {
                        if (!empty($cfg[$position])) {
                            $text = $this->replaceThis($leadid, $cfg[$position], $m[1][$i]);
                        } else {
                            $text = '';
                        }
                        $components[$j]['parameters'][] = array(
                            "type" => "text",
                            "text" => $text // in utf8
                        );
                        // replace placeholders
                        $this->humanReadableTemplate[$data['name']][$lang][$position] = str_replace('{{'.($i+1).'}}', p4n_mb_string('utf8_decode', $text), $this->humanReadableTemplate[$data['name']][$lang][$position]);
                    }
                }
            }
            if (isset($components[$j])) {
                $j++;
            }
        }

        return $components;
    }

    /**
     * @param string $template_name
     * @param numeric $stammdaten_id
     * @param array $template_content
     * @param array $cfg
     *
     * @return array
     * @throws Exception
     */
    public function payloadForMass($template_name, $stammdaten_id, $template_content, $cfg) {
        $components = [];
        $j = 0;
        //AzureApp::dd($cfg);
        //['header_type'] === 'MEDIA'
        if ($template_content["header_media_type"] === 'IMAGE') {
            if (!empty($cfg['header']['switch'][1]) &&
                $cfg['header']['switch'][1] === 'media-image' &&
                !empty($cfg['header']['field'][1])
            ) {
                $components[$j] = [
                    'type' => 'header',
                    'parameters' => []
                ];
                $components[$j]['parameters'][] = [
                    'type' => 'image',
                    //'id' => $cfg['header']['field'][2],
                    'image' => [
                        'link' => $cfg['header']['field'][1]
                    ]
                ];
            } else {
                throw new Exception('Empty image UUID for to replace header image placeholder');
            }
        }

        //todo button url with dynamic param
        //header_text==="" when "header_media_type"==="IMAGE"
        foreach (array('header', 'body', 'footer') as $position) {
            if (!empty($template_content[$position.'_text'])) {
                preg_match_all('/{{(\d+)}}/i', $template_content[$position.'_text'], $m, PREG_PATTERN_ORDER);
                for ($i = 0; $i < count_p4n($m[1]); $i++) {
                    if ($i === 0 && !isset($components[$j])) {
                        $components[$j] = array('type' => $position, 'parameters' => array());
                    }
                    if (!empty($m[1][$i])) {
                        $text = '';
                        if (!empty($cfg[$position])) {
                            $text = $this->replaceThisByStammdaten($stammdaten_id, $cfg[$position], $m[1][$i]);
                        } else {
                            throw new Exception('Empty placeholder for '.$position.' '.$i);
                        }
                        $components[$j]['parameters'][] = array(
                            "type" => "text",
                            "text" => $text // in utf8
                        );
                    }
                }
            }
            if (isset($components[$j])) {
                $j++;
            }
        }
        if (!empty($template_content['buttons'])) {
            foreach ($template_content['buttons'] as $index=>$button) {
                // 'PHONE_NUMBER' && static url not need include here
                if ($button['type'] === 'QUICK_REPLY') {
                    $components[$j] = [
                        'type' => 'button',
                        'sub_type' => 'quick_reply',
                        'index' => (string)$index,
                        "parameters" => [
                            'type' => 'payload',
                            'payload' => MessengerPeople::encode_utf8_if_need($button['text'])
                        ]
                    ];
                    $j++;
                } elseif ($button['type'] === 'URL') {
                    //dynamic?
                    if (strpos($button['url'], '{{1}}')) {
                    //only one allow! so overwrite if more
                        if (empty($cfg['button'])) {
                            throw new Exception('Empty placeholder '.$m[1][$i].' for button url');
                        } else {
                            $text = $this->replaceThisByStammdaten($stammdaten_id, $cfg['button'], 1);
                        }
                        $components[$j] = [
                            'type' => 'button',
                            "sub_type" => 'url',
                            'index' => (string)$index,
                            "parameters" => [[
                                'type' => 'text',
                                'text' => $text // in utf8"
                            ]]
                        ];
                        $j++;
                    }
                }
            }
        }
        $out = [
            "type" => "template",
            "text" => "",
            "template" => [
                "type" => "notification",
                "notification" => [
                    "name" => $template_name,
                    "language" => $template_content['language']
                ]
            ]
        ];
        if (!empty($components)) {
            $out['template']['notification']['components'] = $components;
        }

        return $out;
    }

    /** replace placeholders by data from tables and DB config for this template
     * @param $leadid     'lead id'
     * @param $cfg        'really it is part of config' from DB  $cfg['header' or 'body'] or from manual-value
     * @param $i          '{{1}} {{2}} {{$i}}' placeholders in 'header' or 'body'
     *
     * @return string
     */
    private function replaceThis($leadid, $cfg, $i) {
        global $db, $sql_tab, $sql_tabs;
        $replace = array();
        // switch -> 'time'|'name'|'datetime'|'date'
        // $cfg['switch']['time'] --> time value OR manual-fill (for mass mailing only)
        if (!empty($cfg['switch'][$i]) && $cfg['switch'][$i] === 'time') {
            // for now only from cfg settings
            if (!empty($cfg['field'][$i])) {
                $replace[] = $cfg['field'][$i]; //18:00
            }
        } elseif (!empty($leadid) && !empty($cfg['field'][$i])) {
//            echo ' replaceThis '.$cfg['field'][$i]."<br>";
            if (in_array($cfg['field'][$i], [
                'vorname',
                'name',
                'vorname.name',
                'anzeigename',
                'erstellt_datum',
                'geburtstag',
                'datum_neukunde',
                'datum_letzterauftrag',
                'blacklist_datum',
                'blacklist_temp_datum'
            ])) {
                $res = $db->select(
                    $sql_tab['kampagne_lead'].
                    ' INNER JOIN '.$sql_tab['stammdaten'].
                    ' ON '.$sql_tabs['kampagne_lead']['stammdaten_id'].'='.$sql_tabs['stammdaten']['id'],
                    array(
                        $sql_tabs['stammdaten']['firma1'],
                        $sql_tabs['stammdaten']['anrede'],
                        $sql_tabs['stammdaten']['briefanrede'],
                        $sql_tabs['stammdaten']['vorname'],
                        $sql_tabs['stammdaten']['name'],
                        $sql_tabs['stammdaten']['anzeigename'],
                        $sql_tabs['stammdaten']['erstellt_datum'],
                        $sql_tabs['stammdaten']['geburtstag'],
                        $sql_tabs['stammdaten']['datum_neukunde'],
                        $sql_tabs['stammdaten']['datum_letzterauftrag'],
                        $sql_tabs['stammdaten']['blacklist_datum'],
                        $sql_tabs['stammdaten']['blacklist_temp_datum'],
                    ),
                    $sql_tabs['kampagne_lead']['leadid'].'='.$db->str($leadid)
                );
                // echo $db->last_sql.'<br>';
                if (false !== ($row = $db->zeile($res))) {
                    //prefix -> anrede | briefanrede
                    if (!empty($cfg['prefix'][$i]) && empty($row['firma1'])) {
                        $replace[] = MessengerPeople::encode_utf8_if_need(trim($row[$cfg['prefix'][$i]]));
                    }
                    if (!empty($cfg['field'][$i])) {
                        if ((
                                $cfg['field'][$i] === 'vorname.name' ||
                                $cfg['field'][$i] === 'vorname' ||
                                $cfg['field'][$i] === 'name'
                            ) && !empty($row['firma1'])
                        ) {
                            $replace[] = MessengerPeople::encode_utf8_if_need(trim($row['anzeigename']));
                        } elseif ($cfg['field'][$i] === 'vorname.name') {
                                $replace[] = MessengerPeople::encode_utf8_if_need(trim($row['vorname']));
                                $replace[] = MessengerPeople::encode_utf8_if_need(trim($row['name']));
                        } else {
                            $replace[] = MessengerPeople::encode_utf8_if_need(trim($row[$cfg['field'][$i]]));
                        }
                    }
                }
            } elseif ($cfg['field'][$i] === 'manual-fill') {
                // AzureApp::dd([$cfg, $cfg['manual-value'][$i]]);
                $replace[] = MessengerPeople::encode_utf8_if_need(!empty($cfg['manual-value'][$i]) ? trim($cfg['manual-value'][$i]) : '');
                //todo or throw if empty?
            }
        }
        return !empty($replace) ? implode(' ', $replace): '';
    }

    /** replace placeholders $i with data found by stammdaten_id
     * @param numeric $stammdaten_id
     * @param array $cfg
     * @param numeric $i
     *
     * @return string
     */
    private function replaceThisByStammdaten($stammdaten_id, $cfg, $i) {
        global $db, $sql_tab, $sql_tabs;
        $replace = array();
        // switch -> 'time'|'name'|'datetime'|'date'
        // $cfg['switch']['time'] --> time value OR manual-fill (for mass mailing only)
        if (!empty($cfg['switch'][$i]) && $cfg['switch'][$i] === 'time') {
            // for now only from cfg settings
            if (!empty($cfg['field'][$i])) {
                $replace[] = $cfg['field'][$i]; //18:00
            }
        } elseif (!empty($cfg['switch'][$i]) && $cfg['switch'][$i] === 'stammdaten_id') {
            // for now only from cfg settings for skipping query
            if (!empty($stammdaten_id)) {
                $replace[] = $stammdaten_id;
            }
        } elseif (!empty($stammdaten_id) && !empty($cfg['field'][$i])) {
//            echo ' replaceThis '.$cfg['field'][$i]."<br>";
            if (in_array($cfg['field'][$i], [
                'vorname',
                'name',
                'vorname.name',
                'anzeigename',
                'erstellt_datum',
                'geburtstag',
                'datum_neukunde',
                'datum_letzterauftrag',
                'blacklist_datum',
                'blacklist_temp_datum'
            ])) {
                $res = $db->select(
                    $sql_tab['stammdaten'],
                    array(
                        $sql_tabs['stammdaten']['firma1'],
                        $sql_tabs['stammdaten']['anrede'],
                        $sql_tabs['stammdaten']['briefanrede'],
                        $sql_tabs['stammdaten']['vorname'],
                        $sql_tabs['stammdaten']['name'],
                        $sql_tabs['stammdaten']['anzeigename'],
                        $sql_tabs['stammdaten']['erstellt_datum'],
                        $sql_tabs['stammdaten']['geburtstag'],
                        $sql_tabs['stammdaten']['datum_neukunde'],
                        $sql_tabs['stammdaten']['datum_letzterauftrag'],
                        $sql_tabs['stammdaten']['blacklist_datum'],
                        $sql_tabs['stammdaten']['blacklist_temp_datum'],
                    ),
                    $sql_tabs['stammdaten']['id'].'='.$db->dbzahl($stammdaten_id)
                );
//                echo $db->last_sql.'<br>';
                if (false !== ($row = $db->zeile($res))) {
                    //prefix -> anrede | briefanrede
                    if (!empty($cfg['prefix'][$i]) && empty($row['firma1'])) {
                        $replace[] = MessengerPeople::encode_utf8_if_need(trim($row[$cfg['prefix'][$i]]));
                    }
                    if (!empty($cfg['field'][$i])) {
                        if ((
                                $cfg['field'][$i] === 'vorname.name' ||
                                $cfg['field'][$i] === 'vorname' ||
                                $cfg['field'][$i] === 'name'
                            ) && !empty($row['firma1']) // vorname & name empty
                        ) {
                            $replace[] = MessengerPeople::encode_utf8_if_need(trim($row['anzeigename']));
                        } elseif ($cfg['field'][$i] === 'vorname.name') {
                                $replace[] = MessengerPeople::encode_utf8_if_need(trim($row['vorname']));
                                $replace[] = MessengerPeople::encode_utf8_if_need(trim($row['name']));
                        } else {
                            $replace[] = MessengerPeople::encode_utf8_if_need(trim($row[$cfg['field'][$i]]));
                        }
                    }
                }
            } elseif ($cfg['field'][$i] === 'manual-fill') {
                $replace[] = MessengerPeople::encode_utf8_if_need(!empty($cfg['manual-value'][$i]) ? trim($cfg['manual-value'][$i]) : '');
                //todo or throw if empty?
            }
        }
        return !empty($replace) ? implode(' ', $replace): '';
    }
}