<?php
include_once('inc/session.php');

$postfeld = $_POST;
$getfeld = $_GET;

if ($_SESSION['user_gruppe'] == 2) {
    if (isset($getfeld['uid'])) {
        $uid = intval($getfeld['uid']);
    } elseif (isset($postfeld['uid'])) {
        $uid = intval($postfeld['uid']);
    } else {
        $uid = $_SESSION['user_id'];
    }
    if (isset($postfeld['from'])) {
        $getfeld['from'] = $postfeld['from'];
    }
} else {
    $uid = $_SESSION['user_id'];
}
if (isset($_POST['password_policy_reset'])) {
    $zusatzget = '';
    if ($getfeld['from'] != '') {
        $zusatzget = '?uid='.$uid.'&from='.$getfeld['from'];
    }
    wechsel('benutzer_passwort.php?user_id='.$uid.'&hidden_reset_password='.urlencode(verschluesseleWert($_SESSION['user_id'])).'&quelle='.urlencode(verschluesseleWert('benutzer.php'.$zusatzget)));
}

$link = 'benutzer.php?uid='.$uid;

include_once("class.overlib.php");
$ol = new Overlib();
$ol->set("width",300);
$masterkey='6t22mp=55+xt4';
$anz_pim=10;
$passwHint = oltext(_ADMINBENUTZER_PASSWORT2_, '&nbsp;');

if (isset($postfeld['submit'])) {
    foreach (array('login', 'name', 'vorname', 'passwort') as $key) {
        if (isset($postfeld['user_setting'][$key])) {
            unset($postfeld['user_setting'][$key]);
        }
    }
}

$view = 'default';
$handbuch = '';
if (!empty($getfeld['view'])) {
    $view = $getfeld['view'];
    $viewFile = 'inc/User/views/'.$view.'.php';
    if (!is_file($viewFile)) {
        $view = 'default';
    } else {
        $handbuch = '?view='.$view;
    }
}

$user = new User_Data($uid);
$user->load();

$besonderes_recht=array();
if ($user->besonderes_recht != '') {
    $besonderes_recht = unserialize($user->besonderes_recht);
}
//
$handbuch = '<span class="handbuch" style="display:none;">'.link2('', 'handbuch_suche.php?source='.basename($phs), 'overlib.gif', '', 'target="_blank"').'</span>';
$title = ' - '.trim($user['name'].', '.$user['vorname']).' ('.$lang['_ADMINBENUTZER-LOGIN_'].': '.$user['login'].')';
$temp = new Modern_Template_SubMenu();
$temp->class = 'karten';
$temp->mobile_id = 'pers_einst_karten';
$temp->wrapper_marginbottom = true;
$temp->setTitle(_BENUTZEREINSTELLUNGEN_.$title.$handbuch);
if (!empty($getfeld['from'])) {
    $temp->setFilterString(zuruecklink('admin_benutzer.php', _STAMMDATEN_NAV_ZURUECK_));
    $link .= '&from='.$getfeld['from'];
}
$kartei_values = array(
    array('<a class="karten'.($view === 'default' ? '_a' : '').'" href="'.$link.'" onClick="P4nBoxHelper.startloading();" >' . _ALLGEMEIN_ . '</a>'),
    //array('<a class="karten'.($view === 'personal' ? '_a' : '').'" href="benutzer.php?view=personal&uid='.$uid.'" onClick="P4nBoxHelper.startloading();" >Temp</a>'),
    array('<a class="karten'.($view === 'settings' ? '_a' : '').'" href="'.$link.'&view=settings" onClick="P4nBoxHelper.startloading();" >' . _EINSTELLUNGEN_ . '</a>'),
    array('<a class="karten'.($view === 'interfaces' ? '_a' : '').'" href="'.$link.'&view=interfaces" onClick="P4nBoxHelper.startloading();" >' . _SCHNITTSTELLEN_ . '</a>')
);
$temp->setKarteiValues(
    $kartei_values
);
$temp->setHtml();
$tabsList = $temp->getHtml();

if ($view !== 'default') {
    $link .= '&view='.$view;
    require $viewFile;
    fuss();
    exit;
}

if (isset($getfeld['view'])) {
    if ($getfeld['view'] === 'signatur') {
        Modern_Helper_Request::requestStart();
        require_once 'inc/email_signatur_vorlage.php';
        //fuss();
        exit;
    }
    if ($getfeld['view'] === 'search_criteria') {
        require_once 'inc/Settings/views/search_criteria.php';
        exit;
    }
}
/* raus:
    isdn (war sowieso nicht in modern)
    feiertage import CSV - benutzt niemand
    $cfg_dat_ordner dat_benid
*/

if (!function_exists('resize_bild')) {
    function resize_bild($filename, $ziel, $art, $width = 1024, $height = 768, $ratio=true) {
        list($width_orig, $height_orig) = getimagesize($filename);
        if ($ratio) {
            $ratio_orig = $width_orig / $height_orig;
            if ($width / $height > $ratio_orig) {
                $width = $height * $ratio_orig;
            } else {
                $height = $width / $ratio_orig;
            }
        }
        $image_p = imagecreatetruecolor($width, $height);
        if ($art == 'jpg' or $art == 'jpeg') {
            $image = imagecreatefromjpeg($filename);
        } elseif ($art == 'png') {
            $image = imagecreatefrompng($filename);
        } elseif ($art == 'gif') {
            $image = imagecreatefromgif($filename);
        } else {
            unset($image_p);
            return false;
        }
        imagecopyresampled($image_p, $image, 0, 0, 0, 0, $width, $height, $width_orig, $height_orig);
        imagejpeg($image_p, $ziel, 80);
        unset($image_p);
    }
};

if (isset($postfeld['submit'])) {
    $data = $postfeld['user_setting'];
    
    $x = preg_replace('/_.*/', '', $_SESSION['hash']);
	
	if ($cfg_kat_portal or $_SESSION['cfg_kunde']=='portal') {
		if (isset($postfeld['p4n_verantwortlich'])) {
			$besonderes_recht['p4n_verantwortlich']=$postfeld['p4n_verantwortlich'];
	        $data['besonderes_recht']=serialize($besonderes_recht);
		}
		if (isset($postfeld['p4n_auskennen'])) {
			$besonderes_recht['p4n_auskennen']=$postfeld['p4n_auskennen'];
	        $data['besonderes_recht']=serialize($besonderes_recht);
		}
		if (isset($postfeld['p4n_team'])) {
			$besonderes_recht['p4n_team']=$postfeld['p4n_team'];
	        $data['besonderes_recht']=serialize($besonderes_recht);
		}
		if (isset($postfeld['p4n_aufgaben'])) {
			$besonderes_recht['p4n_aufgaben']=$postfeld['p4n_aufgaben'];
	        $data['besonderes_recht']=serialize($besonderes_recht);
		}
		if (isset($postfeld['p4n_nebenaufgaben'])) {
			$besonderes_recht['p4n_nebenaufgaben']=$postfeld['p4n_nebenaufgaben'];
	        $data['besonderes_recht']=serialize($besonderes_recht);
		}
		if (isset($postfeld['p4n_bereich'])) {
			$besonderes_recht['p4n_bereich']=$postfeld['p4n_bereich'];
	        $data['besonderes_recht']=serialize($besonderes_recht);
		}
		if (isset($postfeld['p4n_wochenstunden'])) {
			$besonderes_recht['p4n_wochenstunden']=$postfeld['p4n_wochenstunden'];
	        $data['besonderes_recht']=serialize($besonderes_recht);
		}
	}
	
    $data['startseite'] = remove_wwwlink_prefix($data['startseite']);
    $m_sprache = $_SESSION['sprache'];
    if ($_SESSION['user_id'] == $uid) {
        $_SESSION['version_reload'] = true;
    }
    $data['signatur_vorlage'] = json_encode($postfeld['signatur_vorlage']);

    $pw_fehler = '';
    $pw = $user['passwort'];
    if ($postfeld['alt'] !== '' && $postfeld['neu1'] !== '' && $postfeld['neu2'] !== '') {
        if ($pw != hash('sha512', $postfeld['alt']) && $pw != md5($postfeld['alt'])) {
            $pw_fehler = _PW_FEHLER1_;
        } else {
            $ok_pass = true;
            if ($postfeld['neu1'] !== $postfeld['neu2']) {
                $pw_fehler .= _PW_FEHLER2_;
                $ok_pass = false;
            } elseif (is_array($cfg_passwortsicherheit) && count($cfg_passwortsicherheit) > 0) {
                $ok_pass = false;
                $neuregex = $meldung = '';
                foreach ($cfg_passwortsicherheit as $warnhinweis => $pregex) {
                    $neuregex .= $pregex;
                    $meldung .= ' '.$warnhinweis;
                }
                if (intval(@preg_match("/^\S*".$neuregex."\S*$/", $postfeld['neu1'])) > 0) {
                    $ok_pass = true;
                } else {
                    $pw_fehler .= _PW_FEHLER3_.' '.trim($meldung);
                }
            }
            if ($ok_pass) {
                // ok:
                $data['passwort'] = hash('sha512', $postfeld['neu1']);
                $pw_fehler .= _PW_OK_;
            }
        }
    } else {
        if ($postfeld['alt'] === '' && ($postfeld['neu1'] !== '' || $postfeld['neu2'] !== '')) {
            $pw_fehler .= _PW_FEHLER1_;
        } elseif ($postfeld['neu1'] !== '' || $postfeld['neu2'] !== '') {
            $pw_fehler .= _PW_FEHLER2_;
        } elseif ($postfeld['alt'] !== '') {
            $pw_fehler .= _PW_FEHLER1_;
        }
    }

    foreach ($data as $key => $value) {
        if (is_array($value)) {
            $value = implode(',', $value);
        } else if ($value === '-1') {
            $value = '';
        }
        $user[$key] = $value;
    }
    $user->save();
    
    if (class_exists('Logger_File')) {
        $logger = new Logger_File('inc/'.$_SESSION['cfg_kunde'].'/crm_protocol.txt', true);
        $logger->info(p4n_mb_string('utf8_encode', _BENUTZER_.' ('.$uid.') '._EINSTELLUNGEN_.' ('._ALLGEMEIN_.') '._WURDE_GEAENDERT_.' ('.$_SESSION['mitarbeiter_name'].' ('.$_SESSION['user_id'].') - benutzer.php)'));
    }
    if ($cfg_pim_otherusers && $_SESSION['crm_version'] > 67) {
        $interface_refRepository = new Interface_RefRepository('pim_users_online');
        $row_interface = $interface_refRepository->getAllForTable('benutzer', $uid);
        $interface_ref_id = null;
        if (!empty($row_interface)) {
            $interface_ref_id = $row_interface[0]['interface_ref_id'];
        }
        $extern_id_val = array();
        if (isset($postfeld['pim_benutzer_online'])) {
            $extern_id_val = $postfeld['pim_benutzer_online'];
        }
        $interface_ref = new Interface_Ref($interface_ref_id);
        $interface_ref['interface'] = 'pim_users_online';
        $interface_ref['table_name'] = 'benutzer';
        $interface_ref['table_id'] = $uid;
        $interface_ref['extern_id'] = implode(',', $extern_id_val);
        $interface_ref->save();
    }

    unset($_SESSION['modern']['cache_menu']);
    unset($_SESSION['modern']['cache_fav']);
    echo javas('window.open(\'menu4.php?refresh=1\',\'menu\');');

    if ($m_sprache != $_SESSION['sprache']) {
        echo javas('location.href="'.$link.'&'.time().'";');
    }
}
// Image2
$userImage2 = 'dokumente/user_images/'.$uid.'_2.jpg';
if (isset($_GET['delete_user_image2'])) {
    unlink($userImage2);
}
$userImageError2 = '';
if (!empty($_FILES['user_image2']) && $_FILES['user_image2']['error'] == 0) {
    $fileData = $_FILES['user_image2'];
    $fileName = $fileData['name'];
    $xpl=explode('.', $fileName);
    $extension = strtolower($xpl[count($xpl)-1]);
    if (in_array($extension, array('jpg', 'jpeg', 'gif', 'png'))) {
        if (!is_dir(dirname($userImage2))) {
            mkdir(dirname($userImage2), 0777, true);
        }
        if ($cfg_user_unterschrift_ratio) {
            if (intval($fileData['size']) > (1024*1024*1)) {
                $userImageError = '<span style="color:red">'._FEHLER_.': '.$lang['_DOK-GROESSE_'].' &gt; 1 MB</span><br>';
                $fileData['error'] = 1;
            } else {
                move_uploaded_file($fileData['tmp_name'], $userImage2);
                if (isset($_POST['user_image_breite2']) && $_POST['user_image_breite2']!='' && isset($_POST['user_image_hoehe2']) && $_POST['user_image_hoehe2']!='') {
                    resize_bild($userImage2, $userImage2, $extension, intval($_POST['user_image_breite2']), intval($_POST['user_image_hoehe2']),(isset($_POST['user_image_prob2'])?true:false));
                }
            }
        } else {
            move_uploaded_file($fileData['tmp_name'], $userImage2);
			if ($_SESSION['cfg_kunde'] == 'carlo_opel_dbrent') {
			    resize_bild($userImage2, $userImage2, $extension, 250, 250, true);
			} else {
	            resize_bild($userImage2, $userImage2, $extension, 200, 100, true);
			}
        }
    } else {
        $userImageError2 = '<span style="color:red">'._UNERLAUBTEDATEI_.' ('.$extension.')</span><br>';
    }
}
// Image
$userImage = 'dokumente/user_images/'.$uid.'.jpg';
if (isset($_GET['delete_user_image'])) {
    unlink($userImage);
}
$userImageError = '';
if (!empty($_FILES['user_image']) && $_FILES['user_image']['error'] == 0) {
    $fileData = $_FILES['user_image'];
    $fileName = $fileData['name'];
    $xpl = explode('.', $fileName);
    $extension = strtolower($xpl[count($xpl)-1]);
    if (in_array($extension, array('jpg', 'jpeg', 'gif', 'png'))) {
        if (!is_dir(dirname($userImage))) {
            mkdir(dirname($userImage), 0777, true);
        }
        if ($cfg_signaturbild_ratio) {
            if (intval($fileData['size']) > (1024*1024*1)) {
                $userImageError = '<span style="color:red">'._FEHLER_.': '.$lang['_DOK-GROESSE_'].' &gt; 1 MB</span><br>';
                $fileData['error'] = 1;
            } else {
                move_uploaded_file($fileData['tmp_name'], $userImage);
                if (isset($_POST['user_image_breite']) && $_POST['user_image_breite'] != '' && isset($_POST['user_image_hoehe']) && $_POST['user_image_hoehe'] != '') {
                    resize_bild($userImage, $userImage, $extension, intval($_POST['user_image_breite']), intval($_POST['user_image_hoehe']), (isset($_POST['user_image_prob']) ? true : false));
                }
            }
        } else {
            move_uploaded_file($fileData['tmp_name'], $userImage);
			if ($_SESSION['cfg_kunde'] == 'carlo_opel_dbrent') {
			    resize_bild($userImage, $userImage, $extension, 250, 250, true);
			} else {
	            resize_bild($userImage, $userImage, $extension, 128, 128);
			}
        }
    } else {
        $userImageError = '<span style="color:red">'._UNERLAUBTEDATEI_.' ('.$extension.')</span><br>';
    }
}
if (is_file($userImage)) {
    list($userImage_width, $userImage_height) = getimagesize($userImage);
}
if (is_file($userImage2)) {
    list($userImage2_width, $userImage2_height) = getimagesize($userImage2);
}
// Startseite:
if ($cfg_opos_stidaufruf && !isset($cfg_benutzer_startseite['op_sap.php'])) {
    $cfg_benutzer_startseite['op_sap.php'] = 'OP-Liste';
}
if (($cfg_catch_retail || $cfg_catch_whole) && !isset($cfg_benutzer_startseite['leadanlage.php'])) {
    $cfg_benutzer_startseite['leadanlage.php'] = _LEADANLAGE_;
}
if (preg_match('/vw/i', $_SESSION['cfg_kunde']) || preg_match('/audi/i', $_SESSION['cfg_kunde'])) {
    $cfg_benutzer_startseite['serviceannahme.php'] = _SERVICECENTER_;
}
if ($cfg_stammdaten_lead || $cfg_leadmanagement_2020) {
    if ($_SESSION['crm_version'] > 60 && is_file('inc/utilities.php')) {
        include_once ('inc/utilities.php');
        if (hasRight($uid, 'leadprozess.php')) {	// $_SESSION['user_id']
            $cfg_benutzer_startseite['leadprozess.php'] = 'Leadprozess';
        }
        if (hasRight($uid, 'leadprozess_vkl.php')) {	// $_SESSION['user_id']
            $cfg_benutzer_startseite['leadprozess_vkl.php'] = 'Lead PIM VKL';
        }
    }
}
// Signatur
$signaturePatterns = array();
$res = $db->select(
    $sql_tab['email_vorlagen'],
    array(
        $sql_tabs['email_vorlagen']['email_vorlagen_id'],
        $sql_tabs['email_vorlagen']['bezeichnung']
    ),
    $sql_tabs['email_vorlagen']['kategorie'].'='.$db->str('_ADMINBENUTZER-SIGNATUR_'),
    $sql_tabs['email_vorlagen']['bezeichnung']
);
while ($row = $db->zeile($res)) {
    $signaturePatterns[$row[0]] = $row[1];
}

$signatur_vorlage = json_decode($user['signatur_vorlage'], true);
if (!is_array($signatur_vorlage)) {
    $signatur_vorlage = array();
}

$pim_benutzer_online = $pim_benutzer_online_def = array();
if ($cfg_pim_otherusers && $_SESSION['crm_version'] > 67) {
    $result_benutzer_gruppen = $db->select(
		$sql_tab['benutzer_gruppe'],
        array(
            $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
            $sql_tabs['benutzer_gruppe']['bezeichnung'],
        ),
        '',
        $sql_tabs['benutzer_gruppe']['rang'].' asc'
    );
    while ($row_benutzer_gruppen = $db->zeile($result_benutzer_gruppen)) {
        $pim_benutzer_online[$row_benutzer_gruppen[0]] = $row_benutzer_gruppen[1];
    }
    
    $interface_ref = new Interface_RefRepository('pim_users_online');
    $row = $interface_ref->getAllForTable('benutzer', $uid);
    if (!empty($row) && $row[0]['extern_id'] != '') {
        $pim_benutzer_online_def = explode(',', $row[0]['extern_id']);
    }
}

$hat_ldap = false;
$res = $db->select(
    $sql_tab['benutzer'],
    $sql_tabs['benutzer']['login_ldap'],
    $sql_tabs['benutzer']['benutzer_id']."=".$db->dbzahl($uid)
);
if ($row = $db->zeile($res)) {
    if ($row[0] != '') {
        $hat_ldap = true;
    }
}
$countries = array();
$res = $db->select(
    $sql_tab['kategorie'],
    $sql_tabs['kategorie']['bezeichnung'],
    $sql_tabs['kategorie']['modul'].'='.$db->dbzahl(12),
    $sql_tabs['kategorie']['bezeichnung'].' asc'
);
while ($row = $db->zeile($res)) {
    $country = $row[0];
    if (!empty($country)) {
        $countries[$country] = abkuerzung($country);
    }
}
$i = 0;
$form = new htmlform();
?>
<script type="text/javascript">
    function openSignPreview(signKey) {
        var patternId = document.getElementById("signatur_vorlage_"+signKey).value;
        if (parseInt(patternId) < 1) {
            return false;
        }
        P4nBoxHelper.iframe("sign_iframe", "benutzer.php?view=signatur&user_id=<?=$uid ?>&vorlage_id="+patternId+"&sig_id="+signKey, false, "500px", "500px");
    }
    <?php if ($cfg_signaturbild_ratio): ?>
        function check_zahl(t) {
            var zahl = t;
            for (var i = 0; i < zahl.value.length; i++) {
                var z = zahl.value.substring(i, i + 1);
                if (z < "0" || "9" < z)  {
                    var zahl2 = zahl.value.substring(0, zahl.value.length-1);
                    zahl.value = zahl2;
                    zahl.focus();
                    return false;
                }
            }
        }
    <?php endif; ?>
</script>
<?= $tabsList.$form->start('settings', $link, 'POST', true) ?>
<?php if ($_SESSION['user_id'] == $uid && !$hat_ldap): ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" <?= $cfg_password_policy ? '' : 'colspan="6"' ?>><?= _BPASSWORT_ ?></th>
        </tr>
        <?php if ($cfg_password_policy): ?>
            <tr class="odd first-child">
                <td class="td"><?= $form->submit('password_policy_reset', _PASSWORD_POLICY_RESET_PASS_).(($_GET['infotext'] != '') ? ' - '.entschluesseleWert($_GET['infotext']) : '' ) ?></td>
            </tr>
        <?php else : ?>
            <tr class="odd first-child">
                <th class="th"><?= _BPASSWORT_ALT_ ?></th>
                <td class="td"><?= $form->passwordinput('alt', 20) ?></td>
                <th class="th"><?= _BPASSWORT_NEU1_ ?></th>
                <td class="td"><?= $form->passwordinput('neu1', 20) ?></td>
                <th class="th"><?= _BPASSWORT_NEU2_ ?></th>
                <td class="td">
                    <?= $form->passwordinput('neu2', 20) ?>
                    <?php if (!empty($pw_fehler)): ?>
                        <font color=<?= $ok_pass ? 'green' : 'red' ?>><?= $pw_fehler ?></font>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endif; ?>
    </table>
<?php endif; ?>

<table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
    <tr class="heading">
        <th class="small th" colspan="<?php echo ($cfg_pers_emails_10?'11':'4'); ?>"><?= _BEMAIL_ ?></th>
    </tr>
    <tr class="odd first-child">
        <th class="th"></th>
        <th class="th">1</th>
        <th class="th">2</th>
        <th class="th">3</th>
		<?php
		if ($cfg_pers_emails_10) {
			for ($mi=4; $mi<=10; $mi++) {
				echo '<th class="th">'.$mi.'</th>';
			}
		}
		?>
    </tr>
    <tr class="odd">
        <th class="th"><?= _EMAIL_ ?></th>
        <?php
            // 1.1) If an AZURE-CATCH-link exists with the �send� option activated and it is linked to a CATCH user,
            // the exact mail address (5) must be placed in the pers. Einstellungen as E-Mail 1 for this CATCH User.
            // And cannot be changed unless the link is broken.
            if (!empty($cfg_microsoft_v2) && !AzureApp::canChangeSettings($uid, 'personal-email1', $user['email'])) :?>
                <td class="td" style="vertical-align:middle;padding-left:10px;"><?= $user['email'] ?> <i style="font-size: 10px">[MS Azure]</i>
                <?= $form->hidden('user_setting[email]', $user['email']) ?>
            <?php else: ?>
                <td class="td">
                <?= $form->textinput('user_setting[email]', $user['email'], 30) ?>
            <?php endif; ?>
        </td>
        <?php
            // 1.3) If an AZURE-CATCH-link is marked as �shared resource� and the �send� option is checked the linked e-mail address (5)
            // is considered a central Lead-e-Mail-Account and can be used in as Mail 2 in pers. Einstellungen to send mails from Lead tab
            // in the customer data set.
            // The e-mail address associated with this AZURE-CATCH-link could be tied directly to a user role.
            // Therefor a correspondingly marked e-mail address could be chosen in the user role and for every CATCH user in
            // this role it would be the second mail address in pers. Einstellungen.
            // Again, without the option to edit it on user basis.
            if (!empty($cfg_microsoft_v2) && !AzureApp::canChangeSettings($uid, 'personal-email2', $user['email2'])) :?>
                <td class="td" style="vertical-align:middle;padding-left:10px;"><?= $user['email2'] ?> <i style="font-size: 10px">[MS Azure]</i>
                <?= $form->hidden('user_setting[email2]', $user['email2']) ?>
            <?php else: ?>
                <td class="td">
                <?= $form->textinput('user_setting[email2]', $user['email2'], 30) ?>
            <?php endif; ?>
        </td>
        <td class="td">
        <?php
            // select from allowed emails by azure admin
            if (!empty($cfg_microsoft_v2) && !empty($cfg_microsoft_v2_email_send)) :
                $mail3 = array();
                $azure_user_emails = AzureApp::getEnabledEmails($_SESSION['user_id'], $_SESSION['user_role']);
                if (!empty($azure_user_emails['error'])) : ?>
                    <span class="error"><?=$azure_user_emails['error']?></span>
                <?php endif;
                if (count_p4n($azure_user_emails['data'])) {
                    foreach($azure_user_emails['data'] as $options) {
                        if($options['mail'] !== $user['email'] && $options['mail'] !== $user['email2']) {
                            $mail3[$options['mail']] = $options['mail'].($options['shared'] ? ' ('._SYSTEM_.' - '._EMAIL_.')' : '');
                        }
                    }
                }
                if (count_p4n($mail3)): ?>
                    <?= $form->selectinput('user_setting[email3]', array_merge(array(''=>_BITTE_WAEHLEN_), $mail3), $user['email3'], false ) ?>
                <?php else: ?>
                    <?= AzureApp::editLink(false) ?>
                <?php endif;
            else: ?>
                <?= $form->textinput('user_setting[email3]', $user['email3'], 30) ?>
            <?php endif; ?>
        </td><?php
		if ($cfg_pers_emails_10) {
			for ($mi=4; $mi<=10; $mi++) {
				echo '<td class="td">'.$form->textinput('user_setting[email'.$mi.']', $user['email'.$mi], 30).'</td>';
			}
		}
		?>
    </tr>
    <tr class="even">
        <th class="th"><?= $lang['_ADMINBENUTZER-SIGNATUR_'] ?></th>
        <td class="td"><?= $form->textareainput('user_setting[signatur]', $user['signatur'], 30, 3) ?></td>
        <td class="td"><?= $form->textareainput('user_setting[signatur2]', $user['signatur2'], 30, 3) ?></td>
        <td class="td"><?= $form->textareainput('user_setting[signatur3]', $user['signatur3'], 30, 3) ?></td>
		<?php
		if ($cfg_pers_emails_10) {
			for ($mi=4; $mi<=10; $mi++) {
				echo '<td class="td">'.$form->textareainput('user_setting[signatur'.$mi.']', $user['signatur'.$mi], 30, 3).'</td>';
			}
		}
		?>
    </tr>
    <?php if (!empty($signaturePatterns)): ?>
        <tr class="odd">
            <th class="th"><?= _VORLAGE_ ?></th>
            <td class="td" nowrap>
                <?= $form->selectinput('signatur_vorlage[1]', $signaturePatterns, @$signatur_vorlage[1], _OHNEVORLAGE_, 'id="signatur_vorlage_1"') ?>
                <?= $form->submit2('sig_button1', _VORSCHAU_, 'onClick="openSignPreview(1);"') ?>
            </td>
            <td class="td" nowrap>
                <?= $form->selectinput('signatur_vorlage[2]', $signaturePatterns, @$signatur_vorlage[2], _OHNEVORLAGE_, 'id="signatur_vorlage_2"') ?>
                <?= $form->submit2('sig_button2', _VORSCHAU_, 'onClick="openSignPreview(2);"') ?>
            </td>
            <td class="td" nowrap>
                <?= $form->selectinput('signatur_vorlage[3]', $signaturePatterns, @$signatur_vorlage[3], _OHNEVORLAGE_, 'id="signatur_vorlage_3"') ?>
                <?= $form->submit2('sig_button3', _VORSCHAU_, 'onClick="openSignPreview(3);"') ?>
            </td>
			<?php
		if ($cfg_pers_emails_10) {
			for ($mi=4; $mi<=10; $mi++) {
				echo '<td class="td" nowrap>'.$form->selectinput('signatur_vorlage['.$mi.']', $signaturePatterns, @$signatur_vorlage[$mi], _OHNEVORLAGE_, 'id="signatur_vorlage_'.$mi.'"').'</td>';
			}
		}
		?>
        </tr>
    <?php endif; ?>
</table>


<table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
    <tr class="heading">
        <th class="small th" colspan="6"><?= _PERSOENLICHE_DATEN_ ?></th>
    </tr>
	<?php
			$alle_av_telf=array();
			$telzus='';
			if ($cfg_avag_telnr_check) {
				$telzus.=' '.av_telnr_ch_ol().' ';
				$alle_av_telf['user_setting[mobilfon]']=$lang['_MOBILFON_'];
				$alle_av_telf['user_setting[telefon]']=$lang['_TELEFON2_'];
				$alle_av_telf['user_setting[fax]']=$lang['_FAX_'];
			}
	?>
    <tr class="odd first-child">
        <th class="th"><?= _MOBILFON_ ?></th>
        <td class="td"><?= $form->textinput('user_setting[mobilfon]', $user['mobilfon'], 30, $telzus) ?></td>
        <th class="th"><?= _TELEFON2_ ?></th>
        <td class="td"><?= $form->textinput('user_setting[telefon]', $user['telefon'], 30, $telzus) ?></td>
        <th class="th"><?= _FAX_ ?></th>
        <td class="td"><?= $form->textinput('user_setting[fax]', $user['fax'], 30, $telzus) ?></td>
    </tr>
    <?php if (!empty($cfg_benutzer_adresse)): ?>
        <tr class="<?= $i++ % 2 ? 'odd' : 'even' ?>">
            <th class="th"><?= _ADRESSE_ ?></th>
            <td class="td"><?= $form->textinput('user_setting[adresse]', $user['adresse'], 30) ?></td>
            <th class="th"><?= _PLZ_.' / '._ORT_ ?></th>
            <td class="td" nowrap>
                <?= $form->textinput('user_setting[plz]', $user['plz'], 5) ?>&nbsp;/&nbsp;
                <?= $form->textinput('user_setting[ort]', $user['ort'], 18) ?>
            </td>
            <th class="th"><?= _LAND_ ?></th>
            <td class="td"><?= $form->selectinput('user_setting[land]', $countries, $user['land'], _KEINE_AUSWAHL_) ?></td>
        </tr>
    <?php endif; ?>
    <tr class="<?= $i++ % 2 ? 'odd' : 'even' ?>">
        <th class="th">
            <?= $cfg_wegbeschreibung_kvbestaetigungsmail ? 'zus�tzl. Email-Empf�nger f�r KV-Best�tigung' : _WEGBESCHREIBUNG_ ?>
        </th>
        <td class="td"><?= $form->textareainput('user_setting[wegbeschreibung]', $user['wegbeschreibung'], 30, 3) ?></td>
        <th class="th"><?= _BILD_ ?></th>
        <td class="td">
            <?= $form->dateiinput('user_image', $userImage) ?>
            <?php if ($cfg_signaturbild_ratio): ?>
                <br>
                <?= $form->zahlinput('user_image_breite', '', 3,'onKeyUp="check_zahl(this)" Placeholder="'._BREITE_.'"').' x ' ?>
                <?= $form->zahlinput('user_image_hoehe', '', 3,'onKeyUp="check_zahl(this)" Placeholder="'._HOEHE_.'"').'px' ?><br>
                <?= $form->checkinput('user_image_prob', true).' '._CSS_PROPORTIONEN_ ?>
                <div style="height:5px;display:block;"></div> <?= $userImageError ?>
            <?php endif; ?>
        </td>
        <td class="td" colspan="2" nowrap>
            <?php if (is_file($userImage)): ?>
                <div style="position: relative;" title="<?= $userImage_width ?> x <?= $userImage_height?> px">
                    <img style="max-width:300px" src="<?= $userImage.'?'.time() ?>" />
                    <span style="top:-1px;left:-1px;cursor:pointer;position:absolute;">
                        <?= link2(_DOK_LOESCH_, $link.'&delete_user_image', 'loesch.gif', _ABFRAGE_LOESCHEN_) ?>
                    </span>
                </div>
            <?php endif; ?>
        </td>
    </tr>
    <?php if ($cfg_user_unterschrift): ?>
        <tr class="<?= $i++ % 2 ? 'odd' : 'even' ?>">
            <th class="th"><?= _BILD_.' '._DATENSCHUTZ1K_5_ ?></th>
            <td class="td">
                <?= $form->dateiinput('user_image2', $userImage2) ?>
                <?php if ($cfg_user_unterschrift_ratio): ?>
                    <br>
                    <?= $form->zahlinput('user_image_breite2', '', 3,'onKeyUp="check_zahl(this)" Placeholder="'._BREITE_.'"').' x ' ?>
                    <?= $form->zahlinput('user_image_hoehe2', '', 3,'onKeyUp="check_zahl(this)" Placeholder="'._HOEHE_.'"').'px' ?><br>
                    <?= $form->checkinput('user_image_prob2', true).' '._CSS_PROPORTIONEN_ ?>
                    <div style="height:5px;display:block;"></div> <?= $userImageError2 ?>
                <?php endif; ?>
            </td>
            <td class="td" colspan=4>
                <?php if (is_file($userImage2)): ?>
                    <div style="position: relative;" title="<?= $userImage2_width ?> x <?= $userImage2_height?> px">
                        <img style="max-width:300px" src="<?= $userImage2.'?'.time() ?>" />
                        <span style="top:-1px;left:-1px;cursor:pointer;position:absolute;">
                            <?= link2(_DOK_LOESCH_, $link.'&delete_user_image2', 'loesch.gif', _ABFRAGE_LOESCHEN_) ?>
                        </span>
                    </div>
                <?php endif; ?>
            </td>
        </tr>
    <?php endif; ?>
</table>

<table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
    <tr class="heading">
        <th class="small th" colspan="2"><?= _WEITERE_ ?></th>
    </tr>
    <tr class="odd first-child">
        <th class="th"><?= _BSTYLE_ ?></th>
        <td class="td" nowrap><?= $form->selectinput('user_setting[stil]', Modern_Helper_Stile::getFarbschemaSelectArr(), $user['stil']) ?></td>
    </tr>
    <tr class="even">
        <th class="th" nowrap><?= _BSTARTSEITE_ ?></th>
        <td class="td" nowrap><?= $form->selectinput('user_setting[startseite]', $cfg_benutzer_startseite, $user['startseite']/*$_SESSION['startseite']*/) ?></td>
    </tr>
    <tr class="odd">
        <th class="th" nowrap><?= _BSPRACHE_ ?></th>
        <td class="td"><?= $form->selectinput('user_setting[sprache]', $cfg_benutzer_sprache, $user['sprache']/*$_SESSION['sprache']*/) ?></td>
    </tr>
    <?php if ($cfg_pim_otherusers && $_SESSION['crm_version']>67): ?>
        <tr class="even">
            <th class="th" nowrap><?= $lang['_PIM-USERONLINE_'] ?></th>
            <td class="td" nowrap><?= $form->selectinput('pim_benutzer_online', $pim_benutzer_online, $pim_benutzer_online_def, false, '', true, (count($pim_benutzer_online) > 4 ? 5 : count($pim_benutzer_online))) ?></td>
        </tr>
    <?php endif; ?>
    <?php if ($cfg_design70_btn && (int)$_SESSION['user_id'] === 1): ?>
        <tr class="even">
            <th class="th" nowrap>Neues Design</th>
            <td class="td" nowrap>
                <?= $form->hidden('user_setting[neuesdesign]', false) ?>
                <?= $form->checkinput('user_setting[neuesdesign]', $user['neuesdesign']) ?>
            </td>
        </tr>
    <?php endif; ?>
</table>
<?php
if ($cfg_kat_portal or $_SESSION['cfg_kunde']=='portal') {
	$alle_pgs=array();
	$alle_p4n_pg=array();
	$res=$db->select(
		$sql_tab['produkt_gruppe'],
		array(
			$sql_tabs['produkt_gruppe']['gruppe_id'],
			$sql_tabs['produkt_gruppe']['parent_id'],
			$sql_tabs['produkt_gruppe']['bezeichnung'],
			$sql_tabs['produkt_gruppe']['rang']
		),
		$sql_tabs['produkt_gruppe']['aktiv'].'=1',
		$sql_tabs['produkt_gruppe']['parent_id'].','.$sql_tabs['produkt_gruppe']['rang']
	);
	while ($row=$db->zeile($res)) {
		$alle_pgs[$row[0]]=$row[2];
		$bez=$row[2];
		if (intval($row[1])>0) {
			$bez=$alle_pgs[$row[1]].' - '.$bez;
		}
		$alle_p4n_pg[$row[0]]=$bez;
	}
	@asort($alle_p4n_pg);
	$p4nkats=array();
	$res=$db->select(
		$sql_tab['kategorie'],
		array(
			$sql_tabs['kategorie']['modul'],
			$sql_tabs['kategorie']['bezeichnung'],
			$sql_tabs['kategorie']['kategorie_id']
		),
		$sql_tabs['kategorie']['modul'].' in (200,201,202,203)'
	);
	while ($row=$db->zeile($res)) {
		$p4nkats[intval($row[0])][$row[2]]=$row[1];
	}
    $p4nkats[200] = is_array($p4nkats[200]) ? $p4nkats[200] : array();
    $p4nkats[201] = is_array($p4nkats[201]) ? $p4nkats[201] : array();
    $p4nkats[202] = is_array($p4nkats[202]) ? $p4nkats[202] : array();
    $p4nkats[203] = is_array($p4nkats[203]) ? $p4nkats[203] : array();
	@asort($p4nkats);
	@asort($p4nkats[200]);
	@asort($p4nkats[201]);
	@asort($p4nkats[202]);
	@asort($p4nkats[203]);
	$sel1=array();
	if (isset($besonderes_recht['p4n_verantwortlich'])) {
		$sel1=$besonderes_recht['p4n_verantwortlich'];
	}
	$sel2=array();
	if (isset($besonderes_recht['p4n_auskennen'])) {
		$sel2=$besonderes_recht['p4n_auskennen'];
	}
	$sel3=array();
	if (isset($besonderes_recht['p4n_team'])) {
		$sel3=$besonderes_recht['p4n_team'];
	}
	$sel4=array();
	if (isset($besonderes_recht['p4n_aufgaben'])) {
		$sel4=$besonderes_recht['p4n_aufgaben'];
	}
	$sel5=array();
	if (isset($besonderes_recht['p4n_nebenaufgaben'])) {
		$sel5=$besonderes_recht['p4n_nebenaufgaben'];
	}
	$sel6=array();
	if (isset($besonderes_recht['p4n_bereich'])) {
		$sel6=$besonderes_recht['p4n_bereich'];
	}
	$wochenstunden='';
	if (isset($besonderes_recht['p4n_wochenstunden'])) {
		$wochenstunden=$besonderes_recht['p4n_wochenstunden'];
	}
	$tabp='<table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100"><tr class="heading">
        <th class="small th" colspan="7">Prof4Net</th>
    </tr><tr class="odd first-child">
        <th class="th">Produktverantwortlich</th><th class="th">Bei diesen Produkten kenne ich mich aus</th><th class="th">Teammitglied</th><th class="th">Aufgabenfelder</th><th class="th">Nebenaufgaben</th><th class="th">Bereich</th><th class="th">Anzahl Wochenstunden</th>
    </tr>';
//	ion selectinput($name, $inhaltfeld, $default=-99, $bw=false, $other='', $multiple=false, $multiple_rows=5, $cache=array()) {
	$tabp.='<tr class="even">
        <td class="td" nowrap>'.$form->selectinput('p4n_verantwortlich', $alle_p4n_pg, $sel1, false, '', true, 10).'</td>
        <td class="td" nowrap>'.$form->selectinput('p4n_auskennen', $alle_p4n_pg, $sel2, false, '', true, 10).'</td>
        <td class="td" nowrap>'.$form->selectinput('p4n_team', $p4nkats[200], $sel3, false, '', true, 10).'</td>
        <td class="td" nowrap>'.$form->selectinput('p4n_aufgaben', $p4nkats[201], $sel4, false, '', true, 10).'</td>
        <td class="td" nowrap>'.$form->selectinput('p4n_nebenaufgaben', $p4nkats[202], $sel5, false, '', true, 10).'</td>
        <td class="td" nowrap>'.$form->selectinput('p4n_bereich', $p4nkats[203], $sel6, false, '', true, 10).'</td>
        <td class="td" nowrap>'.$form->zahlinput('p4n_wochenstunden', $wochenstunden, 5).'</td>
    </tr>';
	
	$tabp.='</table>';
	echo $tabp;
}
			$zus_submit2='';
			if ($cfg_avag_telnr_check) {
				$zus_submit2.='onClick="'.av_telnr_ch_sub().'"';
			}
?>
<?= $form->submit('submit', _SUBMIT_STAMMDATEN_, $zus_submit2).$form->ende() ?>
<?php fuss();
