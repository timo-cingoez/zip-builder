<?php
if (substr($_SERVER["PHP_SELF"], -strlen('admin_benutzerrollen.php')) !== 'admin_benutzerrollen.php') {
    exit(_KEINRECHT_);
}

$role = new User_Role($rid2);
if (!$role->load()) {
    exit(_LS_ROLLE_.' '._NICHT_GEFUNDEN_.' ('.$rid2.')');
}
if (isset($postfeld['submit_sett'])) {
    $settings = explode($sepa, $role['einstellungen']);
    foreach (range(0, 35) as $key) {
        if (!isset($settings[$key])) {
            $settings[$key] = '';
        }
    }
    $settings[0] = $postfeld['e_r_nav'];
    $settings[1] = $postfeld['e_r_suche'];
    $settings[2] = $postfeld['e_r_filter'];
    $settings[3] = $postfeld['e_r_gruppenfilter'];
    $settings[4] = $postfeld['e_sprache'];
    $settings[5] = $postfeld['e_stil'];
    $settings[17] = $postfeld['erinnerung'];
    $settings[19] = $postfeld['kal_w_st'];
    $settings[20] = $postfeld['kal_w_e'];
    $settings[21] = $postfeld['kal_w_s'];
    $settings[22] = $postfeld['korrespondenz_anzahl'];
    $settings[24] = remove_wwwlink_prefix($postfeld['e_startseite']);
    $settings[25] = $postfeld['e_r_feldupdate'];
    $settings[27] = $postfeld['e_kernaz'];
    $settings[28] = $postfeld['e_ccvn'];
    $settings[33] = $postfeld['kal_std_ansicht'];
    $settings[34] = $postfeld['recht_liste_neu'];
    $signatur_vorlage = !empty($postfeld['signatur_vorlage']) ? $postfeld['signatur_vorlage'] : array(1 => '-1', 2 => '-1', 3 => '-1');
    $settings[35] = json_encode($signatur_vorlage);
    $role['einstellungen'] = implode($sepa, $settings);
    $role['besonderes_recht'] = prepareExtraRights(
        $role['besonderes_recht'],
        array(
            'gdpr' => (empty($postfeld['gdpr']) ? false : $postfeld['gdpr']),
            'handbuch' => !empty($postfeld['handbuch']),
            'menu_icon_phone' => !empty($postfeld['menu_icon_phone']),
            'textbaustein_gruppe' => (empty($postfeld['textbaustein_gruppe']) ? -1 : $postfeld['textbaustein_gruppe']),
            'design' => !empty($postfeld['e_design']),
            'bdc_lead_is_default_user' => !empty($postfeld['bdc_lead_is_default_user']),
            'bdc_lead_creation_redirect_to_lead' => !empty($postfeld['bdc_lead_creation_redirect_to_lead']),
            'open_bdc_modal_after_customer_creation' => !empty($postfeld['open_bdc_modal_after_customer_creation']),
            'je_domain_voll' => $postfeld['je_domain_voll']
        )
    );
    // PIM:
    if (!isset($postfeld['pim_l'])) {
        $postfeld['pim_l']=array();
    }
    foreach ($postfeld['pim_l'] as &$val) {
        if ($val === '-1') {
            $val = '';
        }
    }
    if (!isset($postfeld['pim_r'])) {
        $postfeld['pim_r']=array();
    }
    foreach ($postfeld['pim_r'] as &$val) {
        if ($val === '-1') {
            $val = '';
        }
    }
    $role['pim_anordnung'] = implode(',', $postfeld['pim_l']).'/'.implode(',', $postfeld['pim_r']);
    $role->save();
    if ($rid2 > 0) {
        rolle2benutzer_array_new($rid2);
    }
    $logger = new Logger_File('inc/'.$_SESSION['cfg_kunde'].'/crm_protocol.txt', true);
    $logger->info(p4n_mb_string('utf8_encode', _BENUTZERROLLEN_.'-'._EINSTELLUNGEN_.' ('.$postfeld['bezeichnung'].') '._WURDE_GEAENDERT_.' ('.$_SESSION['mitarbeiter_name'].' ('.$_SESSION['user_id'].') - admin_benutzerrollen.php?view=settings)'));
    if ($postfeld['submit_sett'] === 'only_save') {
        clear_all_buffer();
        exit();
    }
}
$besondere_rechte = unserialize($role['besonderes_recht']);
if (!is_array($besondere_rechte)) {
    $besondere_rechte = array();
}
//      Recht (0-3), Sprache 4, Stil 5, Email1 6, Email2 7, Email3 8, Signatur1 9, Signatur2 10, Signatur3 11, CTI 12, CTI_line 13, CTI_popup 14, CTI_letzteziff 15, CTI_vorwahl 16,
// 		Kal_erinnerung 17, Farbe 18, Anzeige (8-22) 19/20, Zeilenschritt 21
//		Korres-Anzahl 22, Dok-Ordner 23, Startseite 24, Recht feldupdate 25, ISDN 26
$e_r = explode($sepa, $role['einstellungen']);
if ($cfg_callcenter) {
    $cfg_benutzer_startseite['leitfaden_tagesliste.php'] = 'Tagesauswertung';
}
if ($cfg_opos) {
    $cfg_benutzer_startseite['op_sap.php'] = 'OP-Liste';
}
if ($cfg_stammdaten_lead || $cfg_leadmanagement_2020) {
    $cfg_benutzer_startseite['leadprozess.php'] = _LEADPROZESS_;
    $cfg_benutzer_startseite['leadprozess_vkl.php'] = _LEADPROZESS_VERKAUFSLEITER_;
}
if ($cfg_letztevkp_genehmigung2_mail) {
    $cfg_benutzer_startseite['kfz_oppliste.php'] = 'letzte VKP';
}
if ($cfg_kfz) {
    $cfg_benutzer_startseite['kfz_schnellsuche.php'] = _KFZ_SUCHE_;
}
// braucht man das??
if (!isset($cfg_benutzer_style['style_pcvisit.css'])) {
    $cfg_benutzer_style['style_pcvisit.css'] = 'PC Visit Administration';
}
if (!empty($cfg_textbausteine_gruppe)) {
    $textbaustein_gruppen = array();
    $result = $db->select(
        $sql_tab['kategorie'],
        array(
            $sql_tabs['kategorie']['zusatz2']
        ),
        $sql_tabs['kategorie']['modul'] . ' IN(62,63,64,67) AND ' . $sql_tabs['kategorie']['zusatz2'] . ' != ""'
    );
    while ($row = $db->zeile($result)) {
        if ($row[0] != -1) {
            $textbaustein_gruppen[$row[0]] = $row[0];
        }  
    }
    if (!is_array($textbaustein_gruppen)){
        $textbaustein_gruppen=array($textbaustein_gruppen);
    }
    $textbaustein_gruppen = array_unique($textbaustein_gruppen);
}
// Signature
$signatur_vorlage = json_decode($e_r[35], true);
$signaturePatterns = array();
$res = $db->select(
    $sql_tab['email_vorlagen'],
    array(
        $sql_tabs['email_vorlagen']['email_vorlagen_id'],
        $sql_tabs['email_vorlagen']['bezeichnung']
    ),
    $sql_tabs['email_vorlagen']['kategorie'].'='.$db->str('_ADMINBENUTZER-SIGNATUR_'),
    $sql_tabs['email_vorlagen']['bezeichnung']
);
while ($row = $db->zeile($res)) {
    $signaturePatterns[$row[0]] = $row[1];
}
// Kalender
$erinnerung_zeit = array(
    '0'     =>_TERMINERINNERUNG_1_,
    '5'     =>_TERMINERINNERUNG_2_,
    '10'    =>_TERMINERINNERUNG_3_,
    '15'    =>_TERMINERINNERUNG_4_,
    '30'    =>_TERMINERINNERUNG_5_,
    '45'    =>_TERMINERINNERUNG_6_,
    '60'    =>_TERMINERINNERUNG_7_,
    '120'   =>_TERMINERINNERUNG_8_,
    '300'   =>_TERMINERINNERUNG_9_,
    '1440'  =>_TERMINERINNERUNG_10_,
    '2880'  =>_TERMINERINNERUNG_11_,
    '4320'  =>_TERMINERINNERUNG_12_,
    '10080' =>_TERMINERINNERUNG_13_,
    '20160' =>_TERMINERINNERUNG_14_,
    '30240' =>_TERMINERINNERUNG_15_,
    '40320' =>_TERMINERINNERUNG_16_
);
$uhrzeit_stunden_beginn = array();
$uhrzeit_stunden_ende = array();
for ($index = 0; $index < 25; $index++) {
    if ($index < 24) {
        $uhrzeit_stunden_beginn[$index] = ($index<10 ? '0' : '').$index;
    }
    if ($index > 0) {
        $uhrzeit_stunden_ende[$index] = ($index<10 ? '0' : '').$index;
    }
}
// Blocks f�r PIM
if (!empty($cfg_benutzerrolle_pimanordnung)) {
    $anz_pim = 10;
    $pim_blockinfo = array(
        'wvl'        => $lang['_K-WVL1_'],
        'kalender'   => $lang['_PIM-KALENDER_'],
        'gebkurz'    => _SP_GEBURTSTAGSLISTE_,
        'geblang'    => _SP_GEBURTSTAGSLISTE_.' ('._LANG_.')',
        'aufgaben'   => $lang['_ADMIN-AUFGABEN_'],
        'pinnwand'   => $lang['_PIM-PINNWAND_'],
        'useronline' => $lang['_PIM-USERONLINE_'],
        'opp'        => _OPPORTUNITIES_,
        'bm'         => _BMHEADLINE_,
        'pm'         => _PMHEADLINE_,
        'notizen'    => _KTYP15_,
        'tkpwps'     => _WERKSTATT_.' '._NAECHSTEN_TERMINE2_,
        'filter'     => _FILTER_,
        'news'       => _NEUIGKEITEN_
    );
    if (is_file('inc/lib_sn.php')) {	//  && extension_loaded("ChartDirector PHP API")
        $pim_blockinfo['verkaufsvorgabe'] = _VERKAUFSZIELE_;
    }
    if ($carlo_tw && $cfg_vw) {
        $pim_blockinfo['pim_reminders'] = _ERINNERUNG_;
    }
    $pim_blockinfo['letztenkunden'] = _TERMIN_T_RHYT5_.' '._KUNDEN_;
    if (empty($cfg_bm)) {
        unset($pim_blockinfo['bm']);
    }
	if ($cfg_leads_at_pim) {
        $pim_blockinfo['lead_pim']='Lead PIM';
	}
	if ($cfg_pim_externeangebote) {
		$pim_blockinfo['externe_ang']  = 'Externe Angebote';
	}
	
    $std_links = array('wvl', 'opp', 'pm', 'bm', 'filter');
    $std_rechts = array('gebkurz', 'tkpwps', 'kalender', 'notizen', 'aufgaben', 'pinnwand', 'useronline');
    $std_unten = array('geblang');
    $l_i = 0;
    $r_i = 0;
    $u_i = 0;
    $pim_vor_l=array();
    $pim_vor_r=array();
    while (list($key, $val) = @each($std_links)) {
        if (isset($pim_blockinfo[$val])) {
            $pim_vor_l[$l_i] = $val;
            $l_i++;
        }
    }
    while (list($key, $val) = @each($std_rechts)) {
        if (isset($pim_blockinfo[$val])) {
            $pim_vor_r[$r_i] = $val;
            $r_i++;
        }
    }
    $u_i = $l_i;
    if ($r_i > $u_i) {
        $u_i = $r_i;
    }
    while (list($key, $val) = @each($std_unten)) {
        if (isset($pim_blockinfo[$val])) {
            $pim_vor_l[$u_i] = $val;
            $u_i++;
        }
    }
    if ($role['pim_anordnung'] != '') {
        $pim_xlp = explode('/', $role['pim_anordnung']);
        $pim_vor_l = explode(',', $pim_xlp[0]);
        $pim_vor_r = explode(',', $pim_xlp[1]);
    }
}

$i = 1;
function trClass($i = 0) {
    return $i % 2 == 0 ? 'even' : 'odd';
}
?>
<script>
    function openSignPreview(signKey) {
        var patternId = document.getElementById("signatur_vorlage_" + signKey).value;
        if (parseInt(patternId) < 1) {
            return false;
        }
        P4nBoxHelper.iframe("sign_iframe", "benutzer.php?view=signatur&user_id=<?= @$_SESSION['user_id'] ?>&vorlage_id="+patternId+"&sig_id="+signKey, false, "500px", "500px");
    }
    function checkForm() {
        var save = false;
        var $form = jq1112("#br_form");
        if ($form.data("changed")) {
            save = confirm("<?= _SWECHSEL_FRAGE_ ?>");
        }
        P4nBoxHelper.startloading(true);
        if (save) {
            var data = $form.serialize();
            RequestHelper.post("<?= $urLink ?>", data+"&submit_sett=only_save", function() {
                P4nBoxHelper.stoploading();
                P4nBoxHelper.startloading(true, "<?= _ERFOLGREICH_.' '._GESPEICHERT_ ?>");
                return true;
            });
        }
        return true;
    }
    jq1112(document).ready(function () {
        jq1112("#br_form :input").change(function() {
            jq1112("#br_form").data("changed",true);
        });
    });
</script>
<?= $tabsList ?>
<?= $form->start('form_sett', $urLink, 'POST', false, 'id="br_form" onSubmit="P4nBoxHelper.startloading(true);"', $formReadOnly) ?>
<?= $form->hidden('rid', $rid2) ?>
<table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
    <tr class="heading">
        <th class="small th" colspan="2">
            <?= _ALLGEMEIN_.' / ' ?>
            <?= _BENUTZERROLLE_.': '.$form->selectinput('rid9', $rollen, $rid2, false, 'onChange="P4nBoxHelper.startloading(true);location.href=\''.$urLink.'&rid=\'+this.options[this.selectedIndex].value;"') ?>
        </th>
    </tr>
    <tr class="<?= trClass($i++) ?> first-child">
        <th class="th"><?= _BSTARTSEITE_ ?></th>
        <td class="td"><?= $form->selectinput('e_startseite', $cfg_benutzer_startseite, $e_r[24]) ?></td>
    </tr>
    <tr class="<?= trClass($i++) ?>">
        <th class="th"><?= _BSPRACHE_ ?></th>
        <td class="td"><?= $form->selectinput('e_sprache', $cfg_benutzer_sprache, $e_r[4]) ?></td>
    </tr>
    <tr class="<?= trClass($i++) ?>">
        <?php $farbeStileListe=Modern_Helper_Stile::getFarbschemaSelectArr(); 
            unset($farbeStileListe['']);
        ?>
        <th class="th"><?= _BSTYLE_ ?></th>
        <td class="td"><?= $form->selectinput('e_stil', $farbeStileListe, trim($e_r[5])==''?'style_blau.css':$e_r[5]) ?></td>
    </tr>
    <?php if ($cfg_design70_btn) { ?>
    <tr class="<?= trClass($i++) ?>">
        <th class="th"><?= _NEUES_.' '._DESIGN_ ?></th>
        <td class="td"><?= $form->checkinput('e_design', @$besondere_rechte['design']) ?></td>
    </tr>
    <?php } ?>
    <?php
    if (!empty($cfg_microsoft_v2)) :
        $azure_data = AzureApp::getRoleEmail($rid2);
    ?>
        <tr class="<?= trClass($i++) ?>">
            <th class="th"><?= 'MS '._EMAIL_.' '._VERSAND_ ?></th>
            <td class="td">
                <?php if (!empty($azure_data['error'])): ?>
                    <div style="color:red;background-color: lightyellow;padding:6px 10px 6px 6px;height: 26px; display: inline-block;"><?= $azure_data['error'] ?></div>
                <?php endif; ?>
                <?php if (!empty($azure_data['email'])): ?>
                    <div style="padding:6px 10px 6px 6px;height: 26px; display: inline-block"><?=$azure_data['email']?></div> <a href="<?= $cfg_basedir ?>/carlocrm/einstellungen.php?view=interfaces#Microsoft-Azure-Graph" title="Change via Microsoft Azure Graph"><?= _AENDERN_ ?></a>
                <?php else : ?>
                    <div style="color:red;background-color: lightyellow;padding:6px 10px 6px 6px;height: 26px; display: inline-block;"><?= _KEINE_.' '._EMAIL_ ?></div> <a href="<?= $cfg_basedir ?>/carlocrm/einstellungen.php?view=interfaces#Microsoft-Azure-Graph" title="Add via Microsoft Azure Graph"><?= _HINZUFUEGEN_ ?></a>
                <?php endif; ?>
            </td>
        </tr>
    <?php endif; ?>
    <tr class="<?= trClass($i++) ?>">
        <th class="th"><?= _BEMAIL_.' - '._VORLAGE_ ?></th>
        <td class="td">
            <?php if (empty($signaturePatterns)): ?>
                <?= _KEINE_VORLAGEN_ ?>
            <?php else : ?>
                <?= $form->selectinput('signatur_vorlage[1]', $signaturePatterns, @$signatur_vorlage[1], _OHNEVORLAGE_, 'id="signatur_vorlage_1"') ?>
                <?= $form->submit2('sig_button1', _VORSCHAU_, 'onClick="openSignPreview(1);"') ?>
            <?php endif; ?>
        </td>
    </tr>
    <tr class="<?= trClass($i++) ?>">
        <th class="th"><?= _KORRESPONDENZ_ ?></th>
        <td class="td">
            <?= _ANZEIGE_ANZAHL_ ?>:&nbsp;<?= $form->zahlinput('korrespondenz_anzahl', $e_r[22], 3) ?>
        </td>
    </tr>
    <tr class="<?= trClass($i++) ?>">
        <th class="th"><?= _EMAIL_.' '._VERSAND_.' '._JE_DOMAIN_.' ('._VOLLSTAENDIG_.')' ?></th>
        <td class="td">
            <?= $form->checkinput('je_domain_voll', @$besondere_rechte['je_domain_voll']) ?>
        </td>
    </tr>
    <?php if (@$besondere_rechte['design']): ?>
        <tr class="<?= trClass($i++) ?>">
            <th class="th"><?= 'Neues Design - BDC '._VORAUSWAHL_.' '._LEADANLAGE_.' - '._BENUTZER_ ?></th>
            <td class="td">
               <?= $form->checkinput('bdc_lead_is_default_user', @$besondere_rechte['bdc_lead_is_default_user']) ?>
            </td>
        </tr>
        <tr class="<?= trClass($i++) ?>">
            <th class="th"><?= 'Neues Design - '._LEADANLAGE_.' - '._WEITERLEITUNG_.' '._ZU_.' '._LEAD_ ?></th>
            <td class="td">
                <?= $form->checkinput('bdc_lead_creation_redirect_to_lead', @$besondere_rechte['bdc_lead_creation_redirect_to_lead']) ?>
            </td>
        </tr>
        <tr class="<?= trClass($i++) ?>">
            <th class="th"><?= 'Neues Design - '._NEUANLAGE_.' - '._WEITERLEITUNG_.' '._ZU_.' BDC' ?></th>
            <td class="td">
                <?= $form->checkinput('open_bdc_modal_after_customer_creation', @$besondere_rechte['open_bdc_modal_after_customer_creation']) ?>
            </td>
        </tr>
    <?php endif; ?>
</table>
<?php $i = 1; ?>
<!-- $inhalt=p4n_mb_string('str_replace', '{e_korrespondenz}', , $inhalt);-->
<table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
    <tr class="heading">
        <th class="small th" colspan="2"><?= _BRECHTE_ ?></th>
    </tr>
    <tr class="<?= trClass($i++) ?> first-child">
        <th class="th"><?= _RECHTE_NAV_ ?></th>
        <td class="td"><?= $form->checkinput('e_r_nav', $e_r[0]) ?></td>
    </tr>
    <tr class="<?= trClass($i++) ?>">
        <th class="th"><?= _RECHTE_SUCHE_ ?></th>
        <td class="td"><?= $form->checkinput('e_r_suche', $e_r[1]) ?></td>
    </tr>
    <tr class="<?= trClass($i++) ?>">
        <th class="th"><?= _RECHTE_FILTER_ ?></th>
        <td class="td"><?= $form->checkinput('e_r_filter', $e_r[2]) ?></td>
    </tr>
    <tr class="<?= trClass($i++) ?>">
        <th class="th"><?= _RECHTE_GRUPPENFILTER_ ?></th>
        <td class="td"><?= $form->checkinput('e_r_gruppenfilter', $e_r[3]) ?></td>
    </tr>
    <tr class="<?= trClass($i++) ?>">
        <th class="th"><?= _RECHT_FELDUPDATE_ ?></th>
        <td class="td"><?= $form->checkinput('e_r_feldupdate', $e_r[25]) ?></td>
    </tr>
    <tr class="<?= trClass($i++) ?>">
        <th class="th"><?= _RECHT_BED2_ ?></th>
        <td class="td"><?= $form->checkinput('recht_liste_neu', $e_r[34]) ?></td>
    </tr>
    <tr class="<?= trClass($i++) ?>">
        <th class="th"><?= _HANDBUCH_ ?></th>
        <td class="td"><?= $form->checkinput('handbuch', @$besondere_rechte['handbuch']) ?></td>
    </tr>
    <?php if ($kernaz_ja): ?>
        <tr class="<?= trClass($i++) ?>">
            <th class="th">Kernarbeitszeit</th>
            <td class="td"><?= $form->textinput('e_kernaz', $e_r[27], 50).'<br>(z.B. 08:00-12:00,12:30-16:45)' ?></td>
        </tr>
        <tr class="<?= trClass($i++) ?>">
            <th class="th">NEs vor-/nachmittag</th>
            <td class="td"><?= $form->checkinput('e_ccvn', $e_r[28]) ?></td>
        </tr>
    <?php endif; ?>
    <tr class="<?= trClass($i++) ?>">
        <th class="small th"><?= _DSGVO_.'-'.$lang['_DOK-RECHTE_'] ?></th>
        <td class="td">
            <?= $form->checkinput('gdpr[view]', @$besondere_rechte['gdpr']['view'], 'id="gdpr1" onClick="if (this.checked) { jq1112(\'#gdpr2\').removeAttr(\'checked\') }"') ?>
            <?= _GDPR_ANONYM_EXPORT_.' + '._GDPR_ANONYM_LISTENANSICHT_ ?><br>
            <?= $form->checkinput('gdpr[export]', @$besondere_rechte['gdpr']['export'], 'id="gdpr2" onClick="if (this.checked) { jq1112(\'#gdpr1\').removeAttr(\'checked\') }"') ?>
            <?= _GDPR_ANONYM_EXPORT_ ?>
        </td>
    </tr>
    <?php if ($cfg_cti): ?>
        <tr class="<?= trClass($i++) ?>">
            <th class="th"><?= _OVA_VERPASSTE_ANRUFE_.' '._ICON_ ?></th>
            <td class="td"><?= ' '.$form->checkinput('menu_icon_phone', @$besondere_rechte['menu_icon_phone']) ?><span id="ctitel" class="icon icon-menu_oldphone"></span><?= ' '._AUFTRAG_INAKTIV_ ?></td>
        </tr>
    <?php endif; ?>
    <?php if (!empty($cfg_textbausteine_gruppe)): ?>
        <tr class="<?= trClass($i++) ?>">
            <th class="th"><?= _DEFAULT_WERT_.' '._TEXTBAUSTEIN_.' '._GRUPPE_ ?></th>
            <td class="td"><?= $form->selectinput('textbaustein_gruppe', $textbaustein_gruppen, @$besondere_rechte['textbaustein_gruppe'], _KEINE_AUSWAHL_) ?></td>
        </tr>
    <?php endif; ?>
</table>
<?php $i = 1; ?>
<table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
    <tr class="heading">
        <th class="small th" colspan="2"><?= _BKALENDERLINK_ ?></th>
    </tr>
    <tr class="<?= trClass($i++) ?> first-child">
        <th class="th"><?= _STANDARD_.' '._ANSICHT_ ?></th>
        <td class="td"><?= $form->selectinput('kal_std_ansicht', array('Tag' => _TAG_, 'Woche' => _TERMIN_WOCHE_, 'Monat' => _MONAT_), $e_r[33]) ?></td>
    </tr>
    <tr class="<?= trClass($i++) ?>">
        <th class="th"><?= _TERMINERINNERUNG_ ?></th>
        <td class="td"><?= $form->selectinput('erinnerung', $erinnerung_zeit, ($e_r[17] == '' ? '-99' : $e_r[17]), _STANDARDERINNERUNG_) ?></td>
    </tr>
    <tr class="<?= trClass($i++) ?>">
        <th class="th"><?= _WOCHENKALENDER_BEREICH_ ?></th>
        <td class="td">
            <?= $form->selectinput('kal_w_st', $uhrzeit_stunden_beginn, ($e_r[19] === '' ? 8 : $e_r[19])).' '._K_BIS_.' ' ?>
            <?= $form->selectinput('kal_w_e', $uhrzeit_stunden_ende, ($e_r[20] === '' ? 20 : $e_r[20])).' '._UHR_ ?>
        </td>
    </tr>
    <tr class="<?= trClass($i++) ?>">
        <th class="th"><?= _WOCHENKALENDER_SCHRITT_ ?></th>
        <td class="td"><?= $form->zahlinput('kal_w_s', ($e_r[21] == '' ? '60' : $e_r[21]), 2).' '._TERMINERINNERUNG_MINUTEN_ ?></td>
    </tr>
</table>

<?php if (!empty($cfg_benutzerrolle_pimanordnung)): ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" colspan="2"><?= _PIM_.' '._ANORDNUNG_ ?></th>
        </tr>
        <tr class="odd first-child">
            <th class="th"><?= _RLINKS_ ?></th>
            <th class="th"><?= _RRECHTS_ ?></th>
        </tr>
        <?php foreach(range(0, $anz_pim - 1) as $pi): ?>
            <tr class="<?= ($pi % 2 ? 'even' : 'odd').($pi === 0 ? ' first-child' : '') ?>">
                <td class="td"><?= $form->selectinput('pim_l['.$pi.']', $pim_blockinfo, $pim_vor_l[$pi], '-------------'._KEINE_AUSWAHL_) ?></td>
                <td class="td"><?= $form->selectinput('pim_r['.$pi.']', $pim_blockinfo, $pim_vor_r[$pi], '-------------'._KEINE_AUSWAHL_) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php endif; ?>
<?= $form->submit('submit_sett', _SUBMIT_STAMMDATEN_) ?>
<?= $form->ende() ?>