<?php
/**
 * MessengerPeople (WhatsApp/Telegram) service implementation via api.messengerpeople.dev
 * https://api.messengerpeople.dev/docs/
 * Version 2.xx. Not compatible with v1.xx
 *
 * @author Alexander Yurkovets <alexander.yurkovets@prof4.net>
 * 20.11.2022
 *
 *
 * PS: V 2.01
 * 14.12.2022: - the 'leadid' consists of two: "channelUUID~~~lead_id" (to-from  /in whatsaapp phone number/)
 * 21.12.2022: - the any channel can enable/disable bot;
 *             - every channel has its own location - so every channel has its own opening hours - important for bots;
 *
 * PS: V 2.02
 * 7.06.2023: - Changed page of presets settings.
 *            - Also changed the logic of working with them.
 * Priorities for working with presets:
 * I check if the incoming message has the id of one of the channel buttons?
 *     If yes -> I switch to that preset.
 *     If no ->
 *         I check if there is a default preset for that channel:
 *             If yes -> I switch to it.
 *             If no -> I use the defaults for all channels.
 *
 * PS: V 2.03 TODO better name is version 3
 * Version 2.03 Not compatible with older V.2.02 & V.1xx
 * 5.07.2023: Now each channel will have its own bot settings: bot during business hours,
 *            bot after business hours and text phrases for their bots;  auto answer phrases;
 * TODO (for now):
 *             So changing
 *                  - page settings for module
 *                              removed common bot & bot off-hours; bots phrases; auto answer phrases;
 *                              added for each channel - own bot & bot off-hours; bots phrases; auto answer phrases;
 *                  - config structure...
 *                  - bot algorithm...
 *                  - algorithm in the websocket part...
 *          + auto upgrade DB structure
 *
 * Version 2.04
 * 19.09.2023:
 *  Added Templates for mass mailing messages (settings page)
 *      Extended placeholders set:
 *          +datetime from stammdaten table & manual for mass mailing type,
 *          +date from stammdaten table & manual for mass mailing type,
 *          +name from stammdaten table & manual for mass mailing type,
 *          +time from preset values & manual for mass mailing type
 *  Added logic/functionality for sending mass mailing Whatsapp messages to the SMS tab.
 *  To CFG add section "mass_templates" for separating templates to two types: for 'mass mailing' & for 're-open 24'
 *
 * ----------- for phpstorm: ---------
 * @noinspection PhpUndefinedConstantInspection
 */


// TODO = maybe need rename MessengerPeopleV2 to MessengerPeopleV3 or MessengerPeople

class MessengerPeopleV2 extends MessengerPeople {

    const MODULE_VERSION = 204;
    private static $instance;
    protected static $activity_marker = 'MessengerPeople V203 activity marker';
    protected static $logger;
    protected $filter = array();
    protected $isTest = false; //for tests purpose; do not install manually
    //uuidChannels not compatible with V2 - so use other  $channels
    public $channels = array();
    public $channelsUUIDtoRecipient = array(); // for quick search
    public $presetsObj;
    public $api;
    public $moduleLanguage = 'de'; //can changed by channel language
    private static $language; //for remember main settings & not allow change by channel language
    public $botSurveyID = false;

    // $this->phrases - not compatible with V1; so todo need change in all places of code
    public $phrases = [];
    // in new version for any channel can enable/disable bot; bots cfg; own Location
    public $bots = [];
    public $botsOnChannels = [];
    //get only for main mandaten_id records where lead_type is null
    public $officesOpenHours = [];
    protected $templateObj;
    public static $template_answer_24h = 'specialist_can_answer';
    private static $template_massmailing = '';
    protected $templatesCFG;
    public $template_type = [];

    /**
     * MessengerPeople constructor.
     * @throws Exception
     */
    public function __construct() {
        global $cfg_db_utf8, $cfg_benutzer_sprache, $cfg_basedir, $cfg_ordner_kdokumente_pfad, $cfg_ordner_kdokumente;
        $params = self::getParams();
        //AzureApp::dd($params,'red','CFG DB');
        $this->presetsObj = new MessengerPeopleV2_Preset($params);
        $params['scope'] = $this->scope;
        $params['urlAuth'] = $this->urlAuth;
        $params['url'] = $this->url;
        if (!isset($cfg_ordner_kdokumente_pfad) or $cfg_ordner_kdokumente_pfad == '') {
            $cfg_ordner_kdokumente_pfad = $cfg_ordner_kdokumente;
        }
        if (isset($_SESSION['kdokpfad']) and $_SESSION['kdokpfad'] != '') {
            $cfg_ordner_kdokumente_pfad = $_SESSION['kdokpfad'];
        }
        if (!empty($cfg_ordner_kdokumente_pfad)) {
            $this->dir = $cfg_ordner_kdokumente_pfad;
        }
        if ($cfg_db_utf8 || $_SESSION['db_utf8']) {
            $tmp = 'lang_de_utf8.php';
        } else {
            $tmp = 'lang_de.php';
        }
        $data['language'] = $tmp;
        if (!empty($params['language'])) {
            $data['language'] = $params['language'];
        }
        if (!file_exists($cfg_basedir.'inc/'.$data['language'])) {
            $data['language'] = $tmp;
        }
        self::$language = $data['language'];
        $this->moduleLanguage = $this->langToTwoSign($data['language']);
        $this->translate = MessengerPeopleV2_Language::instance($data['language']);
        $this->template_type = [
            'mass' => $this->translate->_VORLAGE_MP_MASS_,
            '24h' => $this->translate->_VORLAGE_MP_24H_
        ];
        if (!isset($_SESSION[self::CONFIG_MODULE])) {
            // will store token, channels UUID...
            $_SESSION[self::CONFIG_MODULE] = array();
        }

        //class for operation with date/time
        $this->dateTime = new MessengerPeople_Date();
        $this->timezone = $this->dateTime->timezone;
        //get work schedule (only for main mandaten_id records where lead_type is null)
        $this->officesOpenHours = $this->dateTime->getOpenOfficeHours();
        //self::getLogger()->info(print_r($this->officesOpenHours, true));

        foreach (self::$messengers as $messenger => $short) {
            if ($messenger === 'telegram' && (empty($params['telegram-active']) || $params['telegram-active'] !== '1')) {
                //self::getLogger()->info(__METHOD__.'('.__LINE__.') Telegram channel is disabled - skip init');
                continue;
            }
            //reset old values in session
            if (!isset($_SESSION[self::CONFIG_MODULE][$messenger])) {
                $_SESSION[self::CONFIG_MODULE][$messenger] = array();
            }
            if (count_p4n($params[$messenger])) {
                foreach ($params[$messenger] as $r => $o) {
                    $valid = true;
                    foreach (array('recipient', 'uuid', 'language', 'location') as $key) {
                        if (($key === 'location' || $key === 'language') && $o[$key] === '-1') {
                            $o[$key] = '';
                        }
                        if (empty($o[$key])) {
                            $valid = false;
                            self::getLogger()->error(
                                __METHOD__.'('.__LINE__.') '.$messenger.
                                ' recipient '.$r.' empty value for: '.$key.' - skip init this channel'
                            );
                        }
                        if ($key === 'language' && !empty($o[$key])) {
                            if (!file_exists($cfg_basedir.'inc/'.$o[$key])) {
                                self::getLogger()->error(
                                    __METHOD__.'('.__LINE__.') '.$messenger.
                                    ' recipient '.$r.' Not found Language file: '.$o[$key].' for #'.$key
                                );
                                //switch to main
                                $o[$key] = $data['language'];
                            }
                        }
                    }

                    $this->phrases[$messenger][$o['uuid']] = [];
                    $this->botsOnChannels[$messenger][$o['uuid']] = [];
                    //for this channel bots is ON or OFF?
                    if ($valid && !empty($o['bot-on']) && $o['bot-on'] === '1') {
                        foreach (['bot-id', 'bot-id-offhours'] as $key) {
                            //bot is activated - so required IDs for survey
                            if (empty($o[$key])) {
                                $valid = false;
                                self::getLogger()->error(
                                    __METHOD__.'('.__LINE__.') '.$messenger.
                                    ' recipient '.$r.' empty value for: '.$key.' - skip init this channel'
                                );
                            } else {
                                $this->botsOnChannels[$messenger][$o['uuid']][$key] = $o[$key];
                            }
                        }
                        if ($valid) {
                            if (empty($this->officesOpenHours)) {
                                self::getLogger()->error(
                                    __METHOD__.'('.__LINE__.') '.$messenger.
                                    ' recipient '.$r.' empty officesOpenHours - skip init this channel'
                                );
                                $valid = false;
                            } elseif (empty($this->officesOpenHours[$o['location']]) || !is_array($this->officesOpenHours[$o['location']])) {
                                self::getLogger()->error(
                                    __METHOD__.'('.__LINE__.') '.$messenger.
                                    ' recipient '.$r.' empty officesOpenHours for location '.
                                    $o['location'].' - skip init this channel'
                                );
                                $valid = false;
                            } else {
                                $valid = false;
                                foreach ($this->officesOpenHours[$o['location']] as $day => $hours) {
                                    //0-> start; 1-> 'end'
                                    if (!empty($hours[0]) && !empty($hours[1]) && $hours[0] != $hours[1]) {
                                        $valid = true;
                                    }
                                }
                                if (!$valid) {
                                    $this->error[] = $messenger.' / '.$r.': locations Opening times inactive.';
                                    self::getLogger()->error(
                                        __METHOD__.'('.__LINE__.') '.$messenger.
                                        ' recipient '.$r.' for location '.$o['location'].
                                        ' Opening times inactive.- skip init this channel'
                                    );
                                }
                            }
                        }
                        //recipient is set && bots ON && survey ID is set: required phrases
                        if ($valid) {
                            if (!isset($o['bot-phrases']) || !is_array($o['bot-phrases'])) {
                                //init by empty, then fill by default values
                                $o['bot-phrases'] = [];
                            }
                            // load bot phrases for $this->phrases.messenger.channel
                            $phrases = self::getChannelPhrases($o, 1);
                            foreach ($phrases as $key => $value) {
                                $this->phrases[$messenger][$o['uuid']][$key] = [
                                    'origin' => $value['value'],
                                    'utf8' => self::is_utf8_p4n($value['value']) ? $value['value'] : utf8_encode($value['value'])
                                ];
                            }
                        }
                    } else {
                        $o['bot-on'] = '0';
                    }
                    if (!isset($o['autoanswer-phrases']) || count_p4n($o['autoanswer-phrases']) === 0) {
                        $o['autoanswer-phrases'] = [];
                    }
                    // load auto-answer phrases for $this->phrases.messenger.channel in any way
                    $phrases = self::getChannelPhrases($o, 2);
                    foreach ($phrases as $key => $value) {
                        $this->phrases[$messenger][$o['uuid']][$key] = [
                            'origin' => $value['value'],
                            'utf8' => self::is_utf8_p4n($value['value']) ? $value['value'] : utf8_encode($value['value'])
                        ];
                    }

                    //set only valid cfg for channels
                    if ($valid) {
                        // $this->channels[$messenger]['recipient num'] = array('bot-on'=>'1'|'0', 'recipient'=>'', 'uuid'=>'', 'language'=>'', 'location'=>'')
                        // full cfg for the channel - part of the cfg data is duplicated in other variables for faster access
                        $this->channels[$messenger][$r] = $o;
                        $this->channelsUUIDtoRecipient[$o['uuid']] = $r;
                    } else {
                        self::getLogger()->error(
                            __METHOD__.'('.__LINE__.') skip wrong channel configuration for '.
                            $messenger.' recipient '.$r
                        );
                    }
                }
            }
            if (count_p4n($this->channels[$messenger]) === 0) {
                self::getLogger()->error(
                    __METHOD__.'('.__LINE__.') Messenger '.$messenger.
                    ' is disabled (not present valid channel configuration)'
                );
            }
        }
        if (count_p4n($this->channels) === 0) {
            throw new Exception('Please set correct channels settings');
        }
        // todo format $this->channels[$messenger]['recipient num']=array('recipient'=>'','uuid'=>,'language'=>,'location'=>,'bot-id'=>,'bot-id-offhours'...)
        $params['channels'] = $this->channels;
        $this->api = new MessengerPeopleV2_Api($params);
        $this->id_to_messenger = array_keys(self::$messengers); // (0=>'telegram',1=>'whatsapp');
        $this->messenger_to_ids = array_flip($this->id_to_messenger); //'telegram'=>0, 'whatsapp'=>1
        // for all templates
        $this->templatesCFG = self::getTemplatesCfg('templates', $params);
        if (empty($params['waba-ID'])) {
            throw new Exception('Please set the WhatsApp Business Account ID');
        }
        $this->wabaID = $params['waba-ID'];

        return $this;
    }

    /** get Phrases for init & page admin setup
     * part===1 -> only bot-phrases
     * part===2 -> only auto answer-phrases
     * part===null -> all phrases
     * if $channelOptions is empty - will fill phrases by default
     *
     * @param array $channelOptions (from cfg)
     * @param int|null $part [null, 1, 2]
     *
     * @return array
     */
    public static function getChannelPhrases($channelOptions = [], $part = null) {
        $phrases = [];
        foreach (MessengerPeopleV2::$defaultPhrases as $key => $value) {
            // overwrite default phrase to customer phrase
            //bot-phrases
            if ((substr($key, 0, strlen('noBot_')) !== 'noBot_') && ((int) $part === 1 || empty($part))) {
                if (!empty($channelOptions['bot-phrases'][$key])) {
                    $phrases[$key] = array('title' => $value['title'], 'value' => $channelOptions['bot-phrases'][$key]);
                } else {
                    // use default
                    $phrases[$key] = array('title' => $value['title'], 'value' => $value['value']);
                }
                //auto answer phrases
            } elseif ((substr($key, 0, strlen('noBot_')) === 'noBot_') && ((int) $part === 2 || empty($part))) {
                if (!empty($channelOptions['autoanswer-phrases'][$key])) {
                    $phrases[$key] = array(
                        'title' => $value['title'],
                        'value' => $channelOptions['autoanswer-phrases'][$key]
                    );
                } else {
                    // use default
                    $phrases[$key] = array('title' => $value['title'], 'value' => $value['value']);
                }
            }
        }

        return $phrases;
    }

    /** delete from cfg all channel settings;
     *
     * @param string $messenger
     * @param numeric $recipient
     *
     * @return bool
     */
    public static function deleteChannelSettings($messenger, $recipient) {
        $params = MessengerPeopleV2::getParams();
        if (isset($params[$messenger][$recipient])) {
            unset($params[$messenger][$recipient]);
            if (isset($params['preset']['for-channel'][$recipient])) {
                unset($params['preset']['for-channel'][$recipient]);
            }
            if ($messenger === 'telegram' && isset($params['telegram-active'])) {
                $params['telegram-active'] = 0;
            }
            self::saveParams($params);

            return true;
        }

        return false;
    }

    public function getLanguage() {
        return self::$language;
    }

    /**  version To String for print
     *
     * @param int $v
     *
     * @return string
     */
    //todo more that current max version 999 -> 9.99
    public static function versionToString($v = 0) {
        return substr_replace((!empty($v) ? $v : self::MODULE_VERSION), '.', 1, 0);
    }

    public static function saveParams(array $params) {
        // AzureApp::dd($params, 'green', 'incomming $params for save');
        global $db, $sql_tab, $sql_tabs;
        $upgrade_format_leadID = false;
        $lastParams = self::getParams();
        // leave old preset - if save on main window form
        // and save new or update old if save on preset settings window
        if (!empty($lastParams['preset']) && !isset($params['preset'])) {
            $params['preset'] = $lastParams['preset'];
        }

        foreach (self::$messengers as $messenger => $short) {
            if (!empty($lastParams[$messenger]) && is_array($lastParams[$messenger])) {
                foreach ($lastParams[$messenger] as $recipient => $oldOptions) {
                    //channel: leave old values for bot-phrases, autoanswer-phrases
                    if (!empty($oldOptions['bot-phrases']) && !isset($params[$messenger][$recipient]['bot-phrases'])) {
                        $params['bot-phrases'] = $lastParams['bot-phrases'];
                    }
                    if (!empty($oldOptions['autoanswer-phrases']) && !isset($params[$messenger][$recipient]['autoanswer-phrases'])) {
                        $params['autoanswer-phrases'] = $lastParams['autoanswer-phrases'];
                    }
                }
            }
        }
        // leave old settings (for replace placeholders) for templates (https://app.messengerpeople.dev/settings/templates/)
        if (!empty($lastParams['templates']) && !isset($params['templates'])) {
            $params['templates'] = $lastParams['templates'];
        }
        // leave old settings (used_templates - info what template uses for what target)
        if (!empty($lastParams['used_templates']) && !isset($params['used_templates'])) {
            $params['used_templates'] = $lastParams['used_templates'];
        }
        // v.2.04 +mass_templates
        // leave old settings (mass_templates - info what template uses for mass mailing)
        if (!empty($lastParams['mass_templates']) && !isset($params['mass_templates'])) {
            $params['mass_templates'] = $lastParams['mass_templates'];
        }
        if (isset($params['upgrade_version_MP'])) {
            $upgrade_format_leadID = true;
            unset($params['upgrade_version_MP']);
        }
        $params = json_encode(json_encode_utf8($params));
        if (empty($lastParams)) {
            $res = $db->insert(
                $sql_tab['einstellungen'],
                array(
                    $sql_tabs['einstellungen']['wert'] => $db->str($params),
                    $sql_tabs['einstellungen']['modul'] => $db->str(lcfirst(self::CONFIG_MODULE))
                )
            );
        } else {
            $res = $db->update(
                $sql_tab['einstellungen'],
                array(
                    $sql_tabs['einstellungen']['wert'] => $db->str($params)
                ),
                $sql_tabs['einstellungen']['modul'].'='.$db->str(lcfirst(self::CONFIG_MODULE))
            );
        }
        if (false !== $res) {
            if ($upgrade_format_leadID) {
                MessengerPeopleV2_Lead::changeLeadIDsToCompositeFormat();
            }

            return true;
        }

        return false;
    }

    /** get Data Template via API from MessengerPeople provider for admin page
     *
     * @param string|null $name
     *
     * @return false|array
     */
    public function getDataTemplate($name = '') {
        try {
            return MessengerPeopleV2_Template::instance($this->api)->getDataTemplate($name);
        } catch (Exception $e) {
            //todo
            var_dump($e->getMessage());
            self::getLogger()->error($e->getMessage());
        }

        return false;
    }

    /** generate template payload by method in MessengerPeopleV2_Template class:
     *      data template from API +
     *      get placeholders positions for header & body texts +
     *      DB cfg for this name of template and positions +
     *      replace placeholders by data from stammdaten table
     *
     * @param $leadid
     * @param $template_name
     * @param $lang
     *
     * @return array|false
     */
    public function getTemplatePayload($leadid, $template_name, $lang) {

        if (empty($this->templateObj)) {
            $this->templateObj = new MessengerPeopleV2_Template($this->api);
        }
        if (empty($this->templatesCFG)) {
            // db cfg for all templates
            $this->templatesCFG = self::getTemplatesCfg('templates');
        }
        // placeholders cfg
        $cfg = false;
        if (!empty($this->templatesCFG[$template_name])) {
            // cfg is one for all translations in this template
            $cfg = $this->templatesCFG[$template_name];
        }

        return $this->templateObj->getPayload($leadid, $template_name, $lang, $cfg);
    }

    /** Save cfg section templates to DB
     *
     * @param array $templates
     *
     * @return bool
     */
    public static function updateTemplates(array $templates) {
        if (!empty($templates)) {
            $params = self::getParams();
            $params['templates'] = $templates;

            return self::saveParams($params);
        }

        return false;
    }

    /** Select box options 'header' & 'body' sections for form at the 'template' page in admin panel
     * @return array
     */
    public function getTemplateSelectboxOptions() {
        return MessengerPeopleV2_Template::selectboxOptions();
    }

    /** get some section(part) for Templates from config
     *
     * @param null $cfg full config parameters
     * @param null|string $section what section get from config
     *
     * @return array
     */
    public static function getTemplatesCfg($section = 'templates', $cfg = null, $name = null) {
        $tmp = array();
        if (empty($cfg)) {
            $cfg = self::getParams();
        }
        if (!empty($cfg[$section]) && is_array($cfg[$section])) {
            // common for all translations
            if (!empty($name)) {
                if (!empty($cfg[$section][$name])){
                    return $cfg[$section][$name];
                }
                return [];
            }

            return $cfg[$section];
        }

        return $tmp;
    }

    /**
     * @return MessengerPeopleV2
     */
    public static function instance() {
        if (self::$instance == null) {
            self::$instance = new MessengerPeopleV2();
        }

        return self::$instance;
    }

    /**
     * @return Logger_File
     */
    public static function getLogger() {
        if (empty(self::$logger)) {
            self::$logger = new Logger_File('log/'.self::CONFIG_MODULE.'_v'.self::MODULE_VERSION.'.txt');
        }

        return self::$logger;
    }

    /** switching output to another log for easy debugging
     *
     * @param Logger_File $logger
     *
     * @return Logger_File
     */
    public function switchLogger($logger) {
        self::$logger = $logger;

        // self::$logger->info('switch logger');
        return self::$logger;
    }

    /**
     * Add params to Filter
     *
     * @param array $data
     *
     * @throws Exception
     */
    public function addToFilter(array $data) {
        foreach (array('param', 'sign', 'value') as $key) {
            if (empty($data[$key])) {
                throw new Exception('can not add to filter '.(!empty($data['param']) ? $data['param'].' ' : '').$key);
            }
        }
        $this->filter[] = $data;
    }

    /**
     * Get Filter Array
     * @return array
     */
    public function getFilter() {
        //prepare ...
        return $this->filter;
    }

    /**
     * filter array combine to string
     * @return string
     */
    public function getFilterAsString() {
        $string_filter = '';
        foreach ($this->getFilter() as $items) {
            $string_filter .= urlencode((!empty($string_filter) ? ',' : '').$items['param'].$items['sign'].$items['value']);
        }

        return $string_filter;
    }


    /**
     * Create new lead via MessengerPeopleV2_Lead class
     *
     * @param $data
     * @param $extraData
     *
     * @return false|mixed|null
     */
    public function newLead($data, $extraData) {
        $lead = new MessengerPeopleV2_Lead();

        return $lead->saveLead($data, $extraData, $this->translate);
    }

    /**
     * get array lead data, remember in session
     *
     * @param $kampagne_lead_id
     *
     * @return array
     */
    public function getLeadData($kampagne_lead_id) {
        //clear old
        foreach (self::$messengers as $messenger => $short) {
            unset($_SESSION[self::CONFIG_MODULE][$messenger]['lead'][$kampagne_lead_id]);
        }
        //set new
        $lead = new MessengerPeopleV2_Lead();
        $l = $lead->getLeadData($kampagne_lead_id);
        //V2 new fields:  l[channel_recipient], l[channelUUID]
        // uses in refresh func
        if (!empty($l) && !empty($l['leadid']) && !empty($l['channel'])) {
            $_SESSION[self::CONFIG_MODULE][$lead['channel']]['lead'][$kampagne_lead_id] = $l;
        }

        return $l;
    }

    /** get all messages for all registered channels of this $messenger
     *
     * @param string $messenger
     * @param string $sort
     *
     * @return array|false
     */
    public function mpGetListMessages($messenger, $sort = '') {
        $filter = '';
        try {
            if (empty($messenger) || !in_array($messenger, array_keys(self::$messengers))) {
                $this->error[] = 'Messenger name is empty or invalid';
                self::getLogger()->error(__METHOD__.': '.implode('; ', $this->error));

                return false;
            }
            if (empty($sort)) {
                $sort = $this->sort;
            }
            if (!empty($this->filter)) {
                $filter = $this->getFilterAsString();
            }
            $response = $this->api->mpGetListMessages($sort, $filter);
            // provider api (this version) can not use filter by uuid-channel with logic OR: some_field=value && ( sender===xx || recipient===xx)
            // can only logic AND: some_field=value && sender===xx && recipient===xx
            return $this->filteredByChannel($messenger, $response);
        } catch (Exception $e) {
            $this->error[] = $e->getMessage();
            self::getLogger()->error(__METHOD__.': '.implode('; ', $this->error));

            return false;
        }
    }

    /** check config options and if valid return CFG options
     *
     * @param array $mp_post (presented $_POST if called from page setup)
     *
     * @return array|false|int|mixed|string
     * @throws Exception
     */
    public static function checkParams($mp_post = array()) {
        // get old cfg;
        $old = self::getParams();
        //incomming _POST? -> use settings page
        if (count_p4n($mp_post) > 0) {
            if (isset($mp_post['upgrade_version_MP'])) {
                if ($mp_post['upgrade_version_MP'] === '1') {
                    //need convert leadid to new format
                    $mp_post['upgrade_version_MP'] = true;
                } else {
                    //not need this option in cfg
                    unset($mp_post['upgrade_version_MP']);
                }
            }
            // convert POST structure to CFG structure
            foreach (self::$messengers as $messenger => $short) {
                if (count_p4n($mp_post[$messenger.'-recipient'])) {
                    // change format
                    foreach ($mp_post[$messenger.'-recipient'] as $i => $recipient) {
                        //only numbers
                        $recipient = preg_replace("/[^0-9]/", '', $recipient);
                        if (!empty($recipient)) {
                            $mp_post[$messenger][$recipient] = [
                                'uuid' => !empty($mp_post[$messenger.'-UUID'][$i]) ? $mp_post[$messenger.'-UUID'][$i] : '',
                                'recipient' => $recipient,
                                'language' => (!empty($mp_post[$messenger.'-language'][$i]) && $mp_post[$messenger.'-language'][$i] !== '-1') ? $mp_post[$messenger.'-language'][$i] : '',
                                'location' => (!empty($mp_post[$messenger.'-location'][$i]) && $mp_post[$messenger.'-location'][$i] !== '-1') ? $mp_post[$messenger.'-location'][$i] : '',
                                'bot-on' => (!empty($mp_post[$messenger.'-bot-on'][$i]) && $mp_post[$messenger.'-bot-on'][$i] === '1') ? '1' : '0',
                            ];
                            if (MessengerPeopleV2::MODULE_VERSION >= 203) {
                                $mp_post[$messenger][$recipient]['bot-id'] = (!empty($mp_post[$messenger.'-bot-id'][$i]) && is_numeric($mp_post[$messenger.'-bot-id'][$i])) ? $mp_post[$messenger.'-bot-id'][$i] : null;
                                $mp_post[$messenger][$recipient]['bot-id-offhours'] = (!empty($mp_post[$messenger.'-bot-id-offhours'][$i]) && is_numeric($mp_post[$messenger.'-bot-id-offhours'][$i])) ? $mp_post[$messenger.'-bot-id-offhours'][$i] : null;
                                if ($mp_post[$messenger][$recipient]['bot-on'] === '1') {
                                    if (empty($mp_post[$messenger][$recipient]['bot-id'])) {
                                        throw new Exception(_FEHLER_POPUP_.' - '.$messenger.' '.($i + 1).' Bot ID during working hours');
                                    }
                                    if (empty($mp_post[$messenger][$recipient]['bot-id-offhours'])) {
                                        throw new Exception(_FEHLER_POPUP_.' - '.$messenger.' '.($i + 1).' Bot ID during non-working hours');
                                    }
                                }
                            }
                            //leave old bot-phrases
                            if (!empty($old[$messenger][$recipient]['bot-phrases']) && empty($mp_post[$messenger][$recipient]['bot-phrases'])) {
                                $mp_post[$messenger][$recipient]['bot-phrases'] = $old[$messenger][$recipient]['bot-phrases'];
                            }
                            //leave old autoanswer-phrases
                            if (!empty($old[$messenger][$recipient]['autoanswer-phrases']) && empty($mp_post[$messenger][$recipient]['autoanswer-phrases'])) {
                                $mp_post[$messenger][$recipient]['autoanswer-phrases'] = $old[$messenger][$recipient]['autoanswer-phrases'];
                            }
                        }
                    }
                    //clear - not need it in cfg
                    foreach (
                        [
                            'recipient',
                            'UUID',
                            'language',
                            'location',
                            'bot-on',
                            'bot-id',
                            'bot-id-offhours'
                        ] as $k
                    ) {
                        if (isset($mp_post[$messenger.'-'.$k])) {
                            unset($mp_post[$messenger.'-'.$k]);
                        }
                    }
                }
            }
            // add old preset settings
            $mp_post['preset'] = $old['preset'];
            // then will check this cfg
            $cfg = $mp_post;
        } else {
            //or need check data from CFG
            $cfg = $old;
        }
        //AzureApp::dd($mp_post, 'brown', 'incomming in checkParams');
        if (empty($cfg['Client-ID']) || empty($cfg['Client-Secret'])) {
            throw new Exception(_KEINE_ZUGANGSDATEN_.' - Client-ID, Client-Secret');
        } elseif (empty($cfg['waba-ID'])) {
            throw new Exception(_KEINE_ZUGANGSDATEN_.' - WhatsApp Business Account ID');
        } elseif (empty($cfg['language'])) {
            throw new Exception(_KEINE_ZUGANGSDATEN_.' - '._BSPRACHE_);
        } elseif (count_p4n($cfg['whatsapp']) === 0) {
            throw new Exception(_KEINE_ZUGANGSDATEN_.' - WhatsApp '._EINSTELLUNGEN_);
        } elseif (count_p4n($cfg['preset']['default']) === 0 && count_p4n($cfg['preset']['for-channel']) === 0) {
            throw new Exception(_FEHLER_POPUP_.' - Preset options / Button is empty');
        }

        if (!empty($cfg['telegram-active']) && $cfg['telegram-active'] === '1') {
            if (count_p4n($cfg['telegram']) === 0) {
                throw new Exception(_KEINE_ZUGANGSDATEN_.' - Telegram '._EINSTELLUNGEN_);
            }
        } else {
            //is disabled
            unset($cfg['telegram']);
            // self::getLogger()->info(__METHOD__.'('.__LINE__.') Telegram channel is disabled');
        }
        $cfg['bot-active'] = '0';
        foreach (self::$messengers as $messenger => $short) {
            // checked it above, but maybe unset telegram
            if (count_p4n($cfg[$messenger])) {
                $i = 1;
                foreach ($cfg[$messenger] as $r => $o) {
                    foreach (array('recipient', 'uuid', 'language', 'location') as $k) {
                        if (empty($o[$k])) {
                            throw new Exception(_FEHLER_POPUP_.' - '.$messenger.' '.$k.' ['.$i.']');
                        }
                    }
                    //if telegram is disabled, telegram options array is deleted at little upper of the this code
                    if (!empty($o['bot-on']) && $o['bot-on'] === '1') {
                        $cfg['bot-active'] = '1';
                    }
                    $i++;
                }
            }
        }
        if (MessengerPeopleV2::MODULE_VERSION >= 203) {
            foreach (['bot-active', 'bot-id', 'bot-id-offhours'] as $k) {
                if (isset($cfg[$k])) {
                    unset($cfg[$k]);
                }
            }
        } else {
            if ($cfg['bot-active'] === '1' && empty($cfg['bot-id']) && empty($cfg['bot-id-offhours'])) {
                //if bot active - and not set off-hours & working-hours?
                throw new Exception(_FEHLER_POPUP_.' - Bot ID during working or non-working hours');
            }
        }
        $cfg['need-upgrade-version'] = '';
        if (!empty($cfg['version']) && intval($cfg['version']) < self::MODULE_VERSION) {
            $cfg['need-upgrade-version'] = MessengerPeopleV2::versionToString($cfg['version']).' -> '.MessengerPeopleV2::versionToString();
            //todo - upgrade operations
            self::getLogger()->info(__METHOD__.'('.__LINE__.') need Upgrade DB MP CFG version '.$cfg['need-upgrade-version']);
            $cfg['version'] = self::MODULE_VERSION;
        }

//        AzureApp::dd($cfg, 'red', 'after modify' );
        return $cfg;
    }

    /** get all my channel uuids
     *
     * @param string $messenger
     *
     * @return array
     */
    public function getAllChannelUUIDs($messenger) {
        $uuids = array();
        if (count_p4n($this->channels[$messenger])) {
            // or array_column($this->channels[$messenger], 'uuid');
            foreach ($this->channels[$messenger] as $k => $v) {
                $uuids[] = $v['uuid'];
            }
        }

        return $uuids;
    }

    /**
     * @param string $messenger
     * @param string $sender
     *
     * @return false|string
     */
    public function getValidChannelUUIDFromChat($messenger, $sender) {
        //get current channels UUIDs
        $uuids = $this->getAllChannelUUIDs($messenger);
        //from which channel UUID the last message came from this sender
        $uuid = MessengerPeopleV2_MessengerData::getChannelUUIDFromOldMessages($sender);
        // in current settings exist this channelUUID?
        if (!empty($uuid) && in_array($uuid, $uuids)) {
            return $uuid;
        }

        return false;
    }

    /**
     * @param array $lead
     * @param boolean $from
     * @param boolean $refresh
     *
     * @return array|string
     */
    public function loadContentFromDB(array $lead, $from = false, $refresh = false) {
        // warning - remote api can not create filter with logic OR for combine query!
        // and UUID is not integer
        // so faster is call both : 'in' and 'out' and parse data locally
        $i = 0;
        $out = array();
        if (empty($lead['channel'])) {
            $out[] = '<div class="container" id="container_'.$i.'">No messenger channel selected</div>';

            return $refresh ? implode("\n", $out) : $out;
        }
        if (!isset($this->messenger_to_ids[$lead['channel']])) {
            $out[] = '<div class="container" id="container_'.$i.'">Unknown messenger channel selected'.$lead['channel'].'</div>';

            return $refresh ? implode("\n", $out) : $out;
        }
        if (empty($lead['channel_recipient'])) {
            $out[] = '<div class="container" id="container_'.$i.'">No recipient selected</div>';

            return $refresh ? implode("\n", $out) : $out;
        }

        if (false != ($data = MessengerPeopleV2_MessengerData::getMessages($this->messenger_to_ids[$lead['channel']], $lead, $from))) {
            $part = array();
            $max_date = null;
            if (!empty($lead['message_last_created_at'])) {
                // remind: message_last_created_at calculated for all - incoming and outgoing
                $max_date = $lead['message_last_created_at']; //local timezone
            }
            foreach ($data as $k => $post) {
                $tmp = $post['html'];
                //echo $tmp;
                if (!empty($post['created'])) {

                    //whatsapp calculate datetime for last incoming message
                    if ($lead['channel'] === 'whatsapp' && $post['outgoing'] === '0') {
                        if (empty($this->whatsappTimeOut[$lead['leadid']])) {
                            $this->whatsappTimeOut[$lead['leadid']] = $post['created'];
                        } elseif ($this->dateTime->firstDateIsLess($this->whatsappTimeOut[$lead['leadid']], $post['created'], 'Y-m-d H:i:s')) {
                            $this->whatsappTimeOut[$lead['leadid']] = $post['created'];
                        }
                    }

                    if (empty($max_date)) {
                        $max_date = $post['created'];
                    } elseif ($this->dateTime->firstDateIsLess($max_date, $post['created'], 'Y-m-d H:i:s')) {
                        $max_date = $post['created'];
                    }
                    //prepare chat for save
                    if ((!empty($lead['chat_last_saved_at']) && $this->dateTime->firstDateIsLess($lead['chat_last_saved_at'], $post['created'], 'Y-m-d H:i:s')) || empty($lead['chat_last_saved_at'])) {
                        // this part of chat will saved - so need remember dealer / _HAENDLER_ name
                        $name = $this->translate->_HAENDLER_.' ('.$_SESSION['mitarbeiter_name'].')';
                        $tmp = preg_replace('#_HAENDLER_ \(\)#is', $name, $tmp);
                        $tmp = preg_replace('#Dealer \(\)#is', $name, $tmp); // old records - before using _HAENDLER_
                        $tmp = preg_replace('#Prospect\s*\(#is', $this->translate->_INTERESSENT_.' (', $tmp); // old records - before using _INTERESSENT_
                        $tmp = preg_replace('#_INTERESSENT_\s*\(#is', $this->translate->_INTERESSENT_.' (', $tmp);
                        $tmp = preg_replace('#'.$this->translate->_SYSTEM_.'\s*'.$this->translate->_NOTIZ_.'#is', '<br><br>'.$this->translate->_SYSTEM_.' '.$this->translate->_NOTIZ_, $tmp);
                        $part[] = $tmp;
                    }
                }
                $out[] = $tmp;
            }
            if (!empty($max_date)) {
                self::messageMarkMaxLastCreate($lead['kampagne_lead_id'], $lead['channel'], $max_date);
            }
            // refresh in session
            // part of chat for save/show in form
            $_SESSION[self::CONFIG_MODULE][$lead['channel']]['part_chat_for_save'][$lead['kampagne_lead_id']] = $part;

            return $refresh ? implode("\n", $out) : $out;

        }
        // if the client opened the chat, and did not send or receive anything,
        // but pressed the "Save" button - there are NO messages to save during this period!
        $out[] = '<div class="container" id="container_'.$i.'">
            <div class="row error">
                <div class="message" style="padding:20px;width:100%; color:red">'.(!empty($this->error) ?
                'Error: '.implode('<br>', $this->error) :
                'There are no messages during this period.').'
                </div>
            </div>
        </div>';
        $this->error = array();

        return $refresh ? implode("\n", $out) : $out;
    }

    /** passes messages further from own channel.
     * The rest are saved partly to obtain the maximum creation time - for optimize next iteration.
     *
     * @param $messenger
     * @param array $response
     *
     * @return array|false
     * @throws Exception
     */
    protected function filteredByChannel($messenger, $response = array()) {
        $out = array();
        $ids = $this->getAllChannelUUIDs($messenger);
        self::getLogger()->info(__METHOD__.'('.__LINE__.') will filtered by $ids: '.print_r($ids, true));

        if (is_array($response) && count_p4n($ids)) {
            foreach ($response as $values) {
                self::getLogger()->info(__METHOD__.'('.__LINE__.') compare with $values[recipient]: '.print_r($values['recipient'], true));

                if (in_array($values['recipient'], $ids) || in_array($values['sender'], $ids)) {
                    // if (in_array($values['sender'], $ids)) {
                    //     self::getLogger()->info(__METHOD__.'('.__LINE__.') OWN message '.$values['uuid'].' sender: '.$values['sender']);
                    // }
                    // if (in_array($values['recipient'], $ids)) {
                    //     self::getLogger()->info(__METHOD__.'('.__LINE__.') OWN message '.$values['uuid'].' recipient: '.$values['recipient']);
                    // }
                    $out[] = $values;
                } else {
                    // self::getLogger()->info(__METHOD__.'('.__LINE__.') NOT OWN message '.$values['uuid'].' sender: '.$values['sender'].' recipient: '.$values['recipient']);
                    if ($this->isTest) {
                        // Need to skip writing to db when we run tests!
                        self::getLogger()->info(__METHOD__.'('.__LINE__.') uses TEST mode. Skip write to DB');
                    } elseif (!empty($values['created'])) {
                        // self::getLogger()->info(__METHOD__.'('.__LINE__.') mark as NOT OWN in DB');
                        // need mark as known, for skip in next cycle
                        $values['created'] = $this->dateTime->UTCtoLocalTmz($values['created'], 'Y-m-d\TH:i:s\+00:00', 'Y-m-d H:i:s');
                        $messenger_data_obj = new MessengerPeopleV2_MessengerData();
                        if (false === $messenger_data_obj->isKnownMessage($this->messenger_to_ids[$messenger], $values['uuid'])) {
                            $messenger_data_obj['messenger'] = $this->messenger_to_ids[$messenger];
                            $messenger_data_obj['outgoing'] = $values['outgoing'];
                            $messenger_data_obj['message_uuid'] = $values['uuid'];
                            $messenger_data_obj['created'] = $values['created'];
                            $messenger_data_obj['status'] = $values['statuscode'];
                            $messenger_data_obj['status_internal'] = 'hide';
                            //[sender_uuid] => set empty
                            //[recipient_uuid] =>  set empty
                            $messenger_data_obj->save();
                        }
                    }
                }
            }
            unset($response);

            return !empty($out) ? $out : false;
        }

        // self::getLogger()->info(__METHOD__.' -> empty output');
        return false;
    }

    /**
     * Update Lead via MessengerPeopleV2_Lead class
     *
     * @param integer $kampagne_lead_id
     * @param string $created
     * @param array $extraData
     *
     * @return array|bool|int|mixed|string|string[]
     */
    public function updateLead($kampagne_lead_id, $created, $extraData) {
        self::getLogger()->info('try updateLead() with extra data '.print_r($extraData, true));
        try {
            $lead = new MessengerPeopleV2_Lead($kampagne_lead_id);
            if (!$lead->load()) {
                throw new Exception('Lead not found '.$kampagne_lead_id);
            }
            $text = $log_text = '';
            if (!empty($extraData['survey-data'])) {
                foreach ($extraData['survey-data'] as $k => $v) {
                    if ($k === 'message_body') {
                        //Overwrite: is answer & is not first message
                        $text .= $v;
                    } elseif ($k === 'log') {
                        $log_text .= $v."\n";
                    } else {
                        $lead[$k] = $v;
                        if ($k === 'campaignname' && !empty($v)) {
                            $campaigndata = array(
                                'ID' => null,
                                'Code' => $v,
                                'Description' => $lead['campaignid'],
                                'Active' => null,
                                'StartDate' => null,
                                'EndDate' => null,
                                'InclInSummaryEmails' => 'true',
                                'IncludeInReports' => 'true',
                                'IncludeInNotifEmail' => 'true',
                                'Redistribution' => 'true'
                            );
                            $lead['campaigndata'] = implode('#####', $campaigndata);
                        }
                    }
                }
            }
            if ($log_text) {
                if (!strstr($lead['log_text'], 'BOT '.$this->translate->_UMFRAGE_)) {
                    $lead['log_text'] .= date('d.m.Y H:i:s').': BOT '.$this->translate->_UMFRAGE_."\n";
                }
                $lead['log_text'] .= $log_text;
            }
            if ($text) {
                $additionaldata = $lead['additionaldata'] == '' ? '#####' : $lead['additionaldata']."\n";
                if (!strstr($additionaldata, 'BOT '.$this->translate->_UMFRAGE_)) {
                    $additionaldata .= 'BOT '.$this->translate->_UMFRAGE_.":\n";
                }
                $lead['additionaldata'] = $additionaldata.$text;
            }
            // case when need add text message
            if ($extraData["add_text_message"]) {
                $lead['additionaldata'] .= "\nLead added a message at: : ".$created."\nMessage: ".$extraData["add_text_message"];
            }
            $lead['letzte_aenderung'] = $created; // date of last added message need for registration new messages / after assignment can changed

            return $lead->save();
        } catch (Exception $e) {
            self::getLogger()->error($e->getMessage());
        }

        return false;
    }

    public function setTemplateForMassMailing($template_name) {
        //todo add validation
        self::$template_massmailing = $template_name;
    }

    public function getTemplateForMassMailing() {
        if (empty(self::$template_massmailing)) {
            return false;
        }

        return self::$template_massmailing;
    }

    public function getMessage($muuid) {
        return $this->api->getMessage($muuid);
    }

    /** send (put to queue in MP service provider) whatsapp message with a template for mass mailing
     * save in table stat if success
     *
     * @param $data
     * @param $for_stat
     *
     * @return array|false
     * @throws Exception
     */
    public function sendWhatsAppMassMailingMessage($data, $for_stat) {

        if (false === ($template_name = $this->getTemplateForMassMailing())) {
            throw new Exception('no active mass mailing template set');
        }

        if (empty($this->channelsUUIDtoRecipient[$data['channelUUID']]) ||
            empty($this->channels['whatsapp'][$this->channelsUUIDtoRecipient[$data['channelUUID']]]) ||
            !is_array($this->channels['whatsapp'][$this->channelsUUIDtoRecipient[$data['channelUUID']]])
        ) {
            //Please select active channel
            throw new Exception('Bitte w�hlen Sie den aktiven Kanal');
        }

        if (empty($data['recipient'])) {
            throw new Exception($this->translate->_LEER_.' '.$this->translate->_KNTO_);
        }

        if (empty($data['stammdaten_id'])) {
            throw new Exception($this->translate->_LEER_.' stammdaten id');
        }

        if (empty($data['template_content'])) {
            throw new Exception($this->translate->_LEER_.' '.$this->translate->_VORLAGE_.' '.$this->translate->_INHALT_);
        }

        if (empty($this->templateObj)) {
            $this->templateObj = new MessengerPeopleV2_Template($this->api);
        }

        $payload = $this->templateObj->payloadForMass($template_name, $data['stammdaten_id'], $data['template_content'], $data['cfg']);
        $prepared = array(
            'sender' => $data['channelUUID'],
            'recipient' => $data['recipient'],
            'payload' => $payload
        );
        //AzureApp::dd($prepared,'orange', '$payload from payloadForMass');
        //will get by websocket & save to db
        self::getLogger()->info('API mpSendMessages() call with param:');
        self::getLogger()->info(print_r($prepared, true));
        if (false !== ($response = $this->api->mpSendMessages($prepared))) {
            //Response:{"id":"a4987d03-0344-492c-b30f-3be7f8da1944","messenger":"WB","message_amount":1,"split":false,"status":"queued"}
            //add to stat
            $for_stat['stammdaten_id'] = $data['stammdaten_id'];
            $for_stat['kampagne_lead_id'] = $data['kampagne_lead_id'];
            $for_stat['recipient'] = $data['recipient'];
            $for_stat['message_uuid'] = $response['id'];
            $for_stat['payload'] = $payload;
            $for_stat['status'] = 'queued'; //queued -> then check: sent (to be paid) or error
            $for_stat['sender'] = $this->channelsUUIDtoRecipient[$data['channelUUID']]; //for human reading
            $this->insertStat($for_stat);

            return $response;
        }
        //no queue -> no payment -> no need to write to the database
        throw new Exception($this->api->error, $this->api->errorCode);

    }

    /** sendMediaFile it is other than sendFile
     *
     * @param $binary
     *
     * @return array|false
     */
    public function sendMediaFile($binary) {
        try {
            if (false === ($response = $this->api->sendMediaFile($binary))) {
                if (!empty($this->api->error)) {
                    $this->error[] = $this->api->error;
                    self::getLogger()->error(__METHOD__.': '.implode('; ', $this->error));
                }

                return false;
            }

            return $response;
        } catch (Exception $e) {
            $this->error[] = $e->getMessage();
            self::getLogger()->error(__METHOD__.': '.implode('; ', $this->error));

            return false;
        }
    }

    /** send a message through the selected channel by UUID
     *
     * @param string $message
     * @param string $channelUUID
     * @param numeric $recipient
     * @param string $type
     * @param null|string $filename
     *
     * @return array
     */
    public function mpSendMessages($message, $channelUUID, $recipient, $type = 'text', $filename = null) {
        // self::getLogger()->info(__METHOD__.' call with param:');
        // self::getLogger()->info(print_r(array($message, $channelUUID, $recipient, $type, $filename), true));

        $at = time();
        if ($type === 'text') {
            $data = array(
                'sender' => $channelUUID,
                'recipient' => $recipient,
                'payload' => array('text' => self::encode_utf8_if_need($message))
            );
        } elseif ($type === 'image' || $type === 'document' || $type === 'audio' || $type === 'video') {
            $data = array(
                'sender' => $channelUUID,
                'recipient' => $recipient,
                'payload' => array(
                    'type' => $type,
                    'text' => !empty($filename) ? _ANHANG_.' '._DATEINAME_.': ['.$filename.']' : $type.' '._ANHANG_,
                    'attachment' => $message,
                )
            );
        } elseif ($type === self::$template_answer_24h) {
            // check is set template?
            // for now only one template
            if (false === ($payload = $this->getTemplatePayload($channelUUID.'~~~'.$recipient, self::$template_answer_24h, $this->moduleLanguage))) {
                return array('success' => false, 'error' => true, 'message' => 'no active template set');
            }
            $data = array(
                'sender' => $channelUUID,
                'recipient' => $recipient,
                'payload' => $payload
            );
            // isset only after getTemplatePayload()
            $message = $this->getSentHumanReadableTemplate(self::$template_answer_24h, $this->moduleLanguage);
            self::getLogger()->info('Paid message ('.self::$template_answer_24h.') prepared for send');
            self::getLogger()->info($message);
        }

        try {
            self::getLogger()->info('API mpSendMessages() call with param:');
            self::getLogger()->info(print_r($data, true));
            if (false !== ($response = $this->api->mpSendMessages($data))) {
                self::getLogger()->info(print_r($response, true));

                return array(
                    'success' => true,
                    'datetime' => $this->dateTime->UTCtoLocalTmz(date('Y-m-d H:i:s', $at), 'Y-m-d H:i:s', $this->dtFormat),
                    'direction' => 'out',
                    'status' => $response['status'],
                    'message' => $message
                );
            }
            throw new Exception($this->api->error, $this->api->errorCode);
        } catch (Exception $e) {
            $m = $e->getMessage();
            self::getLogger()->error(__METHOD__.': '.$m);

            return array('success' => false, 'error' => true, 'message' => $m);
        }
    }

    protected function getSentHumanReadableTemplate($template_name, $lang) {
        if (!empty($this->templateObj->humanReadableTemplate[$template_name][$lang])) {
            $text = array();
            foreach (array('header', 'body', 'footer') as $position) {
                self::getLogger()->info('position '.$position.': '.$this->templateObj->humanReadableTemplate[$template_name][$lang][$position]);
                if (!empty($this->templateObj->humanReadableTemplate[$template_name][$lang][$position])) {
                    // to utf8 -> will uses in json_encode
                    $text[] = self::encode_utf8_if_need($this->templateObj->humanReadableTemplate[$template_name][$lang][$position]);
                }
            }
            //buttons, I think, for now, not need show
            // reset
            unset($this->templateObj->humanReadableTemplate[$template_name][$lang]);

            return implode("\n", $text);
        }

        return self::encode_utf8_if_need($this->translate->_PM_PHASE5_);
    }

    /**
     * @param numeric $recipient
     * @param string $messenger
     * @param boolean $outOfOffice
     * @param string $channelUUID
     *
     * @return bool
     */
    public function confirmContactYouSoon($recipient, $messenger, $outOfOffice = false, $channelUUID = '') {
        // todo: throw when empty channel uuid?
        if (empty($channelUUID)) {
            return false;
        }
        $out = $this->mpSendMessages(
            ($outOfOffice === false ?
                $this->phrases[$messenger][$channelUUID]['noBot_ConfirmReceivingText']['origin'] :
                $this->phrases[$messenger][$channelUUID]['noBot_OutSideHoursConfirmReceivingText']['origin']
            ),
            $channelUUID,
            $recipient
        );

        return $out['success'];
    }

    /**
     * @param integer $newBenutzerId
     * @param integer $oldBenutzerId
     *
     * @return void
     */
    public static function changeBenutzerIdWhenMove($newBenutzerId, $oldBenutzerId) {
        // AzureApp::dd(array($newBenutzerId, $oldBenutzerId));
        self::getLogger()->info(__METHOD__.': with params: '.print_r(array($newBenutzerId, $oldBenutzerId), true));
        parent::changeBenutzerIdWhenMove($newBenutzerId, $oldBenutzerId);
    }

    /**
     * @param integer $kampagne_lead_id
     * @param integer $newBenutzerId
     * @param empty|integer $oldBenutzerId
     *
     * @return bool
     */
    public static function changeBenutzerIdInPopup($kampagne_lead_id, $newBenutzerId, $oldBenutzerId = '') {
        if (empty($kampagne_lead_id) || !is_numeric($kampagne_lead_id)) {
            self::getLogger()->error(__METHOD__.' ('.__LINE__.'): empty or incorrect $kampagne_lead_id: '.print_r($kampagne_lead_id, true));

            return false;
        }
        if (empty($newBenutzerId) || !is_numeric($newBenutzerId)) {
            self::getLogger()->error(__METHOD__.' ('.__LINE__.'): empty $newBenutzerId: '.print_r($newBenutzerId, true));

            return false;
        }

        return parent::changeBenutzerIdInPopup($kampagne_lead_id, $newBenutzerId, $oldBenutzerId);
    }

    /** send confirmation message by 'during working hours' or 'outside office hours' (if configured)
     * PS from 14.12.2022 the 'leadid' consists of two: "channelUUID~~~lead_id"
     *
     * @param string $v2_format_leadid
     * @param string $messenger
     * @param array $hours
     * @param numeric|null $lagerort_id
     *
     * @return bool
     */
    //PS  for now the id has not been written to the kampagne_lead table; therefore it is necessary to get the channel uuid from $data
    public function confirmationMessage($v2_format_leadid, $messenger, array $hours, $lagerort_id = null) {
        // self::getLogger()->info('CALL '.__METHOD__.': for '.$messenger);
        try {
            if (strpos($v2_format_leadid, '~~~') === false) {
                self::getLogger()->error(__METHOD__.'('.__LINE__.'): Wrong lead ID format '.$v2_format_leadid);

                return false;
            }
            list($channelUUID, $recipient) = explode('~~~', $v2_format_leadid);
            if (empty($channelUUID)) {
                self::getLogger()->error('Can not send confirmation message -  empty uuidChannel for '.$v2_format_leadid);

                return false;
            }
            if (empty($recipient)) {
                self::getLogger()->error('Can not send confirmation message -  empty recipient for '.$v2_format_leadid);

                return false;
            }

            $dt = new \DateTime('now', $this->timezone);
            $weekDay = $dt->format('N');
            // not configured or inactive
            if (empty($lagerort_id) || empty($hours[$lagerort_id][$weekDay][0]) || empty($hours[$lagerort_id][$weekDay][1])) {
                if (empty($lagerort_id)) {
                    self::getLogger()->info('$lagerort_id is empty');
                } else {
                    self::getLogger()->info('NOT CONFIGURED OpenOfficeHours for day '.$weekDay);
                }
                //send standard confirmation message
                if ($this->confirmContactYouSoon($recipient, $messenger, false, $channelUUID)) {
                    self::getLogger()->info('sent confirmation message to '.$v2_format_leadid);

                    return true;
                }

                return false;
            }
            $start = \DateTime::createFromFormat('H:i:s', $hours[$lagerort_id][$weekDay][0]);
            $end = \DateTime::createFromFormat('H:i:s', $hours[$lagerort_id][$weekDay][1]);
            if ($dt->format('H:i:s') >= $start->format('H:i:s') && $dt->format('H:i:s') < $end->format('H:i:s')) {
                self::getLogger()->info('Office open');
                // send confirmation message
                if ($this->confirmContactYouSoon($recipient, $messenger, false, $channelUUID)) {
                    //self::getLogger()->info('sent confirmation message to '.$v2_format_leadid);
                    return true;
                }
                self::getLogger()->error('can not send confirmation message to '.$v2_format_leadid);
            } else {
                self::getLogger()->info('Office close');
                //outside working time
                if ($this->confirmContactYouSoon($recipient, $messenger, true, $channelUUID)) {
                    //self::getLogger()->info('send out of office confirmation message to '.$v2_format_leadid);
                    return true;
                }
                self::getLogger()->error('can not send out of office confirmation message to '.$v2_format_leadid);
            }
        } catch (Exception $e) {
            self::getLogger()->error($e->getMessage());
        }

        return false;
    }

    /** V1
     * if Messenger People is activated in this user's personal settings -
     * show Telegram or WhatsApp icons in the top menu only if this lead are assigned
     * to this user
     * (of course, the incoming lead comes from the corresponding channel)
     *
     * @return string
     */
    public function checkIncomingChats() {
        $refreshIco = false;
        if (!empty($_GET['refreshIco'])) {
            $refreshIco = true;
        }
        $out = '';
        $svg = array();
        $svg['whatsapp'] = '<svg viewBox="0 0 26 28" width="20" height="22">
                    <path d=" M19.11 17.205c-.372 0-1.088 1.39-1.518 1.39a.63.63 0 0 1-.315-.1c-.802-.402-1.504-.817-2.'.
            '163-1.447-.545-.516-1.146-1.29-1.46-1.963a.426.426 0 0 1-.073-.215c0-.33.99-.945.99-1.49 0-.143-.73-2.09'.
            '-.832-2.335-.143-.372-.214-.487-.6-.487-.187 0-.36-.043-.53-.043-.302 0-.53.115-.746.315-.688.645-1.032 '.
            '1.318-1.06 2.264v.114c-.015.99.472 1.977 1.017 2.78 1.23 1.82 2.506 3.41 4.554 4.34.616.287 2.035.888 2.'.
            '722.888.817 0 2.15-.515 2.478-1.318.13-.33.244-.73.244-1.088 0-.058 0-.144-.03-.215-.1-.172-2.434-1.39-2.'.
            '678-1.39zm-2.908 7.593c-1.747 0-3.48-.53-4.942-1.49L7.793 24.41l1.132-3.337a8.955 8.955 0 0 1-1.72-5.272'.
            'c0-4.955 4.04-8.995 8.997-8.995S25.2 10.845 25.2 15.8c0 4.958-4.04 8.998-8.998 8.998zm0-19.798c-5.96 0-'.
            '10.8 4.842-10.8 10.8 0 1.964.53 3.898 1.546 5.574L5 27.176l5.974-1.92a10.807 10.807 0 0 0 16.03-9.455c0-'.
            '5.958-4.842-10.8-10.802-10.8z" fill-rule="evenodd" fill="#4dc247" >
                    </path>'.
            '</svg>';
        $svg['telegram'] = '<svg viewBox="0 0 26 28" width="20" height="20" style="fill-rule:evenodd;clip-rule:evenodd;'.
            ' stroke-linejoin:round;">
                    <path fill="#04a1d8" d="M12,0c-6.626,0 -12,5.372 -12,12c0,6.627 5.374,12 12,12c6.627,0 12,-5.373 12,'.
            '-12c0,-6.628 -5.373,-12 -12,-12Zm3.224,17.871c0.188,0.133 0.43,0.166 0.646,0.085c0.215,-0.082 '.
            '0.374,-0.267 0.422,-0.491c0.507,-2.382 1.737,-8.412 2.198,-10.578c0.035,-0.164 -0.023,-0.334 '.
            '-0.151,-0.443c-0.129,-0.109 -0.307,-0.14 -0.465,-0.082c-2.446,0.906 -9.979,3.732 -13.058,'.
            '4.871c-0.195,0.073 -0.322,0.26 -0.316,0.467c0.007,0.206 0.146,0.385 0.346,0.445c1.381,0.413 '.
            '3.193,0.988 3.193,0.988c0,0 0.847,2.558 1.288,3.858c0.056,0.164 0.184,0.292 0.352,0.336c0.169,'.
            '0.044 0.348,-0.002 0.474,-0.121c0.709,-0.669 1.805,-1.704 1.805,-1.704c0,0 2.084,1.527 3.266,'.
            '2.369Zm-6.423,-5.062l0.98,3.231l0.218,-2.046c0,0 3.783,-3.413 5.941,-5.358c0.063,'.
            '.-0.057 0.071,-0.153 0.019,-0.22c-0.052,-0.067 -0.148,-0.083 -0.219,'.
            '-0.037c-2.5,1.596 -6.939,4.43 -6.939,4.43Z"/>
                        </svg>';

        $css = '<style>#'.self::CONFIG_MODULE.':hover {cursor: pointer;} .whatsapp-counter {color:red;margin-left:-4px;vertical-align:top}</style>';
        $js = '';
        if (!$refreshIco) {
            $out .= '<span id="'.self::CONFIG_MODULE.'">';
        }
        $uid = $_SESSION['user_id'];
        // if Messenger People is activated in this user's personal settings
        if (!empty($uid) && self::isActive($uid)) {
            $js = javas('
                    var WA_layer = jq1112("#'.self::CONFIG_MODULE.'");
                    function loadMessengerPeopleIcons() {
                        WA_layer.load("api_whatsapp_v2.php?action=load-ico&refreshIco=true");
                    }
                    setInterval(function () {
                        loadMessengerPeopleIcons();
                    }, 10000);
                ');
            foreach (self::$messengers as $messenger => $short) {
                // and leads are assigned to this user from this corresponding channel
                $leads = self::getMessengerPeopleLeads($messenger, $uid);
                if (count_p4n($leads) > 0) {
                    $out .= '<span onclick="window.top.frames[\'main\'].location.href=\'stammdaten_main.php?nav=lead&id='.$leads[0]['stammdaten_id'].'&lead='.$leads[0]['kampagne_lead_id'].'\';">'.$svg[$messenger].'<span class="whatsapp-counter">'.count_p4n($leads).'</span></span>';
                }
            }
        }
        if (!$refreshIco) {
            $out .= '</span>'.$js.$css;
        }

        return $out;
    }

    /**
     * get new assigned leads from source MessengerPeople and selected channel
     * if benutzer_id is set - get leads only for this user
     *
     * @param $messenger
     * @param null $benutzer_id
     *
     * @return array
     */
    public static function getMessengerPeopleLeads($messenger, $benutzer_id = null) {
        global $db, $sql_tab, $sql_tabs;
        $leads = array();
        $res = $db->select(
            $sql_tab['kampagne_lead'],
            $sql_tabs['kampagne_lead']['leadid'].', '. // external ID
            $sql_tabs['kampagne_lead']['kampagne_lead_id'].', '. // crm_lead_id
            $sql_tabs['kampagne_lead']['stammdaten_id'].', '. // crm_lead_id
            $sql_tabs['kampagne_lead']['benutzer_id'].', '. //not assigned if 0 or ''
            $sql_tabs['kampagne_lead']['erfassungsdatum'], // date of first (init) added message to lead
            // 'letzte_aenderung' date of last added message to lead
            $sql_tabs['kampagne_lead']['status'].'<='.$db->dbzahl('2'). //new assigned
            (!empty($benutzer_id) ?
                ' AND '.$sql_tabs['kampagne_lead']['benutzer_id'].'='.$db->dbzahl($benutzer_id) //is assigned to this benutzer_id
                :
                ' AND '.$sql_tabs['kampagne_lead']['benutzer_id'].'>'.$db->dbzahl(0) //is assigned to someone benutzer_id
            ).
            ' AND '.$sql_tabs['kampagne_lead']['source'].'='.$db->dbstr(MessengerPeopleV2_Lead::SOURCE).
            ' AND '.$sql_tabs['kampagne_lead']['channel'].'='.$db->dbstr($messenger)
        );

        while ($row = $db->zeile($res)) {
            $leads[] = array(
                'leadid' => $row['leadid'],
                'kampagne_lead_id' => $row['kampagne_lead_id'],
                'benutzer_id' => $row['benutzer_id'],
                'stammdaten_id' => $row['stammdaten_id'],
                'erfassungsdatum' => $row['erfassungsdatum']
            );
        }

        return $leads;
    }

    /**
     * get JS for stammdaten_lead.php page
     *
     * @param array $lead
     *
     * @return string
     */
    // Warning - for this function array $lead incoming from stammdaten_lead.php and have other keys!!!
    public static function getJSforStammdatenLeadPage(array $lead) {
        global $messengerpeople_close;
        $out = array();
        if (!empty($lead['recipient_id'])) {
            $tmp = <<<EOT
var MessengerPeopleSaved = true;
function onMPButtonClick(url,messenger) {
    url = url.replace('api_whatsapp.php', 'api_whatsapp_v2.php');
    jq1112(".stammdaten_lead_korr ul li").each(function () {
        if (jq1112(this).hasClass("aktive")) {
            kinhalt_stammdaten_lead_close();
        }
    });
    jq1112(".stammdaten_lead_korr ul li").removeClass("aktive");
    jq1112("#message_inline").hide();
    MessengerPeopleSaved = false;
    P4nBoxHelper.init({
        href: url,
        target: "body",
        id: "whatsAppWindow",
        width: "900px",
        height: "600px",
        single: true,
        type: "iframe",
        beforeClose: function () {
            kinhalt_stammdaten_lead('stammdaten_main.php?nav=Korrespondenz&kurzk=103&ajax=1&navto=lead&pzid=0&{params}',messenger);
            if ( MessengerPeopleSaved === false ) {
                alert('Remember: Need save discussion');
                jq1112("#message_inline").addClass("message_inline2");
                jq1112("#message_inline").addClass("stammdaten_lead_whatsapp");
                jq1112("#message_inline").show();
            }
            jq1112.get("api_whatsapp_v2.php?action=close&{params}", function() {console.log("call close");});
        }
    });
}
EOT;
            if (defined('_ERINNERUNG_')) {
                $tmp = str_replace('Remember', _ERINNERUNG_, $tmp);
            }
            if (defined('_SAVE_BEFORE_ADD_MESSAGE_')) {
                $tmp = str_replace('Need save discussion', _SAVE_BEFORE_ADD_MESSAGE_, $tmp);
            }
            $out[] = str_replace('{params}', 'recipient='.$lead['recipient_id'].'&kampagne_lead_id='.$lead['id'].'&leadid='.$lead['id'].'&messenger='.$lead['kanal'], $tmp);

            $messengerpeople_close = Template_IconButton::init('', '', 'class=""', 'close')->setRequest('GET', 'whatsapp_modal_inhalt', 'stammdaten_main.php', 'nav=Korrespondenz&kurzk=103&ajax=1&navto=lead&pzid=0&recipient='.$lead['recipient_id'].'&kampagne_lead_id='.$lead['id'].'&leadid='.$lead['id'].'&messenger='.$lead['kanal']);

            unset($tmp);
            if (self::isActive()) {
                foreach (self::$messengers as $messenger => $short) {
                    if (!empty($lead['kanal']) && $lead['kanal'] === $messenger && $lead['source'] === MessengerPeopleV2_Lead::SOURCE) {
                        $out[] = 'jq1112("#button_'.$messenger.'").show();';
                    }
                }
            }
        }

        //self::getLogger()->info(print_r($out, true));
        return javas(implode("\n", $out));
    }

    /**
     * call included function for show icons in top menu
     * @return string
     */
    public static function whatsappMenuIco() {
        //hide errors
        try {
            return self::instance()->checkIncomingChats();
        } catch (Exception $e) {
            return '';
        }
    }

    /** get location(lagerort_id) for this channel UUID
     *
     * @param string $messenger
     * @param string $currentChannelUUID
     *
     * @return false|int|string
     */
    public function getChannelLagerortId($messenger, $currentChannelUUID) {
        if (!empty($this->channelsUUIDtoRecipient[$currentChannelUUID])) {
            $recipient = $this->channelsUUIDtoRecipient[$currentChannelUUID];
            if (!empty($this->channels[$messenger][$recipient]['location'])) {
                self::getLogger()->info(__METHOD__.'('.__LINE__.') '.$messenger.' ch: '.$recipient.' location: '.$this->channels[$messenger][$recipient]['location']);

                return $this->channels[$messenger][$recipient]['location'];
            } else {
                self::getLogger()->error(__METHOD__.'('.__LINE__.') '.$messenger.' ch: '.$recipient.' not found location in $this->channels');
            }
        } else {
            self::getLogger()->error(__METHOD__.'('.__LINE__.') '.$currentChannelUUID.' in not presented in $currentChannelUUID '.print_r($currentChannelUUID, true));
        }

        return false;
    }

    /** get language for this channel UUID
     *
     * @param string $messenger
     * @param string $currentChannelUUID
     *
     * @return false|string
     */
    public function getChannelLanguage($messenger, $currentChannelUUID) {
        if (!empty($this->channelsUUIDtoRecipient[$currentChannelUUID])) {
            $recipient = $this->channelsUUIDtoRecipient[$currentChannelUUID];
            if (!empty($this->channels[$messenger][$recipient]['language'])) {
                return $this->channels[$messenger][$recipient]['language'];
            }
        }

        return false;
    }

    /** get a two-character language code from the language file selected in the setting for this module
     *
     * @param $language
     *
     * @return mixed|string
     */
    public function langToTwoSign($language) {
        return parent::langToTwoSign($language);
    }

    /** get leads data by 'stammdaten id'
     *
     * @param array $stammdaten
     * @param null|string $messenger
     *
     * @return array
     */
    public static function getMPLeadIds(array $stammdaten, $messenger = 'whatsapp') {
        global $db, $sql_tab, $sql_tabs;
        $leads = array();
        $res = $db->select(
            $sql_tab['kampagne_lead'].
            ' INNER JOIN '.$sql_tab['stammdaten'].
            ' ON '.$sql_tabs['kampagne_lead']['stammdaten_id'].'='.$sql_tabs['stammdaten']['id'],
            [
                $sql_tabs['stammdaten']['vorname'],
                $sql_tabs['stammdaten']['name'],
                $sql_tabs['stammdaten']['firma1'],
                $sql_tabs['stammdaten']['anzeigename'],
                $sql_tabs['kampagne_lead']['leadid'],
                $sql_tabs['kampagne_lead']['kampagne_lead_id'],
                $sql_tabs['kampagne_lead']['stammdaten_id']
            ],
            $db->dbzahlin($stammdaten, $sql_tabs['kampagne_lead']['stammdaten_id']).
            ' AND '.$sql_tabs['kampagne_lead']['source'].'='.$db->dbstr(MessengerPeopleV2_Lead::SOURCE).
            ' AND '.$sql_tabs['kampagne_lead']['channel'].'='.$db->dbstr($messenger).
            ' AND '.$sql_tabs['kampagne_lead']['leadid'].'!='.$db->dbstr('').
            ' AND '.$sql_tabs['kampagne_lead']['leadid'].' NOT LIKE '.$db->dbstr('%was-re-opened%').
            ' AND '.$sql_tabs['kampagne_lead']['leadid'].' NOT LIKE '.$db->dbstr('%was-deleted%'),
            $sql_tabs['kampagne_lead']['stammdaten_id'].' ASC, '.$sql_tabs['kampagne_lead']['kampagne_lead_id'].' DESC'
        );

        while ($row = $db->zeile($res)) {
            $recipient = $channelUUID = '';
            //v2 format leads
            if (strpos($row['leadid'], '~~~')) {
                list($channelUUID, $recipient) = explode('~~~', $row['leadid']);
                //echo "v2 ".$recipient.'<br>';
            } elseif (preg_match('/^\d+$/i', $row['leadid'], $m) && !empty($m[0])) {
                //echo "v1 ".print_r($m, true).'<br>';
                $recipient = $m[0];
            }

            $leads[$row['kampagne_lead_id']] = [
                'leadid' => $row['leadid'],
                'stammdaten_id' => $row['stammdaten_id'],
                'channelUUID' => $channelUUID,
                'recipient' => $recipient,
                'vorname' => $row['vorname'],
                'name' => $row['name'],
                'firma1' => $row['firma1'],
                'anzeigename' => $row['anzeigename'],
            ];
        }

        return $leads;
    }

    /** get Customers For Whatsapp Mass Mailing
     *
     * @param array $data [stammdaten_id=>mobile_phone]
     *
     * @return array
     */
    public static function getCustomersForWhatsappMassMailing(array $data) {
        global $db, $sql_tab, $sql_tabs, $cfg_countrycode;
        $users = [];
        if (count_p4n(array_keys($data))) {
            $stammdaten = array_keys($data);
            $countrycode = '49';
            if (!empty($cfg_countrycode)) {
                //not need sign +
                $tmp = preg_replace('/[^\d]/', '', $cfg_countrycode);
                if (!empty($tmp)) {
                    $countrycode = $tmp;
                }
            }
            $res = $db->select(
                $sql_tab['stammdaten'].
                ' LEFT JOIN '.$sql_tab['kampagne_lead'].
                ' ON '.$sql_tabs['kampagne_lead']['stammdaten_id'].'='.$sql_tabs['stammdaten']['id'].
                ' AND '.$sql_tabs['kampagne_lead']['source'].'='.$db->dbstr(MessengerPeopleV2_Lead::SOURCE).
                ' AND '.$sql_tabs['kampagne_lead']['channel'].'='.$db->dbstr('whatsapp').
                ' AND '.$sql_tabs['kampagne_lead']['leadid'].'!='.$db->dbstr('').
                ' AND '.$sql_tabs['kampagne_lead']['leadid'].' NOT LIKE '.$db->dbstr('%was-re-opened%').
                ' AND '.$sql_tabs['kampagne_lead']['leadid'].' NOT LIKE '.$db->dbstr('%was-deleted%'),
                [
                    //One user can have many leads / use one newest lead
                    'DISTINCT '.$sql_tabs['stammdaten']['id'],
                    $sql_tabs['stammdaten']['vorname'],
                    $sql_tabs['stammdaten']['name'],
                    $sql_tabs['stammdaten']['firma1'],
                    $sql_tabs['stammdaten']['anzeigename'],
                    $sql_tabs['stammdaten']['Mobilfon_1'],
                    $sql_tabs['stammdaten']['Mobilfon_2'],
                    $sql_tabs['stammdaten']['Mobilfon_3'],
                    $sql_tabs['kampagne_lead']['leadid'],
                    $sql_tabs['kampagne_lead']['kampagne_lead_id']
                ],
                $db->dbzahlin($stammdaten, $sql_tabs['stammdaten']['id']),
                $sql_tabs['stammdaten']['id'].' ASC, '.$sql_tabs['kampagne_lead']['kampagne_lead_id'].' DESC'
            );
            while ($row = $db->zeile($res)) {
                $recipient = $channelUUID = '';
                //v2 format leads
                if (strpos($row['leadid'], '~~~')) {
                    list($channelUUID, $recipient) = explode('~~~', $row['leadid']);
                    //echo "v2 ".$recipient.'<br>';
                } elseif (preg_match('/^\d+$/i', $row['leadid'], $m) && !empty($m[0])) {
                    //echo "v1 ".print_r($m, true).'<br>';
                    $recipient = $m[0];
                }
                if (empty($data[$row['stammdaten_id']])) {
                    $nr = '';
                    foreach ([1, 2, 3] as $i) {
                        if (empty($nr) && !empty($row['Mobilfon_'.$i])) {
                            $nr = phone2($row['Mobilfon_'.$i]);
                            //echo 'in stm '.$row['Mobilfon_'.$i].'->'.$nr.'<br>';
                        }
                    }
                } else {
                    $nr = $data[$row['stammdaten_id']];
                    //echo 'in sms '.$nr.'<br>';
                }
                //todo need create own function for analyze mobil phone numbers by Germany rule
                //try fixs duplicate county code from phone2() at DB server
                $pattern = '/^\+?('.$countrycode.$countrycode.')/';
                $nr = preg_replace($pattern, $countrycode, $nr);
                $nr = preg_replace('/[^\d]/', '', $nr);
                $users[$row['stammdaten_id']] = [
                    'leadid' => $row['leadid'],
                    'channelUUID' => $channelUUID,
                    'recipient' => $recipient, //whatsapp
                    'phone' => $nr, //mobile as recipient
                    'vorname' => $row['vorname'],
                    'name' => $row['name'],
                    'firma1' => $row['firma1'],
                    'anzeigename' => $row['anzeigename'],
                    'kampagne_lead_id' => $row['kampagne_lead_id'],
                ];
            }
        }

        return $users;
    }

    /** only fot test_services
     * get Recipients By LeadIds
     *
     * @param array $ids
     * @param string $messenger
     *
     * @return array
     */
    public static function getRecipientsByLeadIds(array $ids, $messenger = 'whatsapp') {
        global $db, $sql_tab, $sql_tabs;
        $tmp = $leads = [];
        $where = '';
        foreach ($ids as $id) {
            $tmp[] = $sql_tabs['kampagne_lead']['leadid'].'='.$db->str($id);
        }
        if (count($tmp)) {
            $where = 'AND ('.implode(' OR ', $tmp).') ';
        }
        $res = $db->select(
            $sql_tab['kampagne_lead'].
            ' INNER JOIN '.$sql_tab['stammdaten'].
            ' ON '.$sql_tabs['kampagne_lead']['stammdaten_id'].'='.$sql_tabs['stammdaten']['id'],
            [
                $sql_tabs['stammdaten']['vorname'],
                $sql_tabs['stammdaten']['name'],
                $sql_tabs['stammdaten']['firma1'],
                $sql_tabs['stammdaten']['anzeigename'],
                $sql_tabs['kampagne_lead']['leadid'],
                $sql_tabs['kampagne_lead']['kampagne_lead_id'],
                $sql_tabs['kampagne_lead']['stammdaten_id']
            ],
            $sql_tabs['kampagne_lead']['source'].'='.$db->dbstr(MessengerPeopleV2_Lead::SOURCE).
            ' AND '.$sql_tabs['kampagne_lead']['channel'].'='.$db->dbstr($messenger).
            $where,
            $sql_tabs['kampagne_lead']['stammdaten_id'].' ASC, '.$sql_tabs['kampagne_lead']['kampagne_lead_id'].' DESC'
        );

        while ($row = $db->zeile($res)) {
            $recipient = $channelUUID = '';
            //v2 format leads
            if (strpos($row['leadid'], '~~~')) {
                list($channelUUID, $recipient) = explode('~~~', $row['leadid']);
                //echo "v2 ".$recipient.'<br>';
            } elseif (preg_match('/^\d+$/i', $row['leadid'], $m) && !empty($m[0])) {
                //echo "v1 ".print_r($m, true).'<br>';
                $recipient = $m[0];
            }

            $leads[$row['kampagne_lead_id']] = [
                'leadid' => $row['leadid'],
                'stammdaten_id' => $row['stammdaten_id'],
                'channelUUID' => $channelUUID,
                'recipient' => $recipient,
                'vorname' => $row['vorname'],
                'name' => $row['name'],
                'firma1' => $row['firma1'],
                'anzeigename' => $row['anzeigename'],
            ];
        }

        return $leads;
    }

    /**
     * @param string $phone
     * todo : Germany ? Subscriber numbers cannot begin with 0 and 11. For increase quality traffic in FB?
     *
     *
     * @return bool
     */
    public static function isValidMobileForRecipient($phone) {
        if (preg_match('/^\d+$/i', $phone, $m) && strlen($m[0]) > 7) {
            return true;
        }

        return false;
    }

    //only fot test_services
    public function testMassPaidSendingOfMessages($out) {
        //AzureApp::dd($out,'coral', $out);
        return $out;
    }

    /** insert the first part of the statistics
     *
     * @param array $data
     *
     * @return void
     */
    public function insertStat(array $data) {
        global $db, $sql_tab, $sql_tabs;
        if ($data['message_uuid']) {
            $payload = json_encode(json_encode_utf8($data['payload']));
            if (empty($lastParams)) {
                $res = $db->insert(
                    $sql_tab['messenger_stat'],
                    array(
                        $sql_tabs['messenger_stat']['messenger'] => $db->dbzahl($data['messenger']),
                        $sql_tabs['messenger_stat']['filter_id'] => $db->dbzahl($data['filter_id']),
                        $sql_tabs['messenger_stat']['stammdaten_id'] => $db->dbzahl($data['stammdaten_id']),
                        $sql_tabs['messenger_stat']['kampagne_lead_id'] => $db->dbzahl($data['kampagne_lead_id']),
                        $sql_tabs['messenger_stat']['batch_uuid'] => $db->str($data['batch_uuid']),
                        $sql_tabs['messenger_stat']['message_uuid'] => $db->str($data['message_uuid']),
                        $sql_tabs['messenger_stat']['sender'] => $db->str($data['sender']),
                        $sql_tabs['messenger_stat']['recipient'] => $db->str($data['recipient']),
                        $sql_tabs['messenger_stat']['status'] => $db->str($data['status']),
                        $sql_tabs['messenger_stat']['payload'] => $db->str($payload),
                        $sql_tabs['messenger_stat']['error'] => $db->str($data['error']),
                        $sql_tabs['messenger_stat']['created_at'] => $db->dbdate($data['created_at']),
                        $sql_tabs['messenger_stat']['updated_at'] => $db->dbdate($data['created_at']),
                    )
                );
            }
        } else {
            self::getLogger()->error(__METHOD__.' '.__LINE__.' error: can not write data to db. Empty message_uuid');
        }
    }

    /** save the second part of the statistics
     *
     * @param array $data
     *
     * @return void
     */
    public function updateStat(array $data) {
        global $db, $sql_tab, $sql_tabs;
        if ($data['message_uuid']) {
            if (empty($lastParams)) {
                $res = $db->update(
                    $sql_tab['messenger_stat'],
                    array(
                        $sql_tabs['messenger_stat']['status'] => $db->str($data['status']),
                        $sql_tabs['messenger_stat']['error'] => $db->str($data['error']),
                        $sql_tabs['messenger_stat']['updated_at'] => $db->dbdate(date('Y-m-d H:i:s', time())),
                    ),
                    $sql_tabs['messenger_stat']['stammdaten_id'].'='.$db->dbzahl($data['stammdaten_id']).
                    ' AND '.$sql_tabs['messenger_stat']['message_uuid'].'='.$db->str($data['message_uuid'])
                );
            }
        } else {
            self::getLogger()->error(__METHOD__.' '.__LINE__.' error: can not update data in db. Empty message_uuid');
        }
    }

    /** get recipient IDs, where according to statistics there are: "(1013) Recipient is not a valid WhatsApp user"
     *
     * @param null|array $recipients by all records OR only in array
     * @param null|boolean $short switch output
     * @param null|integer $messenger [0=>telegram, 1=>whatsapp]
     *
     * @return array{recipients:array, stammdatenIds:array}
     */
    public static function getNotValidRecipientsFromStat($recipients = [], $short = true, $messenger = 1) {
        global $db, $sql_tab, $sql_tabs;
        $notValid = ['recipients' => [], 'stammdatenIds' => []];
        $where = '';
        if (count($recipients)) {
            $where = ' AND '.$db->dbzahlin($recipients, $sql_tabs['messenger_stat']['recipient']);
        }

        if ($short) {
            $select = [
                $sql_tabs['messenger_stat']['recipient'],
                $sql_tabs['messenger_stat']['stammdaten_id'],
            ];
        } else {
            $select = [
                $sql_tabs['messenger_stat']['stammdaten_id'],
                $sql_tabs['messenger_stat']['messenger_stat_id'],
                $sql_tabs['messenger_stat']['recipient'],
                $sql_tabs['messenger_stat']['stammdaten_id'],
                $sql_tabs['messenger_stat']['message_uuid'],
                $sql_tabs['messenger_stat']['updated_at'],
                $sql_tabs['messenger_stat']['error']
            ];
        }
        // user id/phone not valid
        // 472 - Failed to send a message because this user's phone number is part of an experiment.
        // 480 - User potentially changed
        // 1002 - Invalid recipient type
        // 1007 - Recipient blocked to receive message
        // 1021 - Bad User
        // 1009 - Provided WhatsApp ID is not valid. Please provide a valid WhatsApp ID or a phone number with a country code
        // 1013 - Recipient is not a valid WhatsApp user
        $res = $db->select(
            $sql_tab['messenger_stat'],
            $select,
            $sql_tabs['messenger_stat']['messenger'].'='.$db->dbzahl($messenger).
            ' AND ( '.$sql_tabs['messenger_stat']['error'].' LIKE '.$db->str('%(1002)%').
            ' OR '.$sql_tabs['messenger_stat']['error'].' LIKE '.$db->str('%(1007)%').
            ' OR '.$sql_tabs['messenger_stat']['error'].' LIKE '.$db->str('%(1013)%').
            ' OR '.$sql_tabs['messenger_stat']['error'].' LIKE '.$db->str('%(1009)%').
            ' OR '.$sql_tabs['messenger_stat']['error'].' LIKE '.$db->str('%(1021)%').
            ' OR '.$sql_tabs['messenger_stat']['error'].' LIKE '.$db->str('%(472)%').
            ' OR '.$sql_tabs['messenger_stat']['error'].' LIKE '.$db->str('%(480)%').
            ')'.
            $where,
            $sql_tabs['messenger_stat']['updated_at'].' DESC'
        );
//        echo $db->last_sql;
        while ($row = $db->zeile($res)) {
            //todo why not working distinct?
            // for now rewrited is to getting uniq by php code
            if (!in_array($row['recipient'], $notValid['recipients'])) {
                $notValid['recipients'][] = $row['recipient'];
            }

            if (!$short) {
                //recipient id can set to many customers!
                if (!isset($notValid['stammdatenIds'][$row['stammdaten_id']])) {
                    $notValid['stammdatenIds'][$row['stammdaten_id']] = [
                        'messenger_stat_id' => $row['messenger_stat_id'],
                        'recipient' => $row['recipient'],
                        'message_uuid' => $row['message_uuid'],
                        'updated_at' => $row['updated_at'],
                        'error' => $row['error']
                    ];
                }
            }
        }

        return $notValid;
    }

    /** get values of array, (then for generate selectbox)
     *
     * @param string $field
     *
     * @return array
     */
    public static function getUniqueFromStat($field) {
        global $db, $sql_tab, $sql_tabs;
        $out = [];
        $order = $sql_tabs['messenger_stat'][$field].' ASC';
        $distinct = 'distinct '.$sql_tabs['messenger_stat'][$field];
        if ($field === 'filter_id') {
            $order = 'filter_name ASC';
        }
        $res = $db->select(
            $sql_tab['messenger_stat'].
            ' LEFT JOIN '.$sql_tab['filter'].
            ' ON '.$sql_tabs['filter']['filter_id'].'='.$sql_tabs['messenger_stat']['filter_id'],
            [
                $distinct,
                $sql_tabs['filter']['name'].' as filter_name',
            ], '', $order
        );
        while ($row = $db->zeile($res)) {
            if ($field === 'filter_id') {
                $out[$row[$field]] = $row['filter_name'];
                if ($row[$field] === '0') {
                    $out[$row[$field]] = 'kein filter / manueller test';
                }
            } elseif (!empty($row[$field])) {
                $out[$row[$field]] = $row[$field];
            }
        }

        return $out;
    }

    /**
     * @param null|array $conditions
     *
     * @return array
     */
    public static function listFilteredStat($conditions = null) {
        global $db, $sql_tab, $sql_tabs, $sql_meta;
        $where = $tableTypes = $result = array();
        if (!is_array($conditions)) {
            $conditions = array();
        }
        $tableStructure = $sql_tabs['messenger_stat'];
        foreach ($sql_meta['messenger_stat'] as $key => $value) {
            $tableTypes[$tableStructure[$key]] = $value[0];
        }
        foreach ($conditions as $key => $value) {
            if (!isset($tableStructure[$key])) {
                continue;
            }
            $sqlKey = $tableStructure[$key];
            $type = $tableTypes[$sqlKey];
            if (is_array($value)) {
                if (isset($value['from']) || isset($value['to'])) {
                    $from = @$value['from'];
                    if (intval($from) > 0) {
                        if (in_array($type, array('D', 'T', 'TS'))) {
                            $from = strtotime($from);
                        }
                        $where[] = $tableStructure[$key].'>='.$db->prepareValue($type, $from);
                    }
                    $to = @$value['to'];
                    if (intval($to) > 0) {
                        if (in_array($type, array('D', 'T', 'TS'))) {
                            $to = strtotime($to);
                        }
                        $where[] = $tableStructure[$key].'<='.$db->prepareValue($type, $to);
                    }
                } else {
                    if ($type === 'I' || $type === 'F') {
                        $where[] = $db->dbzahlin($value, $tableStructure[$key]);
                    } else {
                        $where[] = $db->dbstrin($value, $tableStructure[$key]);
                    }
                }
            } else {
                if (is_scalar($value)) {
                    if ($value === '-1' || $value === -1) {
                        continue;
                    }
                    if (strstr($value, '%')) {
                        $where[] = $tableStructure[$key].' LIKE '.$db->prepareValue($type, $value);
                    } else {
                        $where[] = $tableStructure[$key].'='.$db->prepareValue($type, $value);
                    }
                }
            }
        }
        $where = implode(' AND ', $where);
        $select = array_values($sql_tabs['messenger_stat']);
        $select[] = $sql_tabs['filter']['name'].' as filter_name';
        $select[] = $sql_tabs['stammdaten']['anzeigename'];
        $select[] = $sql_tabs['messenger_data']['html'];
        $res = $db->select(
            $sql_tab['messenger_stat'].
            ' LEFT JOIN '.$sql_tab['filter'].
            ' ON '.$sql_tabs['messenger_stat']['filter_id'].'='.$sql_tabs['filter']['filter_id'].
            ' LEFT JOIN '.$sql_tab['stammdaten'].
            ' ON '.$sql_tabs['messenger_stat']['stammdaten_id'].' = '.$sql_tabs['stammdaten']['id'].
            ' LEFT JOIN '.$sql_tab['messenger_data'].
            ' ON '.$sql_tabs['messenger_stat']['message_uuid'].' = '.$sql_tabs['messenger_data']['message_uuid'],
            $select,
            $where,
            $sql_tabs['messenger_stat']['created_at'].' DESC', $sql_tabs['messenger_stat']['messenger_stat_id'].' DESC'
        );
//        AzureApp::dd($db->last_sql,'red','last', true);
        while ($row = $db->zeile($res)) {
            $tmp = [];
            foreach ($row as $key => $val) {
                if (!is_numeric($key)) {
                    $tmp[$key] = $val;
                }
            }
            if ($tmp['filter_id'] === '0') {
                $tmp['filter_name'] = 'kein filter / manueller test';
            }
            $result[] = $tmp;
        }

        return $result;
    }
}