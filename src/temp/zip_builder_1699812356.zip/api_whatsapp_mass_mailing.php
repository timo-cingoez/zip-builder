<?php
/**
 * for phpstorm:
 * @noinspection PhpUndefinedConstantInspection
 * @var array $sql_tabs
 * @var array $sql_tab
 * @var PDB $db
 * @var null|string $cfg_basedir
 */

$noauth = true;
$mainPhpFile = basename(__FILE__);
include_once('inc/session.php');
PearAutoLoader::instance()->addSourceRoot('inc/services');

try {
    $logger = new Logger_File('log/'.MessengerPeopleV2::CONFIG_MODULE.'_v'.MessengerPeopleV2::MODULE_VERSION.'_mass_mailing.txt');
    if (empty($cfg_messengerpeople_v2)) {
        throw new Exception('$cfg_messengerpeople_v2 deaktiviert.');
    }
    $mpObj = MessengerPeopleV2::instance();
    $form = new htmlform();
    $messenger = 'whatsapp';
    if (!empty($_SESSION['crm_sec_pfad'])) {
        $mainPhpFile = $_SESSION['crm_sec_pfad'].$mainPhpFile;
    }

    $mpObj->setMainPhpFile($mainPhpFile);
    $full_cfg = MessengerPeopleV2::getParams();
    //AzureApp::dd($full_cfg, 'brown',  'full cfg');
    // get full config for templates section
    $templates_config = MessengerPeopleV2::getTemplatesCfg('templates', $full_cfg);
    $mass_templates_cfg = MessengerPeopleV2::getTemplatesCfg('mass_templates', $full_cfg);
    if (count_p4n($mass_templates_cfg) === 0) {
        throw new Exception('Bitte richten Sie zuerst Ihre WhatsApp-Massenvorlage ein.');
    }

    if (count_p4n($mpObj->channels[$messenger]) === 0) {
        throw new Exception('Nicht gefundene aktive Kan�le. '.MessengerPeopleV2::CONFIG_MODULE.' - Einstellungen pr�fen');
    }

    $action = $recipient = $stid = '';
    if (isset($_GET['action'])) {
        switch ($_GET['action']) {
            case 'form-step-one':
                $select_templates = $templates_approved = $warning = $select_channel = [];
                //$select_options = $mpObj->getTemplateSelectboxOptions();

                if (count_p4n($_SESSION['whatsapp-mass-mailing']) === 0) {
                    throw new Exception('Bitte Empf�nger ausw�hlen.');
                }
                if (empty($_GET['filter_id']) || !is_numeric($_GET['filter_id'])) {
                    throw new Exception(_FALSCHE_DATEN_.': Filter ID');
                }

                //--------check templates ------

                //get external data via api
                $data = $mpObj->getDataTemplate();
                if ($data === false) {
                    throw new Exception('Keine registrierten Vorlagen im '.MessengerPeopleV2::CONFIG_MODULE.' Dienst gefunden');
                }
                // AzureApp::dd($data, 'green', 'via_api');
                foreach ($data as $template_name => $options) {
                    if (in_array($template_name, $mass_templates_cfg)) {
                        if (empty($options['translations']) || empty($options['translations'][$mpObj->moduleLanguage])) {
                            $warning[] = '<b>'.$template_name.'</b>: Keine �bersetzungen f�r ausgew�hlte Sprache gefunden '.strtoupper($mpObj->moduleLanguage).'</b> Vorlage �berspringen';
                        } elseif (!empty($options['translations'][$mpObj->moduleLanguage]) &&
                            $options['translations'][$mpObj->moduleLanguage]['status'] !== 'APPROVED') {
                            $warning[] = '<b>'.$template_name.'</b>: '._NICHT_.' APPROVED. Vorlage �berspringen';
                        } else {
                            $select_templates[$template_name] = $template_name;
                            $templates_approved[$template_name] = $options['translations'][$mpObj->moduleLanguage];
                        }
                    }
                }
                if (count_p4n(array_keys($select_templates)) === 0) {
                    throw new Exception('Keine genehmigten Vorlagen gefunden');
                }
                $_SESSION['whatsapp-mass-mailing-cfg'] = [];
                $_SESSION['whatsapp-mass-mailing-cfg']['templates-approved'] = $templates_approved;
                $_SESSION['whatsapp-mass-mailing-cfg']['filter-id'] = $_GET['filter_id'];

                //--------preview content --------
                $div_content = '';
                $manuals = [];
//                AzureApp::dd($templates_config,'green','$templates_config');
//                AzureApp::dd($data,'grey');
                //AzureApp::dd($templates_approved, 'grey', '$templates_approved', true);
                foreach ($templates_approved as $template_name => $options) {
                    //AzureApp::dd($templates_config[$template_name], 'grey', '$templates_config[$template_name]', true);
                    $div_manual = $div_image = '';
                    $h = 0;
                    $b = 0;
                    //need before set placeholders in admin settings section?
                    $needSetPlaceholder = false;
                    $div_content .= '<table class="show_by_trigger"  id="'.$template_name.'" style="display:none">
                <tr><td><div class="jss1">
                <div title="'._VORSCHAU_.'" class="jss218">
                    <div><p class="jss224">'._VORSCHAU_.' '.$template_name.'</p>
                        <div class="jss4">
                        <div class="jss222">';

                    if ($templates_approved[$template_name]['header_type'] === 'MEDIA') {
                        //AzureApp::dd([$template_name,$templates_approved[$template_name]['header_type'],$templates_approved[$template_name]['header_media_type']],'red');
                        $image = $document = $video = $location = '';
                        if ($templates_approved[$template_name]['header_media_type'] === 'LOCATION') {
                            echo 'todo: LOCATION type';
                            if (!empty($templates_config[$template_name]['header']['switch'][1]) &&
                                $templates_config[$template_name]['header']['switch'][1] === 'media-location' &&
                                !empty($templates_config[$template_name]['header']['field'][1])
                            ) {
                                $location = $templates_config[$template_name]['header']['field'][1];
                            }
                        } elseif ($templates_approved[$template_name]["header_media_type"] === 'DOCUMENT') {
                            echo 'todo: DOCUMENT type';
                            if (!empty($templates_config[$template_name]['header']['switch'][1]) &&
                                $templates_config[$template_name]['header']['switch'][1] === 'media-document' &&
                                !empty($templates_config[$template_name]['header']['field'][1])
                            ) {
                                $document = $templates_config[$template_name]['header']['field'][1];
                            }
                        } elseif ($templates_approved[$template_name]["header_media_type"] === 'VIDEO') {
                            echo 'todo: VIDEO type';
                            if (!empty($templates_config[$template_name]['header']['switch'][1]) &&
                                $templates_config[$template_name]['header']['switch'][1] === 'media-video' &&
                                !empty($templates_config[$template_name]['header']['field'][1])
                            ) {
                                $video = $templates_config[$template_name]['header']['field'][1];
                            }
                        } elseif ($templates_approved[$template_name]["header_media_type"] === 'IMAGE') {
                            //is set in config?
                            if (!empty($templates_config[$template_name]['header']['switch'][1]) &&
                                $templates_config[$template_name]['header']['switch'][1] === 'media-image' &&
                                !empty($templates_config[$template_name]['header']['field'][1])
                            ) {
                                //https://api.messengerpeople.dev/docs/resource/media
                                //MP provider: We will delete media on our servers after 60 days.
                                //so we need upload again! and we can�t save the uuid of the image forever!

                                //image url or local file
                                $image = $templates_config[$template_name]['header']['field'][1];
                                // $tmp = file_get_contents($image);
                                //check ... exist, jpg/png
                                // Read image path, convert to base64 encoding
                                //$imageData = base64_encode($tmp);
                                // Format the image SRC:  data:{mime};base64,{data};
                                //$src = 'data: '.mime_content_type($image).';base64,'.$imageData;
                                // Echo out a sample image <img src = $src
                            }

                            if (empty($image)) {
                                //todo no document & etc.
                                $image = $cfg_basedir.'img/no-image.png';
                                $div_manual .= '<div class="jss5" style="margin-top: 25px;padding: 5px 10px;"><b>Header</b></div>
                                    <div class="jss5" style="margin-top: 5px;padding: 5px 10px;">{{image URL}} <small>(jpg/png)</small> -&gt; '.
                                    $form->textinput(
                                        'media_image',
                                        '',
                                        30,
                                        'data-position="header" data-num="1" class="media-image"'
                                    ).
                                    '</div>';
                            } else {
                                $div_manual .= '<div class="jss5" style="margin-top: 25px;padding: 5px 10px;"><b>Header</b></div>
                                    <div class="jss5" style="margin-top: 5px;padding: 5px 10px;">{{image URL}} <small>(jpg/png)</small> -&gt; <small>'.
                                    $image.
                                    $form->hidden('media_image', $image, 'data-position="header" data-num="1" class="media-image"').
                                    '</small></div>';
                            }
                            $div_content .= '<div class="jss5" style="margin-top: 25px;padding: 5px 10px;">
                                  <img src="'.$image.'" class="message-header-image">
                                  </div>';
                        } elseif ($templates_approved[$template_name]["header_media_type"] === 'DOCUMENT') {
                            //FaceBook allowed only PDF for now 25.10.2023
                            //https://developers.facebook.com/docs/whatsapp/on-premises/reference/messages#template-object
                            $div_content .= '<b style="color:red">todo: '.$templates_approved[$template_name]["header_media_type"].'</b>';
                        } elseif ($templates_approved[$template_name]["header_media_type"] === 'VIDEO') {
                            $div_content .= '<b style="color:red">todo: '.$templates_approved[$template_name]["header_media_type"].'</b>';
                        } elseif ($templates_approved[$template_name]["header_media_type"] === 'LOCATION') {
                            $div_content .= '<b style="color:red">todo: '.$templates_approved[$template_name]["header_media_type"].'</b>';
                        } else {
                            $div_content .= '<div class="jss5" style="margin-top: 25px;padding: 5px 10px;">
                                                <b style="color:red">Unknown header media type'.$templates_approved[$template_name]["header_media_type"].'</b>
                                              </div>';
                        }
                    } elseif (!empty($options['header_text'])) {
                        //AzureApp::dd($options);
                        $div_content .= '<div class="jss5" style="margin-top: 25px;padding: 5px 10px;"><b>'.$options['header_text'].'</b></div>';
                        preg_match_all('/{{(\d+)}}/i', $options['header_text'], $m, PREG_PATTERN_ORDER);
                        for ($i = 0; $i < count_p4n($m[1]); $i++) {

                            if (!empty($m[1][$i])) {
                                if ($h === 0) {
                                    $div_manual .= '<div class="jss5" style="margin-top: 25px;padding: 5px 10px;"><b>Header</b></div>';
                                    $h++;
                                }
                                //$places[$template_name]['header'][] = $m[1][$i];
                                //AzureApp::dd($m[1][$i], 'gold','found');
                                if ($templates_config[$template_name]['header']['field'][$m[1][$i]] === 'manual-fill') {
                                    $manuals[$template_name]['header'][$m[1][$i]] = '';
                                    $div_manual .= '<div class="jss5" style="margin-top: 5px;padding: 5px 10px;">{{'.$m[1][$i].'}} -&gt; '.
                                        $form->textinput(
                                            'manual_header['.$m[1][$i].']',
                                            '',
                                            30,
                                            'data-position="header" data-num="'.$m[1][$i].'" id="header-'.$m[1][$i].'" class="manual"'
                                        ).
                                        '</div>';
                                } else {
                                    $div_manual .= '<div class="jss5" style="margin-top: 5px;padding: 5px 10px;">{{'.$m[1][$i].'}} -&gt; '.
                                        $templates_config[$template_name]['header']['field'][$m[1][$i]].'</div>';
                                    if (empty($templates_config[$template_name]['header']['field'][$m[1][$i]])) {
                                        $needSetPlaceholder = true;
                                    }
                                }
                            }
                        }
                    }
                    if (!empty($options['body_text'])) {
                        $div_content .= '<div class="jss5" style="padding: 5px 10px;">'.
                            wordwrap($options['body_text'], 64, "<br />\n").'</div>';

                        preg_match_all('/{{(\d+)}}/i', $options['body_text'], $m, PREG_PATTERN_ORDER);
                        for ($i = 0; $i < count_p4n($m[1]); $i++) {
                            if (!empty($m[1][$i])) {
                                if ($b === 0) {
                                    $div_manual .= '<div class="jss5" style="margin-top: 25px;padding: 5px 10px;"><b>Body</b></div>';
                                    $b++;
                                }
                                $manuals[$template_name]['body'][$m[1][$i]] = '';
                                if ($templates_config[$template_name]['body']['field'][$m[1][$i]] === 'manual-fill') {
                                    $div_manual .= '<div class="jss5" style="margin-top: 5px;padding: 5px 10px;">{{'.$m[1][$i].'}} -&gt; '.
                                        $form->textinput(
                                            'manual_body['.$m[1][$i].']',
                                            '',
                                            30,
                                            'data-position="body" data-num="'.$m[1][$i].'" id="body-'.$m[1][$i].'" class="manual"'
                                        ).
                                        '</div>';
                                } else {
                                    $div_manual .= '<div class="jss5" style="margin-top: 5px;padding: 5px 10px;">{{'.$m[1][$i].'}} -&gt; '.
                                        $templates_config[$template_name]['body']['field'][$m[1][$i]].'</div>';
                                    if (empty($templates_config[$template_name]['body']['field'][$m[1][$i]])) {
                                        $needSetPlaceholder = true;
                                    }
                                }
                            }
                        }
                    }
                    if (!empty($options['footer_text'])) {
                        $div_content .= '<div class="jss5" style="margin-top: 20px;padding: 5px 10px;"><i>'.
                            $options['footer_text'].'</i></div>';
                    }

                    $div_content .= '</div></div>';
                    if (!empty($options['buttons']) && is_array($options['buttons'])) {
                        $b = 0;
                        $div_content .='<div>';
                        foreach ($options['buttons'] as $id => $button) {
                            if ($button['type'] === 'QUICK_REPLY') {
                                $div_content .= '<div class="jss231"><div class="jss232"><span style="cursor: pointer !important;">'.
                                    $button['text'].
                                    '</div></div>';
                            } elseif ($button['type'] === 'PHONE_NUMBER') {
                                $div_content .= '<div class="jss231"><div class="jss232">'.$button['text'].
                                    ' '.oltext($button['phone_number'], '<img class="vmitte" src="bilder/overlib.gif">').
                                    '</div></div>';
                            } elseif ($button['type'] === 'URL') {
                                $div_content .= '<div class="jss231"><div class="jss232" style="text-align: center;">'.
                                    link2($button['text'], $button['url'], '', '', 'target=_blank').
                                    ' '.oltext($button['url'], '<img class="vmitte" src="bilder/overlib.gif">').
                                    '</div></div>';
                                preg_match_all('/{{(\d+)}}/i', $button['url'], $m, PREG_PATTERN_ORDER);
                                for ($i = 0; $i < count_p4n($m[1]); $i++) {
                                    if (!empty($m[1][$i])) {
                                        $manuals[$template_name]['button'][$m[1][$i]] = '';
                                        if ($b === 0) {
                                            $div_manual .= '<div class="jss5" style="margin-top: 25px;padding: 5px 10px;"><b>Button</b></div>';
                                            $b++;
                                        }
                                        if ($templates_config[$template_name]['button']['field'][$m[1][$i]] === 'manual-fill') {
                                            $div_manual .= '<div class="jss5" style="margin-top: 5px;padding: 5px 10px;">{{'.$m[1][$i].'}} -&gt; '.
                                                $form->textinput(
                                                        'manual_button['.$m[1][$i].']',
                                                        '',
                                                        30,
                                                        'data-position="button" data-num="'.$m[1][$i].'" id="button-'.$m[1][$i].'" class="manual"'
                                                ).
                                                '</div>';
                                        } else {
                                            $div_manual .= '<div class="jss5" style="margin-top: 5px;padding: 5px 10px;">{{'.$m[1][$i].'}} -&gt; '.
                                                $templates_config[$template_name]['button']['field'][$m[1][$i]].
                                                '</div>';
                                            if (empty($templates_config[$template_name]['button']['field'][$m[1][$i]])) {
                                                $needSetPlaceholder = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        $div_content .= '</div>';
                    }
                    if ($needSetPlaceholder) {
//                        //This template must be customized before it can be used
                        $div_manual .= '<span class="template-error">Diese Vorlage muss angepasst werden, bevor sie verwendet werden kann</span>'.
//                            //this field for JS validation and getting an error
                            $form->hidden('fake-input', '1', 'class="mark-template-error"');
                    }
                    $div_content .= '</div></div></div></div></td><td>'.$div_manual.'</td></tr></table></div>';
                }

                //--------list recipients------
//                $leads = MessengerPeopleV2::getMPLeadIds($_SESSION['whatsapp-mass-mailing'], $messenger);
                $customers = MessengerPeopleV2::getCustomersForWhatsappMassMailing($_SESSION['whatsapp-mass-mailing']);
//                AzureApp::dd($customers);

                //--------channels------
                $channels = $mpObj->channels[$messenger];
                foreach ($channels as $channel_phone => $options) {
                    $select_channel[$options['uuid']] = $channel_phone;
                }

                $allow = true;
                //--------content------
                ?>
                <style>
                    table.show_by_trigger td {padding:0; margin: 0;width: 650px}
                    span.success, span.error, span.warning, span.template-error {display: block;padding: 5px 10px;margin-right: 15px;}
                    .success {background-color: #DFF0D8;color: #468847;}
                    .error, .template-error {background-color: #F2DEDE;color: #B94A48;}
                    .warning {background-color: #f9f4d4;color: #0c30b7;}
                    .red {color: #B94A48;}
                    #counter-selected-customers {margin-left: 15px;}
                    .message-header-image {width:100%}
                    .jss231 {
                        color: #00a5f4;
                        height: 34px;
                        margin: 2px 0 0 2px;
                        display: flex;
                        padding: 0 16px;
                        font-size: 14px;
                        background: #fff;
                        box-shadow: 0 1px 0.5px rgba(0, 0, 0, .15);
                        align-items: center;
                        line-height: 20px;
                        white-space: pre-wrap;
                        border-radius: 7.5px;
                        justify-content: center;
                    }
                    *, ::before, ::after {
                        box-sizing: inherit;
                    }
                    .jss224 {
                        font-weight: bold;
                        font-size: 8px;
                    }
                    .jss218::before {
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        content: '';
                        opacity: 0.06;
                        background-color: maroon;
                    }
                    .jss218 {
                        padding: 16px;
                        min-height: 100%;
                        min-width:250px;
                        border-radius: 4px;
                        background-color: #e5ddd5;
                    }
                    .jss1::before {
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        content: '';
                        opacity: 0.06;
                    }
                    .jss1 {
                        padding: 16px;
                        min-height: 100%;
                        border-radius: 4px;
                    }
                    .jss4 {
                        position: relative;
                        word-wrap: break-word;
                        box-shadow: 0 1px 0.5px rgba(0, 0, 0, .15);
                        min-height: 50px;
                        border-radius: 7.5px;
                        background-color: #fff;
                        word-wrap: break-word;
                    }
                    .jss5 {
                        color: #262626;
                        font-size: 13.6px;
                        line-height: 19px;
                        word-wrap: break-word;
                    }
                </style>
                <?php
                if (!empty($warning)) {
                    echo '<span class="warning"><ul><li>'.implode('<li>', $warning).'</ul></span>';
                }
                ?>
                <span class="error" id="message-status" style="display: none"></span>
                <table class="table-ignore2 moderntable" style="width:99%;">
                    <tr>
                        <th class="th"></th>
                        <th class="th"><?= _KNAN_ ?></th>
                        <th class="th"><?= $form->selectinput(
                                'channel',
                                $select_channel, '', _BITTE_WAEHLEN_,
                                ' id="channel"  style="width:200px"'
                            ) ?>
                        </th>
                        <th class="th"><?= _VORLAGE_ ?></th>
                        <th class="th"><?= $form->selectinput(
                                'template',
                                $select_templates, '', _BITTE_WAEHLEN_,
                                ' id="template" class="on_change_trigger"  style="width:200px"'
                            ) ?></th>
                    </tr>
                </table>
                <table class="table-ignore2 moderntable table-margin-bottom" style="width:99%;">
                <tr class="heading">
                    <th class="small th" colspan="8">WhatsApp <?= _KNAN_ ?>
                        <span id="counter-selected-customers">[ <?=p4n_mb_string('ucfirst',_NO_CUSTOMERS_SELECTED_)?> ]</span>
                        <span id="attention-text"></span>
                    </th>
                </tr>
                <tr>
                    <th class="th">#</th>
                    <th class="th">ID</th>
                    <th class="th"><?= _ANZEIGENAME_ ?></th>
                    <th class="th">WhatsApp ID</th>
                    <th class="th"><?= _MOBILFON_ ?></th>
                    <th class="th">Lead-ID</th>
                    <th class="th"><?= _SENDEN_ ?></th>
                    <th class="th" style="width: 650px"><?= _WEBVORSCHAU_ ?></th>
                </tr>
                <?php
                $i = 0;
                $used = $customerIDs = [];
                $_SESSION['whatsapp-mass-mailing-cfg']['all-customers'] = $customers;
                foreach ($customers as $stid => $info) {
                    echo '<tr class="'.($i++ % 2 ? 'even' : 'odd').' first-child"><td>'.$i.'</td>'.
                        '<td>'.link2($stid.'<span class="icon icon-tab">&nbsp;</span>', 'javascript:void(0);', '', '', 'onclick="top.tabs.TabHelper.siteToTab(\'stammdaten_main.php?id='.$stid.'&nav=Uebersicht\')"', 1).'</td>'.
                        '<td>'.$info['anzeigename'].'</td><td>';
                    $to = '';
                    if (!empty($info['recipient'])) {
                        $to = $info['recipient'];
                        echo '<b class="validate-it" data-val="'.$info['recipient'].'">'.$info['recipient'].'</b>';
                    }
                    echo '</td><td>';
                    if (MessengerPeopleV2::isValidMobileForRecipient($info['phone'])) {
                        //valid  $info['phone']
                        if (empty($to)) {
                            $to = $info['phone'];
                            echo '<b class="validate-it" data-val="'.$info['phone'].'">+'.$info['phone'].'</b>';
                        } else {
                            echo (!empty($info['phone']) ? '+'.$info['phone'] : '-');
                        }
                    } else {
                        echo '<del>'.(!empty($info['phone']) ? '+'.$info['phone'] : '').'</del>';
                    }
                    //to shorten it
                    if (empty($to)) {
                        unset($_SESSION['whatsapp-mass-mailing-cfg']['all-customers'][$stid]);
                    } else {
                        $_SESSION['whatsapp-mass-mailing-cfg']['all-customers'][$stid]['recipient'] = $to;
                        unset($_SESSION['whatsapp-mass-mailing-cfg']['all-customers'][$stid]['phone']);
                    }

                    echo '</td><td>'.(!empty($info['kampagne_lead_id']) ?
                            link2($info['kampagne_lead_id'].'<span class="icon icon-tab">&nbsp;</span>',
                                'javascript:void(0);',
                                '', '',
                                'onclick="top.tabs.TabHelper.siteToTab(\'stammdaten_main.php?id='.$stid.'&lead='.$info['kampagne_lead_id'].'&nav=lead\')"', 1)
                            : '').'</td><td>';

                    if (!empty($to)) {
                        echo (!empty($used[$to]) ? '<small class="red">'._REASONNOCONTACT1_.' </small>' : '').
                            $form->checkinput('recipients['.$stid.']', $to,
                                'data-stid="'.$stid.'" class="selected-recipients" data-recipient="'.$to.'"'
                            );
                        $used[$to] = true;
                        //remove duplicate by customer id
                        if (!in_array($stid, $customerIDs)) {
                            $customerIDs[] = $stid;
                        }
                    }
                    echo '</td>';
                    if ($i === 1) {
                        echo '<td rowspan="'.count_p4n($customers).'">'.$div_content.'</td>';
                    }
                    echo '</tr>';
                }
                echo '</table>';
                echo $form->submit2('submit', 'WhatsApp '._VERSENDEN_, 'class="button" id="mp-button-send" onclick="javascript:sendMassMailingMP();"');
                echo $form->start('mass-mailing', $mainPhpFile.'?action=form-step-two', 'POST', '', 'onSubmit="P4nBoxHelper.startloading(true)" id="mass-mailing"');
                echo $form->hidden('mp-template', '', 'id="mp-template"');
                echo $form->hidden('mp-recipients', implode(',', $customerIDs), 'id="mp-recipients"');
                echo $form->hidden('mp-channel-uuid', '', 'id="mp-channel-uuid"');
                echo $form->hidden('mp-manual-data', '', 'id="mp-manual-data"');
                echo $form->hidden('mp-media-image', '', 'id="mp-media-image"');
                echo $form->ende();

                //check recipients for validity in old statistics
                $attention = [];
                if (count_p4n(array_keys($used))) {
                    $tmp = MessengerPeopleV2::getNotValidRecipientsFromStat(array_keys($used));
                    if (count_p4n($tmp['recipients'])) {
                        $attention = $tmp['recipients'];
                    }
                }
                $tmp = [];
                foreach (array_keys($manuals) as $template) {
                    $tmp[] = '"'.$template.'":{"header":{},"body":{},"button":{}}';
                }
                ?>
                <script type="text/javascript">
                    let cUUID = "-1";
                    let template = "-1";
                    let customerIDs = [<?= implode(',', $customerIDs)?>];
                    if (typeof customerIDs === "undefined" || customerIDs.length === 0) {
                        jq1112("#counter-selected-customers").html('[ <?=p4n_mb_string('ucfirst', _NO_CUSTOMERS_SELECTED_)?> ]');
                    } else {
                        jq1112("#counter-selected-customers").html('[ <?=p4n_mb_string('ucfirst', _AUSWAHL_)?>: ' + customerIDs.length + ' ]');
                    }
                    let warningRecipients = ["<?= implode('","', $attention)?>"];
                    let headerAttentionMess = ' <small style="color: #d8bb03;"><span class="material-icons-6-x" style="vertical-align: bottom">warning</span> Die Liste enth�lt Empf�nger, die keine g�ltigen WhatsApp-Benutzer sind</small>';
                    let recipientAttentionMess = '<span class="material-icons-6-x" style="color: #a79101;vertical-align: bottom; cursor: pointer" title="Der Empf�nger ist kein g�ltiger WhatsApp-Benutzer">warning</span>';
                    let tmp = '';
                    let isNotValid = false;
                    let selectedCustomers = [];

                    initCheckAllList();
                    let manuals = {<?= implode(',', $tmp)?>};
                    let mp_button_send = jq1112("#mp-button-send");
                    <?php
                    foreach ($manuals as $template => $holders) :
                        if (!empty($holders["header"])) :
                            foreach ($holders["header"] as $pos => $val) :
                            ?>
                            if (typeof manuals.<?=$template?>.header === "undefined") {
                                manuals["<?=$template?>"]["header"] = {"<?=$pos?>": "<?=$val?>"}
                            } else if (typeof manuals.<?=$template?>.header["<?=$pos?>"] === "undefined") {
                                manuals["<?=$template?>"]["header"] = {"<?=$pos?>": "<?=$val?>"}
                            } else {
                                manuals.<?=$template?>.header["<?=$pos?>"] = "<?=$val?>";
                            }
                            <?php
                            endforeach;
                        endif;
                        if (!empty($holders["body"])) :
                            foreach ($holders["body"] as $pos => $val) :
                            ?>
                            if (typeof manuals.<?=$template?>.body === "undefined") {
                                manuals["<?=$template?>"]["body"] = {"<?=$pos?>": "<?=$val?>"}
                            } else if (typeof manuals.<?=$template?>.body["<?=$pos?>"] === "undefined") {
                                manuals["<?=$template?>"]["body"] = {"<?=$pos?>": "<?=$val?>"}
                            } else {
                                manuals.<?=$template?>.body["<?=$pos?>"] = "<?=$val?>";
                            }
                            <?php
                            endforeach;
                        endif;
                        if (!empty($holders["button"])) :
                            foreach ($holders["button"] as $pos => $val) :
                            ?>
                            if (typeof manuals.<?=$template?>.button === "undefined") {
                                manuals["<?=$template?>"]["button"] = {"<?=$pos?>": "<?=$val?>"}
                            } else if (typeof manuals.<?=$template?>.button["<?=$pos?>"] === "undefined") {
                                manuals["<?=$template?>"]["button"] = {"<?=$pos?>": "<?=$val?>"}
                            } else {
                                manuals.<?=$template?>.button["<?=$pos?>"] = "<?=$val?>";
                            }
                            <?php
                            endforeach;
                        endif;
                    endforeach;
                    ?>

                    function sendMassMailingMP() {
                        if (mp_check()) {
                            if (mp_confirm()) {
                                jq1112("#mp-template").val(template);
                                jq1112("#mp-media-image").val("");
                                let imageUrl = jq1112("#" + template + " input.media-image").val();
                                if (typeof imageUrl !== typeof undefined && imageUrl.length > 3) {
                                    jq1112("#mp-media-image").val(imageUrl);
                                }
                                jq1112("#mp-channel-uuid").val(cUUID);
                                jq1112("#mp-recipients").val(customerIDs.join(";"));
                                if (typeof manuals[template] !== "undefined") {
                                    jq1112("#mp-manual-data").val(JSON.stringify(manuals[template]));
                                }
                                jq1112( "#mass-mailing" ).submit();
                                return true;
                            }
                        }
                        return false;
                    }

                    function initCheckAllList() {
                        let tmp = '';
                        //mark all
                        jq1112('.validate-it').each(function (index, item) {
                            tmp = jq1112(item).attr("data-val");
                            if (typeof tmp !== "undefined" && tmp !== "") {
                                if (warningRecipients.indexOf(tmp) >= 0) {
                                    jq1112(item).append(recipientAttentionMess);
                                }
                            }
                        });
                        //fill selectedCustomers by present checkbox
                        jq1112('.selected-recipients').each(function (index, item) {
                            tmp = jq1112(item).attr("data-recipient");
                            if (typeof tmp !== "undefined" && tmp !== "") {
                                if (warningRecipients.indexOf(tmp) >= 0) {
                                    isNotValid = true;
                                    console.log(jq1112(item).attr("data-stid") + ' is not valid');
                                }
                                selectedCustomers.push(tmp);
                            }
                        });
                        //add to top attention
                        if (isNotValid) {
                            jq1112("span#attention-text").html(headerAttentionMess);
                        }
                    }

                    function mp_check() {
                        isNotValid = false;
                        $.each(selectedCustomers, function (index, value) {
                            if (warningRecipients.indexOf(value) >= 0) {
                                isNotValid = true;
                            }
                        });
                        if (isNotValid) {
                            jq1112("#attention-text").html(headerAttentionMess);
                        } else {
                            jq1112("#attention-text").html("");
                        }

                        jq1112("span.warning").remove();
                        jq1112(".show_by_trigger").hide();
                        jq1112("span.error").html("").hide();
                        cUUID = jq1112("#channel").find(":selected").val();
                        template = jq1112("#template").find(":selected").val();
                        let out = true;
                        if ((typeof template === "undefined" || template === '-1') && (typeof cUUID === "undefined" || cUUID === '-1')) {
                            jq1112("span.error").html("Bitte einen Kanal und eine Vorlage w�hlen").show();
                            return false;
                        }
                        if (typeof cUUID === "undefined" || cUUID === '-1') {
                            jq1112("span.error").html("Bitte einen Kanal w�hlen").show();
                            return false;
                        }
                        if (typeof template === "undefined" || template === '-1') {
                            jq1112("span.error").html("Bitte eine Vorlage w�hlen").show();
                            return false;
                        }
                        jq1112("#" + template).show();
                        if (typeof customerIDs === "undefined" || typeof selectedCustomers === "undefined" || customerIDs.length === 0 || selectedCustomers.length === 0) {
                            jq1112("span.error").html("Bitte Empf�nger ausw�hlen.").show();
                            jq1112("#counter-selected-customers").html('[ <?=p4n_mb_string('ucfirst', _NO_CUSTOMERS_SELECTED_)?> ]');
                            return false;
                        } else {
                            jq1112("#counter-selected-customers").html('[ <?=p4n_mb_string('ucfirst', _AUSWAHL_)?>: ' + customerIDs.length + ' ]');
                        }

                        //is not configured replacement for placeholders in setup
                        let template_error = jq1112("#" + template + " input.mark-template-error");
                        console.log('template_error: ' + jq1112(template_error).val());
                        if (typeof jq1112(template_error).val() !== "undefined" && jq1112(template_error).val() === "1") {
                            jq1112("span.error").html("Diese Vorlage muss angepasst werden, bevor sie verwendet werden kann").show();
                            return false;
                        }

                        let image_field = jq1112("#" + template + " input.media-image");
                        //exist field?
                        if (image_field.length > 0) {
                            console.log('image_field required!');
                            let image_val = jq1112(image_field).val();
                            console.log(image_val);
                            if (typeof image_val === "undefined" || image_val.length < 3) {
                                jq1112("span.error").html("F�llen Sie das Feld aus, um die Url des Bildes einzugeben").show();
                                return false;
                            }

                            //validate on ext jpg/png
                            if (/\.(jpg|jpeg|png)$/.test(image_val.toLowerCase())) {
                                console.log(image_val + " is url to pic jpg/png");
                                //check via
                                let img = new Image();
                                if(img.complete){
                                    console.log(image_val + " image from cache");
                                } else {
                                    img.onload = function(){
                                        console.log(image_val + " the image by url exists");
                                    };
                                    img.onerror = function(){
                                        jq1112("span.error").html("Das Bild konnte nicht von dieser URL geladen werden: " + image_val).show();
                                        return false;
                                    }
                                }
                                img.src = image_val; //run
                            } else {
                                jq1112("span.error").html("Es sind nur '.jpg' und '.png' Bilder erlaubt.").show();
                                return false;
                            }
                        }

                        let tmp_manuals = jq1112("#" + template + " input.manual");

                        if (tmp_manuals.length > 0) {
                            tmp_manuals.each(
                                function (index, str) {
                                    if (typeof jq1112(this).val() === "undefined" || $(this).val() === "") {
                                        jq1112("span.error").html("Bitte geben Sie einen F�llwert ein.").show();
                                        out = false;
                                        return false;
                                    } else {
                                        manuals[template][jq1112(this).data("position")][jq1112(this).data("num")] = jq1112(this).val();
                                    }
                                });
                        }

                        return out;
                    }

                    function mp_confirm() {
                        //Are you sure you want to send? This action is paid!
                        return confirm('Den Vorgang wirklich ausf�hren? (Aus Hinweistext von LM-Zuweisung) Diese Aktion ist kostenpflichtig.');
                    }

                    $(".on_change_trigger").change(function () {
                        mp_check();
                    });

                    $(".selected-recipients").change(function () {
                        let id = $(this).data("stid");
                        tmp = $(this).attr("data-recipient"); //as string
                        if (this.checked) {
                            selectedCustomers.push(tmp);
                            customerIDs.push(id);
                        } else {
                            let index = customerIDs.indexOf(id);
                            if (index !== -1) {
                                customerIDs.splice(index, 1);
                            }

                            index = selectedCustomers.indexOf(tmp);

                            if (index !== -1) {
                                selectedCustomers.splice(index, 1);
                            }
                        }
                        if (typeof customerIDs === "undefined" || customerIDs.length === 0) {
                            jq1112("#counter-selected-customers").html('[ <?=p4n_mb_string('ucfirst', _NO_CUSTOMERS_SELECTED_)?> ]');
                            jq1112("span#attention-text").html("");
                        } else {
                            jq1112("#counter-selected-customers").html('[ <?=p4n_mb_string('ucfirst', _AUSWAHL_)?>: ' + customerIDs.length + ' ]');
                        }
                        mp_check();
                    });

                    $("#channel").change(function () {
                        mp_check();
                    });
                </script>
                <?php
                break;
            case 'form-step-two':
                if (count_p4n($_SESSION['whatsapp-mass-mailing-cfg']['all-customers']) === 0) {
                    throw new Exception('Bitte Empf�nger ausw�hlen.');
                }
                $sess = $_SESSION['whatsapp-mass-mailing-cfg']; //for short

                if (empty($_POST['mp-channel-uuid'])) {
                    throw new Exception('Bitte einen Kanal w�hlen');
                }

                $channelUUID = $_POST['mp-channel-uuid'];
                if (empty($mpObj->channelsUUIDtoRecipient[$channelUUID]) ||
                    empty($mpObj->channels['whatsapp'][$mpObj->channelsUUIDtoRecipient[$channelUUID]]) ||
                    !is_array($mpObj->channels['whatsapp'][$mpObj->channelsUUIDtoRecipient[$channelUUID]])
                ) {
                    throw new Exception('Bitte w�hlen Sie den aktiven Kanal');
                }
                //AzureApp::dd($mpObj->channels);

                if (empty($_POST['mp-recipients'])) {
                    throw new Exception('Bitte Empf�nger ausw�hlen.');
                }

                $recipients = explode(';',$_POST['mp-recipients']);

                if (count_p4n($recipients) === 0) {
                    throw new Exception('Bitte Empf�nger ausw�hlen.');
                }

                if (!in_array($_POST['mp-template'], $mass_templates_cfg)) {
                    throw new Exception('Bitte w�hlen Sie die Typvorlage "WhatsApp-Massenmailing" aus.');
                }

                $template_name = $_POST['mp-template'];
                if (empty($template_name)) {
                    throw new Exception('Bitte eine Vorlage w�hlen');
                }

                //                AzureApp::dd($template_name);
                //                AzureApp::dd($_POST['mp-manual-data']);
                //                AzureApp::dd($sess['templates-approved']);

                if (count_p4n($sess['templates-approved']) === 0 || count_p4n($sess['templates-approved'][$template_name]) === 0) {
                    throw new Exception('Bitte w�hlen Sie eine genehmigte Vorlage aus.');
                }
                $batch = [
                    'messenger' => $mpObj->messenger_to_ids[$messenger],
                    'filter_id' => $sess['filter-id'],
                    'batch_uuid' => uniqid('', true),
                    'created_at' => date('Y-m-d H:i:s', time())
                ];

                // $templates_config[$template_name] should be set if is placeholders & media;
                // in other can empty!
                $cfg = [];
                if (!empty($templates_config[$template_name])) {
                    $cfg = $templates_config[$template_name];
                }

                //AzureApp::dd($_POST['mp-media-image']);
                //add to $cfg media
                if ($sess['templates-approved'][$template_name]['header_type'] === 'MEDIA') {
                    $image = $document = $video = $location = '';
                    if ($sess['templates-approved'][$template_name]["header_media_type"] === 'LOCATION') {
                        echo 'todo: required LOCATION';
                        if (!empty($cfg['header']['switch'][1]) &&
                            $cfg['header']['switch'][1] === 'media-location' &&
                            !empty($cfg['header']['field'][1])
                        ) {
                            $location = $cfg['header']['field'][1];
                            //here need add location to quire
                        } else {
                            //block of code for required location
                        }
                    } elseif ($sess['templates-approved'][$template_name]["header_media_type"] === 'DOCUMENT') {
                        echo 'todo: required DOCUMENT';
                        if (!empty($cfg['header']['switch'][1]) &&
                            $cfg['header']['switch'][1] === 'media-document' &&
                            !empty($cfg['header']['field'][1])
                        ) {
                            $document = $cfg['header']['field'][1];
                            //here need add document to quire
                        } else {
                            //block of code for required document
                        }
                    } elseif ($sess['templates-approved'][$template_name]["header_media_type"] === 'VIDEO') {
                        echo 'todo: required VIDEO';
                        if (!empty($cfg['header']['switch'][1]) &&
                            $cfg['header']['switch'][1] === 'media-video' &&
                            !empty($cfg['header']['field'][1])
                        ) {
                            $video = $cfg['header']['field'][1];
                            //here need add video to quire
                        } else {
                            //block of code for required video
                        }

                    //image
                    } elseif ($sess['templates-approved'][$template_name]["header_media_type"] === 'IMAGE') {
                        if (!empty($cfg['header']['switch'][1]) &&
                            $cfg['header']['switch'][1] === 'media-image' &&
                            !empty($cfg['header']['field'][1])
                        ) {
                            //ok
                            $image = $cfg['header']['field'][1];
                            //AzureApp::dd($image, 'gold', 'image from CFG');
                        } else {
                            //block of code for required image
                            if (empty($_POST['mp-media-image'])) {
                                throw new Exception(_FALSCHE_DATEN_.': Image URl');
                            }
                            //todo need validate $_POST['mp-media-image']
                            $image = $_POST['mp-media-image'];
                            //AzureApp::dd($image, 'gold', 'image from _post');
                            $cfg['header']['switch'][1] = 'media-image';
                            $cfg['header']['field'][1] = $image;
                        }
                        //AzureApp::dd($image);
                        if (false === ($binary = file_get_contents($image))) {
                            throw new Exception('Ich kann die Bilddatei nicht von dieser URL abrufen: '.$image);
                        }
                        $mimetype = $imageUUID = null;
                        //AzureApp::dd($http_response_header);
                        foreach ($http_response_header as $v) {
                            preg_match('/^content\-type:\s*(image\/[^;\s\n\r]+)/i', $v, $m);
                            if (!empty($m[1])) {
                                $tmp = $m[1];
                                if ($m[1] === 'image/png' || $m[1] === 'image/jpeg') {
                                    $mimetype = $m[1];
                                }
                            }
                        }
                        if (!empty($mimetype)) {
                            // sendMediaFile it is other than sendFile
                            //if (false === ($response = $mpObj->sendMediaFile($binary))) {
//                            if (!empty($response['handle'])) {
//                                $imageUUID = $response['handle'];
                            // TODO why not working?
                            // {"type":"image","image":{"id":$response['handle']}}

//                            if (false === ($response = $mpObj->mpSendFile($binary, $mimetype))) {
//                                //The image could not be uploaded to the MP server.
//                                throw new Exception('Das Bild konnte nicht auf den MP-Server hochgeladen werden. '.$mpObj->api->error);
//                            }
//                            if (!empty($response['id'])) {
//                                $imageUUID = $response['id'];
//                            } else {
//                                throw new Exception('Das Bild konnte nicht auf den MP-Server hochgeladen werden. '.print_r($response, true));
//                            }
                            // TODO why not working?
                            // {"type":"image","image":{"id":$response['handle']}}

                            //ok
                            //for now will use {"type":"image","image":{"link":http.....}}
                        } else {
                            throw new Exception("Es sind nur '.jpg' und '.png' Bilder erlaubt. ".(!empty($tmp) ? '['.$tmp.']' : ''));
                        }
                        // I use index 2 !!! for UUID then will use it in template->replace
                        // $cfg['header']['field'][2] = $imageUUID;
                        // $cfg['header']['field'][1] <-- here is link
                    }
                }

                $mpObj->setTemplateForMassMailing($template_name);
//                AzureApp::dd($cfg,'blue', '$templates_config[$template_name]');

                $manual_fields_values = [];
                if (!empty($_POST['mp-manual-data'])) {
                    $manual_fields_values = json_decode($_POST['mp-manual-data'], true);
                    //AzureApp::dd($manual_fields_values, 'darkgroove', '$manual_fields_values');
                    //header":{},"body":{"1":"at 15:20"}}"
                }

                //check manual input && add to $cfg[$position]['manual-value'][$index] values
                foreach (['header', 'body', 'button'] as $position) {
                    if (count_p4n($cfg[$position]['field'])) {
                        foreach ($cfg[$position]['field'] as $index => $value) {
                            if ($value === 'manual-fill') {
                                if (empty($manual_fields_values[$position][$index])) {
                                    throw new Exception('Empty header placeholder '.$index.' value');
                                }
                                $cfg[$position]['manual-value'][$index] = $manual_fields_values[$position][$index];
                            }
                        }
                    }
                }
//                AzureApp::dd($cfg, 'darkgroove', '$cfg modified');
                //AzureApp::dd($sess['templates-approved'][$template_name],'red', 'template_content');
                //die();
                $statistic = $statistic_exception = [];
                $i = 0;
                foreach ($sess['all-customers'] as $stid => $info) {
                    if (in_array($stid, $recipients)) {
                        $data = [
                            'channelUUID' => $channelUUID,
                            'recipient' => $info['recipient'],
                            'stammdaten_id' => $stid,
                            'kampagne_lead_id' => $info['kampagne_lead_id'],
                            'template_content' => $sess['templates-approved'][$template_name],
                            'leadid' => $info['leadid'],
                            'cfg' => $cfg
                        ];
                        try {
                            $out = $mpObj->sendWhatsAppMassMailingMessage($data, $batch);
                            if (!empty($out['id'])) {
                                //queued
                                $statistic[$stid] = $out['id'];
                                $logger->info('Mass Mailing - queued: [stid'.$stid.'] '.$info['recipient'].' '.$info['anzeigename']);
                            } else {
                                throw new Exception(print_r($out, true));
                            }
                            //AzureApp::dd($out, 'green', '$out sendWhatsAppMassMailingMessage');
                        }  catch (Exception $e) {
                            $logger->error('Mass Mailing - no queue: [stid'.$stid.'] '.$info['recipient'].' '.$info['anzeigename']);
                            $m = $e->getMessage();
                            //echo '<br>'.$m;
                            $statistic_exception[$stid] = $m;
                            $logger->error('Mass Mailing Error: '.$m);
                            //return array('success' => false, 'error' => true, 'message' => $m);
                        }
                    }
                }
                ?>
                <table class="table-ignore2 moderntable table-margin-bottom" style="width:99%;">
                <tr class="heading">
                    <th class="small th" colspan="6">WhatsApp <?= _KNAN_ ?></th>
                </tr>
                <tr>
                    <th class="th">#</th>
                    <th class="th">ID</th>
                    <th class="th"><?= _ANZEIGENAME_ ?></th>
                    <th class="th">WhatsApp ID</th>
                    <th class="th"><?= _SENDEN_ ?></th>
                    </tr>
                <?php
                $i = 0;

                //important! Pause to allow MP service provider write data
                sleep(5);

                foreach ($statistic as $stid => $message_id) {
                    echo '<tr class="'.($i++ % 2 ? 'even' : 'odd').' first-child">'.
                        '<td>'.$i.'</td>'.
                        '<td>'.$stid.'</td>'.
                        '<td>'.(!empty($sess['all-customers'][$stid]['firma1']) ?
                            $sess['all-customers'][$stid]['firma1'] :
                            $sess['all-customers'][$stid]['anzeigename']).'</td>'.
                        '<td>'.$sess['all-customers'][$stid]['recipient'].'</td>';
                    try {
                        if (false === ($response = $mpObj->getMessage($message_id))) {
                            $error = (!empty($mpObj->api->errorCode) ? '('.$mpObj->api->errorCode.') ' : '').
                                (!empty($mpObj->api->error) ? $mpObj->api->error : '');
                            echo '<td>'._FEHLER_.': '.$error.'</td>';
                            $logger->error('Mass Mailing - get status error. [stid'.$stid.'] '.$error);
                            $mpObj->updateStat([
                                'stammdaten_id' => $stid,
                                'message_uuid' => $message_id,
                                'status' => 'error',
                                'error' => $error
                            ]);
                        } else {
                            $logger->info('Mass Mailing - status ok. [stid'.$stid.']');
                            echo '<td>'._ERFOLGREICH_.'</td>';
                            $mpObj->updateStat([
                                'stammdaten_id' => $stid,
                                'message_uuid' => $message_id,
                                'status' => 'success'
                            ]);
                        }
                    } catch (Exception $e) {
                        $mpObj->updateStat([
                            'stammdaten_id' => $stid,
                            'message_uuid' => $message_id,
                            'status' => 'error',
                            'error' => $e->getMessage()
                        ]);
                        $logger->error('Mass Mailing - get status error. [stid'.$stid.'] '.$e->getMessage());
                        echo '<td>'._FEHLER_.': '.$e->getMessage().'</td>';
                    }
                    echo '</tr>';
                }
                //continue rows
                foreach ($statistic_exception as $stid => $error) {
                    $logger->error('Mass Mailing - skip get status. [stid'.$stid.']');
                    echo '<tr class="'.($i++ % 2 ? 'even' : 'odd').' first-child">'.
                        '<td>'.$i.'</td>'.
                        '<td>'.$stid.'</td>'.
                        '<td>'.$sess['all-customers'][$stid]['anzeigename'].'</td>'.
                        '<td>'.$sess['all-customers'][$stid]['recipient'].'</td>'.
                        '<td>'._FEHLER_.': '.$error.'</td>
                        </tr>';
                }
                echo '</table>';
                //todo - maybe to run by scheduled & +DB?
                //session reset; so if the iframe is refreshed - no re send again
                unset($_SESSION['whatsapp-mass-mailing-cfg']);
                break;
        }
    }
    fuss();

} catch (Exception $e) {
    // silent top
    if (ob_get_level()) {
        clear_all_buffer();
    }
    if (!empty($logger)) {
        $logger->error('Mass Mailing Exception. '.$e->getMessage());
    }
    echo $e->getMessage();
}