<?php

class SeatLeads_Api extends BaseRest {
    const URL_PROD = 'https://prod.api.nsc.vwgroup.de/de/lead-partner';
    const URL_TEST = 'https://int.api.nsc.vwgroup.de/de/int/lead-partner/api';

    public function __construct($url, array $params = array()) {
        $missed = array();
        foreach (array('client_id', 'client_secret', 'certificate', 'private_key') as $key) {
            if (empty($params[$key])) {
                $missed[] = $key;
            }
        }
        if (!empty($missed)) {
            throw new Exception(_EINSTELLUNGEN_.' '._UNVOLLSTAENDIG_.' ('.implode('/', $missed).')');
        }
        if (empty($url)) {
            $url = self::getUrl();
        }
        parent::__construct($url, array('verifyCert' => false));
        if (!empty($params['logging'])) {
            $this->enableLog();
        }
        $this->header = array(
            'client_id: '.$params['client_id'],
            'client_secret: '.$params['client_secret'],
            'Content-Type: application/json'
        );
        $this->setCurlOpt(CURLOPT_SSLCERT, $params['certificate']);
        $this->setCurlOpt(CURLOPT_SSLKEY, $params['private_key']);
    }

    public function getLeads() {
        return $this->preGet('leads?dealer-id=DEU88232S&brand=SEAT');
    }

    public function generateTestLeads($dealerId, $type, $count) {
        if (empty($type)) {
            $type = 'Test Drive';
        }
        $count = intval($count);
        if ($count < 1 || $count > 10) {
            $count = 1;
        }
        $data = array(
            'test-leads' => array(
                array(
                    'customer-type'     => $type,//'Test Drive',
                    'status'            => 'New',
                    'number-of-records' => $count//1
                )
            )
        );
        return $this->prePost($data, 'leads/testdata?dealer-id='.$dealerId.'&brand=SEAT');
    }

    public static function getUrl() {
        if ($_SESSION['cfg_kunde'] === 'carlo_opel_prof4net') {
            $url = self::URL_TEST;
        } else {
            $url = self::URL_PROD;
        }
        return $url;
    }
    /**
     * Prepares the GET request
     *
     * @param string $func
     * @return array response
     */
    private function preGet($func) {
        return $this->parseResponse($this->get($this->url.'/'.$func));
    }
    /**
     * Prepares the POST request
     * @param array $data
     * @param $func
     * @return array response
     */
    private function prePost(array $data, $func) {
        $response = $this->post(json_encode($data), $this->url.'/'.$func);
        return $this->parseResponse($response);
    }
    /**
     * Checks and formats the response
     * @param $response
     * @return array data
     * @throws Exception
     */
    private function parseResponse($response) {
        $data = json_decode($response, true);
        if (!is_array($data)) {
            throw new Exception('Response must be a JSON');
        }
        return $data;
    }
}