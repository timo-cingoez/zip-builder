<?php
    @session_start();
    $noauth=true;
//    ob_start();
    include_once('inc/session.php');
    ob_end_clean();
    $cfg_merke_zeit=microtime();
    
    $tage=180;
    
    $res=$db->select(
                        $sql_tab['kampagne_lead'],
                        array(
                            $sql_tabs['kampagne_lead']['kampagne_lead_id'],
                            $sql_tabs['kampagne_lead']['stammdaten_id'],
                            $sql_tabs['kampagne_lead']['produktzuordnung_id'],
                            $sql_tabs['kampagne_lead']['benutzer_id'],
                            $sql_tabs['kampagne_lead']['preisvorstellung'],
                            $sql_tabs['kampagne_lead']['kampagne_id']
                        ), 
                        $sql_tabs['kampagne_lead']['produktzuordnung_id'].'>0 and '.
                        $sql_tabs['kampagne_lead']['preisvorstellung'].'>0 and '.
                        $sql_tabs['kampagne_lead']['status'].'='.$db->str('5').' and '.
                            $sql_tabs['kampagne_lead']['status1_time'].'>='.$db->dbtimestamp(time()-180*24*60*60)
    );
    echo $db->anzahl($res)." Leads gefunden\n";
    $log=$db->anzahl($res)." Leads\r\n";
    while ($row=$db->zeile($res)) {
        $res2=$db->select(
            $sql_tab['produktzuordnung'],
            $sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'],
            $sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($row[2])
        );
        if ($row2=$db->zeile($res2)) {
            if (doubleval($row2[0])<=doubleval($row[4])) {
                $log.='Lead '.$row[0].' Preisvorstellung: '.$row[4].' - Fahrzeugpreis: '.$row2[0]."\r\n";
                
                $kpar_id=0;
                $res3=$db->select(
                    $sql_tab['korrespondenz'],
                    $sql_tabs['korrespondenz']['korrespondenz_id'],
                    $sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl($row[0]),
                    $sql_tabs['korrespondenz']['datum'].' desc'
                );
                if ($row3=$db->zeile($res3)) {
                    $kpar_id=$row3[0];
                }
                
                $db->delete(
                    $sql_tab['kampagne_lead_status'],
                    $sql_tabs['kampagne_lead_status']['kampagne_lead_id'].'='.$db->dbzahl($row[0])
                );
                $db->update(
                    $sql_tab['kampagne_lead'],
                    array(
                        $sql_tabs['kampagne_lead']['status5_time'] => 'NULL',
                        $sql_tabs['kampagne_lead']['status4_time'] => $db->dbtimestamp(time()),
                        $sql_tabs['kampagne_lead']['status'] => $db->str('4'),
                        $sql_tabs['kampagne_lead']['preisvorstellung'] => $db->dbzahl(0)
                    ),
                    $sql_tabs['kampagne_lead']['kampagne_lead_id'].'='.$db->dbzahl($row[0])
                );
                $sqlt1=array(
				$sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
				$sql_tabs['korrespondenz']['termin_datum'] => $db->dbtimestamp(time()),
				$sql_tabs['korrespondenz']['datum2'] => $db->dbdate(''),
				$sql_tabs['korrespondenz']['wvl_datum1'] => $db->dbtimestamp(time()),
				$sql_tabs['korrespondenz']['wvl_datum2'] => $db->dbdate(''),
				$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($row[1]),
				$sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl(1),
				$sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($row[3]),
				$sql_tabs['korrespondenz']['eingang'] => $db->dbzahl(true),
				$sql_tabs['korrespondenz']['art'] => $db->dbzahl(14),
				$sql_tabs['korrespondenz']['kategorie'] => $db->str('Preisvorstellung'),
				$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(false),
				$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($kpar_id),
				$sql_tabs['korrespondenz']['doclink'] => $db->str(''),
				$sql_tabs['korrespondenz']['betreff'] => $db->str('Preisvorstellung erreicht: '.$row[4].' - Fahrzeugpreis: '.$row2[0]),
				$sql_tabs['korrespondenz']['beschreibung'] =>$db->str(''),
				$sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl($row[2]),
				$sql_tabs['korrespondenz']['papierkorb'] => 0,
				$sql_tabs['korrespondenz']['kalender_id'] => $db->dbzahl(0),
				$sql_tabs['korrespondenz']['prioritaet'] => $db->dbzahl(0),
				$sql_tabs['korrespondenz']['negativ'] => $db->dblogic(0),
				$sql_tabs['korrespondenz']['auftrag_id'] => $db->dbzahl(0),
				$sql_tabs['korrespondenz']['ansprechpartner_id'] => $db->dbzahl(0),
				$sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl($row[0]),
				$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl($row[5])
				);
                $db->insert(
                    $sql_tab['korrespondenz'],
                    $sqlt1
                );
                
                // Mail:
                $res8=$db->select(
                    $sql_tab['benutzer'],
                    $sql_tabs['benutzer']['email'],
                    $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row[3])
                );
                if ($row8=$db->zeile($res8)) {
                    if ($row8[0]!='') {
                        $mailt='Preisvorstellung des Kunden '.kundenbezeichnung($row[1]).' ('.$row[1].')'.' auf Lead-ID '.$row[0].' erreicht.<br>
Das Lead wurde f�r Sie wieder automatisch ge�ffnet.<br><br>
<a href="'.$sc_crm_hostpfad.'index.php?extcrmziel2='.base64_encode('stammdaten_main.php?id='.$row[1].'&nav=lead&lead='.$row[0]).'">Link Lead</a>';
                        
                	    if (is_file("class.phpmailer.php")) {
							include_once("class.phpmailer.php");
							include_once('RFC822.php');
							include('mailconf.php');
						}
						$mail->ClearAllRecipients();
						$mail->ClearAttachments();
                        $absender = $mcs_pop3_email;
                        $absender_name='CATCH';
	    	        	
            			$mail->From     = $mcs_pop3_email;
			    		$mail->FromName = $mcs_pop3_email;
				    	$mail->IsHTML(true);
					    $mail->Subject  = 'Preisvorstellung Lead erreicht';
    					$mail->Body = $mailt;
	    				$mail->AddAddress($row8[0]);
		    			$gesendet=$mail->Send();
						if ($fp2=fopen($cfg_basedir.'inc/'.$_SESSION['cfg_kunde'].'/maillog.txt', 'a')) {
							fwrite($fp2, adodb_date('d.m.Y H:i:s', time()).': '.($gesendet?_OK_:_FEHLER_).' - '.'Preisvorstellung Lead'.': '.$row8[0].', Lead: '.$row[0]."\r\n");
							fclose($fp2);
						}
                    }
                }
            }
        }
    }
    echo $log;
?>