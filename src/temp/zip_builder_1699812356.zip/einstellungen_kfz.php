<?php
/**
 * for phpstorm:
 * @noinspection PhpUndefinedConstantInspection
 *
 * @var object $db
 * @var array $sql_tab
 * @var array $sql_tabs
 * @var array $lang
 * @var bool|null $cfg_ford_lds
 * @var bool|null $cfg_jassy
 * @var bool|null $cfg_jassy_conf
 */
// Optional Address Update
include_once('inc/session.php');
if (empty($cfg_lead_einstellungen_neu) && $_SESSION['crm_version'] < 68) {
    require 'einstellungen_kfz_alt.php';
    exit;
}
PearAutoLoader::instance()->addSourceRoot('inc/services');
$showChangeSettingsButton = $_SESSION['crm_version_float'] >= 61200;
if (!empty($cfg_lead_settings_change)) {
    $showChangeSettingsButton = true;
}

if (is_array($retailerLeads)) {
    $retailerLeads[] = 'Makros';
} else {
    $retailerLeads = array('Makros');
}

$postfeld = $_POST;
$getf = $_GET;
$files = $_FILES;

$passwHint = oltext(_ADMINBENUTZER_PASSWORT2_, '&nbsp;');
$handbuch = '<span class="handbuch" style="display:none;">'.link2('', 'handbuch_suche.php?source='.basename($phs), 'overlib.gif', '', 'target="_blank"').'</span>';

$view = @$getf['view'];

$navi = new Modern_Template_SubMenu();
$navi->class = 'karten';
$navi->mobile_id = 'einstellungen_kfz_karten';
$navi->wrapper_marginbottom = true;
$navi->setTitle(_LEAD_.' '._EINSTELLUNGEN_.$handbuch);
if ($_SESSION['user_id'] == 1 && empty($view)) {
    $navi->setFilterValues(
        array(
            array('', '<input type="text" name="sst_suche" onchange="searchInterface(this.value);" placeholder="'._SCHNITTSTELLEN_.'-'._SUCHE_.'"/>')
        )
    );
}
$kartei_values = array();
$kartei_values[] = array('<a class="karten'.(empty($view) ? '_a' : '').'" href="einstellungen_kfz.php" onClick="P4nBoxHelper.startloading(true);" >'._ALLE_.' '._LEADS_.'</a>');
if (!empty($cfg_leadengine_version_slmi6) || !empty($cfg_leadengine_version_slmi5)) {
    $kartei_values[] = array('<a class="karten'.($view === 'opel_leads' ? '_a' : '').'" href="einstellungen_kfz.php?view=opel_leads" onClick="P4nBoxHelper.startloading(true);" >'.'Opel '._LEADS_.'</a>');
}
$kartei_values[] = array('<a class="karten'.($view === 'notification_all' ? '_a' : '').'" href="einstellungen_kfz.php?view=notification_all" onClick="P4nBoxHelper.startloading(true);" >'._BENACHRICHTIGUNG_.'</a>');
$kartei_values[] = array('<a class="karten'.($view === 'customer_notification_all' ? '_a' : '').'" href="einstellungen_kfz.php?view=customer_notification_all" onClick="P4nBoxHelper.startloading(true);" >'._SP_KUNDEN_.'-'._BENACHRICHTIGUNG_.'</a>');
$kartei_values[] = array('<a class="karten'.($view === 'auto_assignment_all' ? '_a' : '').'" href="einstellungen_kfz.php?view=auto_assignment_all" onClick="P4nBoxHelper.startloading(true);" >'._LEADZUORDNUNG_.'</a>');
if ($_SESSION['crm_version_float'] >= 61200) {
    $kartei_values[] = array('<a class="karten'.($view === 'campaign_all' ? '_a' : '').'" href="einstellungen_kfz.php?view=campaign_all" onClick="P4nBoxHelper.startloading(true);" >'._KAMPAGNEN_.'</a>');
}
if ($_SESSION['crm_version_float'] >= 61300 || !empty($cfg_lead_other_settings)) {
    $kartei_values[] = array('<a class="karten'.($view === 'other_settings' ? '_a' : '').'" href="einstellungen_kfz.php?view=other_settings" onClick="P4nBoxHelper.startloading(true);" >'._SONSTIGES_.'</a>');
}
$navi->setKarteiValues(
    $kartei_values
);
$navi->setHtml();

if (!empty($view)) {
    $view =  'inc/Lead/views/'.$view.'.php';
    if (!is_file($view)) {
        exit(_DATEI_.' '._NICHT_GEFUNDEN_.' ('.$view.')');
    }
    require $view;
    fuss();
    exit;
}
// Lagerorte
$alle_mand1=array();
$res=$db->select(
    $sql_tab['mandant'],
    array(
        $sql_tabs['mandant']['mandant_id'],
        $sql_tabs['mandant']['bezeichnung'],
        $sql_tabs['mandant']['parent_id']
    ),
    '',
    $sql_tabs['mandant']['parent_id'].','.$sql_tabs['mandant']['bezeichnung']
);
while ($row=$db->zeile($res)) {
    $alle_mand1[$row[0]]=(intval($row[2])==0?$row[0].':':'').$row[1].(intval($row[2])>0?'/'.$row[2]:'');
}
// besser Ueberall das benutzen
$locationList = Location_Helper::instance()->getListWithClients();
// Kampagnen
$campaignsList = $tmp = array();
$res = $db->select(
    $sql_tab['kampagne'],
    array(
        $sql_tabs['kampagne']['kampagne_id'],
        $sql_tabs['kampagne']['bezeichnung'],
        $sql_tabs['kampagne']['kategorie']
    ),
    $sql_tabs['kampagne']['kategorie'].' like '.$db->str('%leads%'),
    $sql_tabs['kampagne']['bezeichnung']
);
while ($row = $db->zeile($res)) {
    $tmp[$row[2]][$row[0]] = $row[1];
}
foreach ($tmp as $category => $list) {
    $campaignsList[$category] = 'OPTGROUP';
    foreach ($list as $campaignId => $title) {
        $campaignsList[$campaignId] = $title;
    }
}

$trz='-#-#-#-#-';
$form=new htmlform;
if ($cfg_ford_lds && file_exists('inc/services/LDS/cfg_LDS.php')) {
    require_once('inc/services/LDS/cfg_LDS.php');
    require_once('inc/services/LDS/LDSAdditional.php');
}
if ($cfg_jassy || $cfg_jassy_conf || $cfg_ferrari_leads || $cfg_toyota_leads || $cfg_toyota_leads_at || $cfg_facebook_leads || $cfg_autouncle || $cfg_clever_lead || $cfg_messengerpeople || $cfg_alles_auto || $cfg_stellantis || $cfg_seat_leads) {
    if (isset($getf['jassy_delete'])) {
        Jassy_Settings::remove($getf['jassy_delete']);
    }
    if (isset($postfeld['jassy'])) {
        Jassy_Settings::save($postfeld['jassy']);
    }
    $MessengerPeople_class = 'MessengerPeople';
    if (!empty($cfg_messengerpeople_v2)) {
        $MessengerPeople_class .= 'V2';
    }
    $mp_field_name = lcfirst($MessengerPeople_class);
    // AzureApp::dd($_POST,'green','$_POST');
    //AzureApp::dd($postfeld[$mp_field_name],'blue','POST');
    $mp_post_error = '';
    $mp_post = array();
    if (isset($postfeld[$mp_field_name])) {
        $mp_post = $postfeld[$mp_field_name];
        // AzureApp::dd($mp_post, 'blue', '$mp_post');
        try {
            if (!empty($cfg_messengerpeople_v2)) {
                $mp_post = MessengerPeopleV2::checkParams($mp_post);
            }
            $MessengerPeople_class::saveParams($mp_post);
        } catch (Exception $e) {
            $mp_post_error = $e->getMessage();
        }
    }
    $mp_post = array();

    if (isset($postfeld['ferrari_leads'])) {
        Ferrari::saveAccessData($postfeld['ferrari_leads']);
    }
    if (isset($postfeld['toyota_leads'])) {
        ToyotaLeads::saveParams($postfeld['toyota_leads']);
    }
    if (isset($postfeld['toyota_leads_at'])) {
        ToyotaLeadsAT::saveParams($postfeld['toyota_leads_at']);
    }
    if (isset($postfeld['facebook_leads'])) {
        Facebook::saveParams($postfeld['facebook_leads']);
    }
    if (isset($postfeld['kia_leads'])) {
        KiaLeads::saveParams($postfeld['kia_leads']);
    }
    if (isset($getf['autouncle_delete'])) {
        AutoUncle::deleteParam($getf['autouncle_delete']);
    }
    if (isset($postfeld['autouncle'])) {
        $autouncle = $postfeld['autouncle'];
        if (isset($autouncle['new']) && empty($autouncle['new']['token'])) {
            unset($autouncle['new']);
        }
        AutoUncle::saveParams($autouncle);
    }
    if (isset($postfeld['clever_lead'])) {
        $cleverLead = $postfeld['clever_lead'];
        if (!empty($cleverLead['password_new'])) {
            $cleverLead['password'] = $cleverLead['password_new'];
        }
        if (!empty($cleverLead['client_secret_new'])) {
            $cleverLead['client_secret'] = $cleverLead['client_secret_new'];
        }
        unset($cleverLead['password_new']);
        unset($cleverLead['client_secret_new']);
        CleverLead::saveParams($cleverLead);
    }
    if (isset($postfeld['bmw_rsp'])) {
        $bmwRSP = BmwRSP::getParams();
        foreach ($postfeld['bmw_rsp'] as $key => $val) {
            $bmwRSP[$key] = $val;
        }
        BmwRSP::updateParams($bmwRSP);
    }
    if (isset($postfeld['alles_auto'])) {
        AllesAuto::saveParams($postfeld['alles_auto']);
    }
    if (isset($postfeld['stellantis'])) {
        Stellantis::saveParams($postfeld['stellantis']);
    }
    if (isset($postfeld['seat_leads'])) {
        $seatLeads = $postfeld['seat_leads'];
        if (isset($files['seat_certificate']) && $files['seat_certificate']['error']==0) {
            $certificate = file_get_contents($files['seat_certificate']['tmp_name']);
            $parsed = @openssl_x509_parse($certificate);
            if (!empty($parsed)) {
                $fileName = dirname($_SERVER['SCRIPT_FILENAME']).'/inc/services/SeatLeads/'.name2filename($files['seat_certificate']['name']);
                if (file_exists($fileName)) {
                    @unlink($fileName);
                }
                file_put_contents($fileName, $certificate);
                $seatLeads['certificate'] = $fileName;
                $seatLeads['certificate_valid'] = $parsed['validTo_time_t'];
            } else {
                echo '<span style="color:red;">Seat Leads: Zertifikat nicht g�ltig</span><br>';
            }
        }
        if (isset($files['seat_pkey']) && $files['seat_pkey']['error']==0) {
            $pkey = file_get_contents($files['seat_pkey']['tmp_name']);
            $parsed = openssl_pkey_get_private($pkey);
            if (!empty($parsed)) {
                $fileName = dirname($_SERVER['SCRIPT_FILENAME']).'/inc/services/SeatLeads/'.name2filename($files['seat_pkey']['name']);
                file_put_contents($fileName, $pkey);
                $seatLeads['private_key'] = $fileName;
            } else {
                echo '<span style="color:red;">Seat Leads: Private key nicht g�ltig</span><br>';
            }
        }
        SeatLeads::saveParams($seatLeads);
    }
}
if ($postfeld['submit']==_SUBMIT_STAMMDATEN_) {
    if (isset($postfeld['lds_site_code'])) {
        $lds_site_code = json_encode($postfeld['lds_site_code']);
        $res2=$db->select(
            $sql_tab['einstellungen'],
            $sql_tabs['einstellungen']['wert'],
            $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_site_code')
        );
        if ($row2=$db->zeile($res2)) {
            $db->update(
                $sql_tab['einstellungen'],
                array(
                    $sql_tabs['einstellungen']['wert'] => $db->str($lds_site_code)
                ),
                $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_site_code')
            );
        } else {
            $db->insert(
                $sql_tab['einstellungen'],
                array(
                    $sql_tabs['einstellungen']['wert'] => $db->str($lds_site_code),
                    $sql_tabs['einstellungen']['modul'] => $db->str('lds_site_code')
                )
            );
        }
    }
    if (isset($postfeld['lds_webservice_path'])) {
        $res2=$db->select(
            $sql_tab['einstellungen'],
            $sql_tabs['einstellungen']['wert'],
            $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_webservice_path')
        );
        if ($row2=$db->zeile($res2)) {
            $db->update(
                $sql_tab['einstellungen'],
                array(
                    $sql_tabs['einstellungen']['wert'] => $db->str($postfeld['lds_webservice_path'])
                ),
                $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_webservice_path')
            );
        } else {
            $db->insert(
                $sql_tab['einstellungen'],
                array(
                    $sql_tabs['einstellungen']['wert'] => $db->str($postfeld['lds_webservice_path']),
                    $sql_tabs['einstellungen']['modul'] => $db->str('lds_webservice_path')
                )
            );
        }
    }
    if (isset($postfeld['lds_log'])) {
        $res2=$db->select(
            $sql_tab['einstellungen'],
            $sql_tabs['einstellungen']['wert'],
            $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_log')
        );
        if ($row2=$db->zeile($res2)) {
            $db->update(
                $sql_tab['einstellungen'],
                array(
                    $sql_tabs['einstellungen']['wert'] => $db->str($postfeld['lds_log'])
                ),
                $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_log')
            );
        } else {
            $db->insert(
                $sql_tab['einstellungen'],
                array(
                    $sql_tabs['einstellungen']['wert'] => $db->str($postfeld['lds_log']),
                    $sql_tabs['einstellungen']['modul'] => $db->str('lds_log')
                )
            );
        }
    }

    if (isset($files['lds_server_certificate']) && $files['lds_server_certificate']['error']==0) {
        $doclink=name2filename($files['lds_server_certificate']['name']);
        // Nachsehen ob die Dateiendung auch erlaubt ist
        $dateiendung=p4n_mb_string('strtolower',p4n_mb_string('substr',$doclink,-4));
        if ($dateiendung != '.cer' && $dateiendung != '.crt') {
            echo '<div class="error_header">'._UNERLAUBTEDATEI_.'</div>';
            echo '<div class="error_text">'._UNERLAUBTEDATEI_.': '.$dateiendung.'. Server Certificate must be a cer or crt file.</div>';
        } else {
            if (file_exists($cfg_lds_cer)) {
                @unlink($cfg_lds_cer);
            }
            move_uploaded_file($files['lds_server_certificate']['tmp_name'], $cfg_lds_cer);
            $chm=0740;
            if ($cfg_unix_dateien!='') {
                $chm=octdec($cfg_unix_dateien);
            }
            @chmod($doclink, $chm);
            LDSAdditional::checkCertificates($cfg_lds_cer, $cfg_lds_p12);
        }
    }

    if (isset($files['lds_p12']) && $files['lds_p12']['error']==0) {
        $doclink=name2filename($files['lds_p12']['name']);
        // Nachsehen ob die Dateiendung auch erlaubt ist
        $dateiendung=p4n_mb_string('strtolower',p4n_mb_string('substr',$doclink,-3));
        if ($dateiendung != 'p12') {
            echo '<div class="error_header">'._UNERLAUBTEDATEI_.'</div>';
            echo '<div class="error_text">'._UNERLAUBTEDATEI_.': '.$dateiendung.'. Private Key must be a p12 file.</div>';
        } else {
            if (file_exists($cfg_lds_p12)) {
                @unlink($cfg_lds_p12);
            }
            move_uploaded_file($files['lds_p12']['tmp_name'], $cfg_lds_p12);
            $chm=0740;
            if ($cfg_unix_dateien!='') {
                $chm=octdec($cfg_unix_dateien);
            }
            @chmod($doclink, $chm);
            $p12 = file_get_contents($cfg_lds_p12);
            if (!openssl_pkcs12_read($p12, $key_store, '')) {
                $p12Info = '<span style="color:red">maybe password? </span>'.$form->textinput('lds_p12_passw');
            } else {
                LDSAdditional::checkCertificates($cfg_lds_cer, $cfg_lds_p12);
            }
            $db->delete(
                $sql_tab['einstellungen'],
                $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_p12_passw')
            );
        }
    }

    if (!empty($postfeld['lds_p12_passw'])) {
        if (file_exists($cfg_lds_p12)) {
            $p12 = file_get_contents($cfg_lds_p12);
            $passw = $postfeld['lds_p12_passw'];
            if (openssl_pkcs12_read($p12, $key_store, $passw)) {
                $res2=$db->select(
                    $sql_tab['einstellungen'],
                    $sql_tabs['einstellungen']['wert'],
                    $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_p12_passw')
                );
                if ($row2=$db->zeile($res2)) {
                    $db->update(
                        $sql_tab['einstellungen'],
                        array(
                            $sql_tabs['einstellungen']['wert'] => $db->str($passw)
                        ),
                        $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_p12_passw')
                    );
                } else {
                    $db->insert(
                        $sql_tab['einstellungen'],
                        array(
                            $sql_tabs['einstellungen']['wert'] => $db->str($passw),
                            $sql_tabs['einstellungen']['modul'] => $db->str('lds_p12_passw')
                        )
                    );
                }
                LDSAdditional::checkCertificates($cfg_lds_cer, array($cfg_lds_p12, $passw));
            } else {
                $p12Info = '<span style="color:red">wrong password? </span>' . $form->textinput('lds_p12_passw', $passw);
            }
        } else {
            $p12Info = '<span style="color:red">please add p12 cert.</span>';
        }
    }
    // griga 2016.06.20 MB NL -->
    if (isset($postfeld['mb_nl'])) {
        if (isset($files['mb_nl_private_key']) && $files['mb_nl_private_key']['error']==0) {
            $pkey = name2filename($files['mb_nl_private_key']['name']);
            $extension = p4n_mb_string('strtolower', p4n_mb_string('substr', $pkey, -3));
            if ($extension !== 'ppk') {
                echo '<div class="error_header">'._UNERLAUBTEDATEI_.'</div>';
                echo '<div class="error_text">'._UNERLAUBTEDATEI_.': '.$extension.'. Private key must be a ppk file.</div>';
            } else {
                $file = 'inc/services/MBNL/'.$pkey;
                if (file_exists($file)) {
                    @unlink($file);
                }
                move_uploaded_file($files['mb_nl_private_key']['tmp_name'], $file);
                $chm=0740;
                if ($cfg_unix_dateien != '') {
                    $chm = octdec($cfg_unix_dateien);
                }
                @chmod($file, $chm);
                $postfeld['mb_nl']['private_key'] = $file;
            }
        }

        $mbNlData = base64_encode(json_encode(array_map('utf8_encode',$postfeld['mb_nl'])));
        $res4=$db->select(
            $sql_tab['einstellungen'],
            $sql_tabs['einstellungen']['wert'],
            $sql_tabs['einstellungen']['modul'].'='.$db->str('mb_nl')
        );
        if ($row4=$db->zeile($res4)) {
            $mb_nl = json_decode(base64_decode($row4[0]), true);
            if (!isset($postfeld['mb_nl']['private_key']) && isset($mb_nl['private_key']) && is_file($mb_nl['private_key'])) {
                $postfeld['mb_nl']['private_key'] = $mb_nl['private_key'];
                $mbNlData = base64_encode(json_encode(array_map('utf8_encode',$postfeld['mb_nl'])));
            }
            $db->update(
                $sql_tab['einstellungen'],
                array(
                    $sql_tabs['einstellungen']['wert'] => $db->str($mbNlData)
                ),
                $sql_tabs['einstellungen']['modul'].'='.$db->str('mb_nl')
            );
        } else {
            $db->insert(
                $sql_tab['einstellungen'],
                array(
                    $sql_tabs['einstellungen']['modul'] => $db->str('mb_nl'),
                    $sql_tabs['einstellungen']['wert'] => $db->str($mbNlData)
                )
            );
        }

    }
    // --> griga 2016.06.20
    if (class_exists('Logger_File')) {
        $logger = new Logger_File('inc/'.$_SESSION['cfg_kunde'].'/crm_protocol.txt', true);
        $logger->info(p4n_mb_string('utf8_encode', _LEAD_.' '._EINSTELLUNGEN_.' '._WURDE_GEAENDERT_.' ('.$_SESSION['mitarbeiter_name'].' ('.$_SESSION['user_id'].') - einstellungen_kfz.php)'));
    }
}
$count = 0;
?>
<script>
    function openInWindow(id) {
        P4nBoxHelper.init({
            href: "#"+id,
            id: "locs_window",
            target: "body",
            width: "400px",
            height: "400px",
            autosize: true,
            type: "innerObj",
            beforeShow: function() {
                jq1112("#locs_window_inner").children("div").each(function(){
                    jq1112(this).find("input").attr("readonly", false);
                    jq1112(this).removeClass("left").show();
                });
            },
            beforeClose: function() {
                jq1112("#locs_window_inner").children("div").each(function(){
                    jq1112(this).addClass("left");
                    var $input = jq1112(this).find("input");
                    $input.attr("readonly", true);
                    if (!$input.val()) {
                        jq1112(this).hide();
                    }
                });
            },
            buttons: "<?= addslashes($form->submit2('',  '&nbsp;'._SPEICHERN_.'&nbsp;','onclick="P4nBoxHelper.close();"')) ?>",
        });
    }
    function openAndReload(id, href, width, height) {
        P4nBoxHelper.init({
            href: href,
            target: "body",
            id: id,
            width: width,
            height: height,
            single: true,
            type: "iframe",
            beforeClose: function() {
                top.tabs.TabHelper.reloadTab();
            }
        });
    }
    function searchInterface(text) {
        var regex = new RegExp(escapeHtml(text), "im");
        $(".heading").each(function() {
            var table = $(this).closest("table")
            var th = $(this).find("th");
            var title = th.html();
            if (title.match(regex)) {
                table.show();
            } else {
                table.hide();
            }
        });
    }
</script>
<?= $navi->getHtml() ?>
<?= $form->start('adminform', $phs, 'POST', true) ?>

<?php if (!empty($cfg_alles_auto)): ?>
    <?php
    $allesAuto = AllesAuto::getParams();
    $count++;
    ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" colspan="6">AllesAuto <?= _LEADS_?></th>
        </tr>
        <tr class="odd first-child">
            <th class="th"><?= 'Client ID' ?></th>
            <td class="td"><?= $form->textinput('alles_auto[client_id]', @$allesAuto['client_id']) ?></td>
            <th class="th"><?= 'Client Secret' ?></th>
            <td class="td"><?= $form->textinput('alles_auto[client_secret]', @$allesAuto['client_secret']) ?></td>
            <th class="th"><?= _LOGGING_ ?></th>
            <td class="td"><?= $form->hidden('alles_auto[logging]', 0).$form->checkinput('alles_auto[logging]', @$allesAuto['logging']) ?></td>
        </tr>
        <tr class="even">
            <th class="th"><?= _MASTERKAMPAGNE_ ?></th>
            <td class="td"><?= $form->selectinput('alles_auto[masterCampaign]', $campaignsList, @$allesAuto['masterCampaign'], _BITTE_WAEHLEN_) ?></td>
            <th class="th"><?= _LAGERORT_.' ('._ERSATZ_.')' ?></th>
            <td class="td"><?= $form->selectinput('alles_auto[locationDef]', $locationList, @$allesAuto['locationDef'], _BITTE_WAEHLEN_) ?></td>
            <th class="th"><?= _ZUORDNUNG_ ?></th>
            <td class="td"><?= $form->submit2('alles_auto_locations', _LAGERORTE_, 'onClick="P4nBoxHelper.iframe(\'alles_auto_locations\', \'einstellungen_kfz.php?view=alles_auto_locations\', false, 400, 400);"') ?></td>
        </tr>
    </table>
<?php endif; ?>

<?php if (!empty($cfg_autouncle)): ?>
    <?php
    $showNew = false;
    PearAutoLoader::instance()->addSourceRoot('inc/services');
    $autouncleList = AutoUncle::getParams();
    if (empty($autouncleList)) {
        $showNew = true;
    }
    $autouncleList['new'] = array();
    $count++;
    ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th">
                AutoUncle <?= _LEADS_ ?>
                <?php if (!$showNew): ?>
                    <?= $form->submit2('', '', 'onclick="jq1112(\'.autouncle_new\').show();jq1112(this).hide();" class="icon icon-plus icon-plus2"') ?>
                <?php endif; ?>
            </th>
        </tr>
        <tr class="odd">
            <td class="td">
                <?php foreach($autouncleList as $key => $autouncle): ?>
                    <table class="table-ignore2 moderntable" style="width:500px;float:left;margin:3px;">
                        <tr class="odd first-child<?= $key === 'new' ? ' autouncle_new"'.($showNew ? '' : ' style="display:none"') : ''?>">
                            <th class="th"><?= 'Token' ?></th>
                            <td class="td">
                                <?= $form->textinput('autouncle['.$key.'][token]', @$autouncle['token'], 35, 'style="width:175px"') ?>
                            </td>
                            <th class="th" title="only_with_trade_in_car=false"><?= _ALLE_.' '._LEADS_ ?></th>
                            <td class="td"><?= $form->hidden('autouncle['.$key.'][all_leads]', 0).$form->checkinput('autouncle['.$key.'][all_leads]', @$autouncle['all_leads']) ?></td>
                            <th class="th"><?= _LOGGING_ ?></th>
                            <td class="td"><?= $form->hidden('autouncle['.$key.'][logging]', 0).$form->checkinput('autouncle['.$key.'][logging]', @$autouncle['logging']) ?></td>
                        </tr>
                        <tr class="even<?= $key === 'new' ? ' autouncle_new"'.($showNew ? '' : ' style="display:none"') : ''?>">
                            <th class="th"><?= _LAGERORTE_ ?></th>
                            <td class="td" colspan="5">
                                <?php if ($key !== 'new'): ?>
                                    <?= $form->submit2('add_au_loc', _AENDERN_, 'onClick="openAndReload(\'autouncle_locations\', \'einstellungen_kfz.php?view=autouncle_locations&key='.$key.'\', 850, 400);"') ?>
                                    <?= 'Oder alle zu dem Lagerort: '.$form->selectinput('autouncle['.$key.'][location_def]', $alle_mand1, @$autouncle['location_def'], _BITTE_WAEHLEN_) ?>
                                    <?= link2('<img src="bilder/loesch.gif">', 'einstellungen_kfz.php?autouncle_delete='.$key, '', '', 'onClick="return confirm(\''._VORGANG_ABFRAGE_.'\');"') ?>
                                <?php else : ?>
                                    <?= _INAKTIV_ ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                <?php endforeach; ?>
            </td>
        </tr>
    </table>
<?php endif; ?>

<?php if (!empty($cfg_bmw_rsp)): ?>
    <?php
    try {
        $bmwRSP = BmwRSP::getParams(true);
        if ($bmwRSP === NULL) {
            throw new Exception('BMW RSP '._EINSTELLUNGEN_.' '._UNVOLLSTAENDIG_.' ('._EINSTELLUNGEN_.' > '._SCHNITTSTELLEN_.')<br>'._ADMINISTRATOR_WENDEN_);
        }
    } catch (Exception $e) {
        $bmwError = $e->getMessage();
    }
    $count++;
    ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" colspan="6">BMW RSP <?= _LEADS_ ?></th>
        </tr>
        <?php if (!empty($bmwError)): ?>
            <tr class="odd first-child">
                <td class="td" ><span style="color: red"><?= $bmwError ?></span></td>
            </tr>
        <?php else : ?>
            <tr class="odd first-child">
                <th class="th"><?= _MASTERKAMPAGNE_ ?></th>
                <td class="td"><?= $form->selectinput('bmw_rsp[masterCampaign]', $campaignsList, @$bmwRSP['masterCampaign'], _BITTE_WAEHLEN_) ?></td>
                <th class="th"><?= _LAGERORT_.' ('._ERSATZ_.')' ?></th>
                <td class="td"><?= $form->selectinput('bmw_rsp[locationDef]', $locationList, @$bmwRSP['locationDef'], _BITTE_WAEHLEN_) ?></td>
                <th class="th"><?= _ZUORDNUNG_ ?></th>
                <td class="td">
                    <?= $form->submit2('bmw_rsp_locations', _LAGERORTE_, 'onClick="P4nBoxHelper.iframe(\'bmw_rsp_locations\', \'einstellungen_kfz.php?view=bmw_rsp_locations\', false, 800, 600);"') ?>
                </td>
            </tr>
        <?php endif; ?>
    </table>
<?php endif; ?>

<?php if (!empty($cfg_clever_lead)): ?>
    <?php
    PearAutoLoader::instance()->addSourceRoot('inc/services');
    $cleverLead = CleverLead::getParams();
    $count++;
    $i = 0;
    ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" colspan="6">CleverLead</th>
        </tr>
        <tr class="odd first-child">
            <th class="th"><?= _URL_ ?></th>
            <td class="td"><?= $form->textinput('clever_lead[url]', $cleverLead['url'], 35) ?></td>
            <th class="th"><?= _IMPORT_DB_USER_ ?></th>
            <td class="td"><?= $form->textinput('clever_lead[username]', $cleverLead['username']) ?></td>
            <th class="th"><?= _IMPORT_DB_PW_ ?></th>
            <td class="td"><?= $form->textinput('clever_lead[password_new]').$form->hidden('clever_lead[password]', $cleverLead['password']).$passwHint ?></td>
        </tr>
        <tr class="even">
            <th class="th"><?= _LOGGING_ ?></th>
            <td class="td"><?= $form->hidden('clever_lead[logging]', 0).$form->checkinput('clever_lead[logging]', @$cleverLead['logging']) ?></td>
            <th class="th"><?= 'Client ID' ?></th>
            <td class="td"><?= $form->textinput('clever_lead[client_id]', $cleverLead['client_id']) ?></td>
            <th class="th"><?= 'Client Secret' ?></th>
            <td class="td"><?= $form->textinput('clever_lead[client_secret_new]').$form->hidden('clever_lead[client_secret]', $cleverLead['client_secret']).$passwHint ?></td>
        </tr>
        <tr class="odd">
            <th class="th"><?= _LAGERORTE_ ?></th>
            <td class="td" colspan="5">
                <div id="cl_locs" class="left">
                    <?php foreach($alle_mand1 as $id => $title):?>
                        <?php $value = @$cleverLead['locations'][$id]; ?>
                        <div class="left" style="padding-right: 10px;<?= ($value ? '' : 'display: none;') ?>">
                            <?= $form->textinput('clever_lead[locations]['.$id.']', $value, 10, 'readonly title="'._ID_.':'.$id.'"').'('.$title.')' ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?= $form->submit2('add_cl_loc', _HINZUFUEGEN_ . '/' . _AENDERN_, 'onClick="openInWindow(\'cl_locs\')"') ?>
            </td>
        </tr>
        <?php foreach(CleverLead::getMilestonesCategories() as $milestone => $list):?>
            <tr class="<?= $i++ % 2 ? 'odd' : 'even' ?>">
                <th class="th"><?= 'CL '._ERGEBNIS_ ?></th>
                <td class="td"><?= $milestone ?></td>
                <th class="th"><?= _ERGEBNIS_KATEGORIE_ ?></th>
                <td class="td"><?= $form->selectinput('clever_lead[milestones]['.$milestone.'][0]', $list[0], @$cleverLead['milestones'][$milestone][0]) ?></td>
                <th class="th"><?= _KATEGORIE_ ?></th>
                <td class="td"><?= $form->selectinput('clever_lead[milestones]['.$milestone.'][1]', $list[1], @$cleverLead['milestones'][$milestone][1]) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php endif; ?>

<?php if (!empty($cfg_facebook_leads)): ?>
    <?php
    PearAutoLoader::instance()->addSourceRoot('inc/services');
    $fb = Facebook::getParams();
    if (isset($postfeld['facebook_leads']['page_id']) && $postfeld['facebook_leads']['page_id'] === $fb['page_id']) {
        unset($fb['ok']);
    }
    $fbOk = @$fb['ok'];
    if (!empty($fb['page_id']) && !empty($fb['token']) && !$fbOk) {
        try {
            $facebook = new Facebook();
            $pageToken = $facebook->checkConnection($fb['page_id']);
            $fbOk = true;
        } catch (Exception $e) {
            $fbError = $e->getMessage();
        }
    }
    $count++;
    ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" colspan="4">Facebook <?= _LEADS_?></th>
        </tr>
        <tr class="odd first-child">
            <th class="th"><?= _SEITE_.' '._ID_ ?></th>
            <td class="td"><?= $form->textinput('facebook_leads[page_id]', @$fb['page_id']) ?></td>
            <th class="th"><?= _LOGGING_ ?></th>
            <td class="td">
                <?= $form->hidden('facebook_leads[logging]', 0).$form->checkinput('facebook_leads[logging]', @$fb['logging']) ?>
                <?php if (isset($fbError)): ?>
                    <span style="color: red"><?= $fbError ?></span>
                <?php endif; ?>
                <?php if (!empty($fb['token'])): ?>
                    <?= $form->submit2('facebook_locations', _LAGERORT_.'-'._ZUORDNUNG_, 'onClick="P4nBoxHelper.iframe(\'facebook_locations\', \'einstellungen_kfz.php?view=facebook_locations\', false, 800, 400);"') ?>
                    <?= $form->submit2('facebook_refresh_token', _UPDATE_TOKENS_, 'onClick="openAndReload(\'facebook_refresh_token\', \'api_facebook.php?action=refresh_token\', 600, 400);"') ?>
                    <?= 'Token '._KONTAKTENDE_.': '.date('Y.m.d', $fb['token']['expires_at']) ?>
                    <?= $form->hidden('facebook_leads[ok]', $fbOk) ?>
                <?php elseif (!empty($fb['page_id'])) : ?>
                    <?= $form->submit2('facebook_get_token', _RETRIEVE_TOKEN_, 'onClick="openAndReload(\'facebook_get_token\', \'api_facebook.php?action=new_token\', 600, 400);"') ?>
                <?php endif; ?>
            </td>
        </tr>
    </table>
<?php endif; ?>

<?php if (!empty($cfg_ferrari_leads)): ?>
    <?php
    $ferrariLeads = Ferrari::getAccessData();
    $count++;
    ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" colspan="6">Ferrari <?= _LEADS_?></th>
        </tr>
        <tr class="odd first-child">
            <th class="th"><?= _ADRESSE_ ?></th>
            <td class="td" colspan="3"><?= $form->textinput('ferrari_leads[url]', @$ferrariLeads['url'], 58, 'style="width:100%"') ?></td>
            <th class="th"><?= _LOGGING_ ?></th>
            <td class="td"><?= $form->hidden('ferrari_leads[logging]', 0).$form->checkinput('ferrari_leads[logging]', @$ferrariLeads['logging']) ?></td>
        </tr>
        <tr class="even">
            <th class="th"><?= _IMPORT_DB_USER_ ?></th>
            <td class="td"><?= $form->textinput('ferrari_leads[login]', @$ferrariLeads['login']) ?></td>
            <th class="th"><?= _IMPORT_DB_PW_ ?></th>
            <td class="td"><?= $form->textinput('ferrari_leads[password]', @$ferrariLeads['password']) ?></td>
            <th class="th"><?= _HAENDLERNUMMER_ ?></th>
            <td class="td"><?= $form->textinput('ferrari_leads[dealerId]', @$ferrariLeads['dealerId']) ?></td>
        </tr>
        <tr class="odd">
            <th class="th"><?= _LAGERORT_ ?></th>
            <td class="td"><?= $form->selectinput('ferrari_leads[location]', $locationList, @$ferrariLeads['location'], _BITTE_WAEHLEN_) ?></td>
            <th class="th"><?= _KAMPAGNE_ ?></th>
            <td class="td"><?= $form->selectinput('ferrari_leads[campaign]', $campaignsList, @$ferrariLeads['campaign'], _BITTE_WAEHLEN_) ?></td>
            <td class="td" colspan="4"></td>
        </tr>
    </table>
<?php endif; ?>

<?php if (!empty($cfg_ford_lds)): ?>
    <?php
    $lds_site_code = '';
    $lds_webservice_path = '';

    $result = $db->select(
        $sql_tab['einstellungen'],
        array(
            $sql_tabs['einstellungen']['wert'],
            $sql_tabs['einstellungen']['modul']
        ),
        $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_site_code').' or '.
        $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_webservice_path').' or '.
        $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_log').' or '.
        $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_p12_passw').' or '.
        $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_server_certificate_expired').' or '.
        $sql_tabs['einstellungen']['modul'].'='.$db->str('lds_p12_expired')
    );
    while ($row_lds = $db->zeile($result)) {
        $lds_data[$row_lds[1]] = $row_lds[0];
    }

    $pfad_p12_t = $cfg_lds_p12;
    if (!file_exists($cfg_lds_p12)) {
        $pfad_p12_t = '-';
    }
    $pfad_cer_t = $cfg_lds_cer;
    if (!file_exists($cfg_lds_cer)) {
        $pfad_cer_t = '-';
    }
    $lds_log = @$lds_data['lds_log'];
    require_once 'inc/lds_direkt.inc.php';;
    $logLink = $errorLink = '';
    if ($lds_log && defined('_WS_XML_DIR_')) {
        $logLink = '&nbsp;'.link2(_OEFFNEN_, _WS_XML_DIR_, null, null, 'target="_blank"');
    }
    $ldsErrorFile = 'log/lds_direkt.txt';
    if (is_file($ldsErrorFile) && $ldsErrors = file_get_contents($ldsErrorFile)) {
        $errorLink .= '&nbsp;/&nbsp;<span style=" background-color: #f2dede;color: #b94a48;" title="'.htmlspecialchars(substr($ldsErrors, -1000)).'">';
        $errorLink .= '&nbsp;'.link2(_FEHLER_.' '._PRUEFEN_, $ldsErrorFile, null, null, 'target="_blank"').'</span>';
    }
    if (!empty($lds_data['lds_server_certificate_expired'])) {
        $info_cer = ' | '._ABLAUF_.'-'._DATUM_.': '.date('d.m.Y', $lds_data['lds_server_certificate_expired']).' | ';
        if (intval($lds_data['lds_server_certificate_expired']) - time() < 5300000) {
            $info_cer = '<span style="color:red">'.$info_cer.'</span>';
        }
    }
    if (!empty($lds_data['lds_p12_expired'])) {
        $info_p12 = ' | '._ABLAUF_.'-'._DATUM_.': '.date('d.m.Y', $lds_data['lds_p12_expired']).' | ';
        if (intval($lds_data['lds_p12_expired']) - time() < 5300000) {
            $info_p12 = '<span style="color:red">'.$info_p12.'</span>';
        }
    }
    $p12Info = empty($p12Info) && !empty($lds_data['lds_p12_passw']) ? _MIT_.' '._BPASSWORT_ : $p12Info;
    $count++;
    ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" colspan="2">Ford LDS</th>
        </tr>
        <tr class="odd first-child">
            <th class="th">Webservice</th>
            <td class="td"><?= $form->textinput('lds_webservice_path', @$lds_data['lds_webservice_path'], 60) ?></td>
        </tr>
        <tr class="even">
            <th class="th">Sitecode</th>
            <td class="td"><?= getSiteCodesFields($form, @$lds_data['lds_site_code']) ?></td>
        </tr>
        <tr class="odd">
            <th class="th">Private Key</th>
            <td class="td" nowrap><?= @basename($pfad_p12_t).@$info_p12.$form->dateiinput('lds_p12', '', 50).@$p12Info ?></td>
        </tr>
        <tr class="even">
            <th class="th">Server Certificate</th>
            <td class="td" nowrap><?= @basename($pfad_cer_t).@$info_cer.$form->dateiinput('lds_server_certificate', '', 50) ?></td>
        </tr>
        <tr class="odd">
            <th class="th"><?= _LOGGING_ ?></th>
            <td class="td"><?= $form->hidden('lds_log', 0).$form->checkinput('lds_log', $lds_log).$logLink.$errorLink ?></td>
        </tr>
    </table>
<?php endif; ?>

<?php if (!empty($cfg_kia_leads)): ?>
    <?php
    $kiaLeads = KiaLeads::getParams();
    $count++;
    ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" colspan="6">Kia <?= _LEADS_ ?></th>
        </tr>
        <tr class="odd first-child">
            <th class="th"><?= _MASTERKAMPAGNE_ ?></th>
            <td class="td"><?= $form->selectinput('kia_leads[masterCampaign]', $campaignsList, @$kiaLeads['masterCampaign'], _BITTE_WAEHLEN_) ?></td>
            <th class="th"><?= _ZUORDNUNG_ ?></th>
            <td class="td" nowrap>
                <?= $form->submit2('kia_locations', _LAGERORTE_, 'onClick="P4nBoxHelper.iframe(\'kia_locations\', \'einstellungen_kfz.php?view=kia_locations\', false, 800, 600);"') ?>
                <?= $form->submit2('kia_users', _BENUTZER_, 'onClick="P4nBoxHelper.iframe(\'kia_users\', \'einstellungen_kfz.php?view=kia_users\', false, 800, 400);"') ?>
            </td>
            <th class="th"><?= _LOGGING_ ?></th>
            <td class="td"><?= $form->hidden('kia_leads[logging]', 0).$form->checkinput('kia_leads[logging]', @$kiaLeads['logging']) ?></td>
        </tr>
    </table>
<?php endif; ?>

<?php if (!empty($cfg_mb_nl)): ?>
    <?php
    $res4=$db->select(
        $sql_tab['einstellungen'],
        $sql_tabs['einstellungen']['wert'],
        $sql_tabs['einstellungen']['modul'].'='.$db->str('mb_nl')
    );
    if ($row4=$db->zeile($res4)) {
        $mb_nl = json_decode(base64_decode($row4[0]), true);
    }
    $pkey = @$mb_nl['private_key'];
    $extraInfo = '';
    if (is_file($pkey)) {
        $extraInfo = '<img src="bilder/hakengruen.gif" border=0 title="'.$pkey.'">';
    }
    $intervalsList = array('inactive' => _INAKTIV_, 'daily' => _TAEGLICH_, 'weekly' => _WOECHENTLICH_, 'monthly' => _MONATLICH_, 'yearly' => _TERMIN_S_Y_);
    $count++;
    ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" colspan="10">MB NL (FTP)</th>
        </tr>
        <tr class="odd first-child">
            <th class="th"><?= _ADRESSE_ ?></th>
            <td class="td"><?= $form->textinput('mb_nl[server]', @$mb_nl['server']) ?></td>
            <th class="th"><?= _PROTOKOLL_ ?></th>
            <td class="td"><?= $form->selectinput('mb_nl[protocol]', array('ftp' => 'FTP', 'sftp' => 'SFTP'), @$mb_nl['protocol']) ?></td>
            <th class="th"><?= _STANDORT_ ?></th>
            <td class="td"><?= $form->selectinput('mb_nl[location_id]', $alle_mand1, @$mb_nl['location_id']) ?></td>
        </tr>
        <tr class="even">
            <th class="th"><?= _IMPORT_DB_USER_ ?></th>
            <td class="td"><?= $form->textinput('mb_nl[username]', p4n_mb_string('utf8_decode', @$mb_nl['username'])) ?></td>
            <th class="th"><?= _IMPORT_DB_PW_ ?></th>
            <td class="td"><?= $form->textinput('mb_nl[password]', p4n_mb_string('utf8_decode', @$mb_nl['password'])) ?></td>
            <th class="th"><?= 'Private Key' ?></th>
            <td class="td" colspan="3"><?= $form->dateiinput('mb_nl_private_key', '', 50).$extraInfo ?></td>
        </tr>
        <tr class="odd">
            <th class="th"><?= _HAENDLERNUMMER_ ?></th>
            <td class="td"><?= $form->textinput('mb_nl[dealer_id]', p4n_mb_string('utf8_decode', @$mb_nl['dealer_id'])) ?></td>
            <th class="th"><?= _STARTDATUM_.' ('._EXPORT_.')' ?></th>
            <td class="td"><?= $form->datuminput('mb_nl[start_date]', @$mb_nl['start_date']) ?></td>
            <th class="th"><?= 'Interval ('._EXPORT_.')' ?></th>
            <td class="td"><?= $form->selectinput('mb_nl[intervall]', $intervalsList, @$mb_nl['intervall']) ?></td>
        </tr>
    </table>
<?php endif; ?>

<?php if (!empty($cfg_toyota_leads)): ?>
    <?php
    $toyotaCfg = new Settings_Data('TOYOTA_DEALERS', true);
    $dealerList = $toyotaCfg->getValue();
    $toyota = ToyotaLeads::getParams();
    //$toyota = array_merge($cfg_toyota_leads, $toyotaDB);
    $logging = isset($toyotaDB['logging']) ? $toyotaDB['logging'] : @$toyota['logging'];
    $count++;
    $tlInfo = 'URL: '.ToyotaLeads_Api::getUrl();
    ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" colspan="6">Toyota <?= _LEADS_.'&nbsp;'.oltext($tlInfo, '&nbsp;');?></th>
        </tr>
        <tr class="odd first-child">
            <th class="th"><?= 'Access key' ?></th>
            <td class="td"><?= $form->textinput('toyota_leads[accessKey]', @$toyota['accessKey'], '', ($_SESSION['user_id'] == 1 ? '' : 'readonly')) ?></td>
            <th class="th"><?= 'Secret key' ?></th>
            <td class="td"><?= $form->textinput('toyota_leads[secretKey]', @$toyota['secretKey'], '', ($_SESSION['user_id'] == 1 ? '' : 'readonly')) ?></td>
            <th class="th"><?= _LOGGING_ ?></th>
            <td class="td"><?= $form->hidden('toyota_leads[logging]', 0).$form->checkinput('toyota_leads[logging]', $logging) ?></td>
        </tr>
        <tr class="even">
            <th class="th"><?= _MASTERKAMPAGNE_ ?></th>
            <td class="td"><?= $form->selectinput('toyota_leads[masterCampaign]', $campaignsList, @$toyota['masterCampaign'], _BITTE_WAEHLEN_) ?></td>
            <th class="th"><?= _LAGERORT_.' ('._ERSATZ_.')' ?></th>
            <td class="td" colspan="3"><?= $form->selectinput('toyota_leads[locationDef]', $locationList, @$toyota['locationDef'], _BITTE_WAEHLEN_) ?></td>
        </tr>
        <tr class="odd">
            <th class="th"><?= $form->submit2('toyota_locs', _HAENDLER_, 'onClick="openAndReload(\'toyota_locs\', \'einstellungen.php?view=toyota_locations\', 600, 400);"') ?></th>
            <td class="td nav-stacked" colspan="5">
                <?php if (!empty($dealerList)): ?>
                    <?php foreach($dealerList as $dealerId => $locationId):?>
                        <span class="odd" style="padding: 8px 10px;float:left;margin:1px;border: 1px solid #b3b7ba;">
                            <?= $alle_mand1[$locationId].' ('.$locationId.') - '.$dealerId ?>
                        </span>
                    <?php endforeach; ?>
                <?php endif; ?>
            </td>
        </tr>
    </table>
<?php endif; ?>

<?php if (!empty($cfg_toyota_leads_at)): ?>
    <?php
    $toyotaAt = ToyotaLeadsAT::getParams();
    $count++;
    ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" colspan="6">Toyota AT <?= _LEADS_?></th>
        </tr>
        <tr class="odd first-child">
            <th class="th"><?= _BENUTZER_ ?></th>
            <td class="td"><?= $form->textinput('toyota_leads_at[username]', @$toyotaAt['username']) ?></td>
            <th class="th"><?= _PASSWORD_ ?></th>
            <td class="td"><?= $form->textinput('toyota_leads_at[password]', @$toyotaAt['password']) ?></td>
            <th class="th"><?= _ZUORDNUNG_ ?></th>
            <td class="td" nowrap>
                <?= $form->submit2('toy_at_locs', _LAGERORTE_, 'onClick="P4nBoxHelper.iframe(\'toy_at_locs\', \'einstellungen_kfz.php?view=toyota_at_locations\', false, 800, 600);"') ?>
            </td>
        </tr>
        <tr class="even">
            <th class="th"><?= _MASTERKAMPAGNE_ ?></th>
            <td class="td"><?= $form->selectinput('toyota_leads_at[masterCampaign]', $campaignsList, @$toyotaAt['masterCampaign'], _BITTE_WAEHLEN_) ?></td>
            <th class="th"><?= _LAGERORT_.' ('._ERSATZ_.')' ?></th>
            <td class="td"><?= $form->selectinput('toyota_leads_at[locationDef]', $locationList, @$toyotaAt['locationDef'], _BITTE_WAEHLEN_) ?></td>
            <th class="th"><?= _LOGGING_ ?></th>
            <td class="td"><?= $form->hidden('toyota_leads_at[logging]', 0).$form->checkinput('toyota_leads_at[logging]', @$toyotaAt['logging']) ?></td>
        </tr>
    </table>
<?php endif; ?>

<?php if (!empty($cfg_jassy) || !empty($cfg_jassy_conf)): ?>
    <?php
    $jassySettings = new Jassy_Settings($form, true);
    $count++;
    ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th">
                Web Jassy
                <?= link2(_BENUTZER_, 'javascript:void(0);', 'benutzer_gruppe.gif', '', 'onClick="P4nBoxHelper.iframe(\'jassyu_iframe\', \'web_jassy.php?view=users\', false, 750, 500);"') ?>
            </th>
        </tr>
        <tr class="odd first-child">
            <td><?= $jassySettings->getHtml() ?></td>
        </tr>
    </table>
<?php endif; ?>

<?php if (!empty($cfg_messengerpeople)):
if (!empty($cfg_messengerpeople_v2) && !empty(MessengerPeopleV2::MODULE_VERSION ) && MessengerPeopleV2::MODULE_VERSION >= 203) :
    $included_correct = true;
    require_once 'inc/Lead/views/mp_203_settings_page.php';
else :
    $error = $upgrade_version_MP = null;
    $count++;
    try {
        $messengerPeople = $MessengerPeople_class::getParams();
        if (!empty($cfg_messengerpeople_v2) && empty($messengerPeople['version'])) {
            // ask about import OLD settings to version 2 (if is correct settings for version 1)
            try {
                $messengerPeopleOld = MessengerPeople::checkParams();
            } catch (Exception $e) {
                $messengerPeopleOld = array();
            }
            if (count_p4n($messengerPeopleOld)) {
                //add hidden field for mark - upgrade version (will create new config & remove old)
                $upgrade_version_MP = true;
                if (!empty($messengerPeopleOld['telegram-UUID'])) {
                    $messengerPeopleOld['telegram-active'] = 1;
                }
                $messengerPeople = $messengerPeopleOld;
            }
        }
        if ( empty($messengerPeople['Client-ID']) || empty($messengerPeople['Client-Secret']) ) {
            $error = $MessengerPeople_class::CONFIG_MODULE .': '._KEINE_ZUGANGSDATEN_;
        }
        if ( empty($messengerPeople['waba-ID']) ) {
            $error =$MessengerPeople_class::CONFIG_MODULE .': '._FELD_LEEREN_. ' WhatsApp Business Account ID';
        }
        $mp_cat_name = $MessengerPeople_class::CONFIG_MODULE.' Bot';
        $mp_res = $db->select(
            $sql_tab['kategorie'],
            $sql_tabs['kategorie']['kategorie_id'],
            $sql_tabs['kategorie']['modul'].'='.$db->dbzahl(29).
            ' AND '.$sql_tabs['kategorie']['bezeichnung'].'='.$db->str($mp_cat_name)
        );

        if ($mp_row = $db->zeile($mp_res)) {
            $mp_category_id = $mp_row[0];
            // setup MP 'survey bot' module - add category if not exist
        } else {
            $db->insert(
                $sql_tab['kategorie'],
                array(
                    $sql_tabs['kategorie']['modul'] => $db->dbzahl(29),
                    $sql_tabs['kategorie']['bezeichnung'] => $db->str($mp_cat_name)
                )
            );
            $mp_category_id = $db->insertid();
        }
        $mp_res = $db->select(
            $sql_tab['kategorie'].' INNER JOIN '.$sql_tab['telefonleitfaden'] .
            ' ON '.$sql_tabs['telefonleitfaden']['kategorie'].'='.$sql_tabs['kategorie']['bezeichnung'],
            array(
                $sql_tabs['telefonleitfaden']['telefonleitfaden_id'],
                $sql_tabs['telefonleitfaden']['bezeichnung'],
            ),
            $sql_tabs['kategorie']['modul'].'='.$db->dbzahl(29).
            ' AND '.$sql_tabs['kategorie']['kategorie_id'].'='.$db->dbzahl($mp_category_id),
            $sql_tabs['kategorie']['bezeichnung'].' ASC'
        );
        $mp_bots = array();
        while ($mp_row = $db->zeile($mp_res)) {
            $mp_bots[$mp_row[0]] = $mp_row[1];
        }
    } catch (Exception $e){
        $messengerPeople = array();
        $error = $MessengerPeople_class::CONFIG_MODULE.': '._KEINE_ZUGANGSDATEN_;
    }
    $i = 1;
    function classTr($s) {
        return $s % 2 ? 'even' : 'odd';
    }
    $dateParse = new MessengerPeople_Date();
    $schedule = $dateParse->getBranchesSchedule($locationList);
    // if (class_exists('Logger_File')) {
    //     $logger = new Logger_File($cfg_basedir.'log/getBranchesSchedule.txt', false);
    //     $logger->info(print_r($schedule, true));
    // }
    $schedule_listing = '';
    $schedule_active = array();
    $schedule_listings = array();
    foreach ($schedule as $bid => $items) {
        $schedule_active[$bid] = false;
        $tmp = '<div id="schd_'.$bid.'" class="schedule-listing"><u>'._OEFFUNGSZEITEN_.'</u>';
        if ($items[1]['activ']) {
            for ($d = 1; $d <= 7; $d++) {
                if ($items[$d]['start'] === false || $items[$d]['end'] === false || ($items[$d]['start'] === '00:00:00' && $items[$d]['end'] === '00:00:00' )) {
                    $tmp .= '<br><b style="display: inline-block; width: 25px">'.$items[$d]['day_short'].'</b> - - - - - - &nbsp;&nbsp;&nbsp; - - - - - -';
                } else {
                    $tmp .= '<br><b style="display: inline-block; width: 25px">'.$items[$d]['day_short'].'</b> '.$items[$d]['start'].' - '.$items[$d]['end'];
                    $schedule_active[$bid] = true;
                }
            }
        } else {
            $tmp .= '<br><span style="color:red">'. _INAKTIV_.'</span>';
        }
        $tmp .= '</div>';
        $schedule_listings[$bid] = $tmp;
    }
    $schedule_listing = implode('', $schedule_listings);
    ?>
<style>
    #whatsapp-table input[type="text"], #telegram-table input[type="text"] {width: 260px}
    #whatsapp-table .btn-danger, #telegram-table .btn-danger {color: #f9d6d6}
    #whatsapp-table button, #telegram-table button, #whatsapp-table input.btn-blue  {padding: 4px 10px}
    #whatsapp-table th > input[type="button"], #telegram-table th > input[type="button"] {vertical-align: top;}
    span#span-use-personal {padding-left: 50px}
    span#span-use-default {padding-left: 10px}
    span.deactive-text {color:lightgrey; font-style: italic;font-stretch: normal}
    span.active-text {color:lightgreen; font-style: italic;font-stretch: normal}
    <?php if (!empty($cfg_messengerpeople_v2)) :?>
        .schedule-listing {float:right; padding: 0px 5px 0px 5px}
        .error-bot-validation {color: lightcoral}
        .warning-bot-validation {color: yellow}
    <?php endif;?>
</style>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" colspan="6">
                <?= MessengerPeople::CONFIG_MODULE ?>
                <?php if ($_SESSION['user_id'] == 1): ?>
                    <?= ' / '.link2(_FEHLER_, 'log/'.$MessengerPeople_class.'_socket.txt?ts='.time(), '', '', 'target="_blank"') ?>
                <?php endif; ?>
                <?php if (!empty($cfg_messengerpeople_v2)) :?>
                    <div style="float:right;"><i>MP V.<?= MessengerPeopleV2::versionToString() ?></i><?= (!empty($messengerPeople['version']) && intval($messengerPeople['version']) !== MessengerPeopleV2::MODULE_VERSION)  ? ' / <i style="color:red">CFG V.'.MessengerPeopleV2::versionToString($messengerPeople['version']).'</i>' : '' ?></div>
                    <?= $form->hidden($mp_field_name.'[version]', MessengerPeopleV2::MODULE_VERSION )?>
                <?php endif; ?>
            </th>
        </tr>

        <?php if (!empty($cfg_messengerpeople_v2) && !empty(MessengerPeopleV2::MODULE_VERSION) && MessengerPeopleV2::MODULE_VERSION === 202 &&
            !empty($messengerPeople['version']) && intval($messengerPeople['version']) !== MessengerPeopleV2::MODULE_VERSION): ?>
            <!-- Attention, the code has been updated to version 2.02. You must also switch the CFG from version 2.01 to
            version 2.02. All parameters and options must be saved again to work correctly -->
            <tr class="<?= classTr($i++) ?>">
                <th class="td" style="color:#c40202;background-color: #eee9c5" colspan="6">Achtung, der Code wurde auf
                    Version 2.02 aktualisiert. Sie m�ssen auch das CFG von Version 2.01 auf Version 2.02 �ndern.<br>
                    Alle Einstellungen und Optionen m�ssen f�r den korrekten Betrieb �berpr�ft und neu gespeichert
                    werden. ( Allgemeine Standardeinstellungen, Whatsapp-buttons und Kanaleinstellungen usw.)
                </th>
            </tr>
        <?php endif; ?>
        <?php if ($error): ?>
            <tr class="<?= classTr($i++) ?>">
                <th class="td" style="color:red" colspan="6"><?= $error ?></th>
            </tr>
        <?php endif; ?>
        <?php if ($mp_post_error): ?>
            <tr class="<?= classTr($i++) ?>">
                <th class="td" style="color:red" colspan="6">Not saved: <?= $mp_post_error ?></th>
            </tr>
        <?php endif; ?>
        <?php if (!empty($upgrade_version_MP)) : ?>
            <!-- block when upgrade v1->v2.x -->
            <tr class="<?= classTr($i++) ?>">
                <th class="td" style="background-color: #ededd1; padding: 10px;" colspan="6"><b style="color:red;">Attention!</b><br>
                    The $cfg_messengerpeople_v2 option is enabled in the config, which activates the 2nd version of
                    the "MessengerPeople" module.<br> To migrate to the new version, check the settings and click "<?=_SUBMIT_STAMMDATEN_?>"<br>
                    If you don't want to upgrade to the new version - set $cfg_messengerpeople_v2 = false - after which this message
                    will no longer appear.<br> Please note that the downgrade from version 2 to version 1 is not possible.
                    <br><br>
                    Very important: LeadID foreign keys will be automatically converted to the new format, which is not backwards compatible with the old version.
                    <br><b>For correct conversion of records, the websocket server must be stopped.
                        In browsers, all chat windows of the MessengerPeople must be closed.</b>
                    <br><br><b>Before clicking the "<?=_SUBMIT_STAMMDATEN_?>" button, make sure that the requirements are met.</b>

                    <?= $form->hidden($mp_field_name.'[upgrade_version_MP]', '1', 'id="field-upgrade_version_MP"')?><br>
                </th>
            </tr>
        <?php endif; ?>
        <!-- block v1 + v2.x -->
        <tr class="<?= classTr($i++) ?> first-child">
            <th class="th">Client-ID</th>
            <td class="td"><?= $form->textinput($mp_field_name.'[Client-ID]', @$messengerPeople['Client-ID'], 45) ?></td>
            <th class="th">Client-Secret</th>
            <td class="td"><?= $form->textinput($mp_field_name.'[Client-Secret]', @$messengerPeople['Client-Secret'], 45) ?></td>
            <th class="th">WhatsApp Business Account ID</th>
            <td class="td"><?= $form->textinput($mp_field_name.'[waba-ID]', @$messengerPeople['waba-ID'], 45) ?></td>
        </tr>
        <?php if (!empty($cfg_messengerpeople_v2)) :?>
            <!-- block v2-->
            <?php $bot_active = false; ?>
            <tr class="<?= classTr($i++) ?>">
                <th class="th"><?= 'Haupt-'._BSPRACHE_ ?></th>
                <td class="td"><?= $form->selectinput($mp_field_name.'[language]', MessengerPeople_Language::getLangArrayFiles(), @$messengerPeople['language']) ?></td>
                <th class="th"><?= _LOGGING_ ?></th>
                <td class="td" colspan="3"><?= $form->checkinput($mp_field_name.'[logging]', @$messengerPeople['logging']) ?></td>
            </tr>
            <tr class="<?= classTr($i++) ?>">
                <th class="th" colspan="6">Telegram <?= _KANAL_ ?>
                    <span style="display:inline-block; padding:3px 30px" id="mp-telegram-active-label">
                        <b><?= ((!empty($messengerPeople['telegram-active']) && intval($messengerPeople['telegram-active']) === 1) ? _AKTIV_ : _INAKTIV_) ?></b> &nbsp;
                        <?= $form->checkinput($mp_field_name.'[telegram-active]', @$messengerPeople['telegram-active'],'id="mp-checkbox-telegram-active"') ?>
                        <span id="message-telegram-validatation" style="display:inline-block; padding:3px 30px"></span>
                    </span>
                </th>
            </tr>
            <tr id="telegram-table-wrapper" style="display:<?=((!empty($messengerPeople['mp-telegram-active']) && intval($messengerPeople['mp-telegram-active']) === 1) ? 'block' : 'none')?>">
                <td colspan="6" style="padding: 0; margin: 0">
                    <table class="table-ignore2 moderntable table-lasttd-w100" id="telegram-table">
                        <tr class="<?= classTr($i++) ?> showed">
                            <th class="th t-counter" style="width: 50px">#</th>
                            <th class="th" style="width: 250px"><?= _KANAL_?> UUID</th>
                            <th class="th" style="width: 250px"><?= _KNTO_ ?></th>
                            <th class="th" style="width: 200px"><?= _KANAL_.' '._BSPRACHE_ ?></th>
                            <th class="th" style="width: 200px"><?= _LAGERORTE_ ?></th>
                            <th class="th">&nbsp;</th>
                        </tr>
                        <?php $t = 0; ?>
                        <?php if (!empty($upgrade_version_MP)  || count_p4n($messengerPeople['telegram']) === 0) : ?>
                            <tr class="<?= classTr($i++) ?> showed">
                                <th class="th"><p><?= ($t+1) ?></p></th>
                                <td class="td"><?= $form->textinput($mp_field_name.'[telegram-UUID][]', @$messengerPeople['telegram-UUID'], 45, ' id="telegram-uuid-'.$t.'"') ?></td>
                                <td class="td"><?= $form->textinput($mp_field_name.'[telegram-recipient][]', @$messengerPeople['telegram-recipient'], 45, ' id="telegram-recipient-'.$t.'"') ?></td>
                                <td class="td"><?= $form->selectinput($mp_field_name.'[telegram-language][]', MessengerPeople_Language::getLangArrayFiles()) ?></td>
                                <td class="td"><?= $form->selectinput($mp_field_name.'[telegram-location][]', $locationList, '-1', _BITTE_WAEHLEN_, 'id="telegram-channel-location-'.$t.'"') ?></td>
                                <th class="td"></th>
                            </tr>
                            <?php $t++; ?>
                        <?php else : ?>
                            <?php foreach ($messengerPeople['telegram'] as $recipient => $options): ?>
                                <tr class="<?= classTr($i++) ?>" id="t-record-<?= $t ?>">
                                    <th class="th"><p><?= ($t+1) ?></p></th>
                                    <td class="td">
                                        <?php if (!empty($options['uuid'])) :?>
                                            <?= $form->textinput('ignore[telegram-UUID][]', $options['uuid'], 45, 'disabled="disabled"  id="telegram-uuid-'.$t.'"') ?>
                                            <?= $form->hidden($mp_field_name.'[telegram-UUID][]', $options['uuid']) ?>
                                        <?php else: ?>
                                            <?= $form->textinput($mp_field_name.'[telegram-UUID][]', $options['uuid'], 45, ' id="telegram-uuid-'.$t.'"') ?>
                                        <?php endif; ?>
                                    </td>
                                    <td class="td">
                                        <?php if (!empty($recipient)) :?>
                                            <?= $form->textinput('ignore[telegram-recipient][]', $recipient, 45, 'disabled="disabled" id="telegram-recipient-'.$t.'"') ?>
                                            <?= $form->hidden($mp_field_name.'[telegram-recipient][]', $recipient) ?>
                                        <?php else: ?>
                                            <?= $form->textinput($mp_field_name.'[telegram-recipient][]', $recipient, 45, ' id="telegram-recipient-'.$t.'"') ?>
                                        <?php endif; ?>
                                    </td>
                                    <td class="td"><?= $form->selectinput($mp_field_name.'[telegram-language][]', MessengerPeople_Language::getLangArrayFiles(), $options['language']) ?></td>
                                    <td class="td"><?= $form->selectinput($mp_field_name.'[telegram-location][]', $locationList, $options['location'], _BITTE_WAEHLEN_, 'id="telegram-channel-location-'.$t.'" class="channel-location" data-i='.$t.' data-messenger="telegram"') ?></td>
                                    <th class="td">
                                        <?php if (!empty($recipient)) :?>
                                            <span style="display:inline-block; padding:3px 30px 5px 3px" id="telegram-bot-on-label-<?=$t?>">
                                            <?php if (!empty($options['bot-on']) && $options['bot-on'] === '1'): ?>
                                                <b class="bot-status-label" style="color: green">Bot <?= _AKTIV_ ?></b>
                                                <?php $bot_active = true; ?>
                                            <?php else: ?>
                                                <b class="bot-status-label" style="color: red">Bot <?= _INAKTIV_ ?></b>
                                            <?php endif; ?>
                                                <?= $form->checkinput($mp_field_name.'[telegram-bot-on]['.$t.']', $options['bot-on'], 'class="channel-bot-on"  data-i='.$t.' data-messenger="telegram" id="telegram-channel-bot-on-'.$t.'"') ?>
                                                <span id="telegram-schedule-location-<?= $t ?>"><?= $schedule_listings[$options['location']] ?></span>
                                            </span>
                                        <?php endif; ?>
                                    </th>
                                </tr>
                                <?php $t++; ?>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </table>
                </td>
            </tr>
            <tr class="<?= classTr($i++) ?>">
                <th class="th" colspan="6">WhatsApp <?= _KANAL_ ?>
                    <span style="margin-left: 5px; padding: 2px 9px; color: white; background: #0C70B7; border: 1px solid grey" id="addBtn"  class="btn-blue"> + </span>
                </th>
            </tr>
            <tr>
                <td colspan="6" style="padding: 0; margin: 0">
                    <table class="table-ignore2 moderntable table-lasttd-w100" id="whatsapp-table">
                        <tr class="<?= classTr($i++) ?> showed">
                            <th class="th" style="width: 50px">#</th>
                            <th class="th" style="width: 250px"><?= _KANAL_?> UUID</th>
                            <th class="th" style="width: 250px"><?= _KNTO_ ?></th>
                            <th class="th" style="width: 200px"><?= _KANAL_.' '._BSPRACHE_ ?></th>
                            <th class="th" style="width: 200px"><?= _LAGERORTE_ ?></th>
                            <th class="th"><?= _AKTION_ ?></th>
                        </tr>
                        <?php $z = 0; ?>
                        <?php if (!empty($upgrade_version_MP)  || count_p4n($messengerPeople['whatsapp']) === 0) : ?>
                            <tr class="<?= classTr($i++) ?> showed">
                                <th class="th" style="width: 50px"><p><?= $z+1 ?></p></th>
                                <td class="td"><?= $form->textinput($mp_field_name.'[whatsapp-UUID][]', @$messengerPeople['whatsapp-UUID'], 45, ' id="whatsapp-uuid-'.$z.'"') ?></td>
                                <td class="td"><?= $form->textinput($mp_field_name.'[whatsapp-recipient][]', @$messengerPeople['whatsapp-recipient'], 45, ' id="whatsapp-recipient-'.$z.'"') ?></td>
                                <td class="td"><?= $form->selectinput($mp_field_name.'[whatsapp-language][]', MessengerPeople_Language::getLangArrayFiles()) ?></td>
                                <td class="td"><?= $form->selectinput($mp_field_name.'[whatsapp-location][]', $locationList, '-1', _BITTE_WAEHLEN_, 'id="whatsapp-channel-location-'.$z.'"') ?></td>
                                <th class="td"></th>
                            </tr>
                            <?php $z++; ?>
                        <?php else : ?>
                            <?php foreach ($messengerPeople['whatsapp'] as $recipient => $options): ?>
                                <tr class="<?= classTr($i++) ?>" id="whatsapp-record-<?= $z ?>" data-id="<?= $z ?>">
                                    <th class="th whatsapp-counter"><p><?= $z+1 ?></p></th>
                                    <td class="td">
                                        <?php if (!empty($options['uuid'])): ?>
                                            <?= $form->textinput('ignore[whatsapp-UUID][]', $options['uuid'], 45, 'disabled="disabled"  id="whatsapp-uuid-'.$t.'"') ?>
                                            <?= $form->hidden($mp_field_name.'[whatsapp-UUID][]', $options['uuid']) ?>
                                        <?php else: ?>
                                            <?= $form->textinput($mp_field_name.'[whatsapp-UUID][]', $options['uuid'], 45, ' id="whatsapp-uuid-'.$t.'"') ?>
                                        <?php endif; ?>
                                    </td>
                                    <td class="td">
                                        <?php if (!empty($recipient)): ?>
                                            <?= $form->textinput('ignore[whatsapp-recipient][]', $recipient, 45, 'disabled="disabled" id="whatsapp-recipient-'.$t.'"') ?>
                                            <?= $form->hidden($mp_field_name.'[whatsapp-recipient][]', $recipient) ?>
                                        <?php else: ?>
                                            <?= $form->textinput($mp_field_name.'[whatsapp-recipient][]', $recipient, 45, ' id="whatsapp-recipient-'.$t.'"') ?>
                                        <?php endif; ?>
                                    </td>
                                    <td class="td"><?= $form->selectinput($mp_field_name.'[whatsapp-language][]', MessengerPeople_Language::getLangArrayFiles(), $options['language']) ?></td>
                                    <td class="td"><?= $form->selectinput($mp_field_name.'[whatsapp-location][]', $locationList, $options['location'], _BITTE_WAEHLEN_, 'id="whatsapp-channel-location-'.$z.'" class="channel-location" data-i='.$z.' data-messenger="whatsapp"') ?></td>
                                    <th class="td">
                                        <?php if (!empty($recipient)) :?>
                                            <span style="display:inline-block; padding:3px;" id="whatsapp-bot-on-label-<?=$z?>">
                                                <?php if (!empty($options['bot-on']) && $options['bot-on'] === '1'): ?>
                                                    <b class="bot-status-label" style="color: green">Bot <?= _AKTIV_ ?></b>
                                                    <?php $bot_active = true; ?>
                                                <?php else: ?>
                                                    <b class="bot-status-label" style="color: red">Bot <?= _INAKTIV_ ?></b>
                                                <?php endif; ?>
                                                <?= $form->checkinput($mp_field_name.'[whatsapp-bot-on]['.$z.']', $options['bot-on'], 'class="channel-bot-on"  data-i='.$z.' data-messenger="whatsapp" id="whatsapp-channel-bot-on-'.$z.'"') ?>
                                                <span id="whatsapp-schedule-location-<?=$z?>"><?= $schedule_listings[$options['location']] ?></span>
                                            </span>
                                        <?= $form->submit2('whatsapp-lead-buttons', 'Whatsapp Buttons und Kanaleinstellungen', ' class="whatsapp-butons" onClick="P4nBoxHelper.iframe(\'whatsapp_lead_buttons_frame\', \'einstellungen_kfz.php?recipient='.$recipient.'&view=_part_messengerpeopleV2_buttons\', false, \'100%\', \'100%\');"') ?>
                                        <?php endif; ?>
                                        <?= ($z > 0 ? '<button class="btn btn-danger remove" type="button">Remove</button>' : '')?>
                                    </th>
                                </tr>
                                <?php $z++; ?>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </table>
                </td>
            </tr>
            <tr class="<?= classTr($i++) ?>">
                <th class="th"><?= _EINSTELLUNGEN_ ?></th>
                <td class="td" colspan="5">
                    <?php if (count_p4n($messengerPeople['whatsapp']) && !empty(array_keys($messengerPeople['whatsapp'])[0])) : ?>
                        <!-- General preset and default button -->
                        <?php $mp_def_url = 'einstellungen_kfz.php?recipient='.array_keys($messengerPeople['whatsapp'])[0].(!empty($messengerPeople['preset']['default']['id']) ? '&id='.$messengerPeople['preset']['default']['id'].'&action=edit-default' : '&action=setup-default').'&view=_part_messengerpeopleV2_default'; ?>
                        <?= $form->submit2('whatsapp-default-lead-buttons', 'Allgemeine Standardeinstellungen und Button', 'style="padding: 2px 10px;" onClick="P4nBoxHelper.iframe(\'whatsapp_lead_buttons_frame\', \''.$mp_def_url.'\', false, \'100%\', \'100%\');"') ?>
                    <?php endif; ?>
                    <?= $form->submit2('auto-answer-phrases', _TEXTE_.' '._OHNE_.' Bot', 'class="bot-disabled" style="margin-left: 5px; padding: 2px 10px;" onClick="P4nBoxHelper.iframe(\'auto_answer_phrases_frame\', \'einstellungen_kfz.php?view=_part_messengerpeople_phrases&part=2\', false, \'100%\', \'100%\');"') ?>
                    <?= $form->submit2('setup-templates', 'WhatsApp '._LEITFADEN_VORLAGE_.' for re-open 24 hours window', 'style="margin-left: 5px; padding: 2px 10px" onClick="P4nBoxHelper.iframe(\'setup_templates_frame\', \'einstellungen_kfz.php?view=_part_messengerpeople_setup_templates\', false, \'100%\', \'100%\');"') ?>
                </td>
            </tr>
            <tr class="<?= classTr($i++) ?>">
                <th class="th" colspan="6">Bot <?= _EINSTELLUNGEN_ ?> <span style="display:inline-block; padding:3px 30px" id="mp-bot-active-label">
                    <b><?= $bot_active ? _AKTIV_ : _INAKTIV_ ?></b> &nbsp;
                    <span id="message-bot-validatation" style="display:inline-block; padding:3px 30px"></span>
                </span></th>
            </tr>
            <tr class="<?= classTr($i++) ?> bot">
                <th class="th"><?= _LEITFADEN_ .' ('. _ARBEITSZEIT_ .')'?></th>
                <td class="td">
                    <?php if (count_p4n($mp_bots) > 0): ?>
                        <?= $form->selectinput($mp_field_name.'[bot-id]', $mp_bots, @$messengerPeople['bot-id'], _BITTE_WAEHLEN_, 'id="bot-id" ') ?>
                    <?php else: ?>
                        <a href="admin_telefonreport.php?tkat=<?= urlencode($mp_cat_name) ?>&datum_von=&datum_bis=&allelf=-1&submit=OK" target="" onclick="topmain.P4nBoxHelper.startloading();"><?= _ADD_NEW_ ?></a>
                    <?php endif; ?>
                </td>
                <th class="th"><?= _LEITFADEN_.' ('. _ANG_KURZ_.' '._STUNDEN_.')'?></th>
                <td class="td">
                    <?php if (count_p4n($mp_bots) > 0): ?>
                        <?= $form->selectinput($mp_field_name.'[bot-id-offhours]', $mp_bots, @$messengerPeople['bot-id-offhours'], _BITTE_WAEHLEN_, 'id="bot-id-offhours" ') ?>
                    <?php endif; ?>
                    <?php if (count_p4n($mp_bots) < 2): ?>
                        <a href="admin_telefonreport.php?tkat=<?= urlencode($mp_cat_name) ?>&datum_von=&datum_bis=&allelf=-1&submit=OK" target="" onclick="topmain.P4nBoxHelper.startloading();"><?= _ADD_NEW_ ?></a>
                    <?php endif; ?>
                </td>
                <th class="th"><?= p4n_mb_string('ucfirst',(_TEXTE_)).' '._MIT_.' Bot' ?></th>
                <td class="td" <?= (!empty($cfg_messengerpeople_v2) ? 'colspan="5"' : '') ?>>
                    <?= $form->submit2('bot-phrases', _TEXTVORLAGEN_, 'class="bot-enabled" style="margin-left: 5px; padding: 2px 10px;" onClick="P4nBoxHelper.iframe(\'bot_phrases_frame\', \'einstellungen_kfz.php?view=_part_messengerpeople_phrases&part=1\', false, \'100%\', \'100%\');"') ?>
                </td>
            </tr>
            <!-- end block v2-->
        <?php else : ?>
            <!-- block for v1 -->
            <tr class="<?= classTr($i++) ?>">
                <th class="th">WhatsApp <?= _KANAL_ ?> UUID</th>
                <td class="td"><?= $form->textinput('messengerPeople[whatsapp-UUID]', @$messengerPeople['whatsapp-UUID'], 45) ?></td>
                <th class="th">Telegram <?= _KANAL_ ?> UUID</th>
                <td class="td"><?= $form->textinput('messengerPeople[telegram-UUID]', @$messengerPeople['telegram-UUID'], 45) ?></td>
                <th class="th"><?= _BSPRACHE_ ?></th>
                <td class="td"><?= $form->selectinput('messengerPeople[language]', MessengerPeople_Language::getLangArrayFiles(), @$messengerPeople['language']) ?></td>
            </tr>
            <tr class="<?= classTr($i++) ?>">
                <th class="th">WhatsApp <?= _KNTO_ ?></th>
                <td class="td"><?= $form->textinput('messengerPeople[whatsapp-recipient]', @$messengerPeople['whatsapp-recipient'], 45) ?></td>
                <th class="th"><?= _LOGGING_ ?></th>
                <td class="td" colspan="3"><?= $form->checkinput('messengerPeople[logging]', @$messengerPeople['logging']) ?></td>
            </tr>
            <tr class="<?= classTr($i++) ?>">
                <th class="th"><?= _EINSTELLUNGEN_ ?></th>
                <td class="td" colspan="5">
                    <?= $form->submit2('whatsapp-lead-buttons', 'Whatsapp Buttons', 'style="padding: 2px 10px" onClick="P4nBoxHelper.iframe(\'whatsapp_lead_buttons_frame\', \'einstellungen_kfz.php?view=_part_messengerpeople_buttons\', false, \'100%\', \'100%\');"') ?>
                    <?= $form->submit2('auto-answer-phrases', _TEXTE_.' '._OHNE_.' Bot', 'class="bot-disabled" style="margin-left: 5px; padding: 2px 10px;" onClick="P4nBoxHelper.iframe(\'auto_answer_phrases_frame\', \'einstellungen_kfz.php?view=_part_messengerpeople_phrases&part=2\', false, \'100%\', \'100%\');"') ?>
                    <?= $form->submit2('setup-templates', 'WhatsApp '._LEITFADEN_VORLAGE_.' for re-open 24 hours window', 'style="margin-left: 5px; padding: 2px 10px" onClick="P4nBoxHelper.iframe(\'setup_templates_frame\', \'einstellungen_kfz.php?view=_part_messengerpeople_setup_templates\', false, \'100%\', \'100%\');"') ?>
                </td>
            </tr>
            <tr class="<?= classTr($i++) ?>">
                <th class="th" colspan="6">Bot <?= _EINSTELLUNGEN_ ?> <span style="display:inline-block; padding:3px 30px" id="mp-bot-active-label">
                    <b><?= _AKTIV_ ?></b> &nbsp; <?= $form->checkinput($mp_field_name.'[bot-active]', @$messengerPeople['bot-active'], 'id="mp-bot-active"') ?>
                    <span id="message-bot-validatation" style="display:inline-block; padding:3px 30px"></span>
                </span></th>
            </tr>
            <tr class="<?= classTr($i++) ?> bot">
                <th class="th"><?= _LAGERORTE_ ?></th>
                <td class="td"><?= $form->selectinput($mp_field_name.'[location]', $locationList, @$messengerPeople['location'], _BITTE_WAEHLEN_, 'id="bot-openhours-location"') ?></td>
                <td class="td" rowspan="4" colspan="4">
                    <?= $schedule_listing ?>
                </td>
            </tr>
            <tr class="<?= classTr($i++) ?> bot">
                <th class="th"><?= _LEITFADEN_ .' ('. _ARBEITSZEIT_ .')'?></th>
                <td class="td">
                    <?php if (count_p4n($mp_bots) > 0): ?>
                        <?= $form->selectinput($mp_field_name.'[bot-id]', $mp_bots, @$messengerPeople['bot-id'], _BITTE_WAEHLEN_, 'id="bot-id" ') ?>
                    <?php else: ?>
                        <a href="admin_telefonreport.php?tkat=<?= urlencode($mp_cat_name) ?>&datum_von=&datum_bis=&allelf=-1&submit=OK" target="" onclick="topmain.P4nBoxHelper.startloading();"><?= _ADD_NEW_ ?></a>
                    <?php endif; ?>
                </td>
            </tr>
            <tr class="<?= classTr($i++) ?> bot">
                <th class="th"><?= _LEITFADEN_.' ('. _ANG_KURZ_.' '._STUNDEN_.')'?></th>
                <td class="td">
                    <?php if (count_p4n($mp_bots) > 0): ?>
                        <?= $form->selectinput($mp_field_name.'[bot-id-offhours]', $mp_bots, @$messengerPeople['bot-id-offhours'], _BITTE_WAEHLEN_, 'id="bot-id-offhours" ') ?>
                    <?php endif; ?>
                    <?php if (count_p4n($mp_bots) < 2): ?>
                        <a href="admin_telefonreport.php?tkat=<?= urlencode($mp_cat_name) ?>&datum_von=&datum_bis=&allelf=-1&submit=OK" target="" onclick="topmain.P4nBoxHelper.startloading();"><?= _ADD_NEW_ ?></a>
                    <?php endif; ?>
                </td>
            </tr>
            <tr class="<?= classTr($i++) ?> bot">
                <th class="th"><?= p4n_mb_string('ucfirst',(_TEXTE_)).' '._MIT_.' Bot' ?></th>
                <td class="td">
                    <?= $form->submit2('bot-phrases', _TEXTVORLAGEN_, 'class="bot-enabled" style="margin-left: 5px; padding: 2px 10px;" onClick="P4nBoxHelper.iframe(\'bot_phrases_frame\', \'einstellungen_kfz.php?view=_part_messengerpeople_phrases&part=1\', false, \'100%\', \'100%\');"') ?>
                </td>
            </tr>
            <!-- end block for v1 -->
        <?php endif; ?>
    </table>
    <script>
        //v1+v2
        let bot_id_field = jq1112("#bot-id");
        let bot_id_field_offline = jq1112("#bot-id-offhours");
        let schedule_active = <?= json_encode($schedule_active) ?>;
    <?php if (!empty($cfg_messengerpeople_v2)) :?>
        //v2
        let mp_telegram_checkbox = jq1112("#mp-checkbox-telegram-active");
        let count_active_tr = 0;
        let rowIdx = <?=$z?>;
        let bot_active = <?= $bot_active ? 1 : 0 ?>;
        let locations_schedule = <?= count_p4n($schedule_listings) ? json_encode(MessengerPeopleV2::encode_utf8_if_need($schedule_listings)) : '[]' ?>;

        function classTr(s) {
            return s % 2 ? 'even' : 'odd';
        }

        function telegram_init_cfg() {
            let allow = true;
            let active = mp_telegram_checkbox.is(':checked');
            if (active) {
                $("#mp-telegram-active").val(1);
                $("#telegram-table-wrapper").show();
                jq1112("span#mp-telegram-active-label b").css('color','lightgreen').html("<?= _AKTIV_ ?>");
                mp_telegram_checkbox.attr("checked", true);
            } else {
                $("#mp-telegram-active").val(0);
                $("#telegram-table-wrapper").hide();
                jq1112("span#mp-telegram-active-label b").css('color','red').html("<?= _INAKTIV_ ?>");
                mp_telegram_checkbox.removeAttr("checked");
            }

            return allow;
        }
    <?php else:  ?>
        //v1
        let bot_active = jq1112("#mp-bot-active");
        let bot_select_location = jq1112("#bot-openhours-location");
    <?php endif; ?>

        jq1112(document).ready(function ($) {
            <?php if (!empty($cfg_messengerpeople_v2)) :?>
            telegram_init_cfg();
            mp_telegram_checkbox.change(function () {
                if (!mp_telegram_checkbox.is(':checked')) {
                    let ok = confirm('Are you sure you want to deactivate? All settings will be deleted after saving');
                    if (ok !== true) {
                        return false;
                    }
                }
                telegram_init_cfg();
                bot_init_cfgV2();
            });
            $('#addBtn').on('click', function () {
                ++rowIdx;
                let tr_class = classTr(rowIdx);
                // Adding a row inside the tbody.
                $('#whatsapp-table').append(`
                <tr class="${tr_class}" id="whatsapp-record-${rowIdx}" data-id="${rowIdx}">
                    <th class="th whatsapp-counter" style="width: 50px"><p>${rowIdx}</p></th>
                    <td class="td" style="width: 250px"><input name="<?=$mp_field_name?>[whatsapp-UUID][]" id="whatsapp-uuid-${rowIdx}"></td>
                    <td class="td" style="width: 250px"><input name="<?=$mp_field_name?>[whatsapp-recipient][]" id="whatsapp-recipient-${rowIdx}"></td>
                    <td class="td"><?= $form->selectinput($mp_field_name.'[whatsapp-language][]', MessengerPeople_Language::getLangArrayFiles(), -1) ?></td>
                    <td class="td"><?= $form->selectinput($mp_field_name.'[whatsapp-location][]', $locationList, -1, _BITTE_WAEHLEN_) ?></td>
                    <th class="td"><button class="btn btn-danger remove" type="button">Remove</button></th>
                </tr>
                `);
            });
            $('#whatsapp-table').on('click', '.remove', function () {
                console.log('remove');
                // let dig = $(this).attr("data-id");
                let ok = confirm('Are you sure you want to Delete?');
                if (!ok) {
                    return false;
                }
                var child = $(this).closest('tr').nextAll();
                // all tr in bottom need reindexed
                child.each(function () {
                    let current_id = parseInt($(this).attr("data-id"));
                    let new_id = current_id - 1;
                    console.log(current_id);
                    // Getting the <p> inside the .row-index class.
                    let tag_p = $(this).children('.whatsapp-counter').children('p');
                    // Modifying row index.
                    tag_p.html(new_id);
                    // Modifying row ids.
                    $(this).attr('id', 'whatsapp-record-' + new_id);
                    $(this).attr("data-id", new_id);
                    $("#whatsapp-uuid-" + current_id).attr("id", "whatsapp-uuid-" + new_id);
                    $("#whatsapp-recipient-" + current_id).attr("id", "whatsapp-recipient-" + new_id);
                });
                // Removing the current row.
                $(this).closest('tr').remove();
                // Decreasing total number of rows by 1.
                rowIdx--;
            });
            //$("whatsapp-record-" + idx).remove();

            //v2 set bot options
            bot_init_cfgV2();

            $(".channel-bot-on").change(function () {
                let i = this.getAttribute('data-i');
                let messenger = this.getAttribute('data-messenger');
                let checked = $(this).is(':checked');
                if (checked) {
                    jq1112("span#" + messenger + "-bot-on-label-" + i + " b.bot-status-label").css('color', 'green').html("Bot <?= _AKTIV_ ?>");
                    $("#" + messenger + "-schedule-location-" + i).show();
                    $(this).attr("checked", true);
                } else {
                    jq1112("span#" + messenger + "-bot-on-label-" + i + " b.bot-status-label").css('color', '#ff4343').html("Bot <?= _INAKTIV_ ?>");
                    $("#" + messenger + "-schedule-location-" + i).hide();
                    $(this).removeAttr("checked");
                }
                bot_init_cfgV2();
            });

            $(".channel-location").change(function () {
                let messenger = this.getAttribute('data-messenger');
                let i = this.getAttribute('data-i');
                let location = $(this).find(":selected").val();
                let checked = $("#" + messenger + "-channel-bot-on-" + i).is(':checked');
                console.log("change " + messenger + "-schedule-location-" + i + " location " + location + "checked:"+ checked);
                $("#message-bot-validatation").html('');
                $("#" + messenger + "-schedule-location-" + i).hide();
                //let n = Number(i) + 1;
                if (typeof location !== "undefined" && location !== '-1' && checked) {
                    //if(schedule_active[location] !== true) {
                    //    $("span#message-bot-validatation").append("<i class='error-bot-validation'>" + messenger + " #" + n + " <?= _LAGERORTE_.' '._OEFFUNGSZEITEN_.' '._INAKTIV_?>.</i>");
                    //}
                    $("#" + messenger + "-schedule-location-" + i).html(locations_schedule[location]).show();
                }
                //else if ((typeof location === "undefined" || location === '-1') && checked) {
                //    $("span#message-bot-validatation").append("<i class='error-bot-validation'>" + messenger + " #" + n + "<?= _LEITFADEN_.' - '._KEINE_AUSWAHL_?>.</i>");
                //}
                bot_init_cfgV2();
            });
            bot_id_field_offline.on('change', function() {
                bot_init_cfgV2();
            });
            bot_id_field.on('change', function() {
                bot_init_cfgV2();
            });
            //v2 submit-settings-kfz
            $("#submit-settings-kfz").click(function (event) {
                let allow = bot_init_cfgV2();
                console.log('when submit - allow? ' + allow);
                if (!allow) {
                    topmain.P4nBoxHelper.stoploading();
                    alert('Bot-<?= _FEHLER_LEADDASHBOARD_EINSTELLUNGEN_ ?>');
                    event.preventDefault();
                } else {
                    console.log('No errors: Form will be submitted');
                }
            });
            <?php else:  ?>
            //v1 set bot options
            bot_init_cfg();
            bot_active.change(function () {
                bot_init_cfg();
            });
            bot_select_location.change(function () {
                bot_init_cfg();
            });
            bot_id_field_offline.on('change', function() {
                bot_init_cfg();
            });
            bot_id_field.on('change', function() {
                bot_init_cfg();
            });
            //v1 submit-settings-kfz
            $("#submit-settings-kfz").click(function (event) {
                let allow = bot_init_cfg();
                console.log('when submit - allow? ' + allow);
                if (!allow) {
                    topmain.P4nBoxHelper.stoploading();
                    alert('Bot-<?= _FEHLER_LEADDASHBOARD_EINSTELLUNGEN_ ?>');
                    event.preventDefault();
                } else {
                    console.log('No errors: Form will be submitted');
                }
            });
            <?php endif; ?>
        }); <!-- ---end document ready-->

        // v2

        function bot_init_cfgV2() {
            let allow = true;
            let withBot = jq1112("input.bot-enabled");
            let withOutBot = jq1112("input.bot-disabled");
            let id = bot_id_field.val();
            let id_offline = bot_id_field_offline.val();
            let n_records = 0;
            let inactive_records = 0;

            jq1112("#message-bot-validatation").html(''); //clear
            jq1112(".channel-bot-on").each(function () {
                let messenger = this.getAttribute('data-messenger');
                if (messenger === 'telegram' && !mp_telegram_checkbox.is(':checked')) {
                    //skip if telegram is deactivated
                    return false;
                }
                n_records +=1;
                let i = this.getAttribute('data-i');
                let checked = jq1112(this).is(':checked');
                let location = jq1112("#" + messenger + "-channel-location-" + i).find(":selected").val();
                jq1112("#" + messenger + "-schedule-location-" + i).hide();
                console.log("#" + messenger + "-i-" + i + "checked:" + checked);
                let n = Number(i) + 1;
                if (checked) {
                    bot_active = 1;
                    if (typeof location !== "undefined" && location !== '-1') {
                        jq1112("#" + messenger + "-schedule-location-" + i).show();
                        if(schedule_active[location] !== true) {
                            jq1112("span#message-bot-validatation").append("<i class='warning-bot-validation'>" + messenger + " #" + n + " <?= _LAGERORTE_.' '._OEFFUNGSZEITEN_.' '. _INAKTIV_?>.</i>");
                        }
                        //$("#schd_" + location).show();
                    } else {
                        allow = false;
                        jq1112("span#message-bot-validatation").append("<i class='error-bot-validation'>" + messenger + " #" + n + " <?= _LAGERORTE_.' '. _ABWESEND_?>.</i>");
                    }
                    //let select_location_id = bot_select_location.val();
                    //console.log('select_location_id: ' + select_location_id);
                } else {
                    inactive_records += 1;
                }
            });
            //all bot for channels has inactive
            if (inactive_records >= n_records) {
                bot_active = 0;
            }
            //if all bots is on - hide this button
            //if all or one bot is inactive  show this button
            if (inactive_records > 0) {
                withOutBot.show();
            } else {
                withOutBot.hide();
            }
            //group action
            if (bot_active === 1) {
                console.log('active: '+ bot_active);
                // jq1112("div#schd_" + select_location_id).show();
                jq1112("span#mp-bot-active-label b").css('color','lightgreen').html("<?= _AKTIV_ ?>");
                jq1112("tr.bot").show();
                withBot.show();
                console.log('bot id field: ' + id);
                console.log('bot offline id field: ' + id_offline);
                if ((typeof id === "undefined" || id === '-1') && (typeof id_offline === "undefined" || id_offline === '-1')) {
                    allow = false;
                    jq1112("span#message-bot-validatation").append("<i class='error-bot-validation'>&nbsp; <?= _LEITFADEN_.' - '._KEINE_AUSWAHL_?>.</i>");
                }
            } else {
                jq1112("span#mp-bot-active-label b").css('color','#ff4343').html("<?= _INAKTIV_ ?>");
                jq1112("tr.bot").hide();
                withBot.hide();
            }
            console.log('return: ' + allow);
            return allow;
        }
        //v1
        function bot_init_cfg() {
            let allow = true;
            let active = bot_active.is(':checked');
            let withBot = jq1112("input.bot-enabled");
            let withOutBot = jq1112("input.bot-disabled");
            //console.log('active: '+ active);
            let select_location_id = bot_select_location.val();
            //console.log('select_location_id: ' + select_location_id);
            let id = bot_id_field.val();
            let id_offline = bot_id_field_offline.val();
            //console.log('bot id field: ' + id);
            //console.log('bot offline id field: ' + id_offline);
            let m1 = jq1112("i.error-bot-validation-1");
            let m2 = jq1112("i.error-bot-validation-2");
            if (m1.length >= 1) {
                m1.remove();
            }
            if (m2.length >= 1) {
                m2.remove();
            }
            if ((!id || id === '-1') && (!id_offline || id_offline === '-1')) {
                //console.log('IF [1]');
                withBot.hide();
                withOutBot.show();
                //console.log('need hide with');
                if (active) {
                    //console.log('[1] active & allow: false');
                    allow = false;
                    jq1112("span#message-bot-validatation").append("<i class='error-bot-validation-1' style='color:#ff4343'>&nbsp; <?= _LEITFADEN_.' - '._KEINE_AUSWAHL_?>.</i>");
                }
            } else if (active && ((id && id !== '-1') || (id_offline && id_offline !== '-1'))) {
                //console.log('IF [2]');
                withBot.show();
                withOutBot.hide();
                //console.log('need how with');
            } else {
                //console.log('need hide with');
                //console.log('IF [3]');
                withBot.hide();
                withOutBot.show();
            }
            if(active) {
                jq1112("div.schedule-listing").hide();
                jq1112("div#schd_" + select_location_id).show();
                jq1112("span#mp-bot-active-label b").css('color','lightgreen').html("<?= _AKTIV_ ?>");
                jq1112("tr.bot").show();
                //console.log('IF [active]');
                //console.log( 'schedule_active[select_location_id] ' + schedule_active[select_location_id]);
                if(schedule_active[select_location_id] !== true) {
                    allow = false;
                    // console.log('[2] active & allow: false');
                    jq1112("span#message-bot-validatation").append("<i class='error-bot-validation-2' style='color:#ff4343'>&nbsp; <?= _LAGERORTE_.' '._OEFFUNGSZEITEN_.' '. _INAKTIV_?>.</i>");
                }
            } else {
                //console.log('[else] not active');
                jq1112("div.schedule-listing").hide();
                jq1112("span#mp-bot-active-label b").css('color','red').html("<?= _INAKTIV_ ?>");
                jq1112("tr.bot").hide();
            }
            //console.log('return: ' + allow);
            return allow;
        }
    </script>
<?php endif; ?>
<?php endif; ?>

<?php if (!empty($cfg_stellantis)): ?>
    <?php
    $count++;
    
    /**
     * TODO?
     *  $stellantisCfg = new Settings_Data('STELLANTIS_DEALERS', true);
     *  $dealerList = $stellantisCfg->getValue();
     */
    $stellantis = Stellantis::getParams();
    $stellantisError = null;
    if (!empty($postfeld['stellantis-refresh-token'])) {
        try {
            $stellantisInstance = Stellantis::instance();
            $stellantisInstance->refreshToken();
        } catch (Exception $e) {
            $stellantisError = $e->getMessage();
        }
        $stellantis = Stellantis::getParams();
    }
    
    $stellantisInfo = '<table>';
    $stellantisInfo .= '<tr>';
    $stellantisInfo .= '<td>PREPROD_PROVIDER_URL</td>';
    $stellantisInfo .= '<td>'.Stellantis::PREPROD_PROVIDER_URL.'</td>';
    $stellantisInfo .= '</tr>';
    $stellantisInfo .= '<tr>';
    $stellantisInfo .= '<td>REDIRECT_URI</td>';
    $stellantisInfo .= '<td>'.Stellantis::REDIRECT_URI.'</td>';
    $stellantisInfo .= '</tr>';
    $stellantisInfo .= '<tr>';
    $stellantisInfo .= '<td>WELL_KNOWN_URL</td>';
    $stellantisInfo .= '<td>'.Stellantis::PREPROD_WELL_KNOWN_URL.'</td>';
    $stellantisInfo .= '</tr>';
    $stellantisInfo .= '<tr>';
    $stellantisInfo .= '<td>PREPROD_URL</td>';
    $stellantisInfo .= '<td>'.Stellantis_Api::PREPROD_URL.'</td>';
    $stellantisInfo .= '</tr>';
    foreach ($stellantis as $key => $value) {
        if ($key === 'token') {
            foreach ($value as $tokenKey => $tokenValue) {
                $stellantisInfo .= '<tr>';
                $stellantisInfo .= "<td>$tokenKey</td>";
                $stellantisInfo .= '<td>'.abkuerzung($tokenValue, 20).'</td>';
                $stellantisInfo .= '</tr>';
            }
        } else {
            $stellantisInfo .= '<tr>';
            $stellantisInfo .= "<td>$key</td>";
            $stellantisInfo .= "<td>$value</td>";
            $stellantisInfo .= '</tr>';
        }
    }
    $stellantisInfo .= '</table>';
    ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" colspan="8">Stellantis <?= _LEADS_.'&nbsp;'.oltext($stellantisInfo, '&nbsp;') ?></th>
        </tr>
        <tr class="even first-child">
            <th class="small th" colspan="8">Stellantis Token (Ping Federate)</th>
        </tr>
        <tr class="odd">
            <th class="th">Client ID</th>
            <td class="td"><?= $form->textinput('stellantis[pingfed_client_id]', $stellantis['pingfed_client_id']) ?></td>
            <th class="th">Client Secret</th>
            <td class="td"><?= $form->textinput('stellantis[pingfed_client_secret]', $stellantis['pingfed_client_secret']) ?></td>
            <th class="th"><?= _TOKEN_ ?></th>
            <td class="td" nowrap>
                <?php if ($stellantisError): ?>
                    <span style="color: red;"><?= _FEHLER_.': '.$stellantisError ?></span>
                <?php else : ?>
                    <?php if (!empty($stellantis['token']['expires_at'])): ?>
                        <?= $lang['_PINNWAND-GUELTIGBIS_'].': '.date('d.m.Y H:i:s', $stellantis['token']['expires_at']) ?>
                        <?= $form->checkinput('stellantis-refresh-token', '', 'title="Refresh token"') ?>
                    <?php endif; ?>
                <?php endif; ?>
            </td>
            <th class="th"><?= _LOGGING_ ?></th>
            <td class="td"><?= $form->checkinput('stellantis[logging]', $stellantis['logging']) ?></td>
        </tr>
        <tr class="even">
            <th class="small th" colspan="8">Stellantis Application</th>
        </tr>
        <tr class="odd">
            <th class="th">Client ID</th>
            <td class="td"><?= $form->textinput('stellantis[application_client_id]', $stellantis['application_client_id']) ?></td>
            <th class="th">Client Secret</th>
            <td class="td"><?= $form->textinput('stellantis[application_client_secret]', $stellantis['application_client_secret']) ?></td>
            <th class="th"><?= _STANDORT_.' Geo Id' ?></th>
            <td class="td" colspan="3"><?= $form->textinput('stellantis[geo_id]', $stellantis['geo_id'], 35) ?></td>
        </tr>
        <tr class="even">
            <th class="small th" colspan="8">Stellantis Leads</th>
        </tr>
        <tr class="even">
            <th class="th"><?= _MASTERKAMPAGNE_ ?></th>
            <td class="td" colspan="3"><?= $form->selectinput('stellantis[masterCampaign]', $campaignsList, $stellantis['masterCampaign'], _BITTE_WAEHLEN_) ?></td>
            <th class="th"><?= _LAGERORT_.' ('._ERSATZ_.')' ?></th>
            <td class="td" colspan="3"><?= $form->selectinput('stellantis[locationDef]', $locationList, $stellantis['locationDef'], _BITTE_WAEHLEN_) ?></td>
        </tr>
    </table>
<?php endif; ?>

<?php if (!empty($cfg_seat_leads)): ?>
    <?php
    $seatLeads = SeatLeads::getParams();
    $info_cer = '';
    if (!empty($seatLeads['certificate'])) {
        $info_cer = _ABLAUF_.'-'._DATUM_.': '.date('d.m.Y', $seatLeads['certificate_valid']);
        if (intval($seatLeads['certificate_valid']) - time() < 5300000) {
            $info_cer = '<span style="color:red">'.$info_cer.'</span>';
        }

    }
    ?>
    <table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
        <tr class="heading">
            <th class="small th" colspan="10">Seat <?= _LEADS_ ?></th>
        </tr>
        <tr class="odd first-child">
            <th class="th">Client ID</th>
            <td class="td"><?= $form->textinput('seat_leads[client_id]', $seatLeads['client_id']) ?></td>
            <th class="th">Zertifikat</th>
            <td class="td" nowrap><?= $form->dateiinput('seat_certificate', '', 50).$info_cer ?></td>
            <th class="th"><?= _MASTERKAMPAGNE_ ?></th>
            <td class="td"><?= $form->selectinput('seat_leads[masterCampaign]', $campaignsList, $seatLeads['masterCampaign'], _BITTE_WAEHLEN_) ?></td>
        </tr>
        <tr class="even">
            <th class="th">Client Secret</th>
            <td class="td"><?= $form->textinput('seat_leads[client_secret]', $seatLeads['client_secret']) ?></td>
            <th class="th">Private Key</th>
            <td class="td"><?= $form->dateiinput('seat_pkey', '', 50) ?></td>
            <th class="th"><?= _ZUORDNUNG_ ?></th>
            <td class="td"><?= $form->submit2('seat_locations', _LAGERORTE_, 'onClick="P4nBoxHelper.iframe(\'seat_locations\', \'einstellungen_kfz.php?view=seat_locations\', false, 800, 400);"') ?></td>
        </tr>
        <tr class="odd">
            <th class="th"><?= _LOGGING_ ?></th>
            <td class="td" colspan="9"><?= $form->checkinput('seat_leads[logging]', $seatLeads['logging']) ?></td>
        </tr>
    </table>
<?php endif; ?>

<?php if ($count > 0): ?>
    <?= $form->submit('submit', _SUBMIT_STAMMDATEN_, 'id="submit-settings-kfz"') ?>
<?php else : ?>
    <span class="error"><?= _KEINE_LEAD_QUELLEN_AKTIV_ ?></span>
<?php endif; ?>
<?= $form->ende(); ?>
<?php fuss();