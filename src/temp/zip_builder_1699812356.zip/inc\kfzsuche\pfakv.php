<?php

	if ($postfeld['submit1']==_PROBEFAHRT_.' '._ERSTELLEN_ or $postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_ or $postfeld['submit1']==_ANGEBOT_.' '._ERSTELLEN_ or $postfeld['submit1']==_EXPOSE_.' '._ERSTELLEN_ or $postfeld['submit1']==_VVI_.' '._ERSTELLEN_ or $postfeld['submit1']==_SAMMELKV_.' '._ERSTELLEN_ or $getfeld['vs']=='1' or $postfeld['submit1']==_INTERNEFAHRT_.' '._ERSTELLEN_ or $postfeld['submit1']=='Vorvertragsinformation'.' '._ERSTELLEN_ or $postfeld['submit1']==_SUCHAUFTRAG_.' '._ERSTELLEN_) {

        If ($_SESSION['design_70']) {
            Modern_Helper_Request::requestStart();
        }
 
        /*
echo '<pre>';
print_r($postfeld);
print_r($getfeld);
die();
*/
		if (intval($postfeld['stid'])>0) {
			$_SESSION['stammdaten_id']=$postfeld['stid'];
		}
		$apid=0;
		$keinap=false;
		if (isset($postfeld['apbezug'])) {
			if (intval($postfeld['apbezug'])>0) {
				$apid=intval($postfeld['apbezug']);
			} else {
				$keinap=true;
			}
		}
		if (!$cfg_kaufvertrag_aendern and intval($postfeld['pid'])>0) {
			$res=$db->select(
				$sql_tab['produktzuordnung'],
				array(
					$sql_tabs['produktzuordnung']['kaufvertrag_kunde'],
					$sql_tabs['produktzuordnung']['fahrzeugstatus_code'],
					$sql_tabs['produktzuordnung']['fahrgestell'],
					$sql_tabs['produktzuordnung']['fahrzeugstatus']
				),
				$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
			);
			if ($row=$db->zeile($res)) {
				if ($cfg_kfz_webservice) {
					$alle_contr=ws_kroa_kfz($postfeld['pid'], 10);
					if (isset($alle_contr['vehicle']['vin'])) {
						if ($alle_contr['vehicle']['vin']==$row[2]) {
							echo '<br>'._KFZ_VERKAUFT_;
							echo javas('alert("'._KFZ_VERKAUFT_.'");');
							die();
						}
					}
				}
				if (!$cfg_kfzsuche_trigger_verkauftenicht and !isset($getfeld['profitc']) and intval($row[0])>0) {
					$res5=$db->select(
						$sql_tab['korrespondenz'],
						$sql_tabs['korrespondenz']['korrespondenz_id'],
						$sql_tabs['korrespondenz']['kategorie'].'='.$db->str(_KAUFVERTRAG_).' and '.
							$sql_tabs['korrespondenz']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
					);
					if ($row5=$db->zeile($res5)) {
						if (isset($postfeld['pfzeit']) and $cfg_kfzsuche_immer_pf) {
						} elseif (($cfg_kfzsuche_kv_vfw_mw_pf or $cfg_kfzsuche_kv_vfw_pf) and ($row[1]=='2' or p4n_mb_string('substr',$row[3], 0, 7)=='Vorf�hr' or p4n_mb_string('substr',$row[3], 0, 4)=='Test' or p4n_mb_string('substr',$row[3], 0, 5)=='Tages')) {
						} else {
							echo '<br>'._KFZ_VERKAUFT_;
							echo javas('alert("'._KFZ_VERKAUFT_.'");');
							die();
						}
					}
				}
			}
		}
		
		$ses_ma2=$_SESSION['mitarbeiter_name2'];
		$ses_ma=$_SESSION['mitarbeiter_name'];
		$ses_ma_email=$_SESSION['user_email'];
		$ses_ma_tel=$_SESSION['benutzer_tel'];
		$ses_ma_fax=$_SESSION['benutzer_fax'];
		$ses_ma_mob=$_SESSION['benutzer_mob'];

		$ang_kv_user=$_SESSION['user_id'];
		if (isset($postfeld['k_benutzer_id'])) {
			if (intval($postfeld['k_benutzer_id'])>0) {
				$ang_kv_user=intval($postfeld['k_benutzer_id']);

				$res2=$db->select(
					$sql_tab['benutzer'],
					array(
						$sql_tabs['benutzer']['vorname'],
						$sql_tabs['benutzer']['name'],
						$sql_tabs['benutzer']['email'],
						$sql_tabs['benutzer']['telefon'],
						$sql_tabs['benutzer']['fax'],
						$sql_tabs['benutzer']['mobilfon']
					),
					$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($ang_kv_user)
				);
				if ($row2=$db->zeile($res2)) {
					$ses_ma=$row2[0].' '.$row2[1];
					$ses_ma2=$row2[1].', '.$row2[0];
					$ses_ma_email=$row2[2];
					$ses_ma_tel=$row2[3];
					$ses_ma_fax=$row2[4];
					$ses_ma_mob=$row2[5];
				}
			}
		}
		
		if ($postfeld['anrede']=='-1') {
			$postfeld['anrede']='';
		}
		if ($postfeld['branche']=='-1') {
			$postfeld['branche']='';
		}
		if ($postfeld['hobby']=='-1') {
			$postfeld['hobby']='';
		}
		if ($postfeld['beruf']=='-1') {
			$postfeld['beruf']='';
		}
		
		if (isset($postfeld['anredehatcode'])) {
			$postfeld['anredecode']=$postfeld['anrede'];
			$res3=$db->select(
				$sql_tab['crmcodes'],
				array(
					$sql_tabs['crmcodes']['crmcodes_id'],
					$sql_tabs['crmcodes']['code1'],
					$sql_tabs['crmcodes']['text1']
				),
				$sql_tabs['crmcodes']['art'].'='.$db->str('CARLO_SALUTATION').' and '.
					$sql_tabs['crmcodes']['code1'].'='.$db->str($postfeld['anrede'])
			);
			if ($row3=$db->zeile($res3)) {
				$postfeld['anredecode']=$postfeld['anrede'];
				$postfeld['anrede']=$row3[2];
			} else {
				$res3=$db->select(
					$sql_tab['stammdaten'],
					$sql_tabs['stammdaten']['anrede'],
					$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($postfeld['stid'])
				);
				if ($row3=$db->zeile($res3)) {
					$postfeld['anrede']=$row3[0];
				}
			}
		}
		if (isset($postfeld['anredehatcode2'])) {
			$postfeld['anredecode']=$postfeld['anrede'];
			$res3=$db->select(
				$sql_tab['crmcodes'],
				array(
					$sql_tabs['crmcodes']['crmcodes_id'],
					$sql_tabs['crmcodes']['code1'],
					$sql_tabs['crmcodes']['text1']
				),
				$sql_tabs['crmcodes']['art'].'='.$db->str('CARLO_ANREDEN').' and '.
					$sql_tabs['crmcodes']['code1'].'='.$db->str($postfeld['anrede'])
			);
			if ($row3=$db->zeile($res3)) {
				$postfeld['anredecode']=$postfeld['anrede'];
				$postfeld['anrede']=$row3[2];
			} else {
				$res3=$db->select(
					$sql_tab['stammdaten'],
					$sql_tabs['stammdaten']['anrede'],
					$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($postfeld['stid'])
				);
				if ($row3=$db->zeile($res3)) {
					$postfeld['anrede']=$row3[0];
				}
			}
		}
		if ($postfeld['titel']=='-1') {
			$postfeld['titel']='';
		}
		if (intval($postfeld['stid'])>0 and (!isset($getfeld['vs']) or $getfeld['vs']!='1')) {
			$stidn=$postfeld['stid'];
			$feld_check=array(
			'anrede',
			'titel',
			'firma1',
			'vorname',
			'name',
			'geburtsdatum',
			'geburtsort',
			'beruf',
			'idstatus',
			'adresse',
			'plz',
			'ort',
			'telefon',
			'fax',
			'mobilfon',
			'email'
			);
			$altdaten=array();
			$res3=$db->select(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['anrede'],
					$sql_tabs['stammdaten']['titel'],
					$sql_tabs['stammdaten']['firma1'],
					$sql_tabs['stammdaten']['vorname'],
					$sql_tabs['stammdaten']['name'],
					$sql_tabs['stammdaten']['geburtstag'],
					$sql_tabs['stammdaten']['geburtsort'],
					$sql_tabs['stammdaten']['beruf'],
					$sql_tabs['stammdaten']['idstatus'],
					$sql_tabs['stammdaten']['Telefon_1'],
					$sql_tabs['stammdaten']['Telefon_2'],	// 10
					$sql_tabs['stammdaten']['Fax_1'],
					$sql_tabs['stammdaten']['Fax_2'],
					$sql_tabs['stammdaten']['Mobilfon_1'],
					$sql_tabs['stammdaten']['Mobilfon_2'],
					$sql_tabs['stammdaten']['EMail_1'],		// 15
					$sql_tabs['stammdaten']['EMail_2'],
					$sql_tabs['stammdaten']['branche'],
					$sql_tabs['stammdaten']['hobby']
				),
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($stidn)
			);
			if ($row3=$db->zeile($res3)) {
				$altdaten=array(
					'anrede' => $row3[0],
					'titel' => $row3[1],
					'firma1' => $row3[2],
					'vorname' => $row3[3],
					'name' => $row3[4],
					'geburtsdatum' => $db->unixdate($row3[5]),
					'geburtsort' => $row3[6],
					'beruf' => $row3[7],
					'idstatus' => $row3[8],
					'telefon' => $row3[9],
					'fax' => $row3[11],
					'mobilfon' => $row3[13],
					'email' => $row3[15]
				);
				if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
					$altdaten['hobby']=$row3[18];
				}
				if ($cfg_kfzsuche_stammdaten_branche) {
					$altdaten['branche']=$row3[17];
				}
				if ($_SESSION['cfg_kunde']=='carlo_opel_dello') {
					$altdaten['branche']=$row3[17];
					$altdaten['hobby']=$row3[18];
				}
				if (p4n_mb_string('strtolower',$row3[0])=='firma' or $row3[2]!='') {
					$altdaten['telefon']=$row3[10];
					$altdaten['fax']=$row3[12];
					$altdaten['mobilfon']=$row3[14];
					$altdaten['email']=$row3[16];
				}
				$res3=$db->select(
					$sql_tab['stammdaten_adresse'],
					array(
						$sql_tabs['stammdaten_adresse']['adresse'],
						$sql_tabs['stammdaten_adresse']['plz'],
						$sql_tabs['stammdaten_adresse']['ort']
					),
					$sql_tabs['stammdaten_adresse']['stammdaten_id'].'='.$db->dbzahl($stidn)
				);
				$row3=$db->zeile($res3);
				$altdaten['adresse']=$row3[0];
				$altdaten['plz']=$row3[1];
				$altdaten['ort']=$row3[2];

				while (list($key1, $val1)=@each($feld_check)) {
					if (isset($postfeld[$val1])) {
						if ($postfeld[$val1]!=$altdaten[$val1]) {
							$db->insert(
								$sql_tab['log_aenderung'],
								array(
									$sql_tabs['log_aenderung']['datum'] => $db->dbtimestamp(time()),
									$sql_tabs['log_aenderung']['benutzer_id'] => $db->dbzahl($_SESSION['user_id']),
									$sql_tabs['log_aenderung']['tabelle'] => $db->str('stammdaten'),
									$sql_tabs['log_aenderung']['feldname'] => $db->str($val1),
									$sql_tabs['log_aenderung']['feldinhalt_alt'] => $db->str($altdaten[$val1]),
									$sql_tabs['log_aenderung']['feldinhalt_neu'] => $db->str($postfeld[$val1]),
									$sql_tabs['log_aenderung']['zusatz1'] => $db->str($stidn),
									$sql_tabs['log_aenderung']['zusatz2'] => $db->str(trim(str_replace(array(_ERSTELLEN_, _VORSCHAU_), '', $postfeld['submit1'])))
								)
							);
						}
					}
				}
			}
		}
		if (isset($postfeld['vertrags_gwmarke']) and !isset($postfeld['vertrags_ankauf'])) {
			unset($postfeld['vertrags_gwmarke']);
			unset($postfeld['vertrags_kennz']);
			unset($postfeld['vertrags_gwtyp']);
			unset($postfeld['vertrags_gwfgnr']);
			unset($postfeld['vertrags_gwez']);
			unset($postfeld['vertrags_gwpreis']);
			unset($postfeld['vertrags_gwlieferung']);
			unset($postfeld['vertrags_gwlagerort']);
			unset($postfeld['vertrags_dvs_steuer']);
			unset($postfeld['vertrags_dvs_h1']);
			unset($postfeld['vertrags_dvs_h2']);
			unset($postfeld['vertrags_gwpreisproz']);
		}
		$alle_pdfs=array();
		$vorschau=false;
		$bez_ang_kv='';
		$bez_ang_kv2='';
		if ($postfeld['submit1']==_EXPOSE_.' '._ERSTELLEN_) {
			$bez_ang_kv=_EXPOSE_;
			$bez_ang_kv2='expose';
		}
		if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_ or $getfeld['vs']=='1') {
			$bez_ang_kv=_KAUFVERTRAG_;
			$bez_ang_kv2='kv';
		}
		if ($cfg_db_kaufrecht2022) {
			if ($postfeld['submit1']=='Vorvertragsinformation'.' '._ERSTELLEN_ or ($getfeld['vs']=='1' and $getfeld['vsv']=='1')) {
				$bez_ang_kv='Vorvertragsinformation';
				$bez_ang_kv2='vvi';
			}
		} elseif ($postfeld['submit1']==_VVI_.' '._ERSTELLEN_) {
			$bez_ang_kv='Vorvertragsinformation';
			$bez_ang_kv2='vvi';
		}
		if ($postfeld['submit1']==_SAMMELKV_.' '._ERSTELLEN_ or ($getfeld['vs']=='1' and $getfeld['vssk']=='1')) {
			$bez_ang_kv=_KAUFVERTRAG_;
			$bez_ang_kv2='skv';
		}
		if ($postfeld['submit1']==_ANGEBOT_.' '._ERSTELLEN_ or ($getfeld['vs']=='1' and $getfeld['vs2']=='1')) {
			$bez_ang_kv=_ANGEBOT_;
			$bez_ang_kv2='ang';
		}
		if ($postfeld['submit1']==_PROBEFAHRT_.' '._ERSTELLEN_ or ($getfeld['vs']=='1' and $getfeld['vs3']=='1')) {
			$bez_ang_kv=_PROBEFAHRT_;
			$bez_ang_kv2='pf';
		}
		if ($postfeld['submit1']==_INTERNEFAHRT_.' '._ERSTELLEN_) {
			$bez_ang_kv=_PROBEFAHRT_;
			$bez_ang_kv2='pf';
		}
		$kampa_id=kamp_insert_kfzsuche($bez_ang_kv);
		if ($cfg_kfzsuche_kampagnenauswahl) {
			if (isset($postfeld['akv_kampagne'])) {
				if (intval($postfeld['akv_kampagne'])>0) {
					$kampa_id=intval($postfeld['akv_kampagne']);
				}
			}
		}
		$leasingdruck=false;
		if (isset($getfeld['leasdruck'])) {
			$leasingdruck=true;
			$getfeld['vs']='1';
		}
		$profitdruck=false;
		if (isset($getfeld['profitc'])) {
			$profitdruck=true;
			$leasingdruck=true;
			$getfeld['vs']='1';
		}
		
		if ($getfeld['vs']=='1') {
			$vorschau=true;
            if ($_SESSION['crm_version']>61 && !$_SESSION['design_70']) {
                echo javas('if (typeof parent.main.P4nBoxHelper.stoploading != typeof undefined) {parent.main.P4nBoxHelper.stoploading();} ');
            }
		}

/*		if ($postfeld['vorname']!='' and $postfeld['name']=='') {
			$postfeld['name']=$postfeld['vorname'];
			$postfeld['vorname']='';
		}
*/
		$manda_id=1;
		$lago_id=0;
		$manda_found=false;
		if (isset($postfeld['vertrag_lagerort'])) {
			$res4=$db->select(
				$sql_tab['mandant'],
				$sql_tabs['mandant']['parent_id'],
				$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($postfeld['vertrag_lagerort'])
			);
			if ($row4=$db->zeile($res4)) {
				if (intval($row4[0])>0) {
					$manda_id=$row4[0];
					$lago_id=$postfeld['vertrag_lagerort'];
					$manda_found=true;
				}
			}
			if (intval($postfeld['vertrag_lagerort'])>0) {
				$lago_id=$postfeld['vertrag_lagerort'];
			}
		}
		if (!$manda_found) {
			if (isset($postfeld['lagerort'])) {
				$xpl=explode('_', $postfeld['lagerort']);
				$manda_id=$xpl[0];
				if ($xpl[1]!='') {
					$res4=$db->select(
						$sql_tab['mandant'],
						$sql_tabs['mandant']['mandant_id'],
						$sql_tabs['mandant']['bezeichnung'].'='.$db->str($xpl[1])
					);
					if ($row4=$db->zeile($res4)) {
						$lago_id=$row4[0];
					}
				}
			} elseif (intval($_SESSION['mandant'])>0) {
				$manda_id=$_SESSION['mandant'];
			}
		}
		if (intval($lago_id)==0 and intval($_SESSION['user_standard_lagerort'])>0) {
			$lago_id=intval($_SESSION['user_standard_lagerort']);
		}
		if (intval($lago_id)==0 and intval($postfeld['pid'])>0) {
			$res=$db->select(
				$sql_tab['produktzuordnung'],
				array(
					$sql_tabs['produktzuordnung']['mandant_id']
				),
				$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
			);
			if ($row=$db->zeile($res)) {
				$lago_id=intval($row[0]);
			}
		}
		
		if ($_SESSION['cfg_kunde']=='carlo_opel_neff') {
			if (isset($postfeld['opp_mandant'])) {
				$manda_id=$postfeld['opp_mandant'];
			}
		}
		
		$ist_mitdummy=false;
		// ohne Kunde:
		$ohnek=false;
		if ($postfeld['vorname']=='' and $postfeld['name']=='' and $postfeld['firma1']=='') {
			$ohnek=true;
			$neu_kid=0;
			$ist_mitdummy=true;
			$res=$db->select(
				$sql_tab['stammdaten'],
				$sql_tabs['stammdaten']['id'],
				$sql_tabs['stammdaten']['id'].'>1000000 and ('.
					$sql_tabs['stammdaten']['name'].'='.$db->str('Dummy').' or '.
					$sql_tabs['stammdaten']['firma1'].'='.$db->str('Dummy').')'
			);
			if ($row=$db->zeile($res)) {
				$neu_kid=$row[0];
				$postfeld['anrede']=_FIRMA_;
				$postfeld['vorname']=$manda_id;
				$postfeld['name']='Dummy';
				$postfeld['firma1']='Dummy';
			} else {
				// anlegen:
				$grbez=0;
			$grbez2=0;
			$res=$db->select(
				$sql_tab['stammdaten_gruppe'],
				array(
					$sql_tabs['stammdaten_gruppe']['gruppe_id'],
					$sql_tabs['stammdaten_gruppe']['bezeichnung']
				),
				$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('Interessenten CRM').' or '.
					$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('CRM Interessenten').' or '.
					$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('CRM Prospects').' or '.
					$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('CRM')
			);
			if ($row=$db->zeile($res)) {
				$grbez=$row[0];
				$grbez2=$row[1];
			}

			$minmax=array(1000000, 9999999);
			if (isset($cfg_min_nra[$grbez2])) {
				$xpl3=explode('-', $cfg_min_nra[$grbez2]);
				if (count($xpl3)==2) {
					$minmax=array($xpl3[0], $xpl3[1]);
				}
			}
				$res=$db->select(
					$sql_tab['stammdaten'],
					'max('.$sql_tabs['stammdaten']['id'].')+1',
					$sql_tabs['stammdaten']['id'].' between '.$minmax[0].' and '.$minmax[1]
				);
				$row=$db->zeile($res);
				$neu_kid=intval($row[0]);
				if ($neu_kid<$minmax[0]) {
					$neu_kid=$minmax[0];
				}

				$neukid_drin=false;
				if ($neu_kid>=intval($minmax[0])) {
					$db->insert(
						$sql_tab['stammdaten'],
						array(
							$sql_tabs['stammdaten']['name'] => $db->str('FDummy')
						)
					);
					$neu_kid=intval($db->insertid());
					$db->delete(
						$sql_tab['stammdaten'],
						$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($neu_kid)
					);
					$neukid_drin=true;
				}

				$postfeld['anrede']=_FIRMA_;
				$postfeld['vorname']=$manda_id;
				$postfeld['name']='Dummy';
				$postfeld['firma1']='Dummy';

				$anzeigename=eingabe2anzeigename($postfeld['vorname'], $postfeld['name'], $postfeld['titel'], $postfeld['firma1'], $postfeld['anrede']);

				$db->insert(
					$sql_tab['stammdaten'],
					array(
					$sql_tabs['stammdaten']['id'] => $db->dbzahl($neu_kid),
					$sql_tabs['stammdaten']['mandant'] => $db->dbzahl($manda_id),
					$sql_tabs['stammdaten']['vpb'] => $db->dbzahl($lago_id),
					$sql_tabs['stammdaten']['anrede'] => $db->str($postfeld['anrede']),
					$sql_tabs['stammdaten']['titel'] => $db->str($postfeld['titel']),
					$sql_tabs['stammdaten']['vorname'] => $db->str($postfeld['vorname']),
					$sql_tabs['stammdaten']['name'] => $db->str($postfeld['name']),
					$sql_tabs['stammdaten']['firma1'] => $db->str($postfeld['firma1']),
					$sql_tabs['stammdaten']['betreuer'] => $db->dbzahl($ang_kv_user),
					$sql_tabs['stammdaten']['anzeigename'] => $db->str($anzeigename),
					$sql_tabs['stammdaten']['meinvp'] => $db->dbzahl(0),
					$sql_tabs['stammdaten']['Telefon_1'] => $db->str(''),
					$sql_tabs['stammdaten']['Mobilfon_1'] => $db->str(''),
					$sql_tabs['stammdaten']['Fax_1'] => $db->str(''),
					$sql_tabs['stammdaten']['EMail_1'] => $db->str(''),
					$sql_tabs['stammdaten']['erstellt_benutzer'] => $db->dbzahl($_SESSION['user_id']),
					$sql_tabs['stammdaten']['erstellt_datum'] => $db->dbtimestamp(time()),
					$sql_tabs['stammdaten']['syncml_letzte_aenderung'] => $db->dbtimestamp(time())
					)
				);
				$db->insert(
					$sql_tab['stammdaten_gruppe_zuordnung'],
					array(
						$sql_tabs['stammdaten_gruppe_zuordnung']['gruppe_id'] => $db->dbzahl($grbez),
						$sql_tabs['stammdaten_gruppe_zuordnung']['stammdaten_id'] => $db->dbzahl($neu_kid)
					)
				);
			}

			unset($postfeld['neukunde']);
			$postfeld['stid']=$neu_kid;
			$_SESSION['stammdaten_id']=$neu_kid;
		}

		$ohnek2=false;
		if (isset($postfeld['coholder']) and $postfeld['co_vorname']=='' and $postfeld['co_name']=='' and $postfeld['co_firma1']=='') {
			$ohnek2=true;
			$neu_kid=0;
			$res=$db->select(
				$sql_tab['stammdaten'],
				$sql_tabs['stammdaten']['id'],
				$sql_tabs['stammdaten']['id'].'>1000000 and ('.
					$sql_tabs['stammdaten']['name'].'='.$db->str('CoDummy').' or '.
					$sql_tabs['stammdaten']['firma1'].'='.$db->str('CoDummy').')'
			);
			if ($row=$db->zeile($res)) {
				$neu_kid=$row[0];
				$postfeld['anrede']=_FIRMA_;
				$postfeld['vorname']=$manda_id;
				$postfeld['name']='CoDummy';
				$postfeld['firma1']='CoDummy';
			} else {
				// anlegen:
				$grbez=0;
			$grbez2=0;
			$res=$db->select(
				$sql_tab['stammdaten_gruppe'],
				array(
					$sql_tabs['stammdaten_gruppe']['gruppe_id'],
					$sql_tabs['stammdaten_gruppe']['bezeichnung']
				),
				$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('Interessenten CRM').' or '.
					$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('CRM Interessenten').' or '.
					$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('CRM Prospects').' or '.
					$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('CRM')
			);
			if ($row=$db->zeile($res)) {
				$grbez=$row[0];
				$grbez2=$row[1];
			}

			$minmax=array(1000000, 9999999);
			if (isset($cfg_min_nra[$grbez2])) {
				$xpl3=explode('-', $cfg_min_nra[$grbez2]);
				if (count($xpl3)==2) {
					$minmax=array($xpl3[0], $xpl3[1]);
				}
			}
				$res=$db->select(
					$sql_tab['stammdaten'],
					'max('.$sql_tabs['stammdaten']['id'].')+1',
					$sql_tabs['stammdaten']['id'].' between '.$minmax[0].' and '.$minmax[1]
				);
				$row=$db->zeile($res);
				$neu_kid=intval($row[0]);
				if ($neu_kid<$minmax[0]) {
					$neu_kid=$minmax[0];
				}

				$neukid_drin=false;
				if ($neu_kid>=intval($minmax[0])) {
					$db->insert(
						$sql_tab['stammdaten'],
						array(
							$sql_tabs['stammdaten']['name'] => $db->str('CoFDummy')
						)
					);
					$neu_kid=intval($db->insertid());
					$db->delete(
						$sql_tab['stammdaten'],
						$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($neu_kid)
					);
					$neukid_drin=true;
				}

				$postfeld['co_anrede']=_FIRMA_;
				$postfeld['co_vorname']=$manda_id;
				$postfeld['co_name']='CoDummy';
				$postfeld['co_firma1']='CoDummy';

				$co_anzeigename=eingabe2anzeigename($postfeld['co_vorname'], $postfeld['co_name'], $postfeld['co_titel'], $postfeld['co_firma1'], $postfeld['co_anrede']);

				$db->insert(
					$sql_tab['stammdaten'],
					array(
					$sql_tabs['stammdaten']['id'] => $db->dbzahl($neu_kid),
					$sql_tabs['stammdaten']['mandant'] => $db->dbzahl($manda_id),
					$sql_tabs['stammdaten']['anrede'] => $db->str($postfeld['co_anrede']),
					$sql_tabs['stammdaten']['titel'] => $db->str($postfeld['co_titel']),
					$sql_tabs['stammdaten']['vorname'] => $db->str($postfeld['co_vorname']),
					$sql_tabs['stammdaten']['name'] => $db->str($postfeld['co_name']),
					$sql_tabs['stammdaten']['firma1'] => $db->str($postfeld['co_firma1']),
					$sql_tabs['stammdaten']['betreuer'] => $db->dbzahl($ang_kv_user),
					$sql_tabs['stammdaten']['anzeigename'] => $db->str($co_anzeigename),
					$sql_tabs['stammdaten']['meinvp'] => $db->dbzahl(0),
					$sql_tabs['stammdaten']['Telefon_1'] => $db->str(''),
					$sql_tabs['stammdaten']['Mobilfon_1'] => $db->str(''),
					$sql_tabs['stammdaten']['Fax_1'] => $db->str(''),
					$sql_tabs['stammdaten']['EMail_1'] => $db->str(''),
					$sql_tabs['stammdaten']['erstellt_benutzer'] => $db->dbzahl($_SESSION['user_id']),
					$sql_tabs['stammdaten']['erstellt_datum'] => $db->dbtimestamp(time()),
					$sql_tabs['stammdaten']['syncml_letzte_aenderung'] => $db->dbtimestamp(time())
					)
				);
				$db->insert(
					$sql_tab['stammdaten_gruppe_zuordnung'],
					array(
						$sql_tabs['stammdaten_gruppe_zuordnung']['gruppe_id'] => $db->dbzahl($grbez),
						$sql_tabs['stammdaten_gruppe_zuordnung']['stammdaten_id'] => $db->dbzahl($neu_kid)
					)
				);
			}

			unset($postfeld['co_neukunde']);
			$postfeld['co_stid']=$neu_kid;
		//	$_SESSION['stammdaten_id']=$neu_kid;
		}

		// merke die inhalt vor bearbeitung:
		$mpostfeld=$postfeld;
		if ($cfg_kfzsuche_tausenderpunkt and $cfg_nova_wltp) {
			$mpostfeld['listenpreis5']=str_replace('.', '', $mpostfeld['listenpreis5']);
			if (preg_match('/,/', $mpostfeld['listenpreis5'])) {
				$mpostfeld['listenpreis5']=str_replace(',', '.', $mpostfeld['listenpreis5']);
			}
			$mpostfeld['vertrag5_farbepreis']=str_replace('.', '', $mpostfeld['vertrag5_farbepreis']);
			if (preg_match('/,/', $mpostfeld['vertrag5_farbepreis'])) {
				$mpostfeld['vertrag5_farbepreis']=str_replace(',', '.', $mpostfeld['vertrag5_farbepreis']);
			}
			$mpostfeld['vertrag5_trimpreis']=str_replace('.', '', $mpostfeld['vertrag5_trimpreis']);
			if (preg_match('/,/', $mpostfeld['vertrag5_farbepreis'])) {
				$mpostfeld['vertrag5_trimpreis']=str_replace(',', '.', $mpostfeld['vertrag5_trimpreis']);
			}
		}
		
		if ($cfg_kfzsuche_holland and $postfeld['firma3']!='') {
			$postfeld['vorname'].=' '.$postfeld['firma3'];
			$postfeld['vorname']=trim($postfeld['vorname']);
		}

		$anzeigename=eingabe2anzeigename($postfeld['vorname'], $postfeld['name'], $postfeld['titel'], $postfeld['firma1'], $postfeld['anrede']);

		// Co-Holder NeuKunden anlegen:
		$m_stid1=$_SESSION['stammdaten_id'];
		$co_anzeigename=eingabe2anzeigename($postfeld['co_vorname'], $postfeld['co_name'], $postfeld['co_titel'], $postfeld['co_firma1'], $postfeld['co_anrede']);
		if (!$vorschau and isset($postfeld['coholder']) and isset($postfeld['co_neukunde'])) {
			$grbez=0;
			$grbez2=0;
			$res=$db->select(
				$sql_tab['stammdaten_gruppe'],
				array(
					$sql_tabs['stammdaten_gruppe']['gruppe_id'],
					$sql_tabs['stammdaten_gruppe']['bezeichnung']
				),
				$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('Interessenten CRM').' or '.
					$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('CRM Interessenten').' or '.
					$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('CRM Prospects').' or '.
					$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('CRM')
			);
			if ($row=$db->zeile($res)) {
				$grbez=$row[0];
				$grbez2=$row[1];
			}

			$minmax=array(1000000, 9999999);
			if (isset($cfg_min_nra[$grbez2])) {
				$xpl3=explode('-', $cfg_min_nra[$grbez2]);
				if (count($xpl3)==2) {
					$minmax=array($xpl3[0], $xpl3[1]);
				}
			}
			$res=$db->select(
					$sql_tab['stammdaten'],
					'max('.$sql_tabs['stammdaten']['id'].')+1',
					$sql_tabs['stammdaten']['id'].' between '.$minmax[0].' and '.$minmax[1]
			);
			$row=$db->zeile($res);
			$neu_kid=intval($row[0]);
			if ($neu_kid<$minmax[0]) {
				$neu_kid=$minmax[0];
			}

			$neukid_drin=false;
				if ($neu_kid>intval($minmax[1])) {
					$db->insert(
						$sql_tab['stammdaten'],
						array(
							$sql_tabs['stammdaten']['name'] => $db->str('FDummy')
						)
					);
					$neu_kid=intval($db->insertid());
					$db->delete(
						$sql_tab['stammdaten'],
						$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($neu_kid)
					);
					$neukid_drin=true;
				}

				if (!$neukid_drin) {

			if ($neu_kid<=0) {
				$neu_kid=intval($minmax[0]);
			} elseif ($neu_kid<=intval($minmax[1])) {
				$neu_kid=intval($row[0]);
			} else {
				if (!isset($min_nra[$grbez])) {
					die('Kein Kunde mehr frei.');
				} else {
					die('Kein Kunde mehr in der Gruppe '.$grbez.' ('.$min_nra[$grbez].') frei.');
				}
			}
					}
			$db->insert(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['id'] => $db->dbzahl($neu_kid),
					$sql_tabs['stammdaten']['mandant'] => $db->dbzahl($manda_id),
					$sql_tabs['stammdaten']['anrede'] => $db->str($postfeld['co_anrede']),
					$sql_tabs['stammdaten']['titel'] => $db->str($postfeld['co_titel']),
					$sql_tabs['stammdaten']['vorname'] => $db->str($postfeld['co_vorname']),
					$sql_tabs['stammdaten']['name'] => $db->str($postfeld['co_name']),
					$sql_tabs['stammdaten']['firma1'] => $db->str($postfeld['co_firma1']),
					$sql_tabs['stammdaten']['firma2'] => $db->str($postfeld['co_firma2']),
					$sql_tabs['stammdaten']['firma3'] => $db->str($postfeld['co_firma3']),
					$sql_tabs['stammdaten']['betreuer'] => $db->dbzahl($ang_kv_user),
					$sql_tabs['stammdaten']['anzeigename'] => $db->str($co_anzeigename),
					$sql_tabs['stammdaten']['meinvp'] => $db->dbzahl(0),
					$sql_tabs['stammdaten']['Telefon_1'] => $db->str($postfeld['co_telefon']),
					$sql_tabs['stammdaten']['Mobilfon_1'] => $db->str($postfeld['co_mobilfon']),
					$sql_tabs['stammdaten']['Fax_1'] => $db->str($postfeld['co_fax']),
					$sql_tabs['stammdaten']['EMail_1'] => $db->str($postfeld['co_email']),
					$sql_tabs['stammdaten']['Telefon_2'] => $db->str($postfeld['co_telefon2']),
					$sql_tabs['stammdaten']['Mobilfon_2'] => $db->str($postfeld['co_mobilfon2']),
					$sql_tabs['stammdaten']['Fax_2'] => $db->str($postfeld['co_fax2']),
					$sql_tabs['stammdaten']['EMail_2'] => $db->str($postfeld['co_email2']),
					$sql_tabs['stammdaten']['geburtstag'] => $db->dbdate($postfeld['co_geburtsdatum']),
					$sql_tabs['stammdaten']['geburtsort'] => $db->str($postfeld['co_geburtsort']),
					$sql_tabs['stammdaten']['idstatus'] => $db->str($postfeld['co_idstatus']),
					$sql_tabs['stammdaten']['steuernummer'] => $db->str($postfeld['co_steuernummer']),
					$sql_tabs['stammdaten']['fleetnummer'] => $db->str($postfeld['co_steuernummer2']),
					$sql_tabs['stammdaten']['beruf'] => $db->str($postfeld['co_beruf']),
					$sql_tabs['stammdaten']['erstellt_benutzer'] => $db->dbzahl($_SESSION['user_id']),
					$sql_tabs['stammdaten']['erstellt_datum'] => $db->dbtimestamp(time()),
					$sql_tabs['stammdaten']['syncml_letzte_aenderung'] => $db->dbtimestamp(time()),
					$sql_tabs['stammdaten']['source'] => $db->str('kfzsuche')
				)
			);
			$_SESSION['stammdaten_id']=$neu_kid;//$db->insertid();
			$postfeld['co_stid']=$neu_kid;
			if (intval($neu_kid)>0) {
				suchfeld_update($neu_kid);
			}

			if (isset($postfeld['wf_sgruppe_id'])) {
				if (intval($postfeld['wf_sgruppe_id'])>0) {
					$db->insert(
						$sql_tab['stammdaten_gruppe_zuordnung'],
						array(
							$sql_tabs['stammdaten_gruppe_zuordnung']['gruppe_id'] => $db->dbzahl($postfeld['wf_sgruppe_id']),
							$sql_tabs['stammdaten_gruppe_zuordnung']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id'])
						)
					);
				}
			}

			$x=$db->insert(
					$sql_tab['stammdaten_adresse'],
					array(
						$sql_tabs['stammdaten_adresse']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
						$sql_tabs['stammdaten_adresse']['adresse'] 		=> $db->str($postfeld['co_adresse']),
						$sql_tabs['stammdaten_adresse']['plz']	 		=> $db->str($postfeld['co_plz']),
						$sql_tabs['stammdaten_adresse']['ort'] 			=> $db->str($postfeld['co_ort']),
						$sql_tabs['stammdaten_adresse']['land']	 		=> $db->str($std_land),
						$sql_tabs['stammdaten_adresse']['art']	 		=> 0,
						$sql_tabs['stammdaten_adresse']['post'] 		=> 1,
						$sql_tabs['stammdaten_adresse']['beginn'] 		=> $db->dbdate(time()),
						$sql_tabs['stammdaten_adresse']['ende'] 		=> 0,
						$sql_tabs['stammdaten_adresse']['mandant_id']	=> $db->dbzahl($manda_id),
						$sql_tabs['stammdaten_adresse']['zusatz2']		=> $db->str($postfeld['co_county'])
					)
			);
			$db->insert(
					$sql_tab['stammdaten_gruppe_zuordnung'],
					array(
						$sql_tabs['stammdaten_gruppe_zuordnung']['gruppe_id'] => $db->dbzahl($grbez),
						$sql_tabs['stammdaten_gruppe_zuordnung']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id'])
					)
			);
			$res2=$db->select(
						$sql_tab['formular'],
						array(
							$sql_tabs['formular']['bezeichnung'],
							$sql_tabs['formular']['vorlage']
						),
						$sql_tabs['formular']['formular_id'].'='.$db->dbzahl(1)
			);
			$row2=$db->zeile($res2);
			$bez_f=$row2[0];
			$kfeld3=array(
								$sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['wvl_datum1'] => 0,
								$sql_tabs['korrespondenz']['wvl_datum2'] => 0,
								$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
								$sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
								$sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['eingang'] => 0,
								$sql_tabs['korrespondenz']['art'] => $db->dbzahl(14),
								$sql_tabs['korrespondenz']['kategorie'] => $db->str(_FORMULARE_),
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
								$sql_tabs['korrespondenz']['parent_id'] => 0,
								$sql_tabs['korrespondenz']['doclink'] => $db->str(''),
								$sql_tabs['korrespondenz']['betreff'] => $db->str($bez_f),
								$sql_tabs['korrespondenz']['beschreibung'] => $db->str(''),
								$sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['papierkorb'] => 0,
								$sql_tabs['korrespondenz']['kalender_id'] => 0,
								$sql_tabs['korrespondenz']['prioritaet'] => 0,
								$sql_tabs['korrespondenz']['negativ'] => 0,
								$sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_nr'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_FORMULAR_),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str(_FORMULAR_),
								$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($ang_kv_user)
			);
			$allesok=$db->insert(
				$sql_tab['korrespondenz'],
				$kfeld3
			);
			
		// neu:
			$alte_id=0;
			if ($cfg_carlo_appserver_cog_adressid) {
								$res6=$db->select(
									$sql_tab['stammdaten_mandant'],
									array(
										$sql_tabs['stammdaten_mandant']['mandant_id'],
										$sql_tabs['stammdaten_mandant']['lagerort'],
										$sql_tabs['stammdaten_mandant']['nummer1'],
										$sql_tabs['stammdaten_mandant']['nummer2']
									),
									$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
										$sql_tabs['stammdaten_mandant']['mandant_id'].'!='.$db->dbzahl($manda_id).' and '.
									//	$sql_tabs['stammdaten_mandant']['nummer1'].'='.$db->str('')
									'('.$sql_tabs['stammdaten_mandant']['nummer1'].'!='.$db->str('').' or '.
										$sql_tabs['stammdaten_mandant']['nummer2'].'!='.$db->str('').')'
								);
								if ($row6=$db->zeile($res6)) {
									$alte_id=$_SESSION['stammdaten_id'];
								}
			}

			$post=$postfeld;
			if ($cfg_carlo_appserver_kv_deb and $postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
				$mcfg_carlo_appserver_neu_deb=$cfg_carlo_appserver_neu_deb;
				$cfg_carlo_appserver_neu_deb=true;
				capps_updatekunde($_SESSION['stammdaten_id'], true, $alte_id);
				$cfg_carlo_appserver_neu_deb=$mcfg_carlo_appserver_neu_deb;
			} elseif (!$cfg_carlo_appserver_keineinteressenten) {
				capps_updatekunde($_SESSION['stammdaten_id'], true, $alte_id);
			}
			if ($cfg_ws_avag_kroatien and $postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
				$postfeld['betreuer']=$_SESSION['user_id'];
				ws_kroa($_SESSION['stammdaten_id'], true);
			}
			if ($cfg_werbas_stx3) {
				$werbas_ist_kfzsuche_neu=true;
				werbas_erstelle_xml($_SESSION['stammdaten_id']);
			}
			if ($cfg_pundf) {
				/*include('inc/pundf.php');
				set_pundf_customer($_SESSION['stammdaten_id'], true);*/
                PearAutoLoader::instance()->addSourceRoot('inc/servers');
                $outbox = new Pundf_Outbox();
                $outbox->activate($_SESSION['stammdaten_id']);
			}
		} elseif (!$vorschau and isset($postfeld['coholder'])) {
			$_SESSION['stammdaten_id']=$postfeld['co_stid'];
			$upsqlt=array(
					$sql_tabs['stammdaten']['anrede'] => $db->str($postfeld['co_anrede']),
					$sql_tabs['stammdaten']['titel'] => $db->str($postfeld['co_titel']),
					$sql_tabs['stammdaten']['vorname'] => $db->str($postfeld['co_vorname']),
					$sql_tabs['stammdaten']['name'] => $db->str($postfeld['co_name']),
					$sql_tabs['stammdaten']['firma1'] => $db->str($postfeld['co_firma1']),
					$sql_tabs['stammdaten']['anzeigename'] => $db->str($co_anzeigename)
			);
			if (isset($postfeld['steuernummer'])) {
				$upsqlt[$sql_tabs['stammdaten']['steuernummer']]=$db->str($postfeld['co_steuernummer']);
			}
			if (isset($postfeld['steuernummer2'])) {
				$upsqlt[$sql_tabs['stammdaten']['fleetnummer']]=$db->str($postfeld['co_steuernummer2']);
			}
			if ($cfg_kfzsuche_kv_betreuer and $postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
				$upsqlt[$sql_tabs['stammdaten']['betreuer']]=$db->dbzahl($_SESSION['user_id']);
			}
			$db->update(
				$sql_tab['stammdaten'],
				$upsqlt,
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
			);
			$sqlt_adr=array(
						$sql_tabs['stammdaten_adresse']['adresse'] 		=> $db->str($postfeld['co_adresse']),
						$sql_tabs['stammdaten_adresse']['plz']	 		=> $db->str($postfeld['co_plz']),
						$sql_tabs['stammdaten_adresse']['ort'] 			=> $db->str($postfeld['co_ort'])
			);
			if (isset($postfeld['co_county'])) {
				$sqlt_adr[$sql_tabs['stammdaten_adresse']['zusatz2']]=$db->str($postfeld['co_county']);
			}
            if (isset($sql_tabs['stammdaten_adresse']['mandanten_entfernung']) && file_exists('_plz_distanz_nachberechnung.php')) {
                $sqlt_adr[$sql_tabs['stammdaten_adresse']['mandanten_entfernung']] = 'null';
            }
			$db->update(
					$sql_tab['stammdaten_adresse'],
					$sqlt_adr,
					$sql_tabs['stammdaten_adresse']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
						$sql_tabs['stammdaten_adresse']['art'].'=0'
			);

			if (!$ohnek2) {
				$upda=true;
				$res5=$db->select(
								$sql_tab['stammdaten_mandant'],
								array(
									$sql_tabs['stammdaten_mandant']['mandant_id'],
									$sql_tabs['stammdaten_mandant']['lagerort'],
									$sql_tabs['stammdaten_mandant']['nummer1'],
									$sql_tabs['stammdaten_mandant']['nummer2']
								),
								$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
								$sql_tabs['stammdaten_mandant']['mandant_id'].'='.$db->dbzahl($manda_id).' and '.
									$sql_tabs['stammdaten_mandant']['nummer1'].'!='.$db->str('')
				);
				if ($db->anzahl($res5)==0) {
					if ($cfg_carlo_appserver_kv_deb and $postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						$c_updaten=false;
						if ($cfg_carlo_appserver_cog_int2deb) {
							$res6=$db->select(
								$sql_tab['stammdaten_mandant'],
								array(
									$sql_tabs['stammdaten_mandant']['mandant_id'],
									$sql_tabs['stammdaten_mandant']['lagerort'],
									$sql_tabs['stammdaten_mandant']['nummer1'],
									$sql_tabs['stammdaten_mandant']['nummer2']
								),
								$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
								$sql_tabs['stammdaten_mandant']['mandant_id'].'='.$db->dbzahl($manda_id).' and '.
									$sql_tabs['stammdaten_mandant']['nummer2'].'!='.$db->str('')
							);
							if ($row6=$db->zeile($res6)) {
								$rg=capps_int2deb($row6[3], $manda_id);
								if (p4n_mb_string('substr',$rg, 0, 6)!='Fehler') {
									$db->update(
										$sql_tab['stammdaten_mandant'],
										array(
											$sql_tabs['stammdaten_mandant']['nummer1'] => $db->str($rg)
										),
										$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
											$sql_tabs['stammdaten_mandant']['mandant_id'].'='.$db->dbzahl($manda_id)
									);
								}
							} else {
								$c_updaten=true;
							}
						} else {
							$c_updaten=true;
						}
						if ($c_updaten) {
							$alte_id=0;
							if ($cfg_carlo_appserver_cog_adressid) {
								$res6=$db->select(
									$sql_tab['stammdaten_mandant'],
									array(
										$sql_tabs['stammdaten_mandant']['mandant_id'],
										$sql_tabs['stammdaten_mandant']['lagerort'],
										$sql_tabs['stammdaten_mandant']['nummer1'],
										$sql_tabs['stammdaten_mandant']['nummer2']
									),
									$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
										$sql_tabs['stammdaten_mandant']['mandant_id'].'!='.$db->dbzahl($manda_id).' and '.
										'('.$sql_tabs['stammdaten_mandant']['nummer1'].'!='.$db->str('').' or '.$sql_tabs['stammdaten_mandant']['nummer2'].'!='.$db->str('').')'
								);
								if ($row6=$db->zeile($res6)) {
									$alte_id=$_SESSION['stammdaten_id'];
								}
							}
							$mcfg_carlo_appserver_neu_deb=$cfg_carlo_appserver_neu_deb;
							$cfg_carlo_appserver_neu_deb=true;
							$post=$postfeld;
							capps_updatekunde($_SESSION['stammdaten_id'], true, $alte_id);
							$cfg_carlo_appserver_neu_deb=$mcfg_carlo_appserver_neu_deb;
							$upda=false;
						}
					}
				}

				if ($upda) {
					capps_updatekunde($_SESSION['stammdaten_id'], false);
				}
				
				if ($cfg_ws_avag_kroatien) {
					if ($db->anzahl($res5)>0) {
						ws_kroa($_SESSION['stammdaten_id'], false);
					} elseif ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						$postfeld['betreuer']=$_SESSION['user_id'];
						ws_kroa($_SESSION['stammdaten_id'], true);
					}
				}
				
				if ($cfg_zls_rueck and isset($cfg_zls_rueck_nurbg) and $cfg_zls_rueck_nurbg!='') {
					$res7=$db->select(
						$sql_tab['benutzer_gruppe'],
						array(
							$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
							$sql_tabs['benutzer_gruppe']['bezeichnung']
						),
						$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str($cfg_zls_rueck_nurbg)
					);
					if ($row7=$db->zeile($res7)) {
						if ($_SESSION['rechte_bgruppen']=='-1' or preg_match('/,'.$row7[0].',/', ','.$_SESSION['rechte_bgruppen'].',')) {
							// kann zur�ckschreiben
						} else {
							$cfg_zls_rueck=false;
						}
					}
				}
				if ($cfg_zls_rueck) {
					include_once('inc/zls.php');
					if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						zls_writecustomer($_SESSION['stammdaten_id'], true);
					}
				}
				if ($cfg_f1allg_rueck) {
					include_once('inc/f1allg.php');
					if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						f1allg_writecustomer($_SESSION['stammdaten_id'], true);
					}
				}
				if ($cfg_md_rueck) {
					include_once('inc/lib_md.php');
					if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						md_writecustomer($_SESSION['stammdaten_id'], true);
					}
				}
				if ($cfg_vx_rueck) {
					include_once('inc/lib_vaudisx.php');
					if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						vx_writecustomer($_SESSION['stammdaten_id'], true);
					}
				}
				if ($cfg_attribut_rueck) {
					include_once('inc/lib_attr.php');
					if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						attr_writecustomer($_SESSION['stammdaten_id'], true);
					}
				}
				if ($cfg_loco_rueck) {
					include_once('inc/lib_loco.php');
					if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						loco_writecustomer($_SESSION['stammdaten_id'], true);
					}
				}
				if ($cfg_ecaros_rueck) {
					include_once('inc/lib_ecaros.php');
					if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						ecaros_writecustomer($_SESSION['stammdaten_id'], true);
					}
				}
				if ($cfg_betzemeier_rueck && $postfeld['submit1'] === _KAUFVERTRAG_.' '._ERSTELLEN_) {
                    Betzemeier::writeCustomer($_SESSION['stammdaten_id'], true);
                }
			}
		}
		$_SESSION['stammdaten_id']=$m_stid1;
		
		if (!$cfg_idms and ($_SESSION['cfg_kunde']=='carlo_opel_dello') and !$vorschau and ($postfeld['stid'])>0 and $bez_ang_kv==_KAUFVERTRAG_ and $_SESSION['stammdaten_id']>1000000) {
				$neu_kid=kfzs_schreibe_stid('');
				$db->insert(
						$sql_tab['stammdaten'],
						array(
							$sql_tabs['stammdaten']['id'] => $db->dbzahl($neu_kid),
							$sql_tabs['stammdaten']['name'] => $db->str('FDummy'),
							$sql_tabs['stammdaten']['source'] => $db->str('kfzsuche')
						)
				);
				$_SESSION['stammdaten_id']=$postfeld['stid'];
				$stid_neu=$neu_kid;
				
				$mfm=$ADODB_FETCH_MODE;
								$ADODB_FETCH_MODE=ADODB_FETCH_ASSOC;
								$res5=$db->select(
									$sql_tab['stammdaten'],
									'*',
									$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
								);
								$zielf=array();
								if ($row5=$db->zeile($res5)) {
									$stiz1=0;
									while (list($keyk, $valk)=@each($row5)) {
										if (!is_numeric($keyk) and $keyk!='stammdaten_id' and $keyk!='id') {
											$val=$valk;
                                            if (!is_array($sql_meta['stammdaten'][$keyk])) {
                                                $sql_meta['stammdaten'][$keyk]=array();
                                            }
											if (@in_array('D', $sql_meta['stammdaten'][$keyk]) or @in_array('T', $sql_meta['stammdaten'][$keyk]) or preg_match('/\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d/', $valk)) {
												$valk=$db->unixdate_ts($valk);
												$val=$db->dbtimestamp($valk);
											} elseif (@in_array('I', $sql_meta['stammdaten'][$keyk]) or @in_array('L', $sql_meta['stammdaten'][$keyk]) or @in_array('F', $sql_meta['stammdaten'][$keyk]) or @in_array('N', $sql_meta['stammdaten'][$keyk])) {
												$val=$db->dbzahl($valk);
											} else {
												$val=$db->str($valk);
											}
											$zielf[$keyk]=$val;
											if ($stiz1>10) {
												$stiz1=0;
												$db->update(
													$sql_tab['stammdaten'],
													$zielf,
													$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($stid_neu)
												);
												$zielf=array();
											}
											$stiz1++;
										}
									}
									if (count($zielf)>0) {
										$db->update(
											$sql_tab['stammdaten'],
											$zielf,
											$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($stid_neu)
										);
									}
								}
				$ADODB_FETCH_MODE=$mfm;
				zusammenf2($_SESSION['stammdaten_id'], $neu_kid);
				$stid=$neu_kid;
				$postfeld['stid']=$stid;
				$_SESSION['stammdaten_id']=$stid;
				
				$db->insert(
					$sql_tab['log_aenderung'],
					array(
					$sql_tabs['log_aenderung']['datum'] => $db->dbtimestamp(time()),
					$sql_tabs['log_aenderung']['benutzer_id'] => $db->dbzahl($_SESSION['user_id']),
					$sql_tabs['log_aenderung']['tabelle'] => $db->str('Neueintrag Stammdaten'),
					$sql_tabs['log_aenderung']['feldname'] => $db->str('name'),
					$sql_tabs['log_aenderung']['feldinhalt_alt'] => $db->str('KV'),
					$sql_tabs['log_aenderung']['feldinhalt_neu'] => $db->str(trim($postfeld['vorname'].' '.$postfeld['name'].' '.$postfeld['firma1'])),
					$sql_tabs['log_aenderung']['zusatz1'] => $db->str($neu_kid),
					$sql_tabs['log_aenderung']['zusatz2'] => $db->str('')
					)
				);
		}
		
		$war_int1=true;
		if (!isset($postfeld['neukunde'])) {
			$res6=$db->select(
				$sql_tab['stammdaten_mandant'],
				array(
					$sql_tabs['stammdaten_mandant']['nummer1'],
					$sql_tabs['stammdaten_mandant']['nummer2']
				),
				$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
			);
			if ($row6=$db->zeile($res6)) {
				if ($row6[0]!='' or $row6[1]!='') {
					$war_int1=false;
				}
			}
		}
		
		// Neukunden anlegen?
		if (!$vorschau and isset($postfeld['neukunde'])) {
			
			$grbez=0;
			$grbez2=0;
			$res=$db->select(
				$sql_tab['stammdaten_gruppe'],
				array(
					$sql_tabs['stammdaten_gruppe']['gruppe_id'],
					$sql_tabs['stammdaten_gruppe']['bezeichnung']
				),
				$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('Interessenten CRM').' or '.
					$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('CRM Interessenten').' or '.
					$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('CRM Prospects').' or '.
					$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('CRM')
			);
			if ($row=$db->zeile($res)) {
				$grbez=$row[0];
				$grbez2=$row[1];
			}
			
			if ($_SESSION['cfg_kunde']=='carlo_opel_dello') {
				$neu_kid=kfzs_schreibe_stid('');
				
				$db->insert(
					$sql_tab['log_aenderung'],
					array(
					$sql_tabs['log_aenderung']['datum'] => $db->dbtimestamp(time()),
					$sql_tabs['log_aenderung']['benutzer_id'] => $db->dbzahl($_SESSION['user_id']),
					$sql_tabs['log_aenderung']['tabelle'] => $db->str('Neueintrag Stammdaten'),
					$sql_tabs['log_aenderung']['feldname'] => $db->str('name'),
					$sql_tabs['log_aenderung']['feldinhalt_alt'] => $db->str(''),
					$sql_tabs['log_aenderung']['feldinhalt_neu'] => $db->str(trim($postfeld['vorname'].' '.$postfeld['name'].' '.$postfeld['firma1'])),
					$sql_tabs['log_aenderung']['zusatz1'] => $db->str($neu_kid),
					$sql_tabs['log_aenderung']['zusatz2'] => $db->str('')
					)
				);
			} else {
			
			$minmax=array(1000000, 9999999);
			if (isset($cfg_min_nra[$grbez2])) {
				$xpl3=explode('-', $cfg_min_nra[$grbez2]);
				if (count($xpl3)==2) {
					$minmax=array($xpl3[0], $xpl3[1]);
				}
			}
			$res=$db->select(
					$sql_tab['stammdaten'],
					'max('.$sql_tabs['stammdaten']['id'].')+1',
					$sql_tabs['stammdaten']['id'].' between '.$minmax[0].' and '.$minmax[1]
			);
			$row=$db->zeile($res);
			$neu_kid=intval($row[0]);
			if ($neu_kid<$minmax[0]) {
				$neu_kid=$minmax[0];
			}

			$neukid_drin=false;
				if ($neu_kid>=intval($minmax[0])) {
					$db->insert(
						$sql_tab['stammdaten'],
						array(
							$sql_tabs['stammdaten']['name'] => $db->str('FDummy')
						)
					);
					$neu_kid=intval($db->insertid());
					$db->delete(
						$sql_tab['stammdaten'],
						$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($neu_kid)
					);
					$neukid_drin=true;
				}

				if (!$neukid_drin) {

			if ($neu_kid<=0) {
				$neu_kid=intval($minmax[0]);
			} elseif ($neu_kid<=intval($minmax[1])) {
				$neu_kid=intval($row[0]);
			} else {
				if (!isset($min_nra[$grbez])) {
					die('Kein Kunde mehr frei.');
				} else {
					die('Kein Kunde mehr in der Gruppe '.$grbez.' ('.$min_nra[$grbez].') frei.');
				}
			}
					}
			
			}
			
			if ($cfg_kfzsuche_kontakt_pg) {
				// telefon 2 nicht �berschreiben
			} elseif (($postfeld['firma1']!='' || $cfg_greek || $cfg_kfzsuche_norway) && $_SESSION['cfg_kunde'] !== 'carlo_koltes') {
				$postfeld['telefon2']=$postfeld['telefon'];
				$postfeld['telefon']='';
				$postfeld['mobilfon2']=$postfeld['mobilfon'];
				$postfeld['mobilfon']='';
				$postfeld['fax2']=$postfeld['fax'];
				$postfeld['fax']='';
				$postfeld['email2']=$postfeld['email'];
				$postfeld['email']='';
			}
			
			$briefanr=_BRIEFANREDE_FIRMA_;
			if (p4n_mb_string('strtolower',$postfeld['anrede'])==p4n_mb_string('strtolower',_HERR_) or p4n_mb_string('strtolower',$postfeld['anrede'])=='herrn') {
				$briefanr=_BRIEFANREDE_HERR_;
			} elseif (p4n_mb_string('strtolower',$postfeld['anrede'])==p4n_mb_string('strtolower',_FRAU_)) {
				$briefanr=_BRIEFANREDE_FRAU_;
			}
			if ($cfg_kfzsuche_holland) {
				$briefanr='';
				if (p4n_mb_string('strtolower',$postfeld['anrede'])==p4n_mb_string('strtolower',_HERR_) or p4n_mb_string('strtolower',$postfeld['anrede'])=='herrn') {
					$briefanr=_BRIEFANREDE_HERR_;
				} elseif (p4n_mb_string('strtolower',$postfeld['anrede'])==p4n_mb_string('strtolower',_FRAU_)) {
					$briefanr=_BRIEFANREDE_FRAU_;
				}
				if ($cfg_carlo_appserver_ws and $briefanr=='') {
					$res9=$db->select(
						$sql_tab['stammdaten'],
						$sql_tabs['stammdaten']['briefanrede'],
						$sql_tabs['stammdaten']['anrede'].'='.$db->str($postfeld['anrede']).' and '.$sql_tabs['stammdaten']['briefanrede'].'!='.$db->str('')
					);
					$alle_ba=array();
					while ($row9=$db->zeile($res9)) {
						$alle_ba[$row9[0]]++;
					}
					@arsort($alle_ba);
					if (list($key, $val)=@each($alle_ba)) {
						$briefanr=$key;
					}
				}
			}
			if ($postfeld['anrede']=='') {
				$briefanr='';
			}
			
			$db->insert(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['id'] => $db->dbzahl($neu_kid),
					$sql_tabs['stammdaten']['mandant'] => $db->dbzahl($manda_id),
					$sql_tabs['stammdaten']['vpb'] => $db->dbzahl($lago_id),
					$sql_tabs['stammdaten']['anrede'] => $db->str($postfeld['anrede']),
					$sql_tabs['stammdaten']['anredecode'] => $db->str($postfeld['anredecode']),
					$sql_tabs['stammdaten']['briefanrede'] => $db->str($briefanr),
					$sql_tabs['stammdaten']['titel'] => $db->str($postfeld['titel']),
					$sql_tabs['stammdaten']['vorname'] => $db->str($postfeld['vorname']),
					$sql_tabs['stammdaten']['name'] => $db->str($postfeld['name']),
					$sql_tabs['stammdaten']['firma1'] => $db->str($postfeld['firma1']),
					$sql_tabs['stammdaten']['firma2'] => $db->str($postfeld['firma2']),
					$sql_tabs['stammdaten']['firma3'] => $db->str($postfeld['firma3']),
					$sql_tabs['stammdaten']['betreuer'] => $db->dbzahl($ang_kv_user),
					$sql_tabs['stammdaten']['anzeigename'] => $db->str($anzeigename),
					$sql_tabs['stammdaten']['meinvp'] => $db->dbzahl(0),
					$sql_tabs['stammdaten']['Telefon_1'] => $db->str($postfeld['telefon']),
					$sql_tabs['stammdaten']['Mobilfon_1'] => $db->str($postfeld['mobilfon']),
					$sql_tabs['stammdaten']['Fax_1'] => $db->str($postfeld['fax']),
					$sql_tabs['stammdaten']['EMail_1'] => $db->str($postfeld['email']),
					$sql_tabs['stammdaten']['Telefon_2'] => $db->str($postfeld['telefon2']),
					$sql_tabs['stammdaten']['Mobilfon_2'] => $db->str($postfeld['mobilfon2']),
					$sql_tabs['stammdaten']['Fax_2'] => $db->str($postfeld['fax2']),
					$sql_tabs['stammdaten']['EMail_2'] => $db->str($postfeld['email2']),
					$sql_tabs['stammdaten']['geburtstag'] => $db->dbdate($postfeld['geburtsdatum']),
					$sql_tabs['stammdaten']['geburtsort'] => $db->str($postfeld['geburtsort']),
					$sql_tabs['stammdaten']['idstatus'] => $db->str($postfeld['idstatus']),
					$sql_tabs['stammdaten']['steuernummer'] => $db->str($postfeld['steuernummer']),
					$sql_tabs['stammdaten']['fleetnummer'] => $db->str($postfeld['steuernummer2']),
					$sql_tabs['stammdaten']['beruf'] => $db->str($postfeld['beruf']),
					$sql_tabs['stammdaten']['branche'] => $db->str($postfeld['branche']),
					$sql_tabs['stammdaten']['hobby'] => $db->str($postfeld['hobby']),
					$sql_tabs['stammdaten']['erstellt_benutzer'] => $db->dbzahl($_SESSION['user_id']),
					$sql_tabs['stammdaten']['erstellt_datum'] => $db->dbtimestamp(time()),
					$sql_tabs['stammdaten']['syncml_letzte_aenderung'] => $db->dbtimestamp(time()),
					$sql_tabs['stammdaten']['source'] => $db->str('kfzsuche')
					//vpnr
				)
			);
			$_SESSION['stammdaten_id']=$neu_kid;//$db->insertid();
			$postfeld['stid']=$neu_kid;
			if (intval($neu_kid)>0) {
				suchfeld_update($neu_kid);
				if (is_file('inc/nachneuanlage.php')) {
					include_once('inc/nachneuanlage.php');
					nachneuanlage($neu_kid);
				}
			}
			if (isset($cfg_kfzsuche_kundendaten_zusatz2) and $cfg_kfzsuche_kundendaten_zusatz2!='') {
				$db->update(
						$sql_tab['stammdaten'],
						array(
							$sql_tabs['stammdaten']['zusatz2'] => $db->str($postfeld['kuzusatz2'])
						),
						$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
				);
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_dello') {
				if ($postfeld['familienstand']=='-1') {
					$postfeld['familienstand']='';
				}
				$res2=$db->select(
					$sql_tab['zusatzfelder'],
					$sql_tabs['zusatzfelder']['stammdaten_id'],
					$sql_tabs['zusatzfelder']['stammdaten_id'].'='.$db->dbzahl($neu_kid)
				);
				if ($row2=$db->zeile($res2)) {
					$res2=$db->update(
						$sql_tab['zusatzfelder'],
						array(
							'zf_2' => $db->str($postfeld['familienstand'])
						),
						$sql_tabs['zusatzfelder']['stammdaten_id'].'='.$db->dbzahl($neu_kid)
					);
				} else {
					$res2=$db->insert(
						$sql_tab['zusatzfelder'],
						array(
							'zf_2' => $db->str($postfeld['familienstand']),
							$sql_tabs['zusatzfelder']['stammdaten_id'] => $db->dbzahl($neu_kid)
						)
					);
				}
			}
			if (isset($postfeld['wf_sgruppe_id'])) {
				if (intval($postfeld['wf_sgruppe_id'])>0) {
					$db->insert(
						$sql_tab['stammdaten_gruppe_zuordnung'],
						array(
							$sql_tabs['stammdaten_gruppe_zuordnung']['gruppe_id'] => $db->dbzahl($postfeld['wf_sgruppe_id']),
							$sql_tabs['stammdaten_gruppe_zuordnung']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id'])
						)
					);
				}
			}

			$x=$db->insert(
					$sql_tab['stammdaten_adresse'],
					array(
						$sql_tabs['stammdaten_adresse']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
						$sql_tabs['stammdaten_adresse']['adresse'] 		=> $db->str($postfeld['adresse']),
						$sql_tabs['stammdaten_adresse']['plz']	 		=> $db->str($postfeld['plz']),
						$sql_tabs['stammdaten_adresse']['ort'] 			=> $db->str($postfeld['ort']),
						$sql_tabs['stammdaten_adresse']['land']	 		=> $db->str($std_land),
						$sql_tabs['stammdaten_adresse']['art']	 		=> 0,
						$sql_tabs['stammdaten_adresse']['post'] 		=> 1,
						$sql_tabs['stammdaten_adresse']['beginn'] 		=> $db->dbdate(time()),
						$sql_tabs['stammdaten_adresse']['ende'] 		=> 0,
						$sql_tabs['stammdaten_adresse']['mandant_id']	=> $db->dbzahl($manda_id),
						$sql_tabs['stammdaten_adresse']['zusatz2']		=> $db->str($postfeld['county'])
					)
			);

			$karray=array(
				0 => $postfeld['telefon'],
				3 => $postfeld['fax'],
				6 => $postfeld['mobilfon'],
				9 => $postfeld['email']
			);
			if ($postfeld['firma1']!='' or $cfg_greek or $cfg_kfzsuche_norway) {
				$karray=array(
					1 => $postfeld['telefon2'],
					4 => $postfeld['fax2'],
					7 => $postfeld['mobilfon2'],
					10 => $postfeld['email2']
				);
			}
			if ($cfg_kfzsuche_kontakt_pg) {
				$karray=array(
					0 => $postfeld['telefon'],
					3 => $postfeld['fax'],
					6 => $postfeld['mobilfon'],
					9 => $postfeld['email'],
					1 => $postfeld['telefon2'],
					4 => $postfeld['fax2'],
					7 => $postfeld['mobilfon2'],
					10 => $postfeld['email2']
				);
			} elseif ($postfeld['firma1']!='' or $cfg_greek or $cfg_kfzsuche_norway) {
				$postfeld['telefon']=$postfeld['telefon2'];
				$postfeld['mobilfon']=$postfeld['mobilfon2'];
				$postfeld['fax']=$postfeld['fax2'];
				$postfeld['email']=$postfeld['email2'];
			}

			$db->insert(
					$sql_tab['stammdaten_gruppe_zuordnung'],
					array(
						$sql_tabs['stammdaten_gruppe_zuordnung']['gruppe_id'] => $db->dbzahl($grbez),
						$sql_tabs['stammdaten_gruppe_zuordnung']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id'])
					)
			);
			$res2=$db->select(
						$sql_tab['formular'],
						array(
							$sql_tabs['formular']['bezeichnung'],
							$sql_tabs['formular']['vorlage']
						),
						$sql_tabs['formular']['formular_id'].'='.$db->dbzahl(1)
			);
			$row2=$db->zeile($res2);
			$bez_f=$row2[0];
			$kfeld3=array(
								$sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['wvl_datum1'] => 0,
								$sql_tabs['korrespondenz']['wvl_datum2'] => 0,
								$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
								$sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
								$sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['eingang'] => 0,
								$sql_tabs['korrespondenz']['art'] => $db->dbzahl(14),
								$sql_tabs['korrespondenz']['kategorie'] => $db->str(_FORMULARE_),
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
								$sql_tabs['korrespondenz']['parent_id'] => 0,
								$sql_tabs['korrespondenz']['doclink'] => $db->str(''),
								$sql_tabs['korrespondenz']['betreff'] => $db->str($bez_f),
								$sql_tabs['korrespondenz']['beschreibung'] => $db->str(''),
								$sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['papierkorb'] => 0,
								$sql_tabs['korrespondenz']['kalender_id'] => 0,
								$sql_tabs['korrespondenz']['prioritaet'] => 0,
								$sql_tabs['korrespondenz']['negativ'] => 0,
								$sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_nr'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_FORMULAR_),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str(_FORMULAR_),
								$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($ang_kv_user)
			);
			$allesok=$db->insert(
				$sql_tab['korrespondenz'],
				$kfeld3
			);

			// neu:

			$alte_id=0;
			if ($cfg_carlo_appserver_cog_adressid) {
								$res6=$db->select(
									$sql_tab['stammdaten_mandant'],
									array(
										$sql_tabs['stammdaten_mandant']['mandant_id'],
										$sql_tabs['stammdaten_mandant']['lagerort'],
										$sql_tabs['stammdaten_mandant']['nummer1'],
										$sql_tabs['stammdaten_mandant']['nummer2']
									),
									$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
										$sql_tabs['stammdaten_mandant']['mandant_id'].'!='.$db->dbzahl($manda_id).' and '.
									//	$sql_tabs['stammdaten_mandant']['nummer1'].'='.$db->str('')
									'('.$sql_tabs['stammdaten_mandant']['nummer1'].'!='.$db->str('').' or '.
										$sql_tabs['stammdaten_mandant']['nummer2'].'!='.$db->str('').')'
								);
								if ($row6=$db->zeile($res6)) {
									$alte_id=$_SESSION['stammdaten_id'];
								}
				if ($alte_id==0) {
					
			}
			}

			$post=$postfeld;
			if ($cfg_carlo_appserver_kv_deb and $postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
				$mcfg_carlo_appserver_neu_deb=$cfg_carlo_appserver_neu_deb;
				$cfg_carlo_appserver_neu_deb=true;
				capps_updatekunde($_SESSION['stammdaten_id'], true, $alte_id);
				$cfg_carlo_appserver_neu_deb=$mcfg_carlo_appserver_neu_deb;
			} elseif (!$cfg_carlo_appserver_keineinteressenten) {
				capps_updatekunde($_SESSION['stammdaten_id'], true, $alte_id);
			}
			
			if ($_SESSION['cfg_kunde']=='carlo_opel_neff') {
				if (substr($postfeld['lagerort'], 0, 1)=='2' and intval($_SESSION['stammdaten_id'])>0) {
					$m_pflagerort=$postfeld['lagerort'];
					$postfeld['lagerort']='1_00NSU';
					$post['lagerort']='1_00NSU';
					$alte_id=$_SESSION['stammdaten_id'];
					
					if ($alte_id<1000000) {
						$mcfg_carlo_appserver_neu_deb=$cfg_carlo_appserver_neu_deb;
						$cfg_carlo_appserver_neu_deb=true;
						capps_updatekunde($_SESSION['stammdaten_id'], true, $alte_id);
						$cfg_carlo_appserver_neu_deb=$mcfg_carlo_appserver_neu_deb;
					}
					$postfeld['lagerort']=$m_pflagerort;
					$post['lagerort']=$m_pflagerort;
				}
			}
			
			if ($cfg_ws_avag_kroatien and $postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
				$postfeld['betreuer']=$_SESSION['user_id'];
				ws_kroa($_SESSION['stammdaten_id'], true);
			}
			
			if ($cfg_zls_rueck and isset($cfg_zls_rueck_nurbg) and $cfg_zls_rueck_nurbg!='') {
					$res7=$db->select(
						$sql_tab['benutzer_gruppe'],
						array(
							$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
							$sql_tabs['benutzer_gruppe']['bezeichnung']
						),
						$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str($cfg_zls_rueck_nurbg)
					);
					if ($row7=$db->zeile($res7)) {
						if ($_SESSION['rechte_bgruppen']=='-1' or preg_match('/,'.$row7[0].',/', ','.$_SESSION['rechte_bgruppen'].',')) {
							// kann zur�ckschreiben
						} else {
							$cfg_zls_rueck=false;
						}
					}
			}
			if ($cfg_zls_rueck) {
				include_once('inc/zls.php');
				if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
					zls_writecustomer($_SESSION['stammdaten_id'], true);
				}
			}
			if ($cfg_f1allg_rueck) {
				include_once('inc/f1allg.php');
				if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
					f1allg_writecustomer($_SESSION['stammdaten_id'], true);
				}
			}
			if ($cfg_md_rueck) {
				include_once('inc/lib_md.php');
				if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
					md_writecustomer($_SESSION['stammdaten_id'], true);
				}
			}
			if ($cfg_vx_rueck) {
				include_once('inc/lib_vaudisx.php');
				if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
					vx_writecustomer($_SESSION['stammdaten_id'], true);
				}
			}
			if ($cfg_attribut_rueck) {
				include_once('inc/lib_attr.php');
				if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
					attr_writecustomer($_SESSION['stammdaten_id'], true);
				}
			}
			if ($cfg_loco_rueck) {
				include_once('inc/lib_loco.php');
				if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
					loco_writecustomer($_SESSION['stammdaten_id'], true);
				}
			}
			if ($cfg_ecaros_rueck) {
				include_once('inc/lib_ecaros.php');
				if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
					ecaros_writecustomer($_SESSION['stammdaten_id'], true);
				}
			}
			if ($cfg_betzemeier_rueck && $postfeld['submit1'] === _KAUFVERTRAG_.' '._ERSTELLEN_) {
                Betzemeier::writeCustomer($_SESSION['stammdaten_id'], true);
            }
			
			if ($cfg_werbas_stx3) {
				$werbas_ist_kfzsuche_neu=true;
				werbas_erstelle_xml($_SESSION['stammdaten_id']);
			}
			if ($cfg_pundf) {
				/*include('inc/pundf.php');
				set_pundf_customer($_SESSION['stammdaten_id'], true);*/
                PearAutoLoader::instance()->addSourceRoot('inc/servers');
                $outbox = new Pundf_Outbox();
                $outbox->activate($_SESSION['stammdaten_id']);
			}
		} elseif (!$vorschau) {
			if (intval($postfeld['stid'])<=0) {
				die('Kein Kunde gew�hlt.');
			}
			// Kein Neukunde:
			$_SESSION['stammdaten_id']=$postfeld['stid'];
			// Update der Daten:
			$dbtelt='1';
			if ($postfeld['firma1']!='' or $cfg_greek or $cfg_kfzsuche_norway) {
				$dbtelt='2';
			}

			$upsqlt=array(
					$sql_tabs['stammdaten']['anrede'] => $db->str($postfeld['anrede']),
					$sql_tabs['stammdaten']['titel'] => $db->str($postfeld['titel']),
					$sql_tabs['stammdaten']['vorname'] => $db->str($postfeld['vorname']),
					$sql_tabs['stammdaten']['name'] => $db->str($postfeld['name']),
					$sql_tabs['stammdaten']['firma1'] => $db->str($postfeld['firma1']),
//					$sql_tabs['stammdaten']['betreuer'] => $db->dbzahl($_SESSION['user_id']),
					$sql_tabs['stammdaten']['anzeigename'] => $db->str($anzeigename),
					$sql_tabs['stammdaten']['meinvp'] => $db->dbzahl(0),
					$sql_tabs['stammdaten']['Telefon_'.$dbtelt] => $db->str($postfeld['telefon']),
					$sql_tabs['stammdaten']['Mobilfon_'.$dbtelt] => $db->str($postfeld['mobilfon']),
					$sql_tabs['stammdaten']['Fax_'.$dbtelt] => $db->str($postfeld['fax']),
					$sql_tabs['stammdaten']['EMail_'.$dbtelt] => $db->str($postfeld['email']),
					$sql_tabs['stammdaten']['geburtstag'] => $db->dbdate($postfeld['geburtsdatum']),
					$sql_tabs['stammdaten']['geburtsort'] => $db->str($postfeld['geburtsort']),
					$sql_tabs['stammdaten']['beruf'] => $db->str($postfeld['beruf'])
			);
			if ($cfg_kfzsuche_kontakt_pg) {
				$upsqlt[$sql_tabs['stammdaten']['Telefon_1']]=$db->str($postfeld['telefon']);
				$upsqlt[$sql_tabs['stammdaten']['Telefon_2']]=$db->str($postfeld['telefon2']);
				$upsqlt[$sql_tabs['stammdaten']['Mobilfon_1']]=$db->str($postfeld['mobilfon']);
				$upsqlt[$sql_tabs['stammdaten']['Mobilfon_2']]=$db->str($postfeld['mobilfon2']);
				$upsqlt[$sql_tabs['stammdaten']['Fax_1']]=$db->str($postfeld['fax']);
				$upsqlt[$sql_tabs['stammdaten']['Fax_2']]=$db->str($postfeld['fax2']);
				$upsqlt[$sql_tabs['stammdaten']['EMail_1']]=$db->str($postfeld['email']);
				$upsqlt[$sql_tabs['stammdaten']['EMail_2']]=$db->str($postfeld['email2']);
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent' and isset($postfeld['hobby'])) {
				$upsqlt[$sql_tabs['stammdaten']['hobby']]=$db->str($postfeld['hobby']);
			}
			if ($cfg_kfzsuche_stammdaten_branche) {
				$upsqlt[$sql_tabs['stammdaten']['branche']]=$db->str($postfeld['branche']);
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_dello') {
				$upsqlt[$sql_tabs['stammdaten']['branche']]=$db->str($postfeld['branche']);
				$upsqlt[$sql_tabs['stammdaten']['hobby']]=$db->str($postfeld['hobby']);
				
				if ($postfeld['familienstand']=='-1') {
					$postfeld['familienstand']='';
				}
				$res2=$db->select(
					$sql_tab['zusatzfelder'],
					$sql_tabs['zusatzfelder']['stammdaten_id'],
					$sql_tabs['zusatzfelder']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
				);
				if ($row2=$db->zeile($res2)) {
					$res2=$db->update(
						$sql_tab['zusatzfelder'],
						array(
							'zf_2' => $db->str($postfeld['familienstand'])
						),
						$sql_tabs['zusatzfelder']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
					);
				} else {
					$res2=$db->insert(
						$sql_tab['zusatzfelder'],
						array(
							'zf_2' => $db->str($postfeld['familienstand']),
							$sql_tabs['zusatzfelder']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id'])
						)
					);
				}
			}
			if ($postfeld['anrede']==_HERR_) {
				$upsqlt[$sql_tabs['stammdaten']['briefanrede']]=$db->str(_BRIEFANREDE_HERR_);
			}
			if ($postfeld['anrede']==_FRAU_) {
				$upsqlt[$sql_tabs['stammdaten']['briefanrede']]=$db->str(_BRIEFANREDE_FRAU_);
			}
			if ($postfeld['anrede']==_FIRMA_) {
				$upsqlt[$sql_tabs['stammdaten']['briefanrede']]=$db->str(_BRIEFANREDE_FIRMA_);
			}
			if ($cfg_kfzsuche_idstatus) {
				$upsqlt[$sql_tabs['stammdaten']['idstatus']]=$db->str($postfeld['idstatus']);
			}
			if (isset($cfg_kfzsuche_kundendaten_zusatz2) and $cfg_kfzsuche_kundendaten_zusatz2!='') {
				$upsqlt[$sql_tabs['stammdaten']['zusatz2']]=$db->str($postfeld['kuzusatz2']);
			}
			if (isset($postfeld['anredehatcode'])) {
				$upsqlt[$sql_tabs['stammdaten']['anredecode']]=$db->str($postfeld['anredecode']);
			}
			if (isset($postfeld['anredehatcode2'])) {
				$upsqlt[$sql_tabs['stammdaten']['anredecode']]=$db->str($postfeld['anredecode']);
			}
			if (isset($postfeld['steuernummer'])) {
				$upsqlt[$sql_tabs['stammdaten']['steuernummer']]=$db->str($postfeld['steuernummer']);
			}
			if (isset($postfeld['steuernummer2'])) {
				$upsqlt[$sql_tabs['stammdaten']['fleetnummer']]=$db->str($postfeld['steuernummer2']);
			}
			if ($cfg_kfzsuche_kv_betreuer and $postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
				$upsqlt[$sql_tabs['stammdaten']['betreuer']]=$db->dbzahl($_SESSION['user_id']);
			}
			if (isset($postfeld['firma2'])) {
				$upsqlt[$sql_tabs['stammdaten']['firma2']]=$db->str($postfeld['firma2']);
			}
			if (isset($postfeld['firma3'])) {
				$upsqlt[$sql_tabs['stammdaten']['firma3']]=$db->str($postfeld['firma3']);
			}
			$db->update(
				$sql_tab['stammdaten'],
				$upsqlt,
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
			);
			$res3=$db->select(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['Telefon_1'],
					$sql_tabs['stammdaten']['Telefon_2'],
					$sql_tabs['stammdaten']['Fax_1'],
					$sql_tabs['stammdaten']['Fax_2'],
					$sql_tabs['stammdaten']['Mobilfon_1'],
					$sql_tabs['stammdaten']['Mobilfon_2'],
					$sql_tabs['stammdaten']['EMail_1'],
					$sql_tabs['stammdaten']['EMail_2']
				),
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
			);
			$sqlt1=array();
			$del_teld='';
			if (!$cfg_kfzsuche_kontakt_pg and $row3=$db->zeile($res3)) {
				if ($row3[0]==$row3[1]) {
					$del_teld.='0,1,';
					if ($postfeld['firma1']!='' or $cfg_greek or $cfg_kfzsuche_norway) {
						$sqlt1[$sql_tabs['stammdaten']['Telefon_1']]=$db->str('');
					} else {
						$sqlt1[$sql_tabs['stammdaten']['Telefon_2']]=$db->str('');
					}
				}
				if ($row3[2]==$row3[3]) {
					$del_teld.='3,4,';
					if ($postfeld['firma1']!='' or $cfg_greek or $cfg_kfzsuche_norway) {
						$sqlt1[$sql_tabs['stammdaten']['Fax_1']]=$db->str('');
					} else {
						$sqlt1[$sql_tabs['stammdaten']['Fax_2']]=$db->str('');
					}
				}
				if ($row3[4]==$row3[5]) {
					$del_teld.='6,7,';
					if ($postfeld['firma1']!='' or $cfg_greek or $cfg_kfzsuche_norway) {
						$sqlt1[$sql_tabs['stammdaten']['Mobilfon_1']]=$db->str('');
					} else {
						$sqlt1[$sql_tabs['stammdaten']['Mobilfon_2']]=$db->str('');
					}
				}
				if ($row3[6]==$row3[7]) {
					$del_teld.='9,10,';
					if ($postfeld['firma1']!='' or $cfg_greek or $cfg_kfzsuche_norway) {
						$sqlt1[$sql_tabs['stammdaten']['EMail_1']]=$db->str('');
					} else {
						$sqlt1[$sql_tabs['stammdaten']['EMail_2']]=$db->str('');
					}
				}
			}
			if (count($sqlt1)>0) {
				$db->update(
					$sql_tab['stammdaten'],
					$sqlt1,
					$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
				);
			}

			$sqlt_adr=array(
						$sql_tabs['stammdaten_adresse']['adresse'] 		=> $db->str($postfeld['adresse']),
						$sql_tabs['stammdaten_adresse']['plz']	 		=> $db->str($postfeld['plz']),
						$sql_tabs['stammdaten_adresse']['ort'] 			=> $db->str($postfeld['ort'])
			);
			if (isset($postfeld['county'])) {
				$sqlt_adr[$sql_tabs['stammdaten_adresse']['zusatz2']]=$db->str($postfeld['county']);
			}
            if (isset($sql_tabs['stammdaten_adresse']['mandanten_entfernung']) && file_exists('_plz_distanz_nachberechnung.php')) {
                $sqlt_adr[$sql_tabs['stammdaten_adresse']['mandanten_entfernung']] = 'null';
            }
			$db->update(
					$sql_tab['stammdaten_adresse'],
					$sqlt_adr,
					$sql_tabs['stammdaten_adresse']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
						$sql_tabs['stammdaten_adresse']['art'].'=0'
			);

			$karray=array(
				0 => $postfeld['telefon'],
				3 => $postfeld['fax'],
				6 => $postfeld['mobilfon'],
				9 => $postfeld['email']
			);
			if ($postfeld['firma1']!='' or $cfg_greek or $cfg_kfzsuche_norway) {
				$karray=array(
					1 => $postfeld['telefon'],
					4 => $postfeld['fax'],
					7 => $postfeld['mobilfon'],
					10 => $postfeld['email']
				);
			}
			if ($cfg_kfzsuche_kontakt_pg) {
				$karray=array(
					0 => $postfeld['telefon'],
					3 => $postfeld['fax'],
					6 => $postfeld['mobilfon'],
					9 => $postfeld['email'],
					1 => $postfeld['telefon2'],
					4 => $postfeld['fax2'],
					7 => $postfeld['mobilfon2'],
					10 => $postfeld['email2']
				);
			}
			if ($del_teld!='') {
				$del_teld=p4n_mb_string('substr',$del_teld, 0, -1);
			}
			while (list($key, $val)=@each($karray)) {
				if ($val!='') {
				}
			}
			// update bei Bestandskunde Ende
if (1==2 and $_SESSION['user_id']==1) {
	if ($fp=fopen('__kvtest.txt', 'a')) {
		fwrite($fp, "\n\n".adodb_date('d.m.Y H:i:s', time())." - Start: ".$ohnek."\n");
		fclose($fp);
	}
}
			if (!$ohnek) {

				$upda=true;
				$dmsverkn_da=true;

				$res5=$db->select(
								$sql_tab['stammdaten_mandant'],
								array(
									$sql_tabs['stammdaten_mandant']['mandant_id'],
									$sql_tabs['stammdaten_mandant']['lagerort'],
									$sql_tabs['stammdaten_mandant']['nummer1'],
									$sql_tabs['stammdaten_mandant']['nummer2']
								),
								$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
								$sql_tabs['stammdaten_mandant']['mandant_id'].'='.$db->dbzahl($manda_id).' and '.
									($cfg_carlo_appserver_ws?'('.$sql_tabs['stammdaten_mandant']['nummer1'].'!='.$db->str('').' or '.$sql_tabs['stammdaten_mandant']['nummer2'].'!='.$db->str('').')':$sql_tabs['stammdaten_mandant']['nummer1'].'!='.$db->str(''))
				);
				if ($db->anzahl($res5)==0) {
					$dmsverkn_da=false;
					
					$res6=$db->select(
						$sql_tab['stammdaten'],
						$sql_tabs['stammdaten']['matchcode'],
						$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
					);
					if ($row6=$db->zeile($res6)) {
						if ($row6[0]!='') {
							$dmsverkn_da=true;
						}
					}
					if ($cfg_carlo_appserver_kv_deb and $postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						$c_updaten=false;
						if ($cfg_carlo_appserver_cog_int2deb) {
							$res6=$db->select(
								$sql_tab['stammdaten_mandant'],
								array(
									$sql_tabs['stammdaten_mandant']['mandant_id'],
									$sql_tabs['stammdaten_mandant']['lagerort'],
									$sql_tabs['stammdaten_mandant']['nummer1'],
									$sql_tabs['stammdaten_mandant']['nummer2']
								),
								$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
								$sql_tabs['stammdaten_mandant']['mandant_id'].'='.$db->dbzahl($manda_id).' and '.
									$sql_tabs['stammdaten_mandant']['nummer2'].'!='.$db->str('')
							);
							if ($row6=$db->zeile($res6)) {
								$rg=capps_int2deb($row6[3], $manda_id);
								if (p4n_mb_string('substr',$rg, 0, 6)!='Fehler') {
									$db->update(
										$sql_tab['stammdaten_mandant'],
										array(
											$sql_tabs['stammdaten_mandant']['nummer1'] => $db->str($rg)
										),
										$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
											$sql_tabs['stammdaten_mandant']['mandant_id'].'='.$db->dbzahl($manda_id)
									);
								}
							} else {
								$c_updaten=true;
							}
						} else {
							$c_updaten=true;
						}
						if ($c_updaten) {
							$alte_id=0;
							if ($cfg_carlo_appserver_cog_adressid) {
								$res6=$db->select(
									$sql_tab['stammdaten_mandant'],
									array(
										$sql_tabs['stammdaten_mandant']['mandant_id'],
										$sql_tabs['stammdaten_mandant']['lagerort'],
										$sql_tabs['stammdaten_mandant']['nummer1'],
										$sql_tabs['stammdaten_mandant']['nummer2']
									),
									$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
										$sql_tabs['stammdaten_mandant']['mandant_id'].'!='.$db->dbzahl($manda_id).' and '.
										'('.$sql_tabs['stammdaten_mandant']['nummer1'].'!='.$db->str('').' or '.$sql_tabs['stammdaten_mandant']['nummer2'].'!='.$db->str('').')'
								);
								if ($row6=$db->zeile($res6)) {
									$alte_id=$_SESSION['stammdaten_id'];
								}
							}
							$mcfg_carlo_appserver_neu_deb=$cfg_carlo_appserver_neu_deb;
							$cfg_carlo_appserver_neu_deb=true;
							$post=$postfeld;
							capps_updatekunde($_SESSION['stammdaten_id'], true, $alte_id);
							$cfg_carlo_appserver_neu_deb=$mcfg_carlo_appserver_neu_deb;
							$upda=false;
						}
					}
				}

				if ($upda) {
					capps_updatekunde($_SESSION['stammdaten_id'], false);
				}
				
				if ($_SESSION['cfg_kunde']=='carlo_opel_neff') {
					if (substr($postfeld['lagerort'], 0, 1)=='2' and intval($_SESSION['stammdaten_id'])>0) {
						$m_pflagerort=$postfeld['lagerort'];
						$postfeld['lagerort']='1_00NSU';
						$post['lagerort']='1_00NSU';
						$alte_id=$_SESSION['stammdaten_id'];
						
						$res7=$db->select(
									$sql_tab['stammdaten_mandant'],
									array(
										$sql_tabs['stammdaten_mandant']['mandant_id'],
										$sql_tabs['stammdaten_mandant']['lagerort'],
										$sql_tabs['stammdaten_mandant']['nummer1'],
										$sql_tabs['stammdaten_mandant']['nummer2']
									),
									$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
										$sql_tabs['stammdaten_mandant']['mandant_id'].'='.$db->dbzahl(1)
						);
						if ($db->anzahl($res7)==0 and $alte_id<1000000) {
							$mcfg_carlo_appserver_neu_deb=$cfg_carlo_appserver_neu_deb;
							$cfg_carlo_appserver_neu_deb=true;
							capps_updatekunde($_SESSION['stammdaten_id'], true, $alte_id);
							$cfg_carlo_appserver_neu_deb=$mcfg_carlo_appserver_neu_deb;
						}
						$postfeld['lagerort']=$m_pflagerort;
						$post['lagerort']=$m_pflagerort;
					}
				}
				
				if ($cfg_ws_avag_kroatien) {
					if ($db->anzahl($res5)>0) {
						ws_kroa($_SESSION['stammdaten_id'], false);
					} elseif ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						$postfeld['betreuer']=$_SESSION['user_id'];
						ws_kroa($_SESSION['stammdaten_id'], true);
					}
				}
				
				if ($cfg_zls_rueck and isset($cfg_zls_rueck_nurbg) and $cfg_zls_rueck_nurbg!='') {
					$res7=$db->select(
						$sql_tab['benutzer_gruppe'],
						array(
							$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
							$sql_tabs['benutzer_gruppe']['bezeichnung']
						),
						$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str($cfg_zls_rueck_nurbg)
					);
					if ($row7=$db->zeile($res7)) {
						if ($_SESSION['rechte_bgruppen']=='-1' or preg_match('/,'.$row7[0].',/', ','.$_SESSION['rechte_bgruppen'].',')) {
							// kann zur�ckschreiben
						} else {
							$cfg_zls_rueck=false;
						}
					}
				}
				if ($cfg_zls_rueck) {
					include_once('inc/zls.php');
					if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						if ($dmsverkn_da) {
							zls_writecustomer($_SESSION['stammdaten_id'], false);
						} else {
							zls_writecustomer($_SESSION['stammdaten_id'], true);
						}
					}
				}
				if ($cfg_f1allg_rueck) {
					include_once('inc/f1allg.php');
					if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						if ($dmsverkn_da) {
							f1allg_writecustomer($_SESSION['stammdaten_id'], false);
						} else {
							f1allg_writecustomer($_SESSION['stammdaten_id'], true);
						}
					}
				}
				
				if ($cfg_md_rueck) {
					include_once('inc/lib_md.php');
					if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						if ($dmsverkn_da) {
							md_writecustomer($_SESSION['stammdaten_id'], false);
						} else {
							md_writecustomer($_SESSION['stammdaten_id'], true);
						}
					}
				}
				if ($cfg_vx_rueck) {
					include_once('inc/lib_vaudisx.php');
					if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						if ($dmsverkn_da) {
							vx_writecustomer($_SESSION['stammdaten_id'], false);
						} else {
							vx_writecustomer($_SESSION['stammdaten_id'], true);
						}
					}
				}
				if ($cfg_attribut_rueck) {
					include_once('inc/lib_attr.php');
					if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						if ($dmsverkn_da) {
							attr_writecustomer($_SESSION['stammdaten_id'], false);
						} else {
							attr_writecustomer($_SESSION['stammdaten_id'], true);
						}
					}
				}
				if ($cfg_loco_rueck) {
					include_once('inc/lib_loco.php');
					if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						if ($dmsverkn_da) {
							loco_writecustomer($_SESSION['stammdaten_id'], false);
						} else {
							loco_writecustomer($_SESSION['stammdaten_id'], true);
						}
					}
				}
				if ($cfg_ecaros_rueck) {
					include_once('inc/lib_ecaros.php');
					if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
						if ($dmsverkn_da) {
							ecaros_writecustomer($_SESSION['stammdaten_id'], false);
						} else {
							ecaros_writecustomer($_SESSION['stammdaten_id'], true);
						}
					}
				}
				if ($cfg_betzemeier_rueck && $postfeld['submit1'] === _KAUFVERTRAG_.' '._ERSTELLEN_) {
                    if ($dmsverkn_da) {
                        Betzemeier::writeCustomer($_SESSION['stammdaten_id'], false);
                    } else {
                        Betzemeier::writeCustomer($_SESSION['stammdaten_id'], true);
                    }
                }
				
				if ($cfg_werbas_stx3) {
					$werbas_ist_kfzsuche=true;
					werbas_erstelle_xml($_SESSION['stammdaten_id']);
				}
				if ($cfg_pundf) {
					/*include('inc/pundf.php');
					set_pundf_customer($_SESSION['stammdaten_id']);*/
                    PearAutoLoader::instance()->addSourceRoot('inc/servers');
                    $outbox = new Pundf_Outbox();
                    $outbox->activate($_SESSION['stammdaten_id']);
				}
			}
		}
		
		if ($_SESSION['cfg_kunde']=='carlo_opel_nl_hogenbirk' or $cfg_plzvk) {
			if (isset($sql_tab['plz_vk'])) {
				$plz1=$postfeld['plz'];
				
				if (is_file('inc/plzvk.php')) {
					include_once('inc/plzvk.php');
					
					plzvk_felder($_SESSION['stammdaten_id'], $plz1);
				}
			}
		}
		
		if ($cfg_smit and isset($getfeld['smitoc'])) {
			include_once('inc/gmac.php');
			$erg=smit_startekonf($_SESSION['stammdaten_id'], $postfeld['pid'], 0, intval($getfeld['smitoc']));
			
			if (isset($erg['url'])) {
				echo javas('window.open("'.$erg['url'].'", "smit");');
			} else {
				echo javas('alert("'.p4n_mb_string('str_replace', array("\r", "\n", '"', "'"), ' ', print_r($erg, true)).'");');
				echo '<pre>';
				print_r($erg);
			}
			
			unset($postfeld);
//			echo javas('location.href="'.$phs.'";');
            if ($_SESSION['design_70'] && !$cfg_design70_hybrid) {
                echo javas('wechsel_a("main","stammdaten_main.php?id='.$_SESSION['stammdaten_id'].'&nav=Uebersicht");');
            } else
			echo javas('location.href="stammdaten_main.php?frameset_start=1&id='.$_SESSION['stammdaten_id'].'&nav=Uebersicht";');
            
			fuss();
			die();
		}
		
        if ($postfeld['submit1']==_SUCHAUFTRAG_.' '._ERSTELLEN_) {
            $getfeld=$_SESSION['kfzsuche_suchauf_button_werte'];
            $alle_sucha_f=array(
			'kfzstatus' => _STATUS_,
			'markencode' => _MARKENCODE_,
			'typ_modell' => $lang['_PZ-TYP-MODELL_'],
			'bauart' => _BAUART_,
			'standort' => _STANDORT_,
			'datum_ez_von' => $lang['_PZ-ERSTZULASSUNG_'].' '._VON_,
			'datum_ez_bis' => $lang['_PZ-ERSTZULASSUNG_'].' '._BIS_,
			'preis_von' => $lang['_P-PREIS_'].' '._VON_,
			'preis_bis' => $lang['_P-PREIS_'].' '._BIS_,
			'km_von' => _KMSTAND_.' '._VON_,
			'km_bis' => _KMSTAND_.' '._BIS_,
			'ps_von' => _LEISTUNG_.' '._PS_.' '._VON_,
			'ps_bis' => _LEISTUNG_.' '._PS_.' '._BIS_,
			'kw_von' => _LEISTUNG_.' '._KW_.' '._VON_,
			'kw_bis' => _LEISTUNG_.' '._KW_.' '._BIS_,
			'hubraum_von' => _HUBRAUM_.' '._VON_,
			'hubraum_bis' => _HUBRAUM_.' '._BIS_,
			'ausstattung' => _AUSSTATTUNG_,
			'farbe' => _FARBE_,
			'farbe2' => _FARBE_,
			'tueren' => _TUEREN_,
			'motorartcode' => _MOTORART_,
			'motorartcode2' => _MOTORART_,
			'fahrzeugmodellnr' => _KFZMODELLNR_,
			'kennbuchstabe_getriebe' => _GETRIEBEART_,
			'besteuerung' => _REGELBEST_.'/'._DIFFBEST_
    		);
			$res4=$db->select(
				$sql_tab['einstellungen'],
				$sql_tabs['einstellungen']['wert'],
				$sql_tabs['einstellungen']['modul'].'='.$db->str('KFZSuche_Ausst_Suchfelder')
			);
			if ($row4=$db->zeile($res4)) {
				if ($row4[0]!='') {
					$ausst_suchfelder=unserialize(base64_decode($row4[0]));
					foreach($ausst_suchfelder as $akey => $aval) {
						$alle_sucha_f['ausst'][$akey]=$akey;
					}
				}
			}
            $suchtext='';
			$para1='';
			@reset($alle_sucha_f);
			while (list($keys, $vals)=@each($alle_sucha_f)) {
				if (isset($getfeld[$keys])) {
					if (is_array($vals)) {
						while (list($keys2, $vals2)=@each($vals)) {
							if (isset($getfeld[$keys][$keys2]) and $getfeld[$keys][$keys2]!='-1' and $getfeld[$keys][$keys2]!='') {
								$para1.=$keys.'['.$keys2.']='.$getfeld[$keys][$keys2].'&';
								$werts=$getfeld[$keys][$keys2];
								$suchtext.=$vals2.': '.($werts=='1'?_JA_:$werts)."\n";
							}
						}
					} elseif ($getfeld[$keys]!='-1' and $getfeld[$keys]!='') {
						$para1.=$keys.'='.$getfeld[$keys].'&';
						if ($getfeld[$keys]=='-80') {
							continue;
						}
						$werts=$getfeld[$keys];
						if ($keys=='kfzstatus') {
							$werts=$kstatus[$werts];
						}
						if ($keys=='motorartcode') {
							$werts=$kmotorart[$werts];
						}
						if ($keys=='motorartcode2') {
							if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
								$werts=$cfg_dvs_treibstoff[$werts];
							} else {
								$werts=$kmotart3[$werts];
							}
						}
						if ($keys=='kennbuchstabe_getriebe') {
							$werts=$kgetrart[$werts];
						}
						if ($keys=='besteuerung') {
							if ($werts=='1') {
								$werts=_DIFFBEST_;
							} elseif ($werts=='2') {
								$werts=_REGELBEST_;
							}
						}
						if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent' and $keys=='unfallstatus') {
							if ($werts=='1') {
								$werts='Unfallfrei';
							} elseif ($werts=='2') {
								$werts='Unfallfahrzeug';
							}
						}
						
						$suchtext.=$vals.': '.$werts."\n";
					}
				}
				
			}
			$suchtext=p4n_mb_string('substr',$suchtext, 0, -1);
            $sqlt = array(
				$sql_tabs['kfzsuche_suchauftrag']['benutzer_id'] => $db->dbzahl($_SESSION['user_id']),
				$sql_tabs['kfzsuche_suchauftrag']['datum'] => $db->dbtimestamp(time()),
				$sql_tabs['kfzsuche_suchauftrag']['kriterien'] => $db->str($para1),
				$sql_tabs['kfzsuche_suchauftrag']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
				$sql_tabs['kfzsuche_suchauftrag']['zusatz1'] => $db->str($suchtext),
                $sql_tabs['kfzsuche_suchauftrag']['mailversand']            => $db->dblogic(false),
                $sql_tabs['kfzsuche_suchauftrag']['wiedervorlage']          => $db->dblogic(false),
                $sql_tabs['kfzsuche_suchauftrag']['enddatum']               => $db->dbdate($postfeld['suchauf_enddatum']),
                $sql_tabs['kfzsuche_suchauftrag']['mail_versand_ab']        => $db->dbzahl(0),
                $sql_tabs['kfzsuche_suchauftrag']['wvl_versand_ab']         => $db->dbzahl(0),
                $sql_tabs['kfzsuche_suchauftrag']['preissenkung']           => $db->dblogic(false),
                $sql_tabs['kfzsuche_suchauftrag']['mailversand_benutzer']   => $db->dbzahl($_SESSION['user_id']),
                $sql_tabs['kfzsuche_suchauftrag']['mailversand_frei']       => $db->dbzahl(false),
                $sql_tabs['kfzsuche_suchauftrag']['freie_email']            => $db->dbstr('')
            );
            $db->insert(
                $sql_tab['kfzsuche_suchauftrag'],
                $sqlt
            );
            unset($postfeld);
            unset($getfeld);
            unset($_SESSION['kfzsuche_suchauf_button_werte']);
            if ($_SESSION['design_70'] && !$cfg_design70_hybrid) {
                echo javas('templateAlert("'._SUCHAUFTRAG_.' '._GESPEICHERT_.'"); wechsel_a("main", "'.$phs.'");');
            } else {
    			echo javas('alert("'._SUCHAUFTRAG_.' '._GESPEICHERT_.'"); location.href="'.$phs.'";');
            }
			fuss();
			die();
        }
        
		$m_vlao1=$postfeld['vertrag_lagerort'];
		
		// kfz anlegen?
		$kzust='';
		if (isset($postfeld['dvs_id'])) {
			$kzust=$postfeld['dvs_id'];
		}
		if (!$vorschau) {
			if (isset($postfeld['dvs_id'])) {
				$kfzfeld=unserialize(base64_decode($postfeld['dvs_inhalt']));
				$stid2d=0;
				if ($postfeld['submit1']==_KAUFVERTRAG_.' '._ERSTELLEN_) {
					$stid2d=$_SESSION['stammdaten_id'];
				}
				$pid1=kfz_dvs2crm($kfzfeld, $stid2d);
			}
		}

		// $postfeld['pid']
		// $postfeld['stid']

		$res3=$db->select(
			$sql_tab['produktzuordnung'],
			array(
				$sql_tabs['produktzuordnung']['markencode'],
				$sql_tabs['produktzuordnung']['typ_modell'],
				$sql_tabs['produktzuordnung']['kommentar'],
				$sql_tabs['produktzuordnung']['kennzeichen'],
				$sql_tabs['produktzuordnung']['fahrgestell'],
				$sql_tabs['produktzuordnung']['text_4'],			// 5
				$sql_tabs['produktzuordnung']['fahrzeugstatus'],
				$sql_tabs['produktzuordnung']['fahrzeugmodellnr'],
				$sql_tabs['produktzuordnung']['text_1'],
				$sql_tabs['produktzuordnung']['text_2'],
				$sql_tabs['produktzuordnung']['text_3'],			// 10
				$sql_tabs['produktzuordnung']['typ'],
				$sql_tabs['produktzuordnung']['datum_ez'],
				$sql_tabs['produktzuordnung']['km_stand'],
				$sql_tabs['produktzuordnung']['fahrzeugstatus_code'],
				$sql_tabs['produktzuordnung']['farbbezeichnung'],	// 15
				$sql_tabs['produktzuordnung']['leistung_kw'],
				$sql_tabs['produktzuordnung']['leistung_ps'],
				$sql_tabs['produktzuordnung']['einstandspreis_mw'],
				$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'],
				(isset($sql_tabs['produktzuordnung']['generation'])?$sql_tabs['produktzuordnung']['generation']:$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst']),
				$sql_tabs['produktzuordnung']['mandant_id'],
				$sql_tabs['produktzuordnung']['kraftstoff'],		// 22
				$sql_tabs['produktzuordnung']['standtage'],
				$sql_tabs['produktzuordnung']['standort'],
				$sql_tabs['produktzuordnung']['zusatz1'],			// 25
				$sql_tabs['produktzuordnung']['haendlerstatus'],
				$sql_tabs['produktzuordnung']['kombiniert'],
				$sql_tabs['produktzuordnung']['abgas_cozwei'],
				$sql_tabs['produktzuordnung']['hersteller'],
				$sql_tabs['produktzuordnung']['unfalltext'],		// 30
				$sql_tabs['produktzuordnung']['differenzbesteuerung'],
				$sql_tabs['produktzuordnung']['aktuellervkpreis_mw'],
				(isset($sql_tabs['produktzuordnung']['ausst_wiki'])?$sql_tabs['produktzuordnung']['ausst_wiki']:$sql_tabs['produktzuordnung']['text_1']),
				$sql_tabs['produktzuordnung']['zusatzcode_1'],
				($cfg_db_kaufrecht2022?$sql_tabs['produktzuordnung']['vermarktungslinie']:$sql_tabs['produktzuordnung']['zusatzcode_1'])	// 35
			),
			$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
		);
		$row3=$db->zeile($res3);
		if (intval($postfeld['pid'])<=0) {
			$row3=array();
		}
		$pid_bez=$row3[0].' '.$row3[1];
		
		$pid_zusatzcode_1=$row3[34];
		$pid_vmlinie=$row3[35];
		
		$pid_lao=$row3[21];
		$pid_kraftstoff=$row3[22];
		$pid_standort=$row3[24];
		$pid_zusatz1=$row3[25];
		$pid_unfalltext=$row3[30];
		$pid_istdiff=false;
		if ($row3[31]=='1') {
			$pid_istdiff=true;
		}
		
		$hat_ez_oder_km=false;
		if (intval($row3[13])>0 or ($row3[12]!='' and p4n_mb_string('substr',$row3[12], 0, 10)!='0000-00-00')) {
			$hat_ez_oder_km=true;
		}

		$pid_bez2=$row3[0].' '.$row3[1].' '.$row3[3];
		$pid_bez3=$pid_bez2;
		if ($_SESSION['cfg_kunde']=='crm_vw_jacobs') {
			$pid_bez3=$row3[3].' '.$row3[0].' '.$row3[1];
		}
		if ($cfg_kfzsuche_avag_austria) {
			$pid_bez3=$row3[4];
		}
		$kennzeichen=$row3[3];
		if (isset($postfeld['pf_kennzeichen'])) {
			if ($postfeld['pf_kennzeichen']!='') {
				$kennzeichen=$postfeld['pf_kennzeichen'];
			}
		}
		$fgnr=$row3[4];
		$kfz=trim($row3[0].' '.$row3[1].($cfg_kfzsuche_typ2?' '.$row3[11]:''));
		if ($cfg_cross_mit_vfw) {
			$kfz=trim($row3[0].' '.$row3[11]);
		}
		$kfz_marke=$row3[0];
		$kfz_typm=trim($row3[1].($cfg_kfzsuche_typ2?' '.$row3[11]:''));
		if ($cfg_cross_mit_vfw) {
			$kfz_typm=trim($row3[11]);
		}
		$kfz_kmstand=intval($row3[13]);
		$kfz_farbe=$row3[15];
		$kfz_ez=$db->unixdate($row3[12]);
		$kfz_kw=$row3[16];
		$kfz_ps=$row3[17];
		$kfz_t1=$row3[8];
		$kfz_t2=$row3[9];
		$kfz_t3=$row3[10];
		$kfz_t4=$row3[5];
		$kfz_ekp=$row3[18];
		$kfz_vkp=$row3[19];
		$kfz_vkph=$row3[32];
		$kfz_generat=$row3[20];
		$kfz_standt=$row3[23];
		$kfz_haendlerstatus=$row3[26];
		$kfz_verb_komb=$row3[27];
		$kfz_co2=$row3[28];
		$kfz_hersteller=$row3[29];
		$ausst_wiki=$row3[33];
		
		$kfz_typ=$row3[1];
		$kfz_typ2='';
		if (p4n_mb_string('substr',trim($row3[7]), -4)=='_DIV') {
			$row3[7]='';
		}
		if (trim($row3[7])!='') {
			$kfz_typ2.=' ('.trim($row3[7]).')';
		}
		$kfz_marke=$row3[0];
		
		$pid_bez=$postfeld['kfz_bez'];
		
		$ausst=$row3[2];
		$kfz_fstatus=$row3[6];
		$kfz_fstatuscode=$row3[14];
		
		if ($vorschau) {
			if (isset($postfeld['dvs_id'])) {
				$kfzfeld=unserialize(base64_decode($postfeld['dvs_inhalt']));
				$pid_bez=$kfzfeld['VK_BEZ'];
				$kfz_typ=$kfzfeld['VK_BEZ'];
				$kfz_hsn=$kfzfeld['HSN'];
				$kfz_tsn=$kfzfeld['TSN'];
				$kfz=$kfzfeld['VK_BEZ'];
				$kfz_marke='';//$kfzfeld['Fabrikat'];
				$fgnr=$kfzfeld['Fahrgestellnummer'];
			}
		}

		if ($_SESSION['cfg_kunde']=='carlo_opel_carebus') {
				$res4=$db->select(
					$sql_tab['produktzuordnung'],
					array (
						$sql_tabs['produktzuordnung']['text_1'],
						$sql_tabs['produktzuordnung']['text_2'],
						$sql_tabs['produktzuordnung']['text_3'],
						$sql_tabs['produktzuordnung']['text_4'],
						$sql_tabs['produktzuordnung']['zusatz_text_9'],
						$sql_tabs['produktzuordnung']['zusatz_text_10']
					),
					$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
				);
				$row4=$db->zeile($res4);
			$inhalt=p4n_sb_strreplace('<<text_1>>', $row4[0], $inhalt);
			$inhalt=p4n_sb_strreplace('<<text_2>>', $row4[1], $inhalt);
			$inhalt=p4n_sb_strreplace('<<text_3>>', $row4[2], $inhalt);
			$inhalt=p4n_sb_strreplace('<<text_4>>', $row4[3], $inhalt);
			$inhalt=p4n_sb_strreplace('<<text_5>>', $row4[4], $inhalt);
			$inhalt=p4n_sb_strreplace('<<text_6>>', $row4[5], $inhalt);
		}

		$doclink_befragung='';
		if (1==2 and $postfeld['vertrag_nwgw']=='1' and $bez_ang_kv==_KAUFVERTRAG_ and $_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
			$doclink_befragung='inc/'.$_SESSION['cfg_kunde'].'/Kundenfragebogen.pdf';
			echo javas('window.open("'.$doclink_befragung.'", "_blank");');
		}
		if (isset($postfeld['vertrags_ankauf']) and $bez_ang_kv==_KAUFVERTRAG_ and $_SESSION['cfg_kunde']=='carlo_opel_toennemann') {
			$doclink_inz_toe='inc/'.$_SESSION['cfg_kunde'].'/checkliste_ankauf.xlsx';
			if (is_file($doclink_inz_toe)) {
				echo javas('window.open("'.$doclink_inz_toe.'", "_blank");');
			}
		}
		$zus_ort_landinfo='';
		if ($cfg_kfzsuche_vorlagen_mitlandunterort) {
			$res2=$db->select(
				$sql_tab['stammdaten_adresse'],
				array(
					$sql_tabs['stammdaten_adresse']['land']
				),
				$sql_tabs['stammdaten_adresse']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid'])
			);
			if ($row2=$db->zeile($res2)) {
				$row2[0]=trim($row2[0]);
				$ungleichland='Deutschland';
				if ($cfg_def_land=='�sterreich' or $cfg_neuanlage_standardland=='�sterreich') {
					$ungleichland='�sterreich';
				}
				if (strtolower($row2[0])!=strtolower($ungleichland)) {
					$zus_ort_landinfo='\\par '.$row2[0];
				}
			}
		}

		// DSE:
		$doclink8='';
		if (isset($postfeld['dse_druck']) and !(isset($postfeld['neukunde']) and $cfg_neuanlage_dsehaken_nichtoeffnen)) {	// and !$vorschau !$cfg_synop_pf and 
			$dse_oeffnen=true;
			if ($cfg_neuanlage_dsehaken_nichtoeffnen) {
				$res4=$db->select(
					$sql_tab['stammdaten_blacklist_log'],
					$sql_tabs['stammdaten_blacklist_log']['stammdaten_id'],
					$sql_tabs['stammdaten_blacklist_log']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid'])
				);
				if ($db->anzahl($res4)==0) {
					$dse_oeffnen=false;
				}
			}
			if ($dse_oeffnen) {
				$dse_marke=$postfeld['kfz_markencode'];
				if (!isset($postfeld['kfz_markencode']) and $kfz_marke!='') {
					$dse_marke=$kfz_marke;
				}
				if ($postfeld['vertrag_nwgw']=='1' and $_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
					$dse_marke='';
				}
				$doclink8=dse_druck_datei($postfeld['stid'], false, $dse_marke);
				$doclink8pdf='';
				if ($cfg_rtf2pdf and substr($doclink8, -4)!='.pdf') {
					$doclink8pdf=check_rtf2pdf($doclink8, $cfg_rtf2pdf_sleep);
					if ($doclink8pdf==$doclink8) {
						$doclink8pdf='';
					}
				} elseif (substr($doclink8, -4)=='.pdf') {
					$doclink8pdf=$doclink8;
				}
				if ($doclink8pdf!='') {
					tempdateien($doclink8pdf, str_replace('temp/', '', str_replace('.rtf', '.pdf', $doclink8pdf)), str_replace('.', '', _DSE_DRUCK_).'_'.kundenbezeichnung($_SESSION['stammdaten_id']));
					if ($cfg_kfzsuche_pdf_join and substr($doclink8pdf, -4)=='.pdf') {
						
					} elseif (!$cfg_synop_pf) {
						echo javas('window.open("'.$doclink8pdf.'", "_blank");');
					}
					$alle_pdfs[50]=$doclink8pdf;
				} elseif (!$cfg_synop_pf) {
					echo javas('window.open("'.$doclink8.'", "_blank");');
				}
			}
		}

		$aov_gruppe='';
		$res7=$db->select(
			$sql_tab['benutzer_gruppe'],
			array(
				$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
				$sql_tabs['benutzer_gruppe']['bezeichnung']
			),
			$sql_tabs['benutzer_gruppe']['bezeichnung'].' like '.$db->str('AOV%')
		);
		$aov_gef=false;
		while (!$aov_gef and $row7=$db->zeile($res7)) {
			if ($_SESSION['rechte_bgruppen']=='-1' or preg_match('/,'.$row7[0].',/', ','.$_SESSION['rechte_bgruppen'].',')) {
				$aov_gef=true;
				$aov_gruppe=$row7[1];
			}
		}
		if ($cfg_kfzsuche_levy and isset($postfeld['fin_ust_gk'])) {
			$postfeld['vorlage_rd_gk']=1;
		}
		
		if ($bez_ang_kv==_PROBEFAHRT_) {
			
			$korrkatpf=_PROBEFAHRT_;
			$ist_intpf=false;
			if (isset($postfeld['ist_interne_fahrt']) and $postfeld['ist_interne_fahrt']=='1') {
				$korrkatpf=_INTERNEFAHRT_;
				$ist_intpf=true;
			}
			
			$dauer_min=(int)(@adodb_mktime((int)$postfeld['pfzeitb'], (int)$postfeld['pfzeitb2'], 0, 1, 1, 2000)-@adodb_mktime((int)$postfeld['pfzeit'], (int)$postfeld['pfzeit2'], 0, 1,1,2000))/60;
			
			if (isset($postfeld['pfdatum']) and isset($postfeld['pfdatumb'])) {
				if (strlen($postfeld['pfdatum'])==10 and strlen($postfeld['pfdatumb'])==10) {
					$dau_ab=adodb_mktime(intval($postfeld['pfzeit']), intval($postfeld['pfzeit2']), 0, intval(substr($postfeld['pfdatum'], 3, 2)), intval(substr($postfeld['pfdatum'], 0, 2)), intval(substr($postfeld['pfdatum'], 6, 4)));
					$dau_bis=adodb_mktime(intval($postfeld['pfzeitb']), intval($postfeld['pfzeitb2']), 0, intval(substr($postfeld['pfdatumb'], 3, 2)), intval(substr($postfeld['pfdatumb'], 0, 2)), intval(substr($postfeld['pfdatumb'], 6, 4)));
					$dauer_min=round(($dau_bis-$dau_ab)/60);
				}
			}
			
			$pfkal_user=$ang_kv_user;
			$pfkal_user2=$_SESSION['user_id'];
			
			if ($ist_intpf and $cfg_benutzer_stammdatenid) {
				$res8=$db->select(
					$sql_tab['benutzer'],
					$sql_tabs['benutzer']['stammdaten_id'],
					$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($pfkal_user)
				);
				if ($row8=$db->zeile($res8)) {
					if (intval($row8[0])>0) {
						$_SESSION['stammdaten_id']=$row8[0];
						$postfeld['stid']=$row8[0];
					}
				}
			}
			
			if (isset($postfeld['imkalben'])) {
				if (!isset($postfeld['im_benutzer_kalender'])) {
					$res3=$db->select(
						$sql_tab['benutzer'],
						$sql_tabs['benutzer']['benutzer_id'],
						$sql_tabs['benutzer']['name'].'='.$db->str('Dummy').' and '.$sql_tabs['benutzer']['vorname'].'='.$db->str('Dummy')
					);
					if ($row3=$db->zeile($res3)) {
						$pfkal_user=$row3[0];
						$pfkal_user2=$row3[0];
					} else {
						$sql_f=array(
					$sql_tabs['benutzer']['login'] => $db->str('dummy'),
					$sql_tabs['benutzer']['passwort'] => $db->str(md5('dummy')),
					$sql_tabs['benutzer']['anrede'] => $db->str(''),
					$sql_tabs['benutzer']['briefanrede'] => $db->str(''),
					$sql_tabs['benutzer']['vorname'] => $db->str('Dummy'),
					$sql_tabs['benutzer']['name'] => $db->str('Dummy'),
					$sql_tabs['benutzer']['gruppe'] => $db->dbzahl(-10),
					$sql_tabs['benutzer']['stil'] => $db->str('style.css'),
					$sql_tabs['benutzer']['startseite'] => $db->str('pim.php'),
					$sql_tabs['benutzer']['sprache'] => $db->str('lang_de.php'),
					$sql_tabs['benutzer']['dokpfad'] => $db->str(''),
					$sql_tabs['benutzer']['hash'] => $db->str(md5(time())),
					$sql_tabs['benutzer']['syncml_user5'] => $db->str('')
						);
						$db->insert(
							$sql_tab['benutzer'],
							$sql_f
						);
						$pfkal_user=$db->insertid();
						$pfkal_user2=$pfkal_user;
					}
				}
			}
			$zusbetreff1='';
			if (isset($postfeld['at_pfart'])) {
				if (intval($postfeld['at_pfart'])==2) {
					$zusbetreff1='Sponsor ';
				}
				if (intval($postfeld['at_pfart'])==3) {
					$zusbetreff1='Kundenersatzfahrzeug';
				}
			}
			
			$zus_pfbetreff='';
			if ($_SESSION['cfg_kunde']=='carlo_opel_nl_hogenbirk') {
				$zus_pfbetreff=$postfeld['pf_kennzeichen'].' / '.kundenbezeichnung($_SESSION['stammdaten_id']).' / '.$alle_bens[$pfkal_user].' / ';
			}
			
			$pfmandid=$_SESSION['mandant'];
			if (intval($postfeld['pid'])>0 and intval($pid_lao)>0) {
				$pfmandid=intval($pid_lao);
			}
			
			$kalpf_betr=($zusbetreff1=='Kundenersatzfahrzeug'?'':_PROBEFAHRT_);
			$kalpf_art=_PROBEFAHRT_;
			if ($ist_intpf) {
				$kalpf_betr=_INTERNEFAHRT_;
				$kalpf_art=_INTERNEFAHRT_;
			}
			
			$sqlt=array(
					$sql_tabs['kalender']['mandant_id'] => $db->dbzahl($pfmandid),
					$sql_tabs['kalender']['produkt_id'] => $db->dbzahl($postfeld['pid']),
					$sql_tabs['kalender']['produkt2_id'] => $db->dbzahl(0),
					$sql_tabs['kalender']['beginn'] => $db->dbzeitdatum($postfeld['pfdatum'], $postfeld['pfzeit'].':'.$postfeld['pfzeit2']),
					$sql_tabs['kalender']['ende'] => $db->dbzeitdatum($postfeld['pfdatumb'], $postfeld['pfzeitb'].':'.$postfeld['pfzeitb2']),
					$sql_tabs['kalender']['dauer_min'] => $db->dbzahl($dauer_min),
					$sql_tabs['kalender']['ganztag'] => $db->dblogic(false),
					$sql_tabs['kalender']['beschreibung'] => $db->str(''),
					$sql_tabs['kalender']['zusatztext'] => $db->str($kzust),
					$sql_tabs['kalender']['betreff'] => $db->str($zusbetreff1.$kalpf_betr.' - '.$zus_pfbetreff.$pid_bez3),
					$sql_tabs['kalender']['prioritaet'] => $db->dbzahl(0),
					$sql_tabs['kalender']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
					$sql_tabs['kalender']['ansprechpartner_id'] => $db->dbzahl(0),
					$sql_tabs['kalender']['kalender_wiederh_id'] => $db->dbzahl(0),
					$sql_tabs['kalender']['gruppe_id'] => $db->dbzahl(0),
					$sql_tabs['kalender']['betreuer'] => $db->dbzahl($pfkal_user),
					$sql_tabs['kalender']['user_id'] => $db->dbzahl($pfkal_user2),
					$sql_tabs['kalender']['privat'] => $db->dblogic(false),
					$sql_tabs['kalender']['erinnerung'] => $db->dblogic(false),
					$sql_tabs['kalender']['kalender_zusatz_id']	=> $db->dbzahl($postfeld['zusatzk']),
					$sql_tabs['kalender']['letzte_aenderung_user'] => $db->dbzahl($_SESSION['user_id']),
					$sql_tabs['kalender']['art'] => $db->str($kalpf_art)
			);
			if ($_SESSION['cfg_kunde']=='crm_vw_jacobs') {
				$sqlt[$sql_tabs['kalender']['betreff']]=$db->str($pid_bez3);
			}
			$sqlt[$sql_tabs['kalender']['syncml_letzte_aenderung']]=$db->dbtimestamp(time());
			$sqlt[$sql_tabs['kalender']['syncml_status']]=$db->str('N');
            $sqlt[$sql_tabs['kalender']['erstellt_am']]=$db->dbtimestamp(time());
			
			if (isset($postfeld['pf_werkstattersatz'])) {
				$sqlt[$sql_tabs['kalender']['art']]=$db->str(_PROBEFAHRT_.' - WE');
			}
			
			$kennz_text='';
			if (!$ist_intpf and ($cfg_kfzsuche_norway or $cfg_kfzsuche_pfkzliste or $cfg_s4_bmw20) and isset($sql_tab['reservierung_fahrzeuge']) and intval($postfeld['pf_kennzeichen2'])>0) {
				$kennzid=intval($postfeld['pf_kennzeichen2']);
				if ($kennzid<0) {
					$kennzid=0;
				}
				$sqlt[$sql_tabs['kalender']['reservierung_fahrzeuge_id']]=$db->dbzahl($kennzid);
				$sqlt_no=$sqlt;
				$sqlt_no[$sql_tabs['kalender']['kalender_zusatz_id']]=$db->dbzahl($postfeld['zusatzk_no']);
				$sqlt_no[$sql_tabs['kalender']['betreuer']]=$db->dbzahl(1);
				
				$res9=$db->select(
						$sql_tab['reservierung_fahrzeuge'],
						array(
							$sql_tabs['reservierung_fahrzeuge']['reservierung_fahrzeuge_id'],
							$sql_tabs['reservierung_fahrzeuge']['kennzeichen'],
							$sql_tabs['reservierung_fahrzeuge']['beschreibung'],
							$sql_tabs['reservierung_fahrzeuge']['zusatz']
						),
						$sql_tabs['reservierung_fahrzeuge']['reservierung_fahrzeuge_id'].'='.$db->dbzahl($kennzid)
				);
				if ($row9=$db->zeile($res9)) {
					$kennz_text=trim($row9[1].' '.$row9[2]);
				}
				$sqlt_no[$sql_tabs['kalender']['beschreibung']]=$db->str($kennz_text);
				
				if (!$vorschau) {
					$res=$db->insert(
						$sql_tab['kalender'],
						$sqlt_no
					);
					$kal_id3=$db->insertid();
					$res=$db->update(
						$sql_tab['kalender'],
						array(
							$sql_tabs['kalender']['syncml_id'] => $db->str('-'.$kal_id3)
						),
						$sql_tabs['kalender']['kalender_id'].'='.$db->dbzahl($kal_id3)
					);
				}
			}
			
			// Insert
			
			if (!$vorschau) {
				if (isset($postfeld['pfkalid']) and intval($postfeld['pfkalid'])>0) {
					$kal_id=$postfeld['pfkalid'];
					$db->update(
						$sql_tab['kalender'],
						$sqlt,
						$sql_tabs['kalender']['kalender_id'].'='.$db->dbzahl($kal_id)
					);
				} else {
					$res=$db->insert(
						$sql_tab['kalender'],
						$sqlt
					);
					$kal_id=$db->insertid();
				}

				$res=$db->update(
					$sql_tab['kalender'],
					array(
						$sql_tabs['kalender']['syncml_id'] => $db->str('-'.$kal_id)
					),
					$sql_tabs['kalender']['kalender_id'].'='.$db->dbzahl($kal_id)
				);

                if ($cfg_caldav && !empty($_SESSION['checkbox_daten']) && in_array('caldav', $_SESSION['checkbox_daten']))  {
                    try {
                        CalDav::instance()->send($kal_id);
                    } catch (Exception $e) {
                        Logger_File::instance()->error('CalDav: '.$e->getMessage().' / '.$_SESSION['mitarbeiter_name2']);
                    }
                }

			    if (!empty($_SESSION['checkbox_daten']) && in_array('probef', $_SESSION['checkbox_daten']) && (isset($postfeld['other_opt_termin_betreuer']) || isset($postfeld['other_opt_termin_kunde'])) && $postfeld['pfdatum']!='') {
                    $betreuer = (isset($postfeld['other_opt_termin_betreuer'])) ? $pfkal_user : 0;
                    $stammdaten_id2 = (isset($postfeld['other_opt_termin_kunde'])) ? $_SESSION['stammdaten_id'] : 0;
                    $ziel_t2='stammdaten_main.php?nav=Uebersicht&kwvl1_z2='.$postfeld['pfzeit2'].'&kwvl1_z='.$postfeld['pfzeit'].'&kwvl1='.$postfeld['pfdatum'].'&inkalender=1&other_opt_termin_betreuer='.$betreuer.'&other_opt_termin_kunde='.$stammdaten_id2.'&termin_id='.$kal_id;
                }
			
			if (!$ist_intpf and isset($cfg_kfzsuche_pf_mail_lao_gruppe) and $cfg_kfzsuche_pf_mail_lao_gruppe!='') {
				$alle_mails=array();
					$res7=$db->select(
						$sql_tab['benutzer_gruppe'],
						array(
							$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
							$sql_tabs['benutzer_gruppe']['bezeichnung']
						),
						$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str($cfg_kfzsuche_pf_mail_lao_gruppe)
					);
					if ($row7=$db->zeile($res7)) {
						$res8=$db->select(
							$sql_tab['benutzer_gruppe_zuordnung'],
							$sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'],
							$sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row7[0])
						);
						while ($row8=$db->zeile($res8)) {
							$res9=$db->select(
								$sql_tab['benutzer'],
								array(
									$sql_tabs['benutzer']['email'],
									$sql_tabs['benutzer']['standard_lagerort']
								),
								$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row8[0])
							);
							if ($row9=$db->zeile($res9)) {
								if ($row9[0]!='' and intval($row9[1])>0 and intval($row9[1])==intval($pid_lao)) {
									$alle_mails[]=$row9[0];
								}
							}
						}
					}
				if (count($alle_mails)>0) {
					$res99=$db->select(
						$sql_tab['email_vorlagen'],
						array(
							$sql_tabs['email_vorlagen']['htmltext'],
							$sql_tabs['email_vorlagen']['email_vorlagen_id']
						),
						$sql_tabs['email_vorlagen']['bezeichnung'].' like '.$db->str($cfg_kfzsuche_pf_mail_lao_gruppe)
					);
        	        $p4n_editor = false;
            	    if ($row99=$db->zeile($res99)) {
						if ($cfg_mailversand_editor && is_file('inc/lib_htmledit.php')) {
                    	    global $cfg_newsletterbaukasten_p4n, $cfg_newsletterbaukasten_2_p4n, $cfg_newsletterbaukasten_p4n_ohne_tracking;
							include_once 'inc/lib_htmledit.php';
							$html_editor = new HTMLEditor();
							$mail_vorlage=$html_editor->prepare_mail($row99[1]);
							$vorlagetext=p4n_mb_string('str_replace', array('&lt;', '&gt;'), array('<', '>'), $mail_vorlage->Body);
            	            if ($mail_vorlage->CharSet == 'utf-8') {
                	            $vorlagetext=p4n_mb_string('utf8_decode', $vorlagetext);
                    	        $p4n_editor=true;
	                        }
    	                } else {
        	                $vorlagetext=p4n_mb_string('str_replace', array('&lt;', '&gt;'), array('<', '>'), $row99[0]);
						}
						
						if ($vorlagetext!='') {
                            if (!$cfg_mailversand_editor) {
                                $b_vorlagetext=nl2br($vorlagetext);
                            } else {
                                $b_vorlagetext=$vorlagetext;
                            }
							$absender_mail2_from=$_SESSION['user_email'];
							if ($absender_mail2_from=='') {
								$absender_mail2_from=$mcs_pop3_email;
							}
							$absender_mail2=$_SESSION['mitarbeiter_name'];
							include_once("mailconf.php");
							$mail->From     = $absender_mail2_from;
							$mail->FromName = 'CRM - '.$absender_mail2;
							$mail->ClearAllRecipients();
							$mail->ClearAttachments();
							$mail->ClearBCCs();
							$mail->IsHTML(true);
							$mail->Subject=_PROBEFAHRT_.' '.$kfz_marke.' '.$kfz_typ.' '.$kennzeichen.' '._VON_.' '.$alle_bens[$ang_kv_user];
							$a_alle_mails2='';
							while (list($keye, $vale)=@each($alle_mails)) {
								$mail->AddAddress($vale);
								$a_alle_mails2.=$vale.'#';
							}
							$a_alle_mails2=substr($a_alle_mails2, 0, -1);
							$mail->Body='';
							$mailt=$b_vorlagetext;
							$mailt=p4n_sb_strreplace('<<markencode>>', $kfz_marke, $mailt);
							$mailt=p4n_sb_strreplace('<<typ>>', $kfz_typ, $mailt);
							$mailt=p4n_sb_strreplace('<<kennzeichen>>', $kennzeichen, $mailt);
							$mailt=p4n_sb_strreplace('<<verkaeufer>>', $alle_bens[$ang_kv_user], $mailt);
							$mailt=p4n_sb_strreplace('<<datum1>>', $postfeld['pfdatum'], $mailt);
							$mailt=p4n_sb_strreplace('<<uhrzeit1>>', $postfeld['pfzeit'].':'.$postfeld['pfzeit2'], $mailt);
							$mailt=p4n_sb_strreplace('<<datum2>>', $postfeld['pfdatumb'], $mailt);
							$mailt=p4n_sb_strreplace('<<uhrzeit2>>', $postfeld['pfzeitb'].':'.$postfeld['pfzeitb2'], $mailt);
							$mailt=p4n_sb_strreplace('<<kunde>>', kundenbezeichnung($_SESSION['stammdaten_id']).' ('.$_SESSION['stammdaten_id'].')', $mailt);
							$mail->Body = $mailt;
							$okv=$mail->Send();
							if (!$okv) {
								echo _EMAILING_EMAILS_FEHLER_.'<br>'.javas('alert("'._EMAILING_EMAILS_FEHLER_.'");');
							}
							
							if ($fp2=fopen('inc/'.$_SESSION['cfg_kunde'].'/maillog.txt', 'a')) {
								fwrite($fp2, adodb_date('d.m.Y H:i:s', time()).': '.($okv?_OK_:_FEHLER_).' - '._PROBEFAHRT_.' PF-Admin: '.$kfz_marke.' '.$kfz_typ.' / '.$kennzeichen.' / '._KUNDE_.': '.kundenbezeichnung($_SESSION['stammdaten_id']).' ('.$_SESSION['stammdaten_id'].') / '._BENUTZER_.': '.$_SESSION['mitarbeiter_name2']."\r\n");
								fclose($fp2);
							}
							
						}
						
					}
				}
			}
			
			$merkeintfahrermail='';
			if (!$ist_intpf and $cfg_internerfahrer_pfakv_email or $_SESSION['crm_version']>64) {
					$res6=$db->select(
						$sql_tab['produktzuordnung'],
						array(
							$sql_tabs['produktzuordnung']['interner_fahrer']
						),
						$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
					);
					if ($row6=$db->zeile($res6)) {
						if (intval($row6[0])>0) {
						$res7=$db->select(
							$sql_tab['benutzer'],
							$sql_tabs['benutzer']['email'],
							$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row6[0])
						);
						if ($row7=$db->zeile($res7)) {
							if ($row7[0]!='') {
								include_once("mailconf.php");
								$abse='CRM';
								if ($_SESSION['user_email']!='') {
									$abse=$_SESSION['user_email'];
								} elseif ($mcs_pop3_email!='') {
									$abse=$mcs_pop3_email;
								}
								$mail->ClearAllRecipients();
								$mail->ClearAttachments();
								$mail->From     = $abse;
								$mail->FromName = 'CRM';
								$mail->IsHTML(false);
								$mail->Subject  = _PROBEFAHRT_.' '.$kennzeichen.' '._VON_.' '.$alle_bens[$ang_kv_user];
								$mail->AddAddress($row7[0]);
								$merkeintfahrermail=$row7[0];
					$liek1='Lieber Kollege';
					if (isset($lang['_LIEBER_KOLLEGE_'])) {
						$liek1=_LIEBER_KOLLEGE_;
					}
					$mfg1='Mit freundlichen Gr��en';
					if (isset($lang['_MITFG_'])) {
						$mfg1=_MITFG_;
					}
					$mailt=$liek1.',

Ihr Fahrzeug <<markencode>> <<typ>> mit dem Kennzeichen <<kennzeichen>> wurde vom Verk�ufer <<verkaeufer>> f�r eine Probefahrt f�r einen Kunden reserviert.
Startdatum: <<datum1>> - <<uhrzeit1>> Uhr
Enddatum: <<datum2>> - <<uhrzeit2>> Uhr

Bitte ber�cksichtigen Sie diese Information f�r Ihre pers�nliche Planung.

'.$mfg1.'
CarloCRM';
					if (isset($cfg_kfzsuche_text4_ma_mailtext) and $cfg_kfzsuche_text4_ma_mailtext!='') {
						$mailt=$cfg_kfzsuche_text4_ma_mailtext;
					}
					$mailt='Es wurde eine Probefahrt f�r ein Fahrzeug erstellt, wo Sie der aktuelle Fahrer sind:
Fahrzeug: <<markencode>> <<typ>>, <<kennzeichen>>  / <<fahrgestellnummer>>

Startdatum: <<datum1>> <<uhrzeit1>>
Enddatum:  <<datum2>> <<uhrzeit2>>
Benutzer: <<ersteller>>
';
					$mailt=p4n_sb_strreplace('<<markencode>>', $kfz_marke, $mailt);
					$mailt=p4n_sb_strreplace('<<typ>>', $kfz_typ, $mailt);
					$mailt=p4n_sb_strreplace('<<kennzeichen>>', $kennzeichen, $mailt);
					$mailt=p4n_sb_strreplace('<<fahrgestellnummer>>', $fgnr, $mailt);
					$mailt=p4n_sb_strreplace('<<verkaeufer>>', $alle_bens[$ang_kv_user], $mailt);
					$mailt=p4n_sb_strreplace('<<datum1>>', $postfeld['pfdatum'], $mailt);
					$mailt=p4n_sb_strreplace('<<uhrzeit1>>', $postfeld['pfzeit'].':'.$postfeld['pfzeit2'], $mailt);
					$mailt=p4n_sb_strreplace('<<datum2>>', $postfeld['pfdatumb'], $mailt);
					$mailt=p4n_sb_strreplace('<<uhrzeit2>>', $postfeld['pfzeitb'].':'.$postfeld['pfzeitb2'], $mailt);
					$mailt=p4n_sb_strreplace('<<kunde>>', kundenbezeichnung($_SESSION['stammdaten_id']).' ('.$_SESSION['stammdaten_id'].')', $mailt);
					$mailt=p4n_sb_strreplace('<<ersteller>>', $_SESSION['mitarbeiter_name2'], $mailt);
					
					if ($cfg_internerfahrer_pfakv_email_ics) {
					$vcal_text = '';
                    $nurtext = 1;
                    $_GET['tid'] = $kal_id;
                    include_once('inc/iCalcreator.class.php');
                    include_once('ical_export.php');
                    if (p4n_mb_string('strlen', $vcal_text) > 0) {
                        if (preg_match('/(BEGIN:VCALENDAR[\w\W]*?:[\w\W]*?)(BEGIN:VEVENT[\w\W]*?:[\w\W]*(?:END:VEVENT)*)(END:VCALENDAR)/ims', $vcal_text, $match)) {
                            if (preg_match_all('/BEGIN:VEVENT[\w\W]*?:[\w\W]*?END:VEVENT/mis', $match[2], $preg_match_split)) {
                                if (!empty($preg_match_split) && isset($preg_match_split[0])) {
                                    foreach ($preg_match_split[0] as $key => $vevents_part) {
                                        if (trim($vevents_part)!='') {
                                            $dateiname = 'temp/'._TERMIN_TERMIN_.'_'.adodb_date('Y-m-d_H_i_s', time()).'_'.$_SESSION['user_id'].($key > 0 ? '_'.$key : '').'.ics';
                                            if ($fp=fopen($dateiname, 'w')) {
                                                fwrite($fp, $match[1].$vevents_part."\n".$match[3]);
                                                fclose($fp);
                                            }
                                            $mail->AddAttachment($dateiname, _TERMIN_TERMIN_.'.ics', "base64", 'text/x-vCalendar');
                                        }
                                    }
                                }
                            }
                        }
                    }
					}
					
					$mail->Body = $mailt;
					$okv=$mail->Send();
					if (!$okv) {
						echo _EMAILING_EMAILS_FEHLER_.'<br>'.javas('alert("'._EMAILING_EMAILS_FEHLER_.'");');
					}
					
					if ($fp2=fopen('inc/'.$_SESSION['cfg_kunde'].'/maillog.txt', 'a')) {
						fwrite($fp2, adodb_date('d.m.Y H:i:s', time()).': '.($okv?_OK_:_FEHLER_).' - '._PROBEFAHRT_.' int. Fahrer: '.$kfz_marke.' '.$kfz_typ.' / '.$kennzeichen.' / '._KUNDE_.': '.kundenbezeichnung($_SESSION['stammdaten_id']).' ('.$_SESSION['stammdaten_id'].') / '._BENUTZER_.': '.$_SESSION['mitarbeiter_name2']."\r\n");
						fclose($fp2);
					}
							}
						}
						}
					}
			}
			// Mail an Betreuer der PF
			if (!$ist_intpf and $cfg_kfzsuche_pf_emailbetreuer) {
					if (1) {
						if (intval($ang_kv_user)>0) {
						$res7=$db->select(
							$sql_tab['benutzer'],
							$sql_tabs['benutzer']['email'],
							$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($ang_kv_user)
						);
						if ($row7=$db->zeile($res7)) {
							if ($row7[0]!='' and $row7[0]!=$merkeintfahrermail) {
								include_once("mailconf.php");
								$abse='CRM';
								if ($_SESSION['user_email']!='') {
									$abse=$_SESSION['user_email'];
								} elseif ($mcs_pop3_email!='') {
									$abse=$mcs_pop3_email;
								}
								$mail->ClearAllRecipients();
								$mail->ClearAttachments();
								$mail->From     = $abse;
								$mail->FromName = 'CRM';
								$mail->IsHTML(false);
								$mail->Subject  = _PROBEFAHRT_.' '.$kennzeichen.' '._VON_.' '.$alle_bens[$ang_kv_user];
								$mail->AddAddress($row7[0]);
								$merkeintfahrermail=$row7[0];
					$liek1='Lieber Kollege';
					if (isset($lang['_LIEBER_KOLLEGE_'])) {
						$liek1=_LIEBER_KOLLEGE_;
					}
					$mfg1='Mit freundlichen Gr��en';
					if (isset($lang['_MITFG_'])) {
						$mfg1=_MITFG_;
					}
					$mailt=$liek1.',

Ihr Fahrzeug <<markencode>> <<typ>> mit dem Kennzeichen <<kennzeichen>> wurde vom Verk�ufer <<verkaeufer>> f�r eine Probefahrt f�r einen Kunden reserviert.
Startdatum: <<datum1>> - <<uhrzeit1>> Uhr
Enddatum: <<datum2>> - <<uhrzeit2>> Uhr

Bitte ber�cksichtigen Sie diese Information f�r Ihre pers�nliche Planung.

'.$mfg1.'
CarloCRM';
					if (isset($cfg_kfzsuche_text4_ma_mailtext) and $cfg_kfzsuche_text4_ma_mailtext!='') {
						$mailt=$cfg_kfzsuche_text4_ma_mailtext;
					}
					$mailt='Es wurde eine Probefahrt erstellt:
Fahrzeug: <<markencode>> <<typ>>, <<kennzeichen>>  / <<fahrgestellnummer>>

Startdatum: <<datum1>> <<uhrzeit1>>
Enddatum:  <<datum2>> <<uhrzeit2>>
Benutzer: <<ersteller>>
';
					$mailt=p4n_sb_strreplace('<<markencode>>', $kfz_marke, $mailt);
					$mailt=p4n_sb_strreplace('<<typ>>', $kfz_typ, $mailt);
					$mailt=p4n_sb_strreplace('<<kennzeichen>>', $kennzeichen, $mailt);
					$mailt=p4n_sb_strreplace('<<fahrgestellnummer>>', $fgnr, $mailt);
					$mailt=p4n_sb_strreplace('<<verkaeufer>>', $alle_bens[$ang_kv_user], $mailt);
					$mailt=p4n_sb_strreplace('<<datum1>>', $postfeld['pfdatum'], $mailt);
					$mailt=p4n_sb_strreplace('<<uhrzeit1>>', $postfeld['pfzeit'].':'.$postfeld['pfzeit2'], $mailt);
					$mailt=p4n_sb_strreplace('<<datum2>>', $postfeld['pfdatumb'], $mailt);
					$mailt=p4n_sb_strreplace('<<uhrzeit2>>', $postfeld['pfzeitb'].':'.$postfeld['pfzeitb2'], $mailt);
					$mailt=p4n_sb_strreplace('<<kunde>>', kundenbezeichnung($_SESSION['stammdaten_id']).' ('.$_SESSION['stammdaten_id'].')', $mailt);
					$mailt=p4n_sb_strreplace('<<ersteller>>', $_SESSION['mitarbeiter_name2'], $mailt);
					
					if ($cfg_kfzsuche_pf_emailbetreuer_ics) {
					$vcal_text = '';
                    $nurtext = 1;
                    $_GET['tid'] = $kal_id;
                    include_once('inc/iCalcreator.class.php');
                    include_once('ical_export.php');
                    if (p4n_mb_string('strlen', $vcal_text) > 0) {
                        if (preg_match('/(BEGIN:VCALENDAR[\w\W]*?:[\w\W]*?)(BEGIN:VEVENT[\w\W]*?:[\w\W]*(?:END:VEVENT)*)(END:VCALENDAR)/ims', $vcal_text, $match)) {
                            if (preg_match_all('/BEGIN:VEVENT[\w\W]*?:[\w\W]*?END:VEVENT/mis', $match[2], $preg_match_split)) {
                                if (!empty($preg_match_split) && isset($preg_match_split[0])) {
                                    foreach ($preg_match_split[0] as $key => $vevents_part) {
                                        if (trim($vevents_part)!='') {
                                            $dateiname = 'temp/'._TERMIN_TERMIN_.'_'.adodb_date('Y-m-d_H_i_s', time()).'_'.$_SESSION['user_id'].($key > 0 ? '_'.$key : '').'.ics';
                                            if ($fp=fopen($dateiname, 'w')) {
                                                fwrite($fp, $match[1].$vevents_part."\n".$match[3]);
                                                fclose($fp);
                                            }
                                            $mail->AddAttachment($dateiname, _TERMIN_TERMIN_.'.ics', "base64", 'text/x-vCalendar');
                                        }
                                    }
                                }
                            }
                        }
                    }
					}
					
					$mail->Body = $mailt;
					$okv=$mail->Send();
					if (!$okv) {
						echo _EMAILING_EMAILS_FEHLER_.'<br>'.javas('alert("'._EMAILING_EMAILS_FEHLER_.'");');
					}
					
					if ($fp2=fopen('inc/'.$_SESSION['cfg_kunde'].'/maillog.txt', 'a')) {
						fwrite($fp2, adodb_date('d.m.Y H:i:s', time()).': '.($okv?_OK_:_FEHLER_).' - '._PROBEFAHRT_.' int. Fahrer: '.$kfz_marke.' '.$kfz_typ.' / '.$kennzeichen.' / '._KUNDE_.': '.kundenbezeichnung($_SESSION['stammdaten_id']).' ('.$_SESSION['stammdaten_id'].') / '._BENUTZER_.': '.$_SESSION['mitarbeiter_name2']."\r\n");
						fclose($fp2);
					}
							}
						}
						}
					}
			}
			
			// E-Mail an MA?
			if (!$ist_intpf and $cfg_kfzsuche_text4_ma) {
				if ($kfz_t4!='' and isset($alle_bens6[$kfz_t4]) and $alle_bens6[$kfz_t4]!=$merkeintfahrermail) {
					include_once("mailconf.php");
					$abse='CRM';
					if ($_SESSION['user_email']!='') {
						$abse=$_SESSION['user_email'];
					} elseif ($mcs_pop3_email!='') {
						$abse=$mcs_pop3_email;
					}
					$mail->From     = $abse;
					$mail->FromName = 'CRM';
					$mail->IsHTML(false);
					$mail->Subject  = _PROBEFAHRT_.' '.$kennzeichen.' '._VON_.' '.$alle_bens[$ang_kv_user];
					$mail->AddAddress($alle_bens6[$kfz_t4]);
					$liek1='Lieber Kollege';
					if (isset($lang['_LIEBER_KOLLEGE_'])) {
						$liek1=_LIEBER_KOLLEGE_;
					}
					$mfg1='Mit freundlichen Gr��en';
					if (isset($lang['_MITFG_'])) {
						$mfg1=_MITFG_;
					}
					$mailt=$liek1.',

Ihr Fahrzeug <<markencode>> <<typ>> mit dem Kennzeichen <<kennzeichen>> wurde vom Verk�ufer <<verkaeufer>> f�r eine Probefahrt f�r einen Kunden reserviert.
Startdatum: <<datum1>> - <<uhrzeit1>> Uhr
Enddatum: <<datum2>> - <<uhrzeit2>> Uhr

Bitte ber�cksichtigen Sie diese Information f�r Ihre pers�nliche Planung.

'.$mfg1.'
CarloCRM';
					if (isset($cfg_kfzsuche_text4_ma_mailtext) and $cfg_kfzsuche_text4_ma_mailtext!='') {
						$mailt=$cfg_kfzsuche_text4_ma_mailtext;
					}
					$mailt=p4n_sb_strreplace('<<markencode>>', $kfz_marke, $mailt);
					$mailt=p4n_sb_strreplace('<<typ>>', $kfz_typ, $mailt);
					$mailt=p4n_sb_strreplace('<<kennzeichen>>', $kennzeichen, $mailt);
					$mailt=p4n_sb_strreplace('<<verkaeufer>>', $alle_bens[$ang_kv_user], $mailt);
					$mailt=p4n_sb_strreplace('<<datum1>>', $postfeld['pfdatum'], $mailt);
					$mailt=p4n_sb_strreplace('<<uhrzeit1>>', $postfeld['pfzeit'].':'.$postfeld['pfzeit2'], $mailt);
					$mailt=p4n_sb_strreplace('<<datum2>>', $postfeld['pfdatumb'], $mailt);
					$mailt=p4n_sb_strreplace('<<uhrzeit2>>', $postfeld['pfzeitb'].':'.$postfeld['pfzeitb2'], $mailt);
					$mailt=p4n_sb_strreplace('<<kunde>>', kundenbezeichnung($_SESSION['stammdaten_id']).' ('.$_SESSION['stammdaten_id'].')', $mailt);
					
					$mail->Body = $mailt;
					$okv=$mail->Send();
					if (!$okv) {
						echo _EMAILING_EMAILS_FEHLER_.'<br>'.javas('alert("'._EMAILING_EMAILS_FEHLER_.'");');
					}
					
					if ($fp2=fopen('inc/'.$_SESSION['cfg_kunde'].'/maillog.txt', 'a')) {
						fwrite($fp2, adodb_date('d.m.Y H:i:s', time()).': '.($okv?_OK_:_FEHLER_).' - '._PROBEFAHRT_.': '.$kfz_marke.' '.$kfz_typ.' / '.$kennzeichen.' / '._KUNDE_.': '.kundenbezeichnung($_SESSION['stammdaten_id']).' ('.$_SESSION['stammdaten_id'].') / '._BENUTZER_.': '.$_SESSION['mitarbeiter_name2']."\r\n");
						fclose($fp2);
					}
				}
			}
			}
			// Korrespondenz/Vertrag:
			$det_datei='probefahrt.rtf';
			if (isset($postfeld['pf_vorlage'])) {
				if ($postfeld['pf_vorlage']!='') {
					$det_datei=$postfeld['pf_vorlage'];
				}
			}
			if (isset($postfeld['at_pfart'])) {
				if (intval($postfeld['at_pfart'])==3) {
					$det_datei='kundenersatzfahrzeug.rtf';
				}
			}
			$ist_docx=false;
			$cfg_kvdok='vorlagen/'.$det_datei;
			if (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei)) {
				$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei;
			} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.p4n_mb_string('substr',$det_datei, 0, -4).'.docx')) {
				$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.p4n_mb_string('substr',$det_datei, 0, -4).'.docx';
				$ist_docx=true;
			}
			
			$aov_vgef=false;
			if ($aov_gruppe!='') {
				$det_datei2='probefahrt';
				$det_datei2.='_'.$aov_gruppe;
				if (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.rtf')) {
					$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.rtf';
					$aov_vgef=true;
				} elseif (is_file('vorlagen/'.$det_datei2.'.rtf')) {
					$cfg_kvdok='vorlagen/'.$det_datei2.'.rtf';
					$aov_vgef=true;
				} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.docx')) {
					$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.docx';
					$aov_vgef=true;
					$ist_docx=true;
				} elseif (is_file('vorlagen/'.$det_datei2.'.docx')) {
					$cfg_kvdok='vorlagen/'.$det_datei2.'.docx';
					$aov_vgef=true;
					$ist_docx=true;
				}
			}
			
			if ($_SESSION['cfg_kunde']=='carlo_opel_kramm') {
				if (strtolower($kfz_marke)=='chevrolet' and substr(strtolower($kfz_typm), 0, strlen('corvette c8'))=='corvette c8') {
					$det_datei2='probefahrt';
					$det_datei2.='_corvette';
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.rtf')) {
						$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.rtf';
						$aov_vgef=true;
					} elseif (is_file('vorlagen/'.$det_datei2.'.rtf')) {
						$cfg_kvdok='vorlagen/'.$det_datei2.'.rtf';
						$aov_vgef=true;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.docx')) {
						$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.docx';
						$aov_vgef=true;
						$ist_docx=true;
					} elseif (is_file('vorlagen/'.$det_datei2.'.docx')) {
						$cfg_kvdok='vorlagen/'.$det_datei2.'.docx';
						$aov_vgef=true;
						$ist_docx=true;
					}
				}
			}
			
			if ($cfg_kfzsuche_pf_lagerortauswahl) {
				
			} elseif (!$aov_vgef and isset($postfeld['vorlage_zus'])) {
				$det_datei2='probefahrt';
				$det_datei2.='_'.p4n_mb_string('strtolower',trim($postfeld['vorlage_zus']));
				if (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.rtf')) {
					$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.rtf';
					$aov_vgef=true;
				} elseif (is_file('vorlagen/'.$det_datei2.'.rtf')) {
					$cfg_kvdok='vorlagen/'.$det_datei2.'.rtf';
					$aov_vgef=true;
				} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.docx')) {
					$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.docx';
					$ist_docx=true;
					$aov_vgef=true;
				} elseif (is_file('vorlagen/'.$det_datei2.'.docx')) {
					$cfg_kvdok='vorlagen/'.$det_datei2.'.docx';
					$ist_docx=true;
					$aov_vgef=true;
				}
			} elseif (!$aov_vgef and $postfeld['vertrag_lagerort']!='' and $kfz_marke!='') {
				$v_lao=$postfeld['vertrag_lagerort'];
				$res3=$db->select(
					$sql_tab['mandant'],
					array(
						$sql_tabs['mandant']['bezeichnung'],
						$sql_tabs['mandant']['parent_id']
					),
					$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($v_lao)
				);
				if ($row3=$db->zeile($res3)) {
					$v_lao=trim($row3[0]);
					$det_datei2=p4n_mb_string('substr',$det_datei, 0, -4);
					$det_datei2.='_'.$v_lao;
					$det_datei2.='_'.p4n_mb_string('strtolower',trim($kfz_marke));
					$det_datei3=p4n_mb_string('substr',$det_datei, 0, -4);
					$det_datei3.='_M'.$row3[1];
					$det_datei3.='_'.p4n_mb_string('strtolower',trim($kfz_marke));
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei3.'.rtf')) {
						$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei3.'.rtf';
						$aov_vgef=true;
					} elseif (is_file('vorlagen/'.$det_datei3.'.rtf')) {
						$cfg_kvdok='vorlagen/'.$det_datei3.'.rtf';
						$aov_vgef=true;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.rtf')) {
						$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.rtf';
						$aov_vgef=true;
					} elseif (is_file('vorlagen/'.$det_datei2.'.rtf')) {
						$cfg_kvdok='vorlagen/'.$det_datei2.'.rtf';
						$aov_vgef=true;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei3.'.docx')) {
						$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei3.'.docx';
						$ist_docx=true;
						$aov_vgef=true;
					} elseif (is_file('vorlagen/'.$det_datei3.'.docx')) {
						$cfg_kvdok='vorlagen/'.$det_datei3.'.docx';
						$ist_docx=true;
						$aov_vgef=true;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.docx')) {
						$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.docx';
						$ist_docx=true;
						$aov_vgef=true;
					} elseif (is_file('vorlagen/'.$det_datei2.'.docx')) {
						$cfg_kvdok='vorlagen/'.$det_datei2.'.docx';
						$ist_docx=true;
						$aov_vgef=true;
					}
				}
			}
			if (!$aov_vgef and $postfeld['vertrag_lagerort']!='') {
				$v_lao=$postfeld['vertrag_lagerort'];
				$res3=$db->select(
					$sql_tab['mandant'],
					array(
						$sql_tabs['mandant']['bezeichnung'],
						$sql_tabs['mandant']['parent_id']
					),
					$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($v_lao)
				);
				if ($row3=$db->zeile($res3)) {
					$v_lao=trim($row3[0]);

					$det_datei2=p4n_mb_string('substr',$det_datei, 0, -4);
					$det_datei2.='_'.$v_lao;
					$det_datei3=p4n_mb_string('substr',$det_datei, 0, -4);
					$det_datei3.='_M'.$row3[1];
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei3.'.rtf')) {
						$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei3.'.rtf';
					} elseif (is_file('vorlagen/'.$det_datei3.'.rtf')) {
						$cfg_kvdok='vorlagen/'.$det_datei3.'.rtf';
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.rtf')) {
						$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.rtf';
					} elseif (is_file('vorlagen/'.$det_datei2.'.rtf')) {
						$cfg_kvdok='vorlagen/'.$det_datei2.'.rtf';
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei3.'.docx')) {
						$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei3.'.docx';
						$ist_docx=true;
					} elseif (is_file('vorlagen/'.$det_datei3.'.docx')) {
						$cfg_kvdok='vorlagen/'.$det_datei3.'.docx';
						$ist_docx=true;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.docx')) {
						$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.docx';
						$ist_docx=true;
					} elseif (is_file('vorlagen/'.$det_datei2.'.docx')) {
						$cfg_kvdok='vorlagen/'.$det_datei2.'.docx';
						$ist_docx=true;
					}
				}
			}
			if ($ist_docx) {
				$cfg_kvdok=docx_entp($cfg_kvdok);
			}
			
			$felder=allefelder($cfg_kvdok);
			$inhalt='';
			if ($fp=@fopen($cfg_kvdok, 'r')) {
				$gesamtblock='';
				$inhalt=fread($fp, filesize($cfg_kvdok));
				fclose($fp);
			}
			$inhalt=preg_replace('/\}\{\\\\f1\\\\fs20\\\\insrsid\d+ /', '', $inhalt);
			
			if ($ustabw>0) {
				$inhalt=p4n_sb_strreplace('19%', $ustabw.'%', $inhalt);
				$inhalt=p4n_sb_strreplace('19 %', $ustabw.' %', $inhalt);
			}
			
			$inhalt=p4n_sb_strreplace('<<kennzeichen>>', $kennzeichen, $inhalt);
			$inhalt=p4n_sb_strreplace('<<vin>>', $fgnr, $inhalt);
			$inhalt=p4n_sb_strreplace('<<kfz>>', $kfz, $inhalt);
			$inhalt=p4n_sb_strreplace('<<markencode>>', $kfz_marke, $inhalt);
			$inhalt=p4n_sb_strreplace('<<typmodell>>', $kfz_typm, $inhalt);
			$inhalt=p4n_sb_strreplace('<<farbe>>', $kfz_farbe, $inhalt);
			$inhalt=p4n_sb_strreplace('<<datum_ez>>', $kfz_ez, $inhalt);
			$inhalt=p4n_sb_strreplace('<<kw>>', $kfz_kw, $inhalt);
			$inhalt=p4n_sb_strreplace('<<ps>>', $kfz_ps, $inhalt);
			$inhalt=p4n_sb_strreplace('<<refnr>>', $kfz_haendlerstatus, $inhalt);
			if ($cfg_kfzsuche_pf_kmstand) {
				if ($postfeld['pf_kmstand']!='' and intval($postfeld['pf_kmstand'])>0) {
					$inhalt=p4n_sb_strreplace('<<kmstand>>', $postfeld['pf_kmstand'], $inhalt);
				}
				if ($cfg_kfzsuche_pf_kmstandleer) {
					$inhalt=p4n_sb_strreplace('<<kmstand>>', $postfeld['pf_kmstand'], $inhalt);
				}
			}
			$inhalt=p4n_sb_strreplace('<<kmstand>>', $kfz_kmstand, $inhalt);
			$inhalt=p4n_sb_strreplace('<<datum1>>', $postfeld['pfdatum'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<zeit1>>', $postfeld['pfzeit'].':'.$postfeld['pfzeit2'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<bei1>>', $ses_ma, $inhalt);
			$inhalt=p4n_sb_strreplace('<<datum2>>', $postfeld['pfdatumb'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<zeit2>>', $postfeld['pfzeitb'].':'.$postfeld['pfzeitb2'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<bei2>>', $ses_ma, $inhalt);
			$inhalt=p4n_sb_strreplace('<<mitarbeiter>>', $ses_ma, $inhalt);
			$inhalt=p4n_sb_strreplace('<<mitarbeiter_email>>', $ses_ma_email, $inhalt);
			$inhalt=p4n_sb_strreplace('<<mitarbeiter_telefon>>', $ses_ma_tel, $inhalt);
			$inhalt=p4n_sb_strreplace('<<mitarbeiter_fax>>', $ses_ma_fax, $inhalt);
			$inhalt=p4n_sb_strreplace('<<mitarbeiter_mobilfon>>', $ses_ma_mob, $inhalt);
			$inhalt=p4n_sb_strreplace('<<euro>>', number_format(doubleval(str_replace(',', '.', $postfeld['uebertag'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<km>>', number_format(doubleval($postfeld['freikm']), 0, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<eurokm>>', number_format(doubleval(str_replace(',', '.', $postfeld['ueberkm'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<fsklasse>>', $postfeld['fsklasse'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<fsnummer>>', $postfeld['fs_nummer'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<fsort>>', $postfeld['fs_ort'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<text_4>>', $kfz_t4, $inhalt);
			$inhalt=p4n_sb_strreplace('<<fsdatum>>', $postfeld['fs_datum'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<persnr>>', $postfeld['fs_panummer'], $inhalt);
			
			if (isset($postfeld['pf_nutzungsgrund']) and $postfeld['pf_nutzungsgrund']=='-1') {
				$postfeld['pf_nutzungsgrund']='-';
			}
			$inhalt=p4n_sb_strreplace('<<nutzungsgrund>>', $postfeld['pf_nutzungsgrund'], $inhalt);
			if (isset($postfeld['pf_tankstand']) and $postfeld['pf_tankstand']=='-1') {
				$postfeld['pf_tankstand']='-';
			}
			$inhalt=p4n_sb_strreplace('<<tankstand>>', $postfeld['pf_tankstand'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kraftstoffkosten>>', $postfeld['pf_kraftstoffkosten'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<abweichenderfahrer>>', $postfeld['pf_abweichenderfahrer'], $inhalt);
			
			$inhalt=p4n_sb_strreplace('<<kfznotiz>>', p4n_mb_string('str_replace', "\n", '\\par ', $postfeld['pf_kfznotiz']), $inhalt);
			$inhalt=p4n_sb_strreplace('<<kfzinfo>>', p4n_mb_string('str_replace', "\n", '\\par ', $postfeld['pf_kfznotiz']), $inhalt);
			if (isset($postfeld['pf_bemerkung'])) {
				$inhalt=p4n_sb_strreplace('<<kfzbemerkung>>', p4n_mb_string('str_replace', "\n", '\\par ', $postfeld['pf_bemerkung']), $inhalt);
			}
			
			if ($vorschau) {
				if (!isset($cfg_kfzsuche_vorschautext)) {
					$cfg_kfzsuche_vorschautext=_VORSCHAU_;
				}
				if (isset($cfg_kfzsuche_vorschautext) and $cfg_kfzsuche_vorschautext!='') {
					$inhalt=p4n_sb_strreplace('<<vorschau>>', $cfg_kfzsuche_vorschautext, $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<vorschau>>', '', $inhalt);
				}
			} else {
				$inhalt=p4n_sb_strreplace('<<vorschau>>', '', $inhalt);
			}
			
			$sonstiges2='';
			$zusatzdateien1=array();
            if (!empty($postfeld['infotextz'])) {
                @reset($postfeld['infotextz']);
                while (list($ikey, $ival)=@each($postfeld['infotextz'])) {
                    $inft1n=base64_decode($postfeld['infotextz2'][$ikey]);
                    for ($zi3=1; $zi3<=10; $zi3++) {
                        if (isset($postfeld['sonst_'.$ikey.'_'.$zi3])) {
                            $inft1n=preg_replace('/xxx/i', $postfeld['sonst_'.$ikey.'_'.$zi3], $inft1n, 1);
                        }
                    }
                    $msv_inhalt=$inhalt;
                    if ($postfeld['infotextzkd'][$ikey]=='1') {
                        $inhalt=p4n_sb_strreplace('<<sonstv_r'.$postfeld['infotextz_rang'][$ikey].'>>', '', $inhalt);
                    } else {
                        $inhalt=p4n_sb_strreplace('<<sonstv_r'.$postfeld['infotextz_rang'][$ikey].'>>', $inft1n, $inhalt);
                        if ($msv_inhalt==$inhalt and !isset($nicht_in_sonst[$ikey])) {
                            $sep_sv2=' ';
                            if (isset($cfg_kfzsuche_sonstiges2_sep)) {
                                if ($cfg_kfzsuche_sonstiges2_sep!='') {
                                    $sep_sv2=$cfg_kfzsuche_sonstiges2_sep;
                                }
                            }
                            if ($sonstiges2!='') {
                                $sonstiges2.=$sep_sv2;
                            }
                            $sonstiges2.=$inft1n;
                        }
                    }
                    if ($postfeld['infotextz_datei'][$ikey]!='') {
                        $keinezdkorr=false;
                        if ($postfeld['infotextzkk'][$ikey]=='1') {
                            $keinezdkorr=true;
                        }
                        $zdmitpdf=false;
                        if ($postfeld['infotextzpdf'][$ikey]=='1') {
                            $zdmitpdf=true;
                        }
                        $zusatzdateien1[$postfeld['infotextz_datei'][$ikey]]=array($postfeld['infotextz_rang'][$ikey], $inft1n, $keinezdkorr, $zdmitpdf);
                    }
                }
            }
			$inhalt=p4n_sb_strreplace('<<sonstiges>>', str_replace(array("\n", '<br>'), '\\par ', $sonstiges2), $inhalt);
			
			if (isset($postfeld['pf_kfznotiz']) and intval($postfeld['pid'])>0) {
				$db->update(
					$sql_tab['produktzuordnung'],
					array(
						$sql_tabs['produktzuordnung']['notizen'] => $db->str($postfeld['pf_kfznotiz'])
					),
					$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
				);
			}
			
			$auswat=array('' => '', '1' => 'Fahrten auf Freilandstra�en', '2' => 'Fahrten an Sonn- und Feiertagen');
			$inhalt=p4n_sb_strreplace('<<pf_grund>>', $auswat[$postfeld['pf_at_opt1']], $inhalt);
			$inhalt=p4n_sb_strreplace('<<pf_von_nach>>', $postfeld['pf_at_opt2'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<pf_zweck>>', $postfeld['pf_at_opt3'], $inhalt);
			
		// Standardlagerort:
		if (preg_match('/<<lagerort_/i', $inhalt) or preg_match('/<<mandant_/i', $inhalt) or preg_match('/<<'.bef_format_kfzs(_LAGERORT_).'_/i', $inhalt) or preg_match('/<<'.bef_format_kfzs(_MANDANT_).'_/i', $inhalt)) {
			$res6=$db->select(
				$sql_tab['benutzer'],
				$sql_tabs['benutzer']['standard_lagerort'],
				$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id'])
			);
			$std_lao=0;
			$std_mand=0;
			if ($row6=$db->zeile($res6)) {
				if (intval($row6[0])>0) {
					$std_lao=intval($row6[0]);
				}
			}
			if ($std_lao==0 and intval($m_vlao1)>0) {
				$std_lao=$m_vlao1;
			}
			
			if ($cfg_kfzsuche_pf_lagerortauswahl and intval($postfeld['vertrag_lagerort'])>0) {
				$std_lao=$postfeld['vertrag_lagerort'];
			}
			
			$mandinfo[0]=array();
			if (!isset($mandinfo[$std_lao])) {
					$sqltm=array(
							$sql_tabs['mandant']['firma'],
							$sql_tabs['mandant']['adresse'],
							$sql_tabs['mandant']['plz'],
							$sql_tabs['mandant']['ort'],
							$sql_tabs['mandant']['briefkopf'],
							$sql_tabs['mandant']['parent_id']
					);
					if (isset($sql_tabs['mandant']['telefon'])) {
						$sqltm[]=$sql_tabs['mandant']['telefon'];
						$sqltm[]=$sql_tabs['mandant']['fax'];
						$sqltm[]=$sql_tabs['mandant']['email'];
						$sqltm[]=$sql_tabs['mandant']['internet'];
						$sqltm[]=$sql_tabs['mandant']['dealercode'];
                        if ($_SESSION['crm_version']>61 && isset($sql_tabs['mandant']['fusszeile'])) {
                            $sqltm[]=$sql_tabs['mandant']['fusszeile'];
                            $sqltm[]=$sql_tabs['mandant']['link1'];
                            $sqltm[]=$sql_tabs['mandant']['link2'];
                            $sqltm[]=$sql_tabs['mandant']['link3'];
                            $sqltm[]=$sql_tabs['mandant']['bezeichnung'];
                        }
					}
					$res4=$db->select(
						$sql_tab['mandant'],
						$sqltm,
						$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($std_lao)
					);
					$row4=$db->zeile($res4);
					$mandinfo[$std_lao]=$row4;

					if (intval($row4[5])>0) {
						$std_mand=intval($row4[5]);
						$res4=$db->select(
							$sql_tab['mandant'],
							$sqltm,
							$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($std_mand)
						);
						$row4=$db->zeile($res4);
						$mandinfo[$std_mand]=$row4;
					}
			}
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._BEZEICHNUNG_).'>>/', $mandinfo[$std_lao][0], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._ADRESSE_).'>>/', $mandinfo[$std_lao][1], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._PLZ_).'>>/', $mandinfo[$std_lao][2], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._ORT_).'>>/', $mandinfo[$std_lao][3], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._BRIEFKOPF_).'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_lao][4]), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._TELEFON2_).'>>/', $mandinfo[$std_lao][6], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._FAX_).'>>/', $mandinfo[$std_lao][7], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._EMAIL_).'>>/', $mandinfo[$std_lao][8], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._WWW_).'>>/', $mandinfo[$std_lao][9], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._NUMMER_).'>>/', $mandinfo[$std_lao][10], $inhalt);
            $inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._FOOTER_).'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_lao][11]), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._LINK_UPPERCASE_.'1').'>>/', $mandinfo[$std_lao][12], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._LINK_UPPERCASE_.'2').'>>/', $mandinfo[$std_lao][13], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._LINK_UPPERCASE_.'3').'>>/', $mandinfo[$std_lao][14], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._CODE_).'>>/', $mandinfo[$std_lao][15], $inhalt);
            
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._BEZEICHNUNG_).'>>/', $mandinfo[$std_mand][0], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._ADRESSE_).'>>/', $mandinfo[$std_mand][1], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._PLZ_).'>>/', $mandinfo[$std_mand][2], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._ORT_).'>>/', $mandinfo[$std_mand][3], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._BRIEFKOPF_).'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_mand][4]), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._TELEFON2_).'>>/', $mandinfo[$std_mand][6], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._FAX_).'>>/', $mandinfo[$std_mand][7], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._EMAIL_).'>>/', $mandinfo[$std_mand][8], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._WWW_).'>>/', $mandinfo[$std_mand][9], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._NUMMER_).'>>/', $mandinfo[$std_mand][10], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._FOOTER_).'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_mand][11]), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._LINK_UPPERCASE_.'1').'>>/', $mandinfo[$std_mand][12], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._LINK_UPPERCASE_.'2').'>>/', $mandinfo[$std_mand][13], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._LINK_UPPERCASE_.'3').'>>/', $mandinfo[$std_mand][14], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._CODE_).'>>/', $mandinfo[$std_mand][15], $inhalt);
            
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_bezeichnung').'>>/', $mandinfo[$std_lao][0], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_adresse').'>>/', $mandinfo[$std_lao][1], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_plz').'>>/', $mandinfo[$std_lao][2], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_ort').'>>/', $mandinfo[$std_lao][3], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_briefkopf').'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_lao][4]), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_telefon').'>>/', $mandinfo[$std_lao][6], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_fax').'>>/', $mandinfo[$std_lao][7], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_email').'>>/', $mandinfo[$std_lao][8], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_www').'>>/', $mandinfo[$std_lao][9], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_nummer').'>>/', $mandinfo[$std_lao][10], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_footer').'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_lao][11]), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_link1').'>>/', $mandinfo[$std_lao][12], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_link2').'>>/', $mandinfo[$std_lao][13], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_link3').'>>/', $mandinfo[$std_lao][14], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_code').'>>/', $mandinfo[$std_lao][15], $inhalt);
			
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_bezeichnung').'>>/', $mandinfo[$std_mand][0], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_adresse').'>>/', $mandinfo[$std_mand][1], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_plz').'>>/', $mandinfo[$std_mand][2], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_ort').'>>/', $mandinfo[$std_mand][3], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_briefkopf').'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_mand][4]), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_telefon').'>>/', $mandinfo[$std_mand][6], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_fax').'>>/', $mandinfo[$std_mand][7], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_email').'>>/', $mandinfo[$std_mand][8], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_www').'>>/', $mandinfo[$std_mand][9], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_nummer').'>>/', $mandinfo[$std_mand][10], $inhalt);
            $inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_footer').'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_mand][11]), $inhalt);
            $inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_link1').'>>/', $mandinfo[$std_mand][12], $inhalt);
            $inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_link2').'>>/', $mandinfo[$std_mand][13], $inhalt);
            $inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_link3').'>>/', $mandinfo[$std_mand][14], $inhalt);
            $inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_code').'>>/', $mandinfo[$std_mand][15], $inhalt);
		}
		
		if ($cfg_kfzsuche_holland) {
				$briefanr='';
				if (p4n_mb_string('strtolower',$postfeld['anrede'])==p4n_mb_string('strtolower',_HERR_) or p4n_mb_string('strtolower',$postfeld['anrede'])=='herrn') {
					$briefanr=_BRIEFANREDE_HERR_;
				} elseif (p4n_mb_string('strtolower',$postfeld['anrede'])==p4n_mb_string('strtolower',_FRAU_)) {
					$briefanr=_BRIEFANREDE_FRAU_;
				}
				if ($cfg_carlo_appserver_ws and $briefanr=='') {
					$res9=$db->select(
						$sql_tab['stammdaten'],
						$sql_tabs['stammdaten']['briefanrede'],
						$sql_tabs['stammdaten']['anrede'].'='.$db->str($postfeld['anrede']).' and '.$sql_tabs['stammdaten']['briefanrede'].'!='.$db->str('')
					);
					$alle_ba=array();
					while ($row9=$db->zeile($res9)) {
						$alle_ba[$row9[0]]++;
					}
					@arsort($alle_ba);
					if (list($key, $val)=@each($alle_ba)) {
						$briefanr=$key;
					}
				}
				
				$zus_ap1='';
				$res9=$db->select(
					$sql_tab['stammdaten_ansprechpartner'],
					array(
						$sql_tabs['stammdaten_ansprechpartner']['anrede'],
						$sql_tabs['stammdaten_ansprechpartner']['vorname'],
						$sql_tabs['stammdaten_ansprechpartner']['bezeichnung'],
						$sql_tabs['stammdaten_ansprechpartner']['titel'],
						$sql_tabs['stammdaten_ansprechpartner']['zusatz4'],
						$sql_tabs['stammdaten_ansprechpartner']['zusatz5']
					),
					$sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid'])
						.' and '.$sql_tabs['stammdaten_ansprechpartner']['hauptkontakt'].'='.$db->dblogic(true),
					$sql_tabs['stammdaten_ansprechpartner']['bezeichnung']
				);
				if ($row9=$db->zeile($res9)) {
					$zus_ap1="\\par ".'T.a.v. '.strtolower($row9[0]).($row9[3]!=''?' '.$row9[3]:'').' '.$row9[1].($row9[4]!=''?' '.$row9[4]:'').' '.$row9[2];
				}
				
				if ($postfeld['firma1']!='' and $postfeld['name']!='' and p4n_mb_string('strtolower',p4n_mb_string('substr',$postfeld['anrede'], 0, 4))!='bedr') {
					$inhalt=p4n_sb_preg_replace('/<<anrede>>.*<<vorname>>.*<<name>>/Uis', trim($postfeld['anrede'].' '.($postfeld['titel']!=''?$postfeld['titel'].' ':'').$postfeld['vorname'].' '.$postfeld['name'])."\\par ".$postfeld['firma1'], $inhalt);
					$inhalt=p4n_sb_preg_replace('/<<briefanrede>>.*<<mn>>.*<<name>>/Uis', str_replace('  ', ' ', trim($briefanr.' '.($postfeld['titel']!=''?$postfeld['titel'].' ':'').p4n_mb_string('ucfirst',$postfeld['firma3']).' '.$postfeld['name'])), $inhalt);
				} elseif ($postfeld['firma1']!='') {
					$inhalt=p4n_sb_preg_replace('/<<anrede>>.*<<vorname>>.*<<name>>/Uis', trim($postfeld['firma1']).$zus_ap1, $inhalt);
				} else {
					$inhalt=p4n_sb_preg_replace('/<<briefanrede>>.*<<mn>>.*<<name>>/Uis', str_replace('  ', ' ', trim($briefanr.' '.($postfeld['titel']!=''?$postfeld['titel'].' ':'').p4n_mb_string('ucfirst',$postfeld['firma3']).' '.$postfeld['name'])), $inhalt);
				}
			}
			$m_apid=$apid;
			$m_keinap=$keinap;
			if (preg_match('/<<ansprechpartner>>/', $inhalt)) {
				$apid=0;
				$keinap=true;
				$apbez='';
				$ap_tel='';
				$ap_mob='';
				if (intval($m_apid)>0) {
					$res9=$db->select(
						$sql_tab['stammdaten_ansprechpartner'],
						array(
							$sql_tabs['stammdaten_ansprechpartner']['anrede'],
							$sql_tabs['stammdaten_ansprechpartner']['vorname'],
							$sql_tabs['stammdaten_ansprechpartner']['bezeichnung'],
							$sql_tabs['stammdaten_ansprechpartner']['titel'],
							$sql_tabs['stammdaten_ansprechpartner']['telefon'],
							$sql_tabs['stammdaten_ansprechpartner']['mobil'],
							$sql_tabs['stammdaten_ansprechpartner']['geburtstag']
						),
						$sql_tabs['stammdaten_ansprechpartner']['ansprechpartner_id'].'='.$db->dbzahl($m_apid)
					);
					if ($row9=$db->zeile($res9)) {
						$apbez=trim($row9[0].' '.($row9[3]!=''?$row9[3].' ':'').$row9[1].' '.$row9[2]);
						$ap_tel=$row9[4];
						$ap_mob=$row9[5];
						$ap_geb=$db->unixdate($row9[6]);
					}
				}
				$inhalt=p4n_sb_strreplace('<<ansprechpartner>>', $apbez, $inhalt);
				$inhalt=p4n_sb_strreplace('<<ansprechpartner_tel>>', $ap_tel, $inhalt);
				$inhalt=p4n_sb_strreplace('<<ansprechpartner_mob>>', $ap_mob, $inhalt);
				$inhalt=p4n_sb_strreplace('<<ansprechpartner_geburtsdatum>>', $ap_geb, $inhalt);
			}
			$inhalt=vorlage_kdaten_ersetzen($inhalt, $postfeld['firma1'], $postfeld['vorname'], $postfeld['name'], $postfeld['titel'], $postfeld['anrede'], $_SESSION['stammdaten_id'], $postfeld['firma3']);
			$apid=$m_apid;
			$keinap=$m_keinap;
			if (preg_match('/<<briefanrede>>/', $inhalt)) {
				$inhalt=p4n_sb_preg_replace('/<<briefanrede>>.*<<mn>>.*,/Uis', _BRIEFANREDE_FIRMA_, $inhalt);
			}
			
			if (!preg_match('/<<vorname>>/', $inhalt)) {
				$inhalt=p4n_sb_strreplace('<<name>>', trim($postfeld['titel'].' '.$postfeld['vorname'].' '.$postfeld['name'].($postfeld['firma1']!=''?', '.$postfeld['firma1']:'')), $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<anschrift>>', trim($postfeld['adresse'].', '.$postfeld['plz'].' '.$postfeld['ort']), $inhalt);
			$inhalt=p4n_sb_strreplace('<<datum>>', adodb_date('d.m.Y'), $inhalt);
			$inhalt=p4n_sb_strreplace('<<datum_jahr>>', adodb_date('Y'), $inhalt);
			$inhalt=p4n_sb_strreplace('<<datumzeit>>', adodb_date('d.m.Y H:i'), $inhalt);
			$inhalt=p4n_sb_strreplace('<<zeit>>', adodb_date('H:i'), $inhalt);
			
			if (isset($postfeld['vorlage_rd_gk'])) {
				$res9=$db->select(
					$sql_tab['stammdaten_ansprechpartner'],
					array(
						$sql_tabs['stammdaten_ansprechpartner']['anrede'],
						$sql_tabs['stammdaten_ansprechpartner']['vorname'],
						$sql_tabs['stammdaten_ansprechpartner']['bezeichnung'],
						$sql_tabs['stammdaten_ansprechpartner']['titel'],
						$sql_tabs['stammdaten_ansprechpartner']['telefon'],
						$sql_tabs['stammdaten_ansprechpartner']['mobil'],		// 5
						$sql_tabs['stammdaten_ansprechpartner']['email']
					),
					$sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid'])
						.' and '.$sql_tabs['stammdaten_ansprechpartner']['hauptkontakt'].'='.$db->dblogic(true),
					$sql_tabs['stammdaten_ansprechpartner']['bezeichnung']
				);
				if ($row9=$db->zeile($res9)) {
					$inhalt=p4n_sb_strreplace('<<anrede_ap>>', $row9[0], $inhalt);
					$inhalt=p4n_sb_strreplace('<<vorname_ap>>', $row9[1], $inhalt);
					$inhalt=p4n_sb_strreplace('<<name_ap>>', $row9[2], $inhalt);
					$inhalt=p4n_sb_strreplace('<<titel_ap>>', $row9[3], $inhalt);
					$inhalt=p4n_sb_strreplace('<<tel_ap>>', $row9[4], $inhalt);
					$inhalt=p4n_sb_strreplace('<<mobil_ap>>', $row9[5], $inhalt);
					$inhalt=p4n_sb_strreplace('<<email_ap>>', $row9[6], $inhalt);
				}
			}
			$inhalt=p4n_sb_strreplace('<<anrede_ap>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<vorname_ap>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<name_ap>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<titel_ap>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<tel_ap>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<mobil_ap>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<email_ap>>', '', $inhalt);
			
			$kdnr1='';
		$intnr1='';
		if (intval($postfeld['stid'])>0) {
			if (isset($postfeld['lagerort']) or $manda_id>0) {
				$res3=$db->select(
					$sql_tab['stammdaten_mandant'],
					$sql_tabs['stammdaten_mandant']['nummer1'],
					$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid']).' and '.
					$sql_tabs['stammdaten_mandant']['mandant_id'].'='.$db->dbzahl($manda_id).' and '.
						$sql_tabs['stammdaten_mandant']['nummer1'].'!='.$db->str('')
				);
				if ($row3=$db->zeile($res3)) {
					$kdnr1=$row3[0];
				}
			}
			if ($kdnr1=='') {
				$res3=$db->select(
					$sql_tab['stammdaten_mandant'],
					$sql_tabs['stammdaten_mandant']['nummer1'],
					$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid']).' and '.
						$sql_tabs['stammdaten_mandant']['nummer1'].'!='.$db->str('')
				);
				if ($row3=$db->zeile($res3)) {
					$kdnr1=$row3[0];
				}
			}
			if (isset($postfeld['lagerort']) or $manda_id>0) {
				$res3=$db->select(
					$sql_tab['stammdaten_mandant'],
					$sql_tabs['stammdaten_mandant']['nummer2'],
					$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid']).' and '.
					$sql_tabs['stammdaten_mandant']['mandant_id'].'='.$db->dbzahl($manda_id).' and '.
						$sql_tabs['stammdaten_mandant']['nummer2'].'!='.$db->str('')
				);
				if ($row3=$db->zeile($res3)) {
					$intnr1=$row3[0];
				}
			}
			if ($intnr1=='') {
				$res3=$db->select(
					$sql_tab['stammdaten_mandant'],
					$sql_tabs['stammdaten_mandant']['nummer2'],
					$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid']).' and '.
						$sql_tabs['stammdaten_mandant']['nummer2'].'!='.$db->str('')
				);
				if ($row3=$db->zeile($res3)) {
					$intnr1=$row3[0];
				}
			}
		}
		if ($_SESSION['cfg_kunde']=='carlo_koltes' or $_SESSION['cfg_kunde']=='carlo_opel_dello') {
			$inhalt=p4n_sb_strreplace('<<kundennr>>', $postfeld['stid'], $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<stid>>', $postfeld['stid'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<kundennr>>', $kdnr1, $inhalt);
		$inhalt=p4n_sb_strreplace('<<intnr>>', $intnr1, $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<vat>>', $postfeld['steuernummer'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<taxoff>>', $postfeld['firma2'], $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<kunde>>', $anzeigename, $inhalt);
		$inhalt=p4n_sb_strreplace('<<adresse>>', $postfeld['adresse'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<plz>>', $postfeld['plz'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<ort>>', $postfeld['ort'].$zus_ort_landinfo, $inhalt);
		$inhalt=p4n_sb_strreplace('<<datum>>', adodb_date('d.m.Y'), $inhalt);
		$inhalt=p4n_sb_strreplace('<<datum_jahr>>', adodb_date('Y'), $inhalt);
		$inhalt=p4n_sb_strreplace('<<datumzeit>>', adodb_date('d.m.Y H:i'), $inhalt);
		$inhalt=p4n_sb_strreplace('<<zeit>>', adodb_date('H:i'), $inhalt);
		$inhalt=p4n_sb_strreplace('<<beruf>>', $postfeld['beruf'], $inhalt);
		$anr1=$postfeld['anrede'];
		if ($anr1=='HERRN' or $anr1=='HERR' or $anr1=='FRAU' or $anr1=='FIRMA') {
			$anr1=p4n_mb_string('ucfirst',p4n_mb_string('strtolower',$anr1));
		}
		$inhalt=p4n_sb_strreplace('<<anrede>>', $anr1, $inhalt);
		$inhalt=p4n_sb_strreplace('<<anrede2>>', $anr1, $inhalt);
		
		if ($postfeld['firma1']!='') {
			if (!preg_match('/<<firma>>/i', $inhalt)) {
				$inhalt=p4n_sb_strreplace('<<vorname>> <<name>>', '<<firma>> <<vorname>> <<name>>', $inhalt);
				if ($postfeld['name']=='' and $postfeld['vorname']=='') {
					$inhalt=p4n_sb_strreplace('<<name>>, <<vorname>>', '<<firma>> <<name>> <<vorname>>', $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<name>>, <<vorname>>', '<<firma>> <<name>>, <<vorname>>', $inhalt);
				}
			}
		}
		$inhalt=p4n_sb_strreplace('<<firma>>', $postfeld['firma1'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vorname>>', $postfeld['vorname'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<name>>', $postfeld['name'], $inhalt);
		
		if (preg_match('/<<steuernummer>>/Uis', $inhalt)) {
			$res8=$db->select(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['id'],
					$sql_tabs['stammdaten']['steuernummer']
				),
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($postfeld['stid'])
			);
			$row8=$db->zeile($res8);
			if (isset($postfeld['steuernummer'])) {
				$row8[1]=$postfeld['steuernummer'];
			}
			$inhalt=p4n_sb_strreplace('<<steuernummer>>', $row8[1], $inhalt);
		}
		if (preg_match('/<<fleetnummer>>/Uis', $inhalt)) {
			$res8=$db->select(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['id'],
					$sql_tabs['stammdaten']['fleetnummer']
				),
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($postfeld['stid'])
			);
			$row8=$db->zeile($res8);
			$inhalt=p4n_sb_strreplace('<<fleetnummer>>', $row8[1], $inhalt);
		}
		if (preg_match('/<<eva/Uis', $inhalt)) {
			$res8=$db->select(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['meinvpb'],
					$sql_tabs['stammdaten']['Telefon_3'],
					$sql_tabs['stammdaten']['Mobilfon_3'],
					$sql_tabs['stammdaten']['Fax_3'],
					$sql_tabs['stammdaten']['EMail_3']
				),
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($postfeld['stid'])
			);
			$row8=$db->zeile($res8);
			$inhalt=p4n_sb_strreplace('<<tel3>>', $row8[1], $inhalt);
			$inhalt=p4n_sb_strreplace('<<telefon3>>', $row8[1], $inhalt);
			$inhalt=p4n_sb_strreplace('<<mob3>>', $row8[2], $inhalt);
			$inhalt=p4n_sb_strreplace('<<mobil3>>', $row8[2], $inhalt);
			$inhalt=p4n_sb_strreplace('<<mobilfon3>>', $row8[2], $inhalt);
			$inhalt=p4n_sb_strreplace('<<fax3>>', $row8[3], $inhalt);
			$inhalt=p4n_sb_strreplace('<<email3>>', $row8[4], $inhalt);
			if ($row8[0]=='0') {
				$row8[0]='';
			}
			$inhalt=p4n_sb_strreplace('<<eva>>', $row8[0], $inhalt);
			$inhalt=p4n_sb_strreplace('<<evanummer>>', $row8[0], $inhalt);
		}
		if (p4n_mb_string('substr',$_SESSION['cfg_kunde'], 0, 17)=='carlo_opel_eisner') {
			$res3=$db->select(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['Telefon_1'],
					$sql_tabs['stammdaten']['Telefon_2'],
					$sql_tabs['stammdaten']['Mobilfon_1'],
					$sql_tabs['stammdaten']['Mobilfon_2'],
				),
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
			);
			if ($row3=$db->zeile($res3)) {
				$tel1p=$row3[0];
				if ($tel1p=='') {
					$tel1p=$row3[2];
				}
				$mtelp=$row3[1];
				if ($mtelp=='') {
					$mtelp=$row3[3];
				}
				$inhalt=p4n_sb_strreplace('<<tel1>>', $tel1p, $inhalt);
				$inhalt=p4n_sb_strreplace('<<tel2>>', $mtelp, $inhalt);
			}
		}
		
		if ($cfg_kfzsuche_kontaktaucheva) {
		$res8=$db->select(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['meinvpb'],
					$sql_tabs['stammdaten']['Telefon_3'],
					$sql_tabs['stammdaten']['Mobilfon_3'],
					$sql_tabs['stammdaten']['Fax_3'],
					$sql_tabs['stammdaten']['EMail_3']
				),
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($postfeld['stid'])
		);
		$row8=$db->zeile($res8);
		if ($postfeld['telefon']=='' and $row8[1]!='') {
			$inhalt=p4n_sb_strreplace('<<telefon1>>', $row8[1], $inhalt);
		}
		if ($postfeld['mobilfon']=='' and $row8[2]!='') {
			$inhalt=p4n_sb_strreplace('<<mobil>>', $row8[2], $inhalt);
			$inhalt=p4n_sb_strreplace('<<mobilfon1>>', $row8[2], $inhalt);
			$inhalt=p4n_sb_strreplace('<<mob1>>', $row8[2], $inhalt);
		}
		if ($postfeld['fax']=='' and $row8[3]!='') {
			$inhalt=p4n_sb_strreplace('<<fax>>', $row8[3], $inhalt);
			$inhalt=p4n_sb_strreplace('<<fax1>>', $row8[3], $inhalt);
		}
		if ($postfeld['email']=='' and $row8[4]!='') {
			$inhalt=p4n_sb_strreplace('<<email>>', $row8[4], $inhalt);
			$inhalt=p4n_sb_strreplace('<<email1>>', $row8[4], $inhalt);
		}
		}
		
		if (preg_match('/<<mobilfon1>>/', $inhalt)) {
			$res3=$db->select(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['Telefon_1'],
					$sql_tabs['stammdaten']['Telefon_2'],
					$sql_tabs['stammdaten']['Mobilfon_1'],
					$sql_tabs['stammdaten']['Mobilfon_2'],
					$sql_tabs['stammdaten']['EMail_1'],
					$sql_tabs['stammdaten']['EMail_2'],
					$sql_tabs['stammdaten']['Fax_1'],
					$sql_tabs['stammdaten']['Fax_2']
				),
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($postfeld['stid'])
			);
			if ($row3=$db->zeile($res3)) {
				$inhalt=p4n_sb_strreplace('<<telefon1>>', $row3[0], $inhalt);
				if ($row3[0]==$row3[1]) {
					$inhalt=p4n_sb_strreplace('<<telefon2>>', '', $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<telefon2>>', $row3[1], $inhalt);
				$inhalt=p4n_sb_strreplace('<<mobilfon1>>', $row3[2], $inhalt);
				if ($row3[2]==$row3[3]) {
					$inhalt=p4n_sb_strreplace('<<mobilfon2>>', '', $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<mobilfon2>>', $row3[3], $inhalt);
				$inhalt=p4n_sb_strreplace('<<email1>>', $row3[4], $inhalt);
				if ($row3[4]==$row3[5]) {
					$inhalt=p4n_sb_strreplace('<<email2>>', '', $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<email2>>', $row3[5], $inhalt);
				$inhalt=p4n_sb_strreplace('<<fax1>>', $row3[6], $inhalt);
				if ($row3[6]==$row3[7]) {
					$inhalt=p4n_sb_strreplace('<<fax2>>', '', $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<fax2>>', $row3[7], $inhalt);
			}
		}
		
		if ($bez_ang_kv2=='expose' and $kfz_fstatuscode=='30') {
			// sp�ter f�llen bei DVS-KFZ
		} else {
			$inhalt=p4n_sb_strreplace('<<kraftstoff>>', $pid_kraftstoff, $inhalt);
			$inhalt=p4n_sb_strreplace('<<kraftstoffart>>', $pid_kraftstoff, $inhalt);
		}
		if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
			if ($postfeld['idstatus']=='Wiederverk�ufer') {
				$inhalt=p4n_sb_strreplace('<<dbkfzstatus>>', 'H�ndlergesch�ft', $inhalt);
			} else {
				$inhalt=p4n_sb_strreplace('<<dbkfzstatus>>', $postfeld['db_fahrzeugstatus'], $inhalt);
			}
		}
		
		$std_tel=$postfeld['telefon'];
		if ($std_tel=='') {
			$std_tel=$postfeld['mobilfon'];
		}
		$inhalt=p4n_sb_strreplace('<<tel1>>', $std_tel, $inhalt);
		$inhalt=p4n_sb_strreplace('<<geb>>', $postfeld['geburtsdatum'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<geburtsort>>', $postfeld['geburtsort'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<personnr>>', substr(str_replace('.', '', $postfeld['geburtsdatum']), 0, 4).substr(str_replace('.', '', $postfeld['geburtsdatum']), -2).$postfeld['geburtsort'], $inhalt);
		
		if ($cfg_kfzsuche_kontakt_pg) {
							if (!preg_match('/<<telefon2>>/', $inhalt) and $postfeld['telefon2']!='' and $postfeld['telefon']=='') {
								$inhalt=p4n_sb_strreplace('<<telefon1>>', $postfeld['telefon2'], $inhalt);
							}
							$inhalt=p4n_sb_strreplace('<<telefon2>>', $postfeld['telefon2'], $inhalt);
							if (!preg_match('/<<mobil2>>/', $inhalt) and $postfeld['mobilfon2']!='' and $postfeld['mobilfon']=='') {
								$inhalt=p4n_sb_strreplace('<<mobil>>', $postfeld['mobilfon2'], $inhalt);
							}
							$inhalt=p4n_sb_strreplace('<<mobil2>>', $postfeld['mobilfon2'], $inhalt);
							if (!preg_match('/<<email2>>/', $inhalt) and $postfeld['email2']!='' and $postfeld['email']=='') {
								$inhalt=p4n_sb_strreplace('<<email>>', $postfeld['email2'], $inhalt);
							}
							$inhalt=p4n_sb_strreplace('<<email2>>', $postfeld['email2'], $inhalt);
							if (!preg_match('/<<fax2>>/', $inhalt) and $postfeld['fax2']!='' and $postfeld['fax']=='') {
								$inhalt=p4n_sb_strreplace('<<fax>>', $postfeld['fax2'], $inhalt);
							}
							$inhalt=p4n_sb_strreplace('<<fax2>>', $postfeld['fax2'], $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<telefon1>>', $postfeld['telefon'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<mob1>>', $postfeld['mobilfon'], $inhalt);
		if ($postfeld['mobilfon']==$std_tel) {
			$inhalt=p4n_sb_strreplace('<<mobil>>', '', $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<mobil>>', $postfeld['mobilfon'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<email>>', $postfeld['email'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<fax>>', $postfeld['fax'], $inhalt);

		$inhalt=p4n_sb_strreplace('<<aufmerksam>>', str_replace("\n", '\\par ', $postfeld['wodurch_aufmerksam']), $inhalt);
		
		if ($cfg_mandanten_bilder) {
			$id_mand=0;
			$kopffussproz=30;
			if (isset($cfg_kfzsuche_kopffuss_prozent)) {
				$kopffussproz=$cfg_kfzsuche_kopffuss_prozent;
			}
			$zielb='dokumente/mandant_images/'.$postfeld['vertrag_lagerort'].'_1.jpg';
			if (!is_file($zielb)) {
				$res4=$db->select(
					$sql_tab['mandant'],
					$sql_tabs['mandant']['parent_id'],
					$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($postfeld['vertrag_lagerort'])
				);
				if ($row4=$db->zeile($res4)) {
					$zielb='dokumente/mandant_images/'.$row4[0].'_1.jpg';
				}
			}
			if (is_file($zielb)) {
				$bildinh2=bin2hex(file_get_contents($zielb));
			//	$m_docx_bild2=file_get_contents('dokumente/marke_logo/'.$postfeld['kfz_markencode'].'_p4nscl.jpg');
				if ($ist_docx) {
			//		list($width_orig, $height_orig)=getimagesize('dokumente/marke_logo/'.$postfeld['kfz_markencode'].'_p4nscl.jpg');
			//		$inhalt=p4n_sb_strreplace('<<logo>>', '<w:pict><v:shape id="_x0000_i1026" style="width:'.(round($width_orig*$logoproz/100)).'pt;height:'.(round($height_orig*$logoproz/100)).'pt" type="#_x0000_t75"><v:imagedata o:title="" r:id="rId2p4n"/></v:shape></w:pict>', $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<kopfbild>>', '{\\pict \\picscalex'.$kopffussproz.'\\picscaley'.$kopffussproz.'\\jpegblip '.$bildinh2.' } ', $inhalt);
				}
			}
			$inhalt=p4n_sb_strreplace('<<kopfbild>>', '', $inhalt);
			
			$zielb='dokumente/mandant_images/'.$postfeld['vertrag_lagerort'].'_2.jpg';
			if (!is_file($zielb)) {
				$res4=$db->select(
					$sql_tab['mandant'],
					$sql_tabs['mandant']['parent_id'],
					$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($postfeld['vertrag_lagerort'])
				);
				if ($row4=$db->zeile($res4)) {
					$zielb='dokumente/mandant_images/'.$row4[0].'_2.jpg';
				}
			}
			if (is_file($zielb)) {
				$bildinh2=bin2hex(file_get_contents($zielb));
			//	$m_docx_bild2=file_get_contents('dokumente/marke_logo/'.$postfeld['kfz_markencode'].'_p4nscl.jpg');
				if ($ist_docx) {
			//		list($width_orig, $height_orig)=getimagesize('dokumente/marke_logo/'.$postfeld['kfz_markencode'].'_p4nscl.jpg');
			//		$inhalt=p4n_sb_strreplace('<<logo>>', '<w:pict><v:shape id="_x0000_i1026" style="width:'.(round($width_orig*$logoproz/100)).'pt;height:'.(round($height_orig*$logoproz/100)).'pt" type="#_x0000_t75"><v:imagedata o:title="" r:id="rId2p4n"/></v:shape></w:pict>', $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<fussbild>>', '{\\pict \\picscalex'.$kopffussproz.'\\picscaley'.$kopffussproz.'\\jpegblip '.$bildinh2.' } ', $inhalt);
				}
			}
			$inhalt=p4n_sb_strreplace('<<fussbild>>', '', $inhalt);
		}
		
		$doclink3='';
		$dok_f_pdf=false;
		if (isset($postfeld['pf_bedingungen'])) {
			$dok_f=false;
			if ($cfg_rtf2pdf and is_file('inc/'.$_SESSION['cfg_kunde'].'/pf_bedingungen.pdf')) {
				$dok_f=true;
				$doclink3='inc/'.$_SESSION['cfg_kunde'].'/pf_bedingungen.pdf';
				$dok_f_pdf=true;
			} elseif ($cfg_rtf2pdf and is_file('vorlagen/pf_bedingungen.pdf')) {
				$dok_f=true;
				$doclink3='vorlagen/pf_bedingungen.pdf';
				$dok_f_pdf=true;
			} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/pf_bedingungen.docx')) {
				$dok_f=true;
				$doclink3='inc/'.$_SESSION['cfg_kunde'].'/pf_bedingungen.docx';
			} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/pf_bedingungen.rtf')) {
				$dok_f=true;
				$doclink3='inc/'.$_SESSION['cfg_kunde'].'/pf_bedingungen.rtf';
			} elseif (is_file('vorlagen/pf_bedingungen.docx')) {
				$dok_f=true;
				$doclink3='vorlagen/pf_bedingungen.docx';
			} elseif (is_file('vorlagen/pf_bedingungen.rtf')) {
				$dok_f=true;
				$doclink3='vorlagen/pf_bedingungen.rtf';
			}
			if ($dok_f_pdf) {
				$alle_pdfs[20]=$doclink3;
			}
			if ($dok_f) {
				if ($cfg_kfzsuche_pdf_join and substr($doclink3, -4)=='.pdf') {
					
				} else {
					echo javas('window.open("'.$doclink3.'", "_blank");');
				}
			}
		}

		if ($vorschau) {
			$doclink=$bez_ang_kv2.'_'.$_SESSION['user_id'].'.rtf';
			$doclink2='temp/'.$doclink;
			if ($ist_docx) {
				$doclink=$bez_ang_kv2.'_'.$_SESSION['user_id'].'.docx';
				$doclink2='temp/'.$doclink;
				$inhalt=docx_schreiben($inhalt);
			}
			if ($fp=fopen($doclink2, 'w')) {
				fwrite($fp, $inhalt);
				fclose($fp);
				
				$doclink2pdf='';
				if ($cfg_rtf2pdf) {
					$doclink2pdf=check_rtf2pdf($doclink2, $cfg_rtf2pdf_sleep);
					if ($doclink2pdf==$doclink2) {
						$doclink2pdf='';
					}
				}
				if ($doclink2pdf!='') {
					if ($cfg_kfzsuche_pdf_join and substr($doclink2pdf, -4)=='.pdf') {
						
					} else {
						echo javas('window.open("'.$doclink2pdf.'", "_blank");');
					}
					$alle_pdfs[10]=$doclink2pdf;
				} else {
					echo javas('window.open("'.$doclink2.'", "_blank");');
				}
				link_dok_oeffnen($doclink2, $doclink2pdf, $doclink3, $doclink8, $doclink8pdf);
			}
			
			@reset($zusatzdateien1);
		while (!$leasingdruck and list($zdatein1, $inh_sv1)=@each($zusatzdateien1)) {
			if (is_file('dokumente/'.$zdatein1)) {
				$inft_zinh=file_get_contents('dokumente/'.$zdatein1);
				$inft_zinh2=ersetze_nwgwbed_felder($inft_zinh);
				$inft_zinh2=p4n_sb_strreplace('<<vereinbarung>>', $inh_sv1[1], $inft_zinh2);
				$zieldatei_it='dokumente/'.$zdatein1;
				
				$zdmit_pdf=false;
				if ($cfg_rtf2pdf and $inh_sv1[3]==true and (strtolower(p4n_mb_string('substr', $zieldatei_it, -4))=='.rtf' or strtolower(p4n_mb_string('substr', $zieldatei_it, -5))=='.docx')) {
					$zdmit_pdf=true;
				}
				
				$doclinksvpdf='';
				if ($zdmit_pdf or $inft_zinh!=$inft_zinh2) {
					if ($vorschau or $inh_sv1[2]==true) {
						$zieldatei_it='temp/pzusatzvereinbarung'.$inh_sv1[0].'_'.$_SESSION['user_id'].'.rtf';
						if ($fp=fopen($zieldatei_it, 'w')) {
							fwrite($fp, $inft_zinh2);
							fclose($fp);
						}
						if ($zdmit_pdf) {
							$doclinksvpdf=check_rtf2pdf($zieldatei_it, $cfg_rtf2pdf_sleep);
							if ($doclinksvpdf==$zieldatei_it) {
								$doclinksvpdf='';
							} else {
								$zieldatei_it=$doclinksvpdf;
//								$alle_pdfs[]=$doclinksvpdf;
							}
						}
					}
					if ($doclinksvpdf=='') {
						if ($fp=fopen($zieldatei_it, 'w')) {
							fwrite($fp, $inft_zinh2);
							fclose($fp);
						}
					}
				}
				if ($cfg_kfzsuche_pdf_join and substr($zieldatei_it, -4)=='.pdf') {
					if (!isset($zaepdf_sv)) {
						$zaepdf_sv=100;
					}
					$alle_pdfs[$zaepdf_sv]=$zieldatei_it;
					$zaepdf_sv++;
				} else {
					echo javas('window.open("'.$zieldatei_it.'", "_blank");');
				}
			}
		}
			
			if ($cfg_kfzsuche_pdf_join) {
				$lo='';
				@unlink('temp\\pf_alles_'.$_SESSION['user_id'].'.pdf');
				$lo2='gswin64c.exe -dNOPAUSE -sDEVICE=pdfwrite -sOUTPUTFILE=temp\\pf_alles_'.$_SESSION['user_id'].'.pdf -dBATCH ';
				@krsort($alle_pdfs);
				@reset($alle_pdfs);
				while (list($keyd, $vald)=@each($alle_pdfs)) {
					$lo='"'.str_replace('/', '\\', $vald).'" '.$lo;
				}
				exec($lo2.$lo, $cmdoutput);
				if (is_file('temp/pf_alles_'.$_SESSION['user_id'].'.pdf')) {
					echo javas('window.open("'.'temp/pf_alles_'.$_SESSION['user_id'].'.pdf'.'", "_blank");');
					link_dok_oeffnen('temp/pf_alles_'.$_SESSION['user_id'].'.pdf');
				}
				if ($fp=fopen('log_pdf.txt', 'w')) { fwrite($fp, $lo2.$lo."\r\n".javas('window.open("'.'temp/pf_alles_'.$_SESSION['user_id'].'.pdf'.'", "_blank");').print_r($alle_pdfs, true).print_r($cmdoutput, true).$lo); fclose($fp); }
			}
			
			die();
		} else {
			if ($cfg_greek or $ist_intpf) {
				$doclink='';
			} else {
			$doclink=$bez_ang_kv2.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'.rtf';
			if ($ist_docx) {
				$doclink=$bez_ang_kv2.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'.docx';
				$inhalt=docx_schreiben($inhalt);
			}
			$doclink=dok_korr_sp($doclink, $bez_ang_kv2);
			$doclink2='dokumente_korrespondenz/'.$doclink;
			if ($fp=fopen($doclink2, 'w')) {
				fwrite($fp, $inhalt);
				fclose($fp);
				$doclink2pdf='';
				if ($cfg_rtf2pdf) {
					$doclink2pdf=check_rtf2pdf($doclink2, $cfg_rtf2pdf_sleep);
					if ($doclink2pdf==$doclink2) {
						$doclink2pdf='';
					}
					$doclink2pdf=str_replace('dokumente_korrespondenz/dokumente_korrespondenz/', 'dokumente_korrespondenz/', $doclink2pdf);
				}
				if ($doclink2pdf!='') {
					$doclink=str_replace('.rtf', '.pdf', $doclink);
					if ($cfg_kfzsuche_pdf_join and substr($doclink2pdf, -4)=='.pdf') {
						
					} else {
						if (!$cfg_synop_pf) {
							echo javas('window.open("'.$doclink2pdf.'", "_blank");');
						}
					}
					$alle_pdfs[10]=$doclink2pdf;
				} else {
					if (!$cfg_synop_pf) {
						echo javas('window.open("'.$doclink2.'", "_blank");');
					}
				}
				link_dok_oeffnen($doclink2, $doclink2pdf, $doclink3, $doclink8, $doclink8pdf);
			}
			}	// ende cfg_greek
			
			$par_id=0;
			$kamp_id=0;
			$lead_id=0;
			$lead_quelle='';
			$ltext=($zusbetreff1=='Kundenersatzfahrzeug'?$zusbetreff1:_PROBEFAHRT_).' - '.$pid_bez2;
			if ($ist_intpf) {
				$ltext=($zusbetreff1=='Kundenersatzfahrzeug'?$zusbetreff1:_INTERNEFAHRT_).' - '.$pid_bez2;
			}
			
			$lead_nicht_schliessen=false;
			
			if (intval($postfeld['kbezug'])>0) {
				$par_id=$postfeld['kbezug'];
				$par_kat='';
				$res3=$db->select(
					$sql_tab['korrespondenz'],
					array(
						$sql_tabs['korrespondenz']['kampagne_id'],
						$sql_tabs['korrespondenz']['lead_id'],
						$sql_tabs['korrespondenz']['betreff'],
						$sql_tabs['korrespondenz']['beschreibung'],
						$sql_tabs['korrespondenz']['kategorie'],
						$sql_tabs['korrespondenz']['quelle']
					),
					$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($postfeld['kbezug'])
				);
				if ($row3=$db->zeile($res3)) {
					$kamp_id=$row3[0];
					$lead_id=$row3[1];
					if ($cfg_avagneuanpassung2018 and $hat_eigkamp) {
						if ($kamp_id!=$kampa_id and intval($lead_id)>0) {
							$lead_nicht_schliessen=true;
						}
						$kamp_id=$kampa_id;
					}
					$lead_quelle=trim($row3[5]);
                    if ($lead_id && $_SESSION['crm_version_float'] >= 61004) {
                        $lead = new Lead_Data($lead_id);
                        if ($lead->load(array('lead_origin'))) {
                            if ($lead['lead_origin'] != '') {
                                $lead_quelle = $lead['lead_origin'];
                            }
                        }
                    }

					$par_kat=$row3[4];

					if (!p4n_mb_string('strpos',$row3[3], $ltext)) {
						$ltext=$ltext.'<br><br>'.$row3[3];
					}
				}
				if ($cfg_kaufvertrag_aendern and $par_kat==_KAUFVERTRAG_) {
					$postfeld['kbezug']=0;
				}
				$par_id=$postfeld['kbezug'];
			}
			
			$lds_dont_close=false;
			if ($ist_intpf) {
				// bei interner Fahrt nichts machen
			} elseif ($lead_id>0 and $lead_quelle=='OFDB') {
				include_once('inc/ofdb.php');
				$carl1=$postfeld['ofdb_carline'];
				if ($carl1=='-1') {
					$carl1='';
				}
				schreibe_ofdb_erg($lead_id, 'testdrive_scheduled', $postfeld['kbezug'], $carl1);
				if (!$lead_nicht_schliessen) {
					parent_k_schliessen($par_id, true);
				}
			} elseif ($lead_id>0 and $lead_quelle=='Ford LDS') {
				require_once 'inc/lds.inc.php';
				$lds_erg=updateLeadSpecific($lead_id, _TEST_DRIVE_BOOKED_);
				if (is_array($lds_erg) && $lds_erg['error']===true) {
					echo javas('alert("'._FEHLER_.' LDS! \n'.$lds_erg['info'].'");');
					$lds_dont_close=true;
				} else {
                    $lds_erg[$lead_id] = $lead_id;
					lds_korrupdate($lds_erg, _PROBEFAHRT_, _PROBEFAHRT_, 0);
				}
			} elseif ($lead_id>0 and $lead_quelle=='Web Jassy') { // griga 31.03.2015 -->
				/*require_once 'inc/jassy.inc.php';
				$feld=$postfeld;
				$jassyTime = $feld['pfdatum'].' '.$feld['pfzeit'].':'.$feld['pfzeit2'].' - '.$feld['pfdatumb'].' '.$feld['pfzeitb'].':'.$feld['pfzeitb2'];
				$jassy_erg = updateLeadSpecific($lead_id, _PROBEFAHRT_, _TEST_DRIVE_BOOKED_.' '.$pid_bez2, $jassyTime);
				if (is_array($jassy_erg) && $jassy_erg['error']===true) {
					echo javas('alert("'._FEHLER_.' Web Jassy! \n'.$jassy_erg['info'].'");');
				} else {
					
				}*/ // --> griga 31.03.2015
			} elseif ($lead_id > 0 && $lead_quelle === 'Toyota') {
                try {
					ToyotaLeads::instance()->updateLead($lead_id, 'TestdrivePlanned', $postfeld);
                    /*$getf = array(
                        'action'   => 'Send milestone',
                        'lead_id'  => $lead_id,
                        'activity' => _VK_LEAD_TESTDRIVE_PLANNING_
                    );
                    require 'toyota_leads.php';*/
					if (!$lead_nicht_schliessen) {
	                    parent_k_schliessen($par_id, true);
					}
                } catch (Exception $e) {
                    echo javas('alert("'.p4n_mb_string('htmlspecialchars', $e->getMessage()).'");');
                }
            } elseif ($lead_id > 0 && $lead_quelle === 'Toyota AT') {
                try {
					ToyotaLeadsAT::instance()->updateLead($lead_id, 'TESTDRIVE_BOOKED');
					if (!$lead_nicht_schliessen) {
	                    parent_k_schliessen($par_id, true);
					}
                } catch (Exception $e) {
                    echo javas('alert("'.p4n_mb_string('htmlspecialchars', $e->getMessage()).'");');
                }
            } elseif ($lead_id > 0 && $lead_quelle === 'Ferrari') {
                try {
                    $getf = array(
                        'action'     => 'Send event',
                        'lead_id'    => $lead_id,
                        'event'      => _SALES_.'___S05|Test Drive',
                        'closed'     => false
                    );
                    require 'ferrari_leads.php';
					if (!$lead_nicht_schliessen) {
	                    parent_k_schliessen($par_id, true);
					}
                } catch (Exception $e) {
                    $error = $e->getMessage();
                    echo javas('alert("'.p4n_mb_string('htmlspecialchars', $error).'");');
                }
            } elseif ($lead_id > 0 && $lead_quelle === 'KIA' && !empty($cfg_kia_leads)) {
                try {
                    $kiaResult = KiaLeads::instance()->updateLead($lead_id, 4);
                } catch (Exception $e) {
                    $error = $e->getMessage();
                    echo javas('alert("'.p4n_mb_string('htmlspecialchars', $error).'");');
                }
            } elseif ($lead_id>0) {
					$feld=$postfeld;
					$feld['kerg_neu']=_KONTAKTIERT_;	// Probefahrt gebucht
					
					$cce=0;
					if ($cfg_leadengine_version_slmi5) {
						$cce=lead_checkcc($lead_id);
						if ($cce>=2) {
							if ($cce==2) {
								echo javas('alert("'._LEAD_.': '._LEADIT_CCLEAD_.' '._LEADIT_OFFEN_.'");');
							}
							if ($cce==3) {
								echo javas('alert("'._LEAD_.': '._LEADIT_CCLEAD3_.'");');
							}
						}
					}
					if ($cce<=1) {
						include_once('inc/gmlead.php');
						$korrespondenz_art = array('contacted' => true);
						le_updatelead($lead_id, $korrespondenz_art);
						if ($cce!=2 and !$lead_nicht_schliessen) {
							parent_k_schliessen($par_id, true);
						}
					}
                    if (!empty($cfg_toyota_toca) && !empty($cfg_toyota_leads) && $lead_quelle !== 'Makros') {
                        try {
                            ToyotaLeads::instance()->updateNotToyotaLead($lead_id, 'TestdrivePlanned', $postfeld);
                        } catch (Exception $e) {
                            //$fehler_nicht_schliessen = true;
                            $error = $e->getMessage();
                            $zus_erg_text2 = $error;
                            echo javas('alert("'.p4n_mb_string('htmlspecialchars', $error).'");');
                        }
                    }
			} else {
				// kein Lead
				if ($par_kat!=_KAUFVERTRAG_ and $par_kat!=_ANGEBOT_) {
					parent_k_schliessen($par_id);
				}
			}
			
			if (intval($postfeld['kbezug'])>0 and $par_kat==_PROBEFAHRT_ and $bez_ang_kv==_PROBEFAHRT_ and isset($postfeld['pfkalid']) and intval($postfeld['pfkalid'])>0) {
				$db->update(
					$sql_tab['korrespondenz'],
					array(
						$sql_tabs['korrespondenz']['kategorie'] => $db->str(_PROBEFAHRT_.' - '._AENDERUNG_)
					),
					$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($postfeld['kbezug'])
				);
			}
			
            if ($lead_id > 0 && in_array($lead_quelle, array('Ford LDS', 'Toyota', 'Ferrari'))) {
                if (class_exists('Interface_Main')) {
                    Interface_Main::addLeadLog($lead_quelle, array('customers' => array($_SESSION['stammdaten_id'])));
                }
            }
			
			if ($cfg_kfzsuche_avag_austria) {
				$ltext=$kennzeichen;
			}
			
			if (isset($postfeld['pf_bemerkung'])) {
				if ($postfeld['pf_bemerkung']!='') {
					$ltext.="\n\n"._BEMERKUNG_.': '.$postfeld['pf_bemerkung'];
				}
			}
			
			if ($sonstiges2!='') {
				$ltext.="\n\n"._SONST_VEREINBARUNGEN_.': '.$sonstiges2;
			}
			if ($kennz_text!='') {
				$ltext.="\n\n"._KENNZEICHEN_.': '.$kennz_text;
			}
			
			if (!$ist_intpf and $cfg_carlo_appserver_activity) {
				$res6=$db->select(
					$sql_tab['stammdaten_zusatz'],
					$sql_tabs['stammdaten_zusatz']['zusatz_id'],
					$sql_tabs['stammdaten_zusatz']['bezeichnung'].'='.$db->str('F�hrerschein Nummer')
				);
				if ($row6=$db->zeile($res6)) {
					$res5=$db->select(
						$sql_tab['zusatzfelder'],
						$sql_tab['zusatzfelder'].'.zf_'.$row6[0],
						$sql_tabs['zusatzfelder']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
					);
					if ($row5=$db->zeile($res5)) {
						$db->update(
							$sql_tab['zusatzfelder'],
							array(
								$sql_tab['zusatzfelder'].'.zf_'.$row6[0] => $db->str($postfeld['fs_nummer'])
							),
							$sql_tabs['zusatzfelder']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
						);
					} else {
						$db->insert(
							$sql_tab['zusatzfelder'],
							array(
								$sql_tab['zusatzfelder'].'.zf_'.$row6[0] => $db->str($postfeld['fs_nummer']),
								$sql_tabs['zusatzfelder']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id'])
							)
						);
					}
				}
				
				$res6=$db->select(
					$sql_tab['stammdaten_zusatz'],
					$sql_tabs['stammdaten_zusatz']['zusatz_id'],
					$sql_tabs['stammdaten_zusatz']['bezeichnung'].'='.$db->str('F�hrerschein Ort')
				);
				if ($row6=$db->zeile($res6)) {
					$res5=$db->select(
						$sql_tab['zusatzfelder'],
						$sql_tab['zusatzfelder'].'.zf_'.$row6[0],
						$sql_tabs['zusatzfelder']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
					);
					if ($row5=$db->zeile($res5)) {
						$db->update(
							$sql_tab['zusatzfelder'],
							array(
								$sql_tab['zusatzfelder'].'.zf_'.$row6[0] => $db->str($postfeld['fs_ort'])
							),
							$sql_tabs['zusatzfelder']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
						);
					} else {
						$db->insert(
							$sql_tab['zusatzfelder'],
							array(
								$sql_tab['zusatzfelder'].'.zf_'.$row6[0] => $db->str($postfeld['fs_ort']),
								$sql_tabs['zusatzfelder']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id'])
							)
						);
					}
				}
			}
			$ltext2='';
			@reset($mpostfeld);
			while (list($pkey, $pval)=@each($mpostfeld)) {
				if ($pkey!='' and $pkey!='von_korr' and $pkey!='von_lead' and $pkey!='neukunde' and $pkey!='infotextz2' and $pkey!='pf_kfznotiz' and $pkey!='p4ntoken' and $pkey!='nfok' and substr($pkey, 0, 5)!='pf_nf' and substr($pkey, 0, 9)!='pf_nf_alt' and substr($pkey, 0, 9)!='t_aendern') {
					if (is_array($pval)) {
						while (list($pkey2, $pval2)=@each($pval)) {
							$ltext2.=$pkey.'['.$pkey2.']==='.$pval2."#####";
						}
					} else {
                        if ($pkey === 'tech_data') {
                            $pval = base64_decode($pval);
                        }
						$ltext2.=$pkey.'==='.$pval."#####";
					}
				}
			}
			
			$korr_pid=$postfeld['pid'];
			// rausgenommen am 19.06.2023, Fahrzeug soll das gew�hlte sein
			if (1==2 and ($cfg_leadmanagement_2020 or $cfg_le_qualifizieren) and intval($lead_id)>0) {
				$res3=$db->select(
        			$sql_tab['kampagne_lead'],
					$sql_tabs['kampagne_lead']['produktzuordnung_id'],
					$sql_tabs['kampagne_lead']['kampagne_lead_id'].'='.$db->dbzahl($lead_id)
		    	);
			    if ($row3=$db->zeile($res3)) {
					if (intval($row3[0])>0) {
				        $korr_pid=intval($row3[0]);
					}
				}
			}
			
			$kfeld=array(
					$sql_tabs['korrespondenz']['datum'] => $db->dbzeitdatum($postfeld['pfdatum'], $postfeld['pfzeit'].':'.$postfeld['pfzeit2']),
					$sql_tabs['korrespondenz']['datum2'] => $db->dbzeitdatum($postfeld['pfdatumb'], $postfeld['pfzeitb'].':'.$postfeld['pfzeitb2']),
					$sql_tabs['korrespondenz']['wvl_datum1'] => $db->dbzeitdatum($feld['kwvl1'], $feld['kwvl1_z'].':'.$feld['kwvl1_z2']),
					$sql_tabs['korrespondenz']['wvl_datum2'] => $db->dbzeitdatum($feld['kwvl2'], $feld['kwvl2_z'].':'.$feld['kwvl2_z2']),
								$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
								$sql_tabs['korrespondenz']['ansprechpartner_id'] => $db->dbzahl($apid),
								$sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
								$sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['eingang'] => 0,
								$sql_tabs['korrespondenz']['art'] => $db->dbzahl(9),
								$sql_tabs['korrespondenz']['kategorie'] => $db->str($korrkatpf),
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(false),
								$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($par_id),
								$sql_tabs['korrespondenz']['doclink'] => $db->str($doclink),
								$sql_tabs['korrespondenz']['betreff'] => $db->str($zusbetreff1.($zusbetreff1=='Kundenersatzfahrzeug'?'':$korrkatpf).' - '.$zus_pfbetreff.$pid_bez3),
								$sql_tabs['korrespondenz']['beschreibung'] => $db->str($ltext),
								$sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl($korr_pid),
								$sql_tabs['korrespondenz']['papierkorb'] => 0,
								$sql_tabs['korrespondenz']['kalender_id'] => $db->dbzahl($kal_id),
								$sql_tabs['korrespondenz']['kalender_zusatz_id']	=> $db->dbzahl($postfeld['zusatzk']),
								$sql_tabs['korrespondenz']['prioritaet'] => 0,
								$sql_tabs['korrespondenz']['negativ'] => 0,
								$sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_nr'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(($kamp_id>0?$kamp_id:$kampa_id)),
								$sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl($lead_id),
								$sql_tabs['korrespondenz']['quelle'] => $db->str($lead_quelle),
								$sql_tabs['korrespondenz']['zusatz1'] => $db->str($ltext2)
			);
			if ($anr>0) {
				$kfeld[$sql_tabs['korrespondenz']['opportunity_id']]=$db->dbzahl($anr);
			}
			if (isset($postfeld['kia_typ'])) {
				$kfeld[$sql_tabs['korrespondenz']['kanal']]=$db->str($postfeld['kia_typ'].';'.$postfeld['kia_motor'].';'.$postfeld['kia_bauart']);
			}
			if ($cfg_kfzsuche_pferledigt or $ist_intpf) {
				$kfeld[$sql_tabs['korrespondenz']['erledigt']]=$db->dblogic(true);
				$kfeld[$sql_tabs['korrespondenz']['ergebnis_kategorie']]=$db->str($korrkatpf);
				$kfeld[$sql_tabs['korrespondenz']['ergebnis_benutzer_id']]=$db->dbzahl($ang_kv_user);
				if ($cfg_kfzsuche_pf_bemerkung) {
					$kfeld[$sql_tabs['korrespondenz']['ergebnis_text']]=$db->str($postfeld['pf_bemerkung']);
				}
			}
			if ($cfg_kfzsuche_pf_kmstand) {
				$kfeld[$sql_tabs['korrespondenz']['zusatzzahl_1']]=$db->dbzahl($postfeld['pf_kmstand']);
			}
			if (isset($postfeld['pf_werkstattersatz'])) {
				$kfeld[$sql_tabs['korrespondenz']['erledigt']]=$db->dblogic(true);
				$kfeld[$sql_tabs['korrespondenz']['wvl_datum1']]=0;
				$kfeld[$sql_tabs['korrespondenz']['wvl_datum2']]=0;
				$kfeld[$sql_tabs['korrespondenz']['kategorie']]=$db->str(_PROBEFAHRT_.' - WE');
			}
			
			$capps_keinek=true;
			$allesok=$db->insert(
				$sql_tab['korrespondenz'],
				$kfeld
			);
			$ins_k_id=$db->insertid();
			if (intval($_POST['alte_korr_id'])>0) {
				$db->update(
					$sql_tab['korrespondenz'],
					array(
						$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($ins_k_id)
					),
					$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($_POST['alte_korr_id'])
				);
			}
            
			$hat_eigkamp=false;
			if (!$ist_intpf and $cfg_avagneuanpassung2018) {
				$kampa_id2=0;
				if (isset($postfeld['vertrags_marketingkampagne'])) {
					if (intval($postfeld['vertrags_marketingkampagne'])>0) {
						$kampa_id2=intval($postfeld['vertrags_marketingkampagne']);
					//	$hat_eigkamp=true;
					}
					if ($postfeld['vertrags_marketingkampagne']=='-1000') {
						if (isset($postfeld['akv_zuskamp']) and intval($postfeld['akv_zuskamp'])>0) {
							$kampa_id2=intval($postfeld['akv_zuskamp']);
						//	$hat_eigkamp=true;
						}
					}
				}
				if (intval($_SESSION['stammdaten_id'])>0 and $kampa_id2>0) {
					$res99=$db->select(
								$sql_tab['korrespondenz'],
								array(
									$sql_tabs['korrespondenz']['korrespondenz_id']
								),
								$sql_tabs['korrespondenz']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
									$sql_tabs['korrespondenz']['datum'].' between '.$db->dbtimestamp(time()-180*24*60*60).' and '.$db->dbtimestamp(time()+31*24*60*60).' and '.
									$sql_tabs['korrespondenz']['kampagne_id'].'='.$db->dbzahl($kampa_id2),
								$sql_tabs['korrespondenz']['datum'].' desc'
					);
					if ($row99=$db->zeile($res99)) {
						/*
						$db->update(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($row99[0])
							),
							$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($ins_k_id)
						);
						*/
					} else {
						$db->insert(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($postfeld['stid']),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl($kampa_id2),
								$sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
                                $sql_tabs['korrespondenz']['wvl_datum1'] => 0,
                                $sql_tabs['korrespondenz']['wvl_datum2'] => 0,
                                $sql_tabs['korrespondenz']['ansprechpartner_id'] => $db->dbzahl(0),
                                $sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
                                $sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($ang_kv_user),
                                $sql_tabs['korrespondenz']['eingang'] => 0,
                                $sql_tabs['korrespondenz']['art'] => $db->dbzahl(14),
                                $sql_tabs['korrespondenz']['kategorie'] => $db->str(_KORRESPONDENZ_),
                                $sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
                                $sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($par_id),	// anstatt 0 hier Parentid
                                $sql_tabs['korrespondenz']['doclink'] => $db->str(''),
                                $sql_tabs['korrespondenz']['betreff'] => $db->str(_KORRESPONDENZ_),
                                $sql_tabs['korrespondenz']['beschreibung'] => $db->str(_KORRESPONDENZ_),
                                $sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl(0),
                                $sql_tabs['korrespondenz']['papierkorb'] => 0,
                                $sql_tabs['korrespondenz']['kalender_id'] => 0,
                                $sql_tabs['korrespondenz']['prioritaet'] => 0,
                                $sql_tabs['korrespondenz']['negativ'] => 0,
                                $sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
                                $sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
                                $sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_KORRESPONDENZ_),
                                $sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str(_KORRESPONDENZ_),
	                            $sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['quelle'] => $db->str(''),
								$sql_tabs['korrespondenz']['kategorie2'] => $db->str('')
							)
						);
						$par_k_id=$db->insertid();
						$db->update(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($par_k_id)
							),
							$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($ins_k_id)
						);
					}
				}
			}
			
			//BENZ
			if (class_exists('PearAutoloader')) {
                $td = new Event_Type_Com_TestdriveRequested($_SESSION['user_id'], $_SESSION['stammdaten_id'], $ins_k_id);
                $td->addContextArray($postfeld);
                $td->call();
            }
			
			if (!$cfg_carlo_appserver_activity_keinekorr and $cfg_carlo_appserver_activity) {
				if ($postfeld['k_activity']!='-1') {
					if ($postfeld['k_activityerg']=='-1') {
						$postfeld['k_activityerg']='';
					}
					edsxml_write_activity($ins_k_id, $postfeld['k_activity'], $postfeld['k_activityerg']);
				}
			}
			
			if ($kal_id>0) {
				$db->update(
					$sql_tab['kalender'],
					array(
						$sql_tabs['kalender']['beschreibung'] => $db->str($ltext),
						$sql_tabs['kalender']['kampagne_id'] => $db->dbzahl(($kamp_id>0?$kamp_id:$kampa_id))
					),
					$sql_tabs['kalender']['kalender_id'].'='.$db->dbzahl($kal_id)
				);
				if ($cfg_carlo_appserver_activity) {
					if (isset($postfeld['export_vcal'])) {
						echo javas('window.open("'.'vcal_export.php?tid='.$kal_id.'", "status");');
					}
					if (isset($postfeld['export_ical'])) {
						echo javas('window.open("'.'ical_export.php?tid='.$kal_id.'", "status");');
					}
				}
			}
			
			if ($cfg_synop_pf) {
				include_once('inc/lib_synop.php');
				$synop_auchdse=false;
/*				if ($postfeld['dse_druck']) {
					$synop_auchdse=true;
				}
*/				synop_create_pf($ins_k_id, '', false, $synop_auchdse);
			}
			
			@reset($zusatzdateien1);
		while (!$ist_intpf and !$leasingdruck and list($zdatein1, $inh_sv1)=@each($zusatzdateien1)) {
			if (is_file('dokumente/'.$zdatein1)) {
				$inft_zinh=file_get_contents('dokumente/'.$zdatein1);
				$inft_zinh2=ersetze_nwgwbed_felder($inft_zinh);
				$inft_zinh2=p4n_sb_strreplace('<<vereinbarung>>', $inh_sv1[1], $inft_zinh2);
				$zieldatei_it='dokumente/'.$zdatein1;
				
				$zdmit_pdf=false;
				if ($cfg_rtf2pdf and $inh_sv1[3]==true and (strtolower(p4n_mb_string('substr', $zieldatei_it, -4))=='.rtf' or strtolower(p4n_mb_string('substr', $zieldatei_it, -5))=='.docx')) {
					$zdmit_pdf=true;
				}
				
				$doclinksvpdf='';
				if ($zdmit_pdf or $inft_zinh!=$inft_zinh2) {
					if ($vorschau or $inh_sv1[2]==true) {
						$zieldatei_it='temp/pzusatzvereinbarung'.$inh_sv1[0].'_'.$_SESSION['user_id'].'.rtf';
						if ($fp=fopen($zieldatei_it, 'w')) {
							fwrite($fp, $inft_zinh2);
							fclose($fp);
						}
						if ($zdmit_pdf) {
							$doclinksvpdf=check_rtf2pdf($zieldatei_it, $cfg_rtf2pdf_sleep);
							if ($doclinksvpdf==$zieldatei_it) {
								$doclinksvpdf='';
							} else {
								$zieldatei_it=$doclinksvpdf;
//								$alle_pdfs[]=$doclinksvpdf;
							}
						}
					} else {
						$zieldatei_it='dokumente_korrespondenz/pf_zusatzvereinbarung'.$inh_sv1[0].'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'.rtf';
						$zieldatei_it='dokumente_korrespondenz/'.dok_korr_sp(str_replace('dokumente_korrespondenz/', '', $zieldatei_it), 'pf_zusatzvereinbarung');
						if ($zdmit_pdf) {
							if ($fp=fopen($zieldatei_it, 'w')) {
								fwrite($fp, $inft_zinh2);
								fclose($fp);
							}
							$doclinksvpdf=check_rtf2pdf($zieldatei_it, $cfg_rtf2pdf_sleep);
							if ($doclinksvpdf==$zieldatei_it) {
								$doclinksvpdf='';
							} else {
								$zieldatei_it=$doclinksvpdf;
//								$alle_pdfs[]=$doclinksvpdf;
							}
						}
						$kfeld=array(
								$sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['wvl_datum1'] => 0,
								$sql_tabs['korrespondenz']['wvl_datum2'] => 0,
								$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
								$sql_tabs['korrespondenz']['ansprechpartner_id'] => $db->dbzahl($apid),
								$sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
								$sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['eingang'] => 0,
								$sql_tabs['korrespondenz']['art'] => $db->dbzahl(11),
								$sql_tabs['korrespondenz']['kategorie'] => $db->str(_ZUSATZVEREINBARUNG_.' '._PROBEFAHRT_),
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
								$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['doclink'] => $db->str(str_replace('dokumente_korrespondenz/', '', $zieldatei_it)),
								$sql_tabs['korrespondenz']['betreff'] => $db->str(_ZUSATZVEREINBARUNG_.' '.$inh_sv1[0]),
								$sql_tabs['korrespondenz']['beschreibung'] => $db->str($inh_sv1[1]),
								$sql_tabs['korrespondenz']['zusatz1'] => $db->str(''),
								$sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['papierkorb'] => 0,
								$sql_tabs['korrespondenz']['kalender_id'] => 0,
								$sql_tabs['korrespondenz']['prioritaet'] => 0,
								$sql_tabs['korrespondenz']['negativ'] => 0,
								$sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_nr'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_ZUSATZVEREINBARUNG_.' '._PROBEFAHRT_),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str(''),
								$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($ang_kv_user)
						);
						tempdateien($zieldatei_it, $zdatein1, _ZUSATZVEREINBARUNG_.' '.kundenbezeichnung($_SESSION['stammdaten_id']));
						$m_capps_keinek=$capps_keinek;
						$capps_keinek=true;
						$allesok=$db->insert(
							$sql_tab['korrespondenz'],
							$kfeld
						);
						$capps_keinek=$m_capps_keinek;
					}
					if ($doclinksvpdf=='') {
						if ($fp=fopen($zieldatei_it, 'w')) {
							fwrite($fp, $inft_zinh2);
							fclose($fp);
						}
					}
				}
				if ($cfg_kfzsuche_pdf_join and substr($zieldatei_it, -4)=='.pdf') {
					if (!isset($zaepdfa_sv)) {
						$zaepdfa_sv=100;
					}
					$alle_pdfs[$zaepdfa_sv]=$zieldatei_it;
					$zaepdfa_sv++;
				} else {
					echo javas('window.open("'.$zieldatei_it.'", "_blank");');
				}
			}
		}
		
			
			unset($capps_keinek);
			if (!$ist_intpf and $cfg_kfzsuche_pdf_join) {
				$lo='';
				@unlink('temp\\pf_alles_'.$_SESSION['user_id'].'.pdf');
				$lo2='gswin64c.exe -dNOPAUSE -sDEVICE=pdfwrite -sOUTPUTFILE=temp\\pf_alles_'.$_SESSION['user_id'].'.pdf -dBATCH ';
				@krsort($alle_pdfs);
				@reset($alle_pdfs);
				while (list($keyd, $vald)=@each($alle_pdfs)) {
					$lo='"'.str_replace('/', '\\', $vald).'" '.$lo;
				}
				exec($lo2.$lo, $cmdoutput);
				if (is_file('temp/pf_alles_'.$_SESSION['user_id'].'.pdf')) {
					echo javas('window.open("'.'temp/pf_alles_'.$_SESSION['user_id'].'.pdf'.'", "_blank");');
					link_dok_oeffnen('temp/pf_alles_'.$_SESSION['user_id'].'.pdf');
				}
				if ($fp=fopen('log_pdf.txt', 'w')) { fwrite($fp, $lo2.$lo."\r\n".javas('window.open("'.'temp/akv_alles_'.$_SESSION['user_id'].'.pdf'.'", "_blank");').print_r($alle_pdfs, true).print_r($cmdoutput, true).$lo); fclose($fp); }
			}
			
            if ($ziel_t2 != '') { 
                $ziel1 = $ziel_t2;
            } else {
				if (!$synop_auchdse and isset($postfeld['dse_druck'])) {
                    if (isset($_SESSION['design_70'])) {
                        // Redirects the user to the customer DSE (Tab Uebersicht - Modal).
                        $ziel1 = 'stammdaten_main.php?nav=Uebersicht&id='.$_SESSION['stammdaten_id'].'&exclude_stammdaten_tabs=1&dse1=1#dse';
                    } else {
                        $ziel1='stammdaten_main.php?id='.$_SESSION['stammdaten_id'].'&nav=Stammdaten&dse1=1#dse';
                    }
				} else {
                    if (isset($_SESSION['design_70'])) {
                        // Redirects the user to the customer overview. (Tab Uebersicht)
                        $ziel1 = 'stammdaten_main.php?nav=Uebersicht&id='.$_SESSION['stammdaten_id'].'&exclude_stammdaten_tabs=1';
                    } else {
                        $ziel1='stammdaten_main.php?id='.$_SESSION['stammdaten_id'].'&nav=Uebersicht';
                    }
				}
			}
			
			if (
                !$ist_intpf &&
                isset($sql_tabs['formular']['nach_angebot']) &&
                (
                    $ziel1 === 'stammdaten_main.php?id='.$_SESSION['stammdaten_id'].'&nav=Uebersicht' ||
                    $ziel1 === 'stammdaten_main.php?nav=Uebersicht&id='.$_SESSION['stammdaten_id'].'&exclude_stammdaten_tabs=1'
                )
            ) {
                $fo_aufr=0;
                $res2=$db->select(
                    $sql_tab['formular'],
                    array(
                        $sql_tabs['formular']['formular_id'],
                        $sql_tabs['formular']['nach_angebot'],
                        $sql_tabs['formular']['nach_kaufvertrag'],
                        $sql_tabs['formular']['nach_probefahrt'],
                    )
                );
                while ($row2=$db->zeile($res2)) {
                    if (intval($row2[3])>0) {
                        $fo_aufr=$row2[0];
                    }
                }
                if (intval($fo_aufr)>0) {
                    unset($_SESSION['crm_kv_letzte_pid']);
                    if (intval($postfeld['pid'])>0) {
                        $_SESSION['crm_kv_letzte_pid']=$postfeld['pid'];
                    }
                    if ($_SESSION['design_70'] && !$cfg_design70_hybrid) {
                    echo javas('wechsel_a("main","stammdaten_main.php?zid='.$_SESSION['stammdaten_id'].'&nav=Uebersicht&fo_aufruf='.$fo_aufr.'");');
                    } else
                    echo javas('location.href="stammdaten_main.php?frameset_start=1&id='.$_SESSION['stammdaten_id'].'&nav=Uebersicht&fo_aufruf='.$fo_aufr.'";');
                    fuss();
                    die();
                }
			}
			
			if (!$ist_intpf and isset($_POST['von_korr'])) {
				$ziel1='stammdaten_main.php';
                $ziel1.=(!preg_match('/\?/Uis',$ziel1)?'?frameset_start=1':'&frameset_start=1');
				echo javas('window.open("'.$ziel1.'", "main");');
				fuss();
				die();
			}
			if (!$ist_intpf and isset($_POST['von_lead'])) {
				$ziel1='stammdaten_main.php?nav=lead';
				echo javas('window.open("'.$ziel1.'", "main");');
				fuss();
				die();
			}
			if ($ist_intpf or $cfg_kfzsuche_pf_bleiben) {
				$ziel1='kfzsuche.php';
			}
            if (isset($_POST['von_pf_uebersicht']) && $_POST['von_pf_uebersicht']==1) {
            	$ziel1='probefahrt_uebersicht.php';
			}
            $ziel1.=(!preg_match('/\?/Uis',$ziel1)?'?frameset_start=1':'&frameset_start=1');
            
            if (isset($_SESSION['design_70'])) {
                echo javas('wechsel_a("main", "'.$ziel1.'");');
            } else {
                echo javas('window.open("'.$ziel1.'", "main");');
            }
			fuss();
			die();
			
			}// Ende Vorschau
		}
		
		// Dello Kunden anlegen f�r �bermittlung
		if ($_SESSION['cfg_kunde']=='carlo_opel_dello') {
			$res=$db->select(
				$sql_tab['log_aenderung'],
				$sql_tabs['log_aenderung']['log_aenderung_id'],
				$sql_tabs['log_aenderung']['zusatz1'].'='.$db->str($_SESSION['stammdaten_id']).' and '.
					$sql_tabs['log_aenderung']['tabelle'].'='.$db->str('Neueintrag Stammdaten temp')
			);
			if ($row=$db->zeile($res)) {
				$db->update(
					$sql_tab['log_aenderung'],
					array(
						$sql_tabs['log_aenderung']['datum'] => $db->dbtimestamp(time()),
						$sql_tabs['log_aenderung']['benutzer_id'] => $db->dbzahl($_SESSION['user_id']),
						$sql_tabs['log_aenderung']['tabelle'] => $db->str('Neueintrag Stammdaten'),
						$sql_tabs['log_aenderung']['feldinhalt_alt'] => $db->str('KV')
					),
					$sql_tabs['log_aenderung']['log_aenderung_id'].'='.$db->dbzahl($row[0])
				);
			}
			$res=$db->select(
				$sql_tab['log_aenderung'],
				$sql_tabs['log_aenderung']['log_aenderung_id'],
				$sql_tabs['log_aenderung']['zusatz1'].'='.$db->str($_SESSION['stammdaten_id']).' and '.
					$sql_tabs['log_aenderung']['tabelle'].'='.$db->str('Neueintrag AP temp')
			);
			while ($row=$db->zeile($res)) {
				$db->update(
					$sql_tab['log_aenderung'],
					array(
						$sql_tabs['log_aenderung']['datum'] => $db->dbtimestamp(time()),
						$sql_tabs['log_aenderung']['benutzer_id'] => $db->dbzahl($_SESSION['user_id']),
						$sql_tabs['log_aenderung']['tabelle'] => $db->str('Neueintrag AP'),
						$sql_tabs['log_aenderung']['feldinhalt_alt'] => $db->str('KV')
					),
					$sql_tabs['log_aenderung']['log_aenderung_id'].'='.$db->dbzahl($row[0])
				);
			}
		}
		
		
		// Kauf an Kroa-WS �bermitteln
		if (!$vorschau and $bez_ang_kv==_KAUFVERTRAG_ and $cfg_ws_avag_kroatien and intval($postfeld['pid'])>0) {
			$liefert=time();
				if (isset($postfeld['vertrag_liefertermin']) and $postfeld['vertrag_liefertermin']!='') {
					$datum_lt=$postfeld['vertrag_liefertermin'];
					$liefert=adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_lt,3,2),p4n_mb_string('substr',$datum_lt,0,2),p4n_mb_string('substr',$datum_lt,6,4) );
				} elseif (isset($postfeld['vertrag_liefertermin1monat'])) {
					$liefert=adodb_mktime(12,0,0, $postfeld['vertrag_liefertermin1monat'], 1, $postfeld['vertrag_liefertermin2']);
				} elseif (isset($postfeld['vertrag_liefertermin1'])) {
					$lwoche=trim($postfeld['vertrag_liefertermin1']);
					if (p4n_mb_string('strlen',$lwoche)==1) {
						$lwoche='0'.$lwoche;
					}
					$liefert=strtotime($postfeld['vertrag_liefertermin2'].'W'.$lwoche);
				}
			ws_kroa_kfz($postfeld['pid'], 1);
		}
		
		if (!$vorschau and $bez_ang_kv==_KAUFVERTRAG_ and $cfg_care_neuefelder and intval($postfeld['pid'])>0) {
			$db->update(
				$sql_tab['produktzuordnung'],
				array(
					$sql_tabs['produktzuordnung']['zusatz2'] => $db->str('')
				),
				$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
			);
		}
		
		// Dello / D�rkop vkinfo setzen
		if (!$vorschau and $bez_ang_kv==_KAUFVERTRAG_ and $cfg_dvs_fm and intval($postfeld['pid'])>0) {
			$db->update(
				$sql_tab['produktzuordnung'],
				array(
					$sql_tabs['produktzuordnung']['vkinfo_carlo'] => $db->str('verkauft')
				),
				$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
			);
		}
		
		// Kauf zu DVS �bermitteln
		if (!$vorschau and $bez_ang_kv==_KAUFVERTRAG_ and $cfg_dvs and intval($postfeld['pid'])>0) {
				$diffbest1=false;
				$res5=$db->select(
					$sql_tab['produktzuordnung'],
					array(
						$sql_tabs['produktzuordnung']['hersteller'],
						$sql_tabs['produktzuordnung']['differenzbesteuerung']
					),
					$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
				);
				if ($row5=$db->zeile($res5)) {
					if ($row5[1]=='1') {
						$diffbest1=true;
					}
					if (p4n_mb_string('strlen',$row5[0])>10 or ($cfg_dvs_fm and $row5[0]!='')) {
						$postfeld['dvs_id']=$row5[0];
					}
				}

				$dpreis=doubleval(str_replace(',', '.', $postfeld['fin_preis']));
				$dnetto=doubleval($dpreis*100/(100+(100*$cfg_mwst)));
				$ust1=$dpreis-$dnetto;
				$liefert=time();
				if (isset($postfeld['vertrag_liefertermin']) and $postfeld['vertrag_liefertermin']!='') {
					$datum_lt=$postfeld['vertrag_liefertermin'];
					$liefert=adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_lt,3,2),p4n_mb_string('substr',$datum_lt,0,2),p4n_mb_string('substr',$datum_lt,6,4) );
				} elseif (isset($postfeld['vertrag_liefertermin1'])) {
					if ($cfg_kfzsuche_liefertermin_monatjahr) {
						$liefert=adodb_mktime(12,0,0, $postfeld['vertrag_liefertermin1monat'], 1, $postfeld['vertrag_liefertermin2']);
					} else {
						$liefert=strtotime($postfeld['vertrag_liefertermin2'].'W'.(strlen($postfeld['vertrag_liefertermin1'])==1?'0':'').$postfeld['vertrag_liefertermin1']);
					}
				}
				$auslt=$liefert;
				if (isset($postfeld['vertrag_auslieferung']) and $postfeld['vertrag_auslieferung']!='') {
					$datum_lt=$postfeld['vertrag_auslieferung'];
					$auslt=adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_lt,3,2),p4n_mb_string('substr',$datum_lt,0,2),p4n_mb_string('substr',$datum_lt,6,4) );
				}

			if ($bez_ang_kv==_KAUFVERTRAG_ and $cfg_dvs and $postfeld['dvs_id']!='') {
				$datum_in1=$postfeld['vertrags_gwlieferung'];
				if ($datum_in1=='') {
					$datum_in1=adodb_date('d.m.Y');
				}
				include_once('webservice/nusoap.php');
				$client = new nusoap_client($cfg_dvs_ws, true);
				if ($cfg_dvs_fm) {
					$client->soap_defencoding = 'UTF-8';
				}
				$fpreis_dvs=$postfeld['fin_preis'];
				if ($postfeld['fin_zahlungsart']=='3') {
					$fpreis_dvs=$postfeld['fin_preis2'];
				}
				$dpreis=doubleval(str_replace(',', '.', $fpreis_dvs));
				$dnetto=doubleval($dpreis*100/(100+(100*$cfg_mwst)));
				$ust1=$dpreis-$dnetto;
				$liefert=time();
				if (isset($postfeld['vertrag_liefertermin']) and $postfeld['vertrag_liefertermin']!='') {
					$datum_lt=$postfeld['vertrag_liefertermin'];
					$liefert=adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_lt,3,2),p4n_mb_string('substr',$datum_lt,0,2),p4n_mb_string('substr',$datum_lt,6,4) );
				} elseif (isset($postfeld['vertrag_liefertermin1'])) {
					$liefert=strtotime($postfeld['vertrag_liefertermin2'].'W'.(strlen($postfeld['vertrag_liefertermin1'])==1?'0':'').$postfeld['vertrag_liefertermin1']);
				}
				$auslt=$liefert;
				if (isset($postfeld['vertrag_auslieferung']) and $postfeld['vertrag_auslieferung']!='') {
					$datum_lt=$postfeld['vertrag_auslieferung'];
					$auslt=adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_lt,3,2),p4n_mb_string('substr',$datum_lt,0,2),p4n_mb_string('substr',$datum_lt,6,4) );
				}
				
				$abnehmergr='0';
				if ($postfeld['idstatus']=='privat') {
					$abnehmergr='1';
				} elseif ($postfeld['idstatus']=='gewerblich') {
					$abnehmergr='2';
				} elseif ($postfeld['idstatus']=='Wiederverk�ufer') {
					$abnehmergr='3';
				} elseif ($postfeld['idstatus']=='DB Mitarbeiter') {
					$abnehmergr='6';
				}
				
				$sf_ar=array();
				$sf_ar['Verkauf']=array(
/*					'F_UID' => $postfeld['dvs_id'],
					'BenutzerID' => $dvs_username,
					'KundenID' => $_SESSION['stammdaten_id'],
					'Preis' => str_replace(',', '.', $postfeld['fin_preis']),
					'Bemerkung' => p4n_mb_string('utf8_encode',$postfeld['vertrags_vereinbarungen'])
*/					'hasChanges' => true,
					'Verkauf_ID' => -1,
					'Verkaeufer_ID' => intval($dvs_username),
					'Datum_Verkauf' => timestamp_to_iso8601(time()),
					'Datum_Auslieferung_geplant' => timestamp_to_iso8601($auslt),
					'Datum_Auslieferung_erfolgt' => timestamp_to_iso8601($auslt),
					'Betrag_Verkaufspreis_netto' => doubleval($dnetto),
					'Betrag_Verkaufspreis_MWST_Satz' => doubleval($cfg_mwst*100),
					'Betrag_Verkaufspreis_MWST' => doubleval($ust1),
					'Betrag_Verkaufspreis_Brutto' => doubleval($dpreis),
					'Kunden_ID' => $_SESSION['stammdaten_id'],
					'Abnehmergruppe' => $abnehmergr,
					'Finanzierung' => 0,
					'Garantie' => 0,
					'Versicherung' => 0,
					'Aufmerksam' => 0,
					'GW_Marke' => 0
				);
				if (isset($postfeld['vertrag_eugeschaeft'])) {
					$sf_ar['Verkauf']['Betrag_Verkaufspreis_MWST_Satz']=0;
					$sf_ar['Verkauf']['Betrag_Verkaufspreis_MWST']=0;
					$sf_ar['Verkauf']['Betrag_Verkaufspreis_Brutto']=doubleval($dnetto);
				} elseif ($diffbest1) {
					$sf_ar['Verkauf']['Betrag_Verkaufspreis_MWST_Satz']=0;
					$sf_ar['Verkauf']['Betrag_Verkaufspreis_MWST']=0;
					$sf_ar['Verkauf']['Betrag_Verkaufspreis_netto']=doubleval($dpreis);
				}
				if (isset($postfeld['vertrags_ankauf'])) {
					$sf_ar['Inzahlungnahme']=array(
/*						'DATAZ' => $postfeld['inz_auswahl'],
						'Lagerort' => $v_lao2,
						'Ankaufpreis' => str_replace(',', '.', $postfeld['vertrags_gwpreis']),
						'Lieferdatum' => timestamp_to_iso8601(adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_in1,3,2),p4n_mb_string('substr',$datum_in1,0,2),p4n_mb_string('substr',$datum_in1,6,4) )),
*/						'ID' => -1,
						'DATAZ' => $postfeld['inz_auswahl'],
						'Lagerort' => intval($v_lao2),
						'Ankaufpreis' => strval(doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis']))),
						'Lieferdatum' => timestamp_to_iso8601(adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_in1,3,2),p4n_mb_string('substr',$datum_in1,0,2),p4n_mb_string('substr',$datum_in1,6,4) )),
						'Ankaeufer' => $dvs_username,
						'Steuerart' => $postfeld['vertrags_dvs_steuer'],
						'Hereinnahmeart' => $postfeld['vertrags_dvs_h1'],
						'Hereinnahmeunterart' => $postfeld['vertrags_dvs_h2'],
						'Datum_Ankauf' => timestamp_to_iso8601(adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_in1,3,2),p4n_mb_string('substr',$datum_in1,0,2),p4n_mb_string('substr',$datum_in1,6,4) )),
						'Status' => 1
					);
				}
				$sf_ar['F_UID']=$postfeld['dvs_id'];

				// Res. l�schen:
				$result = $client->call("getFahrzeug", dvsfm_para(array('DVSGWID' => $postfeld['dvs_id'], 'WhichID' => 'F_UID'), "getFahrzeug"), dvsfm_ns());
				$result=dvsfm_res($result);
				if (isset($result['dvsFahrzeug'])) {

					if ($result['dvsFahrzeug']['Fremd_ID']!='') {
			$res9=$db->select(
			$sql_tab['produktzuordnung_reservierung'],
			array(
				$sql_tabs['produktzuordnung_reservierung']['produktzuordnung_reservierung_id'],
				$sql_tabs['produktzuordnung_reservierung']['datum_von'],
				$sql_tabs['produktzuordnung_reservierung']['datum_bis']
			),
			$sql_tabs['produktzuordnung_reservierung']['fahrzeug_nummer'].'='.$db->str($result['dvsFahrzeug']['Fremd_ID'])
			);
			while ($row9=$db->zeile($res9)) {
			if ($db->unixdate_ts($row9[1])<=time() and $db->unixdate_ts($row9[2])>=time()) {
				$db->update(
					$sql_tab['produktzuordnung_reservierung'],
					array(
						$sql_tabs['produktzuordnung_reservierung']['datum_bis'] => $db->dbtimestamp(time()),
						$sql_tabs['produktzuordnung_reservierung']['bemerkung'] => $db->str(_LOESCHUNG_)
					),
					$sql_tabs['produktzuordnung_reservierung']['produktzuordnung_reservierung_id'].'='.$db->dbzahl($row9[0])
				);
				if (intval($postfeld['pid'])>0) {
				$db->update(
					$sql_tab['produktzuordnung'],
					array(
						$sql_tabs['produktzuordnung']['reservierung'] => $db->dbzahl(0),
						$sql_tabs['produktzuordnung']['reservierung_datum'] => $db->dbtimestamp(null),
						$sql_tabs['produktzuordnung']['reservierung_bisdatum'] => $db->dbtimestamp(null)
					),
					$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
				);
				}
			}
			}
					}
							$rval=$result['dvsFahrzeug'];
							if (isset($rval['Reservierung']['cReservierung'])) {
								$resarr=$rval['Reservierung']['cReservierung'];
								if (isset($rval['Reservierung']['cReservierung']['Res_ID'])) {
									$resarr=array($rval['Reservierung']['cReservierung']);
								}
								$nlb=false;
								while (list($keyr, $valr)=@each($resarr)) {
if (!$cfg_dvs_fm) {
			$result = $client->call("reserveFahrzeug2", array(
				'Reservierung2' => array(
					'Res_ID' => $valr['Res_ID'],
					'Res_FUID' => $valr['Res_FUID'],
					'Res_Verkaeufer_ID' => $dvs_username,
					'Res_Kunden_ID' => '1',
					'Res_von' => timestamp_to_iso8601(time()),
					'Res_bis' => timestamp_to_iso8601(time()+48*24*60*60),
					'Res_Preis' => doubleval(1),
					'Res_Bemerkung' => 'loeschen',
					'Res_Date' => timestamp_to_iso8601(time()),
					'Res_State' => 3,
					'ChangeUser' => $dvs_username,
					'ChangeDate' => timestamp_to_iso8601(time())
				)
			));
			if ($dvs_ws_logging_sf) {
				if ($dvs_ws_logging_alert) {
					echo javas('alert("'.p4n_mb_string('substr',str_replace(array('"', "\n", "\r"), '', $client->request), 0, 1000).'");');
					echo javas('alert("'.p4n_mb_string('substr',str_replace(array('"', "\n", "\r"), '', $client->response), 0, 1000).'");');
				}
				if ($fp=fopen('log/dvs/crm2dvs_reserveFahrzeug2_request_.'.adodb_date('d_m_Y_His').'.xml', 'w')) {
					fwrite($fp, $client->request);
					fclose($fp);
				}
				if ($fp=fopen('log/dvs/crm2dvs_reserveFahrzeug2_.'.adodb_date('d_m_Y_His').'.xml', 'w')) {
					fwrite($fp, $client->response);
					fclose($fp);
				}
			}
}
								}
							}
				}
				$result = $client->call("sellFahrzeug", dvsfm_para(array(
					'SellCar' => $sf_ar
				), "sellFahrzeug"), dvsfm_ns());
				$result=dvsfm_res($result);
				if ($dvs_ws_logging_sf) {
					if ($dvs_ws_logging_alert) {
						echo javas('alert("'.p4n_mb_string('substr',str_replace(array('"', "\n", "\r"), '', $client->request), 0, 1000).'");');
						echo javas('alert("'.p4n_mb_string('substr',str_replace(array('"', "\n", "\r"), '', $client->response), 0, 1000).'");');
					}
					if ($fp=fopen('log/dvs/crm2dvs_sellFahrzeug_request_.'.adodb_date('d_m_Y_His').'.xml', 'w')) {
						fwrite($fp, $client->request);
						fclose($fp);
					}
					if ($fp=fopen('log/dvs/crm2dvs_sellFahrzeug_.'.adodb_date('d_m_Y_His').'.xml', 'w')) {
						fwrite($fp, $client->response);
						fclose($fp);
					}
				}
				
				if ($cfg_dvs_fm) {
					if ($fp=fopen('log/dvs/crm2dvs_sellFahrzeug_result_'.adodb_date('d_m_Y_His').'.txt', 'w')) {
						fwrite($fp, print_r($result, true));
						fclose($fp);
					}
					if (isset($result['beschreibung'])) {
						echo javas('alert("Verkaufsstatus FM: '.$result['beschreibung'].'");');
					} else {
						echo javas('alert("Verkaufsstatus FM: Fehler");');
					}
				} elseif ($keine_dvssuche) {
					
				} else {
				if (isset($result['sellFahrzeugResult'])) {
					if (p4n_mb_string('strtolower',$result['sellFahrzeugResult']['Status'])=='false') {
						echo javas('alert("Achtung: Verkauf wurde nicht nach DVS gemeldet!");');
						echo javas('alert("DVS-Status: '.$result['sellFahrzeugResult']['Beschreibung'].'.");');
						die();
					}
					echo javas('alert("DVS-Status: '.$result['sellFahrzeugResult']['Beschreibung'].'.");');
					$db->update(
						$sql_tab['produktzuordnung'],
						array(
							$sql_tabs['produktzuordnung']['zusatzcode_1'] => $db->str('verkauft')
						),
						$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
					);
				} else {
					echo javas('alert("Achtung: technischer Fehler, Verkauf wurde nicht nach DVS gemeldet!");');
					die();
				}
				}
			}
		}

		if ($postfeld['vertrag_nwgw']=='1') {
			$postfeld['vertrag_zulassung']=$postfeld['vertrag_zulassung2'];
			$postfeld['vertrag_transport']=$postfeld['vertrag_transport2'];
		}

		$postfeld['pid_preis']=str_replace('.', '', $postfeld['kfz_preis']);

		$ltext='';

		$summe=doubleval(number_format(doubleval($postfeld['pid_preis']), 2, '.', ''));
//		$ltext='1 x '.$pid_bez."\t".number_format($summe, 2, ",", ".")." \n";
		while (list($key, $val)=@each($postfeld['pos1'])) {
			if (trim($postfeld['pos2'][$key]!='')) {
				if (intval($val)==0) {
					$val==1;
				}
				$betrag=doubleval(str_replace(',', '.', $postfeld['pos3'][$key]));
				$ltext.=$val.' x '.$postfeld['pos2'][$key]."\t".number_format($betrag, 2, ",", ".")." ".$waehrung_eur."\n";
				$summe+=$betrag;
			}
		}
		for ($auss_i=1; $auss_i<=100; $auss_i++) {
			if ($postfeld['vertrag_sonder'.$auss_i]!='') {
				$soa_p=$postfeld['vertrag_sonderpreis'.$auss_i];
				if (doubleval($soa_p)>0) {
					$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
				}
				$ltext.=$postfeld['vertrag_sonder'.$auss_i]."\t".$soa_p." ".$waehrung_eur."\n";
			}
		}

		$fintext='';
		if ($postfeld['finanzierung']!='-1') {
			$ltext.="\n";

			$fintext.=$lang_db_f['produktzuordnung']['finanzierung'].'/'.$lang['_AUFTRAG-L_'].': '.$finarr[$postfeld['finanzierung']]."\n";
			$fintext.=$lang['_VERTRAG-NUMMER_'].': '.$postfeld['fin_nr']."\n";
			$fintext.=_KOSTEN_.': '.number_format(doubleval($postfeld['fin_kosten']), 2, ",", ".")." ".$waehrung_eur."\n";
			$fintext.=_LAUFZEIT_.': '.$postfeld['fin_laufzeit']."\n";
			$fintext.=_ANSONDERZAHLUNG_.': '.number_format(doubleval($postfeld['fin_anzahlung']), 2, ",", ".")." ".$waehrung_eur."\n";
			$fintext.=_RESTWERT_.': '.number_format(doubleval($postfeld['fin_restwert']), 2, ",", ".")." ".$waehrung_eur."\n";
			$fintext.=_AUSLAUF_.': '.$postfeld['fin_auslauf'];
			if ($postfeld['fin_rsv']!='') {
				$fintext.="\n"._RESTSCHULDV_.': '.$postfeld['fin_rsv']." ".$waehrung_eur."\n";
			}

//			$ltext.=$fintext;
		}

		if ($postfeld['vertrag_bemerkung']!='') {
			$ltext.="\n\n"._BEMERKUNG_.': '.$postfeld['vertrag_bemerkung'];
		}

		$doclink='';

		if ($cfg_kfzsuche_italien and $cfg_mwst!=$cfg_mwstn) {
			$alle_vatf=array('listenpreis', 'listenpreis5', 'vertrag5_farbepreis', 'vertrag5_trimpreis');
			$alle_vatf2=array('vertrag5_sonderpreis');	// nicht die mit vertrag5_istacc?
			$alle_vatf3=array('vertrag5_gesamt', 'vertrag5_summe', 'vertrag5_hauspreis', 'vertrag_summealles', 'fin_preis2');	// minus
			//'vertrag_sonderpreis', 'vertrag2_sonderpreis', 'vertrag3_sonderpreis',
			$minus_vf=0;
			while (list($key1, $val1)=@each($alle_vatf)) {
				if (isset($postfeld[$val1])) {
					$diff1=0;
					$postfeld[$val1]=itrechnezweitsteuer($postfeld[$val1]);
					$minus_vf+=$diff1;
				}
			}
			while (list($key1, $val1)=@each($alle_vatf2)) {
				for ($xi=0; $xi<200; $xi++) {
					if (isset($postfeld[$val1.$xi])) {
						$diff1=0;
						$postfeld[$val1.$xi]=itrechnezweitsteuer($postfeld[$val1.$xi]);
						$minus_vf+=$diff1;
					}
				}
			}
			while (list($key1, $val1)=@each($alle_vatf3)) {
				if (isset($postfeld[$val1])) {
					$postfeld[$val1]=itrechnezweitsteuer($postfeld[$val1], true);
				}
			}

			$postfeld['vat_listenpreis5']=itrechnezweitsteuer($postfeld['listenpreis5'], false, true);
			$postfeld['vat_farbe5']=itrechnezweitsteuer($postfeld['vertrag5_farbepreis'], false, true);
			$postfeld['vat_trim5']=itrechnezweitsteuer($postfeld['vertrag5_trimpreis'], false, true);
			for ($xi=0; $xi<200; $xi++) {
				if (isset($postfeld['vertrag5_sonderpreis'.$xi])) {
					$postfeld['vat_aus5'.$xi]=itrechnezweitsteuer($postfeld['vertrag5_sonderpreis'.$xi], false, true);
				}
			}
			// vat_listenpreis5 vat_farbe5 vat_trim5 vat_aus5..
		}
//echo $minus_vf;
//die();

		if (($cfg_kfzsuche_holland or $cfg_kfzsuche_vgw) and isset($postfeld['vorlage_gw'])) {
			$postfeld['vertrag_nwgw']='1';
		}

		$det_datei='kaufvertrag';
		if ($bez_ang_kv==_ANGEBOT_) {
			$det_datei='angebot';
		}
		if ($bez_ang_kv2=='skv') {
			$det_datei_ids='sammelkaufvertrag';
			if (is_file('vorlagen/vorlage_'.$det_datei_ids.'.rtf')) {
				$det_datei=$det_datei_ids;
			} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei_ids.'.rtf')) {
				$det_datei=$det_datei_ids;
			}
		}
		if ($bez_ang_kv=='Vorvertragsinformation') {
			$det_datei='vorvertragsinformation';
			$det_datei_ids=$det_datei;
			if ($cfg_db_kaufrecht2022) {
				if ($postfeld['idstatus']=='DB Mitarbeiter' or $postfeld['idstatus']=='privat') {
					$det_datei_ids.='_privat';
				} else {
					$det_datei_ids.='_gewerblich';
				}
			}
			if (!$cfg_db_kaufrecht2022) {
				$det_datei_ids='sachmangel_vorvertrag';
			}
			if (is_file('vorlagen/vorlage_'.$det_datei_ids.'.rtf')) {
				$det_datei=$det_datei_ids;
			} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei_ids.'.rtf')) {
				$det_datei=$det_datei_ids;
			}
			
			$v_lao=$postfeld['mvertrag_lagerort'];
			$res3=$db->select(
					$sql_tab['mandant'],
					array(
						$sql_tabs['mandant']['bezeichnung'],
						$sql_tabs['mandant']['parent_id']
					),
					$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($v_lao)
			);
			if ($row3=$db->zeile($res3)) {
				$v_lao=trim($row3[0]);
			}
			$det_datei_ids='sachmangel_vorvertrag_'.$v_lao;
			if (is_file('vorlagen/vorlage_'.$det_datei_ids.'.rtf')) {
				$det_datei=$det_datei_ids;
			} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei_ids.'.rtf')) {
				$det_datei=$det_datei_ids;
			}
			
		}
		if ($bez_ang_kv2=='expose') {
			$det_datei='expose';
			if (isset($postfeld['vorlage_auswahl']) and $postfeld['vorlage_auswahl']=='2') {
				$det_datei.='_premium_mt';
			}
			if (isset($postfeld['vorlage_auswahl']) and $postfeld['vorlage_auswahl']=='3') {
				$det_datei.='_premium_swf';
			}
		}
		if ($postfeld['vertrag_nwgw']!='1' and $cfg_kfzsuche_tz_immer_vfw) {
				if (isset($postfeld['kfz_tz']) and intval($postfeld['kfz_tz'])==1) {
					$postfeld['vorlage_vfw']='1';
				}
		}
		if ($bez_ang_kv2!='skv' and $bez_ang_kv!='Vorvertragsinformation' and isset($postfeld['vertrag_nwgw'])) {
			$det_datei_typ='_gw';
			if ($postfeld['vertrag_nwgw']=='2' or $postfeld['vertrag_nwgw']=='4' or $postfeld['vertrag_nwgw']=='5' or ($postfeld['vertrag_nwgw']=='8' and !isset($postfeld['vorlage_vfw']))) {
				$det_datei_typ='_nw';
			}
			if ($postfeld['vertrag_nwgw']=='3' or $postfeld['vertrag_nwgw']=='6' or $postfeld['vertrag_nwgw']=='7' or ($postfeld['vertrag_nwgw']=='8' and isset($postfeld['vorlage_vfw']))) {
				$det_datei_typ='_vfw';
			}
			if (isset($postfeld['dvs_kfzkat'])) {
				if ($postfeld['dvs_kfzkat']=='2' or $postfeld['dvs_kfzkat']=='4') {
					$det_datei_typ='_nw';
				}
				if ($postfeld['dvs_kfzkat']=='3' or $postfeld['dvs_kfzkat']=='5') {
					$det_datei_typ='_vfw';
				}
			}
			if ($cfg_kfzsuche_mietvorlage and ($kfz_fstatuscode=='6' or $kfz_fstatus=='Mietfahrzeug' or $kfz_fstatus=='Mietwagen')) {
				$det_datei_typ='_miet';
			}
			if (($_SESSION['cfg_kunde']=='carlo_opel_dello' and substr($kfz_fstatus, 0, 4) == 'Test') || ($_SESSION['cfg_kunde'] == 'carlo_opel_duerkop' and substr($kfz_fstatus, 0, 5) == 'Tages')) {
				$det_datei_typ='_tw';
			}
			$det_datei_typ2='_bar';
			if ($postfeld['fin_zahlungsart']!='3') {
				$det_datei_typ2='_fin';
			}
			$det_datei.=$det_datei_typ.$det_datei_typ2;
		}
		
		$ist_docx=false;
		
		$dok_gef=false;
		$aov_vgef=false;
		if ($aov_gruppe!='') {
				$det_datei2=$det_datei;
				$det_datei2.='_'.$aov_gruppe;
				if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
					$det_datei=$det_datei2;
					$dok_gef=true;
					$aov_vgef=true;
				} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
					$det_datei=$det_datei2;
					$dok_gef=true;
					$aov_vgef=true;
				} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
					$det_datei=$det_datei2;
					$dok_gef=true;
					$aov_vgef=true;
					$ist_docx=true;
				} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
					$det_datei=$det_datei2;
					$dok_gef=true;
					$aov_vgef=true;
					$ist_docx=true;
				}
		}
		
		$m_mand1=1;
		
		if (!$dok_gef and $postfeld['vertrag_lagerort']!='' and $postfeld['kfz_markencode']!='') {
			$v_lao=$postfeld['vertrag_lagerort'];
			$res3=$db->select(
				$sql_tab['mandant'],
				array(
					$sql_tabs['mandant']['bezeichnung'],
					$sql_tabs['mandant']['parent_id']
				),
				$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($v_lao)
			);
			if ($row3=$db->zeile($res3)) {
				$v_lao=trim($row3[0]);
				if (intval($row3[1])>0) {
					$m_mand1=$row3[1];
					$det_datei2=$det_datei;
					$det_datei2.='_M'.$row3[1];
					$det_datei2.='_'.p4n_mb_string('strtolower',trim($postfeld['kfz_markencode']));
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf') or is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
						$v_lao='M'.$row3[1];
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx') or is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
						$v_lao='M'.$row3[1];
						$ist_docx=true;
					}
				}
			}
			$det_datei2=$det_datei;
			$det_datei2.='_'.$v_lao;
			$det_datei2.='_'.p4n_mb_string('strtolower',trim($postfeld['kfz_markencode']));
			if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
				$det_datei=$det_datei2;
				$dok_gef=true;
			} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
				$det_datei=$det_datei2;
				$dok_gef=true;
			} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
				$det_datei=$det_datei2;
				$dok_gef=true;
				$ist_docx=true;
			} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
				$det_datei=$det_datei2;
				$dok_gef=true;
				$ist_docx=true;
			}
		}
		if (!$dok_gef and $postfeld['vertrag_lagerort']!='' and $postfeld['vorlage_zus']!='' and !isset($postfeld['vorlage_rd_gk'])) {
			$v_lao=$postfeld['vertrag_lagerort'];
			$res3=$db->select(
				$sql_tab['mandant'],
				array(
					$sql_tabs['mandant']['bezeichnung'],
					$sql_tabs['mandant']['parent_id']
				),
				$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($v_lao)
			);
			if ($row3=$db->zeile($res3)) {
				$v_lao=trim($row3[0]);
				if (intval($row3[1])>0) {
					$m_mand1=$row3[1];
					$det_datei2=$det_datei;
					$det_datei2.='_M'.$row3[1];
					$det_datei2.='_'.trim($postfeld['vorlage_zus']);
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf') or is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
						$v_lao='M'.$row3[1];
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx') or is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
						$v_lao='M'.$row3[1];
						$ist_docx=true;
					}
				}
			}
			$det_datei2=$det_datei;
			$det_datei2.='_'.$v_lao;
			$det_datei2.='_'.trim($postfeld['vorlage_zus']);
			if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
				$det_datei=$det_datei2;
				$dok_gef=true;
			} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
				$det_datei=$det_datei2;
				$dok_gef=true;
			} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
				$det_datei=$det_datei2;
				$dok_gef=true;
				$ist_docx=true;
			} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
				$det_datei=$det_datei2;
				$dok_gef=true;
				$ist_docx=true;
			}
		}

		if ($postfeld['vertrag_lagerort']!='' and !$dok_gef) {
			$v_lao=$postfeld['vertrag_lagerort'];
			$res3=$db->select(
				$sql_tab['mandant'],
				array(
					$sql_tabs['mandant']['bezeichnung'],
					$sql_tabs['mandant']['parent_id']
				),
				$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($v_lao)
			);
			if ($row3=$db->zeile($res3)) {
				$v_lao=trim($row3[0]);
				if (intval($row3[1])>0) {
					$m_mand1=$row3[1];
					$det_datei2=$det_datei;
					$det_datei2.='_M'.$row3[1];
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf') or is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
						$v_lao='M'.$row3[1];
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'_'.$v_lao.'.rtf') or is_file('vorlagen/vorlage_'.$det_datei2.'_'.$v_lao.'.rtf')) {
						$v_lao='M'.$row3[1].'_'.$v_lao;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx') or is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
						$v_lao='M'.$row3[1];
						$ist_docx=true;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'_'.$v_lao.'.docx') or is_file('vorlagen/vorlage_'.$det_datei2.'_'.$v_lao.'.docx')) {
						$v_lao='M'.$row3[1].'_'.$v_lao;
						$ist_docx=true;
					}
				}
			}
			$det_datei2=$det_datei;
			$det_datei2.='_'.$v_lao;
			if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
				$det_datei=$det_datei2;
				$dok_gef=true;
			} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
				$det_datei=$det_datei2;
				$dok_gef=true;
			} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
				$det_datei=$det_datei2;
				$dok_gef=true;
				$ist_docx=true;
			} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
				$det_datei=$det_datei2;
				$dok_gef=true;
				$ist_docx=true;
			}
		}
		if ($_SESSION['cfg_kunde']=='carlo_opel_kramm') {
			if (strtolower($postfeld['kfz_markencode'])=='chevrolet' and substr(strtolower($postfeld['kfz_typmodell']), 0, strlen('corvette c8'))=='corvette c8') {
				$det_datei2=$det_datei;
				$det_datei2.='_corvette';
				if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
					$det_datei=$det_datei2;
				} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
					$det_datei=$det_datei2;
				} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
					$det_datei=$det_datei2;
					$ist_docx=true;
				} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
					$det_datei=$det_datei2;
					$ist_docx=true;
				}
			}
		}
		if ($postfeld['kfz_markencode']!='' and !$dok_gef) {
			$det_datei2=$det_datei;
			$det_datei2.='_'.p4n_mb_string('strtolower',trim($postfeld['kfz_markencode']));
			if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
				$det_datei=$det_datei2;
			} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
				$det_datei=$det_datei2;
			} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
				$det_datei=$det_datei2;
				$ist_docx=true;
			} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
				$det_datei=$det_datei2;
				$ist_docx=true;
			}
		}
		
		if (isset($postfeld['vorlage_zus'])) {
			$det_datei2=$det_datei;
			$det_datei2.='_'.p4n_mb_string('strtolower',trim($postfeld['vorlage_zus']));
			if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
				$det_datei=$det_datei2;
			} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
				$det_datei=$det_datei2;
			} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
				$det_datei=$det_datei2;
				$ist_docx=true;
			} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
				$det_datei=$det_datei2;
				$ist_docx=true;
			}
		}
		if ($cfg_db_kaufrecht2022) {
			$det_datei_ids=$det_datei;
			if ($postfeld['idstatus']=='DB Mitarbeiter' or $postfeld['idstatus']=='privat') {
				$det_datei_ids.='_privat';
			} else {
				$det_datei_ids.='_gewerblich';
			}
			if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei_ids.'.rtf')) {
				$det_datei=$det_datei_ids;
			}
		}
		if (isset($postfeld['vorlage_rd_gk'])) {
					$det_datei2=$det_datei;
					$det_datei2.='_gk';
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					}
		}
		
		if (isset($postfeld['vorlage_email'])) {
					$det_datei2=$det_datei;
					$det_datei2.='_email';
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					}
		}
		
		if (isset($postfeld['ohnemwstexport'])) {
					$det_datei2=$det_datei;
					$det_datei2.='_ex';
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					}
		}
		
		if (intval($postfeld['pid'])<=0) {
					$det_datei2=$det_datei;
					$det_datei2.='_konf';
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					}
		}
		
		if ($cfg_kfzsuche_holland and isset($postfeld['tonnage']) and isset($cfg_mbks_truck_fromkg)) {
			$tons1=intval($postfeld['tonnage']);
			if ($cfg_mbks_truck_fromkg>0) {
				if ($tons1>=$cfg_mbks_truck_fromkg) {
					$det_datei2=$det_datei;
					$det_datei2.='_truck';
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					}
				} elseif ($tons1>0) {
					$det_datei2=$det_datei;
					$det_datei2.='_van';
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					}
				}
			}
		}
		
		if ($cfg_ws_avag_kroatien and !isset($postfeld['kurs_waehrung3'])) {	// isset($postfeld['trosawert2'])
			$det_datei2=$det_datei.'_kunar';
				if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
					$det_datei=$det_datei2;
				} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
					$det_datei=$det_datei2;
				} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
					$det_datei=$det_datei2;
					$ist_docx=true;
				} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
					$det_datei=$det_datei2;
					$ist_docx=true;
				}
		}
		
		if ($cfg_greek or $cfg_kfzsuche_norway) {
			if ($postfeld['firma1']!='') {
				$det_datei2=$det_datei.'_bc';
				if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
					$det_datei=$det_datei2;
				} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
					$det_datei=$det_datei2;
				} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
					$det_datei=$det_datei2;
					$ist_docx=true;
				} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
					$det_datei=$det_datei2;
					$ist_docx=true;
				}
			} elseif ($postfeld['firma1']=='') {
				$det_datei2=$det_datei.'_pc';
				if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
					$det_datei=$det_datei2;
				} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
					$det_datei=$det_datei2;
				} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
					$det_datei=$det_datei2;
					$ist_docx=true;
				} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
					$det_datei=$det_datei2;
					$ist_docx=true;
				}
			}
		}
		
		if ($cfg_carlo_appserver_activity and $kfz_generat!='') {
					$det_datei2=$det_datei;
					$det_datei2.='_'.substr($kfz_generat, 0, 2);
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					}
		}
		
		if (isset($postfeld['oldtimer'])) {
					$det_datei2=$det_datei;
					$det_datei2.='_ot';
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					}
		} elseif (isset($postfeld['youngtimer'])) {
					$det_datei2=$det_datei;
					$det_datei2.='_yt';
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					}
		}
		if (isset($postfeld['englisch'])) {
					$det_datei2=$det_datei;
					$det_datei2.='_en';
					if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
						$det_datei=$det_datei2;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.docx')) {
						$det_datei=$det_datei2;
						$ist_docx=true;
					}
		}
		
		$variante2=false;
		if (intval($postfeld['vertrag_nwgw'])>=4) {// and intval($postfeld['vertrag_nwgw'])!=8
			if (intval($postfeld['vertrag_nwgw'])==8 and intval($postfeld['nwvorlage'])==4) {
				$det_datei.='_3';
				$variante2=true;
			} elseif (intval($postfeld['vertrag_nwgw'])==8 and intval($postfeld['nwvorlage'])==1) {
				
			} else {
				$det_datei.='_2';
				$variante2=true;
			}
		}
		$cfg_kvdok='vorlagen/vorlage_'.$det_datei.'.rtf';
		if ($ist_docx) {
			$cfg_kvdok='vorlagen/vorlage_'.$det_datei.'.docx';
		}
		if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei.'.docx')) {
			$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei.'.docx';
			$ist_docx=true;
		} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei.'.rtf')) {
			$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei.'.rtf';
		}
		
		if (($cfg_kfzsuche_vorlageauswahl or $cfg_s4_bmw20) and isset($postfeld['vorlageauswahl'])) {
			if ($postfeld['vorlageauswahl']!='-1' and $postfeld['vorlageauswahl']!='') {
				$ist_docx=false;
				$cfg_kvdok=$postfeld['vorlageauswahl'];
				if (substr($cfg_kvdok, -5)=='.docx') {
					$ist_docx=true;
				}
			}
		}
		
		if ($profitdruck) {
			$variante2=true;
			$det_datei='profitcalc';
			if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei.'.docx')) {
				$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei.'.docx';
				$ist_docx=true;
			} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei.'.rtf')) {
				$cfg_kvdok='inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei.'.rtf';
			}
		}
		
		if (isset($postfeld['vertrags_vereinbarungen2m']) and $postfeld['vertrags_vereinbarungen2m']!='') {
			$postfeld['vertrags_vereinbarungen2'].=' '.$postfeld['vertrags_vereinbarungen2m'];
		}
		
		if ($_SESSION['user_id']==1 and strtolower($postfeld['vertrags_vereinbarungen2'])=='vorlage') {
			if ($fpx=fopen('_vorlageinfo.txt', 'w')) {
				fwrite($fpx, $cfg_kvdok);
				fclose($fpx);
			}
		}
		
//echo intval($ist_docx).$cfg_kvdok.'<br>';
//$cfg_kvdok='inc/carlo_opel_huebner/vorlage_kaufvertrag_nw_bar_konf_2.rtf';
//$cfg_kvdok='inc/carlo_opel_huebner/vorlage_angebot_nw_bar.docx'; $ist_docx=true;
//die();
		
		if (($cfg_kfzsuche_holland or $cfg_kfzsuche_vgw) and isset($postfeld['vorlage_gw'])) {
			$postfeld['vertrag_nwgw']='8';
		}
		
		if ($ist_docx) {
			$cfg_kvdok=docx_entp($cfg_kvdok);
		}
		
		$felder=allefelder($cfg_kvdok);
		
		$inhalt='';
		if ($fp=@fopen($cfg_kvdok, 'r')) {
			$gesamtblock='';
			$inhalt=fread($fp, filesize($cfg_kvdok));
			fclose($fp);
		}
		$inhalt=p4n_sb_preg_replace('/\}\{\\\\f1\\\\fs20\\\\insrsid\d+ /', '', $inhalt);
		
		if ($ustabw>0) {
			$inhalt=p4n_sb_strreplace('19%', $ustabw.'%', $inhalt);
			$inhalt=p4n_sb_strreplace('19 %', $ustabw.' %', $inhalt);
		}
		
		if ($variante2 and preg_match('/<<sondera2>>/i', $inhalt)) {
			$variante2=true;
		} else {
			$variante2=false;
		}
		
		// Inhalt extrahieren f�r Seitenkopien:
		$ende='';
		if (isset($postfeld['vorlage_kopien'])) {// and intval($postfeld['vorlage_kopien'])>0
			$m_inhalt=$inhalt;
			$inhalt3=$inhalt;
			if ($ist_docx) {
						$replace_text=$inhalt;
						$inhalt=str_replace('&lt;&lt;', '<<', $inhalt);
						$inhalt=str_replace('&gt;&gt;', '>>', $inhalt);
						$beginn="";
						$ende='';
						if (preg_match("/^(.*body>)(.*)(<\/w:body>.*)$/Uis",$inhalt,$gefunden)) {
							$beginn=$gefunden[1];
							$replace_text=$gefunden[2];
							$ende=$gefunden[3];
						} elseif (preg_match("/:body>(.*)(<\/w:body>.*)/imus",$inhalt,$gefunden)) {
							$replace_text=$gefunden[1];
							$inh2=str_replace($gefunden[1], '', $inhalt);
							if (preg_match("/^(.*body>)(.*)(<\/w:body>.*)$/Uis",$inh2,$gefunden)) {
								$beginn=$gefunden[1];
								$ende=$gefunden[3];
							}
						}
			} elseif (preg_match("/^\{(.*)(\{\\\info.*(\{[^\}]*\})\})(.*)\}$/Us",$inhalt3,$gefunden)) {
				$beginn="";
				while (list($key,$val)=@each($gefunden))
					if ($key!=0 and $key!=(count($gefunden)-1) and $key!=(count($gefunden)-2))
						$beginn.=$gefunden[$key];
				$replace_text=$gefunden[count($gefunden)-1];
			} elseif(preg_match("/^\{(.*)(\{\\\info.*(\{.*\})\})(.*)\}/Uis",$inhalt3,$gefunden)) {
						// ab PHP 5.2
						$beginn="";
						while (list($key,$val)=@each($gefunden)) {
							if ($key!=0 and $key!=(count($gefunden)-1) and $key!=(count($gefunden)-2)) {
								$beginn.=$gefunden[$key];
							}
						}
						$replace_text=$gefunden[count($gefunden)-1];

						$replace_text=p4n_mb_string('strstr',$inhalt3, $replace_text);
						if (p4n_mb_string('substr',$replace_text, -1)=='}') {
							$replace_text=p4n_mb_string('substr',$replace_text, 0, -1);
						}
			} elseif (preg_match("/\{(.*)\}(.*)\}/s",$inhalt3,$gefunden)) {
				// Wordpad:
				$beginn=$gefunden[1].'}';
				$replace_text=$gefunden[2];
			} else {
				$replace_text="";	// $inhalt3
			}
			$inhalt=$replace_text;
		}
		
		if (isset($postfeld['vertrags_ankauf_nuraufzahlung'])) {
			$inhalt=p4n_sb_preg_replace('/<<inzna>>.*<<inzne>>/Uis', '', $inhalt);
		}
		$inhalt=p4n_sb_strreplace(array('<<inzna>>', '<<inzne>>'), '', $inhalt);
		
		// lange Version: <<st1>> und <<st2>>
		$ausst_zeile='';
		$ausst_zeileg='';
		$ausst_zeilea='';
		$ausst_zeilea2='';
		if (preg_match('/<<st1>>(.*)<<st2>>/Uis', $inhalt, $ma)) {
			$ausst_zeile=$ma[1];
			$ausst_zeileg=$ma[0];
		}
		if (preg_match('/<<profc12>>(.*)<<profc22>>/Uis', $inhalt, $ma)) {
			$ausst_zeilepc=$ma[1];
			$ausst_zeilegpc=$ma[0];
		}
		if (preg_match('/<<profc31>>(.*)<<profc32>>/Uis', $inhalt, $ma)) {
			$ausst_zeilepc3=$ma[1];
			$ausst_zeilegpc3=$ma[0];
		}
		$ausst_zeilen='';
		$ausst_zeilegn='';
		$ausst_zeilegnz='';
		$ausst_zeilean='';
		$ausst_zeilea2n='';
		if (preg_match('/<<st12>>(.*)<<st22>>/Uis', $inhalt, $ma)) {
			$ausst_zeilen=$ma[1];
			$ausst_zeilegn=$ma[0];
		}
		if (preg_match('/<<st12z>>(.*)<<st22z>>/Uis', $inhalt, $ma)) {
			$ausst_zeilegnz=$ma[0];
		}

		$hzb_zeilean='';
		if (preg_match('/<<hzb12>>(.*)<<hzb22>>/Uis', $inhalt, $ma)) {
			$hzb_zeilen=$ma[1];
			$hzb_zeilegn=$ma[0];
		}
			$ltext2='';
			@reset($mpostfeld);
			while (list($pkey, $pval)=@each($mpostfeld)) {
                if ($pkey === 'tech_data') {
                    $pval = base64_decode($pval);
                }
				if ($pkey!='neukunde') {
					$ltext2.=$pkey.'==='.$pval."#####";
				}
			}
			@reset($mpostfeld);

		$opp_maid=$manda_id;
		if (isset($postfeld['opp_mandant'])) {
			$opp_maid=$postfeld['opp_mandant'];
		}
		
		$m2postfeld=$postfeld;
		if ($cfg_mboe_vorlagen) {
			if ($cfg_kfzsuche_tausenderpunkt and $cfg_nova_wltp) {
				$postfeld['listenpreis5']=str_replace('.', '', $postfeld['listenpreis5']);
			}
			if (preg_match('/,/', $postfeld['listenpreis5'])) {
				$postfeld['listenpreis5']=str_replace(',', '.', $postfeld['listenpreis5']);
			}
			if ($cfg_kfzsuche_tausenderpunkt and $cfg_nova_wltp) {
				$postfeld['vertrag5_farbepreis']=str_replace('.', '', $postfeld['vertrag5_farbepreis']);
			}
			if (preg_match('/,/', $postfeld['vertrag5_farbepreis'])) {
				$postfeld['vertrag5_farbepreis']=str_replace(',', '.', $postfeld['vertrag5_farbepreis']);
			}
			if ($cfg_kfzsuche_tausenderpunkt and $cfg_nova_wltp) {
				$postfeld['vertrag5_trimpreis']=str_replace('.', '', $postfeld['vertrag5_trimpreis']);
			}
			if (preg_match('/,/', $postfeld['vertrag5_trimpreis'])) {
				$postfeld['vertrag5_trimpreis']=str_replace(',', '.', $postfeld['vertrag5_trimpreis']);
			}
		}
		$oppt1=oppkfz_text();
		$postfeld=$m2postfeld;
		
		if ($oppt1!='') {
			$ltext=$oppt1;
		}

		$opp_summe=$summe;
		if ($postfeld['vertrag_nwgw']=='1' and doubleval(str_replace(',', '.', $postfeld['fin_preis2']))>0) {
			$opp_summe=doubleval(str_replace(',', '.', $postfeld['fin_preis2']))+doubleval(str_replace(',', '.', $postfeld['vertrag_zulassung2']));
			$summe=$opp_summe;
		}
		
		if ($cfg_kfzsuche_levy and $kfz_fstatus=='Tageszulassung') {
			// TZ so lassen
		} else {
		
		if (isset($postfeld['gme_markencode'])) {
			$kfz_fstatus='Neufahrzeug - konfiguriert';
			if ($_SESSION['sprache']!='lang_de.php') {
				$kfz_fstatus=_VEHICLE_CONFIGURED_;
			}
		}
		if (isset($postfeld['vertrag_nwgw'])) {
			if ($postfeld['vertrag_nwgw']=='1') {
				$kfz_fstatus=_GEBRAUCHTFAHRZEUG_;
			}
		}
		if (isset($postfeld['vorlage_vfw'])) {
			$kfz_fstatus=_VORFUEHRFAHRZEUG_;
		}
		if (isset($postfeld['vorlage_gw'])) {
			$kfz_fstatus=_GEBRAUCHTFAHRZEUG_;
		}
		if ($kfz_fstatuscode=='6' or $kfz_fstatus=='Mietfahrzeug' or $kfz_fstatus=='Mietwagen') {
			$kfz_fstatus=_MIETFAHRZEUG_;
		}
		
		}// Ende Levy TZ
		
		$opp_marke1=$postfeld['gme_markencode'];
		if ($opp_marke1=='') {
			$opp_marke1=$postfeld['kfz_markencode'];
		}
		$opp_typ1=$postfeld['gme_typ_modell'];
		if ($opp_typ1=='') {
			$opp_typ1=$postfeld['kfz_typmodell'];
		}
		
		if (isset($postfeld['kfz_modellnr'])) {
			if ($postfeld['kfz_modellnr']!='') {
				$postfeld['kfz_typmodell'].=' ('.$postfeld['kfz_modellnr'].')';
			}
		}
		
		$gmemodnr='';
				if (isset($postfeld['gme_modellnr2'])) {
					$gmemodnr=$postfeld['gme_modellnr2'];
				}
				if ($gmemodnr=='') {
					$gmemodnr=$postfeld['gme_modellnr'];
				}
		$sqlt=array(
			$sql_tabs['opportunity']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
			$sql_tabs['opportunity']['mandant_id'] => $db->dbzahl($opp_maid),
			$sql_tabs['opportunity']['bezeichnung'] => $db->str(trim($bez_ang_kv)),//.' '.$postfeld['konf_typmodell']
			$sql_tabs['opportunity']['phase'] => $db->str($bez_ang_kv),
			$sql_tabs['opportunity']['ansprechpartner_id'] => $db->dbzahl($apid),
			$sql_tabs['opportunity']['produkt_id'] => $db->dbzahl($postfeld['pid']),
			$sql_tabs['opportunity']['art'] => $db->str(_OM_ART1_),
			$sql_tabs['opportunity']['quelle'] => $db->str(_OM_QUELLE9_),
			$sql_tabs['opportunity']['betrag'] => $db->dbzahl($opp_summe),
			$sql_tabs['opportunity']['betrag_ist'] => $db->dbzahl(0),
			$sql_tabs['opportunity']['schlusstermin'] => $db->dbdate(adodb_date('d.m.Y', time()+14*24*60*60)),
			$sql_tabs['opportunity']['ws_eintritt'] => $db->dbzahl(0),
			$sql_tabs['opportunity']['bemerkung'] => $db->str($ltext),
			$sql_tabs['opportunity']['benutzer_id'] => $db->dbzahl($ang_kv_user),
			$sql_tabs['opportunity']['benutzer_eintrag'] => $db->dbzahl($_SESSION['user_id']),
			$sql_tabs['opportunity']['prioritaet'] => $db->dbzahl(0),
			$sql_tabs['opportunity']['zusatz6'] => $db->str($postfeld['vertrag_finart']),
			$sql_tabs['opportunity']['markencode'] => $db->str($opp_marke1),
			$sql_tabs['opportunity']['typ_modell'] => $db->str($opp_typ1),
			$sql_tabs['opportunity']['fahrzeugmodellnr'] => $db->str($gmemodnr),
			$sql_tabs['opportunity']['angebot_details'] => $db->str($ltext2),
			$sql_tabs['opportunity']['konfigurator_id'] => $db->dbzahl($postfeld['gme_konf_id']),
			$sql_tabs['opportunity']['fahrzeugstatus'] => $db->str($kfz_fstatus),
			$sql_tabs['opportunity']['kampagne_id'] => $db->dbzahl($kampa_id)
		);
		if (isset($sql_tabs['opportunity']['konfigurator_id2'])) {
			$sqlt[$sql_tabs['opportunity']['konfigurator_id2']]=$db->dbzahl($postfeld['konf_dmskonfid']);
		}
		if (isset($sql_tabs['opportunity']['lagerort_id'])) {
			$sqlt[$sql_tabs['opportunity']['lagerort_id']]=$db->dbzahl($lago_id);
		}
		$sqlt[$sql_tabs['opportunity']['datum_eintrag']]=$db->dbtimestamp(time());
		if ($cfg_kfzsuche_zusatzdatum_kvdatum and $postfeld['zusatzdatum1']!='') {
			$sqlt[$sql_tabs['opportunity']['datum_eintrag']]=$db->dbtimestamp($postfeld['zusatzdatum1'], adodb_date('H', time()), adodb_date('i', time()), 0);
		}
		if (isset($postfeld['co_stid'])) {
			if (intval($postfeld['co_stid'])>0) {
				$sqlt[$sql_tabs['opportunity']['stammdaten_id2']]=$db->dbzahl($postfeld['co_stid']);
			}
		}
		if (isset($postfeld['anzahl_potkv'])) {
			$sqlt[$sql_tabs['opportunity']['zusatzzahl1']]=$db->dbzahl($postfeld['anzahl_potkv']);
		} elseif ($cfg_nl_potentialoffers) {
			$sqlt[$sql_tabs['opportunity']['zusatzzahl1']]=$db->dbzahl(1);
		}
		if (isset($postfeld['kfzvertriebskanal'])) {
			if ($postfeld['kfzvertriebskanal']!='-1' && $postfeld['kfzvertriebskanal']!='') {
				$sqlt[$sql_tabs['opportunity']['zusatz4']]=$db->str($postfeld['kfzvertriebskanal']);
			}
		}
		
		$liefert=time();
				if (isset($postfeld['vertrag_liefertermin']) and $postfeld['vertrag_liefertermin']!='') {
					$datum_lt=$postfeld['vertrag_liefertermin'];
					$liefert=adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_lt,3,2),p4n_mb_string('substr',$datum_lt,0,2),p4n_mb_string('substr',$datum_lt,6,4) );
				} elseif (isset($postfeld['vertrag_liefertermin1monat'])) {
					$liefert=adodb_mktime(12,0,0, $postfeld['vertrag_liefertermin1monat'], 1, $postfeld['vertrag_liefertermin2']);
				} elseif (isset($postfeld['vertrag_liefertermin1'])) {
					$lwoche=trim($postfeld['vertrag_liefertermin1']);
					if (p4n_mb_string('strlen',$lwoche)==1) {
						$lwoche='0'.$lwoche;
					}
					$liefert=strtotime($postfeld['vertrag_liefertermin2'].'W'.$lwoche);
				}
		$sqlt[$sql_tabs['opportunity']['zusatzdatum2']]=$db->dbtimestamp($liefert);
		$lieft_text=$postfeld['vertrag_liefertermin'];
		if ($lieft_text=='') {
			$lwoche=trim($postfeld['vertrag_liefertermin1']);
			if (p4n_mb_string('strlen',$lwoche)==1) {
				$lwoche='0'.$lwoche;
			}
			$lieft_text=$postfeld['vertrag_liefertermin2'].'W'.$lwoche;
			if ($cfg_kfzsuche_liefertermin_monatjahr) {
				$lieft_text=$postfeld['vertrag_liefertermin1monat'].'/'.$postfeld['vertrag_liefertermin2'];
			}
		}
		$sqlt[$sql_tabs['opportunity']['rabatt_bezeichnung']]=$db->str($lieft_text);
		
		$merke_nachl_proz_sum=0;
		$merke_nachl_betrag_sum=0;
		for ($auss_i=1; $auss_i<=50; $auss_i++) {
					if (isset($postfeld['vertrag'.$ve_zus.'_sonderrppreis'.$auss_i])) {
						$nl_p1=doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrppreis'.$auss_i]));
						$merke_nachl_proz_sum+=$nl_p1;
					}
					if (isset($postfeld['vertrag'.$ve_zus.'_sonderrpreis'.$auss_i])) {
						$nl_p1=doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrpreis'.$auss_i]));
						$merke_nachl_betrag_sum+=$nl_p1;
					}
		}
		$sqlt[$sql_tabs['opportunity']['rabatt_prozent']]=$db->dbzahl($merke_nachl_proz_sum);
		$sqlt[$sql_tabs['opportunity']['rabatt_betrag']]=$db->dbzahl($merke_nachl_betrag_sum);
		
		if ($cfg_kfzsuche_zahldetails and isset($sql_tabs['opportunity']['zahlung_abloese'])) {
			$sqlt[$sql_tabs['opportunity']['zahlung_abloese']]=$db->dbzahl(doubleval(str_replace(',', '.', $postfeld['fin_abzug_abloese'])));
		}
		$kfeld_pc=array();
        $werte_aus_pc=array();
		if (!$vorschau) {

		$anr=0;

		if ($bez_ang_kv==_ANGEBOT_) {

			$anzahl_kv_kopie=0;
			if (isset($postfeld['anzahl_kv'])) {
				if (intval($postfeld['anzahl_kv'])>1) {
					$anzahl_kv_kopie=intval($postfeld['anzahl_kv'])-1;
				}
			}
			if ($_SESSION['cfg_kunde'] === 'carlo_koltes') {
                $sqlt[$sql_tabs['opportunity']['ws_eintritt']] = $db->dbzahl(25);
            }

			$res3=$db->select(
				$sql_tab['opportunity'],
				$sql_tabs['opportunity']['opportunity_id'],
				$sql_tabs['opportunity']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
					$sql_tabs['opportunity']['produkt_id'].'='.$db->dbzahl($postfeld['pid']).' and '.
					$sql_tabs['opportunity']['konfigurator_id'].'='.$db->dbzahl($postfeld['gme_konf_id'])
			);
			if (1 or $db->anzahl($res3)==0) {
				$res3=$db->insert(
					$sql_tab['opportunity'],
					$sqlt
				);
				$anr=$db->insertid($res3);
			} else {
				$row3=$db->zeile($res3);
				$res3=$db->update(
					$sql_tab['opportunity'],
					$sqlt,
					$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($row3[0])
				);
				$anr=$row3[0];

				$db->update(
					$sql_tab['korrespondenz'],
					array(
						$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true)
					),
					$sql_tabs['korrespondenz']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
						$sql_tabs['korrespondenz']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid']).' and ('.
						$sql_tabs['korrespondenz']['kategorie'].'='.$db->str(_ANGEBOT_).' or '.
						$sql_tabs['korrespondenz']['kategorie'].'='.$db->str(_ANGEBOT2_).')'
				);
			}
			
			if (isset($cfg_akv_addfields)) {
				$alle_f=$db->metacolumns($sql_tab['opportunity']);
				$alle_f2=array();
				while (list($key1, $val1)=@each($alle_f)) {
					$alle_f2[$val1->name]=1;
				}
				$sqlt2_af=array();
				@reset($cfg_akv_addfields);
				while (list($jkey, $jval)=@each($cfg_akv_addfields)) {
					if (!isset($alle_f2['addfield'.$jkey])) {
						$db->select2('alter table '.$sql_tab['opportunity'].' add addfield'.$jkey.' INTEGER');
					}
					if (isset($postfeld['addproduct'.$jkey])) {
						$anz_jf=intval($postfeld['addproduct_amount'.$jkey]);
						if ($anz_jf<0) {
							$anz_jf=0;
						}
						$sqlt2_af[$sql_tabs['opportunity']['addfield'.$jkey]]=$db->dbzahl($anz_jf);
					} else {
						$sqlt2_af[$sql_tabs['opportunity']['addfield'.$jkey]]=$db->dbzahl(0);
					}
				}
				if (count($sqlt2_af)>0) {
					$db->update(
						$sql_tab['opportunity'],
						$sqlt2_af,
						$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
					);
					@reset($sqlt2_af);
					while (list($jkey, $jval)=@each($sqlt2_af)) {
						$sqlt[$jkey]=$jval;
					}
				}
			}
			if (!empty($cfg_fhd) && !empty($postfeld['fhd_id'])) {
                $refRep = new Interface_RefRepository('FHD');
                $ref = $refRep->getRefForOpportunity($anr);
                if (empty($ref['extern_id'])) {
                    $ref['extern_id'] = $postfeld['fhd_id'];
                    $ref->save();
                }
            }
			
			if (intval($postfeld['kbezug'])>0) {
				$par_kat='';
				$res3=$db->select(
					$sql_tab['korrespondenz'],
					array(
						$sql_tabs['korrespondenz']['opportunity_id'],
						$sql_tabs['korrespondenz']['kategorie']
					),
					$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($postfeld['kbezug'])
				);
				if ($row3=$db->zeile($res3)) {
					$par_id_opp=$row3[0];
					$par_kat=$row3[1];
				}
				if ($cfg_kfzsuche_angebot_angebot_verloren and $par_kat==_ANGEBOT_ and intval($par_id_opp)>0) {
					$db->update(
						$sql_tab['opportunity'],
						array(
							$sql_tabs['opportunity']['phase'] => $db->str(_OM_ANDERESANGEBOT_)
						),
						$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($par_id_opp)
					);
					$db->update(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_OM_ANDERESANGEBOT_)
							),
							$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($par_id_opp)
					);
				}
			}
			
		} elseif ($bez_ang_kv==_KAUFVERTRAG_) {
			
			$phase_opp=_OM_PHASE7_;
			if ($cfg_kfzsuche_kvunbestaetigt) {
				$phase_opp='Geschlossen und unbest�tigt';
			}
			
			if ($cfg_kfzsuche_kvunbestaetigt and $cfg_kaufvertrag_aendern_geschlgewonnen_vkl) {
						$ist_vkloderadmin=false;
						if ($_SESSION['user_gruppe']==2) {
							$ist_vkloderadmin=true;
						}
						$res7=$db->select(
							$sql_tab['benutzer_gruppe'],
							array(
								$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
								$sql_tabs['benutzer_gruppe']['bezeichnung']
							),
							$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('VK-Leiter').' or '.$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('Verkaufsleiter').' or '.$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('Voditelj prodaje')
						);
						if ($row7=$db->zeile($res7)) {
							if (preg_match('/,'.$row7[0].',/', ','.$_SESSION['rechte_bgruppen'].',')) {
								$ist_vkloderadmin=true;
							}
						}
						if ($ist_vkloderadmin) {
							$phase_opp=_OM_PHASE7_;
							$cfg_kfzsuche_kvunbestaetigt=false;
						}
			}
			
			if (intval($postfeld['kbezug'])>0) {
				$par_kat='';
				$res3=$db->select(
					$sql_tab['korrespondenz'],
					array(
						$sql_tabs['korrespondenz']['opportunity_id'],
						$sql_tabs['korrespondenz']['kategorie']
					),
					$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($postfeld['kbezug'])
				);
				if ($row3=$db->zeile($res3)) {
					$par_id_opp=$row3[0];
					$par_kat=$row3[1];
					$anr=$par_id_opp;
					$postfeld['opp_id']=$anr;
				}
				if ($cfg_kaufvertrag_aendern and $par_kat==_KAUFVERTRAG_ and $cfg_kaufvertrag_aendern_ueberschreiben) {
					$db->update(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['kategorie'] => $db->str(_KAUFVERTRAG_.' '._ALT_.' - '._AENDERUNG_),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_KAUFVERTRAG_.' '._ALT_.' - '._AENDERUNG_),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str(_KAUFVERTRAG_.' '._ALT_.' - '._AENDERUNG_),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['opportunity_id'] => $db->dbzahl(0)
							),
							$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($postfeld['kbezug'])
					);
					if ($cfg_kfzsuche_kvunbestaetigt) {
						$db->update(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl($postfeld['pid'])
							),
							$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($par_id_opp).' and '.
								$sql_tabs['korrespondenz']['kategorie'].'='.$db->str(_KALENDER_BESTAETIGUNG_)
						);
					}
				}
				if ($cfg_kaufvertrag_aendern and $par_kat==_KAUFVERTRAG_ and !$cfg_kaufvertrag_aendern_ueberschreiben) {
					if ($cfg_kaufvertrag_aendern_ueberschreiben) {
						
					} else {
						$db->delete(
							$sql_tab['opportunity'],
							$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($par_id_opp)
						);
						$res3=$db->select(
							$sql_tab['produktzuordnung_konfiguration'],
							$sql_tabs['produktzuordnung_konfiguration']['produktzuordnung_konfiguration_id'],
							$sql_tabs['produktzuordnung_konfiguration']['opportunity_id'].'='.$db->dbzahl($par_id_opp)
						);
						if ($row3=$db->zeile($res3)) {
							$db->delete(
								$sql_tab['produktzuordnung_konfiguration_option'],
								$sql_tabs['produktzuordnung_konfiguration_option']['produktzuordnung_konfiguration_id'].'='.$db->dbzahl($row3[0])
							);
						}
						$db->delete(
							$sql_tab['produktzuordnung_konfiguration'],
							$sql_tabs['produktzuordnung_konfiguration']['opportunity_id'].'='.$db->dbzahl($par_id_opp)
						);
						$db->update(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['kategorie'] => $db->str(_KAUFVERTRAG_.' '._ALT_.' - '._AENDERUNG_),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_KAUFVERTRAG_.' '._ALT_.' - '._AENDERUNG_),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str(_KAUFVERTRAG_.' '._ALT_.' - '._AENDERUNG_),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['opportunity_id'] => $db->dbzahl(0)
							),
							$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($postfeld['kbezug'])
						);
					}
					if ($cfg_kfzsuche_kvunbestaetigt) {
						$db->update(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str('KV abgelehnt wegen KV-�nderung'),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str('KV abgelehnt'),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time())
							),
							$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($par_id_opp).' and '.
								$sql_tabs['korrespondenz']['kategorie'].'='.$db->str(_KALENDER_BESTAETIGUNG_)
						);
					}
					$db->update(
						$sql_tab['korrespondenz'],
						array(
							$sql_tabs['korrespondenz']['opportunity_id'] => $db->dbzahl(0)
						),
						$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($par_id_opp)
					);
					$postfeld['kbezug']=0;
					$par_id_opp=0;
					$anr=0;
					$postfeld['opp_id']=0;
				}
			}

			if (intval($postfeld['opp_id'])<=0 and (intval($postfeld['pid'])>0 or intval($postfeld['gme_konf_id'])>0)) {
				$res3=$db->select(
					$sql_tab['opportunity'],
					$sql_tabs['opportunity']['opportunity_id'],
					$sql_tabs['opportunity']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
						$sql_tabs['opportunity']['produkt_id'].'='.$db->dbzahl($postfeld['pid']).' and '.
						$sql_tabs['opportunity']['konfigurator_id'].'='.$db->dbzahl($postfeld['gme_konf_id']).' and '.
						$sql_tabs['opportunity']['phase'].'!='.$db->str(_OM_PHASE7_).' and '.
						$sql_tabs['opportunity']['phase'].'!='.$db->str($phase_opp).' and '.
						$sql_tabs['opportunity']['phase'].'!='.$db->str(_OM_PHASE8_).' and '.
						$sql_tabs['opportunity']['phase'].'!='.$db->str(_OM_ANDERESANGEBOT_).' and '.
						$sql_tabs['opportunity']['phase'].'!='.$db->str(_OM_ANDERERKUNDE_),
					$sql_tabs['opportunity']['datum_eintrag'].' desc'
				);
				if ($row3=$db->zeile($res3)) {
					$postfeld['opp_id']=$row3[0];
				}
			}
			
			if (intval($postfeld['opp_id'])>0) {
				$res3=$db->update(
					$sql_tab['opportunity'],
					$sqlt,
					$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($postfeld['opp_id'])
				);
			}
			
			if (isset($postfeld['aang_schl2'])) {
				$res6=$db->select(
					$sql_tab['opportunity'],
					$sql_tabs['opportunity']['opportunity_id'],
					$sql_tabs['opportunity']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
						$sql_tabs['opportunity']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id']).' and '.
						$sql_tabs['opportunity']['opportunity_id'].'!='.$db->dbzahl($postfeld['opp_id']).' and ('.
						$sql_tabs['opportunity']['phase'].'='.$db->str(_ANGEBOT_).' or '.
						$sql_tabs['opportunity']['phase'].'='.$db->str(_KTYP4_).' or '.
						$sql_tabs['opportunity']['phase'].'='.$db->str(_PROBEFAHRT_).' or '.
						$sql_tabs['opportunity']['phase'].'='.$db->str('Geschlossen und unbest�tigt').' or '.
						$sql_tabs['opportunity']['phase'].'='.$db->str(_NACHFASSEN_).')'
				);
				while ($row6=$db->zeile($res6)) {
					$db->update(
						$sql_tab['opportunity'],
						array(
							$sql_tabs['opportunity']['phase'] => $db->str(_OM_ANDERESANGEBOT_)
						),
						$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($row6[0])
					);
					if (!$cfg_kfzsuche_kv_korroffen) {
						$db->update(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_OM_ANDERESANGEBOT_)
							),
							$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($row6[0])
						);
					} else {
						schliesse_andere_korr_pid($row6[0]);
					}
				}
			}
			
			if (intval($postfeld['pid'])>0) {
				
				if (isset($postfeld['aang_schl'])) {	// nur noch schlie�en, wenn Haken gesetzt
				$res6=$db->select(
					$sql_tab['opportunity'],
					$sql_tabs['opportunity']['opportunity_id'],
					$sql_tabs['opportunity']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
						$sql_tabs['opportunity']['produkt_id'].'='.$db->dbzahl($postfeld['pid']).' and '.
						$sql_tabs['opportunity']['opportunity_id'].'!='.$db->dbzahl($postfeld['opp_id'])
				);
				while ($row6=$db->zeile($res6)) {
					$db->update(
						$sql_tab['opportunity'],
						array(
							$sql_tabs['opportunity']['phase'] => $db->str(_OM_ANDERESANGEBOT_)
						),
						$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($row6[0])
					);
					if (!$cfg_kfzsuche_kv_korroffen) {
						$db->update(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_OM_ANDERESANGEBOT_)
							),
							$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($row6[0])
						);
					} else {
						schliesse_andere_korr_pid($row6[0]);
					}
				}
				}
				
				// Mail an PF aus Zukunft:
				if ($_SESSION['crm_version']>64) {
					$cfg_kfzsuche_mailkv_pfzukunft=true;
				}
				if ($cfg_kfzsuche_mailkv_pfzukunft) {
					$res6=$db->select(
						$sql_tab['korrespondenz'],
						array(
							$sql_tabs['korrespondenz']['korrespondenz_id'],
							$sql_tabs['korrespondenz']['datum'],
							$sql_tabs['korrespondenz']['stammdaten_id'],
							$sql_tabs['korrespondenz']['betreuer_id']
						),
						$sql_tabs['korrespondenz']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid']).' and '.
							$sql_tabs['korrespondenz']['kategorie'].'='.$db->str(_PROBEFAHRT_).' and '.
							$sql_tabs['korrespondenz']['erledigt'].'='.$db->dblogic(false).' and '.
							$sql_tabs['korrespondenz']['datum'].'>='.$db->dbtimestamp(time())
					);
					while ($row6=$db->zeile($res6)) {
						$res7=$db->select(
							$sql_tab['benutzer'],
							$sql_tabs['benutzer']['email'],
							$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row6[3])
						);
						if ($row7=$db->zeile($res7)) {
							if ($row7[0]!='') {
								include_once("mailconf.php");
								$abse='CRM';
								if ($_SESSION['user_email']!='') {
									$abse=$_SESSION['user_email'];
								} elseif ($mcs_pop3_email!='') {
									$abse=$mcs_pop3_email;
								}
								$mail->ClearAllRecipients();
								$mail->ClearAttachments();
								$mail->From     = $abse;
								$mail->FromName = 'CRM';
								$mail->IsHTML(false);
								$mail->Subject  = _KAUFVERTRAG_.' '.$pid_bez2;
								$mail->AddAddress($row7[0]);
								$mailt=_KV_PF_EMAIL_."\n\n"._FAHRZEUG_.': '.$pid_bez2.' / '.$fgnr."\n\n"._KUNDE_.': '.kundenbezeichnung($row6[2]).' ('.$row6[2].')'."\n\n"._DATUM_.' '._PROBEFAHRT_.': '.$db->unixdatetime($row6[1])."\n\n"._BENUTZER_.': '.$_SESSION['mitarbeiter_name2'];
								$mail->Body = $mailt;
								$okv=$mail->Send();
								if ($fp2=fopen('inc/'.$_SESSION['cfg_kunde'].'/maillog.txt', 'a')) {
									fwrite($fp2, adodb_date('d.m.Y H:i:s', time()).': '.$row7[0].' '.($okv?_OK_:_FEHLER_).' - '._FAHRZEUG_.' PF: '.$pid_bez2.' / '.$fgnr.' / '._KUNDE_.': '.kundenbezeichnung($row6[2]).' ('.$row6[2].') / '._BENUTZER_.': '.$_SESSION['mitarbeiter_name2']."\r\n");
									fclose($fp2);
								}
							}
						}
					}
				}
				
				if ($cfg_internerfahrer_pfakv_email or $_SESSION['crm_version']>64) {
					$res6=$db->select(
						$sql_tab['produktzuordnung'],
						array(
							$sql_tabs['produktzuordnung']['interner_fahrer']
						),
						$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
					);
					if ($row6=$db->zeile($res6)) {
						if (intval($row6[0])>0) {
						$res7=$db->select(
							$sql_tab['benutzer'],
							$sql_tabs['benutzer']['email'],
							$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row6[0])
						);
						if ($row7=$db->zeile($res7)) {
							if ($row7[0]!='') {
								include_once("mailconf.php");
								$abse='CRM';
								if ($_SESSION['user_email']!='') {
									$abse=$_SESSION['user_email'];
								} elseif ($mcs_pop3_email!='') {
									$abse=$mcs_pop3_email;
								}
								$mail->ClearAllRecipients();
								$mail->ClearAttachments();
								$mail->From     = $abse;
								$mail->FromName = 'CRM';
								$mail->IsHTML(false);
								$mail->Subject  = _KAUFVERTRAG_.' '.$pid_bez2;
								$mail->AddAddress($row7[0]);
								$mailt=_KV_INTFAHRER_EMAIL_."\n\n"._FAHRZEUG_.': '.$pid_bez2.' / '.$fgnr."\n\n"._BENUTZER_.': '.$_SESSION['mitarbeiter_name2'];
								$mail->Body = $mailt;
								$okv=$mail->Send();
								if ($fp2=fopen('inc/'.$_SESSION['cfg_kunde'].'/maillog.txt', 'a')) {
									fwrite($fp2, adodb_date('d.m.Y H:i:s', time()).': '.$row7[0].' '.($okv?_OK_:_FEHLER_).' - '._FAHRZEUG_.' KV int. Fahrer: '.$pid_bez2.' / '.$fgnr.' / '._BENUTZER_.': '.$_SESSION['mitarbeiter_name2']."\r\n");
									fclose($fp2);
								}
							}
						}
						}
					}
				}
				
				if ($cfg_leadmanagement_2020) {
					$res6=$db->select(
						$sql_tab['kampagne_lead'],
						array(
							$sql_tabs['kampagne_lead']['kampagne_lead_id'],
							$sql_tabs['kampagne_lead']['benutzer_id'],
							$sql_tabs['kampagne_lead']['stammdaten_id'],
							$sql_tabs['kampagne_lead']['leadid']
						),
						$sql_tabs['kampagne_lead']['stammdaten_id'].'!='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
							$sql_tabs['kampagne_lead']['status'].'!='.$db->str('5').' and '.
							$sql_tabs['kampagne_lead']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
					);
					while ($row6=$db->zeile($res6)) {
						// Mail versenden:
						$res7=$db->select(
							$sql_tab['benutzer'],
							$sql_tabs['benutzer']['email'],
							$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row6[1])
						);
						if ($row7=$db->zeile($res7)) {
						if ($row7[0]!='') {
							include_once("mailconf.php");
							$abse='CRM';
							if ($_SESSION['user_email']!='') {
								$abse=$_SESSION['user_email'];
							} elseif ($mcs_pop3_email!='') {
								$abse=$mcs_pop3_email;
							}
							$mail->ClearAllRecipients();
							$mail->ClearAttachments();
							$mail->From     = $abse;
							$mail->FromName = 'CRM';
							$mail->IsHTML(false);
							$mail->Subject  = _KAUFVERTRAG_.' '.$pid_bez2;
							$mail->AddAddress($row7[0]);
							$mailt=_KV_LEAD_EMAIL_."\n\n"._LEAD_.': '.$row6[0].($row6[3]!=''?' / '.$row6[3]:'')."\n\n"._FAHRZEUG_.': '.$pid_bez2.' / '.$fgnr."\n\n"._KUNDE_.': '.kundenbezeichnung($row6[2]).' ('.$row6[2].')'."\n\n"._BENUTZER_.': '.$_SESSION['mitarbeiter_name2'];
							$mail->Body = $mailt;
							$okv=$mail->Send();
							if ($fp2=fopen('inc/'.$_SESSION['cfg_kunde'].'/maillog.txt', 'a')) {
								fwrite($fp2, adodb_date('d.m.Y H:i:s', time()).': '.$row7[0].' '.($okv?_OK_:_FEHLER_).' - '._FAHRZEUG_.': '.$pid_bez2.' / '.$fgnr.' / '._KUNDE_.': '.kundenbezeichnung($row6[2]).' ('.$row6[2].') / '._BENUTZER_.': '.$_SESSION['mitarbeiter_name2']."\r\n");
								fclose($fp2);
							}
							}
						}
					}
				}
				
				$res6=$db->select(
					$sql_tab['opportunity'],
					array(
						$sql_tabs['opportunity']['opportunity_id'],
						$sql_tabs['opportunity']['benutzer_id'],
						$sql_tabs['opportunity']['stammdaten_id']
					),
					$sql_tabs['opportunity']['stammdaten_id'].'!='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
						$sql_tabs['opportunity']['phase'].'='.$db->str(_ANGEBOT_).' and '.
						$sql_tabs['opportunity']['produkt_id'].'='.$db->dbzahl($postfeld['pid']).' and '.
						$sql_tabs['opportunity']['opportunity_id'].'!='.$db->dbzahl($postfeld['opp_id'])
				);
				while ($row6=$db->zeile($res6)) {
					// Mail versenden:
					$res7=$db->select(
						$sql_tab['benutzer'],
						$sql_tabs['benutzer']['email'],
						$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row6[1])
					);
					if ($row7=$db->zeile($res7)) {
						if ($row7[0]!='') {
							include_once("mailconf.php");
							$abse='CRM';
							if ($_SESSION['user_email']!='') {
								$abse=$_SESSION['user_email'];
							} elseif ($mcs_pop3_email!='') {
								$abse=$mcs_pop3_email;
							}
							$mail->ClearAllRecipients();
							$mail->ClearAttachments();
							$mail->From     = $abse;
							$mail->FromName = 'CRM';
							$mail->IsHTML(false);
							$mail->Subject  = _KAUFVERTRAG_.' '.$pid_bez2;
							$mail->AddAddress($row7[0]);
							$mailt=_KV_ANG_EMAIL_."\n\n"._FAHRZEUG_.': '.$pid_bez2.' / '.$fgnr."\n\n"._KUNDE_.': '.kundenbezeichnung($row6[2]).' ('.$row6[2].')'."\n\n"._BENUTZER_.': '.$_SESSION['mitarbeiter_name2'];
							$mail->Body = $mailt;
							$okv=$mail->Send();
							if ($fp2=fopen('inc/'.$_SESSION['cfg_kunde'].'/maillog.txt', 'a')) {
								fwrite($fp2, adodb_date('d.m.Y H:i:s', time()).': '.$row7[0].' '.($okv?_OK_:_FEHLER_).' - '._FAHRZEUG_.': '.$pid_bez2.' / '.$fgnr.' / '._KUNDE_.': '.kundenbezeichnung($row6[2]).' ('.$row6[2].') / '._BENUTZER_.': '.$_SESSION['mitarbeiter_name2']."\r\n");
								fclose($fp2);
							}
						}
					}

					$db->update(
						$sql_tab['opportunity'],
						array(
							$sql_tabs['opportunity']['phase'] => $db->str(_OM_ANDERERKUNDE_)
						),
						$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($row6[0])
					);
					if (!$cfg_kfzsuche_kv_korroffen) {
						$res9=$db->select(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['korrespondenz_id'],
								$sql_tabs['korrespondenz']['lead_id']
							),
							$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($row6[0])
						);
						while ($row9=$db->zeile($res9)) {
							if (intval($row9[1])>0) {
								Plugin_System_LeadTracker::updateStageFromLead($row9[1], 7);
							}
							$db->update(
								$sql_tab['korrespondenz'],
								array(
									$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
									$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
									$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str(_OM_ANDERERKUNDE_),
									$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_OM_ANDERERKUNDE_)
								),
								$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($row9[0])
								//$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($row6[0])
							);
						}
					} else {
						schliesse_andere_korr_pid($row6[0]);
					}
				}
			}
			if (intval($postfeld['gme_konf_id'])>0) {
				if (isset($postfeld['aang_schl'])) {	// nur noch schlie�en, wenn Haken gesetzt
				$res6=$db->select(
					$sql_tab['opportunity'],
					$sql_tabs['opportunity']['opportunity_id'],
					$sql_tabs['opportunity']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
						$sql_tabs['opportunity']['konfigurator_id'].'='.$db->dbzahl($postfeld['gme_konf_id']).' and '.
						$sql_tabs['opportunity']['opportunity_id'].'!='.$db->dbzahl($postfeld['opp_id']).' and '.
						$sql_tabs['opportunity']['phase'].'!='.$db->str(_OM_PHASE7_).' and '.
						$sql_tabs['opportunity']['phase'].'!='.$db->str($phase_opp).' and '.
						$sql_tabs['opportunity']['phase'].'!='.$db->str(_OM_PHASE8_).' and '.
						$sql_tabs['opportunity']['phase'].'!='.$db->str(_OM_ANDERESANGEBOT_).' and '.
						$sql_tabs['opportunity']['phase'].'!='.$db->str(_OM_ANDERERKUNDE_)
				);
				while ($row6=$db->zeile($res6)) {
					$db->update(
						$sql_tab['opportunity'],
						array(
							$sql_tabs['opportunity']['phase'] => $db->str(_OM_ANDERESANGEBOT_)
						),
						$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($row6[0])
					);
					if (!$cfg_kfzsuche_kv_korroffen) {
						$db->update(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_OM_ANDERESANGEBOT_)
							),
							$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($row6[0])
						);
					} else {
						schliesse_andere_korr_pid($row6[0]);
					}
				}
				}
			}
			
			$anzahl_kv_kopie=0;
			if (isset($postfeld['anzahl_kv'])) {
				if (intval($postfeld['anzahl_kv'])>1) {
					$anzahl_kv_kopie=intval($postfeld['anzahl_kv'])-1;
				}
			}
			if ($bez_ang_kv=='Vorvertragsinformation') {
				$anr=0;
			} elseif (isset($postfeld['opp_id']) and intval($postfeld['opp_id'])>0) {
				$db->update(
					$sql_tab['opportunity'],
					array(
						$sql_tabs['opportunity']['phase'] => $db->str($phase_opp),
						$sql_tabs['opportunity']['ws_eintritt'] => $db->dbzahl(100),
						$sql_tabs['opportunity']['betrag_ist'] => $db->dbzahl($summe),
						$sql_tabs['opportunity']['schlusstermin'] => $db->dbtimestamp(time()),
						$sql_tabs['opportunity']['bemerkung'] => $db->str($ltext),
						$sql_tabs['opportunity']['benutzer_id'] => $db->dbzahl($ang_kv_user),
						$sql_tabs['opportunity']['kampagne_id'] => $db->dbzahl($kampa_id)
					),
					$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($postfeld['opp_id'])
				);
				$anr=$postfeld['opp_id'];
			} else {
				$sqlt[$sql_tabs['opportunity']['datum_eintrag']]=$db->dbtimestamp(time());
				if ($cfg_kfzsuche_zusatzdatum_kvdatum and $postfeld['zusatzdatum1']!='') {
					$sqlt[$sql_tabs['opportunity']['datum_eintrag']]=$db->dbtimestamp($postfeld['zusatzdatum1'], adodb_date('H', time()), adodb_date('i', time()), 0);
				}
				$sqlt[$sql_tabs['opportunity']['phase']]=$db->str($phase_opp);
				$sqlt[$sql_tabs['opportunity']['ws_eintritt']]=$db->dbzahl(100);
				$sqlt[$sql_tabs['opportunity']['betrag_ist']]=$db->dbzahl($summe);
				$sqlt[$sql_tabs['opportunity']['schlusstermin']]=$db->dbtimestamp(time());
				$sqlt[$sql_tabs['opportunity']['kampagne_id']]=$db->dbzahl($kampa_id);

				$res3=$db->insert(
					$sql_tab['opportunity'],
					$sqlt
				);
				$anr=$db->insertid($res3);
			}

            if (!empty($cfg_fhd) && !empty($postfeld['fhd_id'])) {
                PearAutoLoader::instance()->addSourceRoot( 'inc/services' );
                try {
                    $offerSoldRes = FHD::instance($cfg_fhd)->offerSold($anr, $postfeld['fhd_id']);
                } catch (Exception $e) {
                    echo javas('alert("'._FEHLER_.' FHD! \n'.$e->getMessage().'");');
                }
            }

			if (!empty($cfg_eautoseller) && empty($cfg_kfzsuche_verkauftbutton)) {
                try {
                    if (empty($postfeld['kfz_fahrgestell'])) {
                        throw new Exception(str_replace('{abfrage_feld}', _FAHRGESTELLNUMMER_, _KFZPFLEGE_ABFRAGE_TEXT_));
                    }
                    $price = intval($postfeld['vertrag5_hauspreis']);
                    Ebewerter::instance()->setSold($postfeld['kfz_fahrgestell'], ($price ? $price : 1));
                } catch (Exception $e) {
                    $eError = 'Ebewerter: '.$e->getMessage();
                    echo javas('alert(\''.addslashes($eError).'\')');
                }
            }

			if ($cfg_mboe_vorlagen) {
				$kommnrneu=$retailer_prefix*10000000+intval($anr);
				$db->update(
					$sql_tab['opportunity'],
					array(
						$sql_tabs['opportunity']['quote_id'] => $db->str($kommnrneu)
					),
					$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
				);
			}

			// uses bezahl api
			$bezahl_order_data = false;
			if ( ! empty( $cfg_api_bezahl ) ) {
				$bz_price = $summe;
				if ( $postfeld['vertrag_nwgw'] == '8' ) {
					$bz_price = $postfeld['vertrag5_hauspreis'];
				}
				try {
					PearAutoLoader::instance()->addSourceRoot( 'inc/services' );
					$bezahl_api = Bezahl::instance();
					$b_params   = array(
						"name"       => "Order product ID: " . $postfeld['pid'],
						"price"      => $bz_price * 100, //Inhouse price in cents
						"pickupdate" => date( 'Y-m-d', time() ),
						"reminder"   => "1d",
						"unique"     => $anr . '/' . $postfeld['pid'] . '/' . $_SESSION['stammdaten_id'] . '/' . time(),
					);
					if ( isset( $postfeld['email'] ) && ! empty( $postfeld['email'] ) && filter_var( $postfeld['email'], FILTER_VALIDATE_EMAIL ) ) {
						$b_params["recipient"] = $postfeld['email'];
					}
					if ( isset( $_SESSION['user_email'] ) && ! empty( $_SESSION['user_email'] ) && filter_var( $_SESSION['user_email'], FILTER_VALIDATE_EMAIL ) ) {
						$b_params["contactperson"] = $_SESSION['user_email'];
					}
					$bezahl_id = $bezahl_api->createOrder( $b_params );
					$bezahl_api->linkingOrderId( $anr, $bezahl_id );
					$bezahl_order_data = $bezahl_api->getOrder( $bezahl_id );
					if ( ! isset( $bezahl_order_data['accountData']['viban'] ) ) {
						$bezahl_order_data = false;
						// TODO ask about it
						// die('Can not get Virtual IBAN ');
					}
				} catch ( \Exeption $e ) {
					die( $e->getMessage() );
				}
			}

			if (isset($cfg_akv_addfields)) {
				$alle_f=$db->metacolumns($sql_tab['opportunity']);
				$alle_f2=array();
				while (list($key1, $val1)=@each($alle_f)) {
					$alle_f2[$val1->name]=1;
				}
				$sqlt2_af=array();
				@reset($cfg_akv_addfields);
				while (list($jkey, $jval)=@each($cfg_akv_addfields)) {
					if (!isset($alle_f2['addfield'.$jkey])) {
						$db->select2('alter table '.$sql_tab['opportunity'].' add addfield'.$jkey.' INTEGER');
					}
					if (isset($postfeld['addproduct'.$jkey])) {
						$anz_jf=intval($postfeld['addproduct_amount'.$jkey]);
						if ($anz_jf<0) {
							$anz_jf=0;
						}
						$sqlt2_af[$sql_tabs['opportunity']['addfield'.$jkey]]=$db->dbzahl($anz_jf);
					} else {
						$sqlt2_af[$sql_tabs['opportunity']['addfield'.$jkey]]=$db->dbzahl(0);
					}
				}
				if (count($sqlt2_af)>0) {
					$db->update(
						$sql_tab['opportunity'],
						$sqlt2_af,
						$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
					);
					@reset($sqlt2_af);
					while (list($jkey, $jval)=@each($sqlt2_af)) {
						$sqlt[$jkey]=$jval;
					}
				}
			}
			
			if ($cfg_kfzsuche_kvunbestaetigt) {
				$korrbestid=0;
				$kampa_id_kvb=kamp_insert_kfzsuche('KV Best�tigung');
				$res3=$db->select(
					$sql_tab['kampagne_kategorie'],
					$sql_tabs['kampagne_kategorie']['kampagne_kategorie_id'],
					$sql_tabs['kampagne_kategorie']['kampagne_id'].'='.$db->dbzahl($kampa_id_kvb).' and '.
						$sql_tabs['kampagne_kategorie']['bezeichnung'].'='.$db->str(_KALENDER_BESTAETIGUNG_)
				);
				if ($db->anzahl($res3)==0) {
					$db->insert(
						$sql_tab['kampagne_kategorie'],
						array(
							$sql_tabs['kampagne_kategorie']['rang'] => $db->dbzahl(1),
							$sql_tabs['kampagne_kategorie']['art'] => $db->dbzahl(1),
							$sql_tabs['kampagne_kategorie']['als_standard'] => $db->dblogic(true),
							$sql_tabs['kampagne_kategorie']['kampagne_id'] => $db->dbzahl($kampa_id_kvb),
							$sql_tabs['kampagne_kategorie']['bezeichnung'] => $db->str(_KALENDER_BESTAETIGUNG_)
						)
					);
					$katerg1=$db->insertid();
				} else {
					$row3=$db->zeile($res3);
					$katerg1=$row3[0];
					$db->update(
						$sql_tab['kampagne_kategorie'],
						array(
							$sql_tabs['kampagne_kategorie']['bezeichnung'] => $db->str(_KALENDER_BESTAETIGUNG_)
						),
						$sql_tabs['kampagne_kategorie']['kampagne_kategorie_id'].'='.$db->dbzahl($katerg1)
					);
				}
				$res3=$db->select(
					$sql_tab['kampagne_kategorie_ergebnis'],
					$sql_tabs['kampagne_kategorie_ergebnis']['kampagne_kategorie_ergebnis_id'],
					$sql_tabs['kampagne_kategorie_ergebnis']['kampagne_kategorie_id'].'='.$db->dbzahl($katerg1).' and '.
						$sql_tabs['kampagne_kategorie_ergebnis']['bezeichnung'].'='.$db->str('KV best�tigt')
				);
				if ($db->anzahl($res3)==0) {
					$db->insert(
						$sql_tab['kampagne_kategorie_ergebnis'],
						array(
							$sql_tabs['kampagne_kategorie_ergebnis']['rang'] => $db->dbzahl(1),
							$sql_tabs['kampagne_kategorie_ergebnis']['kampagne_kategorie_id'] => $db->dbzahl($katerg1),
							$sql_tabs['kampagne_kategorie_ergebnis']['bezeichnung'] => $db->str('KV best�tigt')
						)
					);
				}
				$res3=$db->select(
					$sql_tab['kampagne_kategorie_ergebnis'],
					$sql_tabs['kampagne_kategorie_ergebnis']['kampagne_kategorie_ergebnis_id'],
					$sql_tabs['kampagne_kategorie_ergebnis']['kampagne_kategorie_id'].'='.$db->dbzahl($katerg1).' and '.
						$sql_tabs['kampagne_kategorie_ergebnis']['bezeichnung'].'='.$db->str('KV abgelehnt')
				);
				if ($db->anzahl($res3)==0) {
					$db->insert(
						$sql_tab['kampagne_kategorie_ergebnis'],
						array(
							$sql_tabs['kampagne_kategorie_ergebnis']['rang'] => $db->dbzahl(2),
							$sql_tabs['kampagne_kategorie_ergebnis']['kampagne_kategorie_id'] => $db->dbzahl($katerg1),
							$sql_tabs['kampagne_kategorie_ergebnis']['bezeichnung'] => $db->str('KV abgelehnt')
						)
					);
				}
				$keinwvleintr=false;
				if ($cfg_kaufvertrag_aendern and $par_kat==_KAUFVERTRAG_ and $cfg_kaufvertrag_aendern_ueberschreiben) {
					$res3=$db->select(
						$sql_tab['korrespondenz'],
						$sql_tabs['korrespondenz']['korrespondenz_id'],
						$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($anr).' and '.
							$sql_tabs['korrespondenz']['betreff'].'='.$db->str(_KAUFVERTRAG_.' '._KALENDER_BESTAETIGUNG_).' and '.
							$sql_tabs['korrespondenz']['erledigt'].'='.$db->dblogic(false)
					);
					if ($row3=$db->zeile($res3)) {
						$keinwvleintr=true;
					}
				}
				if (!$keinwvleintr) {
                    /*$kfeld2u=array(
                        $sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
                        $sql_tabs['korrespondenz']['wvl_datum1'] => $db->dbtimestamp(time()+24*60*60),
                        $sql_tabs['korrespondenz']['wvl_datum2'] => 0,
                        $sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
                        $sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
                        $sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($ang_kv_user),
                        $sql_tabs['korrespondenz']['eingang'] => 0,
                        $sql_tabs['korrespondenz']['art'] => $db->dbzahl(14),
                        $sql_tabs['korrespondenz']['kategorie'] => $db->str(_KALENDER_BESTAETIGUNG_),
                        $sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(false),
                        $sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl(0),
                        $sql_tabs['korrespondenz']['doclink'] => $db->str(''),
                        $sql_tabs['korrespondenz']['betreff'] => $db->str(_KAUFVERTRAG_.' '._KALENDER_BESTAETIGUNG_),
                        $sql_tabs['korrespondenz']['beschreibung'] => $db->str($ltext),
                        $sql_tabs['korrespondenz']['zusatz1'] => $db->str(''),
                        $sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl(0),
                        $sql_tabs['korrespondenz']['papierkorb'] => 0,
                        $sql_tabs['korrespondenz']['kalender_id'] => 0,
                        $sql_tabs['korrespondenz']['prioritaet'] => 0,
                        $sql_tabs['korrespondenz']['negativ'] => 0,
                        $sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
                        $sql_tabs['korrespondenz']['formular_nr'] => $db->dbzahl(0),
                        $sql_tabs['korrespondenz']['formular_id'] => $db->dbzahl(0),
                        $sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl($kampa_id_kvb),
                        $sql_tabs['korrespondenz']['opportunity_id'] => $db->dbzahl($anr),
                        $sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl(0)
                    );
					$db->insert(
						$sql_tab['korrespondenz'],
						$kfeld2u
					);
					$korrbestid=$db->insertid();*/
                    $corr = new Correspondence_Data();
                    if (intval($postfeld['kbezug']) > 0) {
                        $corr['korrespondenz_id'] = intval($postfeld['kbezug']);
                        $corr->load();
                        $corr['korrespondenz_id'] = null;
                    } else {
                        $corr['produktzuordnung_id'] = 0;
                    }
                    $corr['datum'] = time();
                    $corr['wvl_datum1'] = time() + 24*60*60;
                    $corr['wvl_datum2'] = 0;
                    $corr['stammdaten_id'] = $_SESSION['stammdaten_id'];
                    $corr['ersteller_id'] = $_SESSION['user_id'];
                    $corr['betreuer_id'] = $ang_kv_user;
                    $corr['eingang'] = 0;
                    $corr['art'] = 14;
                    $corr['kategorie'] = _KALENDER_BESTAETIGUNG_;
                    $corr['erledigt'] = false;
                    $corr['parent_id'] = 0;
                    $corr['doclink'] = '';
                    $corr['betreff'] = _KAUFVERTRAG_.' '._KALENDER_BESTAETIGUNG_;
                    $corr['beschreibung'] = $ltext;
                    $corr['zusatz1'] = '';
                    $corr['papierkorb'] = 0;
                    $corr['kalender_id'] = 0;
                    $corr['prioritaet'] = 0;
                    $corr['negativ'] = 0;
                    $corr['leitfaden_id'] = 0;
                    $corr['formular_nr'] = 0;
                    $corr['formular_id'] = 0;
                    $corr['kampagne_id'] = $kampa_id_kvb;
                    $corr['opportunity_id'] = $anr;
                    $corr->save();
                    $korrbestid = $db->insertid();
				}
			}
			
			if (($cfg_profitcalc or $cfg_kfzsuche_kalkulation) && defined('_NLPROFITCALC_')) {
					$res3=$db->select(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['datum'],
								$sql_tabs['korrespondenz']['doclink'],
								$sql_tabs['korrespondenz']['betreff'],
								$sql_tabs['korrespondenz']['kategorie'],
								$sql_tabs['korrespondenz']['korrespondenz_id'],
								$sql_tabs['korrespondenz']['betreuer_id'],
								$sql_tabs['korrespondenz']['lead_id'],
								$sql_tabs['korrespondenz']['quelle'],
								$sql_tabs['korrespondenz']['beschreibung'],
								$sql_tabs['korrespondenz']['zusatz1']
							),
							$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($anr).' and '.
								$sql_tabs['korrespondenz']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
								$sql_tabs['korrespondenz']['kategorie'].' like '.$db->str(_NLPROFITCALC_.'%'),
							$sql_tabs['korrespondenz']['datum'].' desc'
					);
					if ($row3=$db->zeile($res3)) {
						$xpl=explode('#####', $row3[9]);
						@reset($xpl);
						while (list($keyx, $valx)=@each($xpl)) {
							$xpl2=explode('===', $valx);
							if (count($xpl2)==2) {
								if ($xpl2[0]=='inrl_van' or $xpl2[0]=='inrl_van2' or $xpl2[0]=='inr1_p' or $xpl2[0]=='inr2_p' or $xpl2[0]=='inr1_taxp' or $xpl2[0]=='inr2_taxp' or substr($xpl2[0], 0, 21)=='netto_vertrag5_sonder' or substr($xpl2[0], 0, 15)=='vertrag5_sonder' or substr($xpl2[0], 0, 6)=='profit' or preg_match('/zuscost/', $xpl2[0]) or preg_match('/zusbonus/', $xpl2[0]) or preg_match('/bonussubpro/', $xpl2[0])) {
									$werte_aus_pc[$xpl2[0]]=$xpl2[1];
								}
							}
						}
						$hat_wapc=array();
						$ltext2_neu='';
						$xpl=explode('#####', $ltext2);
						while (list($keyx, $valx)=@each($xpl)) {
							$xpl2=explode('===', $valx);
							if (count($xpl2)==2) {
								if (isset($werte_aus_pc[$xpl2[0]])) {
									$ltext2_neu.=$xpl2[0].'==='.$werte_aus_pc[$xpl2[0]].'#####';
									$hat_wapc[$xpl2[0]]=1;
								} else {
									$ltext2_neu.=$valx.'#####';
								}
							} else {
								$ltext2_neu.=$valx.'#####';
							}
						}
						@reset($werte_aus_pc);
						while (list($keyx, $valx)=@each($werte_aus_pc)) {
							if (!isset($hat_wapc[$xpl2[0]])) {
								$ltext2_neu.=$keyx.'==='.$valx.'#####';
							}
						}
						$kfeld_pc=array(
								$sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp($db->unixdate_ts($row3[0])),
								$sql_tabs['korrespondenz']['wvl_datum1'] => 0,
								$sql_tabs['korrespondenz']['wvl_datum2'] => 0,
								$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
								$sql_tabs['korrespondenz']['ansprechpartner_id'] => $db->dbzahl($apid),
								$sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
								$sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($row3[5]),
								$sql_tabs['korrespondenz']['eingang'] => 0,
								$sql_tabs['korrespondenz']['art'] => $db->dbzahl(11),
								$sql_tabs['korrespondenz']['kategorie'] => $db->str(_NLPROFITCALC_.($cfg_kfzsuche_levy?'':' '.$bez_ang_kv)),
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
								$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($parid_k),
								$sql_tabs['korrespondenz']['doclink'] => $db->str($row3[1]),
								$sql_tabs['korrespondenz']['betreff'] => $db->str(_NLPROFITCALC_.($cfg_kfzsuche_levy?'':' '.$bez_ang_kv)),
								$sql_tabs['korrespondenz']['beschreibung'] => $db->str($ltext),
								$sql_tabs['korrespondenz']['zusatz1'] => $db->str($ltext2_neu),
								$sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl($postfeld['pid']),
								$sql_tabs['korrespondenz']['papierkorb'] => 0,
								$sql_tabs['korrespondenz']['kalender_id'] => 0,
								$sql_tabs['korrespondenz']['prioritaet'] => 0,
								$sql_tabs['korrespondenz']['negativ'] => 0,
								$sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_nr'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(($kamp_id>0?$kamp_id:$kampa_id)),
								$sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl($row3[6]),
								$sql_tabs['korrespondenz']['quelle'] => $db->str($row3[7]),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_NLPROFITCALC_.' '.$bez_ang_kv),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str(_NLPROFITCALC_.($cfg_kfzsuche_levy?'':' '.$bez_ang_kv)),
								$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($row3[5]),
								$sql_tabs['korrespondenz']['opportunity_id'] => $db->dbzahl($anr)
						);
					}
			}
			
			$zus_anr=array();
			$kvkopids='';
			for ($akv_i=0; $akv_i<$anzahl_kv_kopie; $akv_i++) {
				$sqlt[$sql_tabs['opportunity']['datum_eintrag']]=$db->dbtimestamp(time());
				if ($cfg_kfzsuche_zusatzdatum_kvdatum and $postfeld['zusatzdatum1']!='') {
					$sqlt[$sql_tabs['opportunity']['datum_eintrag']]=$db->dbtimestamp($postfeld['zusatzdatum1'], adodb_date('H', time()), adodb_date('i', time()), 0);
				}
				$sqlt[$sql_tabs['opportunity']['phase']]=$db->str($phase_opp);
				$sqlt[$sql_tabs['opportunity']['ws_eintritt']]=$db->dbzahl(100);
				$sqlt[$sql_tabs['opportunity']['betrag_ist']]=$db->dbzahl($summe);
				$sqlt[$sql_tabs['opportunity']['schlusstermin']]=$db->dbtimestamp(time());
				$sqlt[$sql_tabs['opportunity']['kampagne_id']]=$db->dbzahl($kampa_id);
				$res3=$db->insert(
					$sql_tab['opportunity'],
					$sqlt
				);
				$zus_anr[$akv_i]=$db->insertid($res3);
				$kvkopids.=$zus_anr[$akv_i].', ';
			}
			
			if ($cfg_kfzsuche_kvunbestaetigt and $kvkopids!='' and intval($korrbestid)>0) {
				$kvkopids=substr($kvkopids, 0, -2);
				$ltextzus=_KOPIE_.' '._KAUFVERTRAG_.': '.count($zus_anr).' ('.$kvkopids.')'."\n";
				$res9=$db->select(
					$sql_tab['korrespondenz'],
					$sql_tabs['korrespondenz']['beschreibung'],
					$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($korrbestid)
				);
				if ($row9=$db->zeile($res9)) {
					$db->update(
						$sql_tab['korrespondenz'],
						array(
							$sql_tabs['korrespondenz']['beschreibung'] => $db->str($ltextzus.$row9[0])
						),
						$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($korrbestid)
					);
				}
			}
			
			$db->update(
					$sql_tab['korrespondenz'],
					array(
						$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true)
					),
					$sql_tabs['korrespondenz']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
						$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($anr).' and '.
						$sql_tabs['korrespondenz']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid']).' and ('.
						$sql_tabs['korrespondenz']['kategorie'].'='.$db->str(_ANGEBOT_).' or '.
						$sql_tabs['korrespondenz']['kategorie'].'='.$db->str(_ANGEBOT2_).')'
			);

		}
		} // Ende keine Vorschau
		
        if ($cfg_user_placeholder && class_exists('Placeholder_Main')) {
            $inhalt = Placeholder_Main::instance()->init()->replace($inhalt, $postfeld);
        }
		
		$m_docx_bild2='';
		if ($cfg_kfzsuche_markenlogo) {
			$logo_t='';
			if (is_file('dokumente/marke_logo/'.$postfeld['kfz_markencode'].'_p4nscl.jpg')) {
				$bildinh2=bin2hex(file_get_contents('dokumente/marke_logo/'.$postfeld['kfz_markencode'].'_p4nscl.jpg'));
				$m_docx_bild2=file_get_contents('dokumente/marke_logo/'.$postfeld['kfz_markencode'].'_p4nscl.jpg');
				$logoproz=15;
				if (isset($cfg_kfzsuche_markenlogo_proz) and intval($cfg_kfzsuche_markenlogo_proz)>0) {
					$logoproz=$cfg_kfzsuche_markenlogo_proz;
				}
				if ($ist_docx) {
					list($width_orig, $height_orig)=getimagesize('dokumente/marke_logo/'.$postfeld['kfz_markencode'].'_p4nscl.jpg');
					$inhalt=p4n_sb_strreplace('<<logo>>', '<w:pict><v:shape id="_x0000_i1026" style="width:'.(round($width_orig*$logoproz/100)).'pt;height:'.(round($height_orig*$logoproz/100)).'pt" type="#_x0000_t75"><v:imagedata o:title="" r:id="rId2p4n"/></v:shape></w:pict>', $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<logo>>', '{\\pict \\picscalex'.$logoproz.'\\picscaley'.$logoproz.'\\jpegblip '.$bildinh2.' } ', $inhalt);
				}
			}
		}
		$inhalt=p4n_sb_strreplace('<<logo>>', '', $inhalt);
		if ($cfg_mandanten_bilder) {
			$id_mand=0;
			$kopffussproz=30;
			if (isset($cfg_kfzsuche_kopffuss_prozent)) {
				$kopffussproz=$cfg_kfzsuche_kopffuss_prozent;
			}
			$zielb='dokumente/mandant_images/'.$postfeld['vertrag_lagerort'].'_1.jpg';
			if (!is_file($zielb)) {
				$res4=$db->select(
					$sql_tab['mandant'],
					$sql_tabs['mandant']['parent_id'],
					$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($postfeld['vertrag_lagerort'])
				);
				if ($row4=$db->zeile($res4)) {
					$zielb='dokumente/mandant_images/'.$row4[0].'_1.jpg';
				}
			}
			if (is_file($zielb)) {
				$bildinh2=bin2hex(file_get_contents($zielb));
			//	$m_docx_bild2=file_get_contents('dokumente/marke_logo/'.$postfeld['kfz_markencode'].'_p4nscl.jpg');
				if ($ist_docx) {
			//		list($width_orig, $height_orig)=getimagesize('dokumente/marke_logo/'.$postfeld['kfz_markencode'].'_p4nscl.jpg');
			//		$inhalt=p4n_sb_strreplace('<<logo>>', '<w:pict><v:shape id="_x0000_i1026" style="width:'.(round($width_orig*$logoproz/100)).'pt;height:'.(round($height_orig*$logoproz/100)).'pt" type="#_x0000_t75"><v:imagedata o:title="" r:id="rId2p4n"/></v:shape></w:pict>', $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<kopfbild>>', '{\\pict \\picscalex'.$kopffussproz.'\\picscaley'.$kopffussproz.'\\jpegblip '.$bildinh2.' } ', $inhalt);
				}
			}
			$inhalt=p4n_sb_strreplace('<<kopfbild>>', '', $inhalt);
			
			$zielb='dokumente/mandant_images/'.$postfeld['vertrag_lagerort'].'_2.jpg';
			if (!is_file($zielb)) {
				$res4=$db->select(
					$sql_tab['mandant'],
					$sql_tabs['mandant']['parent_id'],
					$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($postfeld['vertrag_lagerort'])
				);
				if ($row4=$db->zeile($res4)) {
					$zielb='dokumente/mandant_images/'.$row4[0].'_2.jpg';
				}
			}
			if (is_file($zielb)) {
				$bildinh2=bin2hex(file_get_contents($zielb));
			//	$m_docx_bild2=file_get_contents('dokumente/marke_logo/'.$postfeld['kfz_markencode'].'_p4nscl.jpg');
				if ($ist_docx) {
			//		list($width_orig, $height_orig)=getimagesize('dokumente/marke_logo/'.$postfeld['kfz_markencode'].'_p4nscl.jpg');
			//		$inhalt=p4n_sb_strreplace('<<logo>>', '<w:pict><v:shape id="_x0000_i1026" style="width:'.(round($width_orig*$logoproz/100)).'pt;height:'.(round($height_orig*$logoproz/100)).'pt" type="#_x0000_t75"><v:imagedata o:title="" r:id="rId2p4n"/></v:shape></w:pict>', $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<fussbild>>', '{\\pict \\picscalex'.$kopffussproz.'\\picscaley'.$kopffussproz.'\\jpegblip '.$bildinh2.' } ', $inhalt);
				}
			}
			$inhalt=p4n_sb_strreplace('<<fussbild>>', '', $inhalt);
		}
		
		if ($cfg_kfzsuche_levy) {
			if (isset($postfeld['bigdeal']) and is_file('inc/'.$_SESSION['cfg_kunde'].'/bigdeal.jpg')) {
				$bildinh2=bin2hex(file_get_contents('inc/'.$_SESSION['cfg_kunde'].'/bigdeal.jpg'));
				$inhalt=p4n_sb_strreplace('<<levydeal>>', '{\\pict \\picscalex'.$cfg_kfzsuche_levy_dealbildproz.'\\picscaley'.$cfg_kfzsuche_levy_dealbildproz.'\\jpegblip '.$bildinh2.' } ', $inhalt);
			}
			if (isset($postfeld['newdeal']) and is_file('inc/'.$_SESSION['cfg_kunde'].'/newdeal.jpg')) {
				$bildinh2=bin2hex(file_get_contents('inc/'.$_SESSION['cfg_kunde'].'/newdeal.jpg'));
				$inhalt=p4n_sb_strreplace('<<levydeal>>', '{\\pict \\picscalex'.$cfg_kfzsuche_levy_dealbildproz.'\\picscaley'.$cfg_kfzsuche_levy_dealbildproz.'\\jpegblip '.$bildinh2.' } ', $inhalt);
			}
			if (isset($postfeld['megadeal']) and is_file('inc/'.$_SESSION['cfg_kunde'].'/megadeal.jpg')) {
				$bildinh2=bin2hex(file_get_contents('inc/'.$_SESSION['cfg_kunde'].'/megadeal.jpg'));
				$inhalt=p4n_sb_strreplace('<<levydeal>>', '{\\pict \\picscalex'.$cfg_kfzsuche_levy_dealbildproz.'\\picscaley'.$cfg_kfzsuche_levy_dealbildproz.'\\jpegblip '.$bildinh2.' } ', $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<levydeal>>', '', $inhalt);
		}
		if (!isset($postfeld['preisa_d1'])) {
			$inhalt=p4n_sb_strreplace('<<nachlassprozent>>', '', $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<nachlassprozent>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrppreis1'])), 2, ",", ""), $inhalt);
		
		if ($bez_ang_kv2=='expose') {
			// {\field{\*\fldinst HYPERLINK "http://www.google.com/"}{\fldrslt http://www.google.com}}
			if (isset($cfg_dbrent_standort_kurz)) {
				if (!isset($cfg_dbrent_standort_kurz[trim($pid_standort)])) {
					$inhalt=p4n_sb_strreplace('<<dbautohauslink>>', '', $inhalt);
					$inhalt=preg_replace('/<<dblink_start>>.*<<dblink_ende>>/Uis', '', $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<dbautohauslink>>', '{\field{\*\fldinst HYPERLINK "https://www.dbautohaus.de/fahrzeuge/'.$cfg_dbrent_standort_kurz[trim($pid_standort)].'-'.$kfz_haendlerstatus.'"}{\fldrslt Link zum Fahrzeug}}', $inhalt);
					$inhalt=p4n_sb_strreplace('<<dblink_start>>', '', $inhalt);
					$inhalt=p4n_sb_strreplace('<<dblink_ende>>', '', $inhalt);
				}
			}
			$inhalt=p4n_sb_strreplace('<<dbautohauslink>>', '{\field{\*\fldinst HYPERLINK "https://www.dbautohaus.de/fahrzeuge/autos?fahrzeugid='.$kfz_haendlerstatus.'"}{\fldrslt Link zum Fahrzeug}}', $inhalt);
			if (intval($kfz_vkph)>0 and $postfeld['idstatus']=='Wiederverk�ufer' or $postfeld['idstatus']=='DB Mitarbeiter') {
				$kfz_vkp=doubleval($kfz_vkph)*(1+$cfg_mwst);
			}
			$inhalt=p4n_sb_strreplace('<<preis>>', number_format(doubleval($kfz_vkp), 0, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<co2>>', $kfz_co2, $inhalt);
			$inhalt=p4n_sb_strreplace('<<kombiniert>>', $kfz_verb_komb, $inhalt);
			$inhalt=p4n_sb_strreplace('<<refnr>>', $kfz_haendlerstatus, $inhalt);
			
			if (preg_match('/<<qrcode>>/Ui', $inhalt)) {
				if (!isset($cfg_kfzsuche_qrcodelink_preisinfo)) {
					$cfg_kfzsuche_qrcodelink_preisinfo='https://www.dbautohaus.de/fahrzeuge/autos?fahrzeugid=<<refnr>>';
					if (!isset($cfg_dbrent_standort_kurz[trim($pid_standort)])) {
						$inhalt=p4n_sb_strreplace('<<qrcode>>', '', $inhalt);
						$inhalt=preg_replace('/<<qr_start>>.*<<qr_ende>>/Uis', '', $inhalt);
						$cfg_kfzsuche_qrcodelink_preisinfo='';
					} elseif (isset($cfg_dbrent_standort_kurz)) {
						$cfg_kfzsuche_qrcodelink_preisinfo='https://www.dbautohaus.de/fahrzeuge/<<staokurz>>-<<refnr>>';
						$cfg_kfzsuche_qrcodelink_preisinfo=str_replace('<<staokurz>>', $cfg_dbrent_standort_kurz[trim($pid_standort)], $cfg_kfzsuche_qrcodelink_preisinfo);
						$inhalt=p4n_sb_strreplace('<<qr_start>>', '', $inhalt);
						$inhalt=p4n_sb_strreplace('<<qr_ende>>', '', $inhalt);
					}
				}
			if (is_file('inc/phpqrcode.php') and isset($cfg_kfzsuche_qrcodelink_preisinfo)) {
				include_once('inc/phpqrcode.php');
				$linkqr=$cfg_kfzsuche_qrcodelink_preisinfo;
				$linkqr=str_replace('<<fgnr>>', $fgnr, $linkqr);
				$linkqr=str_replace('<<refnr>>', $kfz_haendlerstatus, $linkqr);
				QRcode::jpg($linkqr, 'temp/_qr_'.$_SESSION['user_id'].'.jpg');
				if (is_file('temp/_qr_'.$_SESSION['user_id'].'.jpg')) {
					$bildinh=file_get_contents('temp/_qr_'.$_SESSION['user_id'].'.jpg');
					$bildinh2=bin2hex($bildinh);
				}
				$inhalt=p4n_sb_strreplace('<<qrcode>>', '{\\pict \\picscalex85\\picscaley85\\jpegblip '.$bildinh2.' } ', $inhalt);
				@unlink('temp/_qr_'.$_SESSION['user_id'].'.jpg');
			}
			}
			
			$verbr_i=0;
			$verbr_a=0;
			$verbr_k=0;
			$verbr_co=0;
			$kraftst1='';
			$diffbest=false;
			if ($kfz_fstatuscode=='30') {
				if (p4n_mb_string('strlen',$kfz_hersteller)>10) {
					include_once('webservice/nusoap.php');
					$client = new nusoap_client($cfg_dvs_ws, true);
					if ($cfg_dvs_fm) {
						$client->soap_defencoding = 'UTF-8';
					}
					$result2 = $client->call("getFahrzeug", dvsfm_para(array('DVSGWID' => trim($kfz_hersteller), 'WhichID' => 'F_UID'), "getFahrzeug"), dvsfm_ns());
					if (isset($result2['dvsFahrzeug'])) {
						$rval3=$result2['dvsFahrzeug'];
						
						$art_best=$rval3['Ankauf']['Art_Steuer'];	// D  oder R
						if ($art_best=='D') {
							$diffbest=true;
						}
						if (isset($rval3['AusstattungWiki'])) {
							$ausst_wiki=$rval3['AusstattungWiki'];
						}
						
						$kraftst1=$cfg_dvs_treibstoff[$rval3['Art_Treibstoff']];
						if (!empty($rval3['Attribute']['item'])) {
                            while (list($key2, $val2)=@each($rval3['Attribute']['item'])) {
                                $val2=$val2['value']['cFAttr'];
                                if ($val2['AttrName']=='Verbrauch_kombiniert') {
                                    $verbr_k=doubleval(str_replace(',', '.', $val2['AttrValue']));
                                }
                                if ($val2['AttrName']=='Verbrauch_Innerorts') {
                                    $verbr_i=doubleval(str_replace(',', '.', $val2['AttrValue']));
                                }
                                if ($val2['AttrName']=='Verbrauch_Ausserorts') {
                                    $verbr_a=doubleval(str_replace(',', '.', $val2['AttrValue']));
                                }
                                if ($val2['AttrName']=='CO2_Emission') {
                                    $verbr_co=doubleval(str_replace(',', '.', $val2['AttrValue']));
                                }
                            }
                        }
					}
				}
			}
			
			$preis_steuertext='inkl. MwSt.';
			if ($pid_istdiff or $diffbest) {
				$preis_steuertext='';
			}
			$inhalt=p4n_sb_strreplace('<<steuertext>>', $preis_steuertext, $inhalt);
			
			$alle_aus_anz=0;
			$block_vges='';
			if (preg_match_all("/<<start_v_block>>(.*)<<ende_v_block>>/Uis", $inhalt, $apblock, PREG_SET_ORDER)) {
				$block_k=$apblock[0][1];
			}
			$gruppe='';
			$block_k_neu='';
			$block_vges='';
			$aufz=' {\\listtext\\pard\\plain\\ltrpar \\s32 \\rtlch\\fcs1 \\af0\\afs20 \\ltrch\\fcs0 \\f3\\fs20\\cf1\\lang1031\\langfe1031\\langfenp1031\\insrsid15626544\\charrsid15626544 \\loch\\af3\\dbch\\af0\\hich\\f3 \\\'b7\\tab}';
			$aufz='';
			if ($ausst_wiki!='') {
			$xpl=explode("\\", $ausst_wiki);
			foreach($xpl as $vkey => $vval) {
				if (preg_match('/\*\*(.*)\*\*/', $vval, $match1)) {
					if ($alle_aus_anz>0) {
						$vumbr=round($alle_aus_anz/2);
						$xi=0;
						$vlinks='';
						$vrechts='';
						foreach ($alle_aus as $vkey => $vval) {
							if ($xi<$vumbr) {
								$vlinks.=$vval.'\\par ';
							} else {
								$vrechts.=$vval.'\\par ';
							}
							$xi++;
						}
						$vlinks=substr($vlinks, 0, -5);
						$vrechts=substr($vrechts, 0, -5);
						$block_k_neu=p4n_sb_strreplace('<<vaus1>>', $aufz.$vlinks, $block_k_neu);
						$block_k_neu=p4n_sb_strreplace('<<vaus2>>', $aufz.$vrechts, $block_k_neu);
						$block_vges.=$block_k_neu;
					}
					$gruppe=trim($match1[1]);
					$block_k_neu=$block_k;
					$block_k_neu=p4n_sb_strreplace('<<gruppe>>', $gruppe, $block_k_neu);
					if (preg_match_all("/<<start_v_aus>>(.*)<<ende_v_aus>>/Uis", $block_k_neu, $apblock2, PREG_SET_ORDER)) {
						$block_k2=$apblock2[0][1];
					}
					$alle_block_k2='';
					$anzvbl=0;
					$alle_aus=array();
					$alle_aus_anz=0;
				} elseif ($gruppe!='') {
					if (preg_match('/.*\* (.*)/', $vval, $match1)) {
						$vaus1=trim($match1[1]);
						$alle_aus_anz++;
						$alle_aus[]=$vaus1;
					}
				}
			}
			if ($alle_aus_anz>0) {
				$vumbr=round($alle_aus_anz/2);
				$xi=0;
				$vlinks='';
				$vrechts='';
				foreach ($alle_aus as $vkey => $vval) {
					if ($xi<$vumbr) {
						$vlinks.=$vval.'\\par ';
					} else {
						$vrechts.=$vval.'\\par ';
					}
					$xi++;
				}
				$vlinks=substr($vlinks, 0, -5);
				$vrechts=substr($vrechts, 0, -5);
				$block_k_neu=p4n_sb_strreplace('<<vaus1>>', $aufz.$vlinks, $block_k_neu);
				$block_k_neu=p4n_sb_strreplace('<<vaus2>>', $aufz.$vrechts, $block_k_neu);
				$block_vges.=$block_k_neu;
			}
			}
			$inhalt=preg_replace("/<<start_v_block>>.*<<ende_v_block>>/Uis", $block_vges, $inhalt);
			
			$kraftst=$kraftst1;
			if ($kraftst=='D') {
				$kraftst='Diesel';
			} elseif ($kraftst=='G' or $kraftst=='B') {
				$kraftst='Benzin';
			}
			$inhalt=p4n_sb_strreplace('<<kraftstoff>>', $kraftst, $inhalt);
			$inhalt=p4n_sb_strreplace('<<kraftstoffart>>', $kraftst, $inhalt);
			
			$vbr='';
			if (preg_match('/'._VERBRAUCH_.' '._GESAMT_.': ([\d,\.]+)/i', $ausst, $ma)) {
				$vbr=trim(trim($ma[1], ','));
			}
			if ($verbr_k>0) {
				$vbr=number_format(doubleval($verbr_k), 1, ",", "");
			}
			$inhalt=p4n_sb_strreplace('<<verbr_kombiniert>>', $vbr, $inhalt);
			$vbr='';
			if (preg_match('/'._SCHADSTOFF_.': ([\d,\.]+)/i', $ausst, $ma)) {
				$vbr=trim(trim($ma[1], ','));
				$vbr=intval(str_replace(',', '.', $vbr));
			}
			if ($verbr_co>0) {
				$vbr=number_format(doubleval($verbr_co), 0, ",", "");
			}
			$inhalt=p4n_sb_strreplace('<<verbr_schadstoff>>', $vbr, $inhalt);
			
			$ausstb1='';
			$ausstb2='';
			$expl=explode(',', $ausst);
			$iz=1;
			while (list($akey, $aval)=@each($expl)) {
				$aval=trim($aval);
				if ($iz<=14) {
					$ausstb1.=$aval.'\\par ';
				} elseif ($iz<=28) {
					$ausstb2.=$aval.'\\par ';
				}
				while (p4n_mb_string('strlen',$aval)>25) {
					$aval=p4n_mb_string('substr',$aval, 0, -25);
					$iz++;
				}
				$iz++;
			}
			if ($iz>=29) {
				$ausstb2.=_UVM_.'\\par ';
			}
			$ausstb1=p4n_mb_string('substr',$ausstb1, 0, -5);
			$ausstb2=p4n_mb_string('substr',$ausstb2, 0, -5);
			$ausstb1=str_replace('__KO__', ',', $ausstb1);
			$ausstb2=str_replace('__KO__', ',', $ausstb2);
			$inhalt=p4n_sb_strreplace('<<ausstattungb1>>', $ausstb1, $inhalt);
			$inhalt=p4n_sb_strreplace('<<ausstattungb2>>', $ausstb2, $inhalt);
			
			if (is_file('dokumente/user_images/'.$_SESSION['user_id'].'.jpg')) {
				$inhalt_benutzerbild=file_get_contents('dokumente/user_images/'.$_SESSION['user_id'].'.jpg');
			    list($userImage2_width, $userImage2_height) = getimagesize('dokumente/user_images/'.$_SESSION['user_id'].'.jpg');
				$inhalt=p4n_sb_strreplace('<<sig_bild>>', '{\\pict \\picscalex50\\picscaley50\\jpegblip '.bin2hex($inhalt_benutzerbild).' } ', $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<sig_bild>>', '', $inhalt);
		}
		
		if (isset($postfeld['bild_auswahl2']) and !isset($postfeld['bild_auswahl'])) {
			$postfeld['bild_auswahl']=$postfeld['bild_auswahl2'];
		}
		$m_docx_bild='';
		if (isset($postfeld['gme_foto']) and $postfeld['gme_foto']!='') {
			$bildinh=base64_decode($postfeld['gme_foto']);
			$m_docx_bild=$bildinh;
			$bildinh2=bin2hex($bildinh);
			if ($ist_docx) {
				$inhalt=p4n_sb_strreplace('<<bild1>>', '<w:pict><v:shape id="_x0000_i1026" style="width:128.25pt;height:53.25pt" type="#_x0000_t75"><v:imagedata o:title="" r:id="rIdp4n"/></v:shape></w:pict>', $inhalt);
			} else {
				$inhalt=p4n_sb_strreplace('<<bild1>>', '{\\pict \\picscalex70\\picscaley70\\jpegblip '.$bildinh2.' } ', $inhalt);
			}
		} elseif (isset($postfeld['bild_auswahl']) and $postfeld['bild_auswahl']!='') {
			if (is_file($postfeld['bild_auswahl'])) {
				if ($fp1=fopen($postfeld['bild_auswahl'], 'r')) {
					$bildinh=fread($fp1, filesize($postfeld['bild_auswahl']));
					fclose($fp1);
					$m_docx_bild=$bildinh;
					$bildinh2=bin2hex($bildinh);
					if ($ist_docx) {
						$inhalt=p4n_sb_strreplace('<<bild1>>', '<w:pict><v:shape id="_x0000_i1026" style="width:128.25pt;height:53.25pt" type="#_x0000_t75"><v:imagedata o:title="" r:id="rIdp4n"/></v:shape></w:pict>', $inhalt);
					} else {
						if ($bez_ang_kv2=='expose') {
							$inhalt=p4n_sb_strreplace('<<bild1>>', '{\\pict \\picscalex30\\picscaley30\\jpegblip '.$bildinh2.' } ', $inhalt);
						} else {
							$inhalt=p4n_sb_strreplace('<<bild1>>', '{\\pict \\picscalex70\\picscaley70\\jpegblip '.$bildinh2.' } ', $inhalt);
						}
					}
				}
			}
		} else {
			$bild_templ='';
			if (isset($sql_tab['kfzzuordnung']) and isset($sql_tabs['kfzzuordnung']['bild'])) {
				$gmemodnr='';
				if (isset($postfeld['gme_modellnr2'])) {
					$gmemodnr=$postfeld['gme_modellnr2'];
		}
				if ($gmemodnr=='') {
					$gmemodnr=$postfeld['gme_modellnr'];
				}
				$neben_gef=false;
				$bild_1='';
				if ($gmemodnr!='' and $postfeld['kfz_markencode']!='') {
					$sqltu=array(
							$sql_tabs['kfzzuordnung']['bild'],
							$sql_tabs['kfzzuordnung']['modellnr'],
							$sql_tabs['kfzzuordnung']['id']
					);
					$res4=$db->select(
						$sql_tab['kfzzuordnung'],
						$sqltu,
						$sql_tabs['kfzzuordnung']['markencode'].' like '.$db->str($postfeld['kfz_markencode'])
							.' and '.$sql_tabs['kfzzuordnung']['modellnr'].'!='.$db->str('')
					);
					while (!$neben_gef and $row4=$db->zeile($res4)) {
						$expl2=explode(',', $row4[1]);
						while (list($mkey, $mval)=@each($expl2)) {
							$mval=str_replace('%', '', $mval);
							if (p4n_mb_string('substr',$gmemodnr, 0, p4n_mb_string('strlen',$mval))==$mval) {
								$bild_1=$row4[0];
								$kfzzu_id=$row4[2];
								$neben_gef=true;
							}
						}
					}
				}
				if (!$neben_gef and $postfeld['kfz_typmodell']!='' and $postfeld['kfz_markencode']!='') {
					$typm2=$postfeld['kfz_typmodell'];
					$expl2=preg_split('/\W/', $typm2);
					$typm2=$expl2[0];
					$res4=$db->select(
						$sql_tab['kfzzuordnung'],
						array(
							$sql_tabs['kfzzuordnung']['bild'],
							$sql_tabs['kfzzuordnung']['id']
						),
						$sql_tabs['kfzzuordnung']['markencode'].' like '.$db->str($postfeld['kfz_markencode'])
							.' and '.$sql_tabs['kfzzuordnung']['typmodell'].' like '.$db->str($typm2.'%')
					);
					if ($row4=$db->zeile($res4)) {
						$bild_1=$row4[0];
						$kfzzu_id=$row4[1];
						$neben_gef=true;
					}
				}
				if ($bild_1!='' and is_file($bild_1)) {
					$bildinh2=bin2hex(file_get_contents($bild_1));
					$bild_templ='{\\pict \\jpegblip '.$bildinh2.' } ';
					$inhalt=p4n_sb_strreplace('<<bild1>>', $bild_templ, $inhalt);
					if ($bilder=='') {
						$bilder=$bild_templ;
					}
				}
			}
		}
        $konf_quelle='CARLO';
        if (isset($postfeld['freiekonf'])) {
            $konf_quelle=_FREIER_TYP_;
        }
        if (!empty($postfeld['konf_quelle'])) {
            $konf_quelle=$postfeld['konf_quelle'];
        }

		$inhalt=p4n_sb_strreplace('<<bild1>>', '', $inhalt);
		
		$bilder='';
			$bilder1='';
			$bilder2='';
			$bilder3='';
			$bilder4='';
			$b_i=0;
			if (isset($postfeld['auswahl_pi'])) {
				while (list($keya, $vala)=@each($postfeld['auswahl_pi'])) {
					if (is_file('dokumente/kfz_fotos/'.$postfeld['kfz_fahrgestell'].'/thumb/'.$keya)) {
						$bildinh2=bin2hex(file_get_contents('dokumente/kfz_fotos/'.$postfeld['kfz_fahrgestell'].'/thumb/'.$keya));
						$bilder.='{\\pict \\jpegblip '.$bildinh2.' } ';
						$bilder1.='{\\pict \\jpegblip '.$bildinh2.' }'.'\\par ';
						$bilder2.='{\\pict \\jpegblip '.$bildinh2.' } ';
						$bilder3.='{\\pict \\jpegblip '.$bildinh2.' } ';
						$bilder4.='{\\pict \\jpegblip '.$bildinh2.' } ';
						$b_i++;
						if (!($b_i % 2)) {
							$bilder2.='\\par ';
						}
						if (!($b_i % 3)) {
							$bilder3.='\\par ';
						}
						if (!($b_i % 4)) {
							$bilder4.='\\par ';
						}
					}
				}
			}
			
			$bild_templ='';
			$inhalt=p4n_sb_strreplace('<<bild>>', $bild_templ, $inhalt);
			$inhalt=p4n_sb_strreplace('<<bilder>>', $bilder, $inhalt);
			$inhalt=p4n_sb_strreplace('<<bilder1>>', $bilder1, $inhalt);
			$inhalt=p4n_sb_strreplace('<<bilder2>>', $bilder2, $inhalt);
			$inhalt=p4n_sb_strreplace('<<bilder3>>', $bilder3, $inhalt);
			$inhalt=p4n_sb_strreplace('<<bilder4>>', $bilder4, $inhalt);
			
		
		$inhalt=p4n_sb_strreplace('<<text_1>>', $kfz_t1, $inhalt);
		$inhalt=p4n_sb_strreplace('<<text_2>>', $kfz_t2, $inhalt);
		$inhalt=p4n_sb_strreplace('<<text_3>>', $kfz_t3, $inhalt);
		$inhalt=p4n_sb_strreplace('<<text_4>>', $kfz_t4, $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<kfz_ekp>>', number_format(doubleval($kfz_ekp), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<kfz_vkp>>', number_format(doubleval($kfz_vkp), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<cozwei>>', $kfz_co2, $inhalt);
		
		if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
			$ist_outlet=false;
			if (isset($postfeld['vertrag_fernabsatz'])) {
				$inhalt=p4n_sb_strreplace('<<outlethinweis>>', '', $inhalt);
			}
			if ($postfeld['idstatus']=='Wiederverk�ufer') {
				$inhalt=p4n_sb_strreplace('<<dbkfzstatus>>', 'H�ndlergesch�ft', $inhalt);
				$inhalt=p4n_sb_strreplace('<<outlethinweis>>', '', $inhalt);
			} else {
				$inhalt=p4n_sb_strreplace('<<dbkfzstatus>>', $postfeld['db_fahrzeugstatus'], $inhalt);
				if ($postfeld['db_fahrzeugstatus']=='Outlet' or $postfeld['db_fahrzeugstatus']=='XXL Outlet') {
					$ist_outlet=true;
				}
			}
			if ($cfg_db_kaufrecht2022) {
				if ($postfeld['db_fahrzeugstatus']=='Outlet' or $postfeld['db_fahrzeugstatus']=='XXL Outlet') {
					$inhalt=p4n_sb_strreplace('<<outlethinweis>>', $cfg_kfzsuche_ph_outlet, $inhalt);
					if (isset($postfeld['vertrag_fernabsatz'])) {
						$inhalt=p4n_sb_strreplace('<<fernabsatz_outlethinweis>>', $cfg_kfzsuche_ph_outlet_fernabsatz, $inhalt);
					}
				} else {
					$inhalt=p4n_sb_strreplace('<<outlethinweis>>', '', $inhalt);
				}
			}
			if (isset($postfeld['dvs_id']) and isset($kfzfeld['Status'])) {
				if ($kfzfeld['Status']=='20' or $kfzfeld['Status']=='26') {
					$ist_outlet=true;
				}
			}
			if ($ist_outlet or $pid_zusatzcode_1=='Outlet' or $pid_zusatzcode_1=='XXL Outlet') {
				$inhalt=p4n_sb_strreplace('<<outlethinweis>>', $cfg_kfzsuche_ph_outlet, $inhalt);
				if (isset($postfeld['vertrag_fernabsatz'])) {
					$inhalt=p4n_sb_strreplace('<<fernabsatz_outlethinweis>>', $cfg_kfzsuche_ph_outlet_fernabsatz, $inhalt);
				}
			} else {
				$inhalt=p4n_sb_strreplace('<<outlethinweis>>', '', $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<fernabsatz_outlethinweis>>', '', $inhalt);
			
			if ($cfg_db_kaufrecht2022) {
				
				$stlao_ort='';
				if (isset($postfeld['db_standortdrucken'])) {
					if ($postfeld['db_standortdrucken']=='1') {
						if (intval($_SESSION['user_standard_lagerort'])>0) {
							$res5=$db->select(
								$sql_tab['mandant'],
								array(
									$sql_tabs['mandant']['bezeichnung'],
									$sql_tabs['mandant']['firma'],
									$sql_tabs['mandant']['ort']
								),
								$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($_SESSION['user_standard_lagerort'])
							);
							if ($row5=$db->zeile($res5)) {
								$stlao_ort=$row5[2].' '.adodb_date('d.m.Y', time());
							}
						}
					}
				}
				$inhalt=p4n_sb_strreplace('<<db_standort>>', $stlao_ort, $inhalt);
				
				if ($pid_vmlinie=='6') {
					$inhalt=p4n_sb_strreplace('<<db_vm6_1>>', '', $inhalt);
					$inhalt=p4n_sb_strreplace('<<db_vm6_2>>', '', $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<db_vm6_1>>', $cfg_db_vm6_nicht_ph1, $inhalt);
				$inhalt=p4n_sb_strreplace('<<db_vm6_2>>', $cfg_db_vm6_nicht_ph2, $inhalt);
				
				if ($postfeld['db_fahrzeugstatus']=='Nutzer�bernahme') {
					$inhalt=p4n_sb_strreplace('<<db_nutzeruebernahme>>', $cfg_db_nutzeruebernahme, $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<db_nutzeruebernahme>>', '', $inhalt);
				if ($postfeld['idstatus']=='DB Mitarbeiter' or $postfeld['idstatus']=='privat') {
					if ($postfeld['db_fahrzeugstatus']=='Premium') {
						$inhalt=p4n_sb_strreplace('<<db_wartung_hinweis>>', $cfg_db_1154_1_premium, $inhalt);
					}
					if ($postfeld['db_fahrzeugstatus']=='Quality' or $postfeld['db_fahrzeugstatus']=='Outlet' or $postfeld['db_fahrzeugstatus']=='XXL Outlet') {
						$inhalt=p4n_sb_strreplace('<<db_wartung_hinweis>>', $cfg_db_1154_2_qualityoutlet, $inhalt);
					}
					$inhalt=p4n_sb_strreplace('<<db_wartung_hinweis>>', '', $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<db_wartung_hinweis>>', '', $inhalt);
				}
				
				if ($postfeld['idstatus']=='gewerblich') {
					$inhalt=p4n_sb_strreplace('<<db_gewerblich>>', $cfg_db_1145_gewerblich, $inhalt);
				}
				if ($postfeld['idstatus']=='Wiederverk�ufer') {
					$inhalt=p4n_sb_strreplace('<<db_wiederverk>>', $cfg_db_1145_wiederverk, $inhalt);
				}
				
				$inhalt=p4n_sb_strreplace('<<db_gewerblich>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<db_wiederverk>>', '', $inhalt);
			}
		}
		
		if ($vorschau) {
			if (!isset($cfg_kfzsuche_vorschautext)) {
				$cfg_kfzsuche_vorschautext=_VORSCHAU_;
			}
			if (isset($cfg_kfzsuche_vorschautext) and $cfg_kfzsuche_vorschautext!='') {
				$inhalt=p4n_sb_strreplace('<<vorschau>>', $cfg_kfzsuche_vorschautext, $inhalt);
			} else {
				$inhalt=p4n_sb_strreplace('<<vorschau>>', '', $inhalt);
			}
		} else {
			$inhalt=p4n_sb_strreplace('<<vorschau>>', '', $inhalt);
		}
		
		if ($_SESSION['cfg_kunde']=='carlo_opel_auto-team') {
			$inhalt=p4n_sb_strreplace('<<bezahlung>>', $postfeld['extra_bezahlung'], $inhalt);
		}
		
//		$inhalt=p4n_sb_strreplace('<<anr>>', $postfeld['stid'].'-'.$anr, $inhalt);

		$kdnr1='';
		$intnr1='';
		if (intval($postfeld['stid'])>0) {
			if (isset($postfeld['lagerort']) or $manda_id>0) {
				$res3=$db->select(
					$sql_tab['stammdaten_mandant'],
					$sql_tabs['stammdaten_mandant']['nummer1'],
					$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid']).' and '.
					$sql_tabs['stammdaten_mandant']['mandant_id'].'='.$db->dbzahl($manda_id).' and '.
						$sql_tabs['stammdaten_mandant']['nummer1'].'!='.$db->str('')
				);
				if ($row3=$db->zeile($res3)) {
					$kdnr1=$row3[0];
				}
			}
			if ($kdnr1=='') {
				$res3=$db->select(
					$sql_tab['stammdaten_mandant'],
					$sql_tabs['stammdaten_mandant']['nummer1'],
					$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid']).' and '.
						$sql_tabs['stammdaten_mandant']['nummer1'].'!='.$db->str('')
				);
				if ($row3=$db->zeile($res3)) {
					$kdnr1=$row3[0];
				}
			}
			if (isset($postfeld['lagerort']) or $manda_id>0) {
				$res3=$db->select(
					$sql_tab['stammdaten_mandant'],
					$sql_tabs['stammdaten_mandant']['nummer2'],
					$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid']).' and '.
					$sql_tabs['stammdaten_mandant']['mandant_id'].'='.$db->dbzahl($manda_id).' and '.
						$sql_tabs['stammdaten_mandant']['nummer2'].'!='.$db->str('')
				);
				if ($row3=$db->zeile($res3)) {
					$intnr1=$row3[0];
				}
			}
			if ($intnr1=='') {
				$res3=$db->select(
					$sql_tab['stammdaten_mandant'],
					$sql_tabs['stammdaten_mandant']['nummer2'],
					$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid']).' and '.
						$sql_tabs['stammdaten_mandant']['nummer2'].'!='.$db->str('')
				);
				if ($row3=$db->zeile($res3)) {
					$intnr1=$row3[0];
				}
			}
		}
		if ($_SESSION['cfg_kunde']=='carlo_koltes' or $_SESSION['cfg_kunde']=='carlo_opel_dello') {
			$inhalt=p4n_sb_strreplace('<<kundennr>>', $postfeld['stid'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<ansprechpartner>>', $postfeld['apbezug'], $inhalt);
            $ez = $postfeld['kfz_datum_ez'];
            $alter = 0;
            if ($ez) {
                $alter = date('Y') - date('Y', strtotime($ez));
                if ($alter < 0) {
                    $alter = 0;
                }
            }
            $inhalt=p4n_sb_strreplace('<<kfz_alter>>', $alter, $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<kundennr>>', $kdnr1, $inhalt);
		$inhalt=p4n_sb_strreplace('<<intnr>>', $intnr1, $inhalt);
		$inhalt=p4n_sb_strreplace('<<stid>>', $postfeld['stid'], $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<bemerkung>>', str_replace("\n", ' \\par ', $postfeld['vertrag_bemerkung']), $inhalt);
		
			if ($cfg_kfzsuche_holland) {
				$briefanr='';
				if (p4n_mb_string('strtolower',$postfeld['anrede'])==p4n_mb_string('strtolower',_HERR_) or p4n_mb_string('strtolower',$postfeld['anrede'])=='herrn') {
					$briefanr=_BRIEFANREDE_HERR_;
				} elseif (p4n_mb_string('strtolower',$postfeld['anrede'])==p4n_mb_string('strtolower',_FRAU_)) {
					$briefanr=_BRIEFANREDE_FRAU_;
				}
				if ($cfg_carlo_appserver_ws and $briefanr=='') {
					$res9=$db->select(
						$sql_tab['stammdaten'],
						$sql_tabs['stammdaten']['briefanrede'],
						$sql_tabs['stammdaten']['anrede'].'='.$db->str($postfeld['anrede']).' and '.$sql_tabs['stammdaten']['briefanrede'].'!='.$db->str('')
					);
					$alle_ba=array();
					while ($row9=$db->zeile($res9)) {
						$alle_ba[$row9[0]]++;
					}
					@arsort($alle_ba);
					if (list($key, $val)=@each($alle_ba)) {
						$briefanr=$key;
					}
				}
				
				$zus_ap1='';
				$res9=$db->select(
					$sql_tab['stammdaten_ansprechpartner'],
					array(
						$sql_tabs['stammdaten_ansprechpartner']['anrede'],
						$sql_tabs['stammdaten_ansprechpartner']['vorname'],
						$sql_tabs['stammdaten_ansprechpartner']['bezeichnung'],
						$sql_tabs['stammdaten_ansprechpartner']['titel'],
						$sql_tabs['stammdaten_ansprechpartner']['zusatz4'],
						$sql_tabs['stammdaten_ansprechpartner']['zusatz5']
					),
					$sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid'])
						.' and '.$sql_tabs['stammdaten_ansprechpartner']['hauptkontakt'].'='.$db->dblogic(true),
					$sql_tabs['stammdaten_ansprechpartner']['bezeichnung']
				);
				if ($row9=$db->zeile($res9)) {
					$zus_ap1="\\par ".'T.a.v. '.strtolower($row9[0]).($row9[3]!=''?' '.$row9[3]:'').' '.$row9[1].($row9[4]!=''?' '.$row9[4]:'').' '.$row9[2];
				}
				
				if ($postfeld['firma1']!='' and $postfeld['name']!='' and p4n_mb_string('strtolower',p4n_mb_string('substr',$postfeld['anrede'], 0, 4))!='bedr') {
					$inhalt=p4n_sb_preg_replace('/<<anrede>>.*<<vorname>>.*<<name>>/Uis', trim($postfeld['anrede'].' '.($postfeld['titel']!=''?$postfeld['titel'].' ':'').$postfeld['vorname'].' '.$postfeld['name'])."\\par ".$postfeld['firma1'], $inhalt);
					$inhalt=p4n_sb_preg_replace('/<<briefanrede>>.*<<mn>>.*<<name>>/Uis', str_replace('  ', ' ', trim($briefanr.' '.($postfeld['titel']!=''?$postfeld['titel'].' ':'').p4n_mb_string('ucfirst',$postfeld['firma3']).' '.$postfeld['name'])), $inhalt);
				} elseif ($postfeld['firma1']!='') {
					$inhalt=p4n_sb_preg_replace('/<<anrede>>.*<<vorname>>.*<<name>>/Uis', trim($postfeld['firma1']).$zus_ap1, $inhalt);
				} else {
					$inhalt=p4n_sb_preg_replace('/<<briefanrede>>.*<<mn>>.*<<name>>/Uis', str_replace('  ', ' ', trim($briefanr.' '.($postfeld['titel']!=''?$postfeld['titel'].' ':'').p4n_mb_string('ucfirst',$postfeld['firma3']).' '.$postfeld['name'])), $inhalt);
				}
			}
			$m_apid=$apid;
			$m_keinap=$keinap;
			if (preg_match('/<<ansprechpartner>>/', $inhalt)) {
				$apid=0;
				$keinap=true;
				$apbez='';
				$ap_tel='';
				$ap_mob='';
				if (intval($m_apid)>0) {
					$res9=$db->select(
						$sql_tab['stammdaten_ansprechpartner'],
						array(
							$sql_tabs['stammdaten_ansprechpartner']['anrede'],
							$sql_tabs['stammdaten_ansprechpartner']['vorname'],
							$sql_tabs['stammdaten_ansprechpartner']['bezeichnung'],
							$sql_tabs['stammdaten_ansprechpartner']['titel'],
							$sql_tabs['stammdaten_ansprechpartner']['telefon'],
							$sql_tabs['stammdaten_ansprechpartner']['mobil'],
							$sql_tabs['stammdaten_ansprechpartner']['geburtstag']
						),
						$sql_tabs['stammdaten_ansprechpartner']['ansprechpartner_id'].'='.$db->dbzahl($m_apid)
					);
					if ($row9=$db->zeile($res9)) {
						$apbez=trim($row9[0].' '.($row9[3]!=''?$row9[3].' ':'').$row9[1].' '.$row9[2]);
						$ap_tel=$row9[4];
						$ap_mob=$row9[5];
						$ap_geb=$db->unixdate($row9[6]);
					}
				}
				$inhalt=p4n_sb_strreplace('<<ansprechpartner>>', $apbez, $inhalt);
				$inhalt=p4n_sb_strreplace('<<ansprechpartner_tel>>', $ap_tel, $inhalt);
				$inhalt=p4n_sb_strreplace('<<ansprechpartner_mob>>', $ap_mob, $inhalt);
				$inhalt=p4n_sb_strreplace('<<ansprechpartner_geburtsdatum>>', $ap_geb, $inhalt);
			}
		
		$inhalt=vorlage_kdaten_ersetzen($inhalt, $postfeld['firma1'], $postfeld['vorname'], $postfeld['name'], $postfeld['titel'], $postfeld['anrede'], $postfeld['stid'], $postfeld['firma3']);
		
		$apid=$m_apid;
		$keinap=$m_keinap;
		
		if (preg_match('/<<briefanrede>>/', $inhalt)) {
			$inhalt=p4n_sb_preg_replace('/<<briefanrede>>.*<<mn>>.*,/Uis', _BRIEFANREDE_FIRMA_, $inhalt);
		}
		
		if (isset($postfeld['vorlage_rd_gk'])) {
				$res9=$db->select(
					$sql_tab['stammdaten_ansprechpartner'],
					array(
						$sql_tabs['stammdaten_ansprechpartner']['anrede'],
						$sql_tabs['stammdaten_ansprechpartner']['vorname'],
						$sql_tabs['stammdaten_ansprechpartner']['bezeichnung'],
						$sql_tabs['stammdaten_ansprechpartner']['titel'],
						$sql_tabs['stammdaten_ansprechpartner']['telefon'],
						$sql_tabs['stammdaten_ansprechpartner']['mobil'],		// 5
						$sql_tabs['stammdaten_ansprechpartner']['email']
					),
					$sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid'])
						.' and '.$sql_tabs['stammdaten_ansprechpartner']['hauptkontakt'].'='.$db->dblogic(true),
					$sql_tabs['stammdaten_ansprechpartner']['bezeichnung']
				);
				if ($row9=$db->zeile($res9)) {
					$inhalt=p4n_sb_strreplace('<<anrede_ap>>', $row9[0], $inhalt);
					$inhalt=p4n_sb_strreplace('<<vorname_ap>>', $row9[1], $inhalt);
					$inhalt=p4n_sb_strreplace('<<name_ap>>', $row9[2], $inhalt);
					$inhalt=p4n_sb_strreplace('<<titel_ap>>', $row9[3], $inhalt);
					$inhalt=p4n_sb_strreplace('<<tel_ap>>', $row9[4], $inhalt);
					$inhalt=p4n_sb_strreplace('<<mobil_ap>>', $row9[5], $inhalt);
					$inhalt=p4n_sb_strreplace('<<email_ap>>', $row9[6], $inhalt);
				}
		}
		$inhalt=p4n_sb_strreplace('<<anrede_ap>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<vorname_ap>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<name_ap>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<titel_ap>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<tel_ap>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<mobil_ap>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<email_ap>>', '', $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<kunde>>', $anzeigename, $inhalt);
		$inhalt=p4n_sb_strreplace('<<adresse>>', $postfeld['adresse'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<plz>>', $postfeld['plz'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<ort>>', $postfeld['ort'].$zus_ort_landinfo, $inhalt);
		$inhalt=p4n_sb_strreplace('<<county_code>>', $postfeld['county'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<datum>>', adodb_date('d.m.Y'), $inhalt);
		$inhalt=p4n_sb_strreplace('<<datum_jahr>>', adodb_date('Y'), $inhalt);
		$inhalt=p4n_sb_strreplace('<<datumzeit>>', adodb_date('d.m.Y H:i'), $inhalt);
		$inhalt=p4n_sb_strreplace('<<zeit>>', adodb_date('H:i'), $inhalt);
		$inhalt=p4n_sb_strreplace('<<beruf>>', $postfeld['beruf'], $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<kundenmerkmal>>', $postfeld['kundenmerkmal'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vat>>', $postfeld['steuernummer'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<taxoff>>', $postfeld['firma2'], $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<fiscal_code>>', $postfeld['steuernummer'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vat_registration>>', $postfeld['steuernummer2'], $inhalt);
		// Co-Holder:
		$co_anzeigename=eingabe2anzeigename($postfeld['co_vorname'], $postfeld['co_name'], $postfeld['co_titel'], $postfeld['co_firma1'], $postfeld['co_anrede']);
		$inhalt=p4n_sb_strreplace('<<co_kunde>>', $co_anzeigename, $inhalt);
		$inhalt=p4n_sb_strreplace('<<co_adresse>>', $postfeld['co_adresse'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<co_plz>>', $postfeld['co_plz'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<co_ort>>', $postfeld['co_ort'].$zus_ort_landinfo, $inhalt);
		$inhalt=p4n_sb_strreplace('<<co_county_code>>', $postfeld['co_county'], $inhalt);
		$anr1=$postfeld['co_anrede'];
		if ($anr1=='HERRN' or $anr1=='HERR' or $anr1=='FRAU' or $anr1=='FIRMA') {
			$anr1=p4n_mb_string('ucfirst',p4n_mb_string('strtolower',$anr1));
		}
		$inhalt=p4n_sb_strreplace('<<co_anrede>>', $anr1, $inhalt);
		if ($postfeld['co_firma1']!='') {
			if (!preg_match('/<<co_firma>>/i', $inhalt)) {
				$inhalt=p4n_sb_strreplace('<<co_vorname>> <<co_name>>', '<<co_firma>> <<co_vorname>> <<co_name>>', $inhalt);
				if ($postfeld['co_name']=='' and $postfeld['co_vorname']=='') {
					$inhalt=p4n_sb_strreplace('<<co_name>>, <<co_vorname>>', '<<co_firma>> <<co_name>> <<co_vorname>>', $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<co_name>>, <<co_vorname>>', '<<co_firma>> <<co_name>>, <<co_vorname>>', $inhalt);
				}
			}
		}
		$inhalt=p4n_sb_strreplace('<<co_firma>>', $postfeld['co_firma1'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<co_vorname>>', $postfeld['co_vorname'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<co_name>>', $postfeld['co_name'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<co_fiscal_code>>', $postfeld['co_steuernummer'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<co_vat_registration>>', $postfeld['co_steuernummer2'], $inhalt);
		if ($cfg_kfzsuche_italien and !isset($postfeld['coholder'])) {
			$inhalt=p4n_sb_preg_replace('/<<coholder1>>.*<<coholder2>>/Uis', '', $inhalt);
		}
		$inhalt=p4n_sb_strreplace(array('<<coholder1>>', '<<coholder2>>'), '', $inhalt);

		$anr1=$postfeld['anrede'];
		if ($anr1=='HERRN' or $anr1=='HERR' or $anr1=='FRAU' or $anr1=='FIRMA') {
			$anr1=p4n_mb_string('ucfirst',p4n_mb_string('strtolower',$anr1));
		}
		$inhalt=p4n_sb_strreplace('<<anrede>>', $anr1, $inhalt);
		$inhalt=p4n_sb_strreplace('<<anrede2>>', $anr1, $inhalt);
		
		if ($postfeld['firma1']!='') {
			if (!preg_match('/<<firma>>/i', $inhalt)) {
				$inhalt=p4n_sb_strreplace('<<vorname>> <<name>>', '<<firma>> <<vorname>> <<name>>', $inhalt);
				if ($postfeld['name']=='' and $postfeld['vorname']=='') {
					$inhalt=p4n_sb_strreplace('<<name>>, <<vorname>>', '<<firma>> <<name>> <<vorname>>', $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<name>>, <<vorname>>', '<<firma>> <<name>>, <<vorname>>', $inhalt);
				}
			}
		}
		$inhalt=p4n_sb_strreplace('<<firma>>', $postfeld['firma1'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vorname>>', $postfeld['vorname'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<name>>', $postfeld['name'], $inhalt);
		
		if ($cfg_kfzsuche_kontaktaucheva) {
		$res8=$db->select(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['meinvpb'],
					$sql_tabs['stammdaten']['Telefon_3'],
					$sql_tabs['stammdaten']['Mobilfon_3'],
					$sql_tabs['stammdaten']['Fax_3'],
					$sql_tabs['stammdaten']['EMail_3']
				),
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($postfeld['stid'])
		);
		$row8=$db->zeile($res8);
		if ($postfeld['telefon']=='' and $row8[1]!='') {
			$inhalt=p4n_sb_strreplace('<<telefon1>>', $row8[1], $inhalt);
		}
		if ($postfeld['mobilfon']=='' and $row8[2]!='') {
			$inhalt=p4n_sb_strreplace('<<mobil>>', $row8[2], $inhalt);
			$inhalt=p4n_sb_strreplace('<<mobilfon1>>', $row8[2], $inhalt);
			$inhalt=p4n_sb_strreplace('<<mob1>>', $row8[2], $inhalt);
		}
		if ($postfeld['fax']=='' and $row8[3]!='') {
			$inhalt=p4n_sb_strreplace('<<fax>>', $row8[3], $inhalt);
			$inhalt=p4n_sb_strreplace('<<fax1>>', $row8[3], $inhalt);
		}
		if ($postfeld['email']=='' and $row8[4]!='') {
			$inhalt=p4n_sb_strreplace('<<email>>', $row8[4], $inhalt);
			$inhalt=p4n_sb_strreplace('<<email1>>', $row8[4], $inhalt);
		}
		}
		
		if (preg_match('/<<mobilfon1>>/', $inhalt)) {
			$res3=$db->select(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['Telefon_1'],
					$sql_tabs['stammdaten']['Telefon_2'],
					$sql_tabs['stammdaten']['Mobilfon_1'],
					$sql_tabs['stammdaten']['Mobilfon_2'],
					$sql_tabs['stammdaten']['EMail_1'],
					$sql_tabs['stammdaten']['EMail_2'],
					$sql_tabs['stammdaten']['Fax_1'],
					$sql_tabs['stammdaten']['Fax_2']
				),
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($postfeld['stid'])
			);
			if ($row3=$db->zeile($res3)) {
				$inhalt=p4n_sb_strreplace('<<telefon1>>', $row3[0], $inhalt);
				if ($row3[0]==$row3[1]) {
					$inhalt=p4n_sb_strreplace('<<telefon2>>', '', $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<telefon2>>', $row3[1], $inhalt);
				$inhalt=p4n_sb_strreplace('<<mobilfon1>>', $row3[2], $inhalt);
				if ($row3[2]==$row3[3]) {
					$inhalt=p4n_sb_strreplace('<<mobilfon2>>', '', $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<mobilfon2>>', $row3[3], $inhalt);
				$inhalt=p4n_sb_strreplace('<<email1>>', $row3[4], $inhalt);
				if ($row3[4]==$row3[5]) {
					$inhalt=p4n_sb_strreplace('<<email2>>', '', $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<email2>>', $row3[5], $inhalt);
				$inhalt=p4n_sb_strreplace('<<fax1>>', $row3[6], $inhalt);
				if ($row3[6]==$row3[7]) {
					$inhalt=p4n_sb_strreplace('<<fax2>>', '', $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<fax2>>', $row3[7], $inhalt);
			}
		}
		
		$std_tel=$postfeld['telefon'];
		if ($std_tel=='') {
			$std_tel=$postfeld['mobilfon'];
		}
		$inhalt=p4n_sb_strreplace('<<tel1>>', $std_tel, $inhalt);
		if ($cfg_kfzsuche_kontakt_pg) {
							if (!preg_match('/<<telefon2>>/', $inhalt) and $postfeld['telefon2']!='' and $postfeld['telefon']=='') {
								$inhalt=p4n_sb_strreplace('<<telefon1>>', $postfeld['telefon2'], $inhalt);
							}
							$inhalt=p4n_sb_strreplace('<<telefon2>>', $postfeld['telefon2'], $inhalt);
							if (!preg_match('/<<mobil2>>/', $inhalt) and $postfeld['mobilfon2']!='' and $postfeld['mobilfon']=='') {
								$inhalt=p4n_sb_strreplace('<<mobil>>', $postfeld['mobilfon2'], $inhalt);
							}
							$inhalt=p4n_sb_strreplace('<<mobil2>>', $postfeld['mobilfon2'], $inhalt);
							if (!preg_match('/<<email2>>/', $inhalt) and $postfeld['email2']!='' and $postfeld['email']=='') {
								$inhalt=p4n_sb_strreplace('<<email>>', $postfeld['email2'], $inhalt);
							}
							$inhalt=p4n_sb_strreplace('<<email2>>', $postfeld['email2'], $inhalt);
							if (!preg_match('/<<fax2>>/', $inhalt) and $postfeld['fax2']!='' and $postfeld['fax']=='') {
								$inhalt=p4n_sb_strreplace('<<fax>>', $postfeld['fax2'], $inhalt);
							}
							$inhalt=p4n_sb_strreplace('<<fax2>>', $postfeld['fax2'], $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<telefon1>>', $postfeld['telefon'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<mob1>>', $postfeld['mobilfon'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<geb>>', $postfeld['geburtsdatum'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<geburtsort>>', $postfeld['geburtsort'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<personnr>>', substr(str_replace('.', '', $postfeld['geburtsdatum']), 0, 4).substr(str_replace('.', '', $postfeld['geburtsdatum']), -2).$postfeld['geburtsort'], $inhalt);
		if ($postfeld['mobilfon']==$std_tel) {
			$inhalt=p4n_sb_strreplace('<<mobil>>', '', $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<mobil>>', $postfeld['mobilfon'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<email>>', $postfeld['email'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<fax>>', $postfeld['fax'], $inhalt);

		$inhalt=p4n_sb_strreplace('<<aufmerksam>>', str_replace("\n", '\\par ', $postfeld['wodurch_aufmerksam']), $inhalt);

		if (preg_match('/<<anzahlung>>/', $inhalt)) {
			$gef_fin=false;
			$res6=$db->select(
				$sql_tab['einstellungen'],
				$sql_tabs['einstellungen']['wert'],
				$sql_tabs['einstellungen']['modul'].'='.$db->str('kfzsuche_fincalc')
			);
			if ($row6=$db->zeile($res6)) {
				$expl=explode($trz, $row6[0]);
				$zi=0;
				while (list($key, $val)=@each($expl)) {
					$expl2=explode(';', $val);
					$expl2[4]=str_replace('.', ',', $expl2[4]);
					$expl2[6]=str_replace('.', ',', $expl2[6]);
					$expl2[7]=str_replace('.', ',', $expl2[7]);
					$expl2[9]=str_replace('.', ',', $expl2[9]);

					if (isset($postfeld['finkalk_auswahl'])) {
						if ($postfeld['finkalk_auswahl']==$expl2[0]) {
							$f_bank=base64_decode($expl2[1]);
							$f_text=base64_decode($expl2[2]);
							$f_jahreszins=doubleval(str_replace(',', '.', $expl2[4]));
							$f_laufzeit=intval($expl2[5]);
							$f_anzahlung=doubleval(str_replace(',', '.', $expl2[6]));
							$f_restrate=doubleval(str_replace(',', '.', $expl2[7]));
							$f_zusb=doubleval(str_replace(',', '.', $expl2[9]));
							if ($cfg_kfzsuche_finkalk_banktext) {
								$f_text2=base64_decode($expl2[10]);
							}
							$gef_fin=true;
						}
					} elseif ($expl2[8]=='1') {
						if (($expl2[3]=='1' and $postfeld['vertrag_nwgw']=='1') or ($expl2[3]=='2' and $postfeld['vertrag_nwgw']!='1') or $expl2[3]=='3') {
							$f_bank=base64_decode($expl2[1]);
							$f_text=base64_decode($expl2[2]);
							$f_jahreszins=doubleval(str_replace(',', '.', $expl2[4]));
							$f_laufzeit=intval($expl2[5]);	// monate
							$f_anzahlung=doubleval(str_replace(',', '.', $expl2[6]));
							$f_restrate=doubleval(str_replace(',', '.', $expl2[7]));
							$f_zusb=doubleval(str_replace(',', '.', $expl2[9]));
							if ($cfg_kfzsuche_finkalk_banktext) {
								$f_text2=base64_decode($expl2[10]);
							}
							$gef_fin=true;
						}
					}
				}
			}
			$fin_k_w1='';
			$fin_k_w2='';
			$fin_k_w3='';
			$fin_k_w4='';
			$fin_k_w5='';
			$fin_k_w6='';
			$fin_k_w7='';
			$fin_k_w8='';
			if ($gef_fin && $konf_quelle !== 'FHD') {
				$kfzpr1=doubleval(str_replace(',', '.', $postfeld['fin_preis']));
				if (doubleval($kfzpr1)==0 or $postfeld['vertrag_nwgw']=='1' or doubleval(str_replace(',', '.', $postfeld['fin_preis2']))>0) {
					$kfzpr1=doubleval(str_replace(',', '.', $postfeld['fin_preis2']));
				}
				if (isset($postfeld['finkalk_auswahl_preis'])) {
					$kfzpr1_abw=doubleval(str_replace(array('.', ','), array('', '.'), $postfeld['finkalk_auswahl_preis']));
					if ($kfzpr1_abw>0) {
						$kfzpr1=$kfzpr1_abw;
					}
				}
				$fin_kfzpr1=doubleval(number_format($kfzpr1, 2, ".", ""));
				$fin_k_w1=number_format($kfzpr1*$f_anzahlung/100, 2, ",", ".");
				$fin_anz1=doubleval(number_format($kfzpr1*$f_anzahlung/100, 2, ".", ""));

				$fin_k_w2=number_format($kfzpr1*$f_restrate/100, 2, ",", ".");
				$fin_rest1=doubleval(number_format($kfzpr1*$f_restrate/100, 2, ".", ""));

				$fin_finb=$fin_kfzpr1-$fin_anz1-$fin_rest1;
				$fin_effz=doubleval(number_format(doubleval($f_jahreszins), 2, ".", ""));
				$fin_effz2=$fin_effz/100;
				$fin_kost1=round($fin_rest1*$fin_effz/1200);
				$fin_monatsrate=round($fin_finb*(pow(1+$fin_effz2,1/12)-1)/(1-pow(1+$fin_effz2,-$f_laufzeit/12)))+$fin_kost1;

				$fin_k_w3=$f_laufzeit.' '._MONATE_;
				$fin_k_w4=number_format(doubleval($f_jahreszins), 2, ",", ".").'';
				$fin_k_w5=number_format(doubleval($fin_monatsrate), 2, ",", ".");
				$fin_gesamt1=$f_laufzeit*($fin_monatsrate)+$fin_rest1+$fin_anz1;
				$fin_k_w6=number_format(doubleval($fin_gesamt1), 2, ",", ".");
				$fin_k_w7=number_format(doubleval($fin_finb), 2, ",", ".");
				$fin_k_w8=number_format(doubleval($f_zusb), 2, ",", ".");
			} else if ($konf_quelle !== 'FHD') {
				$inhalt=p4n_sb_preg_replace('/<<start_fin>>.*<<ende_fin>>/Uis', '', $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<fbank>>', $f_bank, $inhalt);
			if ($postfeld['zusatz_auswahl']=='-1') {
				$postfeld['zusatz_auswahl']='';
			}
			$f_text2=p4n_mb_string('str_replace', '{zusatzauswahl}', $postfeld['zusatz_auswahl'], $f_text2);
			$inhalt=p4n_sb_strreplace('<<fbanktext>>',  p4n_mb_string('str_replace', "\n", '\\par ', $f_text2), $inhalt);
			$inhalt=p4n_sb_strreplace('<<ftext>>', $f_text, $inhalt);
            if ($konf_quelle !== 'FHD') {
                $inhalt=p4n_sb_strreplace('<<anzahlung>>', $fin_k_w1, $inhalt);
                $inhalt=p4n_sb_strreplace('<<restzahlung>>', $fin_k_w2, $inhalt);
                $inhalt=p4n_sb_strreplace('<<laufzeit>>', $fin_k_w3, $inhalt);
                $inhalt=p4n_sb_strreplace('<<effektivzins>>', $fin_k_w4, $inhalt);
                $inhalt=p4n_sb_strreplace('<<monatsrate>>', $fin_k_w5, $inhalt);
            }
			$inhalt=p4n_sb_strreplace('<<betrag>>', $fin_k_w6, $inhalt);
			$inhalt=p4n_sb_strreplace('<<finbetrag>>', $fin_k_w7, $inhalt);
			$inhalt=p4n_sb_strreplace('<<zusatzbetrag>>', $fin_k_w8, $inhalt);
		}

		if (preg_match('/<<steuernummer>>/Uis', $inhalt)) {
			$res8=$db->select(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['id'],
					$sql_tabs['stammdaten']['steuernummer']
				),
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
			);
			$row8=$db->zeile($res8);
			$inhalt=p4n_sb_strreplace('<<steuernummer>>', $row8[1], $inhalt);
		}
		if (preg_match('/<<fleetnummer>>/Uis', $inhalt)) {
			$res8=$db->select(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['id'],
					$sql_tabs['stammdaten']['fleetnummer']
				),
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
			);
			$row8=$db->zeile($res8);
			$inhalt=p4n_sb_strreplace('<<fleetnummer>>', $row8[1], $inhalt);
		}

		$r_empf='';
		if (isset($postfeld['rechnungsempfaenger'])) {
			$res8=$db->select(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['id'],
					$sql_tabs['stammdaten']['vorname'],
					$sql_tabs['stammdaten']['name'],
					$sql_tabs['stammdaten']['firma1']
				),
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($postfeld['rechnungsempfaenger'])
			);
			$row8=$db->zeile($res8);
			$res9=$db->select(
					$sql_tab['stammdaten_mandant'],
					$sql_tabs['stammdaten_mandant']['nummer1'],
					$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($postfeld['rechnungsempfaenger']).' and '.
						$sql_tabs['stammdaten_mandant']['nummer1'].'!='.$db->str('')
			);
			$row9=$db->zeile($res9);

			$r_empf=_RECHNUNGSEMPFAENGER_.': '.trim(trim($row8[3].' '.$row8[2].', '.$row8[1]), ',').($row9[0]!=''?' ('.$row9[0].')':'');
		}
		$inhalt=p4n_sb_strreplace('<<rechnungsempfaenger>>', $r_empf, $inhalt);

		$inhalt=p4n_sb_strreplace('<<knkurs>>', $postfeld['kurs_waehrung'], $inhalt);
		$kurs1=doubleval(str_replace(',', '.', $postfeld['kurs_waehrung']));
		$kurs3=doubleval(str_replace(',', '.', $postfeld['kurs_waehrung3']));
		$inhalt=p4n_sb_strreplace('<<kndate>>', $postfeld['kurs_datum'], $inhalt);

		$inhalt=p4n_sb_strreplace('<<finart>>', $postfeld['vertrag_finart'], $inhalt);
		
		if (isset($postfeld['vertrag_finart'])) {
			if ($postfeld['vertrag_finart']==_FINANZIERUNG_) {
				$inhalt=p4n_sb_strreplace('<<finstart>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<finende>>', '', $inhalt);
			} else {
				$inhalt=p4n_sb_preg_replace('/<<finstart>>.*<<finende>>/Uis', '', $inhalt);
			}
		}
		
		$lao1='';
		$lao1zusatz1='';
		$mandparid=1;
		$res4=$db->select(
				$sql_tab['mandant'],
				array(
					$sql_tabs['mandant']['bezeichnung'],
					$sql_tabs['mandant']['zusatz1'],
					$sql_tabs['mandant']['parent_id']
				),
				$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($postfeld['vertrag_lagerort'])
		);
		if ($row4=$db->zeile($res4)) {
			$lao1=$row4[0];
			$lao1zusatz1=$row4[1];
			$mandparid=intval($row4[2]);
		}
		$inhalt=p4n_sb_strreplace('<<lagerort>>', $lao1, $inhalt);
		
		if (preg_match('/<<qrcode>>/Ui', $inhalt)) {
			//$cfg_kfzsuche_qrcodelink='<<art>>@@<<lagerort2>>@@<<kundennr>>@@<<datum>>@@<<fgnr>>';
			if (is_file('inc/phpqrcode.php') and isset($cfg_kfzsuche_qrcodelink)) {
				include_once('inc/phpqrcode.php');
				$linkqr=$cfg_kfzsuche_qrcodelink;
				$linkqr=str_replace('<<art>>', '65', $linkqr);
				$linkqr=str_replace('<<datum>>', adodb_date('dmY'), $linkqr);
				$linkqr=str_replace('<<fgnr>>', $postfeld['kfz_fahrgestell'], $linkqr);
                $linkqr=str_replace('<<lagerort>>', $lao1, $linkqr);
				$laobez2=substr($lao1, 1);
				$linkqr=str_replace('<<lagerort2>>', $laobez2, $linkqr);
				$linkqr=str_replace('<<lagerort3>>', $lao1zusatz1, $linkqr);
				$linkqr=str_replace('<<oppid>>', $anr, $linkqr);
				$duerkopmand='';
				if ($_SESSION['cfg_kunde']=='carlo_opel_duerkop') {
					if ($mandparid==1) {
						$duerkopmand='D2';
					} elseif ($mandparid==2) {
						$duerkopmand='D1';
					}
				}
				$linkqr=str_replace('<<duerkopmandant>>', $duerkopmand, $linkqr);
				$linkqr=str_replace('<<kundennr>>', $kdnr1, $linkqr);
				QRcode::jpg($linkqr, 'temp/_qr_'.$_SESSION['user_id'].'.jpg');
				$bildinh=file_get_contents('temp/_qr_'.$_SESSION['user_id'].'.jpg');
				$bildinh2=bin2hex($bildinh);
				$inhalt=p4n_sb_strreplace('<<qrcode>>', '{\\pict \\picscalex85\\picscaley85\\jpegblip '.$bildinh2.' } ', $inhalt);
				unlink('temp/_qr_'.$_SESSION['user_id'].'.jpg');
			}
		}
		
/*		if ($_SESSION['cfg_kunde']=='carlo_opel_tamsen') {
			include('inc/lib_phpbarcode.php');
			$img_bc=barcode39('*'.$lao1.'XYZ'.$kdnr1.'*', 300, 80, 100, 'JPEG', 0, array('filepath' => 'temp/barcode_'.$_SESSION['user_id'].'.jpg'));
			$barc1=bin2hex(file_get_contents('temp/barcode_'.$_SESSION['user_id'].'.jpg'));
			@unlink('temp/barcode_'.$_SESSION['user_id'].'.jpg');
			$inhalt=p4n_sb_strreplace('<<barcode1>>', '{\\pict \\picscalex55\\picscaley55\\jpegblip '.$barc1.' } ', $inhalt);
		}
*/		
		// zus�tzliche Dinge:
		$postfeld['mvertrag_lagerort']=$postfeld['vertrag_lagerort'];
		if ($postfeld['vertrag_lagerort']!='') {
			$res4=$db->select(
				$sql_tab['mandant'],
				$sql_tabs['mandant']['briefkopf'],
				$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($postfeld['vertrag_lagerort'])
			);
			if ($row4=$db->zeile($res4)) {
				$postfeld['vertrag_lagerort']=str_replace(array("\n", '<br>'), '\\par ', $row4[0]);
			}
		}

		$fin_gesamtpreis=doubleval($postfeld['fin_preis']);

		if ($cfg_kfzsuche_liefertermin_schnellstens and isset($postfeld['vertrag_liefertermin_schnellstens'])) {
			$inhalt=p4n_sb_strreplace('<<vdet_lieferdatum>>', _SCHNELLSTENS_, $inhalt);
		}
		if ($cfg_kfzsuche_liefertermin_beides) {
			if (isset($postfeld['clieft1'])) {
				if ($cfg_kfzsuche_liefertermin_monatjahr) {
					$inhalt=p4n_sb_strreplace('<<vdet_lieferdatum>>', $postfeld['vertrag_liefertermin1monat'].'/'.$postfeld['vertrag_liefertermin2'], $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<vdet_lieferdatum>>', ($cfg_kfzsuche_norway?'':_KW_.' ').$postfeld['vertrag_liefertermin1'].'/'.$postfeld['vertrag_liefertermin2'], $inhalt);
				}
			} elseif (isset($postfeld['clieft2'])) {
				$inhalt=p4n_sb_strreplace('<<vdet_lieferdatum>>', $postfeld['vertrag_liefertermin'], $inhalt);
			}
			$liefert_ts=0;
			if (isset($postfeld['clieft1'])) {
				$liefert_ts=strtotime($postfeld['vertrag_liefertermin2'].'W'.(strlen($postfeld['vertrag_liefertermin1'])==1?'0':'').$postfeld['vertrag_liefertermin1']);
				if ($cfg_kfzsuche_liefertermin_monatjahr) {
					$liefert_ts=adodb_mktime(12,0,0, $postfeld['vertrag_liefertermin1monat'], 1, $postfeld['vertrag_liefertermin2']);
				}
			} elseif (isset($postfeld['clieft2'])) {
				$datum_lt=$postfeld['vertrag_liefertermin'];
				$liefert_ts=adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_lt,3,2),p4n_mb_string('substr',$datum_lt,0,2),p4n_mb_string('substr',$datum_lt,6,4) );
			}
			if ($liefert_ts>0) {
				$inhalt=p4n_sb_strreplace('<<vdet_lieferdatum_mj>>', adodb_date('m / Y', $liefert_ts), $inhalt);
			} else {
				$inhalt=p4n_sb_strreplace('<<vdet_lieferdatum_mj>>', '', $inhalt);
			}
			
			$inhalt=p4n_sb_strreplace('<<vdet_lieferdatum>>', $postfeld['vertrag_liefertermin'], $inhalt);
		} elseif ($cfg_kfzsuche_liefertermin_datum) {
			$inhalt=p4n_sb_strreplace('<<vdet_lieferdatum>>', $postfeld['vertrag_liefertermin'], $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<vdet_lieferdatum2>>', $postfeld['vertrag_liefertermin'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vdet_lieferdatum>>', $postfeld['vertrag_liefertermin1'].'/'.$postfeld['vertrag_liefertermin2'], $inhalt);	//$postfeld['vertrag_liefertermin']
		if ($postfeld['vertrag_unfall1']!='') {
			$inhalt=p4n_sb_strreplace('<<unfall>>', trim(str_replace(array("\n", '<br>'), ', ', $postfeld['vertrag_unfall1']), ','), $inhalt);
		}
		
		if ($cfg_kfzsuche_unfalltext_auslesen and !isset($postfeld['vertrag_unfall'])) {
			$postfeld['vertrag_unfall']=$pid_unfalltext;
		}
		
		if (isset($postfeld['vertrag_unfallm'])) {
			$postfeld['vertrag_unfall'].=' '.$postfeld['vertrag_unfallm'];
		}
		if (isset($postfeld['vertrag_unfall_auswahl']) and $postfeld['vertrag_unfall_auswahl']!='') {
			$postfeld['vertrag_unfall']=trim($postfeld['vertrag_unfall_auswahl'].($postfeld['vertrag_unfall']!=''?' / ':'').$postfeld['vertrag_unfall']);
		}
		$postfeld['vertrag_unfall']=trim($postfeld['vertrag_unfall']);
		$inhalt=p4n_sb_strreplace('<<unfalltext>>', trim(str_replace(array("\n", '<br>'), ', ', $postfeld['vertrag_unfall']), ','), $inhalt);
		if ($cfg_kfzsuche_unfallhaken) {
			if (isset($postfeld['vertrag_unfallh']) and $postfeld['vertrag_unfallh']=='1') {
				if (isset($cfg_kfzsuche_unfallhaken_text_ja) and $cfg_kfzsuche_unfallhaken_text_ja!='') {
					$inhalt=p4n_sb_strreplace('<<unfall>>', $cfg_kfzsuche_unfallhaken_text_ja, $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<unfall>>', _UNFALLW_, $inhalt);
				}
			} else {
				if (isset($cfg_kfzsuche_unfallhaken_text_nein) and $cfg_kfzsuche_unfallhaken_text_nein!='') {
					$inhalt=p4n_sb_strreplace('<<unfall>>', $cfg_kfzsuche_unfallhaken_text_nein, $inhalt);
				}
			}
		}
		$inhalt=p4n_sb_strreplace('<<unfall>>', trim(str_replace(array("\n", '<br>'), ', ', $postfeld['vertrag_unfall']), ','), $inhalt);
		$inhalt=p4n_sb_strreplace('<<unfall2>>', trim(str_replace(array("\n", '<br>'), ', ', $postfeld['vertrag_unfall2']), ','), $inhalt);

		// KFZ:
		// PA-Nummer:
		$pa_nummer='';
		if ($postfeld['kfz_fahrgestell']!='') {
			$res3=$db->select(
				$sql_tab['produktzuordnung_dispo'],
				$sql_tabs['produktzuordnung_dispo']['pa_nummer'],
				$sql_tabs['produktzuordnung_dispo']['fahrgestellnummer'].'='.$db->str($postfeld['kfz_fahrgestell'])
			);
			if ($row3=$db->zeile($res3)) {
				$pa_nummer=$row3[0];
			}
		}
		$inhalt=p4n_sb_strreplace('<<pa_nummer>>', $pa_nummer, $inhalt);


		$inhalt=p4n_sb_strreplace('<<markencode>>', $postfeld['kfz_markencode'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<kennzeichen>>', $postfeld['kfz_kennzeichen'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<typ>>', $postfeld['kfz_typmodell'].$kfz_typ2, $inhalt);
		$inhalt=p4n_sb_strreplace('<<fahrgestellnummer>>', $postfeld['kfz_fahrgestell'].(($cfg_kfzsuche_fgnr_panummer and $pa_nummer!='')?'/'.$pa_nummer.'':''), $inhalt);
		$inhalt=p4n_sb_strreplace('<<refnr>>', $postfeld['refnr'], $inhalt);


		if ($cfg_kfzsuche_ausdruckhaken and (!isset($postfeld['aust_drucken']) or $postfeld['aust_drucken']=='0')) {
			$inhalt=p4n_sb_strreplace('<<ausstattung2>>', '', $inhalt);
		}
		
		if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
			$expl=explode(',', $postfeld['kfz_ausstattung']);
			$iz=1;
			$neu_ausst='';
			while (list($akey, $aval)=@each($expl)) {
				$aval=trim($aval);
				if ($iz<=28) {
					$neu_ausst.=$aval.', ';
				}
				while (p4n_mb_string('strlen',$aval)>25) {
					$aval=p4n_mb_string('substr',$aval, 0, -25);
//					$iz++;
				}
				$iz++;
			}
			if ($iz>=29) {
				$neu_ausst.=_UVM_.', ';
			}
			$neu_ausst=p4n_mb_string('substr',$neu_ausst, 0, -2);
			$inhalt=p4n_sb_strreplace('<<ausstattung2>>', $neu_ausst, $inhalt);
		}
		if ($_SESSION['cfg_kunde']=='carlo_opel_dello') {
			$expl=explode(',', $postfeld['kfz_ausstattung']);
			$iz=1;
			$neu_ausst='';
			while (list($akey, $aval)=@each($expl)) {
				$aval=trim($aval);
				$neu_ausst.=$aval.'\\par ';
			}
			$neu_ausst=p4n_mb_string('substr',$neu_ausst, 0, -5);
			$inhalt=p4n_sb_strreplace('<<ausstattung2>>', $neu_ausst, $inhalt);
		}
		if (isset($postfeld['nwvorlage']) and intval($postfeld['nwvorlage'])!=3) {
			$inhalt=p4n_sb_preg_replace('/<<start_ausst2>>.*<<ende_ausst2>>/Uis', '', $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<start_ausst2>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<ende_ausst2>>', '', $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<ausstattung2>>', $postfeld['kfz_ausstattung'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<art>>', $postfeld['kfz_bauart'], $inhalt);

        $inhalt=p4n_sb_strreplace('<<kraftstoffart>>', @$postfeld['kraftstoffart'], $inhalt);
        $inhalt=p4n_sb_strreplace('<<antriebsart>>', @$postfeld['antriebsart'], $inhalt);
		$mctya=trim($postfeld['kfz_markencode'].' '.$postfeld['kfz_typmodell'].$kfz_typ2.' '.$postfeld['kfz_bauart']);
		$inhalt=p4n_sb_strreplace('<<markencode_typ_art2>>', kfzs_klammerraus($mctya), $inhalt);
		$inhalt=p4n_sb_strreplace('<<markencode_typ_art3>>', kfzs_codenachvorne($mctya), $inhalt);
		$mctya_m=$mctya;
		if (p4n_mb_string('strlen',$mctya)>65) {
			$mctya=p4n_mb_string('substr',$mctya, 0, 63).'...';
		}
		$inhalt=p4n_sb_strreplace('<<markencode_typ_art>>', $mctya, $inhalt);
		$inhalt=p4n_sb_strreplace('<<modellnr>>', $postfeld['gme_modellnr'], $inhalt);
		
		if ($cfg_kfzsuche_levy or $cfg_kfzsuche_bestellcode) {
			$inhalt=p4n_sb_strreplace('<<bestellcode>>', $postfeld['kfz_bestellcode'], $inhalt);
		}
		if ($cfg_kfzsuche_gerding) {
			$inhalt=p4n_sb_strreplace('<<bestellcode>>', $postfeld['kfz_bestellcode'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<bestellcode_farbe>>', $postfeld['kfz_bestellcode_farbe'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<bestellcode_trim>>', $postfeld['kfz_bestellcode_trim'], $inhalt);
		}
		
		if ($postfeld['kfz_hubraum']=='0') {
			$postfeld['kfz_hubraum']='  ';
		}
		$inhalt=p4n_sb_strreplace('<<hrm2>>', $postfeld['kfz_hubraum'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<farbe>>', $postfeld['kfz_farbe'], $inhalt);
		if ($postfeld['kfz_kw']=='0') {
			$postfeld['kfz_kw']='    ';
		}
		$inhalt=p4n_sb_strreplace('<<kw>>', $postfeld['kfz_kw'], $inhalt);
		if (intval($postfeld['kfz_ps'])<=0) {
			$postfeld['kfz_ps']=round(intval($postfeld['kfz_kw'])*1.35962);
		}
		if ($postfeld['kfz_ps']=='0') {
			$postfeld['kfz_ps']='    ';
		}
		$inhalt=p4n_sb_strreplace('<<ps>>', $postfeld['kfz_ps'], $inhalt);
		if ($cfg_kfzsuche_kmpunkt) {
			$inhalt=p4n_sb_strreplace('<<km>>', number_format(doubleval($postfeld['kfz_kmstand']), 0, ",", "."), $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<km>>', $postfeld['kfz_kmstand'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<datum_ez>>', $postfeld['kfz_datum_ez'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<halter>>', $postfeld['kfz_vorbesitzer'], $inhalt);
		if ($cfg_ws_avag_kroatien) {
			$inhalt=p4n_sb_strreplace('<<datum_huau>>', p4n_mb_string('substr',$postfeld['kfz_datum_hu'], -4), $inhalt);
		}
		if ($cfg_kfzsuche_dd2020) {
			if ($kfz_fstatuscode=='6' or $kfz_fstatus=='Mietfahrzeug' or $kfz_fstatus=='Mietwagen' or $kfz_fstatus=='Gebrauchtfahrzeug' or $kfz_fstatus=='Gebrauchtwagen') {
			//	$inhalt=p4n_sb_strreplace('<<datum_huau>>', 'neu', $inhalt);
			}
		}
		$inhalt=p4n_sb_strreplace('<<datum_huau>>', $postfeld['kfz_datum_hu'], $inhalt);
		
		if (isset($postfeld['kfz_hsn'])) {
			$inhalt=p4n_sb_strreplace('<<hsn>>', $postfeld['kfz_hsn'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<HSN>>', $postfeld['kfz_hsn'], $inhalt);
		}
		if (isset($postfeld['gme_hsn'])) {
			$inhalt=p4n_sb_strreplace('<<hsn>>', $postfeld['gme_hsn'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<HSN>>', $postfeld['gme_hsn'], $inhalt);
		}
		if (isset($postfeld['kfz_tsn'])) {
			$inhalt=p4n_sb_strreplace('<<tsn>>', $postfeld['kfz_tsn'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<TSN>>', $postfeld['kfz_tsn'], $inhalt);
		}
        if (isset($postfeld['gme_tsn'])) {
			$inhalt=p4n_sb_strreplace('<<tsn>>', $postfeld['gme_tsn'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<TSN>>', $postfeld['gme_tsn'], $inhalt);
		}
		if (isset($postfeld['kfz_diffregel']) and $postfeld['kfz_diffregel']=='1') {
			$inhalt=p4n_sb_strreplace('<<diffregel>>', _REGELBEST_, $inhalt);
		}
		if (isset($postfeld['kfz_diffregel']) and $postfeld['kfz_diffregel']=='2') {
			$inhalt=p4n_sb_strreplace('<<diffregel>>', _DIFFBEST_, $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<diffregel>>', '', $inhalt);
		
		if ($cfg_kfzsuche_levy and $postfeld['kfz_polster']=='' and $postfeld['vertrag5_trim']!='') {
			$postfeld['kfz_polster']=$postfeld['vertrag5_trim'];
		}
		$inhalt=p4n_sb_strreplace('<<polsterung>>', $postfeld['kfz_polster'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<polster>>', $postfeld['kfz_polster'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<bereifung>>', $postfeld['kfz_bereifung'], $inhalt);

		$inhalt=p4n_sb_strreplace('<<description1>>', $postfeld['konf_typmodella'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<description2>>', $postfeld['konf_typmodellb'], $inhalt);
		$summe_own=0;
		if (isset($postfeld['konf_zus_ausst'])) {
			while (list($key_a, $val_a)=@each($postfeld['konf_zus_ausst'])) {
				$res4=$db->select(
					$sql_tab['kfzkonfig_ausstattung'],
					array(
						$sql_tabs['kfzkonfig_ausstattung']['art'],
						$sql_tabs['kfzkonfig_ausstattung']['acode'],
						$sql_tabs['kfzkonfig_ausstattung']['beschreibung'],
						$sql_tabs['kfzkonfig_ausstattung']['preis1'],
						$sql_tabs['kfzkonfig_ausstattung']['preis2']
					),
					'('.$sql_tabs['kfzkonfig_ausstattung']['markencode'].'='.$db->str($postfeld['kfz_markencode']).' or '.
						$sql_tabs['kfzkonfig_ausstattung']['markencode'].'='.$db->str('').') and '.
						$sql_tabs['kfzkonfig_ausstattung']['art'].'='.$db->str('own option').' and '.
						$sql_tabs['kfzkonfig_ausstattung']['acode'].'='.$db->str($key_a),
					$sql_tabs['kfzkonfig_ausstattung']['serienausstattung'].','.$sql_tabs['kfzkonfig_ausstattung']['beschreibung']
				);
				if ($row4=$db->zeile($res4)) {
					if ($row4[4]>0 and $row4[3]==0) {
						$row4[3]=$row4[4];
					}
					$summe_own+=doubleval($row4[3]);
					$postfeld['konf_ausst3'].=$row4[2]."\n"; // $row4[1].' - '.$row4[2].' - '.number_format($row4[3], 2, ",", "")."\n";
				}
			}
		}

		if (!isset($postfeld['konf_ausst1'])) {
			$postfeld['konf_ausst1']='';

			$res4=$db->select(
			$sql_tab['produktzuordnung_ausstattung'],
			array(
				$sql_tabs['produktzuordnung_ausstattung']['ausst_code'],
				$sql_tabs['produktzuordnung_ausstattung']['beschreibung'],
				$sql_tabs['produktzuordnung_ausstattung']['beschreibung2']
			),
			$sql_tabs['produktzuordnung_ausstattung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid']),
			$sql_tabs['produktzuordnung_ausstattung']['beschreibung']
			);
			while ($row4=$db->zeile($res4)) {
				if ($row4[1]!='' or $row4[2]!='') {
					$postfeld['konf_ausst1'].=trim($row4[1].' '.$row4[2])."\n";	// $row4[0].' - '.trim($row4[1].' '.$row4[2])."\n";
				}
			}
		}

		$inhalt=p4n_sb_strreplace('<<ausstattung_serie>>', str_replace("\n", "\\par ", $postfeld['konf_ausst1']), $inhalt);
		$inhalt=p4n_sb_strreplace('<<ausstattung_sonder>>', str_replace("\n", "\\par ", $postfeld['konf_ausst2']), $inhalt);
		$inhalt=p4n_sb_strreplace('<<ausstattung_eigene>>', str_replace("\n", "\\par ", $postfeld['konf_ausst3']), $inhalt);

		if ($postfeld['fin_zahlungsart']=='3') {
			$postfeld['fin_preis']=$postfeld['fin_preis2'];
		} else {
			$postfeld['listenpreis']=$postfeld['listenpreis2'];
		}
		if (intval($postfeld['vertrag_nwgw'])==8) {
			$postfeld['listenpreis']=$postfeld['listenpreis5'];
		}

		if ($postfeld['fin_zahlungsart']=='1') {
			$postfeld['fin_neben']=$postfeld['fin_neben2'];
		}

		$zahlenwerte=array(
			'fin_preis',
			'fin_neben',
			'fin_anzahlung',
			'fin_preis',
			'fin_werden',
			'fin_betrag',
			'fin_baranzahlung',
			'fin_kosten',
			'fin_teilzahlungspreis',
			'fin_effzins',
			'fin_zins',
			'fin_erstrate',
			'fin_schlussrate',
			'fin_zinsloskredithoehe',
			'vertrag_montagepreis',
			'vertrag_zulassung',
			'vertrag_transport',
			'vertrag_sonderpreis1',
			'vertrag_sonderpreis2',
			'vertrag_sonderpreis3',
			'vertrag_sonderpreis4',
			'vertrag_sonderpreis5',
			'vertrag_sonderpreis6',
			'vertrag_sonderpreis7',
			'vertrag_sonderpreis8',
			'vertrag_sonderpreis9',
			'vertrag_sonderpreis10',
			'vertrags_gwpreis',
			'fin_anzahlung2',
			'fin_abzug_inz',
			'fin_abzug_fin',
			'fin_abzug_abloese',
			'fin_abzug_vers',
			'fin_abzug_anz'
		);
		while (list($zkey, $zval)=@each($zahlenwerte)) {
			if ($cfg_kfzsuche_avag and $zval=='vertrags_gwpreis') {
				continue;
			}
			if (isset($postfeld[$zval])) {
				$postfeld[$zval]=str_replace(',', '.', $postfeld[$zval]);
			}
		}
		for ($zi1=11; $zi1<500; $zi1++) {
			if (isset($postfeld['vertrag_sonderpreis'.$zi])) {
				$postfeld['vertrag_sonderpreis'.$zi]=str_replace(',', '.', $postfeld['vertrag_sonderpreis'.$zi]);
			} else {
				break;
			}
		}
		$gespreis=0;
		// Bar:
//	alt	$inhalt=p4n_sb_strreplace('<<vkpreis>>', number_format($postfeld['fin_preis'], 2, ",","."), $inhalt);
        if ($_SESSION['cfg_kunde'] === 'carlo_koltes') {
            $postfeld['fin_preis'] = $postfeld['gesamt_ass'];
        }
		$gespreis+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['fin_preis'])), 2, ".", ""));

		$inhalt=p4n_sb_strreplace('<<bar_nebenleistung>>', number_format(doubleval($postfeld['fin_neben']), 2, ",","."), $inhalt);
		
		if ($_SESSION['cfg_kunde']=='carlo_koltes') {
			if (doubleval($postfeld['fin_anzahlung2'])==0) {
				$inhalt=p4n_sb_strreplace('<<zahlung_abholung>>', '', $inhalt);
			}
			if (doubleval($postfeld['fin_anzahlung'])==0) {
				$inhalt=p4n_sb_strreplace('<<zahlung_anzahlung>>', '', $inhalt);
			}
			
			if (isset($postfeld['fin_fuerexport'])) {
				$inhalt=p4n_sb_strreplace('<<exporttext_de>>', 'Zzgl. Einfuhrkosten '.$postfeld['fuerexpproz'].'%', $inhalt);
				$inhalt=p4n_sb_strreplace('<<exporttext_en>>', 'Plus Import Costs '.$postfeld['fuerexpproz'].'%', $inhalt);
				$res5=$db->select(
					$sql_tab['produktzuordnung'],
					array(
						$sql_tabs['produktzuordnung']['aktuellervkpreis_mw'],
						$sql_tabs['produktzuordnung']['differenzbesteuerung']
					),
					$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
				);
				if ($row5=$db->zeile($res5)) {
					$inhalt=p4n_sb_strreplace('<<vkpreis>>', preparePrice($row5[0]), $inhalt);
					$knetto1=doubleval($row5[0]);
					$kust1=doubleval(str_replace(',', '.', $postfeld['fin_preis2']))-$knetto1;
					$inhalt=p4n_sb_strreplace('<<mwst>>', preparePrice($kust1), $inhalt);
				}
			} else {
				$inhalt=p4n_sb_strreplace('<<exporttext_de>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<exporttext_en>>', '', $inhalt);
			}
			if (isset($postfeld['fin_ust25'])) {
				$inhalt=p4n_sb_strreplace('<<vkpreis>>', preparePrice(str_replace(',', '.', $postfeld['fin_preis2'])), $inhalt);
				$inhalt=p4n_sb_strreplace('<<summe>>', preparePrice(str_replace(',', '.', $postfeld['fin_preis2'])), $inhalt);
			}
            if (isset($postfeld['innergem_lieferung'])) {
                $inhalt=p4n_sb_strreplace('<<gesamt_ass>>', preparePrice($postfeld['netto_ass']), $inhalt);
                $inhalt=p4n_sb_strreplace('<<mwst_export_ass>>', '----', $inhalt);
            }
            $inhalt=p4n_sb_strreplace('<<gesamt_ass>>', preparePrice($postfeld['gesamt_ass']), $inhalt);
            $inhalt=p4n_sb_strreplace('<<netto_ass>>', preparePrice($postfeld['netto_ass']), $inhalt);
            $mwst_export_ass = $postfeld['mwst_export_ass'] ? preparePrice($postfeld['mwst_export_ass']) : '';
            $inhalt=p4n_sb_strreplace('<<mwst_export_ass>>', $mwst_export_ass, $inhalt);
		}
		if (isset($postfeld['vertrag5_hauspreis_euro2022_gw'])) {
			$inhalt=p4n_sb_strreplace('<<price_euro2022>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_hauspreis_euro2022_gw'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<price_kuna2023>>', number_format(7.5345*doubleval(str_replace(',', '.', $postfeld['vertrag5_hauspreis_euro2022_gw'])), 2, ",", "."), $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<zahlung_abholung>>', preparePrice($postfeld['fin_anzahlung2']), $inhalt);
		$inhalt=p4n_sb_strreplace('<<zahlung_anzahlung>>', preparePrice($postfeld['fin_anzahlung']), $inhalt);
		
		if (isset($postfeld['fin_ust25'])) {
			$inhalt=p4n_sb_strreplace('<<keinmwst_text>>', _KEIN_UST25_, $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<keinmwst_text>>', '', $inhalt);
		if (isset($postfeld['fin_ust'])) {
			$inhalt=p4n_sb_strreplace('<<mwst_text>>', 'zzgl. '.strval(intval($cfg_mwst*100)).'% USt. (Option zur Regelbesteuerung)', $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<mwst_text>>', '', $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<zahlung_minus_inz>>', number_format(doubleval($postfeld['fin_abzug_inz']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<zahlung_minus_fin>>', number_format(doubleval($postfeld['fin_abzug_fin']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<zahlung_minus_abloese>>', number_format(doubleval($postfeld['fin_abzug_abloese']), 2, ",","."), $inhalt);
		if ($cfg_kfzsuche_gerding) {
			if ($postfeld['fin_abzug_abloese_kredinst']=='-1') {
				$postfeld['fin_abzug_abloese_kredinst']='';
			}
			$inhalt=p4n_sb_strreplace('<<zahlung_minus_abloese_kred>>', $postfeld['fin_abzug_abloese_kredinst'], $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<zahlung_plus_abloese>>', number_format(doubleval($postfeld['fin_abzug_abloese']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<zahlung_minus_vers>>', number_format(doubleval($postfeld['fin_abzug_vers']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<zahlung_minus_anz>>', number_format(doubleval($postfeld['fin_abzug_anz']), 2, ",","."), $inhalt);
		
		if (doubleval(str_replace(',', '.', $postfeld['fin_anzahlung2']))==0) {
			$inhalt=p4n_sb_preg_replace('/<<za_abs>>.*<<za_abe>>/Uis', '', $inhalt);
		}
		$inhalt=p4n_sb_strreplace(array('<<za_abs>>', '<<za_abe>>'), '', $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<neben>>', number_format(doubleval($postfeld['fin_neben']), 2, ",","."), $inhalt);
		$gespreis+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['fin_neben'])), 2, ".", ""));
		$gespreis+=$summe_own;

		$usteuer=0;
		$vkpreis1=$postfeld['fin_preis'];
		
		$mitsatz_diffbest=false;
		if ($cfg_kfzsuche_avag) {
			$res5=$db->select(
				$sql_tab['produktzuordnung'],
				array(
					$sql_tabs['produktzuordnung']['differenzbesteuerung']
				),
				$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
			);
			if ($row5=$db->zeile($res5)) {
				if ($row5[0]!='1') {
					$postfeld['fin_ust']='1';
				} else {
					$mitsatz_diffbest=true;
				}
			}
			if (isset($postfeld['fin_ust3'])) {
				$postfeld['fin_ust']='1';
			}
		}
		
		if ($cfg_kfzsuche_vgw and isset($postfeld['vorlage_gw'])) {
			$postfeld['at_gwnetto']=$postfeld['at_netto'];
			$postfeld['at_gwnovasatz']=$postfeld['at_novasatz'];
			$postfeld['at_gwco2']=$postfeld['at_co2'];
			$postfeld['at_gwnova']=$postfeld['at_nova'];
			$postfeld['at_gwbonus']=$postfeld['at_bonus'];
			$postfeld['at_gwmwst']=$postfeld['at_mwst'];
		}
		if ($cfg_mboe_vorlagen and isset($postfeld['neuenova2'])) {
			$postfeld['neuenova']=1;
			unset($postfeld['neuenova2']);
			$postfeld['at_novasatz']=$postfeld['at_novasatzw'];
			$postfeld['at_co2']=$postfeld['at_co2w'];
			$postfeld['at_netto']=$postfeld['at_nettow'];
			$postfeld['at_bonus']=$postfeld['at_bonusw'];
			$postfeld['at_nova']=$postfeld['at_novaw'];
			$postfeld['at_mwst']=$postfeld['at_mwstw'];
			$postfeld['at_bonus2']=$postfeld['at_bonus2w'];
		}
		
		if (isset($postfeld['gw_diffbesth'])) {
			if (isset($postfeld['gw_diffbest'])) {
				$mitsatz_diffbest=true;
				unset($postfeld['fin_ust']);
			} else {
				$postfeld['fin_ust']='1';
			}
		}
		
		if (isset($postfeld['gwneuenova']) and (intval($postfeld['vertrag_nwgw'])==1 or ($cfg_kfzsuche_vgw and isset($postfeld['vorlage_gw'])))) {
			$inhalt=p4n_sb_strreplace('<<vkpreis>>', number_format(doubleval(str_replace(',', '.', $postfeld['at_gwnetto'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<novap>>', number_format(doubleval(str_replace(',', '.', $postfeld['at_gwnovasatz'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<co2>>', number_format(doubleval(str_replace(',', '.', $postfeld['at_gwco2'])), 0, ",", ""), $inhalt);
			$inhalt=p4n_sb_strreplace('<<nova>>', number_format(doubleval(str_replace(',', '.', $postfeld['at_gwnova'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<bonusmalus>>', number_format(doubleval(str_replace(',', '.', $postfeld['at_gwbonus'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<mwst>>', number_format(doubleval(str_replace(',', '.', $postfeld['at_gwmwst'])), 2, ",", "."), $inhalt);
		}
		if (isset($postfeld['dvs_steuer2']) and $postfeld['dvs_steuer']=='') {
			if ($postfeld['dvs_steuer2']!='') {
				$postfeld['dvs_steuer']=$postfeld['dvs_steuer2'];
			}
		}

		if (isset($postfeld['dvs_steuer'])) {
			if ($postfeld['dvs_steuer']=='R') {
				$postfeld['fin_ust']='1';
			}
			if ($postfeld['dvs_steuer']=='D') {
				unset($postfeld['fin_ust']);
				$mitsatz_diffbest=true;
			}

		}

		if (isset($postfeld['gme_foto'])) {
			$postfeld['fin_ust']='1';
		}
		
		if (false && $_SESSION['cfg_kunde']=='carlo_koltes') {
			require_once('inc/HtmlToRtf/HtmlToRtf.php');
			$res5=$db->select(
				$sql_tab['produktzuordnung'],
				array(
					$sql_tabs['produktzuordnung']['farbcode_innenausstattung'],
					$sql_tabs['produktzuordnung']['angebotstext_sprache1'],
					$sql_tabs['produktzuordnung']['angebotstext_sprache2']
				),
				$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
			);
			if ($row5=$db->zeile($res5)) {
                $htmlToRtf = 'HtmlToRtf\HtmlToRtf';
			    $text1 = new $htmlToRtf(html_entity_decode($row5[1]));
				$text2 = new $htmlToRtf(html_entity_decode($row5[2]));
//				$inhalt=p4n_sb_strreplace('<<innenausstattung>>', $row5[0], $inhalt);
//				$inhalt=p4n_sb_strreplace('<<angebotstext_sprache1>>', $text1->getRTF(), $inhalt);
//				$inhalt=p4n_sb_strreplace('<<angebotstext_sprache2>>', $text2->getRTF(), $inhalt);
/*				$text1 = new HtmlToRtf\HtmlToRtf(html_entity_decode($row5[1]));
				$text2 = new HtmlToRtf\HtmlToRtf(html_entity_decode($row5[2]));
				$inhalt=p4n_sb_strreplace('<<innenausstattung>>', $row5[0], $inhalt);
				$inhalt=p4n_sb_strreplace('<<angebotstext_sprache1>>', $text1->getRTF(), $inhalt);
				$inhalt=p4n_sb_strreplace('<<angebotstext_sprache2>>', $text2->getRTF(), $inhalt);
*/			}
//			$inhalt=p4n_sb_strreplace('<<innenausstattung>>', '', $inhalt);
//			$inhalt=p4n_sb_strreplace('<<angebotstext_sprache1>>', '', $inhalt);
//			$inhalt=p4n_sb_strreplace('<<angebotstext_sprache2>>', '', $inhalt);
		}
		
		if ($_SESSION['cfg_kunde']=='carlo_opel_carebus') {
			$res5=$db->select(
				$sql_tab['produktzuordnung'],
				$sql_tabs['produktzuordnung']['zusatz_text_8'],
				$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
			);
			if ($row5=$db->zeile($res5)) {
				$inhalt=p4n_sb_strreplace('<<zusatz_text_8>>', $row5[0], $inhalt);
				$inhalt=p4n_sb_strreplace('<<businessno>>', $row5[0], $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<zusatz_text_8>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<businessno>>', '', $inhalt);
		}
		
		if ($cfg_kfzsuche_austria and isset($postfeld['neuenova'])) {
			if (isset($postfeld['at_novasatz'])) {
				$postfeld['novasatz']=$postfeld['at_novasatz'];
			}
			if (isset($postfeld['at_bonus'])) {
				$postfeld['bonus_malus']=$postfeld['at_bonus'];
			}
		}
		
		$m_vkpreis1=0;
		if ($cfg_kfzsuche_steuerrauf and isset($postfeld['fin_ust'])) {
			$usteuer=doubleval(number_format($gespreis*$cfg_mwstn, 2, ".", ""));
			$vkpreis1=$gespreis+$usteuer;
		} else {
		if ($postfeld['fin_zahlungsart']=='3' and isset($postfeld['fin_ust'])) {
			if ($cfg_kfzsuche_norway and $cfg_kfzsuche_vgw and isset($postfeld['vorlage_gw'])) {
				$cfg_mwstn=0;
			}
			$usteuer=doubleval(number_format($gespreis-($gespreis/(1+$cfg_mwstn)), 2, ".", ""));
//			$usteuer=doubleval(number_format(doubleval($gespreis)*0.19, 2, ".", ""));
			$vkpreis1=$gespreis-$usteuer;

			if ($cfg_kfzsuche_austria) {
				$bonmal=doubleval(str_replace(',', '.', $postfeld['bonus_malus']));
				$localtaxp=doubleval(str_replace(',', '.', $postfeld['novasatz']));
				if (isset($postfeld['neuenova'])) {
					$vkpreis1=(($gespreis+$bonmal)/(1+$cfg_mwstn+$localtaxp/100));///(1+$localtaxp/100)
					$m_vkpreis1=doubleval(number_format($vkpreis1, 2, ".", ""));
					$m_vkpreis2=doubleval(number_format($vkpreis1, 2, ".", ""));
					$usteuer=str_replace(',', '.', $postfeld['at_mwst']);
					$postfeld['nova']=$postfeld['at_nova'];
					$vkpreis1=str_replace(',', '.', $postfeld['at_netto']);
					$inhalt=p4n_sb_strreplace('<<vkpreis>>', number_format(doubleval($vkpreis1), 2, ",", "."), $inhalt);
				} else {
					//$vkpreis1=($gespreis-$usteuer-($bonmal/(1+$cfg_mwstn)))/(1+$localtaxp/100);
					$vkpreis1=(($gespreis+$bonmal)/(1+$cfg_mwstn))/(1+$localtaxp/100);
					$m_vkpreis1=doubleval(number_format($vkpreis1, 2, ".", ""));
					$m_vkpreis2=doubleval(number_format($vkpreis1, 2, ".", ""));
					$usteuer=$vkpreis1*$cfg_mwstn;
				}
			}

//echo $vkpreis1.'/'.$gespreis.'/'.$usteuer;
//			die();
// alt:			$usteuer=doubleval($gespreis)*0.19;
//			$inhalt=p4n_sb_strreplace('<<mwst>>', number_format($usteuer, 2, ",","."), $inhalt);//$fin_gesamtpreis
		}

		}
		if (!isset($postfeld['nova']) and isset($postfeld['novasatz'])) {
			$postfeld['nova']=$vkpreis1*doubleval(str_replace(',', '.', $postfeld['novasatz']))/100;
		}
		
		if (isset($postfeld['neuenova'])) {
			$cfg_kfzsuche_nova_mitmwst=false;
		}
		
		if ($cfg_kfzsuche_nova_mitmwst) {
			$nova_orig=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['nova'])), 2, ".", ""));
			$nova_neu=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['nova']))*(1+$cfg_mwstn), 2, ".", ""));
			$inhalt=p4n_sb_strreplace('<<nova>>', number_format($nova_neu, 2, ",", "."), $inhalt);
//2012			$usteuer-=$nova_neu-$nova_orig;
		}
		
		if ($_SESSION['cfg_kunde']=='carlo_koltes') {
			if (isset($postfeld['fin_ust25'])) {
				$inhalt=p4n_sb_strreplace('<<mwst>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<vkpreis>>', '', $inhalt);
			}
		}
		
		if ($cfg_kfzsuche_levy and ($pid_istdiff or $diffbest)) {
			$inhalt=p4n_sb_strreplace('<<vkpreis_liste_netto>>', '', $inhalt);
		}
		
		if (isset($postfeld['nur_hauspreis'])) {
			for ($i=1; $i<=20; $i++) {
				$inhalt=p4n_sb_strreplace('<<pag_n'.$i.'>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<pag_b'.$i.'>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<sonderp'.$i.'_netto>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<sonderp'.$i.'>>', '', $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<vkpreis_liste_netto>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<vkpreis_liste>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<lpreis_sum_netto>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<lpreis_sum_br>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<transportp_netto>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<transportp>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<bpm>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<leges1n>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<leges1>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<leges2n>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<leges2>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<envtaxn>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<envtax>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<total_wo_btw>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<total_incl_btw>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<btw>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<taxnull>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<taxfull>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<taxp>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<pag_n_sum>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<pag_b_sum>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<sonderpx2_netto>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<sonderpx2>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<summe_ane2>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<summe_abr2>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_bpm>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_tax>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_total>>', '', $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<in2>>.*<<\/in2>>/Uis', '', $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<in3>>.*<<\/in3>>/Uis', '', $inhalt);
			
			$inhalt=p4n_sb_strreplace('<<inruil_bpm2>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_tax2>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_total2>>', '', $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<in22>>.*<<\/in22>>/Uis', '', $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<in32>>.*<<\/in32>>/Uis', '', $inhalt);
			
			$inhalt=p4n_sb_preg_replace('/<<starttb>>.*<<endtb>>/Uis', '', $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<tb1a>>.*<<tb1b>>/Uis', '', $inhalt);
			
			$inhalt=p4n_sb_strreplace('<<vkpreis_liste_nb>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<color_price_nb>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<trim_price_nb>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<total_incl_btw_p>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_bpm>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_tax>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_total>>', '', $inhalt);
			
			$inhalt=p4n_sb_strreplace('<<inruil_bpm2>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_tax2>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_total2>>', '', $inhalt);
			
			$inhalt=p4n_sb_strreplace('<<op_price_nb>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<disc_price_nb>>', '', $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<tb1a>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<tb1b>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<starttb>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<endtb>>', '', $inhalt);
		
		$mit_nachlass_oben=false;
		$m_sum_pag_nl=0;
		$nullprozn=0;
		$fullprozn=0;
		$inhalt=p4n_sb_strreplace('<<taxp>>', number_format($cfg_mwst*100, 2, ",", "."), $inhalt);
		$andere_susa1=0;
		$lt_abzug1=0;
		$lt_abzug2=0;
		if (!$cfg_kfzsuche_holland and intval($postfeld['net_listenpreis5'])==0) {
			$postfeld['net_listenpreis5']=doubleval(str_replace(',', '.', $postfeld['listenpreis5']))/(1+$cfg_mwst);
		}
		if ($cfg_greek) {
			$postfeld['net_listenpreis5']=(doubleval(str_replace(',', '.', $postfeld['listenpreis5']))-doubleval(str_replace(',', '.', $postfeld['lt_listenpreis5'])))/(1+$cfg_mwst);
			$lt_abzug1=doubleval(str_replace(',', '.', $postfeld['lt_listenpreis5']));
			for ($i=0; $i<=200; $i++) {
				$lt_abzug2+=doubleval(str_replace(',', '.', $postfeld['lt_aus5'.$i]));
			}
			$lt_abzug2+=doubleval(str_replace(',', '.', $postfeld['lt_farbe5']))+doubleval(str_replace(',', '.', $postfeld['lt_trim5']));
		}
		$listep=doubleval(str_replace(',', '.', $postfeld['net_listenpreis5']));
		if ($cfg_kfzsuche_holland) {

			$alle_netto=0;

			$abzug_diffb=0;
			if ($mitsatz_diffbest) {
				$postfeld['rest_bpm']=0;
				$postfeld['bpm']=0;

				$postfeld['net_listenpreis5']=$postfeld['listenpreis5'];
				$postfeld['net_farbe5']=$postfeld['vertrag5_farbepreis'];
				$postfeld['net_trim5']=$postfeld['vertrag5_trimpreis'];
			} elseif (intval($postfeld['pid'])>0) {

				if (isset($postfeld['vorlage_gw']) or $hat_ez_oder_km) {
					$postfeld['net_listenpreis5']=doubleval(str_replace(',', '.', $postfeld['listenpreis5']))-doubleval(str_replace(',', '.', $postfeld['rest_bpm']));
					$postfeld['net_listenpreis5']=$postfeld['net_listenpreis5']/(1+$cfg_mwst);
					$inhalt=p4n_sb_strreplace('<<tbpm>>', 'Rest BPM', $inhalt);
				} else {
					$postfeld['net_listenpreis5']=doubleval(str_replace(',', '.', $postfeld['listenpreis5']))-doubleval(str_replace(',', '.', $postfeld['lt_listenpreis5']));
					$postfeld['net_listenpreis5']=$postfeld['net_listenpreis5']/(1+$cfg_mwst);
					$inhalt=p4n_sb_strreplace('<<tbpm>>', 'BPM', $inhalt);
				}
/*
				$bpm1=doubleval(str_replace(',', '.', $postfeld['bpm']));
				$restbpm1=calc_rest_bpm($postfeld['kfz_datum_ez'], $bpm1);
				$postfeld['bpm']=$restbpm1;
				$neu_brutto1=doubleval(str_replace(',', '.', $postfeld['listenpreis5']));
				$postfeld['net_listenpreis5']=$neu_brutto1-doubleval(str_replace(',', '.', $restbpm1));
				$postfeld['net_listenpreis5']=$postfeld['net_listenpreis5']/(1+$cfg_mwst);
*/
			}
			if ($listep==0 and isset($postfeld['freiekonf'])) {
				if ($postfeld['freiekonf']=='1') {
					$postfeld['net_listenpreis5']=doubleval(str_replace(',', '.', $postfeld['listenpreis5']))/(1+$cfg_mwst);
					$listep=doubleval(str_replace(',', '.', $postfeld['net_listenpreis5']));
				}
			}
			$inhalt=p4n_sb_strreplace('<<tbpm>>', 'BPM', $inhalt);
			$bpm_raus=false;
			
			if (isset($postfeld['ohnemwstexport'])) {
				$postfeld['ohnebpm']=1;
				$postfeld['fin_ust_gk']=1;
			}
			
			if (isset($postfeld['ohnebpm'])) {
				$postfeld['rest_bpm']=0;
				$postfeld['bpm']=0;
				$bpm_raus=true;
			}
			if ($bpm_raus) {
				$postfeld['listenpreis5']=doubleval(str_replace(',', '.', $postfeld['listenpreis5']))-doubleval(str_replace(',', '.', $postfeld['lt_listenpreis5']));
				$postfeld['vertrag5_farbepreis']=doubleval(str_replace(',', '.', $postfeld['vertrag5_farbepreis']))-doubleval(str_replace(',', '.', $postfeld['lt_farbe5']));
				$postfeld['vertrag5_trimpreis']=doubleval(str_replace(',', '.', $postfeld['vertrag5_trimpreis']))-doubleval(str_replace(',', '.', $postfeld['lt_trim5']));
				if (intval($postfeld['vertrag_nwgw'])==8) {
					$postfeld['listenpreis']=$postfeld['listenpreis5'];
				}
			}
			$listep=doubleval(str_replace(',', '.', $postfeld['net_listenpreis5']));
			$alle_netto+=doubleval(str_replace(',', '.', $postfeld['net_listenpreis5']));
			$alle_netto+=doubleval(str_replace(',', '.', $postfeld['net_farbe5']));
			$andere_susa1+=doubleval(str_replace(',', '.', $postfeld['net_farbe5']));
			$alle_netto+=doubleval(str_replace(',', '.', $postfeld['net_trim5']));
			$andere_susa1+=doubleval(str_replace(',', '.', $postfeld['net_trim5']));
			$abzug_steuer1=0;
			for ($i=0; $i<=200; $i++) {
				if ($bpm_raus) {
					$postfeld['vertrag5_sonderpreis'.$i]=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderpreis'.$i]))-doubleval(str_replace(',', '.', $postfeld['lt_aus5'.$i]));
				}
				if ($mitsatz_diffbest) {
					$postfeld['net_aus5'.$i]=$postfeld['vertrag5_sonderpreis'.$i];
				}
				$alle_netto+=doubleval(str_replace(',', '.', $postfeld['net_aus5'.$i]));
				$andere_susa1+=doubleval(str_replace(',', '.', $postfeld['net_aus5'.$i]));
				if (isset($postfeld['vertrag5_zvat'.$i])) {
					if ($postfeld['vertrag5_zvat'.$i]=='1') {
						$nl_ne_t1=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderzpreis'.$i]));
						$abzug_steuer1+=$nl_ne_t1-$nl_ne_t1/(1+$cfg_mwst);
					}
				}
				$nl_ne_t1=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderzpreis'.$i]));
				$alle_netto+=$nl_ne_t1/(1+$cfg_mwst);
			}
			
			$m_sum_pag_nl=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['summe_preisa'])), 2, '.', ''));
			$soa_p2_nl=doubleval(number_format(doubleval($m_sum_pag_nl)/(1+$cfg_mwstn), 2, ".", ""));
			$soa_p2_nl_br=doubleval(number_format(doubleval($m_sum_pag_nl), 2, ".", ""));
			$preis_gesl_nl=0;
			$preis_gesl_nl+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_farbepreis'])), 2, ".", ""));
			$preis_gesl_nl+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_trimpreis'])), 2, ".", ""));
			$ve_zus=5;
			for ($auss_i=1; $auss_i<=500; $auss_i++) {
				$auss_iz=$auss_i;
				if ($_SESSION['cfg_kunde']=='carlo_opel_nl_mulders' and $cfg_kfzsuche_holland and intval($postfeld['vertrag_nwgw'])==8 and intval($postfeld['nwvorlage'])==1 and doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderpreis'.$auss_iz]))==0 and preg_match('/\:/', $postfeld['vertrag'.$ve_zus.'_sonder'.$auss_iz])) {
					continue;
				}
				if ($postfeld['vertrag'.$ve_zus.'_sonder'.$auss_iz]!='') {
					$preis_gesl_nl+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderpreis'.$auss_iz])), 2, ".", ""));
				}
				if ($postfeld['vertrag'.$ve_zus.'_sonderz'.$auss_iz]!='') {
					$preis_gesl_nl+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderzpreis'.$auss_iz])), 2, ".", ""));
				}
			}
			if (preg_match('/<<lpreis_sum_br_p>>/', $inhalt)) {
				$mit_nachlass_oben=true;
			}
			$inhalt=p4n_sb_strreplace('<<lpreis_sum_br_p>>', number_format($preis_gesl_nl-$m_sum_pag_nl+doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ',', '.'), $inhalt);
			$inhalt=p4n_sb_strreplace('<<lpreis_sum_netto_p>>', number_format($alle_netto-$soa_p2_nl, 2, ",","."), $inhalt);
			
			$inhalt=p4n_sb_strreplace('<<vkpreis_liste_netto>>', number_format(doubleval($listep), 2, ",","."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<lpreis_sum_netto>>', number_format(doubleval($alle_netto), 2, ",","."), $inhalt);
//			$inhalt=p4n_sb_strreplace('<<lpreis_sum_br>>', number_format($alle_netto, 2, ",","."), $inhalt);
			$fullprozn+=$alle_netto;
			$nl_transp_n=doubleval(str_replace(',', '.', $postfeld['vertrag5_transport']))/(1+$cfg_mwst);
			$fullprozn+=$nl_transp_n;

			if (isset($postfeld['rest_bpm']) and $postfeld['rest_bpm']!='') {
				$inhalt=p4n_sb_strreplace('<<bpm>>', number_format(doubleval(str_replace(',', '.', $postfeld['rest_bpm'])), 2, ",", "."), $inhalt);
				$nullprozn+=doubleval(str_replace(',', '.', $postfeld['rest_bpm']));
			} else {
				$inhalt=p4n_sb_strreplace('<<bpm>>', number_format(doubleval(str_replace(',', '.', $postfeld['bpm'])), 2, ",", "."), $inhalt);
				$nullprozn+=doubleval(str_replace(',', '.', $postfeld['bpm']));
			}

			$inhalt=p4n_sb_strreplace('<<leges1>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_leges1'])), 2, ",", "."), $inhalt);
			$leges1n=doubleval(str_replace(',', '.', $postfeld['vertrag5_leges1']));
			$nullprozn+=$leges1n;
			if (!isset($postfeld['fin_ust_gk'])) {
				$inhalt=p4n_sb_strreplace('<<leges1n>>', '', $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<leges1n>>', number_format(doubleval($leges1n), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<leges2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_leges2'])), 2, ",", "."), $inhalt);
			$leges2n=doubleval(str_replace(',', '.', $postfeld['vertrag5_leges2']));
			$nullprozn+=$leges2n;
			if (!isset($postfeld['fin_ust_gk'])) {
				$inhalt=p4n_sb_strreplace('<<leges2n>>', '', $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<leges2n>>', number_format(doubleval($leges2n), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<envtax>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_envtax'])), 2, ",", "."), $inhalt);
			$envtaxn=doubleval(str_replace(',', '.', $postfeld['vertrag5_envtax']))/(1+$cfg_mwst);
			$fullprozn+=$envtaxn;
			if (!isset($postfeld['fin_ust_gk'])) {
				$inhalt=p4n_sb_strreplace('<<envtaxn>>', '', $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<envtaxn>>', number_format(doubleval($envtaxn), 2, ",", "."), $inhalt);

			$inhalt=p4n_sb_strreplace('<<taxnull>>', number_format(doubleval($nullprozn), 2, ",", "."), $inhalt);
			$fullprozn_a=$fullprozn;
			$m_fullprozn_a=$fullprozn_a;
			if ($mitsatz_diffbest) {
				$abzug_diffb=$listep+$andere_susa1;
				$m_fullprozn_a-=$abzug_diffb;
			} else {
$soa_p=doubleval(str_replace(',', '.', $postfeld['summe_preisa']));
$soa_p2=doubleval(number_format(doubleval($soa_p)/(1+$cfg_mwst), 2, ".", ""));
$m_fullprozn_a-=$soa_p2;
			}
			$inhalt=p4n_sb_strreplace('<<taxfull>>', number_format($m_fullprozn_a, 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<marge>>', number_format($abzug_diffb, 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<btw>>', number_format($m_fullprozn_a*$cfg_mwst, 2, ",", "."), $inhalt);
			$m_btw1=$m_fullprozn_a*$cfg_mwst;
			$m_fullprozn_a2=$m_fullprozn_a-$soa_p2_nl;
			if ($mitsatz_diffbest) {
				$m_fullprozn_a2=$m_fullprozn_a-$soa_p2_nl_br;
			}
			$inhalt=p4n_sb_strreplace('<<taxfull_p>>', number_format($m_fullprozn_a2, 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<btw_p>>', number_format($m_fullprozn_a2*$cfg_mwst, 2, ",", "."), $inhalt);
			
			$nl_total_ohne=$nullprozn+$fullprozn;
//echo $nullprozn.' + '.$fullprozn.'<br>';
			
			$nl_total_ohne2=$nl_total_ohne-$soa_p2_nl;
			if ($mitsatz_diffbest) {
				$nl_total_ohne2=$nl_total_ohne-$soa_p2_nl_br;
			}
			$inhalt=p4n_sb_strreplace('<<total_wo_btw>>', number_format($nl_total_ohne, 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<total_wo_btw_p>>', number_format($nl_total_ohne2, 2, ",", "."), $inhalt);
			if ($mitsatz_diffbest) {
				$nl_total_mit=$nl_total_ohne+$m_fullprozn_a*$cfg_mwst;
				$nl_total_mit2=$nl_total_ohne2+($m_fullprozn_a*$cfg_mwst);
			} else {
				$nl_total_mit=$nl_total_ohne+$fullprozn_a*$cfg_mwst;
				$nl_total_mit2=$nl_total_ohne2+($m_fullprozn_a*$cfg_mwst);
			}
			if (isset($postfeld['ohnemwstexport'])) {
				$nl_total_mit-=$m_btw1;
				$nl_total_mit2-=$m_btw1;
			}
			$inhalt=p4n_sb_strreplace('<<total_incl_btw>>', number_format($nl_total_mit, 2, ",", "."), $inhalt);
			if (substr(number_format($nl_total_mit2, 2, ',', ''), -3)==',99') {
				$nl_total_mit2+=0.01;
			}
			if (substr(number_format($nl_total_mit2, 2, ',', ''), -3)==',01') {
				$nl_total_mit2-=0.01;
			}
			$inhalt=p4n_sb_strreplace('<<total_incl_btw_p>>', number_format($nl_total_mit2, 2, ",", "."), $inhalt);
			
			if (isset($postfeld['vertrags_ankauf'])) {
				if ($postfeld['nl_tradein6']=='1') {
					// BTW
					$inhalt=p4n_sb_strreplace('<<vertrags_margebtw>>', 'BTW', $inhalt);
				}
				if ($postfeld['nl_tradein6']=='2') {
					// Marge - in3 l�schen
					$inhalt=p4n_sb_strreplace('<<inruil>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis'])), 2, ",", "."), $inhalt);
					$inhalt=p4n_sb_strreplace('<<vertrags_margebtw>>', 'Marge', $inhalt);
					$inhalt=p4n_sb_preg_replace('/<<in3>>.*<<\/in3>>/Uis', '', $inhalt);
				}
				// 2:
				if ($postfeld['nl_tradein62']=='1') {
					// BTW
					$inhalt=p4n_sb_strreplace('<<vertrags_margebtw2>>', 'BTW', $inhalt);
				}
				if ($postfeld['nl_tradein62']=='2') {
					// Marge - in3 l�schen
					$inhalt=p4n_sb_strreplace('<<inruil2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis2'])), 2, ",", "."), $inhalt);
					$inhalt=p4n_sb_strreplace('<<vertrags_margebtw2>>', 'Marge', $inhalt);
					$inhalt=p4n_sb_preg_replace('/<<in32>>.*<<\/in32>>/Uis', '', $inhalt);
				}
			} else {
				$inhalt=p4n_sb_preg_replace('/<<in1>>.*<<\/in1>>/Uis', '', $inhalt);
				$inhalt=p4n_sb_preg_replace('/<<in2>>.*<<\/in2>>/Uis', '', $inhalt);
				$inhalt=p4n_sb_preg_replace('/<<in3>>.*<<\/in3>>/Uis', '', $inhalt);
				
				$inhalt=p4n_sb_preg_replace('/<<in12>>.*<<\/in12>>/Uis', '', $inhalt);
				$inhalt=p4n_sb_preg_replace('/<<in22>>.*<<\/in22>>/Uis', '', $inhalt);
				$inhalt=p4n_sb_preg_replace('/<<in32>>.*<<\/in32>>/Uis', '', $inhalt);
			}
			
			$inhalt=p4n_sb_strreplace('<<inruil>>', number_format(doubleval(str_replace(',', '.', $postfeld['nl_tradein1'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_bpm>>', number_format(doubleval(str_replace(',', '.', $postfeld['nl_tradein3'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_tax>>', number_format(doubleval(str_replace(',', '.', $postfeld['nl_tradein4'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_total>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis'])), 2, ",", "."), $inhalt);
			
			$inhalt=p4n_sb_strreplace('<<inruil2>>', number_format(doubleval(str_replace(',', '.', $postfeld['nl_tradein12'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_bpm2>>', number_format(doubleval(str_replace(',', '.', $postfeld['nl_tradein32'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_tax2>>', number_format(doubleval(str_replace(',', '.', $postfeld['nl_tradein42'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<inruil_total2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis2'])), 2, ",", "."), $inhalt);
			
			$nl_inz_p=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis'])), 2, ".", ""));
			$nl_inz_p2=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis2'])), 2, ".", ""));
			
			$nl_preisa=doubleval(str_replace(',', '.', $postfeld['summe_preisa']));
			$inhalt=p4n_sb_strreplace('<<te_betalen>>', number_format($nl_total_mit-$nl_inz_p-$nl_inz_p2-$nl_preisa, 2, ",", "."), $inhalt);
			
		}
		$inhalt=p4n_sb_strreplace('<<vertrags_deel>>', $postfeld['vertrags_gwez'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_deel2>>', $postfeld['vertrags_gwez2'], $inhalt);
		$inhalt=p4n_sb_strreplace(array('<<in1>>', '<</in1>>', '<<in2>>', '<</in2>>', '<<in3>>', '<</in3>>'), '', $inhalt);
		$inhalt=p4n_sb_strreplace(array('<<in12>>', '<</in12>>', '<<in22>>', '<</in22>>', '<<in32>>', '<</in32>>'), '', $inhalt);
		
		/*
		if (isset($postfeld['vertrags_ankauf_nuraufzahlung'])) {
			$inhalt=preg_replace('/<<inzna>>.*<<inzne>>/Uis', '', $inhalt);
		}
		$inhalt=str_replace(array('<<inzna>>', '<<inzne>>'), '', $inhalt);
		*/
		
		if ($cfg_kfzsuche_norway) {
			$x_ersetzer='x';
			if (isset($postfeld['no_vertragsort'])) {
				if ($postfeld['no_vertragsort']=='1') {
					$inhalt=p4n_sb_strreplace('<<selgers1>>', $x_ersetzer, $inhalt);
					$inhalt=p4n_sb_strreplace('<<selgers2>>', '', $inhalt);
				}
				if ($postfeld['no_vertragsort']=='2') {
					$inhalt=p4n_sb_strreplace('<<selgers1>>', '', $inhalt);
					$inhalt=p4n_sb_strreplace('<<selgers2>>', $x_ersetzer, $inhalt);
				}
			}
			$inhalt=p4n_sb_strreplace('<<selgers1>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<selgers2>>', '', $inhalt);
			
			$inhalt=p4n_sb_strreplace('<<no_keys>>', $postfeld['no_keys'], $inhalt);
			if ($postfeld['no_rapport']=='1') {
				$inhalt=p4n_sb_strreplace('<<rapport1>>', $x_ersetzer, $inhalt);
				$inhalt=p4n_sb_strreplace('<<rapport2>>', '', $inhalt);
			}
			if ($postfeld['no_rapport']=='2') {
				$inhalt=p4n_sb_strreplace('<<rapport1>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<rapport2>>', $x_ersetzer, $inhalt);
			}
			if ($postfeld['no_garanti']=='1') {
				$inhalt=p4n_sb_strreplace('<<garanti1>>', $x_ersetzer, $inhalt);
				$inhalt=p4n_sb_strreplace('<<garanti2>>', '', $inhalt);
			}
			if ($postfeld['no_garanti']=='2') {
				$inhalt=p4n_sb_strreplace('<<garanti1>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<garanti2>>', $x_ersetzer, $inhalt);
			}
			if (isset($postfeld['vertrag_liefer_janein1'])) {
				$inhalt=p4n_sb_strreplace('<<no_leveringstid>>', $x_ersetzer, $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<no_leveringstid>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<no_gjeld>>', number_format(doubleval($postfeld['fin_gjeld']), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<no_gjeld2>>', $postfeld['fin_gjeld2'], $inhalt);
			
			if (isset($postfeld['no_euimport'])) {
				$inhalt=p4n_sb_strreplace('<<no_euimport>>', $x_ersetzer, $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<no_euimport>>', '', $inhalt);
			
			if (isset($postfeld['no_unfallschaeden'])) {
				$inhalt=p4n_sb_strreplace('<<no_unfall>>', $x_ersetzer, $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<no_unfall>>', '', $inhalt);
			
			if (isset($postfeld['no_jahresabgabe'])) {
				$inhalt=p4n_sb_strreplace('<<no_arsavgift>>', $x_ersetzer, $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<no_arsavgift>>', '', $inhalt);
			
			if (isset($postfeld['no_vers1'])) {
				$inhalt=p4n_sb_strreplace('<<no_insu1>>', $x_ersetzer, $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<no_insu1>>', '', $inhalt);
			if (isset($postfeld['no_vers2'])) {
				$inhalt=p4n_sb_strreplace('<<no_insu2>>', $x_ersetzer, $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<no_insu2>>', '', $inhalt);
			if (isset($postfeld['no_vers3'])) {
				$inhalt=p4n_sb_strreplace('<<no_insu3>>', $x_ersetzer, $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<no_insu3>>', '', $inhalt);
			if (isset($postfeld['no_vers4'])) {
				$inhalt=p4n_sb_strreplace('<<no_insu4>>', $x_ersetzer, $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<no_insu4>>', '', $inhalt);
			if (isset($postfeld['no_vers5'])) {
				$inhalt=p4n_sb_strreplace('<<no_insu5>>', $x_ersetzer, $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<no_insu5>>', '', $inhalt);
			if (isset($postfeld['no_vers6'])) {
				$inhalt=p4n_sb_strreplace('<<no_insu6>>', $x_ersetzer, $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<no_insu6>>', '', $inhalt);
			
			$inhalt=p4n_sb_strreplace('<<no_insutext1>>', $postfeld['no_verstext1'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<no_insutext2>>', $postfeld['no_verstext2'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<no_insutext3>>', $postfeld['no_verstext3'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<no_insutext4>>', $postfeld['no_verstext4'], $inhalt);
			
			if (isset($postfeld['no_medeier'])) {
				$inhalt=p4n_sb_strreplace('<<medeier_name>>', $postfeld['no_medeier_name'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<medeier_pnr>>', $postfeld['no_medeier_personnr'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<medeier_plz>>', $postfeld['no_medeier_plz'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<medeier_ort>>', $postfeld['no_medeier_city'], $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<medeier_name>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<medeier_pnr>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<medeier_plz>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<medeier_ort>>', '', $inhalt);
		}
		
		if ($cfg_kfzsuche_norway) {
			if (isset($postfeld['no_fin'])) {
				$inhalt=p4n_sb_strreplace('<<nofin_base>>', $postfeld['nofin_base1'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_ek>>', $postfeld['nofin_ek'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_tradein>>', $postfeld['nofin_tradein'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_tradeinrest>>', $postfeld['nofin_tradein_rest'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_ektproz>>', $postfeld['nofin_pre_proz'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_ekt>>', $postfeld['nofin_pre'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_rest>>', $postfeld['nofin_remain'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_payout>>', $postfeld['nofin_payout'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_costs>>', $postfeld['nofin_costs'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_costs2>>', $postfeld['nofin_costs2'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_payout2>>', $postfeld['nofin_payout2'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_proz>>', $postfeld['nofin_proz'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_month>>', $postfeld['nofin_month'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_rate1>>', $postfeld['nofin_rate1'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_charge>>', $postfeld['nofin_charge'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_rate2>>', $postfeld['nofin_rate2'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_prozeff>>', $postfeld['nofin_prozeff'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_total>>', $postfeld['nofin_totalamount'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_kreditcost>>', $postfeld['nofin_creditcost'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<nofin_kredittotal>>', $postfeld['nofin_totalcredit'], $inhalt);
			} else {
				$inhalt=p4n_sb_preg_replace('/<<nofin1>>.*<<nofin2>>/Uis', '', $inhalt);
			}
			if (isset($postfeld['no_leas'])) {
				$inhalt=p4n_sb_strreplace('<<noleas_base1>>', $postfeld['noleas_base1'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_base2>>', $postfeld['noleas_base2'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_base3>>', $postfeld['noleas_base3'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_tax>>', $postfeld['noleas_tax'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_ekproz>>', $postfeld['noleas_pre_proz'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_ek>>', $postfeld['noleas_pre'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_reg>>', $postfeld['noleas_reg'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_konstant>>', $postfeld['noleas_konstant'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_sum1>>', $postfeld['noleas_summe1'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_restproz>>', $postfeld['noleas_remain_proz'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_rest>>', $postfeld['noleas_remain'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_manu>>', $postfeld['noleas_manuf'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_manuproz>>', $postfeld['noleas_manuf_proz'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_manu2>>', $postfeld['noleas_manuf2'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_own>>', $postfeld['noleas_own'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_ownproz>>', $postfeld['noleas_own_proz'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_own2>>', $postfeld['noleas_own2'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_restsum>>', $postfeld['noleas_remain_sum'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_month>>', $postfeld['noleas_month'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_km>>', $postfeld['noleas_km'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_costs>>', $postfeld['noleas_costs'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_charge>>', $postfeld['noleas_charge'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_proz>>', $postfeld['noleas_proz'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_amount1>>', $postfeld['noleas_amount1'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_amount2>>', $postfeld['noleas_amount2'], $inhalt);
				$inhalt=p4n_sb_strreplace('<<noleas_amount3>>', $postfeld['noleas_amount3'], $inhalt);
			} else {
				$inhalt=p4n_sb_preg_replace('/<<noleas1>>.*<<noleas2>>/Uis', '', $inhalt);
			}
		}
		$inhalt=p4n_sb_strreplace(array('<<nofin1>>', '<<nofin2>>', '<<noleas1>>', '<<noleas2>>'), '', $inhalt);
		
		// GW NoVA:
		if ($cfg_kfzsuche_vgw and isset($postfeld['vorlage_gw']) and !$mitsatz_diffbest) {
			unset($postfeld['gw_diffbest']);
			$postfeld['gw_novabeiverkauf']=1;
		}
		if (isset($postfeld['gw_diffbest'])) {
			$inhalt=p4n_sb_preg_replace('/<<gwnv1a>>.*<<gwnv1b>>/Uis', '', $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<gwnv2a>>.*<<gwnv2b>>/Uis', '', $inhalt);
		}
		if (!isset($postfeld['gw_novabeiverkauf'])) {
			$inhalt=p4n_sb_preg_replace('/<<gwnv2a>>.*<<gwnv2b>>/Uis', '', $inhalt);
		}
		$inhalt=p4n_sb_strreplace(array('<<gwnv1a>>', '<<gwnv1b>>', '<<gwnv2a>>', '<<gwnv2b>>'), '', $inhalt);
		
		// Serienausst. untereinander:
		$alle_ser1='';
		$ausst_zeile='';
		$ausst_zeileg='';
		if (preg_match('/<<aso1>>(.*)<<aso2>>/Uis', $inhalt, $ma)) {
			$ausst_zeile=$ma[1];
			$ausst_zeileg=$ma[0];
		}
		$alle_ser2='';
		for ($xi=1; $xi<=200; $xi++) {
			if (isset($postfeld['vertrag5_sonders'.$xi])) {
				if ($postfeld['vertrag5_sonders'.$xi]!='') {
					$alle_ser1.=kfzs_klammerraus($postfeld['vertrag5_sonders'.$xi]).' \\par ';
					$zeilet=$ausst_zeile;
					if ($cfg_mboe_vorlagen) {
						$auscode1=kfzs_holecode($postfeld['vertrag5_sonders'.$xi]);
						$auste1=trim(str_replace('('.$auscode1.')', '', $postfeld['vertrag5_sonders'.$xi]));
						$zeilet=p4n_sb_strreplace('<<op_text>>', $auscode1."\t".$auste1, $zeilet);
					} else {
						$zeilet=p4n_sb_strreplace('<<op_text>>', kfzs_klammerraus($postfeld['vertrag5_sonders'.$xi]), $zeilet);
					}
					$alle_ser2.=$zeilet;
				}
			}
		}
		$alle_ser1=p4n_mb_string('substr',$alle_ser1, 0, -p4n_mb_string('strlen',' \\par '));
		if ($alle_ser2!='' and (intval($postfeld['nwvorlage'])==3 or intval($postfeld['vertrag_nwgw'])==1)) {
			$inhalt=p4n_sb_strreplace($ausst_zeileg, $alle_ser2, $inhalt);
			$inhalt=p4n_sb_strreplace(array('<<aso1s>>', '<<aso1e>>'), '', $inhalt);
		} else {
			$inhalt=p4n_sb_preg_replace('/<<aso1s>>.*<<aso1e>>/Uis', '', $inhalt);
		}
		
		if (intval($postfeld['nwvorlage'])==2) {
			$inhalt=p4n_sb_strreplace('<<s_options>>', $alle_ser1, $inhalt);
			$inhalt=p4n_sb_strreplace(array('<<s_optionss>>', '<<s_optionse>>'), '', $inhalt);
		} else {
			$inhalt=p4n_sb_preg_replace('/<<s_optionss>>.*<<s_optionse>>/Uis', '', $inhalt);
		}
		
		$summenpreis_bn=0;
		$preise_netto=false;
		if (isset($postfeld['fin_ust_gk'])) {
			$preise_netto=true;
		}

        if ($cfg_fhd) {
            if ($konf_quelle === 'FHD' && preg_match('/<<start_fin>>.*<<ende_fin>>/Uis', $inhalt, $m)) {
                $finData = !empty($postfeld['fin_data']) ? unserialize(base64_decode($postfeld['fin_data'])) : false;
                if (!empty($postfeld['fin_data_show']) && is_array($finData)) {
                    $anzahlung = doubleval($finData['anzahlung']);
                    $restzahlung = doubleval($finData['restzahlung']);
                    $monatsrate = doubleval($finData['monatsrate']);
                    if ($preise_netto) {
                        if (isset($finData['anzahlung_net'])) {
                            $anzahlung = doubleval($finData['anzahlung_net']);
                        } else {
                            $anzahlung = $anzahlung / (1 + $cfg_mwst);
                        }
                        if (isset($finData['restzahlung_net'])) {
                            $restzahlung = doubleval($finData['restzahlung_net']);
                        } else {
                            $restzahlung = $restzahlung / (1 + $cfg_mwst);
                        }
                        if (isset($finData['monatsrate_net'])) {
                            $monatsrate = doubleval($finData['monatsrate_net']);
                        } else {
                            $monatsrate = $monatsrate / (1 + $cfg_mwst);
                        }
                    }
                    $inhalt=p4n_sb_strreplace('<<anzahlung>>', number_format($anzahlung, 2, ",", "."), $inhalt);
                    $inhalt=p4n_sb_strreplace('<<restzahlung>>', number_format($restzahlung, 2, ",", "."), $inhalt);
                    $inhalt=p4n_sb_strreplace('<<monatsrate>>', number_format($monatsrate, 2, ",", "."), $inhalt);
                    $inhalt=p4n_sb_strreplace('<<jahreslaufleistung>>', $finData['jahreslaufleistung'], $inhalt);
                    $inhalt=p4n_sb_strreplace('<<effektivzins>>', $finData['effektivzins'], $inhalt);
                    $inhalt=p4n_sb_strreplace('<<laufzeit>>', $finData['laufzeit'], $inhalt);
                    $inhalt=p4n_sb_strreplace('<<start_fin>>', '', $inhalt);
                    $inhalt=p4n_sb_strreplace('<<ende_fin>>', '', $inhalt);
                } else {
                    $inhalt=p4n_sb_strreplace($m[0], '', $inhalt);
                }
            }
            if (preg_match('/<<start_warranty>>.*<<ende_warranty>>/Uis', $inhalt, $m)) {
                if (doubleval($postfeld['vertrag5_garantie']) > 0) {
                    $garantie_preis = doubleval($postfeld['vertrag5_garantie']);
                    if ($preise_netto) {
                        if (isset($postfeld['vertrag5_garantie_net'])) {
                            $garantie_preis = doubleval($postfeld['vertrag5_garantie_net']);
                        } else {
                            $garantie_preis = $garantie_preis / (1 + $cfg_mwst);
                        }
                    }
                    $inhalt=p4n_sb_strreplace('<<garantie_text>>', $postfeld['garantie_text'], $inhalt);
                    $inhalt=p4n_sb_strreplace('<<garantie_preis>>', number_format($garantie_preis, 2, ",", "."), $inhalt);
                    $inhalt=p4n_sb_strreplace('<<start_warranty>>', '', $inhalt);
                    $inhalt=p4n_sb_strreplace('<<ende_warranty>>', '', $inhalt);
                } else {
                    $inhalt=p4n_sb_strreplace($m[0], '', $inhalt);
                }
            }
            $inhalt=p4n_sb_strreplace('<<fzg_beschreibung>>', $postfeld['fzg_beschreibung'], $inhalt);
        }
        if ($cfg_mazda_conf && $konf_quelle === 'Mazda') {
            $inhalt=p4n_sb_strreplace('<<farbcode>>', kfzs_holecode($postfeld['vertrag5_farbe']), $inhalt);
        }
        $inhalt=p4n_sb_strreplace('<<start_fin>>', '', $inhalt);
        $inhalt=p4n_sb_strreplace('<<ende_fin>>', '', $inhalt);
		
		if ($cfg_mboe_vorlagen) {
			if ($cfg_kfzsuche_tausenderpunkt and $cfg_nova_wltp) {
				$postfeld['listenpreis5']=str_replace('.', '', $postfeld['listenpreis5']);
			}
			if (preg_match('/,/', $postfeld['listenpreis5'])) {
				$postfeld['listenpreis5']=str_replace(',', '.', $postfeld['listenpreis5']);
			}
			if ($cfg_kfzsuche_tausenderpunkt and $cfg_nova_wltp) {
				$postfeld['vertrag5_farbepreis']=str_replace('.', '', $postfeld['vertrag5_farbepreis']);
			}
			if (preg_match('/,/', $postfeld['vertrag5_farbepreis'])) {
				$postfeld['vertrag5_farbepreis']=str_replace(',', '.', $postfeld['vertrag5_farbepreis']);
			}
			if ($cfg_kfzsuche_tausenderpunkt and $cfg_nova_wltp) {
				$postfeld['vertrag5_trimpreis']=str_replace('.', '', $postfeld['vertrag5_trimpreis']);
			}
			if (preg_match('/,/', $postfeld['vertrag5_trimpreis'])) {
				$postfeld['vertrag5_trimpreis']=str_replace(',', '.', $postfeld['vertrag5_trimpreis']);
			}
			$listep_mitbm=(doubleval($postfeld['listenpreis5'])+doubleval($postfeld['bonus_malus']))/(1+$cfg_mwst+(doubleval($postfeld['at_novasatz'])/100));
		}
		
        // Farbe:
		$inhalt=p4n_sb_strreplace('<<color>>', kfzs_codenachvorne($postfeld['vertrag5_farbe']), $inhalt);
		$inhalt=p4n_sb_strreplace('<<color2>>', kfzs_klammerraus($postfeld['vertrag5_farbe']), $inhalt);
		$inhalt=p4n_sb_strreplace('<<color3>>', $postfeld['vertrag5_farbe'], $inhalt);
		if (!isset($postfeld['fin_ust_gk'])) {
			$inhalt=p4n_sb_strreplace('<<color_net>>', '', $inhalt);
		}
		if (!$cfg_kfzsuche_holland and intval($postfeld['net_farbe5'])==0) {
			$postfeld['net_farbe5']=doubleval(str_replace(',', '.', $postfeld['vertrag5_farbepreis']))/(1+$cfg_mwst);
		}
		if (isset($postfeld['tamsen_keinepreisausst'])) {
			$inhalt=p4n_sb_strreplace('<<color_price_nb>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<color_net>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<color_price>>', '', $inhalt);
		}
		if ($preise_netto) {
			$inhalt=p4n_sb_strreplace('<<color_price_nb>>', number_format(doubleval(str_replace(',', '.', $postfeld['net_farbe5'])), 2, ",", "."), $inhalt);
			$summenpreis_bn+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['net_farbe5'])), 2, ".", ""));
		} else {
			$inhalt=p4n_sb_strreplace('<<color_price_nb>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_farbepreis'])), 2, ",", "."), $inhalt);
			$summenpreis_bn+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_farbepreis'])), 2, ".", ""));
		}
		$inhalt=p4n_sb_strreplace('<<color_net>>', number_format(doubleval(str_replace(',', '.', $postfeld['net_farbe5'])), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<color_price>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_farbepreis'])), 2, ",", "."), $inhalt);
		// Trim:
		$inhalt=p4n_sb_strreplace('<<trim>>', kfzs_codenachvorne($postfeld['vertrag5_trim']), $inhalt);
		$inhalt=p4n_sb_strreplace('<<trim2>>', kfzs_klammerraus($postfeld['vertrag5_trim']), $inhalt);
		$inhalt=p4n_sb_strreplace('<<trim3>>', $postfeld['vertrag5_trim'], $inhalt);
		if (!isset($postfeld['fin_ust_gk'])) {
			$inhalt=p4n_sb_strreplace('<<trim_net>>', '', $inhalt);
		}
		if (!$cfg_kfzsuche_holland and intval($postfeld['net_trim5'])==0) {
			$postfeld['net_trim5']=doubleval(str_replace(',', '.', $postfeld['vertrag5_trimpreis']))/(1+$cfg_mwst);
		}
		if (isset($postfeld['tamsen_keinepreisausst'])) {
			$inhalt=p4n_sb_strreplace('<<trim_price_nb>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<trim_net>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<trim_price>>', '', $inhalt);
		}
		if ($preise_netto) {
			$inhalt=p4n_sb_strreplace('<<trim_price_nb>>', number_format(doubleval(str_replace(',', '.', $postfeld['net_trim5'])), 2, ",", "."), $inhalt);
			$summenpreis_bn+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['net_trim5'])), 2, ".", ""));
		} else {
			$inhalt=p4n_sb_strreplace('<<trim_price_nb>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_trimpreis'])), 2, ",", "."), $inhalt);
			$summenpreis_bn+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_trimpreis'])), 2, ".", ""));
		}
		$inhalt=p4n_sb_strreplace('<<trim_net>>', number_format(doubleval(str_replace(',', '.', $postfeld['net_trim5'])), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<trim_price>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_trimpreis'])), 2, ",", "."), $inhalt);
		
		if ($preise_netto) {
			if (isset($postfeld['tamsen_keinepreisausst'])) {
				
			} else {
				if ($cfg_mboe_vorlagen) {
					$inhalt=p4n_sb_strreplace('<<vkpreis_liste_nb>>', number_format(doubleval($listep_mitbm), 2, ",","."), $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<vkpreis_liste_nb>>', number_format(doubleval($listep), 2, ",","."), $inhalt);
			}
			$summenpreis_bn+=$listep;
		} else {
			if (isset($postfeld['tamsen_keinepreisausst'])) {
				
			} else {
				$inhalt=p4n_sb_strreplace('<<vkpreis_liste_nb>>', number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ",","."), $inhalt);
			}
			$summenpreis_bn+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ".", ""));
		}
		
		if ($preise_netto) {
			if ($cfg_kfzsuche_holland) {
				$inhalt=p4n_sb_strreplace('<<eub>>', 'Prijs excl. BTW / BPM', $inhalt);
			} else {
				$inhalt=p4n_sb_strreplace('<<eub>>', 'Preis exkl. MwSt.', $inhalt);
			}
		}
		if ($cfg_kfzsuche_holland) {
			$inhalt=p4n_sb_strreplace('<<eub>>', 'Prijs incl. BTW / BPM', $inhalt);
		} else {
			$inhalt=p4n_sb_strreplace('<<eub>>', 'Preis inkl. MwSt.', $inhalt);
		}
		
		$startfett_nl='';
		$endfett_nl='';
		if ($cfg_kfzsuche_holland) {
			if ($_SESSION['cfg_kunde']=='carlo_opel_nl_automotions' or $cfg_nl_bold_contract) {
				$startfett_nl='{\b ';
				$endfett_nl='}';
			}
		}
		
		$merke_aus_netto=0;
		
		// Pakete:
		$ausst_zeile='';
		$ausst_zeileg='';
		if (preg_match('/<<pak1>>(.*)<<pak2>>/Uis', $inhalt, $ma)) {
			$ausst_zeile=$ma[1];
			$ausst_zeileg=$ma[0];
		}
		$alle_pak1='';
		$m_pakc='';
		$alle_weg=array();
		
		
		if ($cfg_mboe_vorlagen or $cfg_kfzsuche_mitpak) {
			$alle_pak_zus='';
			$alle_pak_zus2='';
			$schoncode=array();
			
			$allecodeszuaus=array();
			for ($xi=1; $xi<=300; $xi++) {
				if (isset($postfeld['vertrag5_sonders'.$xi]) and $postfeld['vertrag5_sonders'.$xi]!='') {
					$auscode1=kfzs_holecode($postfeld['vertrag5_sonders'.$xi]);
					$auste1=trim(str_replace('('.$auscode1.')', '', $postfeld['vertrag5_sonders'.$xi]));
					$allecodeszuaus[$auste1]=$auscode1;
				}
				if (isset($postfeld['vertrag5_sonder'.$xi]) and $postfeld['vertrag5_sonder'.$xi]!='') {
					$auscode1=kfzs_holecode($postfeld['vertrag5_sonder'.$xi]);
					$auste1=trim(str_replace('('.$auscode1.')', '', $postfeld['vertrag5_sonder'.$xi]));
					$allecodeszuaus[$auste1]=$auscode1;
				}
			}
			for ($xi=1; $xi<=300; $xi++) {
				if (isset($postfeld['vertrag5_sonder'.$xi])) {
					if ($postfeld['vertrag5_sonder'.$xi]!='') {
						$auscode1=kfzs_holecode($postfeld['vertrag5_sonder'.$xi]);
						$m_pakc=$auscode1;
						if (!isset($schoncode[$m_pakc]) and !isset($alle_weg[$xi]) and (p4n_mb_string('substr',$postfeld['vertrag5_sonder'.$xi], 0, p4n_mb_string('strlen',$m_pakc)+1)==$m_pakc.':' or (($cfg_mboe_vorlagen or $cfg_kfzsuche_mitpak) and (isset($postfeld['vertrag5_allesubs'][$m_pakc]) or preg_match('/paket/i', $postfeld['vertrag5_sonder'.$xi])) ))) {
							$zeilet=$ausst_zeile;
								$preist=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderpreis'.$xi]));
								$preistn=doubleval(str_replace(',', '.', $postfeld['net_aus5'.$xi]));
								if (!$cfg_kfzsuche_holland and $preistn==0) {
									$preistn=$preist/(1+$cfg_mwst);
								}
								$preist1='';
								$preist1n='';
								if ($preist!=0) {
									$preist1=number_format(doubleval($preist), 2, ",", ".");
									$preist1n=number_format(doubleval($preistn), 2, ",", ".");
									$zeilet=p4n_sb_strreplace('<<op_text>>', kfzs_codenachvorne($postfeld['vertrag5_sonder'.$xi]), $zeilet);
									$zeilet=p4n_sb_strreplace('<<op_text2>>', kfzs_codenachvorne($postfeld['vertrag5_sonder'.$xi]), $zeilet);
								}
								$zeilet=p4n_sb_strreplace('<<op_text>>', kfzs_codenachvorne($postfeld['vertrag5_sonder'.$xi]), $zeilet);
								$zeilet=p4n_sb_strreplace('<<op_text2>>', kfzs_codenachvorne($postfeld['vertrag5_sonder'.$xi]), $zeilet);
								if ($preise_netto) {
									$zeilet=p4n_sb_strreplace('<<op_price_nb>>', $preist1n, $zeilet);
									$summenpreis_bn+=doubleval($preistn);
								} else {
									$zeilet=p4n_sb_strreplace('<<op_price_nb>>', $preist1, $zeilet);
									$summenpreis_bn+=doubleval($preist);
								}
								$merke_aus_netto+=doubleval($preistn);
								if (!isset($postfeld['fin_ust_gk'])) {
									$preist1n='';
								}
								$zeilet=p4n_sb_strreplace('<<op_netprice>>', $preist1n, $zeilet);
								$zeilet=p4n_sb_strreplace('<<op_price>>', $preist1, $zeilet);
								if ($preist!=0) {
									$alle_pak_zus2.=$zeilet;
								} else {
									$alle_pak_zus.=$zeilet;
								}
								
								if (isset($postfeld['vertrag5_allesubs'][$m_pakc])) {
										$alle_subaus1=explode('<br>', $postfeld['vertrag5_allesubs'][$m_pakc]);
										while (list($keys, $vals)=@each($alle_subaus1)) {
											if ($vals=='') {
												continue;
											}
											$zeilet=$ausst_zeile;
											$vals=substr($vals, 1);
											if (isset($allecodeszuaus[$vals])) {
												$vals="\t".$allecodeszuaus[$vals]."\t".$vals;
											}
											$zeilet=p4n_sb_strreplace('<<op_text>>', "".$vals, $zeilet);
											$zeilet=p4n_sb_strreplace('<<op_text2>>', "".$vals, $zeilet);
											$zeilet=p4n_sb_strreplace('<<op_price_nb>>', '', $zeilet);
											$zeilet=p4n_sb_strreplace('<<op_netprice>>', '', $zeilet);
											$zeilet=p4n_sb_strreplace('<<op_price>>', '', $zeilet);
											if ($preist!=0) {
												$alle_pak_zus2.=$zeilet;
											} else {
												$alle_pak_zus.=$zeilet;
											}
										}
								}
								
								$alle_weg[$xi]=1;
							$schoncode[$m_pakc]=1;
						}
					}
				}
			}
			$alle_pak1=$alle_pak_zus.$alle_pak_zus2;
			if ($alle_pak1!='') {
				$inhalt=p4n_sb_strreplace($ausst_zeileg, $alle_pak1, $inhalt);
				$inhalt=p4n_sb_strreplace(array('<<pak1s>>', '<<pak1e>>'), '', $inhalt);
			} else {
				$inhalt=p4n_sb_preg_replace('/<<pak1s>>.*<<pak1e>>/Uis', '', $inhalt);
			}
		}
		
		if (!$cfg_mboe_vorlagen and !$cfg_kfzsuche_mitpak) {
		
		for ($xi=1; $xi<=100; $xi++) {
			if (isset($postfeld['vertrag5_sonder'.$xi])) {
				if ($postfeld['vertrag5_sonder'.$xi]!='') {
					$auscode1=kfzs_holecode($postfeld['vertrag5_sonder'.$xi]);
					$m_pakc=$auscode1;
					$anz_pak=0;
					if ($m_pakc!='') {
						$alle_pak_zus='';
						$alle_pak_zus2='';
						for ($xi2=$xi; $xi2<=100; $xi2++) {
							if (!isset($alle_weg[$xi2]) and (p4n_mb_string('substr',$postfeld['vertrag5_sonder'.$xi2], 0, p4n_mb_string('strlen',$m_pakc)+1)==$m_pakc.':' or (($cfg_mboe_vorlagen or $cfg_kfzsuche_mitpak) and (isset($postfeld['vertrag5_allesubs'][$m_pakc]) or preg_match('/paket/i', $postfeld['vertrag5_sonder'.$xi2])) ))) {
								if ($postfeld['vertrag5_sonder'.$xi2]=='') {
									continue;
								}
								$anz_pak++;
								$zeilet=$ausst_zeile;
								$preist=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderpreis'.$xi2]));
								$preistn=doubleval(str_replace(',', '.', $postfeld['net_aus5'.$xi2]));
								if (!$cfg_kfzsuche_holland and $preistn==0) {
									$preistn=$preist/(1+$cfg_mwst);
								}
								$preist1='';
								$preist1n='';
								if ($preist!=0) {
									$preist1=number_format(doubleval($preist), 2, ",", ".");
									$preist1n=number_format(doubleval($preistn), 2, ",", ".");
									if ($cfg_mboe_vorlagen) {
										$zeilet=p4n_sb_strreplace('<<op_text>>', kfzs_codenachvorne($postfeld['vertrag5_sonder'.$xi2]), $zeilet);
										$zeilet=p4n_sb_strreplace('<<op_text2>>', kfzs_codenachvorne($postfeld['vertrag5_sonder'.$xi2]), $zeilet);
									} else {
										$zeilet=p4n_sb_strreplace('<<op_text>>', kfzs_codenachvorne(trim(p4n_mb_string('substr',$postfeld['vertrag5_sonder'.$xi2], p4n_mb_string('strlen',$m_pakc.':')))), $zeilet);
										$zeilet=p4n_sb_strreplace('<<op_text2>>', kfzs_klammerraus(trim(p4n_mb_string('substr',$postfeld['vertrag5_sonder'.$xi2], p4n_mb_string('strlen',$m_pakc.':')))), $zeilet);	//'{\b '. .'}'
									}
								}
								if ($cfg_mboe_vorlagen) {
									$zeilet=p4n_sb_strreplace('<<op_text>>', $postfeld['vertrag5_sonder'.$xi2], $zeilet);
									$zeilet=p4n_sb_strreplace('<<op_text2>>', $postfeld['vertrag5_sonder'.$xi2], $zeilet);
								} else {
									$zeilet=p4n_sb_strreplace('<<op_text>>', kfzs_codenachvorne(trim(p4n_mb_string('substr',$postfeld['vertrag5_sonder'.$xi2], p4n_mb_string('strlen',$m_pakc.':')))), $zeilet);
									$zeilet=p4n_sb_strreplace('<<op_text2>>', kfzs_klammerraus(trim(p4n_mb_string('substr',$postfeld['vertrag5_sonder'.$xi2], p4n_mb_string('strlen',$m_pakc.':')))), $zeilet);
								}
								if (isset($postfeld['tamsen_keinepreisausst'])) {
									$zeilet=p4n_sb_strreplace('<<op_price_nb>>', '', $zeilet);
									$zeilet=p4n_sb_strreplace('<<op_netprice>>', '', $zeilet);
									$zeilet=p4n_sb_strreplace('<<op_price>>', '', $zeilet);
								}
								if ($preise_netto) {
									$zeilet=p4n_sb_strreplace('<<op_price_nb>>', $preist1n, $zeilet);
									$summenpreis_bn+=doubleval($preistn);
								} else {
									$zeilet=p4n_sb_strreplace('<<op_price_nb>>', $preist1, $zeilet);
									$summenpreis_bn+=doubleval($preist);
								}
								$merke_aus_netto+=doubleval($preistn);
								if (!isset($postfeld['fin_ust_gk'])) {
									$preist1n='';
								}
								$zeilet=p4n_sb_strreplace('<<op_netprice>>', $preist1n, $zeilet);
								$zeilet=p4n_sb_strreplace('<<op_price>>', $preist1, $zeilet);
								if ($preist!=0) {
									$alle_pak_zus2.=$zeilet;
								} else {
									$alle_pak_zus.=$zeilet;
								}
								$alle_weg[$xi2]=1;
								
								if ($cfg_mboe_vorlagen) {
									if (isset($postfeld['vertrag5_allesubs'][$m_pakc])) {
										$alle_subaus1=explode('<br>', $postfeld['vertrag5_allesubs'][$m_pakc]);
										while (list($keys, $vals)=@each($alle_subaus1)) {
											if ($vals=='') {
												continue;
											}
											$zeilet=$ausst_zeile;
											$zeilet=p4n_sb_strreplace('<<op_text>>', "\t".$vals, $zeilet);
											$zeilet=p4n_sb_strreplace('<<op_text2>>', "\t".$vals, $zeilet);
											$zeilet=p4n_sb_strreplace('<<op_price_nb>>', '', $zeilet);
											$zeilet=p4n_sb_strreplace('<<op_netprice>>', '', $zeilet);
											$zeilet=p4n_sb_strreplace('<<op_price>>', '', $zeilet);
											if ($preist!=0) {
												$alle_pak_zus2.=$zeilet;
											} else {
												$alle_pak_zus.=$zeilet;
											}
										}
									}
								}
							}
						}
					}
					if ($anz_pak>0) {
							$zeilet=$ausst_zeile;
							$zeilet=p4n_sb_strreplace('<<op_text>>', $startfett_nl.kfzs_codenachvorne($postfeld['vertrag5_sonder'.$xi]).$endfett_nl, $zeilet);
							$zeilet=p4n_sb_strreplace('<<op_text2>>', $startfett_nl.kfzs_klammerraus($postfeld['vertrag5_sonder'.$xi]).$endfett_nl, $zeilet);
							$preist=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderpreis'.$xi]));
							$preistn=doubleval(str_replace(',', '.', $postfeld['net_aus5'.$xi]));
							if (!$cfg_kfzsuche_holland and $preistn==0) {
								$preistn=$preist/(1+$cfg_mwst);
							}
							$preist1='';
							$preist1n='';
							if ($preist!=0) {
								$preist1=number_format($preist, 2, ",", ".");
								$preist1n=number_format($preistn, 2, ",", ".");
							}
								if (isset($postfeld['tamsen_keinepreisausst'])) {
									$zeilet=p4n_sb_strreplace('<<op_price_nb>>', '', $zeilet);
									$zeilet=p4n_sb_strreplace('<<op_netprice>>', '', $zeilet);
									$zeilet=p4n_sb_strreplace('<<op_price>>', '', $zeilet);
								}
								if ($preise_netto) {
									$zeilet=p4n_sb_strreplace('<<op_price_nb>>', $preist1n, $zeilet);
									$summenpreis_bn+=doubleval($preistn);
								} else {
									$zeilet=p4n_sb_strreplace('<<op_price_nb>>', $preist1, $zeilet);
									$summenpreis_bn+=doubleval($preist);
								}
								if (!isset($postfeld['fin_ust_gk'])) {
									$preist1n='';
								}
							$zeilet=p4n_sb_strreplace('<<op_netprice>>', $preist1n, $zeilet);
							$zeilet=p4n_sb_strreplace('<<op_price>>', $preist1, $zeilet);
							if ($cfg_mboe_vorlagen) {
								$alle_pak1.=$alle_pak_zus.$alle_pak_zus2;
							} else {
								$alle_pak1.=$zeilet.$alle_pak_zus.$alle_pak_zus2;
							}
							
							$m_pakc=$auscode1;
							
							if ($cfg_mboe_vorlagen) {
									if (isset($postfeld['vertrag5_allesubs'][$m_pakc])) {
										$alle_subaus1=explode('<br>', $postfeld['vertrag5_allesubs'][$m_pakc]);
										while (list($keys, $vals)=@each($alle_subaus1)) {
											if ($vals=='') {
												continue;
											}
											$zeilet=$ausst_zeile;
											$zeilet=p4n_sb_strreplace('<<op_text>>', "\t".$vals, $zeilet);
											$zeilet=p4n_sb_strreplace('<<op_text2>>', "\t".$vals, $zeilet);
											$zeilet=p4n_sb_strreplace('<<op_price_nb>>', '', $zeilet);
											$zeilet=p4n_sb_strreplace('<<op_netprice>>', '', $zeilet);
											$zeilet=p4n_sb_strreplace('<<op_price>>', '', $zeilet);
											if ($preist!=0) {
												$alle_pak_zus2.=$zeilet;
											} else {
												$alle_pak_zus.=$zeilet;
											}
										}
									}
							}
							
							
							if (!$cfg_mboe_vorlagen) {
								$alle_weg[$xi]=1;	// weggenommen 21.09.2018
							}
							
					}
				}
			}
		}
		if ($alle_pak1!='') {
			$inhalt=p4n_sb_strreplace($ausst_zeileg, $alle_pak1, $inhalt);
			$inhalt=p4n_sb_strreplace(array('<<pak1s>>', '<<pak1e>>'), '', $inhalt);
		} else {
			$inhalt=p4n_sb_preg_replace('/<<pak1s>>.*<<pak1e>>/Uis', '', $inhalt);
		}
		
		}
		
		// H�ndlerausst.:
		$ausst_zeile='';
		$ausst_zeileg='';
		if (preg_match('/<<opt1>>(.*)<<opt2>>/Uis', $inhalt, $ma)) {
			$ausst_zeile=$ma[1];
			$ausst_zeileg=$ma[0];
		}
		$alle_opt1='';
		for ($xi=1; $xi<=100; $xi++) {
			if (!isset($alle_weg[$xi]) and isset($postfeld['vertrag5_sonder'.$xi])) {
				if ($postfeld['vertrag5_sonder'.$xi]!='') {
					$zeilet=$ausst_zeile;
							if ($cfg_mboe_vorlagen) {
								$zeilet=p4n_sb_strreplace('<<op_text>>', kfzs_codenachvorne($postfeld['vertrag5_sonder'.$xi]), $zeilet);
								$zeilet=p4n_sb_strreplace('<<op_text2>>', kfzs_codenachvorne($postfeld['vertrag5_sonder'.$xi]), $zeilet);
							} else {
								$zeilet=p4n_sb_strreplace('<<op_text>>', $startfett_nl.kfzs_codenachvorne($postfeld['vertrag5_sonder'.$xi]).$endfett_nl, $zeilet);
								$zeilet=p4n_sb_strreplace('<<op_text2>>', $startfett_nl.kfzs_klammerraus($postfeld['vertrag5_sonder'.$xi]).$endfett_nl, $zeilet);
							}
							$preist=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderpreis'.$xi]));
							$preistn=doubleval(str_replace(',', '.', $postfeld['net_aus5'.$xi]));
							if (!$cfg_kfzsuche_holland and $preistn==0) {
								$preistn=$preist/(1+$cfg_mwst);
							}
							$preist1='';
							$preist1n='';
							if ($preist!=0) {
								$preist1=number_format($preist, 2, ",", ".");
								$preist1n=number_format($preistn, 2, ",", ".");
							}
								if (isset($postfeld['tamsen_keinepreisausst'])) {
									$zeilet=p4n_sb_strreplace('<<op_price_nb>>', '', $zeilet);
									$zeilet=p4n_sb_strreplace('<<op_netprice>>', '', $zeilet);
									$zeilet=p4n_sb_strreplace('<<op_price>>', '', $zeilet);
								}
								if ($preise_netto) {
									$zeilet=p4n_sb_strreplace('<<op_price_nb>>', $preist1n, $zeilet);
									$summenpreis_bn+=doubleval($preistn);
								} else {
									$zeilet=p4n_sb_strreplace('<<op_price_nb>>', $preist1, $zeilet);
									$summenpreis_bn+=doubleval($preist);
								}
								$merke_aus_netto+=doubleval($preistn);
								if (!isset($postfeld['fin_ust_gk'])) {
									$preist1n='';
								}
							$zeilet=p4n_sb_strreplace('<<op_netprice>>', $preist1n, $zeilet);
							$zeilet=p4n_sb_strreplace('<<op_price>>', $preist1, $zeilet);
							$alle_opt1.=$zeilet;
							$alle_weg[$xi]=1;
				}
			}
		}
		
		$merke_werkpreis=$summenpreis_bn;
		
		if ($alle_opt1!='') {
			$inhalt=p4n_sb_strreplace($ausst_zeileg, $alle_opt1, $inhalt);
			$inhalt=p4n_sb_strreplace(array('<<opt1s>>', '<<opt1e>>'), '', $inhalt);
		} else {
			$inhalt=p4n_sb_preg_replace('/<<opt1s>>.*<<opt1e>>/Uis', '', $inhalt);
		}
		
		if (isset($postfeld['nur_hauspreis']) or ($_SESSION['cfg_kunde']=='carlo_opel_tamsen' and $alle_opt1=='' and $alle_pak1=='')) {
			$inhalt=p4n_sb_preg_replace('/<<s1a>>.*<<s1b>>/Uis', '', $inhalt);
		}
		
		$merke_aus_netto+=doubleval(str_replace(',', '.', $postfeld['net_farbe5']));
		$merke_aus_netto+=doubleval(str_replace(',', '.', $postfeld['net_trim5']));
		$inhalt=p4n_sb_strreplace('<<ausst_netto>>', number_format($merke_aus_netto, 2, ",", "."), $inhalt);
		
		$ausst_zeile_sub='';
		$ausst_zeile_sub2='';
		if (preg_match('/<<s1a>>(.*)<<s1b>>/Uis', $inhalt, $ma)) {
			$ausst_zeile_sub=$ma[1];
			$ausst_zeile_sub2=$ma[0];
			if ($cfg_kfzsuche_holland) {
				$ausst_zeile_sub=p4n_sb_strreplace('<<op_text2>>', 'Subtotaal '.($preise_netto?'excl.':'incl.').' BTW/BPM', $ausst_zeile_sub);
			} else {
				$ausst_zeile_sub=p4n_sb_strreplace('<<op_text2>>', 'Zwischensumme '.($preise_netto?'exkl.':'inkl.').' MwSt.', $ausst_zeile_sub);
			}
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_price_nb>>', number_format(doubleval($summenpreis_bn), 2, ",", "."), $ausst_zeile_sub);
			$inhalt=p4n_sb_strreplace($ausst_zeile_sub2, $ausst_zeile_sub, $inhalt);
			$inhalt=p4n_sb_strreplace(array('<<sub1s>>', '<<sub1e>>'), '', $inhalt);
		}
		$inhalt=p4n_sb_preg_replace('/<<sub1s>>.*<<sub1e>>/Uis', '', $inhalt);
		if (isset($postfeld['tamsen_keinepreisausst'])) {
			$inhalt=p4n_sb_strreplace('<<vkpreis_liste_nb>>', number_format(doubleval($summenpreis_bn), 2, ",","."), $inhalt);
		}
		
		if ($cfg_kfzsuche_carlokonf_ausschluss) {
			$inhalt=p4n_sb_strreplace('<<ausst_nichtgewaehlt>>', $postfeld['konf_nicht_gewaehlte'], $inhalt);
		}
		
		// Zubeh�r:
		$ausst_zeile='';
		$ausst_zeileg='';
		if (preg_match('/<<acc1>>(.*)<<acc2>>/Uis', $inhalt, $ma)) {
			$ausst_zeile=$ma[1];
			$ausst_zeileg=$ma[0];
		}
		$alle_acc1='';
		for ($xi=1; $xi<=30; $xi++) {
			if (isset($postfeld['vertrag5_sonderz'.$xi])) {
				if ($postfeld['vertrag5_sonderz'.$xi]!='') {
					if (isset($postfeld['vertrag5_zvat'.$xi])) {
						if ($postfeld['vertrag5_zvat'.$xi]=='0') {
							
						} else {
							continue;
						}
					}
					$zeilet=$ausst_zeile;
							$zeilet=p4n_sb_strreplace('<<op_text>>', $startfett_nl.kfzs_codenachvorne($postfeld['vertrag5_sonderz'.$xi]).$endfett_nl, $zeilet);
							$zeilet=p4n_sb_strreplace('<<op_text2>>', $startfett_nl.kfzs_klammerraus($postfeld['vertrag5_sonderz'.$xi]).$endfett_nl, $zeilet);
							$preist=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderzpreis'.$xi]));
							$preistn=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderzpreis'.$xi]))/(1+$cfg_mwst), 2, ".", ""));
							$preist1='';
							$preist1n='';
							if ($preist!=0) {
								$preist1=number_format($preist, 2, ",", ".");
								$preist1n=number_format($preistn, 2, ",", ".");
							}
								if ($preise_netto) {
									$zeilet=p4n_sb_strreplace('<<op_price_nb>>', $preist1n, $zeilet);
									$summenpreis_bn+=doubleval($preistn);
								} else {
									$zeilet=p4n_sb_strreplace('<<op_price_nb>>', $preist1, $zeilet);
									$summenpreis_bn+=doubleval($preist);
								}
								if (!isset($postfeld['fin_ust_gk'])) {
									$preist1n='';
								}
							$zeilet=p4n_sb_strreplace('<<op_netprice>>', $preist1n, $zeilet);
							$zeilet=p4n_sb_strreplace('<<op_price>>', $preist1, $zeilet);
							$alle_acc1.=$zeilet;
				}
			}
		}
		// Transport:
			$ausst_zeile_sub=$ausst_zeile;
			$transp1=$postfeld['vertrag_transport'];
			if ($postfeld['vertrag_nwgw']=='8') {
				$transp1=$postfeld['vertrag5_transport'];
			}
			if ($postfeld['vertrag_nwgw']=='1') {
				$transp1=$postfeld['vertrag_transport2'];
			}
			$transp1=doubleval(str_replace(',', '.', $transp1));
			$transp2=doubleval(str_replace(',', '.', number_format(doubleval(str_replace(',', '.', $transp1))/(1+$cfg_mwst), 2, ",", "")));
			if ($preise_netto) {
				$transp1=$transp2;
			}
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_text2>>', ($cfg_kfzsuche_holland?'Kosten rijklaar maken:':_BEREITSTELLUNGSKOSTEN_), $ausst_zeile_sub);
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_price_nb>>', number_format($transp1, 2, ",", "."), $ausst_zeile_sub);
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_netprice>>', '', $ausst_zeile_sub);
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_price>>', '', $ausst_zeile_sub);
			if ($transp1!=0) {
				$summenpreis_bn+=$transp1;
				$alle_acc1.=$ausst_zeile_sub;
			}
		// Verwijderingsbijdrage:
			$ausst_zeile_sub=$ausst_zeile;
			$transp1=$postfeld['vertrag5_neben'];
			if ($cfg_kfzsuche_holland) {
				$transp1=$postfeld['vertrag5_envtax'];
			}
			$transp1=doubleval(str_replace(',', '.', $transp1));
			$transp2=doubleval(str_replace(',', '.', number_format(doubleval(str_replace(',', '.', $transp1))/(1+$cfg_mwst), 2, ",", "")));
			if ($preise_netto) {
				$transp1=$transp2;
			}
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_text2>>', ($cfg_kfzsuche_holland?'Verwijderingsbijdrage:':_ZULASSUNG_NEBENKOSTEN_), $ausst_zeile_sub);
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_price_nb>>', number_format($transp1, 2, ",", "."), $ausst_zeile_sub);
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_netprice>>', '', $ausst_zeile_sub);
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_price>>', '', $ausst_zeile_sub);
			if ($transp1!=0) {
				$summenpreis_bn+=$transp1;
				$alle_acc1.=$ausst_zeile_sub;
			}
		if ($alle_acc1!='') {
			$inhalt=p4n_sb_strreplace($ausst_zeileg, $alle_acc1, $inhalt);
			$inhalt=p4n_sb_strreplace(array('<<acc1s>>', '<<acc1e>>'), '', $inhalt);
		} else {
			$inhalt=p4n_sb_preg_replace('/<<acc1s>>.*<<acc1e>>/Uis', '', $inhalt);
		}
		
		if (isset($postfeld['nur_hauspreis']) or ($_SESSION['cfg_kunde']=='carlo_opel_tamsen' and $alle_acc1=='')) {
			$inhalt=p4n_sb_preg_replace('/<<s2a>>.*<<s2b>>/Uis', '', $inhalt);
		}
		
		$ausst_zeile_sub='';
		$ausst_zeile_sub2='';
		if (preg_match('/<<s2a>>(.*)<<s2b>>/Uis', $inhalt, $ma)) {
			$ausst_zeile_sub=$ma[1];
			$ausst_zeile_sub2=$ma[0];
			if ($cfg_kfzsuche_holland) {
				$ausst_zeile_sub=p4n_sb_strreplace('<<op_text2>>', 'Subtotaal '.($preise_netto?'excl.':'incl.').' BTW/BPM', $ausst_zeile_sub);
			} else {
				$ausst_zeile_sub=p4n_sb_strreplace('<<op_text2>>', 'Zwischensumme '.($preise_netto?'exkl.':'inkl.').' MwSt.', $ausst_zeile_sub);
			}
			//$ausst_zeile_sub=p4n_sb_strreplace('<<op_text2>>', 'Subtotaal '.($preise_netto?'excl.':'incl.').' BTW/BPM', $ausst_zeile_sub);
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_price_nb>>', number_format(doubleval($summenpreis_bn), 2, ",", "."), $ausst_zeile_sub);
			$inhalt=p4n_sb_strreplace($ausst_zeile_sub2, $ausst_zeile_sub, $inhalt);
			$inhalt=p4n_sb_strreplace(array('<<sub2s>>', '<<sub2e>>'), '', $inhalt);
		}
		$inhalt=p4n_sb_preg_replace('/<<sub2s>>.*<<sub2e>>/Uis', '', $inhalt);
		
		
		$ausst_zeile='';
		$ausst_zeileg='';
		if (preg_match('/<<ad1>>(.*)<<ad2>>/Uis', $inhalt, $ma)) {
			$ausst_zeile=$ma[1];
			$ausst_zeileg=$ma[0];
		}
		$alle_disc1='';
		for ($auss_i=1; $auss_i<=10; $auss_i++) {
			if (isset($postfeld['preisa_d'.$auss_i])) {
				// and (doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrpreis'.$auss_i]))!=0 or $cfg_kfzsuche_preisangl_null)
				if ($postfeld['vertrag5_sonderr'.$auss_i]!='' or doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrpreis'.$auss_i]))!=0) {
					$ausst_zeile_sub=$ausst_zeile;
					$transp1=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrpreis'.$auss_i]));
					$preistn=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrpreis'.$auss_i]))/(1+$cfg_mwstn), 2, ".", ""));
					if (!isset($postfeld['netto_vertrag5_sonderrpreis'.$auss_i])) {
						$preistn2=$preistn;
					} else {
						$preistn2=doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_sonderrpreis'.$auss_i]));
					}
					$preistproz=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrppreis'.$auss_i]));
					if ($cfg_mboe_vorlagen) {
						$preistn=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrpreis'.$auss_i]))/(1+$cfg_mwstn+(doubleval($postfeld['at_novasatz'])/100)), 2, ".", ""));
					}
					$zus_kort1='';
					$pre_kort1='';
					if ($transp1>0) {
						$zus_kort1='-';
						if ($cfg_mboe_vorlagen) {
							$pre_kort1='-';
							$zus_kort1='';
						}
					}
					$zusadt='';
					if ($cfg_mboe_vorlagen and isset($postfeld['vertrag5_sonderrppreis'.$auss_i]) and $postfeld['vertrag5_sonderrppreis'.$auss_i]!='') {
						$zusadt=' ('.number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrppreis'.$auss_i])), 2, ",", "").' %)';
					}
					$ausst_zeile_sub=p4n_sb_strreplace('<<adisctext>>', $postfeld['vertrag5_sonderr'.$auss_i].$zusadt, $ausst_zeile_sub);
					if ($preise_netto) {
						$ausst_zeile_sub=p4n_sb_strreplace('<<adiscprice>>', $pre_kort1.number_format($preistn, 2, ",", ".").$zus_kort1, $ausst_zeile_sub);
					} else {
						$ausst_zeile_sub=p4n_sb_strreplace('<<adiscprice>>', $pre_kort1.number_format($transp1, 2, ",", ".").$zus_kort1, $ausst_zeile_sub);
					}
					
					$ausst_zeile_sub=p4n_sb_strreplace('<<adiscprice_n>>', number_format($preistn2, 2, ",", "."), $ausst_zeile_sub);
					$ausst_zeile_sub=p4n_sb_strreplace('<<adiscprice_b>>', number_format($transp1, 2, ",", "."), $ausst_zeile_sub);
					$ausst_zeile_sub=p4n_sb_strreplace('<<adiscperc>>', number_format($preistproz, 2, ",", "."), $ausst_zeile_sub);
					
					$alle_disc1.=$ausst_zeile_sub;
				}
			}
		}
		if ($cfg_kfzsuche_alldisc_sep and $alle_disc1!='') {
			$inhalt=p4n_sb_strreplace($ausst_zeileg, $alle_disc1, $inhalt);
			$inhalt=p4n_sb_strreplace(array('<<alldisc1>>', '<<alldisc2>>'), '', $inhalt);
		} else {
			$inhalt=p4n_sb_preg_replace('/<<alldisc1>>.*<<alldisc2>>/Uis', '', $inhalt);
		}
		
		// Discount:
		$ist_mit_disc=false;
		if ((isset($postfeld['summe_preisa_d']) or $cfg_kfzsuche_nlsumme_immer) and doubleval(str_replace(',', '.', $postfeld['summe_preisa']))!=0) {
			$ist_mit_disc=true;
			$inhalt=p4n_sb_strreplace('<<disc_price>>', number_format(doubleval(str_replace(',', '.', $postfeld['summe_preisa'])), 2, ",", "."), $inhalt);
			$preistn=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['summe_preisa']))/(1+$cfg_mwstn), 2, ".", ""));
			$zus_kort0='';
			$zus_kort1='';
			if ($preistn>0) {
				if ($cfg_kfzsuche_holland) {
					$zus_kort1='-';
				} else {
					$zus_kort0='-';
				}
			}
			if ($preise_netto) {
				$inhalt=p4n_sb_strreplace('<<disc_price_nb>>', $zus_kort0.number_format($preistn, 2, ",", ".").$zus_kort1, $inhalt);
				$summenpreis_bn-=doubleval($preistn);
			} else {
				$inhalt=p4n_sb_strreplace('<<disc_price_nb>>', $zus_kort0.number_format(doubleval(str_replace(',', '.', $postfeld['summe_preisa'])), 2, ",", ".").$zus_kort1, $inhalt);
				$summenpreis_bn-=doubleval(doubleval(str_replace(',', '.', $postfeld['summe_preisa'])));
			}
			if (!isset($postfeld['fin_ust_gk'])) {
				$inhalt=p4n_sb_strreplace('<<disc_netprice>>', '', $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<disc_netprice>>', number_format($preistn, 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace(array('<<disc1s>>', '<<disc1e>>'), '', $inhalt);
		} else {
			$inhalt=p4n_sb_preg_replace('/<<disc1s>>.*<<disc1e>>/Uis', '', $inhalt);
		}
		
		if (!$ist_mit_disc or !$preise_netto) {
			$inhalt=p4n_sb_preg_replace('/<<sub3s>>.*<<sub3e>>/Uis', '', $inhalt);
		}
		
		$inhalt=p4n_sb_strreplace('<<disc_price>>', '', $inhalt);
		
		if (isset($postfeld['nur_hauspreis']) or ($_SESSION['cfg_kunde']=='carlo_opel_tamsen' and !$ist_mit_disc)) {
			$inhalt=p4n_sb_preg_replace('/<<s3a>>.*<<s3b>>/Uis', '', $inhalt);
		}
		$ausst_zeile_sub='';
		$ausst_zeile_sub2='';
		if (preg_match('/<<s3a>>(.*)<<s3b>>/Uis', $inhalt, $ma)) {
			$ausst_zeile_sub=$ma[1];
			$ausst_zeile_sub2=$ma[0];
			if ($cfg_kfzsuche_holland) {
				$ausst_zeile_sub=p4n_sb_strreplace('<<op_text2>>', 'Totaal bedrag '.($preise_netto?'excl.':'incl.').' BTW/BPM', $ausst_zeile_sub);
			} else {
				$ausst_zeile_sub=p4n_sb_strreplace('<<op_text2>>', 'Gesamtsumme '.($preise_netto?'exkl.':'inkl.').' MwSt.', $ausst_zeile_sub);
			}
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_price_nb>>', number_format(doubleval($summenpreis_bn), 2, ",", "."), $ausst_zeile_sub);
			$inhalt=p4n_sb_strreplace($ausst_zeile_sub2, $ausst_zeile_sub, $inhalt);
			$inhalt=p4n_sb_strreplace(array('<<sub3s>>', '<<sub3e>>'), '', $inhalt);
		}
		$inhalt=p4n_sb_preg_replace('/<<sub3s>>.*<<sub3e>>/Uis', '', $inhalt);
		
		$ausst_zeile_sub='';
		$ausst_zeile_sub2='';
		if (preg_match('/<<wo1a>>(.*)<<wo1b>>/Uis', $inhalt, $ma)) {
			$ausst_zeile_sub=$ma[1];
			$ausst_zeile_sub_m=$ausst_zeile_sub;
			$ausst_zeile_sub2=$ma[0];
			
			if ($preise_netto) {
				// BTW:
				$ausst_zeile_sub=$ausst_zeile_sub_m;
				$transp1=$m_btw1-$abzug_steuer1;
				$transp1_anz=$transp1;
				if (isset($postfeld['ohnemwstexport'])) {
					$transp1_anz=0;
				}
				$ausst_zeile_sub=p4n_sb_strreplace('<<op_text2>>', 'BTW '.number_format($cfg_mwst*100, 2, ",", ".").'%:', $ausst_zeile_sub);
				$ausst_zeile_sub=p4n_sb_strreplace('<<op_price_nb>>', number_format($transp1_anz, 2, ",", "."), $ausst_zeile_sub);
				if ($transp1!=0 and !isset($postfeld['nur_hauspreis'])) {
					$summenpreis_bn+=$transp1_anz;
					$ausst_zeile_sub_ges.=$ausst_zeile_sub;
				}
				// BPM:
				$ausst_zeile_sub=$ausst_zeile_sub_m;
				$transp1=doubleval(str_replace(',', '.', number_format(doubleval(str_replace(',', '.', $postfeld['bpm'])), 2, ",", "")));
				if (isset($postfeld['rest_bpm']) and $postfeld['rest_bpm']!='') {
					$transp1=doubleval(str_replace(',', '.', number_format(doubleval(str_replace(',', '.', $postfeld['rest_bpm'])), 2, ",", "")));
				}
				$ausst_zeile_sub=p4n_sb_strreplace('<<op_text2>>', 'BPM:', $ausst_zeile_sub);
				$ausst_zeile_sub=p4n_sb_strreplace('<<op_price_nb>>', number_format($transp1, 2, ",", "."), $ausst_zeile_sub);
				if ($transp1!=0 and !isset($postfeld['nur_hauspreis'])) {
					$summenpreis_bn+=$transp1;
					$ausst_zeile_sub_ges.=$ausst_zeile_sub;
				}
			}
			for ($xi=1; $xi<=30; $xi++) {
			if (isset($postfeld['vertrag5_sonderz'.$xi])) {
				if ($postfeld['vertrag5_sonderz'.$xi]!='' and isset($postfeld['vertrag5_zvat'.$xi])) {
					if ($postfeld['vertrag5_zvat'.$xi]=='0') {
						continue;
					}
					$zeilet=$ausst_zeile_sub_m;
							$zeilet=p4n_sb_strreplace('<<op_text>>', kfzs_codenachvorne($postfeld['vertrag5_sonderz'.$xi]), $zeilet);
							$zeilet=p4n_sb_strreplace('<<op_text2>>', kfzs_klammerraus($postfeld['vertrag5_sonderz'.$xi]), $zeilet);
							$preist=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderzpreis'.$xi]));
							$preistn=$soa_p2=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderzpreis'.$xi]))/(1+$cfg_mwst), 2, ".", ""));
							$preist1='';
							$preist1n='';
							if ($preist!=0) {
								$preist1=number_format($preist, 2, ",", ".");
								$preist1n=number_format($preistn, 2, ",", ".");
							}
							$zeilet=p4n_sb_strreplace('<<op_price_nb>>', $preist1, $zeilet);
							$summenpreis_bn+=doubleval($preist);
							$zeilet=p4n_sb_strreplace('<<op_netprice>>', $preist1n, $zeilet);
							$zeilet=p4n_sb_strreplace('<<op_price>>', $preist1, $zeilet);
							$ausst_zeile_sub_ges.=$zeilet;
				}
			}
			}
			// Leges1:
			$ausst_zeile_sub=$ausst_zeile_sub_m;
			$transp1=$postfeld['vertrag5_leges1'];
			$transp1=doubleval(str_replace(',', '.', $transp1));
			$transp2=number_format(doubleval(str_replace(',', '.', $transp1))/(1+$cfg_mwst), 2, ",", ".");
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_text2>>', 'Leges 1:', $ausst_zeile_sub);
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_price_nb>>', number_format($transp1, 2, ",", "."), $ausst_zeile_sub);
			if ($transp1!=0) {
				$summenpreis_bn+=$transp1;
				$ausst_zeile_sub_ges.=$ausst_zeile_sub;
			}
			// Leges2:
			$ausst_zeile_sub=$ausst_zeile_sub_m;
			$transp1=$postfeld['vertrag5_leges2'];
			$transp1=doubleval(str_replace(',', '.', $transp1));
			$transp2=number_format(doubleval(str_replace(',', '.', $transp1))/(1+$cfg_mwst), 2, ",", ".");
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_text2>>', 'Leges 2:', $ausst_zeile_sub);
			$ausst_zeile_sub=p4n_sb_strreplace('<<op_price_nb>>', number_format($transp1, 2, ",", "."), $ausst_zeile_sub);
			if ($transp1!=0) {
				$summenpreis_bn+=$transp1;
				$ausst_zeile_sub_ges.=$ausst_zeile_sub;
			}
			
			$inhalt=p4n_sb_strreplace($ausst_zeile_sub2, $ausst_zeile_sub_ges, $inhalt);
			$inhalt=p4n_sb_strreplace(array('<<wo_vat_s>>', '<<wo_vat_e>>'), '', $inhalt);
		}
		$inhalt=p4n_sb_preg_replace('/<<wo_vat_s>>.*<<wo_vat_e>>/Uis', '', $inhalt);
		
		$nachlaesset='';
		$nlpsum=0;
		for ($vi=1; $vi<=10; $vi++) {
									if (isset($postfeld['vertrag5_sonderrpreis'.$vi])) {
										if ($postfeld['vertrag5_sonderrpreis'.$vi]!='') {
											$nlpsum+=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrppreis'.$vi]));
											$nachlaesset.=$postfeld['vertrag5_sonderr'.$vi].': '.$postfeld['vertrag5_sonderrpreis'.$vi].($postfeld['vertrag5_sonderrppreis'.$vi]!=''?' ('.$postfeld['vertrag5_sonderrppreis'.$vi].' %)':'').'\\par ';
										}
									}
		}
		if ($nachlaesset!='') {
			$nachlaesset=p4n_mb_string('substr', $nachlaesset, 0, -5);
			$inhalt=p4n_sb_strreplace('<<nachlaesse_text>>', $nachlaesset, $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<nachlaesse_text>>', '', $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<nachlassp_sum>>', number_format($nlpsum, 2, ",", "."), $inhalt);
		
		// Tradein:
		
		if (!$cfg_kfzsuche_second_tradein) {
			$inhalt=p4n_sb_preg_replace('/<<ins2>>.*<<ine2>>/Uis', '', $inhalt);
		}
		if (!isset($postfeld['vertrags_ankauf'])) {
			$inhalt=p4n_sb_preg_replace('/<<ins>>.*<<ine>>/Uis', '', $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<ins2>>.*<<ine2>>/Uis', '', $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<ins3>>.*<<ine3>>/Uis', '', $inhalt);
		} elseif (isset($postfeld['vertrags_ankauf']) and isset($postfeld['vertrags_gwpreis2'])) {
			if ($postfeld['vertrags_gwpreis2']!='' or $postfeld['vertrags_gwmarke2']!='' or $postfeld['vertrags_gwtyp2']!='' or $postfeld['vertrags_kennz2']!='') {
				
			} else {
				$inhalt=p4n_sb_preg_replace('/<<ins2>>.*<<ine2>>/Uis', '', $inhalt);
			}
		}
		$inhalt=p4n_sb_strreplace(array('<<ins>>', '<<ine>>'), '', $inhalt);
		$inhalt=p4n_sb_strreplace(array('<<ins2>>', '<<ine2>>'), '', $inhalt);
		$inhalt=p4n_sb_strreplace(array('<<ins3>>', '<<ine3>>'), '', $inhalt);
		// Standardlagerort:
		if (preg_match('/<<lagerort_/i', $inhalt) or preg_match('/<<mandant_/i', $inhalt) or preg_match('/<<'.bef_format_kfzs(_LAGERORT_).'_/i', $inhalt) or preg_match('/<<'.bef_format_kfzs(_MANDANT_).'_/i', $inhalt)) {
			$res6=$db->select(
				$sql_tab['benutzer'],
				$sql_tabs['benutzer']['standard_lagerort'],
				$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id'])
			);
			$std_lao=0;
			$std_mand=0;
			if ($row6=$db->zeile($res6)) {
				if (intval($row6[0])>0) {
					$std_lao=intval($row6[0]);
				}
			}
			if ($std_lao==0 and intval($m_vlao1)>0) {
				$std_lao=$m_vlao1;
			}
			
			if ($cfg_kfzsuche_akv_lagerortauswahl and intval($postfeld['mvertrag_lagerort'])>0) {
				$std_lao=$postfeld['mvertrag_lagerort'];
			}
			
			$m_std_lao=$std_lao;
			if (($_SESSION['cfg_kunde']=='carlo_opel_dello' or $_SESSION['cfg_kunde']=='carlo_opel_duerkop') and substr(strtolower($postfeld['kfz_markencode']), 0, 4)=='opel') {
				$istmietodergw=false;
				if (intval($postfeld['pid'])>0) {
					$res5=$db->select(
						$sql_tab['produktzuordnung'],
						array(
							$sql_tabs['produktzuordnung']['fahrzeugstatus'],
							$sql_tabs['produktzuordnung']['fahrzeugstatus_code']
						),
						$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
					);
					if ($row5=$db->zeile($res5)) {
						if ($row5[0]=='Gebrauchtfahrzeug' or $row5[0]=='Mietfahrzeug' or $row5[0]=='Mietwagen' or $row5[0]=='Gebrauchtwagen' or $row5[1]=='1' or $row5[1]=='6') {
							$istmietodergw=true;
						}
					}
				}
				if (!$istmietodergw) {
					if ($_SESSION['cfg_kunde']=='carlo_opel_dello' and $std_lao==39) {
						$std_lao=31;
					}
					if ($_SESSION['cfg_kunde']=='carlo_opel_dello' and $std_lao==41) {
						$std_lao=31;
					}
					if ($_SESSION['cfg_kunde']=='carlo_opel_dello' and $std_lao==48) {
						$std_lao=46;
					}
					if ($_SESSION['cfg_kunde']=='carlo_opel_duerkop' and $std_lao==34) {
						$std_lao=30;
					}
				}
			}
			
			$mandinfo[0]=array();
			if (!isset($mandinfo[$std_lao])) {
					$sqltm=array(
							$sql_tabs['mandant']['firma'],
							$sql_tabs['mandant']['adresse'],
							$sql_tabs['mandant']['plz'],
							$sql_tabs['mandant']['ort'],
							$sql_tabs['mandant']['briefkopf'],
							$sql_tabs['mandant']['parent_id']
					);
					if (isset($sql_tabs['mandant']['telefon'])) {
						$sqltm[]=$sql_tabs['mandant']['telefon'];
						$sqltm[]=$sql_tabs['mandant']['fax'];
						$sqltm[]=$sql_tabs['mandant']['email'];
						$sqltm[]=$sql_tabs['mandant']['internet'];
						$sqltm[]=$sql_tabs['mandant']['dealercode'];
						$sqltm[]=$sql_tabs['mandant']['zusatz2'];
                        if ($_SESSION['crm_version']>61 && isset($sql_tabs['mandant']['fusszeile'])) {
                            $sqltm[]=$sql_tabs['mandant']['fusszeile'];
                            $sqltm[]=$sql_tabs['mandant']['link1'];
                            $sqltm[]=$sql_tabs['mandant']['link2'];
                            $sqltm[]=$sql_tabs['mandant']['link3'];
                            $sqltm[]=$sql_tabs['mandant']['bezeichnung'];
                        }
					}
					$res4=$db->select(
						$sql_tab['mandant'],
						$sqltm,
						$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($std_lao)
					);
					$row4=$db->zeile($res4);
					$mandinfo[$std_lao]=$row4;

					if (intval($row4[5])>0) {
						$std_mand=intval($row4[5]);
						$res4=$db->select(
							$sql_tab['mandant'],
							$sqltm,
							$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($std_mand)
						);
						$row4=$db->zeile($res4);
						$mandinfo[$std_mand]=$row4;
					}
			}
			
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._BEZEICHNUNG_).'>>/', $mandinfo[$std_lao][0], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._ADRESSE_).'>>/', $mandinfo[$std_lao][1], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._PLZ_).'>>/', $mandinfo[$std_lao][2], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._ORT_).'>>/', $mandinfo[$std_lao][3], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._BRIEFKOPF_).'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_lao][4]), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._TELEFON2_).'>>/', $mandinfo[$std_lao][6], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._FAX_).'>>/', $mandinfo[$std_lao][7], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._EMAIL_).'>>/', $mandinfo[$std_lao][8], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._WWW_).'>>/', $mandinfo[$std_lao][9], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._NUMMER_).'>>/', $mandinfo[$std_lao][10], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._FOOTER_).'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_lao][12]), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._LINK_UPPERCASE_.'1').'>>/', $mandinfo[$std_lao][13], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._LINK_UPPERCASE_.'2').'>>/', $mandinfo[$std_lao][14], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._LINK_UPPERCASE_.'3').'>>/', $mandinfo[$std_lao][15], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_LAGERORT_.'_'._CODE_).'>>/', $mandinfo[$std_lao][16], $inhalt);
            
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._BEZEICHNUNG_).'>>/', $mandinfo[$std_mand][0], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._ADRESSE_).'>>/', $mandinfo[$std_mand][1], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._PLZ_).'>>/', $mandinfo[$std_mand][2], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._ORT_).'>>/', $mandinfo[$std_mand][3], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._BRIEFKOPF_).'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_mand][4]), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._TELEFON2_).'>>/', $mandinfo[$std_mand][6], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._FAX_).'>>/', $mandinfo[$std_mand][7], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._EMAIL_).'>>/', $mandinfo[$std_mand][8], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._WWW_).'>>/', $mandinfo[$std_mand][9], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._NUMMER_).'>>/', $mandinfo[$std_mand][10], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._FOOTER_).'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_mand][12]), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._LINK_UPPERCASE_.'1').'>>/', $mandinfo[$std_mand][13], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._LINK_UPPERCASE_.'2').'>>/', $mandinfo[$std_mand][14], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._LINK_UPPERCASE_.'3').'>>/', $mandinfo[$std_mand][15], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._CODE_).'>>/', $mandinfo[$std_mand][16], $inhalt);
            
			if ($cfg_kfzsuche_norway) {
				$xpl7=explode(';;;', $mandinfo[$std_mand][11]);
				$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'.$lang['_AUFTRAG-KUNDENKONTO_']).'>>/', $xpl7[0], $inhalt);
				$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs(_MANDANT_.'_'._STEUERNUMMER_).'>>/', $xpl7[1], $inhalt);
				$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_konto').'>>/', $xpl7[0], $inhalt);
				$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_steuernummer').'>>/', $xpl7[1], $inhalt);
			}
			
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_bezeichnung').'>>/', $mandinfo[$std_lao][0], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_adresse').'>>/', $mandinfo[$std_lao][1], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_plz').'>>/', $mandinfo[$std_lao][2], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_ort').'>>/', $mandinfo[$std_lao][3], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_briefkopf').'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_lao][4]), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_telefon').'>>/', $mandinfo[$std_lao][6], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_fax').'>>/', $mandinfo[$std_lao][7], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_email').'>>/', $mandinfo[$std_lao][8], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_www').'>>/', $mandinfo[$std_lao][9], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_nummer').'>>/', $mandinfo[$std_lao][10], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_footer').'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_lao][12]), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_link1').'>>/', $mandinfo[$std_lao][13], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_link2').'>>/', $mandinfo[$std_lao][14], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_link3').'>>/', $mandinfo[$std_lao][15], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('lagerort_code').'>>/', $mandinfo[$std_lao][16], $inhalt);
            
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_bezeichnung').'>>/', $mandinfo[$std_mand][0], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_adresse').'>>/', $mandinfo[$std_mand][1], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_plz').'>>/', $mandinfo[$std_mand][2], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_ort').'>>/', $mandinfo[$std_mand][3], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_briefkopf').'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_mand][4]), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_telefon').'>>/', $mandinfo[$std_mand][6], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_fax').'>>/', $mandinfo[$std_mand][7], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_email').'>>/', $mandinfo[$std_mand][8], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_www').'>>/', $mandinfo[$std_mand][9], $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_nummer').'>>/', $mandinfo[$std_mand][10], $inhalt);
            $inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_footer').'>>/', str_replace(array("\n", '<br>'), '\\par ', $mandinfo[$std_mand][12]), $inhalt);
            $inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_link1').'>>/', $mandinfo[$std_mand][13], $inhalt);
            $inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_link2').'>>/', $mandinfo[$std_mand][14], $inhalt);
            $inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_link3').'>>/', $mandinfo[$std_mand][15], $inhalt);
            $inhalt=p4n_sb_preg_replace('/<<'.bef_format_kfzs('mandant_code').'>>/', $mandinfo[$std_mand][16], $inhalt);
			
			$std_lao=$m_std_lao;
		}
		$inhalt=p4n_sb_strreplace('<<luxurytax>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_luxurytax'])), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_preg_replace('/<<localtax>>/', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_localtax'])), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_preg_replace('/<<localtaxd>>/', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_localtax_disc2'])), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_preg_replace('/<<localtaxdp>>/', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_localtax_disc'])), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<summe_woreg>>', number_format($gespreis-doubleval(str_replace(',', '.', $postfeld['vertrag5_neben'])), 2, ",","."), $inhalt);
		if ($cfg_greek) {
			$inhalt=p4n_sb_strreplace('<<vkpreis_liste_netto>>', number_format(doubleval(str_replace(',', '.', $postfeld['net_listenpreis5'])), 2, ",","."), $inhalt);
		}
		
		$inhalt=p4n_sb_strreplace('<<profit_marge>>', number_format(doubleval(str_replace(',', '.', str_replace('.', '', $postfeld['profitcalc_marge']))), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<profit_proz>>', number_format(doubleval(str_replace(',', '.', $postfeld['profitcalc_proz'])), 2, ",", "."), $inhalt);
		
		if ($cfg_kfzsuche_levy or $cfg_kfzsuche_gerding) {
			$inhalt=p4n_sb_strreplace('<<kertrag1>>', $postfeld['levy_ertrag1'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kertrag2>>', $postfeld['levy_ertrag2'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kertrag3>>', $postfeld['levy_ertrag3'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kertrag4>>', $postfeld['levy_ertrag4'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kertrag5>>', $postfeld['levy_ertrag5'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kprovision>>', $postfeld['levy_gesamtprovision'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<keinkprovision>>', $postfeld['levy_einkaeuferprovision'], $inhalt);
			
			$inhalt=p4n_sb_strreplace('<<keigenleistungen>>', $postfeld['levy_eigenleistungen_topco'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<keigenleistungenhzb>>', $postfeld['levy_eigenleistungen_hzb'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<ktopsafe>>', $postfeld['levy_topsafe7'], $inhalt);
			for ($li=1; $li<=6; $li++) {
				$inhalt=p4n_sb_strreplace('<<kvkhname'.$li.'>>', $postfeld['vertrag5_vkhbez'.$li], $inhalt);
				$inhalt=p4n_sb_strreplace('<<kvkhnetto'.$li.'>>', $postfeld['vertrag5_vkh'.$li], $inhalt);
				$inhalt=p4n_sb_strreplace('<<kvkhbrutto'.$li.'>>', $postfeld['vertrag5_vkhbr'.$li], $inhalt);
			}
			if (isset($postfeld['levy_istgw'])) {
				if (($postfeld['levy_f2']=='' or $postfeld['levy_f2']=='0') and $postfeld['levy_f1']!='') {
					$inhalt=p4n_sb_strreplace('<<ktransport>>', $postfeld['levy_f1'], $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<ktransport>>', $postfeld['levy_f2'], $inhalt);
			} else {
				if (($postfeld['levy_f1']=='' or $postfeld['levy_f1']=='0') and $postfeld['levy_f2']!='') {
					$inhalt=p4n_sb_strreplace('<<ktransport>>', $postfeld['levy_f2'], $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<ktransport>>', $postfeld['levy_f1'], $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<ktransport1>>', $postfeld['levy_f1'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<ktransport2>>', $postfeld['levy_f2'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kfahrzeugbrief>>', $postfeld['levy_f2'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kverkaufskosten>>', $postfeld['levy_f3'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kdealpreis>>', $postfeld['levy_deal'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kersteprovision>>', $postfeld['levy_provision'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kfestprovision>>', $postfeld['levy_festprovision'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kaktionsprovision>>', $postfeld['levy_aktionsprovision'], $inhalt);
			if (isset($postfeld['levy_istgw'])) {
				$inhalt=p4n_sb_strreplace('<<ktopsafeart>>', 'Top Safe 5', $inhalt);
                if (isset($postfeld['levy_istmegadeal']) and $postfeld['levy_istmegadeal']=='1') {
    				$inhalt=p4n_sb_strreplace('<<kdealart>>', 'MegaDeal', $inhalt);
                } else {
    				$inhalt=p4n_sb_strreplace('<<kdealart>>', 'BigDeal', $inhalt);
                }
			}
			$inhalt=p4n_sb_strreplace('<<ktopsafeart>>', 'Top Safe 7', $inhalt);
			$inhalt=p4n_sb_strreplace('<<kdealart>>', 'NewDeal', $inhalt);
			$inhalt=p4n_sb_strreplace('<<kauditbonus>>', $postfeld['levy_auditbonus'], $inhalt);
			$prov_ausw=array('20' => 'Bestand', '17' => 'Vorlauf', '15' => 'Neubestellung');
			
			$levy_vbb='';
			if (isset($prov_ausw[$postfeld['levy_provauswahl']])) {
				$levy_vbb=$prov_ausw[$postfeld['levy_provauswahl']];
			}
			
			$res4=$db->select(
		        $sql_tab['einstellungen'],
		        $sql_tabs['einstellungen']['wert'],
		        $sql_tabs['einstellungen']['modul'].'='.$db->str('Levy_Prov_1')
		    );
		    if ($row4=$db->zeile($res4)) {
				$xpl=explode(';', $row4[0]);
				if (count($xpl)==3) {
					if ($postfeld['levy_provauswahl']==$xpl[0]) {
						$levy_vbb='Bestand';
					} elseif ($postfeld['levy_provauswahl']==$xpl[1]) {
						$levy_vbb='Vorlauf';
					} elseif ($postfeld['levy_provauswahl']==$xpl[2]) {
						$levy_vbb='Neubestellung';
					}
				}
			}
			
			if (isset($postfeld['levy_istgw']) and $postfeld['levy_istgw']=='1') {
				$levy_vbb='Bestand '.number_format(doubleval($postfeld['levy_provauswahl']), 1, ",", "").' %';
			}
			/*
						$prov_ausw=array('11.5' => '11,5', '12.5' => '12,5', '13.5' => '13,5', '14.5' => '14,5', '15.5' => '15,5');
						$res4=$db->select(
					        $sql_tab['einstellungen'],
					        $sql_tabs['einstellungen']['wert'],
					        $sql_tabs['einstellungen']['modul'].'='.$db->str('Levy_Prov_2')
					    );
					    if ($row4=$db->zeile($res4)) {
							$def_levy2=explode(';', $row4[0]);
							while (list($keylp, $vallp)=@each($def_levy2)) {
								if ($vallp!='') {
									if ($postfeld['levy_provauswahl']==str_replace(',', '.', $vallp)) {
										$levy_vbb=$vallp;
									}
								}
							}
						}
			}
			*/
			
			if ($_SESSION['cfg_kunde']=='carlo_opel_toyota_autolevy') {
				$levy_vbb=number_format(doubleval($postfeld['levy_provauswahl']), 1, ",", "").' %';
			}
			
			$inhalt=p4n_sb_strreplace('<<kvorlaufbestand>>', $levy_vbb, $inhalt);
			$inhalt=p4n_sb_strreplace('<<fahrzeugstatus>>', $kfz_fstatus, $inhalt);
			
			$inhalt=p4n_sb_strreplace('<<kupebrutto>>', $postfeld['upe_brutto'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kupenetto>>', $postfeld['upe_netto'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kabzugprozent>>', $postfeld['levy_marge'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<kabzug>>', $postfeld['upe_levyabzug'], $inhalt);
			$lzielerr=array('0' => 'bis 90%', '200' => '&gt;=90%', '400' => '&gt;=100%', '550' => '&gt;=110%', '650' => '&gt;=120%');
			$lziel2='';
			if (isset($lzielerr[$postfeld['levy_zielerreichung']])) {
				$lziel2=$lzielerr[$postfeld['levy_zielerreichung']];
				$lziel2=str_replace('&gt;', '>', $lziel2);
			}
			$inhalt=p4n_sb_strreplace('<<kzielauswahl>>', $lziel2, $inhalt);
			$inhalt=p4n_sb_strreplace('<<kzielerreichung>>', $postfeld['levy_zielerreichung'], $inhalt);
			$lmodelcheck='';
			if (isset($postfeld['levy_check'])) {
				$lmodelcheck='Model Fokus Bonus erreicht';
			}
			$inhalt=p4n_sb_strreplace('<<kmodelfokus>>', $lmodelcheck, $inhalt);
			$inhalt=p4n_sb_strreplace('<<kmodelfokusbonus>>', $postfeld['levy_modellbonus'], $inhalt);
			$lev_eink='';
			if (intval($postfeld['levy_proveinkauefer'])>0) {
				$lev_eink=dbout($sql_tab['benutzer'], array($sql_tabs['benutzer']['vorname'], $sql_tabs['benutzer']['name']), $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($postfeld['levy_proveinkauefer']));
			}
			$inhalt=p4n_sb_strreplace('<<kproveinkaeufer>>', $lev_eink, $inhalt);
		}
		
//echo '<pre>';
//print_r($postfeld);
//die();

		if ($cfg_kfzsuche_novaneu) {
			$nova_neu=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['nova']))+$bonmal/(1+$cfg_mwst), 2, ".", ""));
			$usteuer-=doubleval(number_format($nova_neu*$cfg_mwst, 2, ".", ""));
			$inhalt=p4n_sb_strreplace('<<nova>>', number_format($nova_neu*(1+$cfg_mwst), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<bonusmalus>>', '', $inhalt);
		}
		if ($cfg_kfzsuche_eumitsteuer and isset($postfeld['vertrag_eugeschaeft'])) {
			$postfeld['fin_ust25']=1;
			unset($postfeld['vertrag_eugeschaeft']);
			$usteuer=0;
			$postfeld['vorlage_gw']=1;
			$cfg_kfzsuche_vgw=true;
		}
		if (isset($postfeld['vertrag_eugeschaeft'])) {
			$inhalt=p4n_sb_strreplace('<<summe>>', number_format(0, 2, ",","."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<mwst>>',  number_format(0, 2, ",","."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<vkpreis>>', number_format($gespreis*100/(100+(100*$cfg_mwstn)), 2, ",","."), $inhalt);
		}
        
		if ($cfg_kfzsuche_vgw and isset($postfeld['vorlage_gw'])) {
			$su_preis_gw=$gespreis;
			$gw_zulassp=doubleval(str_replace(',', '.', str_replace(',', '.', $postfeld['vertrag5_neben'])));
			$su_preis_gw-=$gw_zulassp;
			$inhalt=p4n_sb_strreplace('<<summe>>', number_format($su_preis_gw, 2, ",","."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<summe_gesamt>>', number_format($su_preis_gw+$gw_zulassp, 2, ",", "."), $inhalt);
			if (!$cfg_greek) {
				if ($usteuer==0) {
					$inhalt=p4n_sb_strreplace('<<vkpreis>>', number_format($su_preis_gw, 2, ",","."), $inhalt);
					$inhalt=p4n_sb_strreplace('<<mwst>>', number_format($usteuer, 2, ",","."), $inhalt);
				} else {
					$usteuer2=doubleval(number_format($su_preis_gw-($su_preis_gw/(1+$cfg_mwstn)), 2, ".", ""));
					$inhalt=p4n_sb_strreplace('<<vkpreis>>', number_format($su_preis_gw-$usteuer2, 2, ",","."), $inhalt);
					$inhalt=p4n_sb_strreplace('<<mwst>>', number_format($usteuer2, 2, ",","."), $inhalt);
				}
			}
		}
		
		if ($cfg_kfzsuche_austria) {

		} else {
			if (!$cfg_greek and !$cfg_kfzsuche_norway) {
				$inhalt=p4n_sb_strreplace('<<vkpreis>>', preparePrice($vkpreis1), $inhalt);
			}
		}
// alt		$gespreis+=doubleval($usteuer);
		if (!$cfg_greek and !$cfg_kfzsuche_norway) {
			$inhalt=p4n_sb_strreplace('<<mwst>>', preparePrice($usteuer), $inhalt);//$fin_gesamtpreis
		}
		
		if ($postfeld['vertrag_nwgw']=='1' and doubleval(str_replace(',', '.', $postfeld['vertrag_zulassung2']))>0) {
			$summe=$gespreis+doubleval(str_replace(',', '.', $postfeld['vertrag_zulassung2']));
		} else {
			$summe=$gespreis;
		}
		if ($cfg_kfzsuche_holland) {
			$summe=doubleval(str_replace(',', '.', $postfeld['fin_preis2']));
		}
		$inhalt=p4n_sb_strreplace('<<summe>>', preparePrice($gespreis), $inhalt);

		$finp_ex=$gespreis-doubleval(str_replace(',', '.', $postfeld['fin_anzahlung2']))-doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis']));
		if ($cfg_greek) {
			$finp_ex-=doubleval(str_replace(',', '.', $postfeld['fin2_betrag']));
		}
		$inhalt=p4n_sb_strreplace('<<summe_ai>>', number_format($finp_ex, 2, ",","."), $inhalt);
		
		$finp_ex2=$gespreis-doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis']));
		$inhalt=p4n_sb_strreplace('<<summe_i>>', number_format($finp_ex2, 2, ",","."), $inhalt);

		$finp_ex2=$gespreis-doubleval(str_replace(',', '.', $postfeld['fin_anzahlung2']));
		$inhalt=p4n_sb_strreplace('<<summe_a>>', number_format($finp_ex2, 2, ",","."), $inhalt);
		
		$m_sum_pag=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['summe_preisa'])), 2, '.', ''));
		$summe_nurnachlass=$m_sum_pag;
		$summe_nurnachlass_netto=$summe_nurnachlass/(1+$cfg_mwst);
		$summe_mitnachlass=$gespreis+$m_sum_pag;
		$summe_mitnachlass_netto=$summe_mitnachlass/(1+$cfg_mwst);
		$summe_inklnachlass=$gespreis;
		$summe_inklnachlass_netto=$summe_inklnachlass/(1+$cfg_mwst);
		if ($preise_netto) {
			$inhalt=p4n_sb_strreplace('<<summe_mnl_nb>>', number_format($summe_mitnachlass_netto, 2, ",","."), $inhalt);
		} else {
			$inhalt=p4n_sb_strreplace('<<summe_mnl_nb>>', number_format($summe_mitnachlass, 2, ",","."), $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<summe_mnl>>', number_format($summe_mitnachlass, 2, ",","."), $inhalt);
		if ($preise_netto) {
			$inhalt=p4n_sb_strreplace('<<summe_nurnl_nb>>', number_format($summe_nurnachlass_netto, 2, ",","."), $inhalt);
		} else {
			$inhalt=p4n_sb_strreplace('<<summe_nurnl_nb>>', number_format($summe_nurnachlass, 2, ",","."), $inhalt);
		}
		if ($preise_netto) {
			$inhalt=p4n_sb_strreplace('<<summe_inklnl_nb>>', number_format($summe_inklnachlass_netto, 2, ",","."), $inhalt);
		} else {
			$inhalt=p4n_sb_strreplace('<<summe_inklnl_nb>>', number_format($summe_inklnachlass, 2, ",","."), $inhalt);
		}
		$proz_nachl=0;
		if ($merke_werkpreis!=0) {
			$proz_nachl=$m_sum_pag/$merke_werkpreis*100;
		}
		$inhalt=p4n_sb_strreplace('<<pag_b_sump>>', number_format($proz_nachl, 2, ",","."), $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<bar_anzahlung>>', number_format(doubleval($postfeld['fin_baranzahlung']), 2, ",","."), $inhalt);

		// Finanz.:
		$inhalt=p4n_sb_strreplace('<<fin_banken>>', $postfeld['fin_bank'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_bank>>', $postfeld['fin_bank'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_finbetragwerden>>', number_format(doubleval($postfeld['fin_werden']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_betragwerden>>', number_format(doubleval($postfeld['fin_werden']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_finbetrag>>', number_format(doubleval($postfeld['fin_betrag']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_baranzahlung>>', number_format(doubleval($postfeld['fin_baranzahlung']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_kosten_summe>>', number_format(doubleval($postfeld['fin_kosten']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_teilzahlungspreis>>', number_format(doubleval($postfeld['fin_teilzahlungspreis']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_zinseff>>', number_format(doubleval($postfeld['fin_effzins']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_zinspa>>', number_format(doubleval($postfeld['fin_zins']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_ersterate>>', $postfeld['fin_datumerstrate'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_ersterate_betrag>>', number_format(doubleval($postfeld['fin_erstrate']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_rate_anzahl>>', $postfeld['fin_anzahlraten'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_rate_betrag>>', number_format(doubleval($postfeld['fin_monatsrate']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_rate_tag>>', $postfeld['fin_zahlungstag'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_schlussrate>>', $postfeld['fin_schlussrate'], $inhalt);

		$inhalt=p4n_sb_strreplace('<<fin_kreditdatum>>', $postfeld['fin_zinsloskreditdatum'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin_kredithoehe>> ', number_format(doubleval($postfeld['fin_zinsloskredithoehe']), 2, ",","."), $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<fin2_betrag>>', number_format(doubleval(str_replace(',', '.', $postfeld['fin2_betrag'])), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin2_laufzeit>>', $postfeld['fin2_laufzeit'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin2_rate>>', number_format(doubleval(str_replace(',', '.', $postfeld['fin2_rate'])), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin2_zins>>', number_format(doubleval(str_replace(',', '.', $postfeld['fin2_zins'])), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<fin2_expense>>', number_format(doubleval(str_replace(',', '.', $postfeld['fin2_expense'])), 2, ",","."), $inhalt);
		
		if ($cfg_olympia) {
			if (isset($postfeld['vers_olympia']) and strtolower(substr($postfeld['vers_olympia'], 0, 2))=='ja') {
				$inhalt=p4n_sb_strreplace('<<vers_olympia>>', $cfg_olympia_kfzsuche_ja, $inhalt);
			} else {
				$inhalt=p4n_sb_strreplace('<<vers_olympia>>', $cfg_olympia_kfzsuche_nein, $inhalt);
			}
		}
		
		if (isset($cfg_toyota_at_gleitklausel)) {
			if ($cfg_toyota_at_gleitklausel!='' and isset($postfeld['fin_ust_gk']) and (strtolower($postfeld['kfz_markencode'])=='toyota' or strtolower($postfeld['kfz_markencode'])=='lexus') and ($postfeld['freiekonf']=='1' or (intval($postfeld['pid'])>0 and $kfz_fstatuscode=='0') or (($kfz_fstatus=='Neufahrzeug - konfiguriert' or $kfz_fstatus==_VEHICLE_CONFIGURED_)))) {
				$inhalt=p4n_sb_strreplace('<<toyota_at_gleitklausel>>', $cfg_toyota_at_gleitklausel, $inhalt);
			} else {
				$inhalt=p4n_sb_strreplace('<<toyota_at_gleitklausel>>', '', $inhalt);
			}
		}
		
		$sonstiges2='';
		if (!$cfg_kfzsuche_holland and !$cfg_kfzsuche_italien and isset($postfeld['kfz_tz']) and intval($postfeld['kfz_tz'])==1) {
			$tztext='Garantie- und Wartungsintervall ab Datum Erstzulassung.';
			if (isset($cfg_kfzsuche_tztext)) {
				if ($cfg_kfzsuche_tztext!='') {
					$tztext=$cfg_kfzsuche_tztext;
				}
			}
			$zussonst2='';
			if ($cfg_kfzsuche_vorbesitzer_tz_text or $_SESSION['cfg_kunde']=='carlo_opel_duerkop') {
				$zussonst2.="\n".'Vorbesitzer: '.$postfeld['kfz_vorbesitzer'];
			}
			$sonstiges2.="\n".'Erstzulassung: '.$postfeld['kfz_datum_ez'].$zussonst2.'\\par '.$tztext;
		}
		if (!$cfg_kfzsuche_holland and !$cfg_kfzsuche_italien and isset($postfeld['vertrags_ankauf'])) {
			if ($_SESSION['cfg_kunde']=='carlo_opel_carebus') {
				$sonstiges2.="\n\n".'Le vehicule '.$postfeld['vertrags_gwmarke'].' '.$postfeld['vertrags_gwtyp'].' avec N� de chassis  '.$postfeld['vertrags_gwfgnr'].' et N� d\'immatriculation '.$postfeld['vertrags_kennz'].' est repris pour un montant de '.($cfg_kfzsuche_avag?$postfeld['vertrags_gwpreis']:number_format(doubleval($postfeld['vertrags_gwpreis']), 2, ",", ".").' '.$waehrung_eur).'.';
			} else {
				$sonstiges2.="\n".'Der Gebrauchtwagen ('.$postfeld['vertrags_gwmarke'].' '.$postfeld['vertrags_gwtyp'].' mit der Fahrgestellnummer '.$postfeld['vertrags_gwfgnr'].' und dem Kennzeichen '.$postfeld['vertrags_kennz'].') wird f�r '.($cfg_kfzsuche_avag?$postfeld['vertrags_gwpreis']:number_format(doubleval($postfeld['vertrags_gwpreis']), 2, ",", ".").' '.$waehrung_eur).' angekauft.';
			}
		}

		$zusv2='';
		$merke_fbn='';
		$merke_fid='';
		$merke_herst='';
		$res5=$db->select(
			$sql_tab['produktzuordnung'],
			array(
				$sql_tabs['produktzuordnung']['fahrzeugstatus_code'],
				$sql_tabs['produktzuordnung']['zusatz2'],
				$sql_tabs['produktzuordnung']['anzahl_tueren'],
				$sql_tabs['produktzuordnung']['eva_typ'],
				$sql_tabs['produktzuordnung']['buchnummer'],
				$sql_tabs['produktzuordnung']['getriebebezeichnung'],	// 5
				$sql_tabs['produktzuordnung']['motorartcode'],
				$sql_tabs['produktzuordnung']['kba_hersteller'],
				$sql_tabs['produktzuordnung']['kba_typ'],
				$sql_tabs['produktzuordnung']['zusatztext2'],
				$sql_tabs['produktzuordnung']['modelljahr'],				// 10
				$sql_tabs['produktzuordnung']['zusatz_crm1'],
				$sql_tabs['produktzuordnung']['hersteller'],
				$sql_tabs['produktzuordnung']['kraftstoff'],
				$sql_tabs['produktzuordnung']['zusatz1'],
				$sql_tabs['produktzuordnung']['kennbuchstabe_getriebe']		// 15
			),
			$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
		);
		if ($row5=$db->zeile($res5)) {
			$inhalt=p4n_sb_strreplace('<<zusatz1>>', $row5[14], $inhalt);
			$inhalt=p4n_sb_strreplace('<<edvnummer>>', $row5[3], $inhalt);
			$inhalt=p4n_sb_strreplace('<<buchnummer>>', $row5[4], $inhalt);
			if ($row5[5]!='') {
				$inhalt=p4n_sb_strreplace('<<getriebeart>>', $row5[5], $inhalt);
			} elseif ($row5[15]!='') {
				$inhalt=p4n_sb_strreplace('<<getriebeart>>', $row5[15], $inhalt);
			}
			if ($row5[13]!='') {
				$inhalt=p4n_sb_strreplace('<<kraftstoffart>>', $row5[13], $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<motorart>>', $row5[6], $inhalt);
			$inhalt=p4n_sb_strreplace('<<HSN>>', $row5[7], $inhalt);
			$inhalt=p4n_sb_strreplace('<<TSN>>', $row5[8], $inhalt);
			$inhalt=p4n_sb_strreplace('<<hsn>>', $row5[7], $inhalt);
			$inhalt=p4n_sb_strreplace('<<tsn>>', $row5[8], $inhalt);
			$inhalt=p4n_sb_strreplace('<<zusatztext2>>', $row5[9], $inhalt);
			$inhalt=p4n_sb_strreplace('<<filialbuchnummer>>', $row5[9], $inhalt);
			$inhalt=p4n_sb_strreplace('<<modelljahr>>', $row5[10], $inhalt);
			$merke_fbn=$row5[9];
			$merke_fid=$row5[11];
			$merke_herst=$row5[12];
			$inhalt=p4n_sb_strreplace('<<tueren>>', (intval($row5[2])>0?$row5[2]:''), $inhalt);
			if (($row5[0]=='20' or $row5[0]=='21' or $row5[0]=='26') and $row5[1]=='4') {
				$zusv2='Kaufvertrag vorbehaltlich Verf�gbarkeit des Fahrzeugs'."\n";
				$sonstiges2.="\n".'Kaufvertrag vorbehaltlich Verf�gbarkeit des Fahrzeugs';
			}
            
            if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent' and $row5[13]=='Elektro') {
                $inhalt=p4n_sb_strreplace('<<elektro_text>>', $cfg_kfzsuche_dbrent_elektro_text, $inhalt);
            }
            
		} else {
			$inhalt=p4n_sb_strreplace('<<modelljahr>>', $postfeld['extmodelljahr'], $inhalt);
		}
        if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
            $inhalt=p4n_sb_strreplace('<<elektro_text>>', '', $inhalt);
        }
		$inhalt=p4n_sb_strreplace('<<zusatz1>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<edvnummer>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<buchnummer>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<tueren>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<getriebeart>>', @$postfeld['getriebeart'], $inhalt);
        $inhalt=p4n_sb_strreplace('<<motorart>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<zusatztext2>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<filialbuchnummer>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<kraftstoffart>>', '', $inhalt);
		if (isset($postfeld['dvs_id']) and isset($kfz_hsn) and $kfz_hsn!='') {
			$inhalt=p4n_sb_strreplace('<<HSN>>', $kfz_hsn, $inhalt);
			$inhalt=p4n_sb_strreplace('<<TSN>>', $kfz_tsn, $inhalt);
			$inhalt=p4n_sb_strreplace('<<hsn>>', $kfz_hsn, $inhalt);
			$inhalt=p4n_sb_strreplace('<<tsn>>', $kfz_tsn, $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<HSN>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<TSN>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<hsn>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<tsn>>', '', $inhalt);
		
		if ($cfg_kfzsuche_gweuhaken and isset($postfeld['gweuwagen'])) {
			$inhalt=p4n_sb_strreplace('<<vdet_eu_satz>>', $cfg_kfzsuche_gweuhaken_text_kv, $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<vdet_eu_satz>>', '', $inhalt);
		
		if ($cfg_kfzsuche_fernabsatz and isset($postfeld['vertrag_fernabsatz'])) {
			$inhalt=p4n_sb_strreplace('<<fernabsatz>>', $cfg_kfzsuche_fernabsatz_text, $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<fernabsatz>>', '', $inhalt);
		
		$sep_so2='\\par ';
		if (isset($cfg_kfzsuche_sonstiges2_sep)) {
			$sep_so2=$cfg_kfzsuche_sonstiges2_sep;
		}
		$inhalt=p4n_sb_strreplace('<<sonstiges_vvi>>', str_replace(array("\n", '<br>'), $sep_so2, $postfeld['vertrags_vereinbarungen']), $inhalt);
		$inhalt=p4n_sb_strreplace('<<sonstiges_kv>>', str_replace(array("\n", '<br>'), $sep_so2, $postfeld['vertrags_vereinbarungenm']), $inhalt);
		
		if (isset($postfeld['vertrags_vereinbarungenm']) and $postfeld['vertrags_vereinbarungenm']!='') {
			$postfeld['vertrags_vereinbarungen'].=' '.$postfeld['vertrags_vereinbarungenm'];
			$postfeld['vertrags_vereinbarungen']=trim($postfeld['vertrags_vereinbarungen']);
		}
		$sv_ohnetext='';
		
		if ($postfeld['vertrag_nwgw']=='1') {
			if ($cfg_kfzsuche_gwgarantie) {
				if (isset($postfeld['gwgarantie'])) {
					$zusv2.=$cfg_kfzsuche_gwgarantie_text_kv."\n";
				} elseif($cfg_kfzsuche_gwgarantie_text_kv_nicht!='') {
					$zusv2.=$cfg_kfzsuche_gwgarantie_text_kv_nicht."\n";
				}
			}
			if ($cfg_kfzsuche_gweuhaken) {
				if (isset($postfeld['gweuwagen'])) {
					$zusv2.=$cfg_kfzsuche_gweuhaken_text_kv."\n";
				}
			}
		} else {

			if ($cfg_kfzsuche_nwgarantie) {
				if (isset($postfeld['nwgarantie'])) {
					$zusv2.=$cfg_kfzsuche_nwgarantie_text_kv."\n";
				} elseif($cfg_kfzsuche_nwgarantie_text_kv_nicht!='') {
					$zusv2.=$cfg_kfzsuche_nwgarantie_text_kv_nicht."\n";
				}
			}
		}

		$zusatzdateien1=array();

		$merk_vers_ang=0;
		$merk_vers_ang_qr=0;
		$nicht_in_sonst=array();
		if (isset($postfeld['infotextz_sel'])) {
			@reset($postfeld['infotextz_sel']);
			while (list($key1, $val1)=@each($postfeld['infotextz_sel'])) {
				$inft1n='';
				if ($val1!='-1') {
					$xpl=explode('_', $key1);
					while (list($key2, $val2)=@each($xpl)) {
					}
					$postfeld['infotextz'][$val1]=1;
					$inft1n=base64_decode($postfeld['infotextz2'][$val1]);
					if ($inft1n=='Versicherungsangebot erw�nscht') {
						$merk_vers_ang=$val1;
					}
					if ($inft1n=='Versicherungsangebot erw�nscht (QR-Code)') {
						$merk_vers_ang_qr=$val1;
					}
					for ($zi3=1; $zi3<=10; $zi3++) {
						if (isset($postfeld['sonst_'.$val1.'_'.$zi3])) {
							$inft1n=preg_replace('/xxx/i', $postfeld['sonst_'.$val1.'_'.$zi3], $inft1n, 1);
						}
					}
					$ms_inhalt=$inhalt;
					$inhalt=p4n_sb_strreplace('<<sonstv_'.strtolower(str_replace(' ', '', $postfeld['infotextz_seltext'][$key1])).'>>', $inft1n, $inhalt);
					if ($ms_inhalt!=$inhalt) {
						$nicht_in_sonst[$val1]=1;
					}
				}
				$ms_inhalt=$inhalt;
				$inhalt=p4n_sb_strreplace('<<sonstv_'.strtolower(str_replace(' ', '', $postfeld['infotextz_seltext'][$key1])).'>>', '', $inhalt);
				if ($ms_inhalt!=$inhalt) {
					$nicht_in_sonst[$val1]=1;
				}
			}
		}
		$synop_vers=false;
		$allianz_vers=false;
		$korr_sv_text='';
        if (!empty($postfeld['infotextz'])) {
            @reset($postfeld['infotextz']);
            while (list($ikey, $ival)=@each($postfeld['infotextz'])) {
                $sv_nurint=false;
                if (isset($postfeld['infotextzopt'][$ikey])) {
                    $expl3=explode(',', $postfeld['infotextzopt'][$ikey]);
                    while (list($key2, $val2)=@each($expl3)) {
                        $val2=trim($val2);
                        if ($val2=='int') {
                            $sv_nurint=true;
                        }
                    }
                }
                if ($sv_nurint and !$war_int1) {
                    continue;
                }
                $inft1n=base64_decode($postfeld['infotextz2'][$ikey]);
                if ($cfg_kfzsuche_levy) {
                    if (strtolower($inft1n)=='bigdeal') {
                        if (!isset($postfeld['bigdeal'])) {
                            continue;
                        }
                    }
                    if (strtolower($inft1n)=='newdeal') {
                        if (!isset($postfeld['newdeal'])) {
                            continue;
                        }
                    }
                    if (strtolower($inft1n)=='megadeal') {
                        if (!isset($postfeld['megadeal'])) {
                            continue;
                        }
                    }
                }
                for ($zi3=1; $zi3<=10; $zi3++) {
                    if (isset($postfeld['sonst_'.$ikey.'_'.$zi3])) {
                        $inft1n=preg_replace('/xxx/i', $postfeld['sonst_'.$ikey.'_'.$zi3], $inft1n, 1);
                    }
                }
				
				if (intval($merk_vers_ang)>0 and $ikey==$merk_vers_ang) {
					$synop_vers=true;
				}
				if (intval($merk_vers_ang_qr)>0 and $ikey==$merk_vers_ang_qr) {
					$allianz_vers=true;
				}
				
				$korr_sv_text.=$inft1n."\n";
                
				$msv_inhalt=$inhalt;
                if ($postfeld['infotextzkd'][$ikey]=='1') {
                    $inhalt=p4n_sb_strreplace('<<sonstv_r'.$postfeld['infotextz_rang'][$ikey].'>>', '', $inhalt);
                } else {
                    $inhalt=p4n_sb_strreplace('<<sonstv_r'.$postfeld['infotextz_rang'][$ikey].'>>', $inft1n, $inhalt);
                    if ($msv_inhalt==$inhalt and !isset($nicht_in_sonst[$ikey])) {
                        $sep_sv2=' ';
                        if (isset($cfg_kfzsuche_sonstiges2_sep)) {
                            if ($cfg_kfzsuche_sonstiges2_sep!='') {
                                $sep_sv2=$cfg_kfzsuche_sonstiges2_sep;
                            }
                        }
                        if ($postfeld['vertrags_vereinbarungen']!='') {
                            $postfeld['vertrags_vereinbarungen'].=$sep_sv2;
                        }
                        $postfeld['vertrags_vereinbarungen'].=$inft1n;
						if ($sv_ohnetext!='') {
                            $sv_ohnetext.=$sep_sv2;
                        }
						$sv_ohnetext.=$inft1n;
                    }
                }
                if ($postfeld['infotextz_datei'][$ikey]!='') {
                    $keinezdkorr=false;
                    if ($postfeld['infotextzkk'][$ikey]=='1') {
                        $keinezdkorr=true;
                    }
                    $zdmitpdf=false;
                    if ($postfeld['infotextzpdf'][$ikey]=='1') {
                        $zdmitpdf=true;
                    }
                    $zusatzdateien1[$postfeld['infotextz_datei'][$ikey]]=array($postfeld['infotextz_rang'][$ikey], $inft1n, $keinezdkorr, $zdmitpdf);
                }
            }
        }
		for ($svi=1; $svi<200; $svi++) {
			$inhalt=p4n_sb_strreplace('<<sonstv_r'.$svi.'>>', '', $inhalt);
		}
		if (isset($postfeld['gar_text_auswahl'])) {
			if (intval($postfeld['gar_text_auswahl'])>0) {
				$sqlt_gara=array(
					$sql_tabs['kfzsuche_zusatztexte']['beschreibung']
				);
				$sep_ph=false;
				if ($_SESSION['crm_version']>60) {
					$sqlt_gara=array(
						$sql_tabs['kfzsuche_zusatztexte']['beschreibung'],
						$sql_tabs['kfzsuche_zusatztexte']['zusatz']
					);
					$sep_ph=true;
				}
				$res=$db->select(
					$sql_tab['kfzsuche_zusatztexte'],
					$sqlt_gara,
					$sql_tabs['kfzsuche_zusatztexte']['kfzsuche_zusatztexte_id'].'='.$db->dbzahl($postfeld['gar_text_auswahl'])
				);
				if ($row=$db->zeile($res)) {
					if ($sep_ph and $row[1]=='1') {
						$inhalt=p4n_sb_strreplace('<<gar>>', str_replace("\n", '\\par ', $row[0]), $inhalt);
					} else {
						$postfeld['vertrags_vereinbarungen'].="\\par \\par ".str_replace("\n", '\\par ', $row[0]);
						$sv_ohnetext.="\\par \\par ".str_replace("\n", '\\par ', $row[0]);
					}
				}
			}
		}
		$inhalt=p4n_sb_strreplace('<<gar>>', '', $inhalt);
		
		if (isset($postfeld['angpfh'])) {
			if ($postfeld['angpfh']=='1') {
				$postfeld['vertrags_vereinbarungen'].=' Dieses Fahrzeug ist bereits reserviert. Es kann zwischenzeitlich an andere Interessenten verkauft werden.';
				$sv_ohnetext.=' Dieses Fahrzeug ist bereits reserviert. Es kann zwischenzeitlich an andere Interessenten verkauft werden.';
			}
		}

		$inhalt=p4n_sb_strreplace('<<jn_leasing>>', ($postfeld['jn_leasing']=='1'?_JA_:_NEIN_), $inhalt);
		$inhalt=p4n_sb_strreplace('<<jn_kredit>>', ($postfeld['jn_kredit']=='1'?_JA_:_NEIN_), $inhalt);
		$inhalt=p4n_sb_strreplace('<<jn_dia>>', ($postfeld['jn_dia']=='1'?_JA_:_NEIN_), $inhalt);
		$inhalt=p4n_sb_strreplace('<<jn_vers>>', ($postfeld['jn_versicherung']=='1'?_JA_:_NEIN_), $inhalt);
		$inhalt=p4n_sb_strreplace('<<text_leasing>>', $postfeld['text_leasing'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<text_kredit>>', $postfeld['text_kredit'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<text_dia>>', $postfeld['text_dia'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<text_vers>>', $postfeld['text_versicherung'], $inhalt);

		$gwb_ja='X';
		$gwb_nein='-';
		$inhalt=p4n_sb_strreplace('<<ca1>>', ($postfeld['gwb_ca1']=='1'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<ca2>>', ($postfeld['gwb_ca1']=='2'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<ca3>>', ($postfeld['gwb_ca1']=='3'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<ca4>>', ($postfeld['gwb_ca1']=='4'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<cb1>>', ($postfeld['gwb_cb1']=='1'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<cb2>>', ($postfeld['gwb_cb1']=='2'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<cb3>>', ($postfeld['gwb_cb1']=='3'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<cb4>>', ($postfeld['gwb_cb1']=='4'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<cc1>>', ($postfeld['gwb_cc1']=='1'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<cc2>>', ($postfeld['gwb_cc1']=='2'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<cc3>>', ($postfeld['gwb_cc1']=='3'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<cc4>>', ($postfeld['gwb_cc1']=='4'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<cd1>>', ($postfeld['gwb_cd1']=='1'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<cd2>>', ($postfeld['gwb_cd1']=='2'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<cd3>>', ($postfeld['gwb_cd1']=='3'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<cd4>>', ($postfeld['gwb_cd1']=='4'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<ce1>>', ($postfeld['gwb_ce1']=='1'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<ce2>>', ($postfeld['gwb_ce1']=='2'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<ce3>>', ($postfeld['gwb_ce1']=='3'?$gwb_ja:$gwb_nein), $inhalt);
		$inhalt=p4n_sb_strreplace('<<ce4>>', ($postfeld['gwb_ce1']=='4'?$gwb_ja:$gwb_nein), $inhalt);

		// neuS4C 2012
		$inhalt=p4n_sb_strreplace('<<bonusmalus>>', number_format(-1*doubleval(str_replace(',', '.', $postfeld['bonus_malus'])), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<novap>>', number_format(doubleval(str_replace(',', '.', $postfeld['novasatz'])), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<nova>>', number_format(doubleval(str_replace(',', '.', $postfeld['nova'])), 2, ",", "."), $inhalt);
		$fzgv_werte=array('1' => 'in serienm��iger Ausst.', '2' => 'in Sonderausf�hrung');
		$inhalt=p4n_sb_strreplace('<<fzg_variante>>', $fzgv_werte[$postfeld['fzg_variante']], $inhalt);
		$fzgv_werte=array('1' => 'bei Kraftfahrzeugen in serienm��iger Ausf�hrung um h�chstens zwei Wochen', '2' => 'bei Kraftfahrzeugen in Sonderausf�hrungen um h�chstens acht Wochen');
		$inhalt=p4n_sb_strreplace('<<fahrzeug_variante_text>>', $fzgv_werte[$postfeld['fzg_variante']], $inhalt);
		$fzgn_werte=array('1' => 'zur privaten Nutzung', '2' => 'zur gewerblichen Nutzung');
		$inhalt=p4n_sb_strreplace('<<fzg_nutzung>>', $fzgn_werte[$postfeld['vertrag_nutzungsart']], $inhalt);
		
		if ($cfg_dd_vvi2022) {
			if (isset($postfeld['ddvvi_gw_4'])) {
				$postfeld['vertrags_vereinbarungen']='Kilometerstand bei �bergabe: '.$postfeld['ddvvi_gw_km'].' km'."\n".$postfeld['vertrags_vereinbarungen'];
			}
		}
		
		$inhalt=p4n_sb_strreplace('<<sonstiges>>', str_replace(array("\n", '<br>'), '\\par ', $postfeld['vertrags_vereinbarungen'].$sonstiges2), $inhalt);
		
		if ($cfg_dd_sammelkv) {
			$skv_template='';
			$skv_template_alles='';
			if (preg_match('/<<startskv>>(.*)<<endeskv>>/Uis', $inhalt, $ma)) {
				$skv_template=$ma[1];
				$skv_template_alles=$ma[0];
			}
			$inhalt=p4n_sb_strreplace('<<skv_gesamtbrutto>>', number_format(doubleval(str_replace(',', '.', $postfeld['skv_gesamtbrutto'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<skv_gesamtnetto>>', number_format(doubleval(str_replace(',', '.', $postfeld['skv_gesamtnetto'])), 2, ",", "."), $inhalt);
			$alle_skv_temp='';
			$summe_haendlerpreis=0;
			if (isset($postfeld['skv_preis'])) {
			foreach ($postfeld['skv_preis'] as $skpid => $skpreis) {
				$skv_temp=$skv_template;
				$skvkfz='';
				$skvvin='';
				$skvid='';
				$skvkm='';
				$skvez='';
				$skvfarbe='';
				$skvhpreis='';
				$res3=$db->select(
					$sql_tab['produktzuordnung'],
					array(
						$sql_tabs['produktzuordnung']['fahrgestell'],
						$sql_tabs['produktzuordnung']['markencode'],
						$sql_tabs['produktzuordnung']['typ_modell'],
						$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'],
						$sql_tabs['produktzuordnung']['hersteller'],
						$sql_tabs['produktzuordnung']['differenzbesteuerung'],	// 5
						$sql_tabs['produktzuordnung']['datum_ez'],
						$sql_tabs['produktzuordnung']['buchnummer'],
						$sql_tabs['produktzuordnung']['km_stand'],
						$sql_tabs['produktzuordnung']['farbbezeichnung'],
						$sql_tabs['produktzuordnung']['aktuellervkpreis_mw']	// 10
					),
					$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($skpid)
				);
				if ($row3=$db->zeile($res3)) {
					$skvkfz=$row3[1].' '.$row3[2];
					$skvvin=$row3[0];
					$skvid=$row3[4];
					if ($skvid=='') {
						$skvid=$row3[7];
					}
					$skvkm=$row3[8];
					$skvez=$db->unixdate($row3[6]);
					$skvfarbe=$row3[9];
					$summe_haendlerpreis+=doubleval($row3[10]);
					$skvhpreis=doubleval($row3[10]);
				}
				$skv_diffzus='';
				if ($postfeld['skv_preis_diff'][$skpid]=='1') {
					$skv_diffzus=_DIFFBEST_.' - ';
				}
				$skv_temp=p4n_sb_strreplace('<<skvhpreis>>', number_format(doubleval($skvhpreis), 2, ",", "."), $skv_temp);
				$skv_temp=p4n_sb_strreplace('<<skvbrutto>>', number_format(doubleval(str_replace(',', '.', $skpreis)), 2, ",", "."), $skv_temp);
				$skv_temp=p4n_sb_strreplace('<<skvnetto>>', $skv_diffzus.number_format(doubleval(str_replace(',', '.', $postfeld['skv_preis_netto'][$skpid])), 2, ",", "."), $skv_temp);
				$skv_temp=p4n_sb_strreplace('<<skvkfz>>', $skvkfz, $skv_temp);
				$skv_temp=p4n_sb_strreplace('<<skvvin>>', $skvvin, $skv_temp);
				$skv_temp=p4n_sb_strreplace('<<skvid>>', $skvid, $skv_temp);
				$skv_temp=p4n_sb_strreplace('<<skvkm>>', $skvkm, $skv_temp);
				$skv_temp=p4n_sb_strreplace('<<skvez>>', $skvez, $skv_temp);
				$skv_temp=p4n_sb_strreplace('<<skvfarbe>>', $skvfarbe, $skv_temp);
				$alle_skv_temp.=$skv_temp;
			}
			}
			$inhalt=p4n_sb_strreplace('<<skv_gesamthpreis>>', number_format($summe_haendlerpreis, 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_preg_replace('/<<startskv>>.*<<endeskv>>/Uis', $alle_skv_temp, $inhalt);
		}
		
		$gef_nfz=false;
		if ($cfg_kfzsuche_novafreies_hzb) {
			$su_nfz=0;
			for ($ni=1; $ni<=20; $ni++) {
				if (!isset($postfeld['hzb_novafrei'.$ni])) {
					continue;
				}
				if ($postfeld['hzb_novafrei'.$ni]!='') {
					$gef_nfz=true;
					$inhalt=p4n_sb_strreplace('<<nfzbh'.$ni.'>>', $postfeld['hzb_novafrei'.$ni], $inhalt);
					$inhalt=p4n_sb_strreplace('<<nfzbhp'.$ni.'>>', number_format(doubleval(str_replace(',', '.', $postfeld['hzb_novafrei_preis'.$ni])), 2, ",", "."), $inhalt);
					$su_nfz+=doubleval(str_replace(',', '.', $postfeld['hzb_novafrei_preis'.$ni]));
					if ($cfg_kfzsuche_novafreies_hzb_v2) {
						$inhalt=p4n_sb_strreplace('<<nfzbhv'.$ni.'>>', $postfeld['hzb_novafrei_verr'.$ni], $inhalt);
					}
				}
				$inhalt=p4n_sb_strreplace('<<nfzbh'.$ni.'>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<nfzbhp'.$ni.'>>', '', $inhalt);
				if ($cfg_kfzsuche_novafreies_hzb_v2) {
					$inhalt=p4n_sb_strreplace('<<nfzbhv'.$ni.'>>', '', $inhalt);
				}
			}
			$inhalt=p4n_sb_strreplace('<<nfzbhp>>', number_format(doubleval(str_replace(',', '.', $su_nfz)), 2, ",", "."), $inhalt);
		}
		if ($gef_nfz) {
			$inhalt=p4n_sb_strreplace('<<start_nfzbh>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<ende_nfzbh>>', '', $inhalt);
		} else {
			$inhalt=p4n_sb_preg_replace('/<<start_nfzbh>>.*<<ende_nfzbh>>/Uis', '', $inhalt);
		}
		
		if ($zusv2!='') {
			$postfeld['vertrags_vereinbarungen']=$zusv2.$postfeld['vertrags_vereinbarungen'];
			$sv_ohnetext=$zusv2.$sv_ohnetext;
		}
		if (isset($postfeld['kfz_tz']) and intval($postfeld['kfz_tz'])==1) {
			$tztext='Garantie- und Wartungsintervall ab Datum Erstzulassung.';
			if (isset($cfg_kfzsuche_tztext)) {
				if ($cfg_kfzsuche_tztext!='') {
					$tztext=$cfg_kfzsuche_tztext;
				}
			}
			$zussonst2='';
			if ($cfg_kfzsuche_vorbesitzer_tz_text or $_SESSION['cfg_kunde']=='carlo_opel_duerkop') {
				$zussonst2.="\n".'Vorbesitzer: '.$postfeld['kfz_vorbesitzer'];
			}
			$postfeld['vertrags_vereinbarungen']='Erstzulassung: '.$postfeld['kfz_datum_ez'].$zussonst2.'\\par '.$tztext."\n".$postfeld['vertrags_vereinbarungen'];
			$sv_ohnetext='Erstzulassung: '.$postfeld['kfz_datum_ez'].$zussonst2.'\\par '.$tztext."\n".$sv_ohnetext;
		}
		if (isset($postfeld['dvs_kfzart'])) {
			if (intval($postfeld['dvs_kfzart'])==6) {
				$postfeld['vertrags_vereinbarungen']='Das Fahrzeug wurde als Selbstfahrervermietfahrzeug genutzt.'."\n".$postfeld['vertrags_vereinbarungen'];
				$sv_ohnetext='Das Fahrzeug wurde als Selbstfahrervermietfahrzeug genutzt.'."\n".$sv_ohnetext;
			}
		}
		$sep_so2='\\par ';
		if (isset($cfg_kfzsuche_sonstiges2_sep)) {
			$sep_so2=$cfg_kfzsuche_sonstiges2_sep;
		}
		
		$inhalt=p4n_sb_strreplace('<<sonstiges2>>', str_replace(array("\n", '<br>'), $sep_so2, $postfeld['vertrags_vereinbarungen']), $inhalt);
		$inhalt=p4n_sb_strreplace('<<sonstiges3>>', str_replace(array("\n", '<br>'), $sep_so2, $sv_ohnetext), $inhalt);
		
		if ($cfg_mboe_vorlagen) {
			$inhalt=p4n_sb_strreplace('<<zahlungsbedingungen>>', str_replace(array("\n", '<br>'), $sep_so2, $postfeld['vertrags_zahlungsbedingungen']), $inhalt);
			$kommnrneu=$retailer_prefix*10000000+intval($anr);
			$inhalt=str_replace('<<auftragsnr>>', $kommnrneu, $inhalt);
			$inhalt=str_replace('<<kommnr>>', $merke_herst, $inhalt);
			$inhalt=str_replace('<<kommissions_nr>>', $merke_herst, $inhalt);
		}
		
		if (trim($postfeld['vertrags_vereinbarungen'])=='') {
			$inhalt=p4n_sb_preg_replace('/<<sonsts>>.*<<sonste>>/Uis', '', $inhalt);
		}
		$inhalt=p4n_sb_strreplace(array('<<sonsts>>', '<<sonste>>'), '', $inhalt);
		
		// INzahlung:
        if (!empty($cfg_schwackenet) || (!empty($cfg_dat) && $cfg_dat === 3)) {
            $inhalt=p4n_sb_strreplace('<<vertrags_gwmodell>>', @$postfeld['vertrags_gwmodell'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwhsn>>', @$postfeld['vertrags_gwhsn'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwtsn>>', @$postfeld['vertrags_gwtsn'], $inhalt);
            //$inhalt=p4n_sb_strreplace('<<vertrags_gwfarbe>>', @$postfeld['vertrags_gwfarbe'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwbauart>>', @$postfeld['vertrags_gwbauart'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwhubraum>>', @$postfeld['vertrags_gwhubraum'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwkw>>', @$postfeld['vertrags_gwkw'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwps>>', @$postfeld['vertrags_gwps'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwbesitzer>>', @$postfeld['vertrags_gwbesitzer'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwserie>>', @$postfeld['vertrags_gwserie'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwsonder>>', @$postfeld['vertrags_gwsonder'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwnetto>>', @$postfeld['vertrags_gwnetto'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwmwst>>', @$postfeld['vertrags_gwmwst'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwanzahltueren>>', @$postfeld['vertrags_gwanzahltueren'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwgetriebe>>', @$postfeld['vertrags_gwgetriebe'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwzylinder>>', @$postfeld['vertrags_gwzylinder'], $inhalt);
            $inhalt=p4n_sb_strreplace('<<vertrags_gwkraftstoffart>>', @$postfeld['vertrags_gwkraftstoffart'], $inhalt);
        }
		$inhalt=p4n_sb_strreplace('<<vertrags_gwmarke>>', $postfeld['vertrags_gwmarke'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwmotor>>', $postfeld['vertrags_kennz'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwkennzeichen>>', $postfeld['vertrags_kennz'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwtyp>>', $postfeld['vertrags_gwtyp'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwfgnr>>', $postfeld['vertrags_gwfgnr'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwez>>', $postfeld['vertrags_gwez'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwkm>>', $postfeld['vertrags_kmstand'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwlieferung>>', $postfeld['vertrags_gwlieferung'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwmasse>>', $postfeld['vertrags_gewicht'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwfarbe>>', $postfeld['vertrags_farbe'], $inhalt);
		if ($tradein_erw_felder) {
			$inhalt=p4n_sb_strreplace('<<vertrags_gwmotornr>>', $postfeld['vertrags_gwmotornr'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<vertrags_gwhubraum>>', $postfeld['vertrags_gwhubraum'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<vertrags_gwleistungps>>', $postfeld['vertrags_gwleistungps'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<vertrags_gwleistungkw>>', $postfeld['vertrags_gwleistungkw'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<vertrags_gwanzahlbesitzer>>', $postfeld['vertrags_gwanzahlbesitzer'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<vertrags_gwlackfarbe>>', $postfeld['vertrags_gwlackfarbe'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<vertrags_gwanzahltueren>>', $postfeld['vertrags_gwanzahltueren'], $inhalt);
			$inhalt=p4n_sb_strreplace('<<vertrags_gwnatcode>>', $postfeld['vertrags_gwnatcode'], $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<vertrags_gwmarke2>>', $postfeld['vertrags_gwmarke2'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwmotor2>>', $postfeld['vertrags_kennz2'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwkennzeichen2>>', $postfeld['vertrags_kennz2'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwtyp2>>', $postfeld['vertrags_gwtyp2'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwfgnr2>>', $postfeld['vertrags_gwfgnr2'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwez2>>', $postfeld['vertrags_gwez2'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwkm2>>', $postfeld['vertrags_kmstand2'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwlieferung2>>', $postfeld['vertrags_gwlieferung2'], $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<vertrags_1umbauten>>', $postfeld['vertrags_atg_1'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_2nachlackierung>>', $postfeld['vertrags_atg_2'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_3tacho>>', $postfeld['vertrags_atg_3'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_4leasing>>', $postfeld['vertrags_atg_4'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_5betriebsanleitung>>', $postfeld['vertrags_atg_5'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_6leistungssteigerung>>', $postfeld['vertrags_atg_6'], $inhalt);
		
		$mit_unfall='';
		if (isset($postfeld['vertrags_unfall'])) {
			if ($postfeld['vertrags_unfall']=='1') {
				$mit_unfall=_NEIN_;
			} elseif ($postfeld['vertrags_unfall']=='2') {
				$mit_unfall=_JA_;
			}
		}
		$inhalt=p4n_sb_strreplace('<<vertrags_gwunf>>', $mit_unfall, $inhalt);
		
		if ($_SESSION['cfg_kunde']=='carlo_opel_wiens') {
			$inhalt=p4n_sb_strreplace('<<vertrags_gwpreis>>', number_format(doubleval(str_replace(',','.',$postfeld['vertrags_gwpreis'])), 2, ",","."), $inhalt);
		}
		if (isset($postfeld['vertrags_gwpreis_echt'])) {
			$inhalt=p4n_sb_strreplace('<<vertrags_gwpreis>>', number_format(doubleval(str_replace(',','.',$postfeld['vertrags_gwpreis_echt'])), 2, ",","."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<vertrags_gwpreis_haus>>', number_format(doubleval(str_replace(',','.',$postfeld['vertrags_gwpreis'])), 2, ",","."), $inhalt);
		}
		if ($cfg_ws_avag_kroatien or $cfg_kfzsuche_italien) {
			$inhalt=p4n_sb_strreplace('<<vertrags_gwpreis>>', number_format(doubleval($postfeld['vertrags_gwpreis']), 2, ",","."), $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<vertrags_gwpreis>>', ($cfg_kfzsuche_avag?$postfeld['vertrags_gwpreis']:number_format(doubleval($postfeld['vertrags_gwpreis']), 2, ",",".")), $inhalt);
		
		$inz_pr_brutto=doubleval(str_replace(',','.',$postfeld['vertrags_gwpreis']));
		if (isset($postfeld['vertrags_gwpreis_echt']) and $postfeld['vertrags_gwpreis_echt']!='') {
			$inz_pr_brutto=doubleval(str_replace(',','.',$postfeld['vertrags_gwpreis_echt']));
		}
		$inz_pr_netto=$inz_pr_brutto*100/((1+$cfg_mwst)*100);
		$inz_pr_mwst=$inz_pr_brutto-$inz_pr_netto;
		$inhalt=p4n_sb_strreplace('<<vertrags_gwpreis2>>', number_format(doubleval($inz_pr_brutto), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwmwst2>>', number_format(doubleval($inz_pr_mwst), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<vertrags_gwnetto2>>', number_format(doubleval($inz_pr_netto), 2, ",","."), $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<gwankauf_prozent>>', number_format(doubleval($postfeld['vertrags_gwpreisproz']), 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<gwankauf>>', 'Der Gebrauchtwagen ('.$postfeld['vertrags_gwmarke'].' '.$postfeld['vertrags_gwtyp'].' mit der Fahrgestellnummer '.$postfeld['vertrags_gwfgnr'].' und dem Kennzeichen '.$postfeld['vertrags_kennz'].') wird f�r '.($cfg_kfzsuche_avag?$postfeld['vertrags_gwpreis']:number_format(doubleval($postfeld['vertrags_gwpreis']), 2, ",", ".").' '.$waehrung_eur).' angekauft.', $inhalt);

		$inhalt=p4n_sb_strreplace('<<vdet_filiale>>', $postfeld['vertrag_lagerort'], $inhalt);
		
		if ($cfg_greek) {
			if (isset($cfg_quote_testdrivetext)) {
				if ($cfg_quote_testdrivetext!='') {
					$tdtext1='';
					$mpfgef=false;
					if (intval($postfeld['kbezug'])>0) {
						$res7=$db->select(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['produktzuordnung_id'],
								$sql_tabs['korrespondenz']['datum'],
								$sql_tabs['korrespondenz']['kategorie']
							),
							$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($postfeld['kbezug'])
						);
						if ($row7=$db->zeile($res7)) {
							if ($row7[2]==_PROBEFAHRT_) {
								$tdtext1=$cfg_quote_testdrivetext;
								$res5=$db->select(
									$sql_tab['produktzuordnung'],
									array(
										$sql_tabs['produktzuordnung']['kennzeichen'],
										$sql_tabs['produktzuordnung']['typ_modell']
									),
									$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($row7[0])
								);
								if ($row5=$db->zeile($res5)) {
									$tdtext1=str_replace('<<license>>', $row5[0], $tdtext1);
									$tdtext1=str_replace('<<typ>>', $row5[1], $tdtext1);
									$mpfgef=true;
								}
								$tdtext1=str_replace('<<license>>', '', $tdtext1);
								$tdtext1=str_replace('<<typ>>', '', $tdtext1);
							}
						}
					}
					if (1==2 and !$mpfgef) {
					$res7=$db->select(
						$sql_tab['korrespondenz'],
						array(
							$sql_tabs['korrespondenz']['produktzuordnung_id'],
							$sql_tabs['korrespondenz']['datum']
						),
						$sql_tabs['korrespondenz']['kategorie'].' like '.$db->str('%'._PROBEFAHRT_.'%').' and '.
							$sql_tabs['korrespondenz']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
							$sql_tabs['korrespondenz']['datum'].'>='.$db->dbtimestamp(time()-30*24*60*60),
						$sql_tabs['korrespondenz']['datum'].' desc'
					);
					if ($row7=$db->zeile($res7)) {
						$tdtext1=$cfg_quote_testdrivetext;
						$res5=$db->select(
							$sql_tab['produktzuordnung'],
							array(
								$sql_tabs['produktzuordnung']['kennzeichen'],
								$sql_tabs['produktzuordnung']['typ_modell']
							),
							$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($row7[0])
						);
						if ($row5=$db->zeile($res5)) {
							$tdtext1=str_replace('<<license>>', $row5[0], $tdtext1);
							$tdtext1=str_replace('<<typ>>', $row5[1], $tdtext1);
						}
						$tdtext1=str_replace('<<license>>', '', $tdtext1);
						$tdtext1=str_replace('<<typ>>', '', $tdtext1);
					}
					}
					$inhalt=p4n_sb_strreplace('<<testdrivetext>>', $tdtext1, $inhalt);
				}
			}
		}
		
			$mitarbeiter_info='';
			$res4=$db->select(
				$sql_tab['benutzer'],
				$sql_tabs['benutzer']['signatur2'],
				$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($ang_kv_user)
			);
			$row4=$db->zeile($res4);

			$kvu_name=$_SESSION['mitarbeiter_name'];
			$kvu_email=$_SESSION['user_email'];
			$kvu_fax=$_SESSION['benutzer_fax'];
			$kvu_mobilfon=$_SESSION['benutzer_mob'];
			$kvu_telefon=$_SESSION['benutzer_tel'];

			if ($ang_kv_user!=$_SESSION['user_id']) {
				$res5=$db->select(
					$sql_tab['benutzer'],
					array(
						$sql_tabs['benutzer']['signatur2'],
						$sql_tabs['benutzer']['vorname'],
						$sql_tabs['benutzer']['name'],
						$sql_tabs['benutzer']['email'],
						$sql_tabs['benutzer']['fax'],
						$sql_tabs['benutzer']['mobilfon'],
						$sql_tabs['benutzer']['telefon']
					),
					$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($ang_kv_user)
				);
				if ($row5=$db->zeile($res5)) {
					$kvu_name=$row5[1].' '.$row5[2];
					$kvu_email=$row5[3];
					$kvu_fax=$row5[4];
					$kvu_mobilfon=$row5[5];
					$kvu_telefon=$row5[6];
				}
			}
			$mitarbeiter_info=str_replace(array("\n", '<br>'), "\\par ", $row4[0]);
			$inhalt=p4n_sb_strreplace('<<mitarbeiter_info>>', $mitarbeiter_info, $inhalt);
			$inhalt=p4n_sb_strreplace('<<mitarbeiter>>', $kvu_name, $inhalt);
			$inhalt=p4n_sb_strreplace('<<mitarbeiter_email>>', $kvu_email, $inhalt);
			$inhalt=p4n_sb_strreplace('<<mitarbeiter_telefon>>', $kvu_telefon, $inhalt);
			$inhalt=p4n_sb_strreplace('<<mitarbeiter_fax>>', $kvu_fax, $inhalt);
			$inhalt=p4n_sb_strreplace('<<mitarbeiter_mobilfon>>', $kvu_mobilfon, $inhalt);
		
		if (isset($postfeld['garantie_fraeter1'])) {
			$gar_text_f='';
			if ($postfeld['garantie_fraeter1']!='-1') {
				$gar_text_f=$postfeld['garantie_fraeter1'];
			}
			if ($postfeld['garantie_fraeter2']!='') {
				$gar_text_f.=' '.$postfeld['garantie_fraeter2'];
			}
			$inhalt=p4n_sb_strreplace('<<garantie>>', trim($gar_text_f), $inhalt);
		}
		
		if (isset($postfeld['vdet_ohnegarantie'])) {
			$inhalt=p4n_sb_strreplace('<<garantie>>', 'ohne Garantie', $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<garantie>>', 'mit Gebrauchtwagengarantie', $inhalt);
		
		$ausst3='';
		$res3=$db->select(
			$sql_tab['produktzuordnung_ausstattung'],
			array(
				$sql_tabs['produktzuordnung_ausstattung']['beschreibung'],
				$sql_tabs['produktzuordnung_ausstattung']['beschreibung2'],
						$sql_tabs['produktzuordnung_ausstattung']['vk_preis_mwst'],
						$sql_tabs['produktzuordnung_ausstattung']['listen_preis_mwst'],
						$sql_tabs['produktzuordnung_ausstattung']['ausst_code'],
						$sql_tabs['produktzuordnung_ausstattung']['ausst_art'],		// 5
						$sql_tabs['produktzuordnung_ausstattung']['ausst_kennzeichen'],
						$sql_tabs['produktzuordnung_ausstattung']['serienausstattung'],
						$sql_tabs['produktzuordnung_ausstattung']['ausst_art_text'],
						$sql_tabs['produktzuordnung_ausstattung']['ausst_kennzeichen_text']
			),
			$sql_tabs['produktzuordnung_ausstattung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid']),
			$sql_tabs['produktzuordnung_ausstattung']['beschreibung']
		);
		while ($row3=$db->zeile($res3)) {
			$ausst3.=trim($row3[0].' '.$row3[1]).' \\par ';
			
			$zus_oder=false;
					if (isset($cfg_kfzsuche_fracht_code)) {
						@reset($cfg_kfzsuche_fracht_code);
						while (list($fkey, $fval)=@each($cfg_kfzsuche_fracht_code)) {
							if ($fval!='') {
								if (preg_match('/'.preg_quote($fval).'/i', $row6[0].$row6[1]) or preg_match('/'.preg_quote($fval).'/i', $row6[4])) {
									$zus_oder=true;
								}
							}
						}
					}
					$zus_oder2=false;
					if (isset($cfg_kfzsuche_neben_code)) {
						@reset($cfg_kfzsuche_neben_code);
						while (list($fkey, $fval)=@each($cfg_kfzsuche_neben_code)) {
							if ($fval!='') {
								if (preg_match('/'.preg_quote($fval).'/i', $row6[0].$row6[1]) or preg_match('/'.preg_quote($fval).'/i', $row6[4])) {
									$zus_oder2=true;
								}
							}
						}
					}
					$pr_neu1=doubleval($row6[2]);
					if ($pr_neu1<=0) {
						$pr_neu1=doubleval($row6[3]);
					}
					if (!$cfg_kfzsuche_austria and ($row6[5]=='' or $row6[5]=='3' or $row6[8]=='Eigene Ausstattung' or $row6[5]=='4' or $row6[8]=='Sonstige Artikel') and ($zus_oder2)) {
						continue;
					} elseif (($row6[5]=='' or $row6[5]=='3' or $row6[8]=='Eigene Ausstattung' or $row6[5]=='4' or $row6[8]=='Sonstige Artikel') and ($zus_oder or preg_match('/auslieferung/i', $row6[0]) or preg_match('/berf/i', $row6[0]) or preg_match('/transport/i', $row6[0]) or preg_match('/brief/i', $row6[0]) or preg_match('/bereit/i', $row6[0]) or preg_match('/nebenkosten/i', $row6[0]))) {
						continue;
					}
					if (preg_match('/transport/i', $row6[0])) {
						continue;
					}
					if (($row3[6]!='0' and $pr_neu1==0) or $row3[5]=='1' or $row3[8]=='Fahrzeug') {
						continue;
					}
					$aval=trim($row3[0].' '.$row3[1].($row3[4]!=''?' ('.trim($row3[4]).')':''));
					$aval2=$aval;
					$aval=str_replace(',', '__KO__', $aval);
					$row[10].=$aval.',';

					if ($row3[7]=='1') {
						$ausst5_serie.=$aval2.'\\par ';
						$ausst5_serie2.=$aval2.', ';
					} else {
						$ausst5_sonder.=$aval2.'\\par ';
						$ausst5_sonder2.=$aval2.', ';
					}
		}
		$ausst3=p4n_mb_string('substr',$ausst3, 0, -p4n_mb_string('strlen',' \\par '));
		if ($ausst3=='' and $ausst!='') {
			$ausst3=$ausst2;
		}
		
		$inhalt=p4n_sb_strreplace('<<ausstattung_sonder1>>', $ausst5_sonder, $inhalt);
		$inhalt=p4n_sb_strreplace('<<ausstattung_sonder2>>', $ausst5_sonder2, $inhalt);
		$inhalt=p4n_sb_strreplace('<<ausstattung_serie1>>', $ausst5_serie, $inhalt);
		$inhalt=p4n_sb_strreplace('<<ausstattung_serie2>>', $ausst5_serie2, $inhalt);
		
		if (p4n_mb_string('substr',$kfz_fstatus, 0, 7)=='Locator') {
			$ausst_text='';
			$xpl=explode("\n", $ausst);
			while (list($akey, $aval)=@each($xpl)) {
				$xpl2=explode('EUR netto', $aval);
				$ausst_text.=trim(p4n_mb_string('html_entity_decode',$xpl2[0])).'; ';
			}
			$ausst_text=p4n_mb_string('substr',$ausst_text, 0, -2);
			$ausst3=p4n_mb_string('html_entity_decode',$ausst_text);
		}

		$inhalt=p4n_sb_strreplace('<<ausstattung3>>', $ausst3, $inhalt);

		$checkboxen=array(
			'vertrags_ankauf' => 'gw_ankaufgw',	// Inzahlungnahme
			'vertrag_gwproto' => 'vdet_uebergabe',
			'vertrag_fahrbereit' => 'vdet_fahrbereit',
			'vertrag_taximietfs' => 'vdet_taxi',
			'vertrag_ahk' => 'vdet_haenger',
			'vertrag_unternehmer' => 'vdet_unternehmer',
			'vertrag_gwgarantieweg' => 'vdet_ohnegarantie',
			'fin_ust' => 'bar_regelsteuer',
			'fin_ust25' => 'vdet_vorsteuer',
			'vertrag_liefer_janein1' => 'vertrag_liefer_janein1',
			'vertrag_liefer_janein2' => 'vertrag_liefer_janein2',
			'vdet_liefer_janein1' => 'vdet_liefer_janein1',
			'vdet_liefer_janein2' => 'vdet_liefer_janein2',
			'vertrag_handelsgerichtlich' => 'h',
			'vertrag_janein3' => 'janein3'
		);
		while (list($cbkey, $cbval)=@each($checkboxen)) {
			$cb_ersetz=_NEIN_;
			if (isset($postfeld[$cbkey])) {
				$cb_ersetz=_JA_;
			}
			$inhalt=p4n_sb_strreplace('<<'.$cbval.'>>', $cb_ersetz, $inhalt);
		}

		if (isset($postfeld['vertrag_taximietfs'])) {
			if (!isset($cfg_kv_taximiettext)) {
				$cfg_kv_taximiettext='Kfz wurde laut Vorbesitzer als Taxi / Miet- oder Fahrschulwagen genutzt.';
			}
			$inhalt=p4n_sb_strreplace('<<vdet_taxi_satz>>', $cfg_kv_taximiettext, $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<vdet_taxi_satz>>', '', $inhalt);
		
		if (isset($postfeld['vertrag_ahk'])) {
			if (isset($cfg_kv_ahksatz) and $cfg_kv_ahksatz!='') {
				$inhalt=p4n_sb_strreplace('<<vdet_ahk_satz>>', $cfg_kv_ahksatz, $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<vdet_ahk_satz>>', 'Das Fahrzeug ist lt. Fz-Brief mit AHK ausgestattet.', $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<vdet_ahk_satz>>', '', $inhalt);

		if (isset($bezahl_order_data) && is_array($bezahl_order_data)) {
			$inhalt=p4n_sb_strreplace('<<kaufvertrag_iban>>', $bezahl_order_data['accountData']['viban'], $inhalt);
		}

		if ($_SESSION['cfg_kunde']=='carlo_koltes') {
			if (isset($postfeld['vertrag_fahrbereit'])) {
				$inhalt=p4n_sb_strreplace('<<vdet_fahrbereit_satz_en>>', 'No accidents according to the previous owner.', $inhalt);
			} else {
				$inhalt=p4n_sb_strreplace('<<vdet_fahrbereit_satz_en>>', '', $inhalt);
			}
			if (isset($postfeld['vertrag_gwproto'])) {
				$inhalt=p4n_sb_strreplace('<<ausfuhr_besteller>>', 'x', $inhalt);
			} else {
				$inhalt=p4n_sb_strreplace('<<ausfuhr_besteller>>', '', $inhalt);
			}
			if (isset($postfeld['vertrag_unternehmer'])) {
				$inhalt=p4n_sb_strreplace('<<vdet_unternehmer_text>>', 'x', $inhalt);
			} else {
				$inhalt=p4n_sb_strreplace('<<vdet_unternehmer_text>>', '', $inhalt);
			}
			if (isset($postfeld['fin_ust25'])) {
				$inhalt=p4n_sb_strreplace('<<keinmwst_text_en>>', 'VAT cannot be stated separately according to � 25a UStG', $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<keinmwst_text_en>>', '', $inhalt);
			if (isset($postfeld['fin_ust'])) {
				$inhalt=p4n_sb_strreplace('<<mwst_text_en>>', 'additionally '.strval(intval($cfg_mwst*100)).'% VAT', $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<mwst_text_en>>', '', $inhalt);
		}
		
		if (isset($postfeld['vertrag_fahrbereit'])) {
			if ($_SESSION['cfg_kunde']=='carlo_koltes') {
				$inhalt=p4n_sb_strreplace('<<vdet_fahrbereit_satz>>', 'Fahrzeug ist unfallfrei.', $inhalt);
			}
			$satz_kfzfahrbereit='Kfz ist fahrbereit.';
			if (isset($cfg_kfzsuche_satz_fahrzbereit) and $cfg_kfzsuche_satz_fahrzbereit!='') {
				$satz_kfzfahrbereit=$cfg_kfzsuche_satz_fahrzbereit;
			}
			if ($postfeld['vertrag_unfall']!='' and isset($cfg_kfzsuche_satz_fahrzbereit_mitunfalltext) and $cfg_kfzsuche_satz_fahrzbereit_mitunfalltext!='') {
				$satz_kfzfahrbereit=$cfg_kfzsuche_satz_fahrzbereit_mitunfalltext;
			}
			$inhalt=p4n_sb_strreplace('<<vdet_fahrbereit_satz>>', $satz_kfzfahrbereit, $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<vdet_fahrbereit_satz>>', '', $inhalt);
		
		if (isset($postfeld['idstatus']) and $cfg_kfzsuche_unternehmer_vonstatus) {
			if ($postfeld['idstatus']=='Wiederverk�ufer' or $postfeld['idstatus']=='gewerblich') {
				$postfeld['vertrag_unternehmer']='1';
			}
		}

		$zus_unternehmer='';
		if (isset($postfeld['vertrag_eugeschaeft'])) {
			$postfeld['vertrag_unternehmer']='1';
			$zus_unternehmer=' Netto Faktura nur bei positiver Pr�fung der Umsatzsteuer-ID-Nr. und Vorlage aller erforderlichen Unterlagen durch den K�ufer.';
		}
		if ($mitsatz_diffbest) {
			$zus_unternehmer.=' '._DIFFBEST_TEXT_;
		}
		
		$preis_steuertext='Preis inkl. Mehrwertsteuer';
		if ($mitsatz_diffbest) {
			$preis_steuertext='Verkauf erfolgt nach �25a UStG';
		}
		$inhalt=p4n_sb_strreplace('<<steuertext>>', $preis_steuertext, $inhalt);
		
		if ($cfg_greek) {
			$cfg_kv_unternehmertext=_KAEUFER_UNTERNEHMER_;
			$zus_unternehmer='';
		}
		
		if (isset($postfeld['vertrag_unternehmer'])) {
			if (!isset($cfg_kv_unternehmertext)) {
				$cfg_kv_unternehmertext='K�ufer ist Unternehmer. Fahrzeug wird unter Ausschluss jeglicher Garantie und Gew�hrleistung verkauft.';
			}
			$inhalt=p4n_sb_strreplace('<<vdet_unternehmer_text>>', $cfg_kv_unternehmertext.$zus_unternehmer, $inhalt);
		} else {
			if (!isset($cfg_kv_nichtunternehmertext)) {
//				$cfg_kv_nichtunternehmertext='Weitere Beschaffenheitsmerkmale des Fahrzeuges, insbesondere seines technischen Zustands, sind nicht vereinbart. Im Gew�hrleistungsfalls unbedingt vor Reparaturbeginn mit DB Fuhrpark Service in Verbindung setzen.';
			}
			$inhalt=p4n_sb_strreplace('<<vdet_unternehmer_text>>', $cfg_kv_nichtunternehmertext.$zus_unternehmer, $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<vdet_unternehmer_text>>', $zus_unternehmer, $inhalt);
		
		$m_cfg_mwst=$cfg_mwst;
		if ($cfg_kfzsuche_austria) {
			$cfg_mwst=( (1+$cfg_mwst) * (1+ doubleval(str_replace(',', '.', $postfeld['novasatz']))/100 )) -1;
		}
		$nova_zus_mwst=0;
		if ($cfg_kfzsuche_austria) {
			$nova_zus_mwst=doubleval(str_replace(',', '.', $postfeld['novasatz']))/100;
		}
		// NW-KV Dinge:
		// Sonderausstattung
		$preis_ges1=0;

		if ($postfeld['vertrag_nwgw']=='8') {
			$postfeld['vertrag_zulassung']=$postfeld['vertrag5_neben'];
			$postfeld['vertrag_transport']=$postfeld['vertrag5_transport'];
		}

		$su_t_z_lux=doubleval(str_replace(',', '.', $postfeld['vertrag5_luxurytax']));
		$su_t_z_lux+=doubleval(str_replace(',', '.', $postfeld['vertrag_transport']));
		$su_t_z_lux+=doubleval(str_replace(',', '.', $postfeld['vertrag_zulassung']));
		$inhalt=p4n_sb_strreplace('<<tzlux>>', number_format($su_t_z_lux, 2, ",", "."), $inhalt);
		
		$werkpreis=doubleval(str_replace(',', '.', $postfeld['listenpreis']));

		$summe_alle_aus=0;

		if (intval($postfeld['vertrag_nwgw'])>=4) {
			$au_plus=0;
			$ve_zus=2;
			$maxzeilen=11;
			if ($cfg_kfzsuche_maxzeilen) {
				if (intval($cfg_kfzsuche_maxzeilen)>1) {
					$maxzeilen=$cfg_kfzsuche_maxzeilen;
				}
			}
			if (intval($postfeld['nwvorlage'])==4) {
				$maxzeilen=1000;
			}
			if (intval($postfeld['vertrag_nwgw'])==5 or intval($postfeld['vertrag_nwgw'])==7) {
				$ve_zus=3;
			}
			$genutzte_zeilen=0;
			if (intval($postfeld['vertrag_nwgw'])==8) {

				$aus_kurz_daten=array();
				$aus_kurz_daten_hz=array();
				$aus_kurz_daten_nl=array();
				$su_ausst=0;
				$su_ausst2=0;
				$su_ausst_netto=0;

				if (isset($postfeld['messa_su_strada_sep'])) {
					$aus_kurz_daten[]=array('Messa su strada (soggetto IVA)', str_replace(',', '.', $postfeld['vertrag_transport']), doubleval(str_replace(',', '.', $postfeld['vertrag_transport']))/(1+$cfg_mwst) );
					$aus_kurz_daten[]=array('Immatricolazione (non soggetta IVA)', str_replace(',', '.', $postfeld['vertrag5_neben2']), doubleval(str_replace(',', '.', $postfeld['vertrag5_neben2']))/(1+$cfg_mwst) );
				}

				$ve_zus=5;
				if (intval($postfeld['vertrag5_farbepreis'])!=0) {
					$au_plus++;
					$soa_p=str_replace(',', '.', $postfeld['vertrag5_farbepreis']);
					$werkpreis+=doubleval($soa_p);
					$su_ausst2+=doubleval($soa_p);
					$soa_p2=str_replace(',', '.', $postfeld['vertrag5_farbepreis']);
					$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
					$soa_p2=number_format(doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_farbepreis'])), 2, ".", ""))/(1+$cfg_mwstn), 2, ",", ".");
					$nl_aus_temp1=doubleval(str_replace(',', '.', $postfeld['net_farbe5']));
					if ($nl_aus_temp1!=0) {
						$soa_p2=number_format($nl_aus_temp1, 2, ",", ".");
						$su_ausst_netto+=$nl_aus_temp1;
					}
					$preis_ges1+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_farbepreis'])), 2, ".", ""));
					if ($variante2) {
						$az1=$ausst_zeilen;
						if ($cfg_kfzsuche_holland) {
							$az1=p4n_sb_strreplace('<<sondera2>>', '{\b '.$postfeld['vertrag5_farbe'].'}', $az1);
						}
						$az1=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag5_farbe'], $az1);
						if (!isset($postfeld['fin_ust_gk'])) {
							$soa_p2='';
						}
						$az1=p4n_sb_strreplace('<<sonderpx2_netto>>', $soa_p2, $az1);
						$az1=p4n_sb_strreplace('<<sonderpx2>>', $soa_p, $az1);
						$az1=p4n_sb_strreplace('<<sonderpagn>>', '', $az1);
						$az1=p4n_sb_strreplace('<<sonderpag>>', '', $az1);
						$ausst_zeilean.=$az1;
						$su_ausst+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_farbepreis'])), 2, ".", ""));
					}
					$az1=$ausst_zeile;
					if ($cfg_kfzsuche_holland) {
						$az1=p4n_sb_strreplace('<<sondera>>', '{\b '.$postfeld['vertrag5_farbe'].'}', $az1);
					}
					$az1=p4n_sb_strreplace('<<sondera>>', $postfeld['vertrag5_farbe'], $az1);
					if (!isset($postfeld['fin_ust_gk'])) {
						$soa_p2='';
					}
					$az1=p4n_sb_strreplace('<<sonderpx_netto>>', $soa_p2, $az1);
					$az1=p4n_sb_strreplace('<<sonderpx>>', $soa_p, $az1);
					$az1=p4n_sb_strreplace('<<sonderpagn>>', '', $az1);
					$az1=p4n_sb_strreplace('<<sonderpag>>', '', $az1);
					$ausst_zeilea.=$az1;
//					$genutzte_zeilen++;
					if (!$variante2) {
						$aus_kurz_daten[]=array($postfeld['vertrag5_farbe'], str_replace(',', '.', $postfeld['vertrag5_farbepreis']), str_replace(',', '.', $postfeld['net_farbe5']));
					}
				} elseif ($postfeld['vertrag5_farbe']!='' and $postfeld['vertrag5_farbe']!=' ()') {
					if ($variante2) {
						$az1=$ausst_zeilen;
						if ($cfg_kfzsuche_holland) {
							$az1=p4n_sb_strreplace('<<sondera2>>', '{\b '.$postfeld['vertrag5_farbe'].'}', $az1);
						}
						$az1=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag5_farbe'], $az1);
						if (!isset($postfeld['fin_ust_gk'])) {
							$az1=p4n_sb_strreplace('<<sonderpx2_netto>>', '', $az1);
						} else {
							$az1=p4n_sb_strreplace('<<sonderpx2_netto>>', number_format(0, 2, ",", "."), $az1);
						}
						$az1=p4n_sb_strreplace('<<sonderpx2>>', number_format(0, 2, ",", "."), $az1);
						$az1=p4n_sb_strreplace('<<sonderpagn>>', '', $az1);
						$az1=p4n_sb_strreplace('<<sonderpag>>', '', $az1);
						$ausst_zeilean.=$az1;
					}
					$az1=$ausst_zeile;
					if ($cfg_kfzsuche_holland) {
						$az1=p4n_sb_strreplace('<<sondera>>', '{\b '.$postfeld['vertrag5_farbe'].'}', $az1);
					}
					$az1=p4n_sb_strreplace('<<sondera>>', $postfeld['vertrag5_farbe'], $az1);
					if (!isset($postfeld['fin_ust_gk'])) {
						$az1=p4n_sb_strreplace('<<sonderpx_netto>>', '', $az1);
					} else {
						$az1=p4n_sb_strreplace('<<sonderpx_netto>>', number_format(0, 2, ",", "."), $az1);
					}
					$az1=p4n_sb_strreplace('<<sonderpx>>', number_format(0, 2, ",", "."), $az1);
					$az1=p4n_sb_strreplace('<<sonderpagn>>', '', $az1);
					$az1=p4n_sb_strreplace('<<sonderpag>>', '', $az1);
					$ausst_zeilea2.=$az1;
				}

				if (intval($postfeld['vertrag5_trimpreis'])!=0) {
					$au_plus++;
					$soa_p=str_replace(',', '.', $postfeld['vertrag5_trimpreis']);
					$soa_p2=str_replace(',', '.', $postfeld['vertrag5_trimpreis']);
					$werkpreis+=doubleval($soa_p);
					$su_ausst2+=doubleval($soa_p);
					$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
					$soa_p2=number_format(doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_trimpreis'])), 2, ".", ""))/(1+$cfg_mwstn), 2, ",", ".");
					$nl_aus_temp1=doubleval(str_replace(',', '.', $postfeld['net_trim5']));
					if ($nl_aus_temp1!=0) {
						$soa_p2=number_format($nl_aus_temp1, 2, ",", ".");
						$su_ausst_netto+=$nl_aus_temp1;
					}
					$preis_ges1+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_trimpreis'])), 2, ".", ""));
					if ($variante2) {
						$az1=$ausst_zeilen;
						if ($cfg_kfzsuche_holland) {
							$az1=p4n_sb_strreplace('<<sondera2>>', '{\b '.$postfeld['vertrag5_trim'].'}', $az1);
						}
						$az1=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag5_trim'], $az1);
						if (!isset($postfeld['fin_ust_gk'])) {
							$soa_p2='';
						}
						$az1=p4n_sb_strreplace('<<sonderpx2_netto>>', $soa_p2, $az1);
						$az1=p4n_sb_strreplace('<<sonderpx2>>', $soa_p, $az1);
						$az1=p4n_sb_strreplace('<<sonderpagn>>', '', $az1);
						$az1=p4n_sb_strreplace('<<sonderpag>>', '', $az1);
						$ausst_zeilean.=$az1;
						$su_ausst+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_trimpreis'])), 2, ".", ""));
					}
					$az1=$ausst_zeile;
					if ($cfg_kfzsuche_holland) {
						$az1=p4n_sb_strreplace('<<sondera>>', '{\b '.$postfeld['vertrag5_trim'].'}', $az1);
					}
					$az1=p4n_sb_strreplace('<<sondera>>', $postfeld['vertrag5_trim'], $az1);
					if (!isset($postfeld['fin_ust_gk'])) {
						$soa_p2='';
					}
					$az1=p4n_sb_strreplace('<<sonderpx_netto>>', $soa_p2, $az1);
					$az1=p4n_sb_strreplace('<<sonderpx>>', $soa_p, $az1);
					$az1=p4n_sb_strreplace('<<sonderpagn>>', '', $az1);
					$az1=p4n_sb_strreplace('<<sonderpag>>', '', $az1);
					$ausst_zeilea.=$az1;
//					$genutzte_zeilen++;
					if (!$variante2) {
						$aus_kurz_daten[]=array($postfeld['vertrag5_trim'], str_replace(',', '.', $postfeld['vertrag5_trimpreis']), str_replace(',', '.', $postfeld['net_trim5']));
					}
				} elseif ($postfeld['vertrag5_trim']!='' and $postfeld['vertrag5_trim']!=' ()') {
					if ($variante2) {
						$az1=$ausst_zeilen;
						if ($cfg_kfzsuche_holland) {
							$az1=p4n_sb_strreplace('<<sondera2>>', '{\b '.$postfeld['vertrag5_trim'].'}', $az1);
						}
						$az1=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag5_trim'], $az1);
						if (!isset($postfeld['fin_ust_gk'])) {
							$az1=p4n_sb_strreplace('<<sonderpx2_netto>>', '', $az1);
						} else {
							$az1=p4n_sb_strreplace('<<sonderpx2_netto>>', number_format(0, 2, ",", "."), $az1);
						}
						$az1=p4n_sb_strreplace('<<sonderpx2>>', number_format(0, 2, ",", "."), $az1);
						$az1=p4n_sb_strreplace('<<sonderpagn>>', '', $az1);
						$az1=p4n_sb_strreplace('<<sonderpag>>', '', $az1);
						$ausst_zeilean.=$az1;
					}
					$az1=$ausst_zeile;
					if ($cfg_kfzsuche_holland) {
						$az1=p4n_sb_strreplace('<<sondera>>', '{\b '.$postfeld['vertrag5_trim'].'}', $az1);
					}
					$az1=p4n_sb_strreplace('<<sondera>>', $postfeld['vertrag5_trim'], $az1);
					if (!isset($postfeld['fin_ust_gk'])) {
						$az1=p4n_sb_strreplace('<<sonderpx_netto>>', '', $az1);
					} else {
						$az1=p4n_sb_strreplace('<<sonderpx_netto>>', number_format(0, 2, ",", "."), $az1);
					}
					$az1=p4n_sb_strreplace('<<sonderpx>>', number_format(0, 2, ",", "."), $az1);
					$az1=p4n_sb_strreplace('<<sonderpagn>>', '', $az1);
					$az1=p4n_sb_strreplace('<<sonderpag>>', '', $az1);
					$ausst_zeilea2.=$az1;
				}
			}
		// Anzahl Nachl�sse:
		$anz_nl=0;
		for ($auss_i=1; $auss_i<=4; $auss_i++) {
			$auss_iz=$auss_i;
			if (isset($postfeld['preisa_d'.$auss_iz])) {
				$anz_nl++;
			}
		}
		if ($anz_nl>0) {
			$genutzte_zeilen++;
		}
		// Anzahl eigenes Zubeh�r:
		$anz_hz=0;
		$zeilen_hzb=5;
		if (isset($cfg_kfzsuche_zeilen_haendlerzubehoer)) {
			if (intval($cfg_kfzsuche_zeilen_haendlerzubehoer)>0) {
				$zeilen_hzb=$cfg_kfzsuche_zeilen_haendlerzubehoer;
			}
		}
		$max_ausi=0;
		for ($auss_i=1; $auss_i<=50; $auss_i++) {
			$auss_iz=$auss_i;
			if ($postfeld['vertrag'.$ve_zus.'_sonderz'.$auss_iz]!='') {
				$max_ausi=$auss_i;
			}
		}
		if ($max_ausi>$zeilen_hzb) {
			$zeilen_hzb=$max_ausi;
		}
		for ($auss_i=1; $auss_i<=$zeilen_hzb; $auss_i++) {
			$auss_iz=$auss_i;
			if ($postfeld['vertrag'.$ve_zus.'_sonderz'.$auss_iz]!='') {
				if ($cfg_kfzsuche_hzb_druckoption and !isset($postfeld['hzbdruck'.$auss_iz]) and !isset($postfeld['hzbdruckp'.$auss_iz])) {
					continue;
				}
				$anz_hz++;
			}
		}
		if ($anz_hz>0 or ($mit_nachlass_oben and $m_sum_pag_nl!=0)) {
			$genutzte_zeilen++;
		}
		
		if ($cfg_kfzsuche_levy or $cfg_kfzsuche_gerding or $cfg_kfzsuche_platzhalter_ausst) {
			$basis_i=0;
			if (trim($postfeld['vertrag5_farbe'])!='' or str_replace(',', '.', $postfeld['vertrag5_farbepreis'])>0) {
				$basis_i++;
				$abez1=trim($postfeld['vertrag5_farbe']);
				$apreis1=number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_farbepreis'])), 2, ",", ".");
				$apreis1n=number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_farbepreis']))*100/(100+(100*$cfg_mwst)), 2, ",", ".");
				$inhalt=p4n_sb_strreplace('<<ausst_werk'.$basis_i.'>>', $abez1, $inhalt);
				$inhalt=p4n_sb_strreplace('<<ausst_werkpreis'.$basis_i.'>>', $apreis1, $inhalt);
				$inhalt=p4n_sb_strreplace('<<ausst_werkpreisnetto'.$basis_i.'>>', $apreis1n, $inhalt);
			}
			if (trim($postfeld['vertrag5_trim'])!='' or str_replace(',', '.', $postfeld['vertrag5_trimpreis'])>0) {
				$basis_i++;
				$abez1=trim($postfeld['vertrag5_trim']);
				$apreis1=number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_trimpreis'])), 2, ",", ".");
				$apreis1n=number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_trimpreis']))*100/(100+(100*$cfg_mwst)), 2, ",", ".");
				$inhalt=p4n_sb_strreplace('<<ausst_werk'.$basis_i.'>>', $abez1, $inhalt);
				$inhalt=p4n_sb_strreplace('<<ausst_werkpreis'.$basis_i.'>>', $apreis1, $inhalt);
				$inhalt=p4n_sb_strreplace('<<ausst_werkpreisnetto'.$basis_i.'>>', $apreis1n, $inhalt);
			}
			for ($auss_i=1; $auss_i<=100; $auss_i++) {
				$abez1='';
				$apreis1='';
				$apreis1n='';
				if (isset($postfeld['vertrag5_sonder'.$auss_i]) and $postfeld['vertrag5_sonder'.$auss_i]!='') {
					$abez1=trim($postfeld['vertrag5_sonder'.$auss_i]);
					$apreis1=number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderpreis'.$auss_i])), 2, ",", ".");
					$apreis1n=number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderpreis'.$auss_i]))*100/(100+(100*$cfg_mwst)), 2, ",", ".");
				}
				$inhalt=p4n_sb_strreplace('<<ausst_werk'.($auss_i+$basis_i).'>>', $abez1, $inhalt);
				
				if (isset($postfeld['levy_ausstpreisd']) or $cfg_kfzsuche_platzhalter_ausst) {
					$inhalt=p4n_sb_strreplace('<<ausst_werkpreis'.($auss_i+$basis_i).'>>', $apreis1, $inhalt);
					$inhalt=p4n_sb_strreplace('<<ausst_werkpreisnetto'.($auss_i+$basis_i).'>>', $apreis1n, $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<ausst_werkpreis'.($auss_i+$basis_i).'>>', '', $inhalt);
					$inhalt=p4n_sb_strreplace('<<ausst_werkpreisnetto'.($auss_i+$basis_i).'>>', '', $inhalt);
				}
				$habez1='';
				$hapreis1='';
				$hapreis1n='';
				if (isset($postfeld['vertrag5_sonderz'.$auss_i]) and $postfeld['vertrag5_sonderz'.$auss_i]!='') {
					$habez1=trim($postfeld['vertrag5_sonderz'.$auss_i]);
					$hapreis1=number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderzpreis'.$auss_i])), 2, ",", ".");
					$hapreis1n=number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderzpreis'.$auss_i]))*100/(100+(100*$cfg_mwst)), 2, ",", ".");
				}
				$inhalt=p4n_sb_strreplace('<<ausst_hzb'.$auss_i.'>>', $habez1, $inhalt);
				if (isset($postfeld['levy_ausstpreisd']) or $cfg_kfzsuche_platzhalter_ausst) {
					$inhalt=p4n_sb_strreplace('<<ausst_hzbpreis'.$auss_i.'>>', $hapreis1, $inhalt);
					$inhalt=p4n_sb_strreplace('<<ausst_hzbpreisnetto'.$auss_i.'>>', $hapreis1n, $inhalt);
				} else {
					$inhalt=p4n_sb_strreplace('<<ausst_hzbpreis'.$auss_i.'>>', '', $inhalt);
					$inhalt=p4n_sb_strreplace('<<ausst_hzbpreisnetto'.$auss_i.'>>', '', $inhalt);
				}
			}
		}
		
		for ($auss_i=1; $auss_i<=500; $auss_i++) {
			$auss_iz=$auss_i;
			if ($_SESSION['cfg_kunde']=='carlo_opel_nl_mulders' and $cfg_kfzsuche_holland and intval($postfeld['vertrag_nwgw'])==8 and intval($postfeld['nwvorlage'])==1 and doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderpreis'.$auss_iz]))==0 and preg_match('/\:/', $postfeld['vertrag'.$ve_zus.'_sonder'.$auss_iz])) {
				continue;
			}
			if ($cfg_kfzsuche_sonderausst_preis0_raus and doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderpreis'.$auss_iz]))==0) {
				continue;
			}
			if ($postfeld['vertrag'.$ve_zus.'_sonder'.$auss_iz]!='') {
				$soa_p=str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderpreis'.$auss_iz]);
				$werkpreis+=doubleval($soa_p);
				$su_ausst2+=doubleval($soa_p);

				$soa_p2=str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderpreis'.$auss_iz]);
				if (trim($postfeld['vertrag'.$ve_zus.'_sonder'.$auss_iz])!='') {
					$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
					$soa_p2=number_format(doubleval(number_format(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderpreis'.$auss_iz]), 2, ".", ""))/(1+$cfg_mwstn), 2, ",", ".");
					$nl_aus_temp1=doubleval(str_replace(',', '.', $postfeld['net_aus5'.$auss_iz]));
					if ($nl_aus_temp1!=0) {
						$soa_p2=number_format($nl_aus_temp1, 2, ",", ".");
						$su_ausst_netto+=$nl_aus_temp1;
					}
					$preis_ges1+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderpreis'.$auss_iz])), 2, ".", ""));
				}
				$az2='';
				if ($variante2) {
							if (preg_match('/.*\((.*)\)$/', $postfeld['vertrag'.$ve_zus.'_sonder'.$auss_iz], $mat2)) {
								if (!$cfg_kfzsuche_keine_subopts and isset($postfeld['vertrag5_allesubs'][trim($mat2[1])])) {
									$alle_subaus1=explode('<br>', $postfeld['vertrag5_allesubs'][trim($mat2[1])]);
									while (list($keys, $vals)=@each($alle_subaus1)) {
										if ($vals=='') {
											continue;
										}
										$az1=$ausst_zeilen;
										$az1=p4n_sb_strreplace('<<sondera2>>', $vals, $az1);
										$az1=p4n_sb_strreplace('<<sonderpx2_netto>>', '', $az1);
										$az1=p4n_sb_strreplace('<<sonderpx2>>', '', $az1);
										$az1=p4n_sb_strreplace('<<sonderpagn>>', '', $az1);
										$az1=p4n_sb_strreplace('<<sonderpag>>', '', $az1);
										$az2.=$az1;
									}
//									$z_aust1="\\par ".str_replace(array("\n", '<br>'), "\\par ", $postfeld['vertrag5_allesubs'][trim($mat2[1])]);
								}
							}
						$az1=$ausst_zeilen;
						if ($cfg_kfzsuche_holland) {
							$az1=p4n_sb_strreplace('<<sondera2>>', $startfett_nl.$postfeld['vertrag'.$ve_zus.'_sonder'.$auss_iz].$endfett_nl, $az1);
						}
						$az1=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag'.$ve_zus.'_sonder'.$auss_iz], $az1);
						if (!isset($postfeld['fin_ust_gk'])) {
							$soa_p2='';
						}
						$az1=p4n_sb_strreplace('<<sonderpx2_netto>>', $soa_p2, $az1);
						$az1=p4n_sb_strreplace('<<sonderpx2>>', $soa_p, $az1);
						$az1=p4n_sb_strreplace('<<sonderpagn>>', '', $az1);
						$az1=p4n_sb_strreplace('<<sonderpag>>', '', $az1);
						if (p4n_mb_string('strpos',$ausst_zeilean, $az1)===false) {
							$ausst_zeilean.=$az1.$az2;
						}
						$su_ausst+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderpreis'.$auss_iz])), 2, ".", ""));
						if (doubleval($soa_p)==0) {
							if (p4n_mb_string('strpos',$ausst_zeilea2n, $az1)===false) {
								$ausst_zeilea2n.=$az1;
							}
						}
				}
				$az1=$ausst_zeile;
				$az1=p4n_sb_strreplace('<<sondera>>', $postfeld['vertrag'.$ve_zus.'_sonder'.$auss_iz], $az1);
				if (!isset($postfeld['fin_ust_gk'])) {
					$soa_p2='';
				}
				$az1=p4n_sb_strreplace('<<sonderpx_netto>>', $soa_p2, $az1);
				$az1=p4n_sb_strreplace('<<sonderpx>>', $soa_p, $az1);
				$ausst_zeilea.=$az1;
				if (doubleval($soa_p)==0) {
					$ausst_zeilea2.=$az1;
				}

				if ($variante2) {

				} else {
					$soa_p2t=str_replace(',', '.', $postfeld['net_aus5'.$auss_iz]);
					if ($cfg_ws_avag_kroatien) {
						$soa_p2t=doubleval(number_format(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderpreis'.$auss_iz]), 2, ".", ""))/(1+$cfg_mwstn);
					}
					$aus_kurz_daten[]=array($postfeld['vertrag'.$ve_zus.'_sonder'.$auss_iz], str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderpreis'.$auss_iz]), $soa_p2t);
				}
			}
		}
		
		if ($variante2 and $cfg_kfzsuche_variante2_pag) {
			for ($auss_i=1; $auss_i<=50; $auss_i++) {
				$auss_iz=$auss_i;
				if (isset($postfeld['preisa_d'.$auss_iz]) and (doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrpreis'.$auss_iz]))!=0 or $cfg_kfzsuche_preisangl_null)) {
					if ($postfeld['vertrag'.$ve_zus.'_sonderr'.$auss_iz]!='') {
						$az1=$ausst_zeilen;
						
						$soa_p=str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrpreis'.$auss_iz]);
						$msp1=$soa_p;
						$soa_p2=str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrpreis'.$auss_iz]);
						
						if (doubleval($soa_p)<0) {
							$soa_p=abs($soa_p);
						} else {
							$soa_p=-doubleval($soa_p);
						}
						if (doubleval($soa_p2)<0) {
							$soa_p2=abs($soa_p2);
						} else {
							$soa_p2=-doubleval($soa_p2);
						}
						$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
						$soa_p2=number_format(doubleval(number_format(doubleval($soa_p2), 2, ".", ""))/(1+$cfg_mwstn+$nova_zus_mwst), 2, ",", ".");
						
						$az1=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag'.$ve_zus.'_sonderr'.$auss_iz], $az1);
						
						if (!isset($postfeld['fin_ust_gk'])) {
							$soa_p2='';
						} elseif ($cfg_kfzsuche_preisa_proz) {
							$soa_p=number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrppreis'.$auss_iz])), 2, ",", "").' - '.$soa_p;
							$soa_p2=number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrppreis'.$auss_iz])), 2, ",", "").' - '.$soa_p2;
						}
						$az1=p4n_sb_strreplace('<<sonderpx2_netto>>', '', $az1);
						$az1=p4n_sb_strreplace('<<sonderpx2>>', '', $az1);
						$az1=p4n_sb_strreplace('<<sonderpagn>>', $soa_p2, $az1);
						$az1=p4n_sb_strreplace('<<sonderpag>>', $soa_p, $az1);
						$ausst_zeilean.=$az1;
					}
				}
			}
		}
		
		$serie_komma='';
		
		if (intval($postfeld['vertrag_nwgw'])==8) {
			if (intval($postfeld['nwvorlage'])==3 or intval($postfeld['nwvorlage'])==4) {
				for ($auss_i=1; $auss_i<=500; $auss_i++) {
					$auss_iz=$auss_i;
					if (isset($postfeld['vertrag5_sonders'.$auss_iz]) and $postfeld['vertrag5_sonders'.$auss_iz]!='') {
						$soa_p=str_replace(',', '.', $postfeld['vertrag5_sonderpreiss'.$auss_iz]);
						$soa_p2=$soa_p;
						$nl_aus_temp1=doubleval(str_replace(',', '.', $postfeld['net_aus5'.$auss_iz]));
						if ($nl_aus_temp1>0) {
							$soa_p2=number_format($nl_aus_temp1, 2, ",", ".");
							$su_ausst_netto+=$nl_aus_temp1;
						}
						$az2='';
						$ist_spaket=false;
						if ($variante2) {
							if (preg_match('/.*\((.*)\)$/', $postfeld['vertrag5_sonders'.$auss_iz], $mat2)) {
								if (isset($postfeld['vertrag5_allesubs'][trim($mat2[1])])) {
									$ist_spaket=true;
									$alle_subaus1=explode('<br>', $postfeld['vertrag5_allesubs'][trim($mat2[1])]);
									while (list($keys, $vals)=@each($alle_subaus1)) {
										if ($vals=='') {
											continue;
										}
										$az1=$ausst_zeilen;
										$az1=p4n_sb_strreplace('<<sondera2>>', $vals, $az1);
										$az1=p4n_sb_strreplace('<<sonderpx2_netto>>', '', $az1);
										$az1=p4n_sb_strreplace('<<sonderpx2>>', '', $az1);
										$az2.=$az1;
									}
//									$z_aust1="\\par ".str_replace(array("\n", '<br>'), "\\par ", $postfeld['vertrag5_allesubs'][trim($mat2[1])]);
								}
							}
							$az1=$ausst_zeilen;
							if ($cfg_kfzsuche_holland) {
								$az1=p4n_sb_strreplace('<<sondera2>>', $startfett_nl.$postfeld['vertrag5_sonders'.$auss_iz].$endfett_nl, $az1);
							}
							$az1=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag5_sonders'.$auss_iz], $az1);
							$soa_pn=number_format(doubleval($soa_p), 2, ",", ".");
							$soa_p2n=number_format(doubleval($soa_p)/(1+$cfg_mwstn), 2, ",", ".");
							if (!isset($postfeld['fin_ust_gk'])) {
								$soa_p2n='';
							}
							$az1=p4n_sb_strreplace('<<sonderpx2_netto>>', $soa_p2n, $az1);
							$az1=p4n_sb_strreplace('<<sonderpx2>>', $soa_pn, $az1);
							if (p4n_mb_string('strpos',$ausst_zeilean, $az1)===false) {
								$ausst_zeilean.=$az1.$az2;
							}
							$su_ausst+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderpreiss'.$auss_iz])), 2, ".", ""));
							if (doubleval($soa_pn)==0) {
								if (p4n_mb_string('strpos',$ausst_zeilea2n, $az1)===false) {
									$ausst_zeilea2n.=$az1;
								}
							}
						}
						$serie_komma.=kfzs_klammerraus($postfeld['vertrag5_sonders'.$auss_iz]).', ';
						$az1=$ausst_zeile;
						$az1=p4n_sb_strreplace('<<sondera>>', $postfeld['vertrag5_sonders'.$auss_iz], $az1);
						$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
						$soa_p2=number_format(doubleval($soa_p)/(1+$cfg_mwstn), 2, ",", ".");
						if (!isset($postfeld['fin_ust_gk'])) {
							$soa_p2='';
						}
						$az1=p4n_sb_strreplace('<<sonderpx_netto>>', $soa_p2, $az1);
						$az1=p4n_sb_strreplace('<<sonderpx>>', $soa_p, $az1);
						$ausst_zeilea.=$az1;
						if (doubleval($soa_p)==0) {
							$ausst_zeilea2.=$az1;
						}
					}
				}
			}
		
		$m_listenp_hersteller=$preis_ges1+doubleval(str_replace(',', '.', $postfeld['listenpreis']));
		
		// eigenes Zubeh�r:
		$hzb_istdrin=false;
		$summe_hzb=0;
		for ($auss_i=1; $auss_i<=$zeilen_hzb; $auss_i++) {
			$auss_iz=$auss_i;
			if ($postfeld['vertrag'.$ve_zus.'_sonderz'.$auss_iz]!='') {
				$soa_p=str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderzpreis'.$auss_iz]);
				$soa_p2=str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderzpreis'.$auss_iz]);
				if (trim($postfeld['vertrag'.$ve_zus.'_sonderz'.$auss_iz])!='') {
					$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
					$soa_p2=number_format(doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderzpreis'.$auss_iz])), 2, ".", ""))/(1+$m_cfg_mwst+$nova_zus_mwst), 2, ",", ".");
					$preis_ges1+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderzpreis'.$auss_iz])), 2, ".", ""));
					$summe_hzb+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderzpreis'.$auss_iz])), 2, ".", ""));
					$hzb_istdrin=true;
					if ($cfg_ws_avag_kroatien) {
						$su_ausst2+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderzpreis'.$auss_iz])), 2, ".", ""));
					}
				}
				$az1=$ausst_zeile;
				
				if ($cfg_kfzsuche_hzb_druckoption and !isset($postfeld['hzbdruck'.$auss_iz])) {
					$az1=p4n_sb_strreplace('<<sondera>>', '', $az1);
				}
				
				$az1=p4n_sb_strreplace('<<sondera>>', $postfeld['vertrag'.$ve_zus.'_sonderz'.$auss_iz], $az1);
				if (!isset($postfeld['fin_ust_gk'])) {
					$soa_p2='';
				}
				
				if ($cfg_kfzsuche_hzb_druckoption and !isset($postfeld['hzbdruckp'.$auss_iz])) {
					$az1=p4n_sb_strreplace('<<sonderpx_netto>>', '', $az1);
					$az1=p4n_sb_strreplace('<<sonderpx>>', '', $az1);
				}
				
				$az1=p4n_sb_strreplace('<<sonderpx_netto>>', $soa_p2, $az1);
				$az1=p4n_sb_strreplace('<<sonderpx>>', $soa_p, $az1);
				if ($cfg_kfzsuche_hzb_druckoption and !isset($postfeld['hzbdruck'.$auss_iz]) and !isset($postfeld['hzbdruckp'.$auss_iz])) {
					
				} else {
					$ausst_zeilea.=$az1;
				}
				
				$az1=$hzb_zeilen;
				if ($cfg_kfzsuche_hzb_druckoption and !isset($postfeld['hzbdruck'.$auss_iz])) {
					$az1=p4n_sb_strreplace('<<sondera2>>', '', $az1);
				}
				$az1=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag'.$ve_zus.'_sonderz'.$auss_iz], $az1);
				if ($cfg_kfzsuche_hzb_druckoption and !isset($postfeld['hzbdruckp'.$auss_iz])) {
					$az1=p4n_sb_strreplace('<<sonderpx2_netto>>', '', $az1);
					$az1=p4n_sb_strreplace('<<sonderpx2>>', '', $az1);
				}
				if (!isset($postfeld['fin_ust_gk'])) {
					$az1=p4n_sb_strreplace('<<sonderpx2_netto>>', '', $az1);
				} else {
					$az1=p4n_sb_strreplace('<<sonderpx2_netto>>', $soa_p2, $az1);
				}
				$az1=p4n_sb_strreplace('<<sonderpx2>>', $soa_p, $az1);
				if ($cfg_kfzsuche_hzb_druckoption and !isset($postfeld['hzbdruck'.$auss_iz]) and !isset($postfeld['hzbdruckp'.$auss_iz])) {
					
				} else {
					$hzb_zeilean.=$az1;
				}
				$keinpreis1=false;
				if ($cfg_kfzsuche_hzb_druckoption and !isset($postfeld['hzbdruckp'.$auss_iz])) {
					$keinpreis1=true;
				}
				$keintext1=false;
				if ($cfg_kfzsuche_hzb_druckoption and !isset($postfeld['hzbdruck'.$auss_iz])) {
					$keintext1=true;
				}
				
				$aus_kurz_daten_hz[0].=$postfeld['vertrag'.$ve_zus.'_sonderz'.$auss_iz].' / ';
				$aus_kurz_daten_hz[1]+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderzpreis'.$auss_iz])), 2, ".", ""));
				$aus_kurz_daten_hz2[]=array($postfeld['vertrag'.$ve_zus.'_sonderz'.$auss_iz], str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderzpreis'.$auss_iz]), $keintext1, $keinpreis1);
			}
		}

		$m_listenp_zub=$preis_ges1-$m_listenp_hersteller+doubleval(str_replace(',', '.', $postfeld['listenpreis']));

		// Nachlass:
		$merke_nachl_proz_sum=0;
		$preis_gesl=$preis_ges1;
		for ($auss_i=1; $auss_i<=50; $auss_i++) {
			$auss_iz=$auss_i;
			$preis_ges1-=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrpreis'.$auss_iz])), 2, ".", ""));
			if (isset($postfeld['preisa_d'.$auss_iz]) and (doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrpreis'.$auss_iz]))!=0 or $cfg_kfzsuche_preisangl_null)) {
			if ($postfeld['vertrag'.$ve_zus.'_sonderr'.$auss_iz]!='') {
				$soa_p=str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrpreis'.$auss_iz]);
				$msp1=$soa_p;
				$soa_p2=str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrpreis'.$auss_iz]);
				if (trim($postfeld['vertrag'.$ve_zus.'_sonderr'.$auss_iz])!='') {
					if (doubleval($soa_p)<0) {
						$soa_p=abs($soa_p);
					} else {
						$soa_p=-doubleval($soa_p);
					}
					if (doubleval($soa_p2)<0) {
						$soa_p2=abs($soa_p2);
					} else {
						$soa_p2=-doubleval($soa_p2);
					}
					$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
					$soa_p2=number_format(doubleval(number_format(doubleval($soa_p2), 2, ".", ""))/(1+$cfg_mwstn+$nova_zus_mwst), 2, ",", ".");
				}
				$az1=$ausst_zeile;
				$az1=p4n_sb_strreplace('<<sondera>>', $postfeld['vertrag'.$ve_zus.'_sonderr'.$auss_iz], $az1);
				if (!isset($postfeld['fin_ust_gk'])) {
					$soa_p2='';
				} elseif ($cfg_kfzsuche_preisa_proz) {
					$soa_p=number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrppreis'.$auss_iz])), 2, ",", "").' - '.$soa_p;
					$soa_p2=number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrppreis'.$auss_iz])), 2, ",", "").' - '.$soa_p2;
				}
				$az1=p4n_sb_strreplace('<<sonderpx_netto>>', '', $az1);
				$az1=p4n_sb_strreplace('<<sonderpx>>', '', $az1);
				$az1=p4n_sb_strreplace('<<pag_nx>>', $soa_p2, $az1);
				$az1=p4n_sb_strreplace('<<pag_bx>>', $soa_p, $az1);
				$ausst_zeilea.=$az1;

				$aus_kurz_daten_nl[0].=$postfeld['vertrag'.$ve_zus.'_sonderr'.$auss_iz].' / ';
				$aus_kurz_daten_nl[1]-=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrpreis'.$auss_iz])), 2, ".", ""));
				$nl_p1=doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrppreis'.$auss_iz]));
				if ($nl_p1==0) {
					if ($werkpreis>0) {
						$nl_p1=100*$msp1/$werkpreis;
					}
				}
//				$merke_nachl_proz_sum+=$nl_p1;
				$aus_kurz_daten_nl2[]=array($postfeld['vertrag'.$ve_zus.'_sonderr'.$auss_iz], str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrpreis'.$auss_iz]), $nl_p1);
			}
			}
		}
		
		$serie_komma=p4n_mb_string('substr', $serie_komma, 0, -2);
		$inhalt=p4n_sb_strreplace('<<serie_komma>>', $serie_komma, $inhalt);
		
		// Nachl�sse:
		$gesamt_nlt='';
		$zeile_nachlass='';
		if (preg_match('/<<b_pag1>>(.*)<<b_pag2>>/Uis', $inhalt, $ma)) {
			$zeile_nachlass=$ma[1];
			$zeile_nachlass_alles=$ma[0];
		}
		
		// Profc
		$pc_su1=0;
		$pc_su2=0;
		$alle_pcz='';
		
		$tempzpc=$ausst_zeilepc;
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sondera2>>', '', $tempzpc);
		if ($cfg_kfzsuche_holland) {
			$tempzpc=p4n_sb_strreplace('<<netpx2>>', 'Verkoopprijs', $tempzpc);
		} else {
			$tempzpc=p4n_sb_strreplace('<<netpx2>>', 'VK', $tempzpc);
		}
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', '', $tempzpc);
		if ($cfg_kfzsuche_holland) {
			$tempzpc=p4n_sb_strreplace('<<purpx2>>', 'Inkoopprijs', $tempzpc);
		} else {
			$tempzpc=p4n_sb_strreplace('<<purpx2>>', 'EK', $tempzpc);
		}
		$alle_pcz.=$tempzpc;
		
		$tempzpc=$ausst_zeilepc;
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sondera2>>', profitc_bez($mctya), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['net_listenpreis5'])), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis5'])), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['profit_listenpreis5'])), 2, ",", "."), $tempzpc);
		if ($cfg_mboe_vorlagen) {
			$pc_su1+=doubleval($listep_mitbm);
		} else {
			$pc_su1+=doubleval(str_replace(',', '.', $postfeld['net_listenpreis5']));
		}
		$pc_su2+=doubleval(str_replace(',', '.', $postfeld['profit_listenpreis5']));
		$alle_pcz.=$tempzpc;
		$tempzpc=$ausst_zeilepc;
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sondera2>>', profitc_bez($postfeld['vertrag5_farbe']), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['net_farbe5'])), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_farbepreis'])), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['profit_farbe5'])), 2, ",", "."), $tempzpc);
		$pc_su1+=doubleval(str_replace(',', '.', $postfeld['net_farbe5']));
		$pc_su2+=doubleval(str_replace(',', '.', $postfeld['profit_farbe5']));
		$alle_pcz.=$tempzpc;
		$tempzpc=$ausst_zeilepc;
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sondera2>>', profitc_bez($postfeld['vertrag5_trim']), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['net_trim5'])), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_trimpreis'])), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['profit_trim5'])), 2, ",", "."), $tempzpc);
		$pc_su1+=doubleval(str_replace(',', '.', $postfeld['net_trim5']));
		$pc_su2+=doubleval(str_replace(',', '.', $postfeld['profit_trim5']));
		$alle_pcz.=$tempzpc;
//<<profc12>><<art2>><<sondera2>>	<<netpx2>><<sonderpx2>><<purpx2>><<profc22>>
		$pctsa1='';
		for ($auss_i=1; $auss_i<=500; $auss_i++) {
					$auss_iz=$auss_i;
					if (isset($postfeld['vertrag5_sonder'.$auss_iz]) and $postfeld['vertrag5_sonder'.$auss_iz]!='') {
		$tempzpc=$ausst_zeilepc;
		if ($pctsa1=='') {
			if ($cfg_kfzsuche_holland) {
				$pctsa1='SA';
				$tempzpc=p4n_sb_strreplace('<<art2>>', 'SA', $tempzpc);
			} else {
				$pctsa1=_AUSSTATTUNG_;
				$tempzpc=p4n_sb_strreplace('<<art2>>', _AUSST_, $tempzpc);
			}
		}
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sondera2>>', profitc_bez($postfeld['vertrag5_sonder'.$auss_iz]), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['net_aus5'.$auss_iz])), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderpreis'.$auss_iz])), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['profit_aus5'.$auss_iz])), 2, ",", "."), $tempzpc);
		$alle_pcz.=$tempzpc;
		$pc_su1+=doubleval(str_replace(',', '.', $postfeld['net_aus5'.$auss_iz]));
		$pc_su2+=doubleval(str_replace(',', '.', $postfeld['profit_aus5'.$auss_iz]));
					}
		}
		$tempzpc=$ausst_zeilepc;
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		if ($cfg_kfzsuche_holland) {
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', '*** Totaal voertuig en SAs', $tempzpc);
		} else {
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', '*** '._FAHRZEUG_.' '._UND_.' '._AUSSTATTUNG_, $tempzpc);
		}
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format($pc_su1, 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format($pc_su2, 2, ",", "."), $tempzpc);
		$alle_pcz.=$tempzpc;
		
		if ($_SESSION['cfg_kunde']=='carlo_opel_nl_gomes') {
		$tempzpc=$ausst_zeilepc;
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sondera2>>', 'BPM / Rest BPM', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['bpm'])), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['rest_bpm'])), 2, ",", "."), $tempzpc);
		$alle_pcz.=$tempzpc;
		}
		
		$inhalt=p4n_sb_strreplace('<<gesamtpreis_netto>>', number_format($pc_su1, 2, ",", "."), $inhalt);
		
		$pc_hzb1=0;
		$pc_hzb2=0;
		$pctsa1='';
		for ($auss_i=1; $auss_i<=100; $auss_i++) {
					$auss_iz=$auss_i;
					if (isset($postfeld['vertrag5_sonderz'.$auss_iz]) and $postfeld['vertrag5_sonderz'.$auss_iz]!='') {
		$tempzpc=$ausst_zeilepc;
		if ($pctsa1=='') {
			$pctsa1='SA';
			if ($cfg_kfzsuche_holland) {
				$tempzpc=p4n_sb_strreplace('<<art2>>', 'Int.', $tempzpc);
			} else {
				$tempzpc=p4n_sb_strreplace('<<art2>>', 'Zub.', $tempzpc);
			}
		}
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sondera2>>', profitc_bez($postfeld['vertrag5_sonderz'.$auss_iz]), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['net_zaus5'.$auss_iz])), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderzpreis'.$auss_iz])), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['profit_zaus5'.$auss_iz])), 2, ",", "."), $tempzpc);
		$alle_pcz.=$tempzpc;
		$pc_hzb1+=doubleval(str_replace(',', '.', $postfeld['net_zaus5'.$auss_iz]));
		$pc_hzb2+=doubleval(str_replace(',', '.', $postfeld['profit_zaus5'.$auss_iz]));
					}
		}
		$tempzpc=$ausst_zeilepc;
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		if ($cfg_kfzsuche_holland) {
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', '*** Totaal intern werk', $tempzpc);
		} else {
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', '*** '._ZUBEHOER_, $tempzpc);
		}
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format($pc_hzb1, 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format($pc_hzb2, 2, ",", "."), $tempzpc);
		$alle_pcz.=$tempzpc;
		
		if ($_SESSION['cfg_kunde']=='carlo_opel_nl_gomes') {
		$tempzpc=$ausst_zeilepc;
		$tempzpc=p4n_sb_strreplace('<<art2>>', 'Subtot.', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sondera2>>', 'auto en accessoires', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format($pc_su1+$pc_hzb1, 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format($pc_su2+$pc_hzb2, 2, ",", "."), $tempzpc);
		$alle_pcz.=$tempzpc;
		
		$tempzpc=$ausst_zeilepc;
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sondera2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', '', $tempzpc);
		$alle_pcz.=$tempzpc;
		}
		
		$alle_pcz3='';
		
		$pc_ops1=0;
		$pc_ops2=0;
		$pctsa1='';
		for ($auss_i=1; $auss_i<=30; $auss_i++) {
					$auss_iz=$auss_i;
					if (isset($postfeld['vertrag5_zusbonus'.$auss_iz]) and $postfeld['vertrag5_zusbonus'.$auss_iz]!='') {
		$tempzpc=$ausst_zeilepc;
		$tempzpc3=$ausst_zeilepc3;
		if ($pctsa1=='') {
			$pctsa1='SA';
			if ($cfg_kfzsuche_holland) {
				$tempzpc=p4n_sb_strreplace('<<art2>>', 'Opslag', $tempzpc);
				$tempzpc3=p4n_sb_strreplace('<<art2>>', 'Opslag', $tempzpc3);
			} else {
				$tempzpc=p4n_sb_strreplace('<<art2>>', 'Bonus', $tempzpc);
				$tempzpc3=p4n_sb_strreplace('<<art2>>', 'Bonus', $tempzpc3);
			}
		}
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag5_zusbonus'.$auss_iz], $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', '0')), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_zusbonusp'.$auss_iz])), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format(-1*doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_zusbonus'.$auss_iz])), 2, ",", "."), $tempzpc);
		$alle_pcz.=$tempzpc;
		
		$tempzpc3=p4n_sb_strreplace('<<art2>>', '', $tempzpc3);
		$tempzpc3=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag5_zusbonus'.$auss_iz], $tempzpc3);
		$tempzpc3=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', '0')), 2, ",", "."), $tempzpc3);
		$tempzpc3=p4n_sb_strreplace('<<sonderpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_zusbonusp'.$auss_iz])), 2, ",", "."), $tempzpc3);
		$tempzpc3=p4n_sb_strreplace('<<purpx2>>', number_format(-1*doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_zusbonus'.$auss_iz])), 2, ",", "."), $tempzpc3);
		$alle_pcz3.=$tempzpc3;
		
		$pc_ops1-=doubleval(str_replace(',', '.', '0'));
		$pc_ops2-=doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_zusbonus'.$auss_iz]));
					}
		}
		$tempzpc=$ausst_zeilepc;
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		if ($cfg_kfzsuche_holland) {
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', '*** Totaal opslagen', $tempzpc);
		} else {
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', '*** Bonus', $tempzpc);
		}
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format($pc_ops1, 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format($pc_ops2, 2, ",", "."), $tempzpc);
		$alle_pcz.=$tempzpc;
		
		$tempzpc3=$ausst_zeilepc3;
		$tempzpc3=p4n_sb_strreplace('<<art2>>', '', $tempzpc3);
		if ($cfg_kfzsuche_holland) {
			$tempzpc3=p4n_sb_strreplace('<<sondera2>>', '*** Totaal opslagen', $tempzpc3);
		} else {
			$tempzpc3=p4n_sb_strreplace('<<sondera2>>', '*** Bonus', $tempzpc3);
		}
		$tempzpc3=p4n_sb_strreplace('<<netpx2>>', number_format($pc_ops1, 2, ",", "."), $tempzpc3);
		$tempzpc3=p4n_sb_strreplace('<<sonderpx2>>', '', $tempzpc3);
		$tempzpc3=p4n_sb_strreplace('<<purpx2>>', number_format($pc_ops2, 2, ",", "."), $tempzpc3);
		$alle_pcz3.=$tempzpc3;
		
		if ($_SESSION['cfg_kunde']=='carlo_opel_nl_gomes') {
		$tempzpc=$ausst_zeilepc;
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sondera2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', '', $tempzpc);
		$alle_pcz.=$tempzpc;
		}
		
		/*
		$pc_ops1=0;
		$pc_ops2=0;
		$pctsa1='';
		for ($auss_i=1; $auss_i<=30; $auss_i++) {
					$auss_iz=$auss_i;
					if (isset($postfeld['vertrag5_sonderr'.$auss_iz]) and $postfeld['vertrag5_sonderr'.$auss_iz]!='') {
		$tempzpc=$ausst_zeilepc;
		if ($pctsa1=='') {
			$pctsa1='SA';
			$tempzpc=p4n_sb_strreplace('<<art2>>', 'Opslag', $tempzpc);
		}
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag5_sonderr'.$auss_iz], $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_sonderrpreis'.$auss_iz])), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrpreis'.$auss_iz])), 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['profit_vertrag5_sonderrpreis'.$auss_iz])), 2, ",", "."), $tempzpc);
		$alle_pcz.=$tempzpc;
		$pc_ops1+=doubleval(str_replace(',', '.', $postfeld['net_zaus5'.$auss_iz]));
		$pc_ops2+=doubleval(str_replace(',', '.', $postfeld['profit_vertrag5_sonderrpreis'.$auss_iz]));
					}
		}
		$tempzpc=$ausst_zeilepc;
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sondera2>>', '*** Totaal opslagen', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format($pc_ops1, 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format($pc_ops2, 2, ",", "."), $tempzpc);
		$alle_pcz.=$tempzpc;
		*/
		
		$pc_ove1=0;
		$pc_ove2=0;
		$pctsa1='';
		
		for ($auss_i=1; $auss_i<=30; $auss_i++) {
					$auss_iz=$auss_i;
					if (isset($postfeld['vertrag5_sonderr'.$auss_iz]) and $postfeld['vertrag5_sonderr'.$auss_iz]!='' and doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_sonderrpreis'.$auss_iz]))!=0) {
		$tempzpc=$ausst_zeilepc;
		if ($pctsa1=='') {
			$pctsa1='SA';
			if ($cfg_kfzsuche_holland) {
				$tempzpc=p4n_sb_strreplace('<<art2>>', 'Overig', $tempzpc);
			} else {
				$tempzpc=p4n_sb_strreplace('<<art2>>', _ANDERE_, $tempzpc);
			}
		}
		if ($_SESSION['cfg_kunde']=='carlo_opel_nl_gomes') {
			$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag5_sonderr'.$auss_iz], $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<netpx2>>', '-'.number_format(doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_sonderrpreis'.$auss_iz])), 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrpreis'.$auss_iz])), 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<purpx2>>', '0,00'/*number_format(doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_sonderrpreis'.$auss_iz])), 2, ",", ".")*/, $tempzpc);
			$alle_pcz.=$tempzpc;
			$pc_ove1-=doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_sonderrpreis'.$auss_iz]));
		//	$pc_ove2-=doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_sonderrpreis'.$auss_iz]));
		} else {
			$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag5_sonderr'.$auss_iz], $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_sonderrpreis'.$auss_iz])), 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrpreis'.$auss_iz])), 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_sonderrpreis'.$auss_iz])), 2, ",", "."), $tempzpc);
			$alle_pcz.=$tempzpc;
			$pc_ove1+=doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_sonderrpreis'.$auss_iz]));
			$pc_ove2+=doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_sonderrpreis'.$auss_iz]));
		}
					}
		}
		
		if (doubleval(str_replace(',', '.', $postfeld['vertrag5_transport']))!=0 or doubleval(str_replace(',', '.', $postfeld['profit_vertrag5_trans']))!=0 or doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_trans']))!=0) {
			$tempzpc=$ausst_zeilepc;
			if ($pctsa1=='') {
				$pctsa1='SA';
				if ($cfg_kfzsuche_holland) {
					$tempzpc=p4n_sb_strreplace('<<art2>>', 'Overig', $tempzpc);
				} else {
					$tempzpc=p4n_sb_strreplace('<<art2>>', _ANDERE_, $tempzpc);
				}
			}
			$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
			if ($cfg_kfzsuche_holland) {
				$tempzpc=p4n_sb_strreplace('<<sondera2>>', 'Kosten rijklaar maken', $tempzpc);
			} else {
				$tempzpc=p4n_sb_strreplace('<<sondera2>>', _TRANSPORTKOSTEN_, $tempzpc);
			}
			$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_trans'])), 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_zuscostp'])), 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['profit_vertrag5_trans'])), 2, ",", "."), $tempzpc);
			$alle_pcz.=$tempzpc;
			$pc_ove1+=doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_trans']));
			$pc_ove2+=doubleval(str_replace(',', '.', $postfeld['profit_vertrag5_trans']));
		}
	if ($_SESSION['cfg_kunde']=='carlo_opel_nl_gomes') {
		if (doubleval(str_replace(',', '.', $postfeld['vertrag5_leges1']))!=0 or doubleval(str_replace(',', '.', $postfeld['profit_vertrag5_leges1']))!=0) {
			$tempzpc=$ausst_zeilepc;
			if ($pctsa1=='') {
				$pctsa1='SA';
				if ($cfg_kfzsuche_holland) {
					$tempzpc=p4n_sb_strreplace('<<art2>>', 'Overig', $tempzpc);
				} else {
					$tempzpc=p4n_sb_strreplace('<<art2>>', _ANDERE_, $tempzpc);
				}
			}
			$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', 'Leges 1', $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_leges1'])), 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(0, 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['profit_vertrag5_leges1'])), 2, ",", "."), $tempzpc);
			$alle_pcz.=$tempzpc;
			$pc_ove1+=doubleval(str_replace(',', '.', $postfeld['vertrag5_leges1']));
			$pc_ove2+=doubleval(str_replace(',', '.', $postfeld['profit_vertrag5_leges1']));
		}
		if (doubleval(str_replace(',', '.', $postfeld['vertrag5_leges2']))!=0 or doubleval(str_replace(',', '.', $postfeld['profit_vertrag5_leges2']))!=0) {
			$tempzpc=$ausst_zeilepc;
			if ($pctsa1=='') {
				$pctsa1='SA';
				$tempzpc=p4n_sb_strreplace('<<art2>>', 'Overig', $tempzpc);
			}
			$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', 'Leges 2', $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_leges2'])), 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(0, 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['profit_vertrag5_leges2'])), 2, ",", "."), $tempzpc);
			$alle_pcz.=$tempzpc;
			$pc_ove1+=doubleval(str_replace(',', '.', $postfeld['vertrag5_leges2']));
			$pc_ove2+=doubleval(str_replace(',', '.', $postfeld['profit_vertrag5_leges2']));
		}
		if (doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_envtax']))!=0 or doubleval(str_replace(',', '.', $postfeld['profit_vertrag5_envtax']))!=0) {
			$tempzpc=$ausst_zeilepc;
			if ($pctsa1=='') {
				$pctsa1='SA';
				$tempzpc=p4n_sb_strreplace('<<art2>>', 'Overig', $tempzpc);
			}
			$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', 'Verwijderingsbijdrage', $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_envtax'])), 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(0, 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['profit_vertrag5_envtax'])), 2, ",", "."), $tempzpc);
			$alle_pcz.=$tempzpc;
			$pc_ove1+=doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_envtax']));
			$pc_ove2+=doubleval(str_replace(',', '.', $postfeld['profit_vertrag5_envtax']));
		}
	}
		for ($auss_i=1; $auss_i<=30; $auss_i++) {
					$auss_iz=$auss_i;
					if (isset($postfeld['vertrag5_zuscost'.$auss_iz]) and $postfeld['vertrag5_zuscost'.$auss_iz]!='') {
		$tempzpc=$ausst_zeilepc;
		if ($pctsa1=='') {
			$pctsa1='SA';
			if ($cfg_kfzsuche_holland) {
				$tempzpc=p4n_sb_strreplace('<<art2>>', 'Overig', $tempzpc);
			} else {
				$tempzpc=p4n_sb_strreplace('<<art2>>', _ANDERE_, $tempzpc);
			}
		}
		if ($_SESSION['cfg_kunde']=='carlo_opel_nl_gomes') {
			$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag5_zuscost'.$auss_iz], $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<netpx2>>', '-'.number_format(doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_zuscost'.$auss_iz])), 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_zuscostp'.$auss_iz])), 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<purpx2>>', '0,00'/*'-'.number_format(doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_zuscost'.$auss_iz])), 2, ",", ".")*/, $tempzpc);
			$alle_pcz.=$tempzpc;
			$pc_ove1-=doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_zuscost'.$auss_iz]));
			//$pc_ove2-=doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_zuscost'.$auss_iz]));
		} else {
			$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', $postfeld['vertrag5_zuscost'.$auss_iz], $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_zuscost'.$auss_iz])), 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_zuscostp'.$auss_iz])), 2, ",", "."), $tempzpc);
			$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format(doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_zuscost'.$auss_iz])), 2, ",", "."), $tempzpc);
			$alle_pcz.=$tempzpc;
			$pc_ove1+=doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_zuscost'.$auss_iz]));
			$pc_ove2+=doubleval(str_replace(',', '.', $postfeld['netto_vertrag5_zuscost'.$auss_iz]));
		}
					}
		}
		$tempzpc=$ausst_zeilepc;
		$tempzpc=p4n_sb_strreplace('<<art2>>', '', $tempzpc);
		if ($cfg_kfzsuche_holland) {
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', '*** Totaal overig', $tempzpc);
		} else {
			$tempzpc=p4n_sb_strreplace('<<sondera2>>', '*** '._ANDERE_, $tempzpc);
		}
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format($pc_ove1, 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format($pc_ove2, 2, ",", "."), $tempzpc);
		$alle_pcz.=$tempzpc;
		
		if ($_SESSION['cfg_kunde']=='carlo_opel_nl_gomes') {
		$tempzpc=$ausst_zeilepc;
		$tempzpc=p4n_sb_strreplace('<<art2>>', 'Subtot.', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sondera2>>', 'auto, accessoires, bonussen en kortingen', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<netpx2>>', number_format($pc_su1+$pc_hzb1+$pc_ove1, 2, ",", "."), $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<sonderpx2>>', '', $tempzpc);
		$tempzpc=p4n_sb_strreplace('<<purpx2>>', number_format($pc_su2+$pc_hzb2+$pc_ops2+$pc_ove2, 2, ",", "."), $tempzpc);
		$alle_pcz.=$tempzpc;
		}
		
		$inhalt=p4n_sb_strreplace($ausst_zeilegpc, $alle_pcz, $inhalt);
		$inhalt=p4n_sb_strreplace(array('<<profc12>>', '<<profc22>>'), '', $inhalt);
		
		$inhalt=p4n_sb_strreplace($ausst_zeilegpc3, $alle_pcz3, $inhalt);
		$inhalt=p4n_sb_strreplace(array('<<profc31>>', '<<profc32>>'), '', $inhalt);
		
		if (isset($postfeld['vertrags_ankauf'])) {
			$inz_prof_c1=doubleval(str_replace(',', '.', $postfeld['inr1_taxp']));
			$inz_prof_c2=doubleval(str_replace(',', '.', $postfeld['inr1_p']));
			$inz_prof_c1+=doubleval(str_replace(',', '.', $postfeld['inr2_taxp']));
			$inz_prof_c2+=doubleval(str_replace(',', '.', $postfeld['inr2_p']));
		}
		$inhalt=p4n_sb_strreplace('<<inr_van>>', $postfeld['inrl_van'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<inr_van2>>', $postfeld['inrl_van2'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<profit_ti_vk>>', number_format($inz_prof_c2, 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<profit_ti_ek>>', number_format($inz_prof_c1, 2, ",", "."), $inhalt);
		
		$prof_marg=doubleval(str_replace(',', '.', $postfeld['profitcalc_marge']));
		$prof_netto=doubleval(str_replace(',', '.', $postfeld['vertrag5_hauspreis_netto']));
		
		$inr_diff=$inz_prof_c2-$inz_prof_c1;
		
		if ($_SESSION['cfg_kunde']=='carlo_opel_nl_gomes') {
			$m_1=$prof_marg;
			$m_2=$prof_netto;
			$prof_netto=$pc_su1+$pc_hzb1+$pc_ove1-$inz_prof_c2;
			$prof_inkoop=$pc_su2+$pc_hzb2+$pc_ops2+$pc_ove2-$inz_prof_c2;
			$marge_inr=$inz_prof_c2-$inz_prof_c1;
			$marge_inr_vat=0;
			if ($postfeld['inr_art']=='2') {
				$marge_inr=$inz_prof_c2-$inz_prof_c1;
				$marge_inr_vat=$marge_inr/(1+$cfg_mwst);
				$inr_diff=$marge_inr_vat;
				$prof_netto-=$marge_inr_vat;
				$prof_marg=$prof_netto-$prof_inkoop;//($pc_su2+$pc_hzb2+$pc_ops2+$pc_ove2-($inz_prof_c1/(1+$cfg_mwst)));
			} else {
				$prof_marg=$prof_netto-($pc_su2+$pc_hzb2+$pc_ops2+$pc_ove2-$inz_prof_c1);
			}
		}
		$inhalt=p4n_sb_strreplace('<<profit_ti_diff>>', number_format($inr_diff, 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<profit_ek>>', number_format($prof_netto-$prof_marg, 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<profit_vk>>', number_format($prof_netto, 2, ",", "."), $inhalt);
		
		//Summe Preisangl. drucken?
		$m_pag_brutto1=0;
		$m_pag_netto1=0;
		$nlt1x='';
		$m_pagbsum=0;
		$m_sum_pag=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['summe_preisa'])), 2, '.', ''));
		if (isset($postfeld['summe_preisa_d']) and doubleval(str_replace(',', '.', $postfeld['summe_preisa']))!=0) {
				$soa_p=str_replace(',', '.', $postfeld['summe_preisa']);
				$soa_p2=$soa_p;
				$az1=$ausst_zeile;
				$az1=p4n_sb_strreplace('<<sondera>>', _SUMME_.' '._PREISANGLEICHUNGEN_, $az1);
				if (doubleval($soa_p)<0) {
					$soa_p=abs($soa_p);
				} else {
					$soa_p=-doubleval($soa_p);
				}
				if (doubleval($soa_p2)<0) {
					$soa_p2=abs($soa_p2);
				} else {
					$soa_p2=-doubleval($soa_p2);
				}
				$m_pagbsum=$soa_p;
				$soa_p_fw=doubleval($soa_p)*$kurs1;
				$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
				$kpagn_soa_p2_fw=(doubleval($soa_p2)/(1+$cfg_mwstn+$nova_zus_mwst))*$kurs1;
				$soa_p2=number_format(doubleval($soa_p2)/(1+$cfg_mwstn+$nova_zus_mwst), 2, ",", ".");
				$soa_p3=number_format(doubleval($soa_p2)/(1+$cfg_mwstn), 2, ",", ".");
				$m_pag_brutto1=$soa_p;
				$m_pag_netto1=$soa_p2;
				if (!isset($postfeld['fin_ust_gk'])) {
					$soa_p2='';
				}
				$az1=p4n_sb_strreplace('<<sonderpx_netto>>', '', $az1);
				$az1=p4n_sb_strreplace('<<sonderpx>>', '', $az1);
				$az1=p4n_sb_strreplace('<<pag_nx>>', $soa_p2, $az1);
				$az1=p4n_sb_strreplace('<<pag_bx>>', $soa_p, $az1);
//				$ausst_zeilea.=$az1;
				$inhalt=p4n_sb_strreplace('<<pag_b_sum>>', $soa_p, $inhalt);
				$inhalt=p4n_sb_strreplace('<<kpag_b_sum>>', number_format(doubleval($soa_p_fw), 2, ",", "."), $inhalt);
				$inhalt=p4n_sb_strreplace('<<pag_n_sum>>', $soa_p2, $inhalt);
				$m_vkpreis1-=doubleval(number_format(doubleval(str_replace(',', '.', str_replace('.', '', $soa_p2))), 2, ".", ""));
				$m_vkpreis2-=doubleval(number_format(doubleval(str_replace(',', '.', str_replace('.', '', $soa_p2))), 2, ".", ""));

				$nlt1x=$zeile_nachlass;
				$nlt1x=p4n_sb_strreplace('<<pag_text>>', _SUMME_.' '._PREISANGLEICHUNGEN2_, $nlt1x);
				$nlt1x=p4n_sb_strreplace('<<pag_b1>>', $soa_p, $nlt1x);
				$nlt1x=p4n_sb_strreplace('<<pag_n1>>', $soa_p2, $nlt1x);
//				$gesamt_nlt.=$nlt1;
		}
		if ($anz_nl>0 or (isset($postfeld['summe_preisa_d']) and doubleval(str_replace(',', '.', $postfeld['summe_preisa']))!=0)) {
			$inhalt=p4n_sb_strreplace('<<pag_b>>', _PREISANGLEICHUNGEN2_.' '._BRUTTO_, $inhalt);
			if (isset($postfeld['fin_ust_gk'])) {
				$inhalt=p4n_sb_strreplace('<<pag_n>>', _PREISANGLEICHUNGEN2_.' '._NETTO_, $inhalt);
			}
		}
		
		$inhalt=p4n_sb_strreplace('<<ausstattungen_sum>>', number_format($su_ausst2/(1+$cfg_mwstn), 2, ",", "."), $inhalt);
	//	$tempdv_we1=doubleval(str_replace(',', '.', $postfeld['listenpreis']));
		$sum_lp1=doubleval(
			number_format(
				doubleval( number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ".","")	)/(1+$cfg_mwstn) , 2, ".",""
			)
		);
		$sum_lp1+=$su_ausst2/(1+$cfg_mwstn);
		$sum_lp1-=doubleval(number_format(doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['summe_preisa'])), 2, ".",""))/(1+$cfg_mwstn), 2, ".",""));
		$inhalt=p4n_sb_strreplace('<<total_ohnesteuer_sum>>', number_format($sum_lp1, 2, ",", "."), $inhalt);
		$fremdwaehrung1=doubleval(number_format($kurs1*$sum_lp1, 2, ".", ""));
		$eigenwaehrung1=doubleval($sum_lp1);
		$trosa1=doubleval(number_format($kurs3*doubleval(str_replace(',', '.', $postfeld['trosa'])), 2, ".", ""));
		$etrosa1=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['trosa'])), 2, ".", ""));
		$inhalt=p4n_sb_strreplace('<<trosarina>>', number_format($trosa1, 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<etrosarina>>', number_format($etrosa1, 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<kurs_trosarina>>', number_format($kurs3, 2, ",", "."), $inhalt);
		if ($cfg_ws_avag_kroatien) {
			$inhalt=p4n_sb_strreplace('<<co2>>', number_format(doubleval($postfeld['trosa_co2p']), 2, ",", "."), $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<kunar>>', number_format($fremdwaehrung1, 2, ",", "."), $inhalt);
		$fremdwaehrung1_steuer=doubleval(number_format($fremdwaehrung1*$cfg_mwstn, 2, ".", ""));
		$eigenwaehrung1_steuer=doubleval(number_format($eigenwaehrung1*$cfg_mwstn, 2, ".", ""));
		$inhalt=p4n_sb_strreplace('<<kunar_pdv>>', number_format($fremdwaehrung1_steuer, 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<euro_pdv>>', number_format($eigenwaehrung1_steuer, 2, ",", "."), $inhalt);
		$gesamtb_k=$fremdwaehrung1+$fremdwaehrung1_steuer;
		$gesamtb_k2=$eigenwaehrung1+$eigenwaehrung1_steuer;
		$inhalt=p4n_sb_strreplace('<<kunar_sum>>', number_format($gesamtb_k, 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<euro_sum>>', number_format($gesamtb_k2, 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<kunar_sumt>>', number_format($gesamtb_k+$trosa1, 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<ekunar_sumt>>', number_format($gesamtb_k2+$etrosa1, 2, ",", "."), $inhalt);
		$darlehb1=doubleval(str_replace(',', '.', $postfeld['bank_darlehen']));
		$inhalt=p4n_sb_strreplace('<<banka_kredit>>', number_format($darlehb1, 2, ",", "."), $inhalt);
		$anzahlungb1=doubleval(str_replace(',', '.', $postfeld['fin_anzahlung2']));
		$gwpreisb1=doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis']));
		$inhalt=p4n_sb_strreplace('<<kunar_sum2>>', number_format($gesamtb_k-$anzahlungb1-$gwpreisb1-$darlehb1, 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<kunar_sum2t>>', number_format($gesamtb_k+$trosa1-$anzahlungb1-$gwpreisb1-$darlehb1, 2, ",", "."), $inhalt);

		$inhalt=p4n_sb_strreplace('<<nacin_carinjenja>>', $postfeld['kroatien_behindertensteuersatz'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<nacin_placanja>>', $postfeld['kroatien_speziellezahlung'], $inhalt);
		
		if (isset($postfeld['vertrag5_hauspreis_euro2022'])) {
			$inhalt=p4n_sb_strreplace('<<price_euro2022>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_hauspreis_euro2022'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<price_kuna2023>>', number_format(7.5345*doubleval(str_replace(',', '.', $postfeld['vertrag5_hauspreis_euro2022'])), 2, ",", "."), $inhalt);
		}
		if (isset($postfeld['vertrag5_hauspreis_euro2022_gw'])) {
			$inhalt=p4n_sb_strreplace('<<price_euro2022>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_hauspreis_euro2022_gw'])), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<price_kuna2023>>', number_format(7.5345*doubleval(str_replace(',', '.', $postfeld['vertrag5_hauspreis_euro2022_gw'])), 2, ",", "."), $inhalt);
		}
		
		if ($cfg_kfzsuche_austria) {
			$inhalt=p4n_sb_strreplace('<<co2>>', number_format(doubleval($postfeld['at_co2']), 0, ",", ""), $inhalt);
		}
		
		$inhalt=p4n_sb_strreplace('<<baumuster>>', $postfeld['gme_modellnr2'], $inhalt);
		
		// 						neue Vorlage (4):
		// Summe Werkszubeh�r
		$soa_p=str_replace(',', '.', $su_ausst2);
		$soa_p2=str_replace(',', '.',$su_ausst2);
		$temp_netwert=doubleval($soa_p)/(1+$cfg_mwst);
		$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
		$soa_p_netto=number_format(doubleval($temp_netwert), 2, ",", ".");
		$soa_p2=number_format(doubleval(number_format(doubleval(str_replace(',', '.', $su_ausst2)), 2, ".", ""))/(1+$cfg_mwstn), 2, ",", ".");
		$soa_p3=number_format(doubleval(number_format(doubleval(str_replace(',', '.', $su_ausst2)), 2, ".", ""))/(1+$cfg_mwstn+intval($postfeld['at_novasatz'])/100), 2, ",", ".");
		if (!isset($postfeld['fin_ust_gk'])) {
			$soa_p2='';
			$soa_p3='';
		}
		$inhalt=p4n_sb_strreplace('<<sonder_sum>>', $soa_p, $inhalt);
		if ($preise_netto) {
			$inhalt=p4n_sb_strreplace('<<sonder_sum_nb>>', $soa_p_netto, $inhalt);
		} else {
			$inhalt=p4n_sb_strreplace('<<sonder_sum_nb>>', $soa_p, $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<sonder_sum_netto>>', $soa_p2, $inhalt);
		$inhalt=p4n_sb_strreplace('<<sonder_sum_netto2>>', $soa_p3, $inhalt);
		// Summe Listenpreis+Werkszubeh�r
		$preis_summe_liste=doubleval($su_ausst2)+doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ".",""));
		$soa_p=$preis_summe_liste;
		$soa_p2=$preis_summe_liste;
		$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
		$soa_p2=number_format(doubleval(number_format(doubleval($preis_summe_liste), 2, ".", ""))/(1+$cfg_mwstn), 2, ",", ".");
		if (!isset($postfeld['fin_ust_gk'])) {
			$soa_p2='';
		}
		$inhalt=p4n_sb_strreplace('<<liste_sum>>', $soa_p, $inhalt);
		$inhalt=p4n_sb_strreplace('<<liste_sum_netto>>', $soa_p2, $inhalt);
		// Summe mit Nachl�sse
		$preis_summe_liste_nl=$preis_summe_liste-$m_sum_pag;
		$soa_p=$preis_summe_liste_nl;
		$soa_p2=$preis_summe_liste_nl;
		$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
		$soa_p2=number_format(doubleval(number_format(doubleval($preis_summe_liste_nl), 2, ".", ""))/(1+$cfg_mwstn), 2, ",", ".");
		if (!isset($postfeld['fin_ust_gk'])) {
			$soa_p2='';
		}
		$inhalt=p4n_sb_strreplace('<<liste_nl_sum>>', $soa_p, $inhalt);
		$inhalt=p4n_sb_strreplace('<<liste_nl_sum_netto>>', $soa_p2, $inhalt);
		// Summe H�ndlerzubeh�r
		$soa_p=str_replace(',', '.', $summe_hzb);
		$soa_p2=str_replace(',', '.',$summe_hzb);
		$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
		$soa_p2=number_format(doubleval(number_format(doubleval(str_replace(',', '.', $summe_hzb)), 2, ".", ""))/(1+$cfg_mwst), 2, ",", ".");
		if (!isset($postfeld['fin_ust_gk'])) {
			$soa_p2='';
		}
		$inhalt=p4n_sb_strreplace('<<hzb>>', $soa_p, $inhalt);
		$inhalt=p4n_sb_strreplace('<<hzb_netto>>', $soa_p2, $inhalt);

		// Vorlage eine Seite:
		$sonderp_sum=0;
		$sonderp_sumn=0;
		$auss_i=1;
		$susa1=_SUMME_SONDER_SEITE2_;
		if (!isset($lang['_SUMME_SONDER_SEITE2_'])) {
			$susa1='Summe Sonderausstattungen (siehe Seite 2)';
		}
		if ($variante2) {
			$inhalt=p4n_sb_strreplace('<<sonder'.$auss_i.'>>', $susa1, $inhalt);
			$soa_p=str_replace(',', '.', $su_ausst);
			$m_soapt=doubleval($soa_p);
			$soa_p2=str_replace(',', '.',$su_ausst);
			$soa_p_fw=doubleval($soa_p)*$kurs1;
			$sonderp_sum+=doubleval($soa_p);
			$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
			$soa_p2=number_format(doubleval(number_format(doubleval(str_replace(',', '.', $su_ausst)), 2, ".", ""))/(1+$cfg_mwstn+$nova_zus_mwst), 2, ",", ".");
			if ($andere_susa1>0) {
				$soa_p2=number_format(doubleval($andere_susa1), 2, ",", ".");
			}
			$sonderp_sumn+=doubleval(str_replace(',', '.', str_replace('.', '', $soa_p2)));
			$inhalt=p4n_sb_strreplace('<<sonderp'.$auss_i.'>>', $soa_p, $inhalt);
			$inhalt=p4n_sb_strreplace('<<ksonderp'.$auss_i.'>>', number_format(doubleval($soa_p_fw), 2, ",", "."), $inhalt);
			if (!isset($postfeld['fin_ust_gk'])) {
				$soa_p2='';
			}
			$m_vkpreis2-=doubleval(number_format(doubleval(str_replace(',', '.', str_replace('.', '', $soa_p2))), 2, ".", ""));
			$inhalt=p4n_sb_strreplace('<<sonderp'.$auss_i.'_netto>>', $soa_p2, $inhalt);
			$auss_i++;
			$inhalt=p4n_sb_strreplace('<<summe_abr2>>', $soa_p, $inhalt);
			$inhalt=p4n_sb_strreplace('<<summe_ane2>>', $soa_p2, $inhalt);
			
			$inhalt=p4n_sb_strreplace('<<sum_hzb_abr2>>', number_format(doubleval($summe_hzb+$m_soapt), 2, ",", "."), $inhalt);
		} else {
			if (intval($su_ausst)==0 and intval($su_ausst2)>0) {
				$su_ausst=$su_ausst2;
			}
			$soa_p=str_replace(',', '.', $su_ausst);
			$m_soapt=doubleval($soa_p);
			$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
			$inhalt=p4n_sb_strreplace('<<summe_abr2>>', $soa_p, $inhalt);
			$soa_p2=number_format(doubleval(number_format(doubleval(str_replace(',', '.', $su_ausst)), 2, ".", ""))/(1+$cfg_mwstn+$nova_zus_mwst), 2, ",", ".");
			if ($andere_susa1>0) {
				$soa_p2=number_format(doubleval($andere_susa1), 2, ",", ".");
			}
			if (!isset($postfeld['fin_ust_gk'])) {
				$soa_p2='';
			}
			$inhalt=p4n_sb_strreplace('<<summe_ane2>>', $soa_p2, $inhalt);
			$inhalt=p4n_sb_strreplace('<<sum_hzb_abr2>>', number_format(doubleval($summe_hzb+$m_soapt), 2, ",", "."), $inhalt);
		}
		@reset($aus_kurz_daten);
		while (list($key, $val)=@each($aus_kurz_daten)) {
			if ($auss_i>($maxzeilen-1-$genutzte_zeilen)) {
				$vm_t=$val[0].' / ';
				$vm_p=$val[1];
				$vm_pn=$val[2];
				while (list($key, $val)=@each($aus_kurz_daten)) {
					$vm_t.=$val[0].' / ';
					if (isset($val[2]) and doubleval(str_replace(',', '.', $val[2]))>0) {
//						$val[1]=$val[2];	// rausgenommen wegen adam
					}
					$vm_p+=$val[1];
					$vm_pn+=$val[2];
				}
				$val[0]=p4n_mb_string('substr',$vm_t, 0, -3);
				if ($cfg_greek) {
					if (strlen($val[0])>50) {
						$val[0]=abkuerzung($val[0], 50);
					}
				}
				$val[1]=$vm_p;
				$val[2]=$vm_pn;
			}
			
			$inhalt=p4n_sb_strreplace('<<sonder'.$auss_i.'>>', $val[0], $inhalt);
			$soa_p=str_replace(',', '.', $val[1]);
			$m2_soap=doubleval($soa_p);
			$soa_p_fw=doubleval($soa_p)*$kurs1;
			$soa_p2=str_replace(',', '.', $val[1]);
			$sonderp_sum+=$soa_p;
			if (trim($val[0])!='') {
				$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
				$soa_p2=number_format(doubleval(number_format(doubleval(str_replace(',', '.', $val[1])), 2, ".", ""))/(1+$cfg_mwstn), 2, ",", ".");
			}
			if (isset($val[2]) and doubleval(str_replace(',', '.', $val[2]))>0) {
				$soa_p2=number_format(doubleval(str_replace(',', '.', $val[2])), 2, ",", ".");
			}
			if (isset($postfeld['freiekonf'])) {
				$soa_p2=number_format($m2_soap/(1+$m_cfg_mwst+$nova_zus_mwst), 2, ",", ".");
			}
			$sonderp_sumn+=doubleval(str_replace(',', '.', str_replace('.', '', $soa_p2)));
			$inhalt=p4n_sb_strreplace('<<sonderp'.$auss_i.'>>', $soa_p, $inhalt);
			$inhalt=p4n_sb_strreplace('<<ksonderp'.$auss_i.'>>', number_format(doubleval($soa_p_fw), 2, ",", "."), $inhalt);
			if (!isset($postfeld['fin_ust_gk'])) {
				$soa_p2='';
			}
			$m_vkpreis2-=doubleval(number_format(doubleval(str_replace(',', '.', str_replace('.', '', $soa_p2))), 2, ".", ""));
			$inhalt=p4n_sb_strreplace('<<sonderp'.$auss_i.'_netto>>', $soa_p2, $inhalt);
			$auss_i++;
		}
		$auss_i3=1;
		$mauss_i=$auss_i;
		
		if ($mit_nachlass_oben and $m_sum_pag_nl!=0) {
			$aus_kurz_daten_nl=array();
			$aus_kurz_daten_nl2=array();
			$aus_kurz_daten_hz2[]=array('Korting', -$m_sum_pag_nl, -$soa_p2_nl);
			if (!isset($aus_kurz_daten_hz[1])) {
				$aus_kurz_daten_hz[1]=0;
			}
		}
		$sum_hzb_netto=0;
		if (!$cfg_kfzsuche_vlohnehzb and isset($aus_kurz_daten_hz[1])) {
			@reset($aus_kurz_daten_hz2);
			while (list($key, $val)=@each($aus_kurz_daten_hz2)) {
//echo '<br>'.$val[0].': ';
				if ($cfg_kfzsuche_hzb_druckoption and $val[2] and $val[3]) {
					continue;
				}
				if ($auss_i3>=($maxzeilen-($mauss_i-1)-($genutzte_zeilen-1))) {
//echo 'wird gesammelt';
					$vm_t=$val[0].' / ';
					$vm_p=$val[1];
					while (list($key, $val)=@each($aus_kurz_daten_hz2)) {
						$vm_t.=$val[0].' / ';
						$vm_p+=$val[1];
					}
					$val[0]=p4n_mb_string('substr',$vm_t, 0, -3);
					$val[1]=$vm_p;
				}
				if ($cfg_kfzsuche_hzb_druckoption and $val[2]) {
					$inhalt=p4n_sb_strreplace('<<sonder'.$auss_i.'>>', '', $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<sonder'.$auss_i.'>>', $val[0], $inhalt);
				$soa_p=str_replace(',', '.', $val[1]);
				$sonderp_sum+=doubleval($soa_p);
				$soa_p_fw=doubleval($soa_p)*$kurs1;
				$soa_p2=str_replace(',', '.', $val[1]);
				if (trim($val[0])!='') {
					$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
					$soa_p2=number_format(doubleval(number_format(doubleval(str_replace(',', '.', $val[1])), 2, ".", ""))/(1+$m_cfg_mwst+$nova_zus_mwst), 2, ",", ".");
				}
				$sonderp_sumn+=doubleval(str_replace(',', '.', str_replace('.', '', $soa_p2)));
				if ($cfg_kfzsuche_hzb_druckoption and $val[3]) {
					$inhalt=p4n_sb_strreplace('<<sonderp'.$auss_i.'>>', '', $inhalt);
					$inhalt=p4n_sb_strreplace('<<ksonderp'.$auss_i.'>>', '', $inhalt);
					$inhalt=p4n_sb_strreplace('<<sonderp'.$auss_i.'_netto>>', '', $inhalt);
				}
				$inhalt=p4n_sb_strreplace('<<sonderp'.$auss_i.'>>', $soa_p, $inhalt);
				$inhalt=p4n_sb_strreplace('<<ksonderp'.$auss_i.'>>', number_format(doubleval($soa_p_fw), 2, ",", "."), $inhalt);
				if (!isset($postfeld['fin_ust_gk'])) {
					$soa_p2='';
				}
				$m_vkpreis2-=doubleval(number_format(doubleval(str_replace(',', '.', str_replace('.', '', $soa_p2))), 2, ".", ""));
				$sum_hzb_netto+=doubleval(number_format(doubleval(str_replace(',', '.', str_replace('.', '', $soa_p2))), 2, ".", ""));
				$inhalt=p4n_sb_strreplace('<<sonderp'.$auss_i.'_netto>>', $soa_p2, $inhalt);
				$auss_i++;
				$auss_i3++;
			}
		}
		$auss_i3=1;
		$soa_p='';
		$soa_p2='';
		$mauss_i=$auss_i;
		if (preg_match('/<<disc_b1>>/', $inhalt)) {
			unset($aus_kurz_daten_nl);
		}
		
		if (isset($aus_kurz_daten_nl[1])) {
			@reset($aus_kurz_daten_nl2);
			while (list($key, $val)=@each($aus_kurz_daten_nl2)) {
				if ($auss_i3>=($maxzeilen-($mauss_i-1))) {
					$vm_t=$val[0].' / ';
					$vm_p=$val[1];
					$vm_p2=$val[2];
					while (list($key, $val)=@each($aus_kurz_daten_nl2)) {
						$vm_t.=$val[0].' / ';
						$vm_p+=$val[1];
						$vm_p2+=$val[2];
					}
					$val[0]=p4n_mb_string('substr',$vm_t, 0, -3);
					$val[1]=$vm_p;
					$val[2]=$vm_p2;
				}
				$inhalt=p4n_sb_strreplace('<<sonder'.$auss_i.'>>', $val[0], $inhalt);
				$soa_p=str_replace(',', '.', $val[1]);
				$soa_p2=str_replace(',', '.', $val[1]);
				if (trim($val[0])!='') {
					if (doubleval($soa_p)<0) {
						$soa_p=abs($soa_p);
					} else {
						$soa_p=-doubleval($soa_p);
					}
					if (doubleval($soa_p2)<0) {
						$soa_p2=abs($soa_p2);
					} else {
						$soa_p2=-doubleval($soa_p2);
					}
					$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
					$soa_p2=number_format(doubleval(number_format(doubleval($soa_p2), 2, ".", ""))/(1+$cfg_mwstn+$nova_zus_mwst), 2, ",", ".");
				}
				$soa_p_fw=doubleval(str_replace(',', '.', $soa_p))*$kurs1;
				if (!isset($postfeld['fin_ust_gk'])) {
					$soa_p2='';
				} elseif ($cfg_kfzsuche_preisa_proz) {
					$soa_p=number_format(doubleval($val[2]), 2, ",", "").'% / '.$soa_p;
					$soa_p2=number_format(doubleval($val[2]), 2, ",", "").'% / '.$soa_p2;
				}
				$inhalt=p4n_sb_strreplace('<<pag_b'.$auss_i.'>>', $soa_p, $inhalt);
				$inhalt=p4n_sb_strreplace('<<kpag_b'.$auss_i.'>>', $soa_p_fw, $inhalt);
				$inhalt=p4n_sb_strreplace('<<pag_n'.$auss_i.'>>', $soa_p2, $inhalt);
				$auss_i++;
				$auss_i3++;

				$nlt1=$zeile_nachlass;
				$nlt1=p4n_sb_strreplace('<<pag_text>>', $val[0], $nlt1);
				$nlt1=p4n_sb_strreplace('<<pag_b1>>', $soa_p, $nlt1);
				$nlt1=p4n_sb_strreplace('<<pag_n1>>', $soa_p2, $nlt1);
				$gesamt_nlt.=$nlt1;
			}
		}
		$gesamt_nlt.=$nlt1x;
		// Nachl�sse Vorlage 4
		$inhalt=str_replace($zeile_nachlass_alles, $gesamt_nlt, $inhalt);


			$inhalt=p4n_sb_strreplace('<<pag_n>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<pag_b>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<pag_n_sum>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<kpag_b_sum>>', '', $inhalt);
//			$inhalt=p4n_sb_strreplace('<<kpag_n_sum>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<pag_b_sum>>', '', $inhalt);
			for ($zi=1; $zi<=50; $zi++) {
				$inhalt=p4n_sb_strreplace('<<sonder'.$zi.'>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<sonderp'.$zi.'>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<ksonderp'.$zi.'>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<sonderp'.$zi.'_netto>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<sonder'.$zi.'>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<sonderp'.$zi.'>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<sonderp'.$zi.'_netto>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<pag_n'.$zi.'>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<pag_b'.$zi.'>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<kpag_b'.$zi.'>>', '', $inhalt);
			}
		}
		} else {
		for ($auss_i=1; $auss_i<=50; $auss_i++) {
			$inhalt=p4n_sb_strreplace('<<sonder'.$auss_i.'>>', $postfeld['vertrag_sonder'.$auss_i], $inhalt);
			$soa_p=str_replace(',', '.', $postfeld['vertrag_sonderpreis'.$auss_i]);
			$soa_p_fw=doubleval($soa_p)*$kurs1;
			$soa_p2=str_replace(',', '.', $postfeld['vertrag_sonderpreis'.$auss_i]);
			$sonderp_sum+=doubleval($soa_p);
			if (/*1 or doubleval($soa_p)>0 */trim($postfeld['vertrag_sonder'.$auss_i])!='') {
				$soa_p=number_format(doubleval($soa_p), 2, ",", ".");
				$soa_p2=number_format(doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag_sonderpreis'.$auss_i])), 2, ".", ""))/(1+$cfg_mwstn), 2, ",", ".");
				$preis_ges1+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag_sonderpreis'.$auss_i])), 2, ".", ""));
			}
			$sonderp_sumn+=doubleval(str_replace(',', '.', str_replace('.', '', $soa_p2)));
			$inhalt=p4n_sb_strreplace('<<sonderp'.$auss_i.'>>', $soa_p, $inhalt);
			$inhalt=p4n_sb_strreplace('<<ksonderp'.$auss_i.'>>', number_format(doubleval($soa_p_fw), 2, ",", "."), $inhalt);
			if (!isset($postfeld['fin_ust_gk'])) {
				$soa_p2='';
			}
			$inhalt=p4n_sb_strreplace('<<sonderp'.$auss_i.'_netto>>', $soa_p2, $inhalt);
		}
		}
		
		$su_nachl1=0;
		$disc_z=1;
		for ($auss_i=1; $auss_i<=4; $auss_i++) {
			if (isset($postfeld['preisa_d'.$auss_i])) {
				if ($postfeld['vertrag5_sonderr'.$auss_i]!='' or doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrpreis'.$auss_i]))!=0) {
					$transp1=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrpreis'.$auss_i]));
					$preistn=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrpreis'.$auss_i]))/(1+$cfg_mwstn), 2, ".", ""));
					$inhalt=p4n_sb_strreplace('<<discount'.$disc_z.'>>', $postfeld['vertrag5_sonderr'.$auss_i], $inhalt);
					$soa_p_fw=doubleval(str_replace(',', '.', $transp1))*$kurs1;
					
					$inhalt=p4n_sb_strreplace('<<kdisc_b'.$disc_z.'>>', number_format(doubleval($soa_p_fw), 2, ",", "."), $inhalt);
					$inhalt=p4n_sb_strreplace('<<disc_b'.$disc_z.'>>', number_format(doubleval($transp1), 2, ",", "."), $inhalt);
					$disc_z++;
				}
			}
			$su_nachl1+=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderrpreis'.$auss_i]));
		}
		for ($auss_i=1; $auss_i<=4; $auss_i++) {
			$inhalt=p4n_sb_strreplace('<<discount'.$auss_i.'>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<kdisc_b'.$auss_i.'>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<disc_b'.$auss_i.'>>', '', $inhalt);
		}
		
		$ausst_zeilea=str_replace(array('<<pag_nx>>', '<<pag_bx>>'), '', $ausst_zeilea);
		if (intval($postfeld['nwvorlage'])==4) {
			$inhalt=p4n_sb_strreplace($ausst_zeileg, $ausst_zeilea2, $inhalt);
		} else {
			$inhalt=p4n_sb_strreplace($ausst_zeileg, $ausst_zeilea, $inhalt);
		}
		
		$ausst_zeilean=str_replace(array('<<pag_nx>>', '<<pag_bx>>'), '', $ausst_zeilean);
		$ausst_zeilean=str_replace(array('<<sonderpagn>>', '<<sonderpag>>'), '', $ausst_zeilean);
		if (intval($postfeld['nwvorlage'])==3) {
			$inhalt=p4n_sb_strreplace($ausst_zeilegn, $ausst_zeilean/*.$ausst_zeilea2n*/, $inhalt);
			$inhalt=p4n_sb_strreplace($ausst_zeilegnz, $ausst_zeilean, $inhalt);
		} else {
			$inhalt=p4n_sb_strreplace($ausst_zeilegn, $ausst_zeilean, $inhalt);
			$inhalt=p4n_sb_strreplace($ausst_zeilegnz, $ausst_zeilean, $inhalt);
		}

		$inhalt=p4n_sb_strreplace($hzb_zeilegn, $hzb_zeilean, $inhalt);

		if (isset($postfeld['gme_foto'])) {
			$inhalt=p4n_sb_preg_replace('/<<vc1>>.*<<vc2>>/Uis', '', $inhalt);
		}
		$inhalt=p4n_sb_strreplace(array('<<vc1>>','<<vc2>>'), '', $inhalt);

//echo $ausst_zeileg.'<br><br>---- '.$ausst_zeilea;
//die();
		
		$inhalt=p4n_sb_strreplace('<<sonderpsum>>', number_format($sonderp_sum, 2, ",", "."), $inhalt);
		$soa_p_fw=$sonderp_sum*$kurs1;
		$kspn_soa_p_fw2=$sonderp_sumn*$kurs1;
		$inhalt=p4n_sb_strreplace('<<ksonderpsum>>', number_format($soa_p_fw, 2, ",", "."), $inhalt);
		
		$sonderp_sum2=$sonderp_sum;//+$su_nachl1;
		$inhalt=p4n_sb_strreplace('<<sonderpsum2>>', number_format($sonderp_sum2, 2, ",", "."), $inhalt);
//echo $sonderp_sum.'/'.$soa_p_fw.' + '.$su_nachl1.' = '.$sonderp_sum2.'<br>';
		$soa_p_fw=$sonderp_sum2*$kurs1;
		$inhalt=p4n_sb_strreplace('<<ksonderpsum2>>', number_format($soa_p_fw, 2, ",", "."), $inhalt);
//echo $sonderp_sum2.'/'.$soa_p_fw.' + '.$su_nachl1.' = '.$sonderp_sum2.'<br>';
		
		$summe2=0;
		$summe3=0;
		$summe2+=doubleval(str_replace(',', '.', $postfeld['vertrag_montagepreis']));
		$summe2+=doubleval(str_replace(',', '.', $postfeld['vertrag_zulassung']));
		$summe2+=doubleval(str_replace(',', '.', $postfeld['vertrag_transport']));
		$finp1=doubleval(str_replace(',', '.', $postfeld['fin_preis']));
		$finp2=doubleval(str_replace(',', '.', $postfeld['fin_preis2']));
		if ($finp1==$finp2) {
			$summe2+=doubleval(str_replace(',', '.', $postfeld['fin_preis2']));
			$summe3+=doubleval(str_replace(',', '.', $postfeld['fin_preis2']));
		} else {
			$summe2+=doubleval(str_replace(',', '.', $postfeld['fin_preis2']));
			$summe2+=doubleval(str_replace(',', '.', $postfeld['fin_preis']));
			$summe3+=doubleval(str_replace(',', '.', $postfeld['fin_preis2']));
			$summe3+=doubleval(str_replace(',', '.', $postfeld['fin_preis']));
		}
		if ($cfg_dvs) {
			$spak_preis=doubleval(str_replace(',', '.', $postfeld['fin_servicepaket']));
			$summe2+=$spak_preis;
			$summe3+=$spak_preis;
		}
		if (isset($postfeld['vertrag_eugeschaeft'])) {
//			$inhalt=p4n_sb_strreplace('<<summe_gesamt>>', number_format($summe2-($summe2*$cfg_mwst), 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<summe_gesamt>>', number_format($summe2*100/(100+(100*$cfg_mwstn)), 2, ",", "."), $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<summe_gesamt>>', number_format($summe2, 2, ",", "."), $inhalt);
		
		$finspaket=$postfeld['fin_servicepaket2'];
		$finspaket=str_replace(number_format($spak_preis, 2, ",", "."), '', $finspaket);
		$finspaket=trim($finspaket);
		$inhalt=p4n_sb_strreplace('<<servicepaket>>', $finspaket, $inhalt);
		$inhalt=p4n_sb_strreplace('<<servicepaketpreis>>', number_format($spak_preis, 2, ",", "."), $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<zusatzdatum>>', $postfeld['zusatzdatum1'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<h>>', $postfeld['vertrag_handelsgerichtlich'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vdet_liefer_janein1>>', $postfeld['vertrag_liefer_janein1'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<vdet_liefer_janein2>>', $postfeld['vertrag_liefer_janein2'], $inhalt);
		
		if ($cfg_kfzsuche_transneben_druckoption) {
			if (!isset($postfeld['nebendruck'])) {
				$inhalt=p4n_sb_strreplace('<<zulassungp>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<zulassungp_netto>>', '', $inhalt);
				$inhalt=p4n_sb_preg_replace('/<<start_nebdr>>.*<<end_nebdr>>/Uis', '', $inhalt);
			} else {
				$inhalt=p4n_sb_strreplace('<<start_nebdr>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<end_nebdr>>', '', $inhalt);
			}
			
			if (!isset($postfeld['transdruck'])) {
				$inhalt=p4n_sb_strreplace('<<transportp>>', '', $inhalt);
				$inhalt=p4n_sb_strreplace('<<transportp_netto>>', '', $inhalt);
			}
		}
		
		$inhalt=p4n_sb_strreplace('<<montagep>>', number_format(doubleval(str_replace(',', '.', str_replace(',', '.', $postfeld['vertrag_montagepreis']))), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<zulassungp>>', number_format(doubleval(str_replace(',', '.', str_replace(',', '.', $postfeld['vertrag_zulassung']))), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<transportp>>', number_format(doubleval(str_replace(',', '.', str_replace(',', '.', $postfeld['vertrag_transport']))), 2, ",", "."), $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<listenpreis_sa>>', number_format($werkpreis, 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<listenpreis_sa_netto>>', number_format($werkpreis/(1+$m_cfg_mwst), 2, ",", "."), $inhalt);
		
		$listenpreis_sa2=$werkpreis+doubleval(str_replace(',', '.', str_replace(',', '.', $postfeld['vertrag_transport'])))+$m_pagbsum;
		$mwst_sa2=$listenpreis_sa2-($listenpreis_sa2/(1+$m_cfg_mwst));
		if ($mitsatz_diffbest and $_SESSION['cfg_kunde']=='carlo_opel_werbas_schleusener') {
			$inhalt=p4n_sb_strreplace('<<listenpreis_sa2_mwst>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<listenpreis_sa2_netto>>', number_format($listenpreis_sa2, 2, ",", "."), $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<listenpreis_sa2_netto>>', number_format($listenpreis_sa2/(1+$m_cfg_mwst), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<listenpreis_sa2>>', number_format($listenpreis_sa2, 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<listenpreis_sa2_mwst>>', number_format($mwst_sa2, 2, ",", "."), $inhalt);
		
		$listenpreis_sa3=$listenpreis_sa2+doubleval(str_replace(',', '.', str_replace(',', '.', $postfeld['vertrag_zulassung'])))+doubleval($summe_hzb);
		$inhalt=p4n_sb_strreplace('<<listenpreis_sa3>>', number_format($listenpreis_sa3, 2, ",", "."), $inhalt);
		
		$listenpreis_sa_avag=$listenpreis_sa3-$m_pagbsum;
		$inhalt=p4n_sb_strreplace('<<listenpreis_br_all>>', number_format($listenpreis_sa_avag, 2, ",", "."), $inhalt);
		if (!isset($postfeld['fin_ust_gk'])) {
			$inhalt=p4n_sb_strreplace('<<listenpreis_ne_all>>', '', $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<listenpreis_ne_all>>', number_format($listenpreis_sa_avag/(1+$m_cfg_mwst), 2, ",", "."), $inhalt);
		
		$listenpreis_sa4=$listenpreis_sa3-doubleval(str_replace(',', '.', $postfeld['fin_abzug_inz']))-doubleval(str_replace(',', '.', $postfeld['fin_abzug_fin']))+doubleval(str_replace(',', '.', $postfeld['fin_abzug_abloese']))-doubleval(str_replace(',', '.', $postfeld['fin_abzug_vers']));
		$inhalt=p4n_sb_strreplace('<<listenpreis_sa4>>', number_format($listenpreis_sa4, 2, ",", "."), $inhalt);
		$listenpreis_sa5=$listenpreis_sa4-doubleval(str_replace(',', '.', $postfeld['fin_abzug_anz']));
		$inhalt=p4n_sb_strreplace('<<listenpreis_sa5>>', number_format($listenpreis_sa5, 2, ",", "."), $inhalt);
		
		if (isset($postfeld['vertrag5_neben2'])) {
			$inhalt=p4n_sb_strreplace('<<neben2_brutto>>', number_format(doubleval(str_replace(',', '.', str_replace(',', '.', $postfeld['vertrag5_neben2']))), 2, ",", "."), $inhalt);
			$summe2+=doubleval(str_replace(',', '.', $postfeld['vertrag5_neben2']));
		}
		$steuer_lp=$preis_gesl+doubleval(str_replace(',', '.', $postfeld['listenpreis']));
		$steuer_lp=$steuer_lp-doubleval(str_replace(',', '.', $steuer_lp))/(1+$cfg_mwstn);
		$steuer_kfz_trans=$steuer_lp+doubleval(str_replace(',', '.', $postfeld['vertrag_transport']))-doubleval(str_replace(',', '.', $postfeld['vertrag_transport']))/(1+$cfg_mwst);
		$inhalt=p4n_sb_strreplace('<<steuer_kfz_transport>>', number_format($steuer_kfz_trans, 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<vkpreis_sum_br_pa>>', number_format($preis_ges1+doubleval(str_replace(',', '.', $postfeld['summe_preisa']))+doubleval(str_replace(',', '.', $postfeld['listenpreis']))+(isset($postfeld['vertrag5_neben2'])?doubleval(str_replace(',', '.', $postfeld['vertrag5_neben2'])):0)+doubleval(str_replace(',', '.', $postfeld['vertrag_transport']))+doubleval(str_replace(',', '.', $postfeld['vertrag_zulassung'])), 2, ',', '.'), $inhalt);

		//Bj�rn
		if ($cfg_kfzsuche_tausenderpunkt) {
			if (preg_match('/,/', $postfeld['listenpreis']) and preg_match('/\./', $postfeld['listenpreis'])) {
				$postfeld['listenpreis']=str_replace('.', '', $postfeld['listenpreis']);
			}
		}
		$inhalt=p4n_sb_strreplace('<<vkpreis_liste>>', number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ",","."), $inhalt);
		$soa_p_fw=doubleval(str_replace(',', '.', $postfeld['listenpreis']))*$kurs1;
		$inhalt=p4n_sb_strreplace('<<kvkpreis_liste>>', number_format($soa_p_fw, 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<vkpreis_sum_br>>', number_format($preis_ges1+doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ',', '.'), $inhalt);
		$inhalt=p4n_sb_strreplace('<<lpreis_sum_br>>', number_format($preis_gesl+doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ',', '.'), $inhalt);
		$merke_lpreis_sum_br=number_format($preis_gesl+doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ',', '.');
		$inhalt=p4n_sb_strreplace('<<lpreis_sum_br_gr>>', number_format($preis_gesl+doubleval(str_replace(',', '.', $postfeld['listenpreis']))+doubleval(str_replace(',', '.', $postfeld['vertrag_transport']))+doubleval(str_replace(',', '.', $postfeld['vertrag_zulassung']))+doubleval(str_replace(',', '.', $postfeld['vertrag5_luxurytax'])), 2, ',', '.'), $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<lpreis_sum_br_obm>>', number_format($preis_gesl+doubleval(str_replace(',', '.', $postfeld['listenpreis']))+doubleval(str_replace(',', '.', $postfeld['bonus_malus'])), 2, ',', '.'), $inhalt);

		$neben_brutto1=doubleval(str_replace(',', '.', $postfeld['vertrag5_neben2']));
		if (isset($postfeld['messa_su_strada_sep'])) {
			$inhalt=p4n_sb_strreplace('<<vkpreis_liste2>>', number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis']))+doubleval(str_replace(',', '.', 0)), 2, ",","."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<vkpreis_liste3>>', number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis']))+doubleval(str_replace(',', '.', 0)), 2, ",","."), $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<vkpreis_liste2>>', number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis']))+doubleval(str_replace(',', '.', $postfeld['vertrag_transport'])), 2, ",","."), $inhalt);
		$transp_brutto1=doubleval(str_replace(',', '.', $postfeld['vertrag_transport']));
		
		if ($cfg_kfzsuche_transneben_druckoption) {
			if (!isset($postfeld['nebendruck'])) {
				$inhalt=p4n_sb_strreplace('<<vkpreis_liste_netto_nt>>', number_format(doubleval($listep+doubleval(str_replace(',', '.', $postfeld['vertrag5_neben']))/(1+$cfg_mwst)), 2, ",","."), $inhalt);
				$inhalt=p4n_sb_strreplace('<<vkpreis_liste_nt>>', number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis']))+doubleval(str_replace(',', '.', $postfeld['vertrag5_transport']))+doubleval(str_replace(',', '.', $postfeld['vertrag5_neben'])), 2, ",","."), $inhalt);
			} else {
				$inhalt=p4n_sb_strreplace('<<vkpreis_liste_nt>>', number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ",","."), $inhalt);
				$inhalt=p4n_sb_strreplace('<<vkpreis_liste_netto_nt>>', number_format(doubleval($listep), 2, ",","."), $inhalt);
			}
		}
		$inhalt=p4n_sb_strreplace('<<vkpreis_liste3>>', number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis']))+doubleval(str_replace(',', '.', $postfeld['vertrag_transport']))+$neben_brutto1, 2, ",","."), $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<lpreis_sum_br2>>', number_format($preis_gesl+doubleval(str_replace(',', '.', $postfeld['listenpreis']))+$transp_brutto1, 2, ',', '.'), $inhalt);
		$inhalt=p4n_sb_strreplace('<<lpreis_sum_br3>>', number_format($preis_gesl+doubleval(str_replace(',', '.', $postfeld['listenpreis']))+$transp_brutto1+$neben_brutto1, 2, ',', '.'), $inhalt);
		$m_lpreis_sum_br3=$preis_gesl+doubleval(str_replace(',', '.', $postfeld['listenpreis']))+$transp_brutto1+$neben_brutto1;
		$pagb1t=str_replace(',', '.', str_replace('.', '', $m_pag_brutto1));
		$inhalt=p4n_sb_strreplace('<<lpapreis_sum_br2>>', number_format($preis_gesl+doubleval(str_replace(',', '.', $postfeld['listenpreis']))+$transp_brutto1+doubleval($pagb1t), 2, ',', '.'), $inhalt);
		$inhalt=p4n_sb_strreplace('<<lpapreis_sum_br3>>', number_format($preis_gesl+doubleval(str_replace(',', '.', $postfeld['listenpreis']))+$transp_brutto1+$neben_brutto1+doubleval($pagb1t), 2, ',', '.'), $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<vkpreis_liste4>>', number_format(doubleval($pagb1t)+doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ",","."), $inhalt);
		// <<summe>> - <<nofin_payout>> -  <<zahlung_abholung>> - <<vertrags_gwpreis>>
		$nofin_payout1=doubleval(str_replace(',', '.', $postfeld['nofin_payout']));
		if (!isset($postfeld['no_fin'])) {
			$nofin_payout1=0;
		}
		$no_b3=$gespreis-$nofin_payout1-doubleval(str_replace(',', '.', $postfeld['fin_anzahlung2']))-doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis']));
		$no_b5=doubleval(str_replace(',', '.', $postfeld['fin_anzahlung2']))+doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis']))+$no_b3+$nofin_payout1;
		$no_b4=0;
		if (isset($postfeld['no_leas'])) {
			$no_b3=doubleval(str_replace(',', '.', $postfeld['noleas_pre']))*(1+$cfg_mwst)-doubleval(str_replace(',', '.', $postfeld['fin_anzahlung2']));
			$no_b4=$no_b5-$no_b3-doubleval(str_replace(',', '.', $postfeld['fin_anzahlung2']))-doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis']));
		}
		$inhalt=p4n_sb_strreplace('<<no_b3>>', number_format($no_b3, 2, ",","."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<no_b4>>', number_format($no_b4, 2, ",","."), $inhalt);
		// 		<<zahlung_abholung>+<<vertrags_gwpreis>>+b3+<<nofin_payout>
		$inhalt=p4n_sb_strreplace('<<no_b5>>', number_format($no_b5, 2, ",","."), $inhalt);
		
		$transp_netto='';
		$neben_netto='';
		if (isset($postfeld['fin_ust_gk'])) {
			$transp_netto=number_format(doubleval(str_replace(',', '.', $postfeld['vertrag_transport']))/(1+$m_cfg_mwst+$nova_zus_mwst), 2, ",", ".");
			$neben_netto=number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_neben2']))/(1+$cfg_mwst), 2, ",", ".");
			$m_vkpreis1-=doubleval(number_format(doubleval(str_replace(',', '.', str_replace('.', '', $transp_netto))), 2, ".",""));
			$m_vkpreis2-=doubleval(number_format(doubleval(str_replace(',', '.', str_replace('.', '', $transp_netto))), 2, ".",""));
			$zulp_netto=number_format(doubleval(doubleval(str_replace(',', '.', $postfeld['vertrag_zulassung'])))/(1+$cfg_mwst), 2, ",", ".");
			$inhalt=p4n_sb_strreplace('<<nettok_brutto>>', $waehrung_eur2.' '._NETTO_, $inhalt);

			$bonmal_abzug=0;
			if ($cfg_kfzsuche_austria) {
				$listep=(doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ".",""))/(1+$m_cfg_mwst)-$bonmal/(1+$m_cfg_mwst))/(1+$localtaxp/100);
				$listep2=(doubleval(number_format($preis_gesl+doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ".",""))/(1+$m_cfg_mwst)-$bonmal/(1+$m_cfg_mwst))/(1+$localtaxp/100);
				$liste_neu=doubleval(str_replace(',', '.', $postfeld['listenpreis']))/(1+$cfg_mwst);
				$bonmal_abzug=$liste_neu-$listep;
				if ($cfg_kfzsuche_novaneu) {
//					$bonmal_abzug=0;
				}
				$ist_von_konf=false;
				if (($s4c_neu or $cfg_kfzsuche_austria) and isset($postfeld['gme_netpreis'])) {
					$listep=$postfeld['gme_netpreis'];
					$listep2=$postfeld['gme_netpreis2'];
					$ist_von_konf=true;
				} elseif ($s4c_neu or $cfg_kfzsuche_austria) {
					$listep=$m_vkpreis2;
					if (isset($postfeld['freiekonf'])) {
						$listep=(doubleval(str_replace(',', '.', $postfeld['listenpreis5']))+$bonmal)/(1+$m_cfg_mwst+$nova_zus_mwst);
					}
					$listep2=$m_vkpreis1;
				}
				$dazulpn=0;
				if ($cfg_kfzsuche_nettolpreissum_hzb and ($ist_von_konf or !$hzb_istdrin)) {
					$dazulpn=$sum_hzb_netto;
				}
				
				$inhalt=p4n_sb_strreplace('<<lpreis_sum_netto>>', number_format(doubleval($listep2)+$dazulpn, 2, ',', '.'), $inhalt);
				$inhalt=p4n_sb_strreplace('<<vkpreis_liste_netto>>', number_format(doubleval($listep), 2, ",","."), $inhalt);
				
				$neulp_n2=doubleval(number_format(doubleval(str_replace(',', '.', $listep2)), 2,".",""))-doubleval(str_replace(',', '.', $postfeld['summe_preisa']))/(1+$m_cfg_mwst+$nova_zus_mwst);
				$neulp_n2+=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag_transport']))/(1+$m_cfg_mwst+$nova_zus_mwst), 2, ".", ""));
				if ($s4c_neu or $cfg_kfzsuche_austria) {
					$inhalt=p4n_sb_strreplace('<<vkpreis_sum_ne_total>>', number_format($neulp_n2+$dazulpn, 2, ',', '.'), $inhalt);
				}
			}

			$tax1wn=doubleval(str_replace(',', '.', $postfeld['add_tax1_wert']))/(1+$cfg_mwst);
			if ($postfeld['add_tax1v']!='1') {
				$tax1wn=doubleval(str_replace(',', '.', $postfeld['add_tax1_wert']));
			}
			$tax1wn=doubleval(number_format($tax1wn, 2, ".", ""));
			$tax2wn=doubleval(str_replace(',', '.', $postfeld['add_tax2_wert']))/(1+$cfg_mwst);
			if ($postfeld['add_tax2v']!='1') {
				$tax2wn=doubleval(str_replace(',', '.', $postfeld['add_tax2_wert']));
			}
			$tax2wn=doubleval(number_format($tax2wn, 2, ".", ""));
			$inhalt=p4n_sb_strreplace('<<tax1n>>', number_format($tax1wn, 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<tax2n>>', number_format($tax2wn, 2, ",", "."), $inhalt);

			$lp_netto_t1=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ".",""))/(1+$cfg_mwstn);
			$inhalt=p4n_sb_strreplace('<<vkpreis_liste_netto2>>', number_format($lp_netto_t1+doubleval(str_replace(',', '.', $transp_netto)), 2, ",","."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<vkpreis_liste_netto3>>', number_format($lp_netto_t1+doubleval(str_replace(',', '.', $transp_netto))+doubleval(str_replace(',', '.', $neben_netto)), 2, ",","."), $inhalt);

			$lpreissune1=str_replace(',', '.', number_format(($preis_gesl+doubleval(str_replace(',', '.', $postfeld['listenpreis'])))/(1+$cfg_mwstn), 2, '.', ''));
			$inhalt=p4n_sb_strreplace('<<lpreis_sum_netto2>>', number_format(doubleval($lpreissune1)+doubleval(str_replace(',', '.', $transp_netto)), 2, ',', '.'), $inhalt);
			$inhalt=p4n_sb_strreplace('<<lpreis_sum_netto3>>', number_format(doubleval($lpreissune1)+doubleval(str_replace(',', '.', $transp_netto))+doubleval(str_replace(',', '.', $neben_netto)), 2, ',', '.'), $inhalt);

			$pagn1t=str_replace(',', '.', str_replace('.', '', $m_pag_netto1));
			$inhalt=p4n_sb_strreplace('<<lpapreis_sum_netto2>>', number_format(doubleval($lpreissune1)+doubleval(str_replace(',', '.', $transp_netto))+doubleval($pagn1t), 2, ',', '.'), $inhalt);
			$inhalt=p4n_sb_strreplace('<<lpapreis_sum_netto3>>', number_format(doubleval($lpreissune1)+doubleval(str_replace(',', '.', $transp_netto))+doubleval(str_replace(',', '.', $neben_netto))+doubleval($pagn1t), 2, ',', '.'), $inhalt);

			$inhalt=p4n_sb_strreplace('<<lpreis_sum_netto>>', number_format(($preis_gesl-$lt_abzug1-$lt_abzug2+doubleval(str_replace(',', '.', $postfeld['listenpreis'])))/(1+$cfg_mwstn), 2, ',', '.'), $inhalt);

			$inhalt=p4n_sb_strreplace('<<vkpreis_sum_netto>>', number_format(($preis_ges1+doubleval(str_replace(',', '.', $postfeld['listenpreis'])))/(1+$cfg_mwstn), 2, ',', '.'), $inhalt);
			$inhalt=p4n_sb_strreplace('<<lpreis_sum_netto>>', number_format(($preis_gesl+doubleval(str_replace(',', '.', $postfeld['listenpreis'])))/(1+$cfg_mwstn), 2, ',', '.'), $inhalt);
			$inhalt=p4n_sb_strreplace('<<vkpreis_liste_netto>>', number_format(doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['listenpreis'])), 2, ".","")/(1+$cfg_mwstn)), 2, ",","."), $inhalt);
			
			$soa_p_fw=doubleval(str_replace(',', '.', $postfeld['listenpreis'])) / (1 + $cfg_mwstn) * $kurs1;
			$inhalt=p4n_sb_strreplace('<<kvkpreis_liste_netto>>', number_format($soa_p_fw, 2, ",","."), $inhalt);
			
			//Bj�rn
			$vkpreis_sum_ne_total=(($preis_ges1+doubleval(str_replace(',', '.', $postfeld['listenpreis'])))/(1+$cfg_mwstn))+((doubleval(str_replace(',', '.', $postfeld['vertrag_zulassung']))+$tax1wn+$tax2wn+(isset($postfeld['vertrag5_neben2'])?doubleval(str_replace(',', '.', $postfeld['vertrag5_neben2'])):0)+doubleval(str_replace(',', '.', $postfeld['vertrag_transport'])))/(1+$cfg_mwst));
			if ($postfeld['vertrag_nwgw']=='1') {
				if ($pid_istdiff or $diffbest or $mitsatz_diffbest) {
					$inhalt=p4n_sb_strreplace('<<vkpreis_sum_ne_total_20>>', number_format(0, 2, ',', '.'), $inhalt);
				}
				$vkpreis_sum_ne_total=$finp2/(1+$cfg_mwst);	// $summe2 mit Transport
			}
			if ($cfg_greek) {
				$vkpreis_sum_ne_total=(($preis_ges1-$lt_abzug1-$lt_abzug2+doubleval(str_replace(',', '.', $postfeld['listenpreis'])))/(1+$cfg_mwstn))+(($tax1wn+$tax2wn+doubleval(str_replace(',', '.', $postfeld['vertrag_transport'])))/(1+$cfg_mwst));
			}
			if ($cfg_kfzsuche_novaneu) {
				$inhalt=p4n_sb_strreplace('<<mwst>>', number_format(doubleval($vkpreis_sum_ne_total-$bonmal_abzug)*$cfg_mwst, 2, ",", "."), $inhalt);
			}
			if ($cfg_kfzsuche_austria) {
//2012			$inhalt=p4n_sb_strreplace('<<vkpreis>>', number_format($vkpreis_sum_ne_total-$bonmal_abzug, 2, ',', '.'), $inhalt);
				$inhalt=p4n_sb_strreplace('<<vkpreis_sum_ne_total>>', number_format($vkpreis_sum_ne_total-$bonmal_abzug, 2, ',', '.'), $inhalt);
				$inhalt=p4n_sb_strreplace('<<vkpreis_sum_ne_total_20>>', number_format(($vkpreis_sum_ne_total-$bonmal_abzug)*$cfg_mwst, 2, ',', '.'), $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<vkpreis_sum_ne_total>>', number_format($vkpreis_sum_ne_total, 2, ',', '.'), $inhalt);
			$inhalt=p4n_sb_strreplace('<<vkpreis_sum_ne_total_20>>', number_format($vkpreis_sum_ne_total*$cfg_mwstn, 2, ',', '.'), $inhalt);
			$inhalt=p4n_sb_strreplace('<<enthaltene_mwst>>', 'Enthaltene MwSt:', $inhalt);
			
			if (isset($postfeld['summe_preisa_d']) and doubleval(str_replace(',', '.', $postfeld['summe_preisa']))!=0) {
				$inhalt=p4n_sb_strreplace('<<kpag_n_sum>>', number_format($kpagn_soa_p2_fw, 2, ",", "."), $inhalt);
			}
			$inhalt=p4n_sb_strreplace('<<sonderpsum_n>>', number_format($sonderp_sumn, 2, ",", "."), $inhalt);
			$inhalt=p4n_sb_strreplace('<<ksonderpsum_n>>', number_format($kspn_soa_p_fw2, 2, ",", "."), $inhalt);
		}
//echo number_format((($preis_ges1-$lt_abzug1-$lt_abzug2+str_replace(',', '.', $postfeld['listenpreis']))/(1+$cfg_mwstn))+(($tax1wn+$tax2wn+str_replace(',', '.', $postfeld['vertrag_transport']))/(1+$cfg_mwst)), 2, ",", ".");
		$nettotemp_nl=0;
		$vkpreis_diffe=0;
		$mwst_diffe=0;
		if ($cfg_kfzsuche_norway) {
			$nettotemp_nl=$m_pagbsum;
			if ($cfg_kfzsuche_norway and isset($postfeld['ohnesteuer']) and $postfeld['ohnesteuer']=='1') {
				$cfg_mwstn=0;
				for ($i=0; $i<=200; $i++) {
					if (isset($postfeld['vertrag5_zvat'.$i])) {
						if ($postfeld['vertrag5_zvat'.$i]=='0') {
							$hzbpr1=doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderzpreis'.$i]));//net_zaus5
							$hzbnetto1=$hzbpr1*100/(100+100*$cfg_mwst);
							$hzbsteuer1=$hzbpr1-$hzbnetto1;
							$mwst_diffe+=$hzbsteuer1;
							$vkpreis_diffe-=$hzbsteuer1;
						}
					}
				}
			}
		}
//echo number_format((($preis_ges1-$nettotemp_nl-$lt_abzug1-$lt_abzug2+doubleval(str_replace(',', '.', $postfeld['listenpreis'])))/(1+$cfg_mwstn))+(($tax1wn+$tax2wn+str_replace(',', '.', $postfeld['vertrag_transport']))/(1+$cfg_mwst)), 2, ",", ".");
//echo number_format((($preis_ges1-$nettotemp_nl-$lt_abzug1-$lt_abzug2+doubleval(str_replace(',', '.', $postfeld['listenpreis'])))/(1+$cfg_mwstn))+(($tax1wn+$tax2wn+str_replace(',', '.', $postfeld['vertrag_transport']))/(1+($cfg_kfzsuche_norway?$cfg_mwstn:$cfg_mwst))), 2, ",", ".");
//echo '<br>'.$preis_ges1.'-'.$nettotemp_nl.'-'.$lt_abzug1.'-'.$lt_abzug2.'+'.doubleval(str_replace(',', '.', $postfeld['listenpreis'])).' / '.(1+$cfg_mwstn);
//echo '<br>+'.$tax1wn.'+'.$tax2wn.'+'.doubleval(str_replace(',', '.', $postfeld['vertrag_transport'])).' / '.(1+$cfg_mwst).' + '.$vkpreis_diffe;
//die();
		if (!$cfg_kfzsuche_austria) { // neu 2014
			$inhalt=p4n_sb_strreplace('<<vkpreis>>', number_format((($preis_ges1-$nettotemp_nl-$lt_abzug1-$lt_abzug2+doubleval(str_replace(',', '.', $postfeld['listenpreis'])))/(1+$cfg_mwstn))+(($tax1wn+$tax2wn+doubleval(str_replace(',', '.', $postfeld['vertrag_transport'])))/(1+($cfg_kfzsuche_norway?$cfg_mwstn:$cfg_mwst)))+$vkpreis_diffe, 2, ",", "."), $inhalt);
		}
		if ($cfg_greek) {
			$gnetto1=doubleval(number_format((($preis_ges1-$lt_abzug1-$lt_abzug2+doubleval(str_replace(',', '.', $postfeld['listenpreis'])))/(1+$cfg_mwstn))+(($tax1wn+$tax2wn+doubleval(str_replace(',', '.', $postfeld['vertrag_transport'])))/(1+$cfg_mwst)), 2, ".", ""));
			$net1=$gespreis-doubleval(str_replace(',', '.', $postfeld['vertrag5_neben']));
			$net1-=$gnetto1;
			$net1-=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_luxurytax'])), 2, ".", ""));
			$net1-=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_localtax'])), 2, ".", ""));
			$inhalt=p4n_sb_strreplace('<<mwst>>', number_format($net1, 2, ",","."), $inhalt);
		}
		if ($cfg_kfzsuche_norway) {
			$gnetto1=doubleval(number_format((($preis_ges1+doubleval(str_replace(',', '.', $postfeld['listenpreis'])))/(1+$cfg_mwstn)), 2, ".", ""));
			$net1=$gespreis-doubleval(str_replace(',', '.', $postfeld['vertrag5_neben']));
			$net1-=$gnetto1;
			$nettotemp_nl=$m_pagbsum-$m_pagbsum/(1+$cfg_mwstn);
			$net1-=$nettotemp_nl;
			$net1-=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_localtax'])), 2, ".", ""));
$net1-=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_transport'])), 2, ".", ""))/(1+$cfg_mwstn);
//echo '-'.strval(doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_transport'])), 2, ".", ""))/(1+$cfg_mwstn)).'='.$net1.' / ';
//echo $m_pagbsum.'/'.$gespreis.'/'.$gnetto1.'/'.$preis_ges1.'/'.$net1; die();
			$inhalt=p4n_sb_strreplace('<<mwst>>', number_format($net1+$mwst_diffe, 2, ",","."), $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<vkpreis_sum_ne_total_20>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<enthaltene_mwst>>', '', $inhalt);

		$inhalt=p4n_sb_strreplace('<<vkpreis_liste_netto2>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<vkpreis_liste_netto3>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<lpreis_sum_netto2>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<lpapreis_sum_netto2>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<lpreis_sum_netto3>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<lpapreis_sum_netto3>>', '', $inhalt);

		if ($cfg_kfzsuche_austria) {
			$inhalt=p4n_sb_strreplace('<<vkpreis>>', number_format(doubleval($vkpreis1), 2, ',', '.'), $inhalt);
//echo '<br>'.$vkpreis1;
//die();
			$cfg_mwst=$m_cfg_mwst;
		}

		$inhalt=p4n_sb_strreplace('<<tax1_description>>', $postfeld['add_tax1'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<tax2_description>>', $postfeld['add_tax2'], $inhalt);
		$tax1w=doubleval(str_replace(',', '.', $postfeld['add_tax1_wert']));
		$inhalt=p4n_sb_strreplace('<<tax1>>', number_format($tax1w, 2, ',', '.'), $inhalt);
		$tax2w=doubleval(str_replace(',', '.', $postfeld['add_tax2_wert']));
		$inhalt=p4n_sb_strreplace('<<tax2>>', number_format($tax2w, 2, ',', '.'), $inhalt);
		$inhalt=p4n_sb_strreplace('<<tax1n>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<tax2n>>', '', $inhalt);

		$total_tax=doubleval(str_replace(',', '.', $postfeld['vertrag_zulassung']))+$tax1w+$tax2w;
		$inhalt=p4n_sb_strreplace('<<total_tax>>', number_format($total_tax, 2, ",", "."), $inhalt);
		$total_decrease=abs($m_pagbsum)+doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis']));
		$inhalt=p4n_sb_strreplace('<<total_decrease>>', number_format($total_decrease, 2, ",", "."), $inhalt);
		$total_without_disc=$total_tax+$m_lpreis_sum_br3;
		$inhalt=p4n_sb_strreplace('<<total_without_disc>>', number_format($total_without_disc, 2, ",", "."), $inhalt);
		$total_pay=$total_without_disc-$total_decrease;
		$inhalt=p4n_sb_strreplace('<<total_pay>>', number_format($total_pay, 2, ",", "."), $inhalt);
		$total_cash=$total_pay-$fin_finb;
		$inhalt=p4n_sb_strreplace('<<total_cash>>', number_format($total_cash, 2, ",", "."), $inhalt);
		$adv_amount=doubleval(str_replace(',', '.', $postfeld['fin_anzahlung2']));
		$inhalt=p4n_sb_strreplace('<<adv_amount>>', number_format($adv_amount, 2, ",", "."), $inhalt);
		$bal_delivery=$total_cash-$adv_amount;
		$inhalt=p4n_sb_strreplace('<<bal_delivery>>', number_format($bal_delivery, 2, ",", "."), $inhalt);

		$inhalt=p4n_sb_strreplace('<<transportp_netto>>', $transp_netto, $inhalt);
		$inhalt=p4n_sb_strreplace('<<zulassungp_netto>>', $zulp_netto, $inhalt);
		$inhalt=p4n_sb_strreplace('<<gwankauf_preis>>', ($cfg_kfzsuche_avag?$postfeld['vertrags_gwpreis']:number_format(doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis'])), 2, ",", ".")), $inhalt);

		$inhalt=p4n_sb_strreplace('<<nettok_brutto>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<vkpreis_sum_br>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<vkpreis_sum_netto>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<vkpreis_liste>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<vkpreis_liste_netto>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<kvkpreis_liste_netto>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<lpreis_sum_br>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<lpreis_sum_netto>>', '', $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<ksonderpsum_n>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<sonderpsum_n>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<kpag_n_sum>>', '', $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<panr_fzg>>', '', $inhalt);
		
		$inhalt=p4n_sb_strreplace('<<preis_inworten>>', $postfeld['preis_inworten'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<innenausstattung>>', $postfeld['kfz_innenausstattung'], $inhalt);
		$inhalt=p4n_sb_strreplace('<<angebotstext_sprache1>>', str_replace(array("\n", '<br>'), $sep_so2, $postfeld['kfz_angebotstext1']), $inhalt);
		$inhalt=p4n_sb_strreplace('<<angebotstext_sprache2>>', str_replace(array("\n", '<br>'), $sep_so2, $postfeld['kfz_angebotstext2']), $inhalt);
        $inhalt=p4n_sb_strreplace('<<boersenmerkmale>>', @$postfeld['kfz_boersenmerkmale'], $inhalt);
		
		//BJ�RN
		$inhalt=p4n_sb_strreplace('<<vkpreis_sum_ne_total>>', '', $inhalt);
		if ($cfg_greek) {
			$inhalt=p4n_sb_strreplace('<<vkpreis_sum_br_total>>', number_format($preis_ges1+doubleval(str_replace(',', '.', $postfeld['listenpreis']))+doubleval(str_replace(',', '.', $postfeld['vertrag_transport']))+$tax1w+$tax2w, 2, ',', '.'), $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<vkpreis_sum_br_total>>', number_format($preis_ges1+doubleval(str_replace(',', '.', $postfeld['listenpreis']))+(isset($postfeld['vertrag5_neben2'])?doubleval(str_replace(',', '.', $postfeld['vertrag5_neben2'])):0)+doubleval(str_replace(',', '.', $postfeld['vertrag_transport']))+$tax1w+$tax2w+doubleval(str_replace(',', '.', $postfeld['vertrag_zulassung'])), 2, ',', '.'), $inhalt);
		
		$neben_text1=$postfeld['neben_auswahl_text'];
		if (isset($postfeld['gwneben_auswahl_text'])) {
			if ($postfeld['gwneben_auswahl_text']!='' and $postfeld['gwneben_auswahl_text']!='-1') {
				$neben_text1=$postfeld['gwneben_auswahl_text'];
			}
		}
		$inhalt=p4n_sb_strreplace('<<nebenkosten_text>>', $neben_text1, $inhalt);
		$inhalt=p4n_sb_strreplace('<<nebenkosten>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_neben'])), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<nebenkostennetto>>', number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_neben']))*100/(100+(100*$cfg_mwst)), 2, ",", "."), $inhalt);
/*
beruf
vdet_filiale
vdet_zahlungsart
vdet_lieferdatum
bar_nebenleistung
bar_anzahlung
vdet_schaeden
gw_ankaufgw
gwmarke
gw_motornr
gw-typ
gw-fgnr
gw-preis
vdet_sonstiges
*/

		if (preg_match_all("/<<sv>>(.*)<<ev>>/Uis", $inhalt, $apblock, PREG_SET_ORDER)) {
			$block_k=$apblock[0][1];
		}

		if (preg_match_all("/<<sa>>(.*)<<ea>>/Uis", $inhalt, $apblock, PREG_SET_ORDER)) {
			$block_a=$apblock[0][1];
		}

		if ($fintext!='') {
			$inhalt=p4n_sb_strreplace(array('<<fin>>', '<<fin2>>'), '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<finanzierung>>', str_replace("\n", "\n".'\\par ', $fintext), $inhalt);
		} else {
			$inhalt=p4n_sb_preg_replace('/<<fin>>(.*)<<fin2>>/Uis', '', $inhalt);
		}

		// KFZ und Ausstattung:
		$gesamt_a='';
		$inhalt=p4n_sb_strreplace('<<fahrzeug>>', $pid_bez, $inhalt);
		if (preg_match_all('/( Ausstattung|Polster|Farbe)\s{2,}(\S{2,7})\s{2,}(.*)/i', $ausst, $matc)) {
/*			echo '<pre>';
			print_r($matc);
			echo '</pre>';
*/			while (list($akey, $aval)=@each($matc[1])) {
				$block=$block_a;
				$block=p4n_sb_strreplace('<<ausstattung_code>>', trim($aval).' '.trim($matc[2][$akey]), $block);
				$au_bez=trim($matc[3][$akey]);
				$au_bez=preg_replace('/\s{2,}/', ' ', $au_bez);
				$block=p4n_sb_strreplace('<<ausstattung_bezeichnung>>', $au_bez, $block);
				$gesamt_a.=$block;
			}
		}
		$inhalt=p4n_sb_preg_replace('/<<sa>>(.*)<<ea>>/Uis', $gesamt_a, $inhalt);

		$gesamt_k='';
        
//		$summe=doubleval($postfeld['pid_preis']);

		$block=$block_k;
		$block=p4n_sb_strreplace('<<anzahl>>', '1', $block);
		$block=p4n_sb_strreplace('<<bezeichnung>>', $pid_bez, $block);
		$summen=array();

		$preis3=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['pid_preis'])), 2, '.', ''));
		$block=p4n_sb_strreplace('<<preis3>>', number_format($preis3, 2, ",", "."), $block);
		$summen[3]+=$preis3;

		$preis2=doubleval(number_format($preis3-($preis3*100/119), 2, '.', ''));
		$block=p4n_sb_strreplace('<<preis2>>', number_format($preis2, 2, ",", "."), $block);
		$summen[2]+=$preis2;

		$preis1=$preis3-$preis2;
		$block=p4n_sb_strreplace('<<preis1>>', number_format($preis1, 2, ",", "."), $block);
		$summen[1]+=$preis1;

		$gesamt_k.=$block;
        if (!empty($postfeld['pos1'])) {
            @reset($postfeld['pos1']);
            while (list($key, $val)=@each($postfeld['pos1'])) {
                //$ltext.=$val' x '.$postfeld['pos2'][$key]."\t".number_format($betrag, 2, ",", ".")." \n";
                //$summe+=$betrag;

                if (trim($postfeld['pos2'][$key]!='')) {
                    $block=$block_k;
                    $betrag=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['pos3'][$key])), 2, '.', ''));
                    if (intval($val)==0) {
                        $val==1;
                    }
                    $block=p4n_sb_strreplace('<<anzahl>>', $val, $block);
                    $block=p4n_sb_strreplace('<<bezeichnung>>', $postfeld['pos2'][$key], $block);

                    $preis3=$betrag;
                    $block=p4n_sb_strreplace('<<preis3>>', number_format($preis3, 2, ",", "."), $block);
                    $summen[3]+=$preis3;

                    $preis2=doubleval(number_format($preis3-($preis3*100/119), 2, '.', ''));
                    $block=p4n_sb_strreplace('<<preis2>>', number_format($preis2, 2, ",", "."), $block);
                    $summen[2]+=$preis2;

                    $preis1=$preis3-$preis2;
                    $block=p4n_sb_strreplace('<<preis1>>', number_format($preis1, 2, ",", "."), $block);
                    $summen[1]+=$preis1;

                    $gesamt_k.=$block;
                }
            }
        }
        
		$inhalt=p4n_sb_strreplace('<<summe1>>', number_format(doubleval($summen[1]), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<summe2>>', number_format(doubleval($summen[2]), 2, ",", "."), $inhalt);
		$inhalt=p4n_sb_strreplace('<<summe3>>', number_format(doubleval($summen[3]), 2, ",", "."), $inhalt);

		$inhalt=p4n_sb_preg_replace('/<<sv>>(.*)<<ev>>/Uis', $gesamt_k, $inhalt);

		// Zusatzfelder
		if (preg_match_all('/<<zf(\d*)>>/Ui', $inhalt, $zfmat)) {
			$res5=$db->select(
				$sql_tab['zusatzfelder'],
				'*',
				$sql_tabs['zusatzfelder']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
			);
			$row5=$db->zeile($res5);
			while (list($zfkey, $zfval)=@each($zfmat[1])) {
				$zfwert='';
				if (isset($row5['zf_'.$zfval])) {
					$zfwert=$row5['zf_'.$zfval];
				}
				$inhalt=p4n_sb_strreplace($zfmat[0][$zfkey], $zfwert, $inhalt);
			}
		}

		// tech.Daten f�llen:
		$en_label_gef=false;
		$co2_label_gef=false;
		if ($cfg_kfzsuche_holland) {
			$res2=$db->select(
					$sql_tab['kfz_konfigurator_gme'],
					array(
						$sql_tabs['kfz_konfigurator_gme']['inhalt'],
						$sql_tabs['kfz_konfigurator_gme']['konfig_id']
					),
					$sql_tabs['kfz_konfigurator_gme']['kfz_konfigurator_gme_id'].'='.$db->dbzahl($postfeld['gme_konf_id'])
			);
			if ($row2=$db->zeile($res2)) {
				if (preg_match_all('/technicalValue\stype="(.*)">(.*)<\/technicalValue/Ui', str_replace(array('&lt;', '&gt;'), array('<', '>'), $row2[0]), $ma_td)) {
						while (list($key_td, $val_td)=@each($ma_td[1])) {
							$alle_techdaten[$val_td]=$ma_td[2][$key_td];
						}
				}
				while (list($keytd, $valtd)=@each($alle_techdaten)) {
					if ($keytd=='ENERGIELABEL' and $valtd!='') {
						$en_label_gef=true;
					}
					if ($keytd=='EMLIMIT' and $valtd!='') {
						$co2_label_gef=true;
					}
					$inhalt=p4n_sb_strreplace('<<'.$keytd.'>>', $valtd, $inhalt);
				}
			}
			if (!$en_label_gef) {
				$inhalt=p4n_sb_preg_replace('/<<energies>>.*<<energiee>>/Uis', '', $inhalt);
			}
			$inhalt=p4n_sb_strreplace(array('<<energies>>', '<<energiee>>'), '', $inhalt);
			if (!$co2_label_gef) {
				$inhalt=p4n_sb_preg_replace('/<<cos>>.*<<coe>>/Uis', '', $inhalt);
			}
			$inhalt=p4n_sb_strreplace(array('<<cos>>', '<<coe>>'), '', $inhalt);
		}
		
		if (isset($getfeld['leasdruck']) and isset($getfeld['lstid'])) {
			$res9=$db->select(
				$sql_tab['stammdaten'],
				array(
					$sql_tabs['stammdaten']['anzeigename'],
					$sql_tabs['stammdaten']['firma1'],
					$sql_tabs['stammdaten']['steuernummer']
				),
				$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($getfeld['lstid'])
			);
			$row9=$db->zeile($res9);
			$anzn=$row9[0];
			if ($anzn=='') {
				$anzn=$row9[1];
			}
			$res10=$db->select(
				$sql_tab['stammdaten_adresse'],
				array(
					$sql_tabs['stammdaten_adresse']['adresse'],
					$sql_tabs['stammdaten_adresse']['plz'],
					$sql_tabs['stammdaten_adresse']['ort']
				),
				$sql_tabs['stammdaten_adresse']['stammdaten_id'].'='.$db->dbzahl($getfeld['lstid'])
			);
			$row10=$db->zeile($res10);
			$inhalt=p4n_sb_strreplace('<<leasing_company_name>>', $anzn, $inhalt);
			$inhalt=p4n_sb_strreplace('<<leasing_company_address>>', $row10[0].', '.$row10[1].' '.$row10[2], $inhalt);
			$inhalt=p4n_sb_strreplace('<<leasing_company_steuernummer>>', $row9[2], $inhalt);
			$inhalt=p4n_sb_strreplace('<<start_leasingcompany>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<end_leasingcompany>>', '', $inhalt);
		} else {
			$inhalt=p4n_sb_preg_replace('/<<start_leasingcompany>>.*<<end_leasingcompany>>/Uis', '', $inhalt);
		}
		$inhalt=p4n_sb_strreplace('<<leasing_company_name>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<leasing_company_address>>', '', $inhalt);
		$inhalt=p4n_sb_strreplace('<<leasing_company_steuernummer>>', '', $inhalt);
		
		if ($profitdruck) {
			$res6=$db->select(
					$sql_tab['korrespondenz'],
					array(
						$sql_tabs['korrespondenz']['produktzuordnung_id'],
						$sql_tabs['korrespondenz']['stammdaten_id'],
						$sql_tabs['korrespondenz']['opportunity_id']
					),
					$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($postfeld['kbezug'])
			);
			if ($row6=$db->zeile($res6)) {
				$anr=$row6[2];
			}
			$inhalt=p4n_sb_strreplace('<<opp_id>>', $anr, $inhalt);
		}
		
		if (($cfg_kfzsuche_levy or $cfg_kfzsuche_gerding) and isset($postfeld['levy_standtage'])) {
			$inhalt=preg_replace('/<<standtage>>/', $postfeld['levy_standtage'], $inhalt);
		}
		$inhalt=preg_replace('/<<standtage>>/', intval($kfz_standt), $inhalt);
		
		
		if ($cfg_allianz_qr and $allianz_vers) {
				if (preg_match('/<<allianz_qr>>/Ui', $inhalt)) {
					if (is_file('inc/phpqrcode.php')) {
						include_once('inc/phpqrcode.php');
						$avs_uname='';
						$avs_encryption_key='';
						$avs_iv='';
						$avs_allelao=array();
    					$res2=$db->select(
    						$sql_tab['einstellungen'],
    						$sql_tabs['einstellungen']['wert'],
    						$sql_tabs['einstellungen']['modul'].'='.$db->str('AllianzQR')
    				    );
    					if ($row2=$db->zeile($res2)) {
    						$xpl1=explode(';;;', $row2[0]);
    						$avs_encryption_key=$xpl1[0];
    						$avs_iv=$xpl1[1];
    						$avs_allelao=unserialize(base64_decode($xpl1[2]));
    					}
						if (isset($avs_allelao[$postfeld['mvertrag_lagerort']])) {
							$avs_uname=$avs_allelao[$postfeld['mvertrag_lagerort']];
						}
						$avs_strasse='';
						$avs_hn='';
						$avs_strasse=$postfeld['adresse'];
						$avs_strasse=preg_replace('/(str\.)(\d)/i', '\\1 \\2', $avs_strasse);
	                    $spl_a=preg_split("/[\s]+/", $avs_strasse);
    	                if (count_p4n($spl_a)>=2) {
	                        $avs_hn=$spl_a[count_p4n($spl_a)-1];
                    	    if (is_numeric($spl_a[count_p4n($spl_a)-2])) {
                	            $avs_hn=$spl_a[count_p4n($spl_a)-2].' '.$avs_hn;
            	            }
        	                $avs_strasse=trim(p4n_mb_string('str_replace', $avs_hn, '', $avs_strasse));
	                    }
						$all_uebergabe='';
						if ($avs_uname!='' and $avs_encryption_key!='' and $avs_iv!='') {
							$all_uebergabe='1|'.$avs_uname.'|V|'.$postfeld['anrede'].'|'.$postfeld['titel'].'|'.$postfeld['vorname'].'|'.$postfeld['name'].'|'.substr($postfeld['geburtsdatum'], -4).'-'.substr($postfeld['geburtsdatum'], 3, 2).'-'.substr($postfeld['geburtsdatum'], 0, 2).'|'.$postfeld['plz'].'|'.$postfeld['ort'].'||'.$avs_strasse.'|'.$avs_hn.'||'.$postfeld['email'].'|'.$postfeld['kfz_hsn'].'|'.$postfeld['kfz_tsn'].'|'.substr($postfeld['kfz_datum_ez'], -4).'-'.substr($postfeld['kfz_datum_ez'], 3, 2).'-'.substr($postfeld['kfz_datum_ez'], 0, 2).'|'.intval($postfeld['kfz_kmstand']).'|L';
							$avs_toencode=openssl_encrypt(utf8_encode($all_uebergabe), 'aes-256-cbc', base64_decode($avs_encryption_key), OPENSSL_RAW_DATA, base64_decode($avs_iv));
							$linkqr='https://portal.avs-automotive.de/qr?code='.rtrim(strtr(base64_encode($avs_toencode), '+/', '-_'), '=');
							$linkqr='https://avs-de-portal-next.uat.cssteam.at/qr?code='.rtrim(strtr(base64_encode($avs_toencode), '+/', '-_'), '=');
							$linkqr='https://scansurance-next.uat.cssteam.at/qr?code='.rtrim(strtr(base64_encode($avs_toencode), '+/', '-_'), '=');
                            $linkqr='https://qcarcode.avs-automotive.de/qr?code='.rtrim(strtr(base64_encode($avs_toencode), '+/', '-_'), '=');
							// <version>|<AVS-username>|<AVS-vorgangstyp>|<anrede>|<title>|<vorname>|<nachname>|<geburtsdatum>|<plz>|<ort>|<ortzusatz>|<strasse>|<strassen-nr>|<adresszusatz>|<email>|<hsn>|<tsn>|<erstzulassungs-datum>|<km-stand>|<finanzierungsart>
							QRcode::jpg($linkqr, 'temp/_qr_'.$_SESSION['user_id'].'.jpg');
							$bildinh=file_get_contents('temp/_qr_'.$_SESSION['user_id'].'.jpg');
							$bildinh2=bin2hex($bildinh);
							$inhalt=p4n_sb_strreplace('<<allianz_qr>>', '{\\pict \\picscalex100\\picscaley100\\jpegblip '.$bildinh2.' } ', $inhalt);
                            if (isset($cfg_allianz_qr_text)) {
                                $inhalt=p4n_sb_strreplace('<<allianz_qr_text>>', $cfg_allianz_qr_text, $inhalt);
                            }
							unlink('temp/_qr_'.$_SESSION['user_id'].'.jpg');
						}
						$db->update(
							$sql_tab['opportunity'],
							array(
								$sql_tabs['opportunity']['zusatz12'] => $db->str($all_uebergabe)
							),
							$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
						);
					}
				}
		}
		if ($cfg_allianz_qr) {
			$inhalt=p4n_sb_strreplace('<<allianz_qr>>', '', $inhalt);
			$inhalt=p4n_sb_strreplace('<<allianz_qr_text>>', '', $inhalt);
		}
		
		if ($cfg_vvi2022_nurersterhaken) {
			if (isset($postfeld['vvi_1'])) {
				$postfeld['vvi_2']='1';
				$postfeld['vvi_3']='1';
			}
		}
		
		if ($bez_ang_kv=='Vorvertragsinformation') {
			$inhalt=sb_ersetzen('<<vvi_1>>', dse_rtf_wert(isset($postfeld['vvi_1'])), $inhalt);
			$inhalt=sb_ersetzen('<<vvi_2>>', dse_rtf_wert(isset($postfeld['vvi_2'])), $inhalt);
			$inhalt=sb_ersetzen('<<vvi_3>>', dse_rtf_wert(isset($postfeld['vvi_3'])), $inhalt);
			$inhalt=sb_ersetzen('<<vvi_4>>', dse_rtf_wert(isset($postfeld['vvi_4'])), $inhalt);
			$inhalt=sb_ersetzen('<<vvi_5>>', dse_rtf_wert(isset($postfeld['vvi_5'])), $inhalt);
			$inhalt=preg_replace('/<<vvi_maengeltext>>/', str_replace(array("\n", '<br>'), '\\par ', $postfeld['abweichung1']), $inhalt);
		}
		$inhalt=sb_ersetzen('<<kvvi_1>>', dse_rtf_wert(isset($postfeld['kvvi_1'])), $inhalt);
		$inhalt=sb_ersetzen('<<kvvi_2>>', dse_rtf_wert(isset($postfeld['kvvi_2'])), $inhalt);
		$inhalt=sb_ersetzen('<<kvvi_3>>', dse_rtf_wert(isset($postfeld['kvvi_3'])), $inhalt);
		$inhalt=sb_ersetzen('<<kvvi_4>>', dse_rtf_wert(isset($postfeld['kvvi_4'])), $inhalt);
		$inhalt=sb_ersetzen('<<kvvi_5>>', dse_rtf_wert(isset($postfeld['kvvi_5'])), $inhalt);
		$inhalt=preg_replace('/<<kvvi_maengeltext>>/', str_replace(array("\n", '<br>'), '\\par ', $postfeld['kabweichung1']), $inhalt);
		
		if (!isset($postfeld['kvvi_gewerbekunde'])) {
			$inhalt=p4n_sb_strreplace(array('<<startkvvi>>', '<<endekvvi>>'), '', $inhalt);
		} else {
			$inhalt=p4n_sb_preg_replace('/<<startkvvi>>.*<<endekvvi>>/Uis', '', $inhalt);
		}
		
		$m_ist_docx=$ist_docx;
		$ist_docx=false;
		
		$alle_zus_korr_doks=array();
		
		$vvi_doks_bez=array(
			1 => 'Abweichungen der Kaufsache von einzelnen objektiven Anforderungen',
			2 => 'Verk�rzung der Verj�hrungsfrist',
			3 => 'Ausschluss der gesetzlichen Aktualisierungspflicht',
			4 => 'Information des Verbrauchers �ber die Rechtsfolgen'
		);
		$anzahl_vvidoks=4;
		if ($cfg_vvi2022_nurersterhaken) {
			$anzahl_vvidoks=1;
			$vvi_doks_bez[1]='Abweichung / Verj�hrungsfrist / Aktualisierungspflicht';
		}
		
		for ($vviz=1; $vviz<=$anzahl_vvidoks; $vviz++) {
			if ($bez_ang_kv2=='kv' and isset($postfeld['kvvi_'.$vviz])) {
				$vvidok='inc/'.$_SESSION['cfg_kunde'].'/'.'vorlage_sachmangel_'.$vviz.'.rtf';
				$v_lao=$postfeld['mvertrag_lagerort'];
				$res3=$db->select(
					$sql_tab['mandant'],
					array(
						$sql_tabs['mandant']['bezeichnung'],
						$sql_tabs['mandant']['parent_id']
					),
					$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($v_lao)
				);
				if ($row3=$db->zeile($res3)) {
					$v_lao=trim($row3[0]);
				}
				$det_datei2=p4n_mb_string('substr',$vvidok, 0, -4).'_'.$v_lao.'.rtf';
				if (is_file($det_datei2)) {
					$vvidok=$det_datei2;
				}
				if (is_file($vvidok)) {
					$doclink_vviz='vvi'.$vviz.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'.rtf';
					$doclink_vviz=dok_korr_sp($doclink_vviz, 'vvi');
					$doclink_vviz2='dokumente_korrespondenz/'.$doclink_vviz;
					$doclink_vviz2_m=$doclink_vviz2;
					$vviinh=file_get_contents($vvidok);
					$vviinh=ersetze_nwgwbed_felder($vviinh);
					$vviinh=sb_ersetzen('<<kvvi_1>>', dse_rtf_wert(isset($postfeld['kvvi_1'])), $vviinh);
					$vviinh=sb_ersetzen('<<kvvi_2>>', dse_rtf_wert(isset($postfeld['kvvi_2'])), $vviinh);
					$vviinh=sb_ersetzen('<<kvvi_3>>', dse_rtf_wert(isset($postfeld['kvvi_3'])), $vviinh);
					$vviinh=sb_ersetzen('<<kvvi_4>>', dse_rtf_wert(isset($postfeld['kvvi_4'])), $vviinh);
					$vviinh=sb_ersetzen('<<kvvi_5>>', dse_rtf_wert(isset($postfeld['kvvi_5'])), $vviinh);
					$vviinh=preg_replace('/<<kvvi_maengeltext>>/', str_replace(array("\n", '<br>'), '\\par ', $postfeld['kabweichung1']), $vviinh);
					if ($fp=fopen($doclink_vviz2, 'w')) {
							fwrite($fp, $vviinh);
							fclose($fp);
					}
					if ($cfg_rtf2pdf) {
						$doclink_vviz2=check_rtf2pdf($doclink_vviz2, $cfg_rtf2pdf_sleep);
						if ($doclink_vviz2!=$doclink_vviz2_m) {
							$doclink_vviz=str_replace('.rtf', '.pdf', $doclink_vviz);
							$doclink_vviz2=str_replace('.rtf', '.pdf', $doclink_vviz2);
							$alle_pdfs[70+$vviz]=$doclink_vviz2;
						}
					}
					$alle_zus_korr_doks[$vvi_doks_bez[$vviz]]=$doclink_vviz;
					
					$weitere_kv[]=$doclink_vviz2;
					if (1==2 and $cfg_kfzsuche_pdf_join and substr($doclink_vviz2, -4)=='.pdf') {
						
					} else {
						echo javas('window.open("'.$doclink_vviz2.'", "_blank");');
					}
				}
			}
		}
		
		// Ankaufschein bei KV:
		if ($cfg_kfzsuche_ankaufschein and $bez_ang_kv==_KAUFVERTRAG_ and isset($postfeld['vertrags_ankauf'])) {
			$dok_gef=false;
			$inhalt2='';
			$det_datei3='';
			if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_ankauf.rtf')) {
				$det_datei3='inc/'.$_SESSION['cfg_kunde'].'/vorlage_ankauf.rtf';
				$dok_gef=true;
			} elseif (is_file('vorlagen/vorlage_ankauf.rtf')) {
				$det_datei3='vorlagen/vorlage_ankauf.rtf';
				$dok_gef=true;
			}
			if ($postfeld['vertrags_gwlagerort']!='') {
				$v_lao=$postfeld['vertrags_gwlagerort'];
				$v_lao2=0;
				$res3=$db->select(
					$sql_tab['mandant'],
					$sql_tabs['mandant']['bezeichnung'],
					$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($v_lao)
				);
				if ($row3=$db->zeile($res3)) {
					$v_lao=$row3[0];
					if (isset($dvs_lagerorte[$v_lao])) {
						$v_lao2=$dvs_lagerorte[$v_lao];
					}
				}
			}
			if (!$dok_gef) {
				$det_datei2='ankauf';
				$det_datei2.='_'.$v_lao;
				if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
					$det_datei3='inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf';
					$dok_gef=true;
				} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
					$det_datei3='vorlagen/vorlage_'.$det_datei2.'.rtf';
					$dok_gef=true;
				}
			}
			$felder=allefelder($det_datei3);
			if ($fp=fopen($det_datei3, 'r')) {
				$inhalt2=fread($fp, filesize($det_datei3));
				fclose($fp);
				$inhalt2=preg_replace('/\}\{\\\\f1\\\\fs20\\\\insrsid\d+ /', '', $inhalt2);
			}
			if ($inhalt2!='') {
				$inhalt2=vorlage_kdaten_ersetzen($inhalt2, $postfeld['firma1'], $postfeld['vorname'], $postfeld['name'], $postfeld['titel'], $postfeld['anrede'], $_SESSION['stammdaten_id'], $postfeld['firma3']);
				if (preg_match('/<<briefanrede>>/', $inhalt2)) {
					$inhalt2=preg_replace('/<<briefanrede>>.*<<mn>>.*,/Uis', _BRIEFANREDE_FIRMA_, $inhalt2);
				}
				$inhalt2=p4n_sb_strreplace('<<kunde>>', $anzeigename, $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<adresse>>', $postfeld['adresse'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<plz>>', $postfeld['plz'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<ort>>', $postfeld['ort'].$zus_ort_landinfo, $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<datum>>', adodb_date('d.m.Y'), $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<datumzeit>>', adodb_date('d.m.Y H:i'), $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<zeit>>', adodb_date('H:i'), $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<beruf>>', $postfeld['beruf'], $inhalt2);
				$anr1=$postfeld['anrede'];
				if ($anr1=='HERRN' or $anr1=='HERR' or $anr1=='FRAU' or $anr1=='FIRMA') {
					$anr1=p4n_mb_string('ucfirst',p4n_mb_string('strtolower',$anr1));
				}
				$inhalt2=p4n_sb_strreplace('<<anrede>>', $anr1, $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<vorname>>', $postfeld['vorname'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<name>>', $postfeld['name'], $inhalt2);
				if ($postfeld['firma1']!='') {
					if (!preg_match('/<<firma>>/i', $inhalt2)) {
						$inhalt2=p4n_sb_strreplace('<<vorname>> <<name>>', '<<firma>> <<vorname>> <<name>>', $inhalt2);
						if ($postfeld['name']=='' and $postfeld['vorname']=='') {
							$inhalt2=p4n_sb_strreplace('<<name>>, <<vorname>>', '<<firma>> <<name>> <<vorname>>', $inhalt2);
						} else {
							$inhalt2=p4n_sb_strreplace('<<name>>, <<vorname>>', '<<firma>> <<name>>, <<vorname>>', $inhalt2);
						}
					}
				}
				$inhalt2=p4n_sb_strreplace('<<firma>>', $postfeld['firma1'], $inhalt2);
				$std_tel=$postfeld['telefon'];
				if ($std_tel=='') {
					$std_tel=$postfeld['mobilfon'];
				}
				$inhalt2=p4n_sb_strreplace('<<tel1>>', $std_tel, $inhalt2);
				if ($cfg_kfzsuche_kontakt_pg) {
							if (!preg_match('/<<telefon2>>/', $inhalt2) and $postfeld['telefon2']!='' and $postfeld['telefon']=='') {
								$inhalt2=p4n_sb_strreplace('<<telefon1>>', $postfeld['telefon2'], $inhalt2);
							}
							$inhalt2=p4n_sb_strreplace('<<telefon2>>', $postfeld['telefon2'], $inhalt2);
							if (!preg_match('/<<mobil2>>/', $inhalt2) and $postfeld['mobilfon2']!='' and $postfeld['mobilfon']=='') {
								$inhalt2=p4n_sb_strreplace('<<mobil>>', $postfeld['mobilfon2'], $inhalt2);
							}
							$inhalt2=p4n_sb_strreplace('<<mobil2>>', $postfeld['mobilfon2'], $inhalt2);
							if (!preg_match('/<<email2>>/', $inhalt2) and $postfeld['email2']!='' and $postfeld['email']=='') {
								$inhalt2=p4n_sb_strreplace('<<email>>', $postfeld['email2'], $inhalt2);
							}
							$inhalt2=p4n_sb_strreplace('<<email2>>', $postfeld['email2'], $inhalt2);
							if (!preg_match('/<<fax2>>/', $inhalt2) and $postfeld['fax2']!='' and $postfeld['fax']=='') {
								$inhalt2=p4n_sb_strreplace('<<fax>>', $postfeld['fax2'], $inhalt2);
							}
							$inhalt2=p4n_sb_strreplace('<<fax2>>', $postfeld['fax2'], $inhalt2);
				}
				$inhalt2=p4n_sb_strreplace('<<telefon1>>', $postfeld['telefon'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<mob1>>', $postfeld['mobilfon'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<geb>>', $postfeld['geburtsdatum'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<geburtsort>>', $postfeld['geburtsort'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<mobil>>', $postfeld['mobilfon'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<email>>', $postfeld['email'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<fax>>', $postfeld['fax'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<kundennr>>', $kdnr1, $inhalt2);
				
				if (preg_match('/<<qrcode>>/Ui', $inhalt2)) {
					if (is_file('inc/phpqrcode.php') and isset($cfg_kfzsuche_qrcodelink)) {
						include_once('inc/phpqrcode.php');
						$linkqr=$cfg_kfzsuche_qrcodelink;
						$linkqr=str_replace('<<art>>', '67', $linkqr);
						$linkqr=str_replace('<<datum>>', adodb_date('dmY'), $linkqr);
						$linkqr=str_replace('<<fgnr>>', $postfeld['vertrags_gwfgnr'], $linkqr);
                        $linkqr=str_replace('<<lagerort>>', $lao1, $linkqr);
						$laobez2=substr($lao1, 1);
						$linkqr=str_replace('<<lagerort2>>', $laobez2, $linkqr);
						$linkqr=str_replace('<<lagerort3>>', $lao1zusatz1, $linkqr);
						$linkqr=str_replace('<<oppid>>', $anr, $linkqr);
						$linkqr=str_replace('<<duerkopmandant>>', $duerkopmand, $linkqr);
						$linkqr=str_replace('<<kundennr>>', $kdnr1, $linkqr);
						QRcode::jpg($linkqr, 'temp/_qr_'.$_SESSION['user_id'].'.jpg');
						$bildinh=file_get_contents('temp/_qr_'.$_SESSION['user_id'].'.jpg');
						$bildinh2=bin2hex($bildinh);
						$inhalt2=p4n_sb_strreplace('<<qrcode>>', '{\\pict \\picscalex100\\picscaley100\\jpegblip '.$bildinh2.' } ', $inhalt2);
						unlink('temp/_qr_'.$_SESSION['user_id'].'.jpg');
					}
				}
				
				if ($cfg_kfzsuche_liefertermin_datum) {
					$inhalt2=p4n_sb_strreplace('<<vdet_lieferdatum>>', $postfeld['vertrag_liefertermin'], $inhalt2);
				}
				$inhalt2=p4n_sb_strreplace('<<vdet_lieferdatum>>', $postfeld['vertrags_gwlieferung'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<mitarbeiter>>', $_SESSION['mitarbeiter_name'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<mitarbeiter_email>>', $_SESSION['user_email'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<mitarbeiter_telefon>>', $_SESSION['benutzer_tel'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<mitarbeiter_fax>>', $_SESSION['benutzer_fax'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<mitarbeiter_mobilfon>>', $_SESSION['benutzer_mob'], $inhalt2);
				
				// DAT:
				if (isset($postfeld['inz_auswahl'])) {
					$datdatei='import/dat/'.$_SESSION['user_id'].'---'.trim($postfeld['inz_auswahl']).'.szf';
					if (is_file($datdatei)) {
						if ($fp=fopen($datdatei, 'r')) {
							$dat_inh=fread($fp, filesize($datdatei));
							fclose($fp);
							lese_datdatei($dat_inh);
						}
					}
				}
				// Schwacke:
				if (isset($postfeld['schwacke_token'])) {
					if ($postfeld['schwacke_token']!='') {
						@reset($_SESSION['kfzsuche_snet']);
						while (list($keyan, $valan)=@each($_SESSION['kfzsuche_snet'])) {
							$postfeld[$keyan]=$valan;
						}
						if (isset($postfeld['ankauf_taxtype'])) {
							if ($postfeld['ankauf_taxtype']=='D') {
								$postfeld['preis']=number_format(doubleval(str_replace(',', '.', $postfeld['ankauf_kalkpreis'])), 2, ",", ".");
								$postfeld['preis_netto']='';
								$postfeld['preis_brutto']='';
								$postfeld['preis_steuer']='';
							} else {
								$postfeld['preis']='';
								$proz=19;
								if (isset($postfeld['ankauf_taxwert'])) {
									$proz=doubleval($postfeld['ankauf_taxwert']);
								}
								$steuer=number_format(doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['ankauf_kalkpreis'])), 2, ".", ""))*$proz/100 , 2, ".", "");
								$netto=doubleval(number_format(doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['ankauf_kalkpreis'])), 2, ".", ""))-$steuer, 2, ".", ""));
								$postfeld['preis_netto']=number_format($netto, 2, ",", ".");
								$postfeld['preis_brutto']=number_format(doubleval(str_replace(',', '.', $postfeld['ankauf_kalkpreis'])), 2, ",", ".");
								$postfeld['preis_steuer']=number_format(doubleval($steuer), 2, ",", ".");
							}
						}
					}
				}
				
				$inhalt2=p4n_sb_strreplace('<<preis>>', $postfeld['preis'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<preis_netto>>', $postfeld['preis_netto'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<preis_brutto>>', $postfeld['preis_brutto'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<preis_steuer>>', $postfeld['preis_steuer'], $inhalt2);
				
				$inhalt2=p4n_sb_strreplace('<<markencode>>', $postfeld['vertrags_gwmarke'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<typ>>', $postfeld['vertrags_gwtyp'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<fahrgestellnummer>>', $postfeld['vertrags_gwfgnr'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<kennzeichen>>', $postfeld['vertrags_kennz'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<briefnummer>>', $postfeld['briefnummer'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<datum_hu>>', $postfeld['ankauf_hu'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<datum_au>>', $postfeld['ankauf_au'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<art>>', $postfeld['ankauf_art'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<hrm2>>', $postfeld['ankauf_hrm'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<kw>>', $postfeld['ankauf_kw'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<halter>>', $postfeld['ankauf_halter'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<km>>', $postfeld['ankauf_km'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<km2>>', $postfeld['ankauf_km2'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<datum_ez>>', $postfeld['ankauf_ez'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<farbe>>', $postfeld['ankauf_farbe'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<gesamtgewicht>>', $postfeld['ankauf_gesamtgewicht'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<tueren>>', $postfeld['ankauf_tueren'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<motor>>', $postfeld['ankauf_motor'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<typ_schluessel>>', $postfeld['ankauf_typ_schluessel'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<vdet_taxi_satz>>', $postfeld['ankauf_taxi'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<versicherung>>', $postfeld['ankauf_versicherung'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<versicherungsnummer>>', $postfeld['ankauf_versicherungsnummer'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<v_sb1>>', $postfeld['ankauf_v_sb1'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<v_sb2>>', $postfeld['ankauf_v_sb2'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<vers_bez>>', $postfeld['ankauf_vers_bez'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<unfall>>', $postfeld['ankauf_unfall'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<ausstattung2>>', $postfeld['ankauf_ausstattung2'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<sonstiges>>', $postfeld['ankauf_sonstiges'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<datum>>', $postfeld['ankauf_datum'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<km3>>', $postfeld['ankauf_km3'], $inhalt2);
				$inhalt2=p4n_sb_strreplace('<<lieferdatum>>', $postfeld['vertrags_gwlieferung'], $inhalt2);
				if ($tradein_erw_felder) {
					$inhalt2=p4n_sb_strreplace('<<vertrags_gwmotornr>>', $postfeld['vertrags_gwmotornr'], $inhalt2);
					$inhalt2=p4n_sb_strreplace('<<vertrags_gwhubraum>>', $postfeld['vertrags_gwhubraum'], $inhalt2);
					$inhalt2=p4n_sb_strreplace('<<vertrags_gwleistungps>>', $postfeld['vertrags_gwleistungps'], $inhalt2);
					$inhalt2=p4n_sb_strreplace('<<vertrags_gwleistungkw>>', $postfeld['vertrags_gwleistungkw'], $inhalt2);
					$inhalt2=p4n_sb_strreplace('<<vertrags_gwanzahlbesitzer>>', $postfeld['vertrags_gwanzahlbesitzer'], $inhalt2);
					$inhalt2=p4n_sb_strreplace('<<vertrags_gwlackfarbe>>', $postfeld['vertrags_gwlackfarbe'], $inhalt2);
					$inhalt2=p4n_sb_strreplace('<<vertrags_gwanzahltueren>>', $postfeld['vertrags_gwanzahltueren'], $inhalt2);
					$inhalt2=p4n_sb_strreplace('<<vertrags_gwnatcode>>', $postfeld['vertrags_gwnatcode'], $inhalt2);
				}
			}
		}
		
		$inhalt4='';
		$dok_gef=false;
		if ($postfeld['vertrag_nwgw']!='1' and isset($postfeld['vertrag_fernabsatz_nw'])) {
			if (is_file('inc/'.$_SESSION['cfg_kunde'].'/widerrufsbelehrung_nw.rtf')) {
					$det_datei4='inc/'.$_SESSION['cfg_kunde'].'/widerrufsbelehrung_nw.rtf';
					$dok_gef=true;
			} elseif (is_file('vorlagen/widerrufsbelehrung_nw.rtf')) {
					$det_datei4='vorlagen/widerrufsbelehrung_nw.rtf';
					$dok_gef=true;
			}
		} elseif (isset($postfeld['vertrag_fernabsatz'])) {
			$det_datei4='';
			if (isset($postfeld['vorlage_zus'])) {
				$det_datei2='widerrufsbelehrung';
				$det_datei2.='_'.p4n_mb_string('strtolower',trim($postfeld['vorlage_zus']));
				if (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.rtf')) {
					$det_datei4='inc/'.$_SESSION['cfg_kunde'].'/'.$det_datei2.'.rtf';
					$dok_gef=true;
				} elseif (is_file('vorlagen/'.$det_datei2.'.rtf')) {
					$det_datei4='vorlagen/'.$det_datei2.'.rtf';
					$dok_gef=true;
				}
			}
			if (!$dok_gef) {
				if (is_file('inc/'.$_SESSION['cfg_kunde'].'/widerrufsbelehrung.rtf')) {
					$det_datei4='inc/'.$_SESSION['cfg_kunde'].'/widerrufsbelehrung.rtf';
					$dok_gef=true;
				} elseif (is_file('vorlagen/widerrufsbelehrung.rtf')) {
					$det_datei4='vorlagen/widerrufsbelehrung.rtf';
					$dok_gef=true;
				}
			}
		}
		if ($dok_gef) {
			$felder=allefelder($det_datei4);
			if ($fp=fopen($det_datei4, 'r')) {
				$inhalt4=fread($fp, filesize($det_datei4));
				fclose($fp);
				$inhalt4=preg_replace('/\}\{\\\\f1\\\\fs20\\\\insrsid\d+ /', '', $inhalt4);
			}
			if ($inhalt4!='') {
				$inhalt4=vorlage_kdaten_ersetzen($inhalt4, $postfeld['firma1'], $postfeld['vorname'], $postfeld['name'], $postfeld['titel'], $postfeld['anrede'], $_SESSION['stammdaten_id'], $postfeld['firma3']);
				$inhalt4=p4n_sb_strreplace('<<kunde>>', $anzeigename, $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<adresse>>', $postfeld['adresse'], $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<plz>>', $postfeld['plz'], $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<ort>>', $postfeld['ort'].$zus_ort_landinfo, $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<datum>>', adodb_date('d.m.Y'), $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<datumzeit>>', adodb_date('d.m.Y H:i'), $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<zeit>>', adodb_date('H:i'), $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<beruf>>', $postfeld['beruf'], $inhalt4);
				$anr1=$postfeld['anrede'];
				if ($anr1=='HERRN' or $anr1=='HERR' or $anr1=='FRAU' or $anr1=='FIRMA') {
					$anr1=p4n_mb_string('ucfirst',p4n_mb_string('strtolower',$anr1));
				}
				$inhalt4=p4n_sb_strreplace('<<anrede>>', $anr1, $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<vorname>>', $postfeld['vorname'], $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<name>>', $postfeld['name'], $inhalt4);
				if ($postfeld['firma1']!='') {
					if (!preg_match('/<<firma>>/i', $inhalt4)) {
						$inhalt4=p4n_sb_strreplace('<<vorname>> <<name>>', '<<firma>> <<vorname>> <<name>>', $inhalt4);
						if ($postfeld['name']=='' and $postfeld['vorname']=='') {
							$inhalt4=p4n_sb_strreplace('<<name>>, <<vorname>>', '<<firma>> <<name>> <<vorname>>', $inhalt4);
						} else {
							$inhalt4=p4n_sb_strreplace('<<name>>, <<vorname>>', '<<firma>> <<name>>, <<vorname>>', $inhalt4);
						}
					}
				}
				$inhalt4=p4n_sb_strreplace('<<firma>>', $postfeld['firma1'], $inhalt4);
				$std_tel=$postfeld['telefon'];
				if ($std_tel=='') {
					$std_tel=$postfeld['mobilfon'];
				}
				$inhalt4=p4n_sb_strreplace('<<tel1>>', $std_tel, $inhalt4);
				if ($cfg_kfzsuche_kontakt_pg) {
							if (!preg_match('/<<telefon2>>/', $inhalt4) and $postfeld['telefon2']!='' and $postfeld['telefon']=='') {
								$inhalt4=p4n_sb_strreplace('<<telefon1>>', $postfeld['telefon2'], $inhalt4);
							}
							$inhalt4=p4n_sb_strreplace('<<telefon2>>', $postfeld['telefon2'], $inhalt4);
							if (!preg_match('/<<mobil2>>/', $inhalt4) and $postfeld['mobilfon2']!='' and $postfeld['mobilfon']=='') {
								$inhalt4=p4n_sb_strreplace('<<mobil>>', $postfeld['mobilfon2'], $inhalt4);
							}
							$inhalt4=p4n_sb_strreplace('<<mobil2>>', $postfeld['mobilfon2'], $inhalt4);
							if (!preg_match('/<<email2>>/', $inhalt4) and $postfeld['email2']!='' and $postfeld['email']=='') {
								$inhalt4=p4n_sb_strreplace('<<email>>', $postfeld['email2'], $inhalt4);
							}
							$inhalt4=p4n_sb_strreplace('<<email2>>', $postfeld['email2'], $inhalt4);
							if (!preg_match('/<<fax2>>/', $inhalt4) and $postfeld['fax2']!='' and $postfeld['fax']=='') {
								$inhalt4=p4n_sb_strreplace('<<fax>>', $postfeld['fax2'], $inhalt4);
							}
							$inhalt4=p4n_sb_strreplace('<<fax2>>', $postfeld['fax2'], $inhalt4);
				}
				$inhalt4=p4n_sb_strreplace('<<telefon1>>', $postfeld['telefon'], $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<mob1>>', $postfeld['mobilfon'], $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<geb>>', $postfeld['geburtsdatum'], $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<geburtsort>>', $postfeld['geburtsort'], $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<mobil>>', $postfeld['mobilfon'], $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<email>>', $postfeld['email'], $inhalt4);
				$inhalt4=p4n_sb_strreplace('<<kundennr>>', $kdnr1, $inhalt4);

				$inhalt4=p4n_sb_strreplace('<<datum>>', adodb_date('d.m.Y'), $inhalt4);
			}
		}
		
		// KV Sanktionsabfrage DBRent:
		if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent' and $bez_ang_kv==_KAUFVERTRAG_ and ($postfeld['name']!='' or $postfeld['firma1']!='')) {
			$dok_gef=false;
			$inhalt9='';
			$det_datei3='';
			if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_sanktion.rtf')) {
				$det_datei3='inc/'.$_SESSION['cfg_kunde'].'/vorlage_sanktion.rtf';
				$dok_gef=true;
			} elseif (is_file('vorlagen/vorlage_sanktion.rtf')) {
				$det_datei3='vorlagen/vorlage_sanktion.rtf';
				$dok_gef=true;
			}
			if ($postfeld['vertrags_gwlagerort']!='') {
				$v_lao=$postfeld['vertrags_gwlagerort'];
				$v_lao2=0;
				$res3=$db->select(
					$sql_tab['mandant'],
					$sql_tabs['mandant']['bezeichnung'],
					$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($v_lao)
				);
				if ($row3=$db->zeile($res3)) {
					$v_lao=$row3[0];
					if (isset($dvs_lagerorte[$v_lao])) {
						$v_lao2=$dvs_lagerorte[$v_lao];
					}
				}
			}
			if (!$dok_gef) {
				$det_datei2='sanktion';
				$det_datei2.='_'.$v_lao;
				if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf')) {
					$det_datei3='inc/'.$_SESSION['cfg_kunde'].'/vorlage_'.$det_datei2.'.rtf';
					$dok_gef=true;
				} elseif (is_file('vorlagen/vorlage_'.$det_datei2.'.rtf')) {
					$det_datei3='vorlagen/vorlage_'.$det_datei2.'.rtf';
					$dok_gef=true;
				}
			}
			$felder=allefelder($det_datei3);
			if ($fp=fopen($det_datei3, 'r')) {
				$inhalt9=fread($fp, filesize($det_datei3));
				fclose($fp);
				$inhalt9=preg_replace('/\}\{\\\\f1\\\\fs20\\\\insrsid\d+ /', '', $inhalt9);
			}
			if ($inhalt9!='') {
				$sankt_name=$postfeld['vorname'].' '.$postfeld['name'];
				if ($postfeld['firma1']!='') {
					$sankt_name=$postfeld['firma1'];
				}
				
				$xmlsank='<?xml version="1.0" encoding="UTF-8"
standalone="yes"?><MatchRequest
xmlns="http://sanctionlists.schenker.com/1.0"
requestId="12345"><Address id="TEST01"><Name>'.utf8_encode(trim($sankt_name)).'</Name><Street>'.utf8_encode($postfeld['adresse']).'</Street><City>'.utf8_encode($postfeld['ort']).'</City><ZipCode>'.utf8_encode($postfeld['plz']).'</ZipCode><CountryCode>D
E</CountryCode></Address></MatchRequest>';
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, 'https://dbsankt-app1.ico.comp.db.de/api');	// alt: http://sanctionlist.dc.signintra.com/api
				curl_setopt($ch, CURLOPT_PROXY, '10.35.171.29:3128');
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
				curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0); 
				curl_setopt($ch, CURLOPT_TIMEOUT, 120);
				curl_setopt($ch,CURLOPT_POST, true);
				curl_setopt($ch,CURLOPT_POSTFIELDS, $xmlsank);
				curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: application/xml', 'Content-Type: application/xml'));
curl_setopt($ch, CURLOPT_VERBOSE, true);
				$verbose = fopen('php://temp', 'w+');
				curl_setopt($ch, CURLOPT_STDERR, $verbose);
				$data = curl_exec($ch);
				rewind($verbose);
				$verboseLog = stream_get_contents($verbose);
				$error_no = curl_errno($ch);
				if ($fpsank=fopen('_log_sanktion.txt', 'a')) {
					fwrite($fpsank, adodb_date('d.m.Y H:i:s', time()).': '.$error_no.' / '.$xmlsank.' / '.$verboseLog.' / '.$data."\r\n\r\n\r\n");
					fclose($fpsank);
				}
				curl_close($ch);
				$return=simplexml_load_string($data);
				$return3=json_decode(json_encode((array) $return), 1);
				
				$sankt_erg='';
				$sankt_beschr='';
				$tri=0;
				
				$sa_zeile='';
				$sa_zeileg='';
				if (preg_match('/<<start_s>>(.*)<<ende_s>>/Uis', $inhalt9, $ma)) {
					$sa_zeile=$ma[1];
					$sa_zeileg=$ma[0];
				}
				
				if (isset($return3['Entry'])) {
					$sank_werte=$return3['Entry'];
					if (isset($return3['Entry']['NameEntry'])) {
						$sank_werte=array(0 => $return3['Entry']);
					}
					$zeilet=$sa_zeile;
					$alle_szeilen='';
					while (list($keye, $vale)=@each($sank_werte)) {
						$s_id=$vale['@attributes']['entryId'];
						$s_gueltigab=$vale['@attributes']['validFrom'];
						$s_gueltigab=substr($s_gueltigab, 6, 2).'.'.substr($s_gueltigab, 4, 2).'.'.substr($s_gueltigab, 0, 4);
						$s_source=$vale['Source'];
						
						$s_namen='';
						$sank_namen=$vale['NameEntry'];
						if (isset($vale['NameEntry']['Name'])) {
							$sank_namen=array(0 => $vale['NameEntry']);
						}
						while (list($keye2, $vale2)=@each($sank_namen)) {
							$s_name=p4n_mb_string('utf8_decode', $vale2['Name']);
							$s_comment=p4n_mb_string('utf8_decode', $vale2['CommentGerman']);
							if (isset($vale2['Comment'])) {
								$s_comment.=' '.p4n_mb_string('utf8_decode', $vale2['Comment']);
							}
							$s_namen.=$s_name.': '.trim($s_comment)."\n";
						}
						$s_namen=substr($s_namen, 0, -1);
						
						$s_adresse='';
						$sank_adr=$vale['AddressEntry'];
						if (isset($vale['AddressEntry']['Street'])) {
							$sank_adr=array(0 => $vale['AddressEntry']);
						}
						while (list($keye2, $vale2)=@each($sank_adr)) {
							$s_adresse.=p4n_mb_string('utf8_decode', $vale2['Street'].' '.$vale2['HouseNumber'].', '.$vale2['ZipCode'].' '.$vale2['City'].', '.$vale2['CountryCode']).'; ';
						}
						$s_adresse=substr($s_adresse, 0, -2);
						
						$zeilet=$sa_zeile;
						$zeilet=p4n_sb_strreplace('<<sid>>', $s_id, $zeilet);
						$zeilet=p4n_sb_strreplace('<<sdatum>>', $s_gueltigab, $zeilet);
						$zeilet=p4n_sb_strreplace('<<sname>>', $s_namen, $zeilet);
						$zeilet=p4n_sb_strreplace('<<sadresse>>', $s_adresse, $zeilet);
						$zeilet=p4n_sb_strreplace('<<squelle>>', $s_source, $zeilet);
						$alle_szeilen.=$zeilet;
						
						$tri++;
						$sankt_beschr.=$s_id.':'."\r".'G�ltig ab: '.$s_gueltigab."\r".'Quelle: '.$s_source."\r".'Namen:'.$s_namen."\r".'Adresse: '.$s_adresse."\r\r";
						$sankt_beschr=substr($sankt_beschr, 0, -2);
					//	echo $s_id.':<br>'.$s_gueltigab.'/'.$s_source.'/'.nl2br($s_namen).'/'.$s_adresse.'<br><br>';
					}
					$sankt_erg=$tri.' Treffer';
				} else {
					$sankt_erg='keine Treffer';
					$sankt_beschr='keine Treffer';
					// No Match
					$zeilet=$sa_zeile;
					$zeilet=p4n_sb_strreplace('<<sid>>', 'kein Treffer', $zeilet);
					$zeilet=p4n_sb_strreplace('<<sdatum>>', '-', $zeilet);
					$zeilet=p4n_sb_strreplace('<<sname>>', '-', $zeilet);
					$zeilet=p4n_sb_strreplace('<<sadresse>>', '-', $zeilet);
					$zeilet=p4n_sb_strreplace('<<squelle>>', '-', $zeilet);
					$alle_szeilen.=$zeilet;
				}
				
				if ($alle_szeilen!='') {
					$inhalt9=p4n_sb_strreplace($sa_zeileg, $alle_szeilen, $inhalt9);
					$inhalt9=p4n_sb_strreplace(array('<<start_s>>', '<<ende_s>>'), '', $inhalt9);
				} else {
					$inhalt9=p4n_sb_preg_replace('/<<start_s>>.*<<ende_s>>/Uis', '', $inhalt9);
				}
				
				$inhalt9=vorlage_kdaten_ersetzen($inhalt9, $postfeld['firma1'], $postfeld['vorname'], $postfeld['name'], $postfeld['titel'], $postfeld['anrede'], $_SESSION['stammdaten_id'], $postfeld['firma3']);
				if (preg_match('/<<briefanrede>>/', $inhalt9)) {
					$inhalt9=preg_replace('/<<briefanrede>>.*<<mn>>.*,/Uis', _BRIEFANREDE_FIRMA_, $inhalt9);
				}
				$inhalt9=p4n_sb_strreplace('<<kunde>>', $anzeigename, $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<adresse>>', $postfeld['adresse'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<plz>>', $postfeld['plz'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<ort>>', $postfeld['ort'].$zus_ort_landinfo, $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<datum>>', adodb_date('d.m.Y'), $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<datumzeit>>', adodb_date('d.m.Y H:i'), $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<zeit>>', adodb_date('H:i'), $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<beruf>>', $postfeld['beruf'], $inhalt9);
				$anr1=$postfeld['anrede'];
				if ($anr1=='HERRN' or $anr1=='HERR' or $anr1=='FRAU' or $anr1=='FIRMA') {
					$anr1=p4n_mb_string('ucfirst',p4n_mb_string('strtolower',$anr1));
				}
				$inhalt9=p4n_sb_strreplace('<<anrede>>', $anr1, $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<vorname>>', $postfeld['vorname'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<name>>', $postfeld['name'], $inhalt9);
				if ($postfeld['firma1']!='') {
					if (!preg_match('/<<firma>>/i', $inhalt9)) {
						$inhalt9=p4n_sb_strreplace('<<vorname>> <<name>>', '<<firma>> <<vorname>> <<name>>', $inhalt9);
						if ($postfeld['name']=='' and $postfeld['vorname']=='') {
							$inhalt9=p4n_sb_strreplace('<<name>>, <<vorname>>', '<<firma>> <<name>> <<vorname>>', $inhalt9);
						} else {
							$inhalt9=p4n_sb_strreplace('<<name>>, <<vorname>>', '<<firma>> <<name>>, <<vorname>>', $inhalt9);
						}
					}
				}
				$inhalt9=p4n_sb_strreplace('<<firma>>', $postfeld['firma1'], $inhalt9);
				$std_tel=$postfeld['telefon'];
				if ($std_tel=='') {
					$std_tel=$postfeld['mobilfon'];
				}
				$inhalt9=p4n_sb_strreplace('<<tel1>>', $std_tel, $inhalt9);
				if ($cfg_kfzsuche_kontakt_pg) {
							if (!preg_match('/<<telefon2>>/', $inhalt9) and $postfeld['telefon2']!='' and $postfeld['telefon']=='') {
								$inhalt9=p4n_sb_strreplace('<<telefon1>>', $postfeld['telefon2'], $inhalt9);
							}
							$inhalt9=p4n_sb_strreplace('<<telefon2>>', $postfeld['telefon2'], $inhalt9);
							if (!preg_match('/<<mobil2>>/', $inhalt9) and $postfeld['mobilfon2']!='' and $postfeld['mobilfon']=='') {
								$inhalt9=p4n_sb_strreplace('<<mobil>>', $postfeld['mobilfon2'], $inhalt9);
							}
							$inhalt9=p4n_sb_strreplace('<<mobil2>>', $postfeld['mobilfon2'], $inhalt9);
							if (!preg_match('/<<email2>>/', $inhalt9) and $postfeld['email2']!='' and $postfeld['email']=='') {
								$inhalt9=p4n_sb_strreplace('<<email>>', $postfeld['email2'], $inhalt9);
							}
							$inhalt9=p4n_sb_strreplace('<<email2>>', $postfeld['email2'], $inhalt9);
							if (!preg_match('/<<fax2>>/', $inhalt9) and $postfeld['fax2']!='' and $postfeld['fax']=='') {
								$inhalt9=p4n_sb_strreplace('<<fax>>', $postfeld['fax2'], $inhalt9);
							}
							$inhalt9=p4n_sb_strreplace('<<fax2>>', $postfeld['fax2'], $inhalt9);
				}
				$inhalt9=p4n_sb_strreplace('<<telefon1>>', $postfeld['telefon'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<mob1>>', $postfeld['mobilfon'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<geb>>', $postfeld['geburtsdatum'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<geburtsort>>', $postfeld['geburtsort'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<mobil>>', $postfeld['mobilfon'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<email>>', $postfeld['email'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<fax>>', $postfeld['fax'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<kundennr>>', $kdnr1, $inhalt9);
				
				if ($cfg_kfzsuche_liefertermin_datum) {
					$inhalt9=p4n_sb_strreplace('<<vdet_lieferdatum>>', $postfeld['vertrag_liefertermin'], $inhalt9);
				}
				$inhalt9=p4n_sb_strreplace('<<vdet_lieferdatum>>', $postfeld['vertrags_gwlieferung'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<mitarbeiter>>', $_SESSION['mitarbeiter_name'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<mitarbeiter_email>>', $_SESSION['user_email'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<mitarbeiter_telefon>>', $_SESSION['benutzer_tel'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<mitarbeiter_fax>>', $_SESSION['benutzer_fax'], $inhalt9);
				$inhalt9=p4n_sb_strreplace('<<mitarbeiter_mobilfon>>', $_SESSION['benutzer_mob'], $inhalt9);
				
				
			}
		}
		
		// KV Embargo ungleich Deutschland:
		if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent' and $bez_ang_kv==_KAUFVERTRAG_) {
			
			$dbland='';
			$res2=$db->select(
				$sql_tab['stammdaten_adresse'],
				array(
					$sql_tabs['stammdaten_adresse']['land']
				),
				$sql_tabs['stammdaten_adresse']['stammdaten_id'].'='.$db->dbzahl($postfeld['stid'])
			);
			if ($row2=$db->zeile($res2)) {
				$dbland=$row2[0];
			}
			if ($dbland!='Deutschland') {
				$dok_gef=false;
				$inhalt11='';
				$det_datei3='';
				if (is_file('inc/'.$_SESSION['cfg_kunde'].'/vorlage_embargo.rtf')) {
					$det_datei3='inc/'.$_SESSION['cfg_kunde'].'/vorlage_embargo.rtf';
					$dok_gef=true;
				} elseif (is_file('vorlagen/vorlage_embargo.rtf')) {
					$det_datei3='vorlagen/vorlage_embargo.rtf';
					$dok_gef=true;
				}
				if ($dok_gef) {
					$felder=allefelder($det_datei3);
					if ($fp=fopen($det_datei3, 'r')) {
						$inhalt11=fread($fp, filesize($det_datei3));
						fclose($fp);
						$inhalt11=preg_replace('/\}\{\\\\f1\\\\fs20\\\\insrsid\d+ /', '', $inhalt11);
					}
					if ($inhalt11!='') {
						$inhalt11=vorlage_kdaten_ersetzen($inhalt11, $postfeld['firma1'], $postfeld['vorname'], $postfeld['name'], $postfeld['titel'], $postfeld['anrede'], $_SESSION['stammdaten_id'], $postfeld['firma3']);
						if (preg_match('/<<briefanrede>>/', $inhalt11)) {
							$inhalt11=preg_replace('/<<briefanrede>>.*<<mn>>.*,/Uis', _BRIEFANREDE_FIRMA_, $inhalt11);
						}
						$inhalt11=p4n_sb_strreplace('<<kunde>>', $anzeigename, $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<adresse>>', $postfeld['adresse'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<plz>>', $postfeld['plz'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<ort>>', $postfeld['ort'].$zus_ort_landinfo, $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<datum>>', adodb_date('d.m.Y'), $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<datumzeit>>', adodb_date('d.m.Y H:i'), $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<zeit>>', adodb_date('H:i'), $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<beruf>>', $postfeld['beruf'], $inhalt11);
						$anr1=$postfeld['anrede'];
						if ($anr1=='HERRN' or $anr1=='HERR' or $anr1=='FRAU' or $anr1=='FIRMA') {
							$anr1=p4n_mb_string('ucfirst',p4n_mb_string('strtolower',$anr1));
						}
						$inhalt11=p4n_sb_strreplace('<<anrede>>', $anr1, $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<vorname>>', $postfeld['vorname'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<name>>', $postfeld['name'], $inhalt11);
						if ($postfeld['firma1']!='') {
							if (!preg_match('/<<firma>>/i', $inhalt11)) {
								$inhalt11=p4n_sb_strreplace('<<vorname>> <<name>>', '<<firma>> <<vorname>> <<name>>', $inhalt11);
								if ($postfeld['name']=='' and $postfeld['vorname']=='') {
									$inhalt11=p4n_sb_strreplace('<<name>>, <<vorname>>', '<<firma>> <<name>> <<vorname>>', $inhalt11);
								} else {
									$inhalt11=p4n_sb_strreplace('<<name>>, <<vorname>>', '<<firma>> <<name>>, <<vorname>>', $inhalt11);
								}
							}
						}
						$inhalt11=p4n_sb_strreplace('<<firma>>', $postfeld['firma1'], $inhalt11);
						$std_tel=$postfeld['telefon'];
						if ($std_tel=='') {
							$std_tel=$postfeld['mobilfon'];
						}
						$inhalt11=p4n_sb_strreplace('<<tel1>>', $std_tel, $inhalt11);
						if ($cfg_kfzsuche_kontakt_pg) {
							if (!preg_match('/<<telefon2>>/', $inhalt11) and $postfeld['telefon2']!='' and $postfeld['telefon']=='') {
								$inhalt11=p4n_sb_strreplace('<<telefon1>>', $postfeld['telefon2'], $inhalt11);
							}
							$inhalt11=p4n_sb_strreplace('<<telefon2>>', $postfeld['telefon2'], $inhalt11);
							if (!preg_match('/<<mobil2>>/', $inhalt11) and $postfeld['mobilfon2']!='' and $postfeld['mobilfon']=='') {
								$inhalt11=p4n_sb_strreplace('<<mobil>>', $postfeld['mobilfon2'], $inhalt11);
							}
							$inhalt11=p4n_sb_strreplace('<<mobil2>>', $postfeld['mobilfon2'], $inhalt11);
							if (!preg_match('/<<email2>>/', $inhalt11) and $postfeld['email2']!='' and $postfeld['email']=='') {
								$inhalt11=p4n_sb_strreplace('<<email>>', $postfeld['email2'], $inhalt11);
							}
							$inhalt11=p4n_sb_strreplace('<<email2>>', $postfeld['email2'], $inhalt11);
							if (!preg_match('/<<fax2>>/', $inhalt11) and $postfeld['fax2']!='' and $postfeld['fax']=='') {
								$inhalt11=p4n_sb_strreplace('<<fax>>', $postfeld['fax2'], $inhalt11);
							}
							$inhalt11=p4n_sb_strreplace('<<fax2>>', $postfeld['fax2'], $inhalt11);
						}
						$inhalt11=p4n_sb_strreplace('<<telefon1>>', $postfeld['telefon'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<mob1>>', $postfeld['mobilfon'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<geb>>', $postfeld['geburtsdatum'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<geburtsort>>', $postfeld['geburtsort'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<mobil>>', $postfeld['mobilfon'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<email>>', $postfeld['email'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<fax>>', $postfeld['fax'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<kundennr>>', $kdnr1, $inhalt11);
						
						if ($cfg_kfzsuche_liefertermin_datum) {
							$inhalt11=p4n_sb_strreplace('<<vdet_lieferdatum>>', $postfeld['vertrag_liefertermin'], $inhalt11);
						}
						$inhalt11=p4n_sb_strreplace('<<vdet_lieferdatum>>', $postfeld['vertrags_gwlieferung'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<mitarbeiter>>', $_SESSION['mitarbeiter_name'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<mitarbeiter_email>>', $_SESSION['user_email'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<mitarbeiter_telefon>>', $_SESSION['benutzer_tel'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<mitarbeiter_fax>>', $_SESSION['benutzer_fax'], $inhalt11);
						$inhalt11=p4n_sb_strreplace('<<mitarbeiter_mobilfon>>', $_SESSION['benutzer_mob'], $inhalt11);
					}
				}
			}
		}
		
		// DD Beratungsprotokoll
		if ($cfg_dd_vvi2022 and $bez_ang_kv2!='skv') {//  and $bez_ang_kv==_KAUFVERTRAG_
			
			if (1) {
				$dok_gef=false;
				$inhalt19='';
				$ddvvi_vl='vorlage_beratungsprotokoll_gw.rtf';
				if (isset($postfeld['ddvvi_nw_schadenkosten'])) {
					$ddvvi_vl='vorlage_beratungsprotokoll_nw.rtf';
				}
				$det_datei3='';
				if (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$ddvvi_vl)) {
					$det_datei3='inc/'.$_SESSION['cfg_kunde'].'/'.$ddvvi_vl;
					$dok_gef=true;
				}
				if ($dok_gef) {
					$felder=allefelder($det_datei3);
					if ($fp=fopen($det_datei3, 'r')) {
						$inhalt19=fread($fp, filesize($det_datei3));
						fclose($fp);
						$inhalt19=preg_replace('/\}\{\\\\f1\\\\fs20\\\\insrsid\d+ /', '', $inhalt19);
					}
					if ($inhalt19!='') {
						$inhalt19=ersetze_nwgwbed_felder($inhalt19);
						$inhalt19=vorlage_kdaten_ersetzen($inhalt19, $postfeld['firma1'], $postfeld['vorname'], $postfeld['name'], $postfeld['titel'], $postfeld['anrede'], $_SESSION['stammdaten_id'], $postfeld['firma3']);
						if (preg_match('/<<briefanrede>>/', $inhalt19)) {
							$inhalt19=preg_replace('/<<briefanrede>>.*<<mn>>.*,/Uis', _BRIEFANREDE_FIRMA_, $inhalt19);
						}
						$inhalt19=p4n_sb_strreplace('<<kunde>>', $anzeigename, $inhalt19);
						$inhalt19=p4n_sb_strreplace('<<adresse>>', $postfeld['adresse'], $inhalt19);
						$inhalt19=p4n_sb_strreplace('<<plz>>', $postfeld['plz'], $inhalt19);
						$inhalt19=p4n_sb_strreplace('<<ort>>', $postfeld['ort'].$zus_ort_landinfo, $inhalt19);
						$inhalt19=p4n_sb_strreplace('<<datum>>', adodb_date('d.m.Y'), $inhalt19);
						$inhalt19=p4n_sb_strreplace('<<datumzeit>>', adodb_date('d.m.Y H:i'), $inhalt19);
						$inhalt19=p4n_sb_strreplace('<<zeit>>', adodb_date('H:i'), $inhalt19);
						$inhalt19=p4n_sb_strreplace('<<beruf>>', $postfeld['beruf'], $inhalt19);
						$anr1=$postfeld['anrede'];
						if ($anr1=='HERRN' or $anr1=='HERR' or $anr1=='FRAU' or $anr1=='FIRMA') {
							$anr1=p4n_mb_string('ucfirst',p4n_mb_string('strtolower',$anr1));
						}
						$inhalt19=p4n_sb_strreplace('<<anrede>>', $anr1, $inhalt19);
						$inhalt19=p4n_sb_strreplace('<<vorname>>', $postfeld['vorname'], $inhalt19);
						$inhalt19=p4n_sb_strreplace('<<name>>', $postfeld['name'], $inhalt19);
						if ($postfeld['firma1']!='') {
							if (!preg_match('/<<firma>>/i', $inhalt19)) {
								$inhalt19=p4n_sb_strreplace('<<vorname>> <<name>>', '<<firma>> <<vorname>> <<name>>', $inhalt19);
								if ($postfeld['name']=='' and $postfeld['vorname']=='') {
									$inhalt19=p4n_sb_strreplace('<<name>>, <<vorname>>', '<<firma>> <<name>> <<vorname>>', $inhalt19);
								} else {
									$inhalt19=p4n_sb_strreplace('<<name>>, <<vorname>>', '<<firma>> <<name>>, <<vorname>>', $inhalt19);
								}
							}
						}
						$inhalt19=p4n_sb_strreplace('<<refnr>>', $kfz_haendlerstatus, $inhalt19);
						$inhalt19=p4n_sb_strreplace('<<firma>>', $postfeld['firma1'], $inhalt19);
						$inhalt19=p4n_sb_strreplace('<<mitarbeiter>>', $_SESSION['mitarbeiter_name'], $inhalt19);
						$inhalt19=p4n_sb_strreplace('<<mitarbeiter_email>>', $_SESSION['user_email'], $inhalt19);
						$inhalt19=p4n_sb_strreplace('<<mitarbeiter_telefon>>', $_SESSION['benutzer_tel'], $inhalt19);
						if ($ddvvi_vl=='vorlage_beratungsprotokoll_nw.rtf') {
							// NW
							if (isset($postfeld['ddvvi_nw_0'])) {
								$inhalt19=p4n_sb_strreplace(array('<<s_ddvvinw0>>', '<<e_ddvvinw0>>'), '', $inhalt19);
							} else {
								$inhalt19=p4n_sb_preg_replace('/<<s_ddvvinw0>>.*<<e_ddvvinw0>>/Uis', '', $inhalt19);
							}
							if (isset($postfeld['ddvvi_nw_1'])) {
								$inhalt19=p4n_sb_strreplace(array('<<s_ddvvinw1>>', '<<e_ddvvinw1>>'), '', $inhalt19);
							} else {
								$inhalt19=p4n_sb_preg_replace('/<<s_ddvvinw1>>.*<<e_ddvvinw1>>/Uis', '', $inhalt19);
							}
							if (isset($postfeld['ddvvi_nw_2'])) {
								$inhalt19=p4n_sb_strreplace(array('<<s_ddvvinw2>>', '<<e_ddvvinw2>>'), '', $inhalt19);
							} else {
								$inhalt19=p4n_sb_preg_replace('/<<s_ddvvinw2>>.*<<e_ddvvinw2>>/Uis', '', $inhalt19);
							}
							if (isset($postfeld['ddvvi_nw_3'])) {
								$inhalt19=p4n_sb_strreplace(array('<<s_ddvvinw3>>', '<<e_ddvvinw3>>'), '', $inhalt19);
							} else {
								$inhalt19=p4n_sb_preg_replace('/<<s_ddvvinw3>>.*<<e_ddvvinw3>>/Uis', '', $inhalt19);
							}
							if (isset($postfeld['ddvvi_nw_4'])) {
								$inhalt19=p4n_sb_strreplace(array('<<s_ddvvinw4>>', '<<e_ddvvinw4>>'), '', $inhalt19);
							} else {
								$inhalt19=p4n_sb_preg_replace('/<<s_ddvvinw4>>.*<<e_ddvvinw4>>/Uis', '', $inhalt19);
							}
							$inhalt19=p4n_sb_strreplace('<<bp_nw_pf_ausst>>', $postfeld['ddvvi_pf_ausst'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_nw_pf_motor>>', $postfeld['ddvvi_pf_motor'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_nw_pf_ez>>', $postfeld['ddvvi_pf_ez'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_nw_proddatum>>', $postfeld['ddvvi_nw_proddatum'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_nw_maxkm>>', $postfeld['ddvvi_nw_km'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_nw_schaden>>', $postfeld['ddvvi_nw_schadenkosten'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_nw_schadentext>>', str_replace(array("\n", '<br>'), '\\par ', $postfeld['ddvvi_nw_schaden']), $inhalt19);
						} else {
							// GW
							if (isset($postfeld['ddvvi_gw_1'])) {
								$inhalt19=p4n_sb_strreplace(array('<<s_ddvvigw1>>', '<<e_ddvvigw1>>'), '', $inhalt19);
							} else {
								$inhalt19=p4n_sb_preg_replace('/<<s_ddvvigw1>>.*<<e_ddvvigw1>>/Uis', '', $inhalt19);
							}
							if (isset($postfeld['ddvvi_gw_2'])) {
								$inhalt19=p4n_sb_strreplace(array('<<s_ddvvigw2>>', '<<e_ddvvigw2>>'), '', $inhalt19);
							} else {
								$inhalt19=p4n_sb_preg_replace('/<<s_ddvvigw2>>.*<<e_ddvvigw2>>/Uis', '', $inhalt19);
							}
							if (isset($postfeld['ddvvi_gw_3'])) {
								$inhalt19=p4n_sb_strreplace(array('<<s_ddvvigw3>>', '<<e_ddvvigw3>>'), '', $inhalt19);
							} else {
								$inhalt19=p4n_sb_preg_replace('/<<s_ddvvigw3>>.*<<e_ddvvigw3>>/Uis', '', $inhalt19);
							}
							if (isset($postfeld['ddvvi_gw_4'])) {
								$inhalt19=p4n_sb_strreplace(array('<<s_ddvvigw4>>', '<<e_ddvvigw4>>'), '', $inhalt19);
							} else {
								$inhalt19=p4n_sb_preg_replace('/<<s_ddvvigw4>>.*<<e_ddvvigw4>>/Uis', '', $inhalt19);
							}
							if (isset($postfeld['ddvvi_gw_5'])) {
								$inhalt19=p4n_sb_strreplace(array('<<s_ddvvigw5>>', '<<e_ddvvigw5>>'), '', $inhalt19);
							} else {
								$inhalt19=p4n_sb_preg_replace('/<<s_ddvvigw5>>.*<<e_ddvvigw5>>/Uis', '', $inhalt19);
							}
							if (isset($postfeld['ddvvi_gw_6'])) {
								$inhalt19=p4n_sb_strreplace(array('<<s_ddvvigw6>>', '<<e_ddvvigw6>>'), '', $inhalt19);
							} else {
								$inhalt19=p4n_sb_preg_replace('/<<s_ddvvigw6>>.*<<e_ddvvigw6>>/Uis', '', $inhalt19);
							}
							$inhalt19=p4n_sb_strreplace('<<bp_gw_pf_ausst>>', $postfeld['ddvvi_pf_ausst'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_gw_pf_motor>>', $postfeld['ddvvi_pf_motor'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_gw_pf_ez>>', $postfeld['ddvvi_pf_ez'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_gw_km>>', $postfeld['ddvvi_gw_km'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_gw_nichtrep>>', $postfeld['ddvvi_gw_schaden'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_gw_tuev>>', $postfeld['ddvvi_gw_hu_rest'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_gw_profil>>', $postfeld['ddvvi_gw_profiltiefe'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_gw_sonstiges>>', $postfeld['ddvvi_gw_sonstiges'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_gw_schaden>>', $postfeld['ddvvi_gw_schadenkosten'], $inhalt19);
							$inhalt19=p4n_sb_strreplace('<<bp_gw_schadentext>>', str_replace(array("\n", '<br>'), '\\par ', $postfeld['ddvvi_gw_schaden2']), $inhalt19);
						}
					}
				}
			}
		}
		
		if (!$leasingdruck and isset($postfeld['reifenlabel']) and isset($sql_tab['kfzzuordnung']) and isset($sql_tabs['kfzzuordnung']['reifenlabel'])) {
				$gmemodnr='';
				if (isset($postfeld['gme_modellnr2'])) {
					$gmemodnr=$postfeld['gme_modellnr2'];
				}
				if ($gmemodnr=='') {
					$gmemodnr=$postfeld['gme_modellnr'];
				}
				$neben_gef=false;
				$reifenl_1='';
				if ($gmemodnr!='' and $postfeld['kfz_markencode']!='') {
					$sqltu=array(
							$sql_tabs['kfzzuordnung']['reifenlabel'],
							$sql_tabs['kfzzuordnung']['modellnr'],
							$sql_tabs['kfzzuordnung']['id']
					);
					$res4=$db->select(
						$sql_tab['kfzzuordnung'],
						$sqltu,
						$sql_tabs['kfzzuordnung']['markencode'].' like '.$db->str($postfeld['kfz_markencode'])
							.' and '.$sql_tabs['kfzzuordnung']['modellnr'].'!='.$db->str('')
					);
					while (!$neben_gef and $row4=$db->zeile($res4)) {
						$expl2=explode(',', $row4[1]);
						while (list($mkey, $mval)=@each($expl2)) {
							$mval=str_replace('%', '', $mval);
							if (p4n_mb_string('substr',$gmemodnr, 0, p4n_mb_string('strlen',$mval))==$mval) {
								$reifenl_1=$row4[0];
								$kfzzu_id=$row4[2];
								$neben_gef=true;
							}
						}
					}
				}
				if (!$neben_gef and $postfeld['kfz_typmodell']!='' and $postfeld['kfz_markencode']!='') {
					$typm2=$postfeld['kfz_typmodell'];
					$expl2=preg_split('/\W/', $typm2);
					$typm2=$expl2[0];
					$res4=$db->select(
						$sql_tab['kfzzuordnung'],
						array(
							$sql_tabs['kfzzuordnung']['reifenlabel'],
							$sql_tabs['kfzzuordnung']['id']
						),
						$sql_tabs['kfzzuordnung']['markencode'].' like '.$db->str($postfeld['kfz_markencode'])
							.' and '.$sql_tabs['kfzzuordnung']['typmodell'].' like '.$db->str($typm2.'%')
					);
					if ($row4=$db->zeile($res4)) {
						$reifenl_1=$row4[0];
						$kfzzu_id=$row4[1];
						$neben_gef=true;
					}
				}
				if ($reifenl_1!='' and is_file($reifenl_1)) {
					if ($cfg_kfzsuche_pdf_join and substr($reifenl_1, -4)=='.pdf') {
						$alle_pdfs[199]=$doclink8pdf;
					}
					echo javas('window.open("'.$reifenl_1.'", "_blank");');
				}
		}
		
		$kvbed_inh='';
		$doclink_bed='';
		$dok_f=false;
		$dok_f_pdf=false;
		if (!$leasingdruck and (isset($postfeld['kv_bedingungen_nw']) or isset($postfeld['kv_bedingungen_gw']))) {
			$kvbed='kv_bedingungen_nw';
			if (isset($postfeld['kv_bedingungen_gw'])) {
				$kvbed='kv_bedingungen_gw';
			}

			if (isset($postfeld['vertrag_nwgw'])) {
				if ($postfeld['vertrag_nwgw']=='1') {
					$kvbed='kv_bedingungen_gw';
				}
			}
			if (isset($postfeld['vorlage_vfw'])) {
				$ist_testw=false;
				if ($_SESSION['cfg_kunde']=='carlo_opel_dello') {
					$res77=$db->select(
						$sql_tab['produktzuordnung'],
						array(
							$sql_tabs['produktzuordnung']['fahrzeugstatus'],
							$sql_tabs['produktzuordnung']['fahrzeugstatus_code']
						),
						$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
					);
					if ($row77=$db->zeile($res77)) {
						if (substr($row77[0], 0, 4)=='Test') {
							$ist_testw=true;
						}
					}
				}
				if ($_SESSION['cfg_kunde']=='carlo_opel_elsemann' or $cfg_kfzsuche_vfw_nwbed) {
					$ist_testw=true;
				}
				if (!$ist_testw and $postfeld['vorlage_vfw']=='1') {
					$kvbed='kv_bedingungen_gw';
				}
			}
			if (isset($postfeld['vorlage_gw'])) {
				if ($postfeld['vorlage_gw']=='1') {
					$kvbed='kv_bedingungen_gw';
				}
			}
			
			if ($postfeld['mvertrag_lagerort']!='' and !$dok_f) {
				$v_lao=$postfeld['mvertrag_lagerort'];
				$res3=$db->select(
					$sql_tab['mandant'],
					array(
						$sql_tabs['mandant']['bezeichnung'],
						$sql_tabs['mandant']['parent_id']
					),
					$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($v_lao)
				);
				if ($row3=$db->zeile($res3)) {
					$v_lao=trim($row3[0]);
					if (intval($row3[1])>0) {
						$m_mand1=$row3[1];
						$kvbed2=$kvbed;
						$kvbed2.='_M'.$row3[1];
						if ($cfg_rtf2pdf and is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed2.'.pdf')) {
							$doclink_bed='inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed2.'.pdf';
							$dok_f_pdf=true;
							$dok_f=true;
						} elseif ($cfg_rtf2pdf and is_file('vorlagen/'.$kvbed2.'.pdf')) {
							$doclink_bed='vorlagen/'.$kvbed2.'.pdf';
							$dok_f_pdf=true;
							$dok_f=true;
						} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed2.'.rtf')) {
							$doclink_bed='inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed2.'.rtf';
							$dok_f=true;
						} elseif (is_file('vorlagen/'.$kvbed2.'.rtf')) {
							$doclink_bed='vorlagen/'.$kvbed2.'.rtf';
							$dok_f=true;
						}
						if ($dok_f) {
							$kvbed=$kvbed2;
						}
					}
				}
			}
			
			if ($postfeld['kfz_markencode']!='' and !$dok_f) {
				$kvbed2=$kvbed;
				$kvbed2.='_'.p4n_mb_string('strtolower',trim($postfeld['kfz_markencode']));
				if ($cfg_rtf2pdf and is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed2.'.pdf')) {
					$doclink_bed='inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed2.'.pdf';
					$dok_f_pdf=true;
					$dok_f=true;
				} elseif ($cfg_rtf2pdf and is_file('vorlagen/'.$kvbed2.'.pdf')) {
					$doclink_bed='vorlagen/'.$kvbed2.'.pdf';
					$dok_f_pdf=true;
					$dok_f=true;
				} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed2.'.rtf')) {
					$doclink_bed='inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed2.'.rtf';
					$dok_f=true;
				} elseif (is_file('vorlagen/'.$kvbed2.'.rtf')) {
					$doclink_bed='vorlagen/'.$kvbed2.'.rtf';
					$dok_f=true;
				}
				if ($dok_f) {
					$kvbed=$kvbed2;
				}
			}
			
			if (isset($postfeld['vertrag_nutzungsart'])) {
				$kvbed2='';
				if ($postfeld['vertrag_nutzungsart']=='1') {
					$kvbed2=$kvbed.'_priv';
				}
				if ($postfeld['vertrag_nutzungsart']=='2') {
					$kvbed2=$kvbed.'_gewerb';
				}
				if ($kvbed2!='') {
					$dok_f=false;

					if ($cfg_rtf2pdf and is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed2.'.pdf')) {
						$dok_f=true;
						$doclink_bed='inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed2.'.pdf';
						$dok_f_pdf=true;
					} elseif ($cfg_rtf2pdf and is_file('vorlagen/'.$kvbed2.'.pdf')) {
						$dok_f=true;
						$doclink_bed='vorlagen/'.$kvbed2.'.pdf';
						$dok_f_pdf=true;
					} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed2.'.rtf')) {
						$dok_f=true;
						$doclink_bed='inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed2.'.rtf';
					} elseif (is_file('vorlagen/'.$kvbed2.'.rtf')) {
						$dok_f=true;
						$doclink_bed='vorlagen/'.$kvbed2.'.rtf';
					}
					if ($dok_f) {
						$kvbed=$kvbed2;
					}
				}
			}

			if (!$dok_f) {
				$dok_f=false;
				if ($cfg_rtf2pdf and is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed.'.pdf')) {
					$dok_f=true;
					$doclink_bed='inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed.'.pdf';
					$dok_f_pdf=true;
				} elseif ($cfg_rtf2pdf and is_file('vorlagen/'.$kvbed.'.pdf')) {
					$dok_f=true;
					$doclink_bed='vorlagen/'.$kvbed.'.pdf';
					$dok_f_pdf=true;
				} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed.'.rtf')) {
					$dok_f=true;
					$doclink_bed='inc/'.$_SESSION['cfg_kunde'].'/'.$kvbed.'.rtf';
				} elseif (is_file('vorlagen/'.$kvbed.'.rtf')) {
					$dok_f=true;
					$doclink_bed='vorlagen/'.$kvbed.'.rtf';
				}
			}
			if ($dok_f_pdf) {
				$alle_pdfs[20]=$doclink_bed;
			}
			if (!$dok_f_pdf and isset($postfeld['vorlage_kopien'])) {
				if ($fp=fopen($doclink_bed, 'r')) {
					$kvbed_inh=fread($fp, filesize($doclink_bed));
					fclose($fp);
				}
				$inhalt3=$kvbed_inh;
				if (preg_match("/^\{(.*)(\{\\\info.*(\{[^\}]*\})\})(.*)\}$/Us",$inhalt3,$gefunden)) {
				//	$beginn="";
					while (list($key,$val)=@each($gefunden))
						if ($key!=0 and $key!=(count($gefunden)-1) and $key!=(count($gefunden)-2)) {
						//	$beginn.=$gefunden[$key];
						}
					$replace_text=$gefunden[count($gefunden)-1];
				} elseif(preg_match("/^\{(.*)(\{\\\info.*(\{.*\})\})(.*)\}/Uis",$inhalt3,$gefunden)) {
						// ab PHP 5.2
						//$beginn="";
						while (list($key,$val)=@each($gefunden)) {
							if ($key!=0 and $key!=(count($gefunden)-1) and $key!=(count($gefunden)-2)) {
							//	$beginn.=$gefunden[$key];
							}
						}
						$replace_text=$gefunden[count($gefunden)-1];

						$replace_text=p4n_mb_string('strstr',$inhalt3, $replace_text);
						if (p4n_mb_string('substr',$replace_text, -1)=='}') {
							$replace_text=p4n_mb_string('substr',$replace_text, 0, -1);
						}
				} elseif (preg_match("/\{(.*)\}(.*)\}/s",$inhalt3,$gefunden)) {
					// Wordpad:
				//	$beginn=$gefunden[1].'}';
					$replace_text=$gefunden[2];
				} else {
					$replace_text="";	// $inhalt3
				}

				$replace_text=ersetze_nwgwbed_felder($replace_text);

				$kvbed_inh='\page '.$replace_text;
			}
			if ($dok_f and $kvbed_inh=='') {
				if ($cfg_kfzsuche_nwgwbedingungen_felder) {
					if ($fp=fopen($doclink_bed, 'r')) {
						$kvbed_inh2=fread($fp, filesize($doclink_bed));
						fclose($fp);

						$kvbed_inh2=ersetze_nwgwbed_felder($kvbed_inh2);

						$neubeddat='temp/kvbed_'.$_SESSION['user_id'].'.rtf';
						if ($fp=fopen($neubeddat, 'w')) {
							fwrite($fp, $kvbed_inh2);
							fclose($fp);
							$doclink_bed=$neubeddat;//.'?time='.time()
						}
					}
				}
				if ($cfg_kfzsuche_pdf_join and substr($doclink_bed, -4)=='.pdf' and $dok_f_pdf) {
					
				} else {
					echo javas('window.open("'.$doclink_bed.'?ts='.time().'", "_blank");');
				}
			}
		}
		
		$ist_docx=$m_ist_docx;
		
		$inhalt_kunde=$inhalt;
		$inhalt_temp=$inhalt;
		
		$doclink_t='';
		if (!$leasingdruck and isset($postfeld['vorlage_kopien'])) {	// and intval($postfeld['vorlage_kopien'])>0
			if ($ist_docx) {
				$inhalt_kunde=$beginn.$inhalt.$ende;
			} else {
				$inhalt_kunde='{'.$beginn.$inhalt.'}';
			}
			$anz1=intval($postfeld['vorlage_kopien']);
			$neu_inh=$inhalt;
			while ($anz1>0) {
				if ($ist_docx) {
					$neu_inh.='<w:p/>'.$inhalt;
				} else{
					$neu_inh.='\page '.$inhalt;
				}
				$anz1--;
			}
			if ($ist_docx) {
				$inhalt_temp=$beginn.$neu_inh.$ende;//$kvbed_inh.
			} else {
				$inhalt_temp='{'.$beginn.$neu_inh.$kvbed_inh.'}';
			}
			
			$doclink_t='temp/'.$bez_ang_kv2.'_'.$_SESSION['user_id'].'.rtf';
			$inhalt_temp2=$inhalt_temp;
			if ($ist_docx) {
				$doclink_t='temp/'.$bez_ang_kv2.'_'.$_SESSION['user_id'].'.docx';
				$inhalt_temp2=docx_schreiben($inhalt_temp);
			}
			if ($fp=fopen($doclink_t, 'w')) {
				fwrite($fp, $inhalt_temp2);
				fclose($fp);
			}
		}
		
		$alle_zve_kids='';
		$weitere_kv=array();
		@reset($zusatzdateien1);
		while (!$leasingdruck and list($zdatein1, $inh_sv1)=@each($zusatzdateien1)) {
			if (is_file('dokumente/'.$zdatein1)) {
				$inft_zinh=file_get_contents('dokumente/'.$zdatein1);
				$inft_zinh2=ersetze_nwgwbed_felder($inft_zinh);
				$inft_zinh2=p4n_sb_strreplace('<<vereinbarung>>', $inh_sv1[1], $inft_zinh2);
				$zieldatei_it='dokumente/'.$zdatein1;
				
				$zdmit_pdf=false;
				if ($cfg_rtf2pdf and $inh_sv1[3]==true and (strtolower(p4n_mb_string('substr', $zieldatei_it, -4))=='.rtf' or strtolower(p4n_mb_string('substr', $zieldatei_it, -5))=='.docx')) {
					$zdmit_pdf=true;
				}
				
				$doclinksvpdf='';
				if ($cfg_kfzsuche_sonst_vereinb_korr_immer or $zdmit_pdf or $inft_zinh!=$inft_zinh2) {
					if ($vorschau or $inh_sv1[2]==true) {
						$zieldatei_it='temp/zusatzvereinbarung'.$inh_sv1[0].'_'.$_SESSION['user_id'].'.rtf';
						if ($fp=fopen($zieldatei_it, 'w')) {
							fwrite($fp, $inft_zinh2);
							fclose($fp);
						}
						if ($zdmit_pdf) {
							$doclinksvpdf=check_rtf2pdf($zieldatei_it, $cfg_rtf2pdf_sleep);
							if ($doclinksvpdf==$zieldatei_it) {
								$doclinksvpdf='';
							} else {
								$zieldatei_it=$doclinksvpdf;
//								$alle_pdfs[]=$doclinksvpdf;
							}
						}
					} else {
						$zieldatei_it='dokumente_korrespondenz/'.$bez_ang_kv2.'_zusatzvereinbarung'.$inh_sv1[0].'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'.rtf';
						$zieldatei_it='dokumente_korrespondenz/'.dok_korr_sp(str_replace('dokumente_korrespondenz/', '', $zieldatei_it), $bez_ang_kv2.'_zusatzvereinbarung');
						if ($zdmit_pdf) {
							if ($fp=fopen($zieldatei_it, 'w')) {
								fwrite($fp, $inft_zinh2);
								fclose($fp);
							}
							$doclinksvpdf=check_rtf2pdf($zieldatei_it, $cfg_rtf2pdf_sleep);
							if ($doclinksvpdf==$zieldatei_it) {
								$doclinksvpdf='';
							} else {
								$zieldatei_it=$doclinksvpdf;
//								$alle_pdfs[]=$doclinksvpdf;
							}
						}
						$kfeld=array(
								$sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['wvl_datum1'] => 0,
								$sql_tabs['korrespondenz']['wvl_datum2'] => 0,
								$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
								$sql_tabs['korrespondenz']['ansprechpartner_id'] => $db->dbzahl($apid),
								$sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
								$sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['eingang'] => 0,
								$sql_tabs['korrespondenz']['art'] => $db->dbzahl(11),
								$sql_tabs['korrespondenz']['kategorie'] => $db->str(_ZUSATZVEREINBARUNG_),
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
								$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['doclink'] => $db->str(str_replace('dokumente_korrespondenz/', '', $zieldatei_it)),
								$sql_tabs['korrespondenz']['betreff'] => $db->str(_ZUSATZVEREINBARUNG_.' '.$inh_sv1[0]),
								$sql_tabs['korrespondenz']['beschreibung'] => $db->str($inh_sv1[1]),
								$sql_tabs['korrespondenz']['zusatz1'] => $db->str(''),
								$sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['papierkorb'] => 0,
								$sql_tabs['korrespondenz']['kalender_id'] => 0,
								$sql_tabs['korrespondenz']['prioritaet'] => 0,
								$sql_tabs['korrespondenz']['negativ'] => 0,
								$sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_nr'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_ZUSATZVEREINBARUNG_),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str(''),
								$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($ang_kv_user)
						);
						if ($cfg_kfzsuche_levy) {
							$kfeld[$sql_tabs['korrespondenz']['betreff']]=$db->str($inh_sv1[1]);
						}
						tempdateien($zieldatei_it, $zdatein1, _ZUSATZVEREINBARUNG_.' '.kundenbezeichnung($_SESSION['stammdaten_id']));
						if ($anr>0) {
							//	$kfeld[$sql_tabs['korrespondenz']['opportunity_id']]=$db->dbzahl($anr);
						}
						$m_capps_keinek=$capps_keinek;
						$capps_keinek=true;
						$allesok=$db->insert(
							$sql_tab['korrespondenz'],
							$kfeld
						);
						$alle_zve_kids.=$db->insertid().',';
						$capps_keinek=$m_capps_keinek;
					}
					if ($doclinksvpdf=='') {
						if ($fp=fopen($zieldatei_it, 'w')) {
							fwrite($fp, $inft_zinh2);
							fclose($fp);
						}
					}
				}
				if ($cfg_kfzsuche_pdf_join and substr($zieldatei_it, -4)=='.pdf') {
					if (!isset($zaepdfk_sv)) {
						$zaepdfk_sv=100;
					}
					$alle_pdfs[$zaepdfk_sv]=$zieldatei_it;
					$zaepdfk_sv++;
				} else {
					echo javas('window.open("'.$zieldatei_it.'", "_blank");');
				}
			}
			// $zusatzdateien1[$postfeld['infotextz_datei'][$ikey]]=array($postfeld['infotextz_rang'][$ikey], $inft1n);
		}
		
		if ($vorschau and $cfg_kfzsuche_avagfullservice) {
			if ($postfeld['fulls_allvalues']!='') {
				include_once('inc/fulls.php');
				$rtf=fulls_dok();
				if ($rtf=='') {
					
				} else {
					$doclink_en='temp/fulls_'.$_SESSION['user_id'].'.rtf';
					if ($fp=fopen($doclink_en, 'w')) {
						fwrite($fp, $rtf);
						fclose($fp);
						echo javas('window.open("'.$doclink_en.'", "_blank");');
						$weitere_kv[]=$doclink_en;
					}
				}
				if (preg_match('/fulls_rahmenabk=1/', $postfeld['fulls_allvalues'])) {
					$rtf2=fulls_dok2();
					if ($rtf2=='') {
						
					} else {
						$doclink_en2='temp/fulls2_'.$_SESSION['user_id'].'.rtf';
						if ($fp=fopen($doclink_en2, 'w')) {
							fwrite($fp, $rtf2);
							fclose($fp);
							echo javas('window.open("'.$doclink_en2.'", "_blank");');
							$weitere_kv[]=$doclink_en2;
						}
					}
				}
			}
		}
		if ($vorschau and $cfg_kfzsuche_avagautoabo) {
			if ($postfeld['autoabo_allvalues']!='') {
				include_once('inc/fulls.php');
				$rtf=autoabo_dok();
				if ($rtf=='') {
					
				} else {
					$doclink_en='temp/autoabo_'.$_SESSION['user_id'].'.rtf';
					if ($fp=fopen($doclink_en, 'w')) {
						fwrite($fp, $rtf);
						fclose($fp);
						echo javas('window.open("'.$doclink_en.'", "_blank");');
						$weitere_kv[]=$doclink_en;
					}
				}
			}
		}
		
		// envkv:
		if (!$leasingdruck and isset($postfeld['en_klasse'])) {
			$rtf=envkv_dok();
			if ($rtf=='') {
				
			} else {
				$doclink_en='temp/envkv_'.$_SESSION['user_id'].'.rtf';
				if ($fp=fopen($doclink_en, 'w')) {
					fwrite($fp, $rtf);
					fclose($fp);
					
					$doclink_en_pdf='';
					if ($cfg_rtf2pdf and substr($doclink_en, -4)!='.pdf') {
						$doclink_en_pdf=check_rtf2pdf($doclink_en, $cfg_rtf2pdf_sleep);
						if ($doclink_en_pdf==$doclink_en) {
							$doclink_en_pdf='';
						}
					} elseif (substr($doclink_en, -4)=='.pdf') {
						$doclink_en_pdf=$doclink_en;
					}
					
					if ($doclink_en_pdf!='') {
						if ($cfg_kfzsuche_pdf_join and substr($doclink_en_pdf, -4)=='.pdf') {
							
						} else {
							echo javas('window.open("'.$doclink_en_pdf.'", "_blank");');
						}
						$alle_pdfs[30]=$doclink_en_pdf;
					} else {
						echo javas('window.open("'.$doclink_en.'", "_blank");');
						$weitere_kv[]=$doclink_en;
					}
				}
			}
		}
		if (!$leasingdruck and isset($postfeld['vkh_rtf'])) {
			$rtf=opelvkh_dok();
			if ($rtf=='') {
				
			} else {
				$doclink_en='temp/opelvkh_'.$_SESSION['user_id'].'.rtf';
				if ($fp=fopen($doclink_en, 'w')) {
					fwrite($fp, $rtf);
					fclose($fp);
					
					$doclink_en_pdf='';
					if ($cfg_rtf2pdf and substr($doclink_en, -4)!='.pdf') {
						$doclink_en_pdf=check_rtf2pdf($doclink_en, $cfg_rtf2pdf_sleep);
						if ($doclink_en_pdf==$doclink_en) {
							$doclink_en_pdf='';
						}
					} elseif (substr($doclink_en, -4)=='.pdf') {
						$doclink_en_pdf=$doclink_en;
					}
					
					if ($doclink_en_pdf!='') {
						if ($cfg_kfzsuche_pdf_join and substr($doclink_en_pdf, -4)=='.pdf') {
							
						} else {
							echo javas('window.open("'.$doclink_en_pdf.'", "_blank");');
						}
						$alle_pdfs[35]=$doclink_en_pdf;
					} else {
						echo javas('window.open("'.$doclink_en.'", "_blank");');
						$weitere_kv[]=$doclink_en;
					}
//				link_dok_oeffnen($doclink_en);
				}
			}
		}
		if ($vorschau) {
			$doclink=$bez_ang_kv2.'_'.$_SESSION['user_id'].'.rtf';
			if ($leasingdruck) {
				$doclink=$bez_ang_kv2.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'_leasingprint.rtf';
			}
			if ($profitdruck) {
				$doclink=$bez_ang_kv2.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'_profitprint.rtf';
			}
			if ($ist_docx) {
				$doclink=$bez_ang_kv2.'_'.$_SESSION['user_id'].'.docx';
				if ($leasingdruck) {
					$doclink=$bez_ang_kv2.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'_leasingprint.docx';
				}
				if ($profitdruck) {
					$doclink=$bez_ang_kv2.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'_profitprint.docx';
				}
				$inhalt_temp=docx_schreiben($inhalt_temp);
			}
			$doclink2='temp/'.$doclink;
			if ($leasingdruck) {
				$doclink=dok_korr_sp($doclink, $bez_ang_kv2);
				$doclink2='dokumente_korrespondenz/'.$doclink;
			}
			if ($cfg_kfzsuche_kalkulation and $profitdruck) {
				$doclink='';
				$doclink2='';
			} elseif ($fp=fopen($doclink2, 'w')) {
				fwrite($fp, $inhalt_temp);
				fclose($fp);
				
				if ($cfg_rtf2pdf) {
					$m_doclink2=$doclink2;
					$doclink2=check_rtf2pdf($doclink2, $cfg_rtf2pdf_sleep);
					$alle_pdfs[12]=$doclink2;
					if ($leasingdruck and $m_doclink2!=$doclink2) {
						unlink($m_doclink2);
					}
				}
				if (!isset($getfeld['profitc_genehmigt'])) {
					if ($cfg_kfzsuche_pdf_join and substr($doclink2, -4)=='.pdf') {
						
					} else {
						echo javas('window.open("'.$doclink2.'?ts='.time().'", "_blank");');
					}
				}
				$doclink3='';
				$doclink4='';
				$doclink5='';
				$doclink6='';
				$doclink9='';
				if (!$leasingdruck and $inhalt2!='') {
					$doclink3=$bez_ang_kv2.'_ankauf_'.$_SESSION['user_id'].'.rtf';
					$doclink3='temp/'.$doclink3;
					if ($fp=fopen($doclink3, 'w')) {
						fwrite($fp, $inhalt2);
						fclose($fp);
					}
					if ($cfg_rtf2pdf) {
						$doclink3=check_rtf2pdf($doclink3, $cfg_rtf2pdf_sleep);
						$alle_pdfs[25]=$doclink3;
					}
					if ($cfg_kfzsuche_pdf_join and substr($doclink3, -4)=='.pdf') {
						
					} else {
						echo javas('window.open("'.$doclink3.'", "_blank");');
					}
				}
				if (!$leasingdruck and $inhalt4!='') {
					$doclink4=$bez_ang_kv2.'_widerruf_'.$_SESSION['user_id'].'.rtf';
					$doclink4='temp/'.$doclink4;
					if ($fp=fopen($doclink4, 'w')) {
						fwrite($fp, $inhalt4);
						fclose($fp);
					}
					if ($cfg_rtf2pdf) {
						$doclink4=check_rtf2pdf($doclink4, $cfg_rtf2pdf_sleep);
						$alle_pdfs[26]=$doclink4;
					}
					if ($cfg_kfzsuche_pdf_join and substr($doclink4, -4)=='.pdf') {
						
					} else {
						echo javas('window.open("'.$doclink4.'", "_blank");');
					}
				}
				if (!$leasingdruck and $inhalt9!='') {
					$doclink9=$bez_ang_kv2.'_sanktion_'.$_SESSION['user_id'].'.rtf';
					$doclink9='temp/'.$doclink9;
					if ($fp=fopen($doclink9, 'w')) {
						fwrite($fp, $inhalt9);
						fclose($fp);
					}
					if ($cfg_rtf2pdf) {
						$doclink9=check_rtf2pdf($doclink9, $cfg_rtf2pdf_sleep);
						$alle_pdfs[29]=$doclink9;
					}
					if ($cfg_kfzsuche_pdf_join and substr($doclink9, -4)=='.pdf') {
						
					} else {
						echo javas('window.open("'.$doclink9.'", "_blank");');
					}
				}
				$doclink11='';
				if (!$leasingdruck and $inhalt11!='') {
					$doclink11=$bez_ang_kv2.'_embargo_'.$_SESSION['user_id'].'.rtf';
					$doclink11='temp/'.$doclink11;
					if ($fp=fopen($doclink11, 'w')) {
						fwrite($fp, $inhalt11);
						fclose($fp);
					}
					if ($cfg_rtf2pdf) {
						$doclink11=check_rtf2pdf($doclink11, $cfg_rtf2pdf_sleep);
						$alle_pdfs[129]=$doclink11;
					}
					if ($cfg_kfzsuche_pdf_join and substr($doclink11, -4)=='.pdf') {
						
					} else {
						echo javas('window.open("'.$doclink11.'", "_blank");');
					}
				}
				if ($doclink11!='') {
					$weitere_kv[]=$doclink11;
				}
				
				$doclink19='';
				if (!$leasingdruck and $inhalt19!='') {
					$doclink19=$bez_ang_kv2.'_beratungsprotokoll_'.$_SESSION['user_id'].'.rtf';
					$doclink19='temp/'.$doclink19;
					if ($fp=fopen($doclink19, 'w')) {
						fwrite($fp, $inhalt19);
						fclose($fp);
					}
					if ($cfg_rtf2pdf) {
						$doclink19=check_rtf2pdf($doclink19, $cfg_rtf2pdf_sleep);
						$alle_pdfs[2]=$doclink19;
					}
					if ($cfg_kfzsuche_pdf_join and substr($doclink19, -4)=='.pdf') {
						
					} else {
						echo javas('window.open("'.$doclink19.'", "_blank");');
					}
				}
				if ($doclink19!='') {
					$weitere_kv[]=$doclink19;
				}
				link_dok_oeffnen($doclink2, $doclink3, $doclink4, $doclink5, $doclink6, $doclink_bed, $weitere_kv);
			}
			if ($leasingdruck) {
				$parid_k=0;
				$res=$db->select(
					$sql_tab['korrespondenz'],
					array(
						$sql_tabs['korrespondenz']['produktzuordnung_id'],
						$sql_tabs['korrespondenz']['stammdaten_id'],
						$sql_tabs['korrespondenz']['opportunity_id']
					),
					$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($postfeld['kbezug'])
				);
				if ($row=$db->zeile($res)) {
					$parid_k=$postfeld['kbezug'];
					$postfeld['pid']=$row[0];
					$_SESSION['stammdaten_id']=$row[1];
					$anr=$row[2];
				}
//echo '<pre>';
//print_r($postfeld);
//die();
				$lkat=_KOPIE_.' '.$bez_ang_kv;
				if ($profitdruck) {
					$lkat=_NLPROFITCALC_.' '.$bez_ang_kv;
					if ($cfg_kfzsuche_levy or $cfg_kfzsuche_gerding or $cfg_kfzsuche_kalkulation) {
						$lkat=_NLPROFITCALC_;
					}
				}
				
				if ($cfg_kfzsuche_kalkulation and $profitdruck) {
					$ltext='<table>';
					$ltext.='<tr><th>Kaufpreis</th><td style="text-align:right">'.number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_hauspreis_netto'])), 2, ",", ".").'</td></tr>';
					$ltext.='<tr><th>UPE</th><td style="text-align:right">'.number_format(doubleval(str_replace(',', '.', $postfeld['upe_netto'])), 2, ",", ".").'</td></tr>';
					$ltext.='<tr><th>mon. Zielerreichung</th><td style="text-align:right">'.number_format(doubleval(str_replace(',', '.', $postfeld['levy_zielerreichung'])), 2, ",", ".").'</td></tr>';
					$ltext.='<tr><th>Modell Fokus Bonus</th><td style="text-align:right">'.number_format(doubleval(str_replace(',', '.', $postfeld['levy_modellbonus'])), 2, ",", ".").'</td></tr>';
					$ltext.='<tr><th>Auditbonus</th><td style="text-align:right">'.number_format(doubleval(str_replace(',', '.', $postfeld['levy_auditbonus'])), 2, ",", ".").'</td></tr>';
					$ltext.='<tr><th>Zwischensumme 1</th><th style="text-align:right">'.number_format(doubleval(str_replace(',', '.', $postfeld['levy_ertrag1'])), 2, ",", ".").'</th></tr>';
					$ltext.='<tr><th>Aufwand lt. DMS</th><td style="text-align:right">-'.number_format(doubleval(str_replace(',', '.', $postfeld['levy_eigenleistungen_topco'])), 2, ",", ".").'</td></tr>';
					$ltext.='<tr><th>Vertriebskosten pauschal</th><td style="text-align:right">-'.number_format(doubleval(str_replace(',', '.', $postfeld['levy_topsafe7'])), 2, ",", ".").'</td></tr>';
					$ltext.='<tr><th>Zwischensumme 2</th><th style="text-align:right">'.number_format(doubleval(str_replace(',', '.', $postfeld['levy_ertrag2'])), 2, ",", ".").'</th></tr>';
					for ($ka1=1; $ka1<=6; $ka1++) {
						if ($postfeld['vertrag5_vkhbez'.$ka1]!='') {
							$ltext.='<tr><th>'.$postfeld['vertrag5_vkhbez'.$ka1].'</th><td style="text-align:right">'.($ka1==6?'-':'').number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_vkh'.$ka1])), 2, ",", ".").'</td></tr>';
						}
					}
					$ltext.='<tr><th>Zwischensumme 3</th><th style="text-align:right">'.number_format(doubleval(str_replace(',', '.', $postfeld['levy_ertrag3'])), 2, ",", ".").'</th></tr>';
					$ltext.='<tr><th>Transport/Speditions/Bereitstellungskosten</th><td style="text-align:right">-'.number_format(doubleval(str_replace(',', '.', $postfeld['levy_f1'])), 2, ",", ".").'</td></tr>';
					$ltext.='<tr><th>Fahrzeugbrief/Zulassungskosten</th><td style="text-align:right">-'.number_format(doubleval(str_replace(',', '.', $postfeld['levy_f2'])), 2, ",", ".").'</td></tr>';
					$ltext.='<tr><th>Ertrag</th><th style="text-align:right">'.number_format(doubleval(str_replace(',', '.', $postfeld['levy_ertrag4'])), 2, ",", ".").'</th></tr>';
					if (isset($postfeld['levy_inz_ja'])) {
						$ltext.='<tr><th>Inzahlungnahme Ankauf</th><td style="text-align:right">'.number_format(doubleval(str_replace(',', '.', $postfeld['levy_inz_preis'])), 2, ",", ".").'</td></tr>';
						$ltext.='<tr><th>Inzahlungnahme vrsl. Verkauf</th><td style="text-align:right">'.number_format(doubleval(str_replace(',', '.', $postfeld['levy_inz_preis_echt'])), 2, ",", ".").'</td></tr>';
					}
					$ltext.='</table>';
				}
				
				$kfeld=array(
								$sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['wvl_datum1'] => 0,
								$sql_tabs['korrespondenz']['wvl_datum2'] => 0,
								$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
								$sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
								$sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['eingang'] => 0,
								$sql_tabs['korrespondenz']['art'] => $db->dbzahl(11),
								$sql_tabs['korrespondenz']['kategorie'] => $db->str($lkat),
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
								$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($parid_k),
								$sql_tabs['korrespondenz']['doclink'] => $db->str(str_replace('dokumente_korrespondenz/', '', $doclink2)),
								$sql_tabs['korrespondenz']['betreff'] => $db->str($lkat),
								$sql_tabs['korrespondenz']['beschreibung'] => $db->str($ltext),
								$sql_tabs['korrespondenz']['zusatz1'] => $db->str($ltext2),
								$sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl($postfeld['pid']),
								$sql_tabs['korrespondenz']['papierkorb'] => 0,
								$sql_tabs['korrespondenz']['kalender_id'] => 0,
								$sql_tabs['korrespondenz']['prioritaet'] => 0,
								$sql_tabs['korrespondenz']['negativ'] => 0,
								$sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_nr'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(($kamp_id>0?$kamp_id:$kampa_id)),
								$sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl($lead_id),
								$sql_tabs['korrespondenz']['quelle'] => $db->str($lead_quelle),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str($lkat),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str($lkat),
								$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['opportunity_id'] => $db->dbzahl($anr)
				);
				$capps_keinek=true;
				$kupdid=0;
				if (isset($getfeld['profkorrid'])) {
					if (intval($getfeld['profkorrid'])>0) {
						$kupdid=intval($getfeld['profkorrid']);
					}
				}
//die();
				if ($kupdid>0) {
					$db->update(
						$sql_tab['korrespondenz'],
						$kfeld,
						$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($kupdid)
					);
				} else {
					$db->insert(
						$sql_tab['korrespondenz'],
						$kfeld
					);
					$kupdid=$db->insertid();
				}
				if (!$cfg_kfzsuche_kalkulation) {
					pc_schreibe_details($anr, $ltext2);
				}
				if ($cfg_kfzsuche_kalkulation and $profitdruck and is_array($opp_felder_nachkalk)) {
					$opp_sql_upd=array();
					@reset($opp_felder_nachkalk);
					while (list($jkey, $jval)=@each($opp_felder_nachkalk)) {
						if (isset($opp_felder_nachkalk_text[$jkey])) {
							$opp_sql_upd[$sql_tabs['opportunity']['nachkalk_'.$jkey]]=$db->str($postfeld[$jkey]);
						} else {
							$opp_sql_upd[$sql_tabs['opportunity']['nachkalk_'.$jkey]]=$db->dbzahl($postfeld[$jkey]);
						}
					}
					if (count($opp_sql_upd)>0) {
						$db->update(
							$sql_tab['opportunity'],
							$opp_sql_upd,
							$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
						);
					}
				}
				if ($cfg_kfzsuche_levy) {
				$opp_sql_upd=array();
				@reset($opp_felder_levy);
				while (list($jkey, $jval)=@each($opp_felder_levy)) {
					if (isset($opp_felder_levy_text[$jkey])) {
						$opp_sql_upd[$sql_tabs['opportunity']['levy_'.$jkey]]=$db->str($postfeld[$jkey]);
					} else {
						$opp_sql_upd[$sql_tabs['opportunity']['levy_'.$jkey]]=$db->dbzahl($postfeld[$jkey]);
					}
				}
				if (count($opp_sql_upd)>0) {
					$db->update(
						$sql_tab['opportunity'],
						$opp_sql_upd,
						$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
					);
				}
				}
				$ist_vkl_kalk=false;
				if ($cfg_kfzsuche_gerding) {
					$alle_mails_kalk=array();
					$res7=$db->select(
						$sql_tab['benutzer_gruppe'],
						array(
							$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
							$sql_tabs['benutzer_gruppe']['bezeichnung']
						),
						$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('VK-Leiter Kalkulation').' or '.$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('Verkaufsleiter Kalkulation')
					);
					if ($row7=$db->zeile($res7)) {
						if (preg_match('/,'.$row7[0].',/', ','.$_SESSION['rechte_bgruppen'].',')) {
							$ist_vkl_kalk=true;
						}
						$res8=$db->select(
							$sql_tab['benutzer_gruppe_zuordnung'],
							$sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'],
							$sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row7[0])
						);
						while ($row8=$db->zeile($res8)) {
							$res9=$db->select(
								$sql_tab['benutzer'],
								array(
									$sql_tabs['benutzer']['email'],
									$sql_tabs['benutzer']['standard_lagerort']
								),
								$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row8[0])
							);
							if ($row9=$db->zeile($res9)) {
								if ($row9[0]!='') {
									$alle_mails_kalk[]=$row9[0];
								}
							}
						}
					}
					
					$alle_mails_kalk_dispo=array();
					$res7=$db->select(
						$sql_tab['benutzer_gruppe'],
						array(
							$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
							$sql_tabs['benutzer_gruppe']['bezeichnung']
						),
						$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('Kalkulation Dispo')
					);
					if ($row7=$db->zeile($res7)) {
						$res8=$db->select(
							$sql_tab['benutzer_gruppe_zuordnung'],
							$sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'],
							$sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row7[0])
						);
						while ($row8=$db->zeile($res8)) {
							$res9=$db->select(
								$sql_tab['benutzer'],
								array(
									$sql_tabs['benutzer']['email'],
									$sql_tabs['benutzer']['standard_lagerort']
								),
								$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row8[0])
							);
							if ($row9=$db->zeile($res9)) {
								if ($row9[0]!='') {
									$alle_mails_kalk_dispo[]=$row9[0];
								}
							}
						}
					}
					
					$subj_zus='';
					$mailvorlage_kalk='Kalkulation VKL';
					if (isset($getfeld['profitc_genehmigt'])) {
						$mailvorlage_kalk='Kalkulation VKL Genehmigung';
						$subj_zus=' Genehmigung ('.$anr.')';
					}
					if (isset($getfeld['profitc_ablehnen'])) {
						$mailvorlage_kalk='Kalkulation VKL Ablehnung';
						$subj_zus=' Ablehnung ('.$anr.')';
					}
					$vorlagetext='';
					$vorlagetext2='';
					
					$res99=$db->select(
						$sql_tab['email_vorlagen'],
						array(
							$sql_tabs['email_vorlagen']['htmltext'],
							$sql_tabs['email_vorlagen']['email_vorlagen_id']
						),
						$sql_tabs['email_vorlagen']['bezeichnung'].' like '.$db->str($mailvorlage_kalk)
					);
        	        $p4n_editor = false;
	                if ($row99=$db->zeile($res99)) {
						if ($cfg_mailversand_editor && is_file('inc/lib_htmledit.php')) {
        	                global $cfg_newsletterbaukasten_p4n, $cfg_newsletterbaukasten_2_p4n, $cfg_newsletterbaukasten_p4n_ohne_tracking;
							include_once 'inc/lib_htmledit.php';
							$html_editor = new HTMLEditor();
							$mail_vorlage=$html_editor->prepare_mail($row99[1]);
							$vorlagetext=p4n_mb_string('str_replace', array('&lt;', '&gt;'), array('<', '>'), $mail_vorlage->Body);
	                        if ($mail_vorlage->CharSet == 'utf-8') {
    	                        $vorlagetext=p4n_mb_string('utf8_decode', $vorlagetext);
        	                    $p4n_editor=true;
            	            }
                	    } else {
                    	    $vorlagetext=p4n_mb_string('str_replace', array('&lt;', '&gt;'), array('<', '>'), $row99[0]);
						}
					}
					
					if (isset($getfeld['profitc_genehmigt'])) {
						$res99=$db->select(
							$sql_tab['email_vorlagen'],
							array(
								$sql_tabs['email_vorlagen']['htmltext'],
								$sql_tabs['email_vorlagen']['email_vorlagen_id']
							),
							$sql_tabs['email_vorlagen']['bezeichnung'].' like '.$db->str('Dispo Genehmigung')
						);
    	    	        $p4n_editor = false;
		                if ($row99=$db->zeile($res99)) {
							if ($cfg_mailversand_editor && is_file('inc/lib_htmledit.php')) {
        	    	            global $cfg_newsletterbaukasten_p4n, $cfg_newsletterbaukasten_2_p4n, $cfg_newsletterbaukasten_p4n_ohne_tracking;
								include_once 'inc/lib_htmledit.php';
								$html_editor = new HTMLEditor();
								$mail_vorlage=$html_editor->prepare_mail($row99[1]);
								$vorlagetext2=p4n_mb_string('str_replace', array('&lt;', '&gt;'), array('<', '>'), $mail_vorlage->Body);
	                        	if ($mail_vorlage->CharSet == 'utf-8') {
    	                	        $vorlagetext2=p4n_mb_string('utf8_decode', $vorlagetext2);
        	        	            $p4n_editor=true;
            		            }
            	    	    } else {
        	            	    $vorlagetext2=p4n_mb_string('str_replace', array('&lt;', '&gt;'), array('<', '>'), $row99[0]);
							}
						}
						if ($vorlagetext2!='') {
							
						}
					}
					
					$ist_gen_abl=false;
					if (isset($getfeld['profitc_genehmigt']) or isset($getfeld['profitc_ablehnen'])) {
						$alle_mails_kalk=array();
						
						$res8=$db->select(
							$sql_tab['opportunity'],
							$sql_tabs['opportunity']['benutzer_id'],
							$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
						);
						if ($row8=$db->zeile($res8)) {
							$res9=$db->select(
								$sql_tab['benutzer'],
								array(
									$sql_tabs['benutzer']['email'],
									$sql_tabs['benutzer']['standard_lagerort']
								),
								$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row8[0])
							);
							if ($row9=$db->zeile($res9)) {
								if ($row9[0]!='') {
									$alle_mails_kalk[]=$row9[0];
								}
							}
						}
						$ist_gen_abl=true;
					}
					
					if ((!$ist_vkl_kalk or $ist_gen_abl) and count($alle_mails_kalk)>0 and $vorlagetext!='') {
						$absender_mail2_from=$_SESSION['user_email'];
						if ($absender_mail2_from=='') {
							$absender_mail2_from=$mcs_pop3_email;
						}
						$absender_mail2=$_SESSION['mitarbeiter_name'];
						$absender_mail3=$absender_mail2;
						$absender_mail3_from=$absender_mail2_from;
						$absender_telefon='';
						$absender_name=$_SESSION['mitarbeiter_name'];
						if (!$ist_gen_abl) {
						$res100=$db->select(
							$sql_tab['benutzer'],
							array(
								$sql_tabs['benutzer']['name'],
								$sql_tabs['benutzer']['vorname'],
								$sql_tabs['benutzer']['email'],
								$sql_tabs['benutzer']['telefon']
							),
							$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($ang_kv_user)	//$row99[8]
						);
						if ($row100=$db->zeile($res100)) {
							if ($row100[2]!='') {
								$absender_mail3=$row100[0].', '.$row100[1];
								$absender_mail3_from=$row100[2];
								$absender_name=$row100[1].' '.$row100[0];
								$absender_telefon=$row100[3];
							}
						}
						}
						
						include_once("mailconf.php");
						$mail->From     = $absender_mail3_from;
						$mail->FromName = 'CRM - '.$absender_name;
						$mail->ClearAllRecipients();
						$mail->ClearAttachments();
						$mail->ClearBCCs();
						$mail->IsHTML(true);
						$mail->Subject=_NLPROFITCALC_.$subj_zus;
						while (list($keye, $vale)=@each($alle_mails_kalk)) {
							$mail->AddAddress($vale);
						}
						$mail->Body='';
						if ($vorlagetext!='') {
                            if (!$cfg_mailversand_editor) {
                                $b_vorlagetext=nl2br($vorlagetext);
                                $b_vorlagetext2=nl2br($vorlagetext2);
                            } else {
                                $b_vorlagetext=$vorlagetext;
                                $b_vorlagetext2=$vorlagetext2;
                            }
							$b_vorlagetext=preg_replace('/<<mitarbeiter_telefon>>/', $absender_telefon, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<'.bef_format(_MITARBEITER_).'_'.bef_format(_TELEFON2_).'>>/', $absender_telefon, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<mitarbeiter>>/', $absender_name, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<'.bef_format(_MITARBEITER_).'>>/', $absender_name, $b_vorlagetext);
							$b_vorlagetext2=preg_replace('/<<mitarbeiter_telefon>>/', $absender_telefon, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<'.bef_format(_MITARBEITER_).'_'.bef_format(_TELEFON2_).'>>/', $absender_telefon, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<mitarbeiter>>/', $absender_name, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<'.bef_format(_MITARBEITER_).'>>/', $absender_name, $b_vorlagetext2);
							$ertragsrech='';
							if (function_exists('bruttoertrag_anzeige')) {
								$ertragsrech=bruttoertrag_anzeige($anr);
							}
							$b_vorlagetext=preg_replace('/<<ertragsrechnung>>/', $ertragsrech, $b_vorlagetext);
							$b_vorlagetext2=preg_replace('/<<ertragsrechnung>>/', $ertragsrech, $b_vorlagetext2);
							
							$b_vorlagetext=preg_replace('/<<kalk_bemerkung>>/', nl2br($postfeld['pc_bemerkung']), $b_vorlagetext);
							$b_vorlagetext2=preg_replace('/<<kalk_bemerkung>>/', nl2br($postfeld['pc_bemerkung']), $b_vorlagetext2);
							
							if ($_SESSION['crm_version']>60) {
								$ovkhilfen='';
								for ($vi=1; $vi<=10; $vi++) {
									if (isset($postfeld['vkh_progn'.$vi])) {
										if ($postfeld['vkh_progn'.$vi]!='') {
											$ovkhilfen.=$postfeld['vkh_progn'.$vi].': '.$postfeld['vkh_proge'.$vi].($postfeld['vkh_progp'.$vi]!=''?' ('.$postfeld['vkh_progp'.$vi].' %)':'').'<br>';
										}
									}
								}
								if ($ovkhilfen=='') {
									for ($vi=1; $vi<=10; $vi++) {
										if (isset($postfeld['vertrag5_vkhbez'.$vi])) {
											if ($postfeld['vertrag5_vkhbez'.$vi]!='') {
												$ovkhilfen.=$postfeld['vertrag5_vkhbez'.$vi].': '.$postfeld['vertrag5_vkh'.$vi].($postfeld['vkh_progp'.$vi]!=''?' ('.$postfeld['vertrag5_vkhp'.$vi].' %)':'').'<br>';
											}
										}
									}
								}
								$ovkhilfen=substr($ovkhilfen, 0, -4);
								
								$b_vorlagetext=preg_replace('/<<verkaufshilfen>>/', $ovkhilfen, $b_vorlagetext);
								$b_vorlagetext2=preg_replace('/<<verkaufshilfen>>/', $ovkhilfen, $b_vorlagetext2);
								
								$nachlaesse='';
								for ($vi=1; $vi<=10; $vi++) {
									if (isset($postfeld['vertrag5_sonderrpreis'.$vi])) {
										if ($postfeld['vertrag5_sonderrpreis'.$vi]!='') {
											$nachlaesse.=$postfeld['vertrag5_sonderr'.$vi].': '.$postfeld['vertrag5_sonderrpreis'.$vi].($postfeld['vertrag5_sonderrppreis'.$vi]!=''?' ('.$postfeld['vertrag5_sonderrppreis'.$vi].' %)':'').'<br>';
										}
									}
								}
							}
							$nachlaesse=substr($nachlaesse, 0, -4);
							$b_vorlagetext=preg_replace('/<<nachlaesse>>/', $nachlaesse, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<nachlaesse_text>>/', $nachlaesse, $b_vorlagetext);
							$b_vorlagetext2=preg_replace('/<<nachlaesse>>/', $nachlaesse, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<nachlaesse_text>>/', $nachlaesse, $b_vorlagetext2);
							
							$uvp_betrag=$postfeld['listenpreis5'];
							if (intval($postfeld['listenpreis5'])==0 and intval($postfeld['fin_preis2'])!=0) {
								$uvp_betrag=$postfeld['fin_preis2'];
							}
							$uvp_betrag=doubleval(p4n_mb_string('str_replace',',', '.', $uvp_betrag));
							if (doubleval($postfeld['vertrag5_farbepreis'])>0) {
								$uvp_betrag+=doubleval(number_format(doubleval(p4n_mb_string('str_replace',',', '.', $postfeld['vertrag5_farbepreis'])), 2, ".", ""));
							}
							if (doubleval($postfeld['vertrag5_trimpreis'])>0) {
								$uvp_betrag+=doubleval(number_format(doubleval(p4n_mb_string('str_replace',',', '.', $postfeld['vertrag5_trimpreis'])), 2, ".", ""));
							}
							for ($xi=1; $xi<500; $xi++) {
								if (isset($postfeld['vertrag5_sonder'.$xi])) {
									if (doubleval($postfeld['vertrag5_sonderpreis'.$xi])!=0) {
										$uvp_betrag+=doubleval(number_format(doubleval(p4n_mb_string('str_replace',',', '.', $postfeld['vertrag5_sonderpreis'.$xi])), 2, ".", ""));
									}
								}
							}
							
							$b_vorlagetext=preg_replace('/<<oppid>>/', $anr, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<datum>>/', adodb_date('d.m.Y', time()), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<uhrzeit>>/', adodb_date('H:i', time()), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<kundenname>>/', kundenbezeichnung($_SESSION['stammdaten_id']), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<verkaufspreis>>/', number_format(doubleval($summe), 2, ",", "."), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<uvp>>/', number_format(doubleval($uvp_betrag), 2, ",", "."), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<ber_summe>>/', number_format(doubleval($postfeld['marge2_betrag']), 2, ",", "."), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<ber_prozent>>/', number_format(doubleval($postfeld['marge2_prozent']), 2, ",", "."), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<ber_summe2>>/', number_format(doubleval($postfeld['marge2_betrag2']), 2, ",", "."), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<ber_prozent2>>/', number_format(doubleval($postfeld['marge2_prozent2']), 2, ",", "."), $b_vorlagetext);
							
							$b_vorlagetext=preg_replace('/<<standtage>>/', intval($kfz_standt), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<ekpreis>>/', number_format(doubleval($kfz_ekp), 2, ",", "."), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<fahrzeugstatus>>/', $kfz_fstatus, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<standort>>/', $pid_standort, $b_vorlagetext);
							
							$b_vorlagetext2=preg_replace('/<<oppid>>/', $anr, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<datum>>/', adodb_date('d.m.Y', time()), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<uhrzeit>>/', adodb_date('H:i', time()), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<kundenname>>/', kundenbezeichnung($_SESSION['stammdaten_id']), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<verkaufspreis>>/', number_format(doubleval($summe), 2, ",", "."), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<uvp>>/', number_format(doubleval($uvp_betrag), 2, ",", "."), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<ber_summe>>/', number_format(doubleval($postfeld['marge2_betrag']), 2, ",", "."), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<ber_prozent>>/', number_format(doubleval($postfeld['marge2_prozent']), 2, ",", "."), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<ber_summe2>>/', number_format(doubleval($postfeld['marge2_betrag2']), 2, ",", "."), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<ber_prozent2>>/', number_format(doubleval($postfeld['marge2_prozent2']), 2, ",", "."), $b_vorlagetext2);
							
							$b_vorlagetext2=preg_replace('/<<standtage>>/', intval($kfz_standt), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<ekpreis>>/', number_format(doubleval($kfz_ekp), 2, ",", "."), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<fahrzeugstatus>>/', $kfz_fstatus, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<standort>>/', $pid_standort, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<zusatz1>>/', $pid_zusatz1, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<refnr>>/', $kfz_haendlerstatus, $b_vorlagetext2);
							
							$m_ist_docx=$ist_docx;
							$ist_docx=false;
							$b_vorlagetext=ersetze_nwgwbed_felder($b_vorlagetext);
							$b_vorlagetext2=ersetze_nwgwbed_felder($b_vorlagetext2);
							$ist_docx=$m_ist_docx;
							
							$mail->Body=$b_vorlagetext;
							if ($p4n_editor) {
                                $mail->Body=p4n_mb_string('utf8_encode', $mail->Body);
                            }
							
							if ($doclink2!='') {
								$dateiname='';
								$xpl=explode('/', $doclink2);
								$mail->AddAttachment($doclink2, $xpl[count($xpl)-1], "base64", '');
							}
							
							$gesendet=$mail->Send();
							
							if ($fp2=fopen('inc/'.$_SESSION['cfg_kunde'].'/maillog.txt', 'a')) {
								fwrite($fp2, adodb_date('d.m.Y H:i:s', time()).': '.$row7[0].' '.($gesendet?_OK_:_FEHLER_).' - '.'Kalkulation'.$subj_zus.': '.$anr.' / '._BENUTZER_.': '.$_SESSION['mitarbeiter_name2']."\r\n");
								fclose($fp2);
							}
							
							if (count($alle_mails_kalk_dispo)>0) {
								$mail->Body=$b_vorlagetext2;
								if ($p4n_editor) {
    	                            $mail->Body=p4n_mb_string('utf8_encode', $mail->Body);
        	                    }
								$mail->ClearAllRecipients();
								$mail->ClearAttachments();
								$mail->ClearBCCs();
								while (list($keye, $vale)=@each($alle_mails_kalk_dispo)) {
									$mail->AddAddress($vale);
								}
								
								$gesendet=$mail->Send();
								if ($fp2=fopen('inc/'.$_SESSION['cfg_kunde'].'/maillog.txt', 'a')) {
									fwrite($fp2, adodb_date('d.m.Y H:i:s', time()).': '.$row7[0].' '.($gesendet?_OK_:_FEHLER_).' - '.'Dispo Kalkulation'.$subj_zus.': '.$anr.' / '._BENUTZER_.': '.$_SESSION['mitarbeiter_name2']."\r\n");
									fclose($fp2);
								}
								
							}
						}
					}
				}
				if (isset($postfeld['pc_final'])) {
					$db->update(
						$sql_tab['korrespondenz'],
						array(
							$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str($lkat.' - '._FERTIG_BEARBEITET_)
						),
						$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($kupdid)
					);
					$res2=$db->select(
						$sql_tab['benutzer'],
						array(
							$sql_tabs['benutzer']['vorname'],
							$sql_tabs['benutzer']['name']
						),
						$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id'])
					);
					$row2=$db->zeile($res2);
					$gen_ben1=$row2[1].', '.$row2[0];
					$db->update(
						$sql_tab['opportunity'],
						array(
							$sql_tabs['opportunity']['zusatz1'] => $db->str(_NLPROFITCALC_.': '._FERTIG_BEARBEITET_.' ('.adodb_date('d.m.Y H:i', time()).', '.$gen_ben1.')')
						),
						$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
					);
				}
				
				if (isset($getfeld['profitc_genehmigt']) or isset($getfeld['profitc_ablehnen'])) {
					$db->update(
						$sql_tab['korrespondenz'],
						array(
							$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str($lkat.' - '.(isset($getfeld['profitc_ablehnen'])?_DATENSCHUTZ1K_N_:_GENEHMIGT_))
						),
						$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($kupdid)
					);
					$res2=$db->select(
						$sql_tab['benutzer'],
						array(
							$sql_tabs['benutzer']['vorname'],
							$sql_tabs['benutzer']['name']
						),
						$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id'])
					);
					$row2=$db->zeile($res2);
					$gen_ben1=$row2[1].', '.$row2[0];
					$db->update(
						$sql_tab['opportunity'],
						array(
							$sql_tabs['opportunity']['zusatz1'] => $db->str(_NLPROFITCALC_.': '.(isset($getfeld['profitc_ablehnen'])?_DATENSCHUTZ1K_N_:_GENEHMIGT_).' ('.adodb_date('d.m.Y H:i', time()).', '.$gen_ben1.((isset($postfeld['pc_bemerkung']) and $postfeld['pc_bemerkung']!='')?' / '.$postfeld['pc_bemerkung']:'').')')
						),
						$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
					);
					if ($cfg_submitkv_profitc_konf) {
						if ($postfeld['freiekonf']=='1' or (($kfz_fstatus=='Neufahrzeug - konfiguriert' or $kfz_fstatus==_VEHICLE_CONFIGURED_) and $quelle!='GMEVC')) {
							$cfg_submitkv_profitc=true;
						} else {
							$cfg_submitkv_profitc=false;
						}
					}
					if ($cfg_submitkv_profitc_konf_nw) {
						$pid_opp=0;
						$pid_statcode=-1;
						$res5=$db->select(
							$sql_tab['opportunity'],
							$sql_tabs['opportunity']['produkt_id'],
							$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
						);
						if ($row5=$db->zeile($res5)) {
							$pid_opp=intval($row5[0]);
							if ($pid_opp>0) {
								$res5=$db->select(
									$sql_tab['produktzuordnung'],
									$sql_tabs['produktzuordnung']['fahrzeugstatus_code'],
									$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($pid_opp)
								);
								if ($row5=$db->zeile($res5)) {
									$pid_statcode=intval($row5[0]);
								}
							}
						}
						if ($postfeld['freiekonf']=='1' or ($pid_opp>0 and $pid_statcode==0) or (($kfz_fstatus=='Neufahrzeug - konfiguriert' or $kfz_fstatus==_VEHICLE_CONFIGURED_) and $quelle!='GMEVC')) {
							$cfg_submitkv_profitc=true;
						} else {
							$cfg_submitkv_profitc=false;
						}
					}
					if ($cfg_submitkv_profitc) {
						$res8=$db->select(
							$sql_tab['opportunity'],
							$sql_tabs['opportunity']['phase'],
							$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
						);
						$row8=$db->zeile($res8);
						if ($row8[0]==_OM_PHASE7_) {
							$res6=$db->select(
							$sql_tab['stammdaten_mandant'],
							array(
								$sql_tabs['stammdaten_mandant']['mandant_id'],
								$sql_tabs['stammdaten_mandant']['lagerort'],
								$sql_tabs['stammdaten_mandant']['nummer1'],
								$sql_tabs['stammdaten_mandant']['nummer2']
							),
							$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
								'('.$sql_tabs['stammdaten_mandant']['nummer1'].'!='.$db->str('').' or '.$sql_tabs['stammdaten_mandant']['nummer2'].'!='.$db->str('').')'
							);
							if ($row6=$db->zeile($res6)) {
								$res7=$db->select(
									$sql_tab['opportunity'],
									$sql_tabs['opportunity']['zusatz3'],
									$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
								);
								if ($row7=$db->zeile($res7)) {
									if ($row7[0]=='') {
										uebertrage_deal($anr);
									}
								}
							} else {
								echo javas('alert("'._FEHLER_KVUEBER_.'");');
							}
						}
					}
				}
				if ($cfg_kfzsuche_gerding and isset($getfeld['profitc_genehmigt'])) {
					echo javas('window.open("kfz_oppliste.php?dealid='.$anr.'&datum_von=&phase=-1&submit=OK&submitda=1&frameset_start=1", "main");');
				} else {
					echo javas('window.open("stammdaten_main.php?nav=OM&id='.$_SESSION['stammdaten_id'].'&frameset_start=1", "main");');
				}
			}
			if ($cfg_kfzsuche_pdf_join) {
				$lo='';
				@unlink('temp\\akv_alles_'.$_SESSION['user_id'].'.pdf');
				$lo2='gswin64c.exe -dNOPAUSE -sDEVICE=pdfwrite -sOUTPUTFILE=temp\\akv_alles_'.$_SESSION['user_id'].'.pdf -dBATCH ';
				@krsort($alle_pdfs);
				@reset($alle_pdfs);
				while (list($keyd, $vald)=@each($alle_pdfs)) {
					$lo='"'.str_replace('/', '\\', $vald).'" '.$lo;
				}
				exec($lo2.$lo, $cmdoutput);
				if (is_file('exiftool.exe')) {
					exec('exiftool.exe -Title="'.$bez_ang_kv.'" -Author="ABC" -Subject="'.$bez_ang_kv.'" -overwrite_original temp\\akv_alles_'.$_SESSION['user_id'].'.pdf', $cmdoutput2);
				}
				if (is_file('temp/akv_alles_'.$_SESSION['user_id'].'.pdf')) {
					echo javas('window.open("'.'temp/akv_alles_'.$_SESSION['user_id'].'.pdf'.'", "_blank");');
					link_dok_oeffnen('temp/akv_alles_'.$_SESSION['user_id'].'.pdf');
				}
				if ($fp=fopen('log_pdf.txt', 'w')) { fwrite($fp, $lo2.$lo."\r\n".javas('window.open("'.'temp/akv_alles_'.$_SESSION['user_id'].'.pdf'.'", "_blank");').print_r($alle_pdfs, true).print_r($cmdoutput, true).$lo); fclose($fp); }
			}
			die();
		} else {
			$doclink=$bez_ang_kv2.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'.rtf';
			if ($ist_docx) {
				$doclink=$bez_ang_kv2.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'.docx';
			}
			$doclink=dok_korr_sp($doclink, $bez_ang_kv2);
			
			$zus_dok=array();
			for ($akv_i=0; $akv_i<$anzahl_kv_kopie; $akv_i++) {
				$doclink_zus=$bez_ang_kv2.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'_'.$akv_i.'.rtf';
				if ($ist_docx) {
					$doclink_zus=$bez_ang_kv2.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'_'.$akv_i.'.docx';
				}
				$doclink_zus=dok_korr_sp($doclink_zus, $bez_ang_kv2);
				$doclink2='dokumente_korrespondenz/'.$doclink_zus;
				$doclink2_m='dokumente_korrespondenz/'.$doclink_zus;
				$inhalt_kunde_zus=$inhalt_kunde;
				$inhalt_kunde_zus=p4n_sb_strreplace('<<anr>>', $postfeld['stid'].'-'.$zus_anr[$akv_i], $inhalt_kunde_zus);
				$inhalt_kunde_zus=p4n_sb_strreplace('<<opp_id>>', $zus_anr[$akv_i], $inhalt_kunde_zus);
				if ($ist_docx) {
					$inhalt_kunde_zus=docx_schreiben($inhalt_kunde_zus);
				}
				if ($fp=fopen($doclink2, 'w')) {
					fwrite($fp, $inhalt_kunde_zus);
					fclose($fp);
				}
				if ($cfg_rtf2pdf) {
					$doclink2=check_rtf2pdf($doclink2, $cfg_rtf2pdf_sleep);
					if ($doclink2!=$doclink2_m) {
						$doclink2=str_replace('.rtf', '.pdf', $doclink2);
						$doclink_zus=str_replace('.rtf', '.pdf', $doclink_zus);
						if (!isset($zaepdfkop_sv)) {
							$zaepdfkop_sv=200;
						}
						$alle_pdfs[$zaepdfkop_sv]=$doclink2;
						$zaepdfkop_sv++;
					}
				}
				
				$zus_dok[$akv_i]=$doclink_zus;
				$weitere_kv[]=$doclink2;
				echo javas('window.open("'.$doclink2.'", "_blank");');
			}
			
			$doclink2='dokumente_korrespondenz/'.$doclink;
			$doclink3='';
			if ($fp=fopen($doclink2, 'w')) {
				$inhalt_kunde=p4n_sb_strreplace('<<anr>>', $postfeld['stid'].'-'.$anr, $inhalt_kunde);
				$inhalt_kunde=p4n_sb_strreplace('<<opp_id>>', $anr, $inhalt_kunde);
				if ($ist_docx) {
					$inhalt_kunde=docx_schreiben($inhalt_kunde);
				}
				fwrite($fp, $inhalt_kunde);
				fclose($fp);
				if ($doclink_t=='') {
					$doclink_t=$doclink2;
				} else {
					if ($cfg_rtf2pdf) {
						$doclink2=check_rtf2pdf($doclink2, $cfg_rtf2pdf_sleep);
						$doclink=str_replace('.rtf', '.pdf', $doclink);
						$doclink=str_replace('.docx', '.pdf', $doclink);
						$alle_pdfs[10]=$doclink2;
					}
				}
				if ($cfg_rtf2pdf) {
					$doclink_t2=check_rtf2pdf($doclink_t, $cfg_rtf2pdf_sleep);
					if ($doclink_t!=$doclink_t2) {
						$doclink=str_replace('.rtf', '.pdf', $doclink);
						$doclink=str_replace('.docx', '.pdf', $doclink);
						$alle_pdfs[10]=$doclink_t2;
					}
					$doclink_t=$doclink_t2;
				}
				echo javas('window.open("'.$doclink_t.'", "_blank");');
				$doclink3='';
				$doclink4='';
				$doclink5='';
				$doclink6='';
				if ($inhalt2!='') {
					$doclink3=$bez_ang_kv2.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_ankauf_'.$_SESSION['user_id'].'.rtf';
					$doclink3=dok_korr_sp($doclink3, $bez_ang_kv2.'_ankauf');
					$doclink4='dokumente_korrespondenz/'.$doclink3;
					if ($fp=fopen($doclink4, 'w')) {
						fwrite($fp, $inhalt2);
						fclose($fp);
					}
					if ($cfg_rtf2pdf) {
						$doclink4=check_rtf2pdf($doclink4, $cfg_rtf2pdf_sleep);
						$alle_pdfs[25]=$doclink4;
					}
					echo javas('window.open("'.$doclink4.'", "_blank");');
				}
				if ($inhalt4!='') {
					$doclink5=$bez_ang_kv2.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_widerruf_'.$_SESSION['user_id'].'.rtf';
					$doclink5=dok_korr_sp($doclink5, $bez_ang_kv2.'_widerruf');
					$doclink6='dokumente_korrespondenz/'.$doclink5;
					if ($fp=fopen($doclink6, 'w')) {
						fwrite($fp, $inhalt4);
						fclose($fp);
					}
					if ($cfg_rtf2pdf) {
						$doclink6=check_rtf2pdf($doclink6, $cfg_rtf2pdf_sleep);
						$doclink5=p4n_mb_string('str_replace', 'dokumente_korrespondenz/', '', $doclink6);
						$alle_pdfs[26]=$doclink6;
					}
					echo javas('window.open("'.$doclink6.'", "_blank");');
				}
				if ($inhalt9!='') {
					$doclink9=$bez_ang_kv2.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_sanktion_'.$_SESSION['user_id'].'.rtf';
					$doclink9=dok_korr_sp($doclink9, $bez_ang_kv2.'_sanktion');
					$doclink92='dokumente_korrespondenz/'.$doclink9;
					if ($fp=fopen($doclink92, 'w')) {
						fwrite($fp, $inhalt9);
						fclose($fp);
					}
					if ($cfg_rtf2pdf) {
						$doclink92=check_rtf2pdf($doclink92, $cfg_rtf2pdf_sleep);
						$alle_pdfs[29]=$doclink92;
					}
					echo javas('window.open("'.$doclink92.'", "_blank");');
				}
				if ($doclink9!='') {
					$weitere_kv[]=$doclink92;
				}
				
				if ($inhalt11!='') {
					$doclink11=$bez_ang_kv2.'_embargo_'.$_SESSION['user_id'].'.rtf';
					$doclink11='temp/'.$doclink11;
					if ($fp=fopen($doclink11, 'w')) {
						fwrite($fp, $inhalt11);
						fclose($fp);
					}
					if ($cfg_rtf2pdf) {
						$doclink11=check_rtf2pdf($doclink11, $cfg_rtf2pdf_sleep);
						$alle_pdfs[129]=$doclink11;
					}
					if ($cfg_kfzsuche_pdf_join and substr($doclink11, -4)=='.pdf') {
						
					} else {
						echo javas('window.open("'.$doclink11.'", "_blank");');
					}
				}
				if ($doclink11!='') {
					$weitere_kv[]=$doclink11;
				}
				
				if ($inhalt19!='') {
					$doclink19=$bez_ang_kv2.'_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_beratungsprotokoll_'.$_SESSION['user_id'].'.rtf';
					$doclink19=dok_korr_sp($doclink19, $bez_ang_kv2.'_beratungsprotokoll');
					$doclink192='dokumente_korrespondenz/'.$doclink19;
					$doclink192m=$doclink192;
					if ($fp=fopen($doclink192, 'w')) {
						fwrite($fp, $inhalt19);
						fclose($fp);
					}
					if ($cfg_rtf2pdf) {
						$doclink192=check_rtf2pdf($doclink192, $cfg_rtf2pdf_sleep);
						$alle_pdfs[2]=$doclink92;
						if ($doclink192m!=$doclink192) {
							$doclink19=str_replace('.rtf', '.pdf', $doclink19);
						}
					}
					echo javas('window.open("'.$doclink192.'", "_blank");');
				}
				if ($doclink19!='') {
					$weitere_kv[]=$doclink192;
					$alle_zus_korr_doks['Beratungsprotokoll']=$doclink19;
				}
				
				//link_dok_oeffnen($link1, $link2='', $link3='', $link4='', $link5='', $link6='', $weitere=array())
				link_dok_oeffnen($doclink_t, $doclink4, $doclink6, $doclink_bed, $doclink8, $doclink_befragung, $weitere_kv);
			}
			
			$lead_nicht_schliessen=false;
			$par_id=0;
			$par_id_opp=0;
			$kamp_id=0;
			$lead_id=0;
			$par_kat='';
			$lead_quelle='';
			$hat_bezug_act=false;
			if (intval($postfeld['kbezug'])>0) {
				$res3=$db->select(
					$sql_tab['korrespondenz'],
					array(
						$sql_tabs['korrespondenz']['kampagne_id'],
						$sql_tabs['korrespondenz']['lead_id'],
						$sql_tabs['korrespondenz']['betreff'],
						$sql_tabs['korrespondenz']['beschreibung'],
						$sql_tabs['korrespondenz']['opportunity_id'],
						$sql_tabs['korrespondenz']['kategorie'],
						$sql_tabs['korrespondenz']['quelle']
					),
					$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($postfeld['kbezug'])
				);
				if ($row3=$db->zeile($res3)) {
					$kamp_id=$row3[0];
					$lead_id=$row3[1];
					if ($cfg_avagneuanpassung2018 and $hat_eigkamp) {
						if ($kamp_id!=$kampa_id and intval($lead_id)>0) {
							$lead_nicht_schliessen=true;
						}
						$kamp_id=$kampa_id;
					}
					$par_id_opp=$row3[4];
					$par_kat=$row3[5];
					$lead_quelle=trim($row3[6]);
                    if ($lead_id && $_SESSION['crm_version_float'] >= 61004) {
                        $lead = new Lead_Data($lead_id);
                        if ($lead->load(array('lead_origin'))) {
                            if ($lead['lead_origin'] != '') {
                                $lead_quelle = $lead['lead_origin'];
                            }
                        }
                    }
					
					if ($par_kat==_PROBEFAHRT_) {
						$db->update(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['zusatzzahl_1'] => $db->dbzahl($postfeld['k_zusatz1']),
								$sql_tabs['korrespondenz']['zusatzzahl_2'] => $db->dbzahl($postfeld['k_zusatz2'])
							),
							$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($postfeld['kbezug'])
						);
						if (!$cfg_kfzsuche_holland and intval($postfeld['k_zusatz2'])>0 and intval($postfeld['pid'])>0) {
							include_once('inc/xml_io.php');
							carlo_km_stand_schreiben($postfeld['pid'], intval($postfeld['k_zusatz2']));
						}
						if ($cfg_kfzsuche_pf_notizen and isset($postfeld['k_pf_kfznotiz'])) {
							$res6=$db->select(
								$sql_tab['korrespondenz'],
								$sql_tabs['korrespondenz']['produktzuordnung_id'],
								$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($postfeld['kbezug'])
							);
							if ($row6=$db->zeile($res6)) {
								$k_pid=intval($row6[0]);
								if ($k_pid>0) {
									$db->update(
										$sql_tab['produktzuordnung'],
										array(
											$sql_tabs['produktzuordnung']['notizen'] => $db->str($postfeld['k_pf_kfznotiz'])
										),
										$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($k_pid)
									);
								}
							}
						}
						/*//BENZ
						if (class_exists('PearAutoloader')) {
							$td = new Event_Type_Com_TestdriveDone($_SESSION['user_id'], $_SESSION['stammdaten_id'], $postfeld['kbezug']);
							$td->call();
						}*/
					}
//					$anr=$par_id_opp;

					if (!p4n_mb_string('strpos',$row3[3], $ltext)) {
//						$ltext=$ltext.'<br><br>'.$row3[3];
					}
				}
				$par_id=$postfeld['kbezug'];
				
				$cce=0;
				$lds_dont_close=false;
				if ($lead_id>0 and $lead_quelle=='OFDB') {
					if ($par_kat==_PROBEFAHRT_) {
						include_once('inc/ofdb.php');
						$carl1=$postfeld['ofdb_carline'];
						if ($carl1=='-1') {
							$carl1='';
						}
					//	schreibe_ofdb_erg($lead_id, 'testdrive_scheduled', $postfeld['kbezug'], $carl1);
					}
					if ($bez_ang_kv==_KAUFVERTRAG_) {
						include_once('inc/ofdb.php');
						$carl1=$postfeld['ofdb_carline'];
						if ($carl1=='-1') {
							$carl1='';
						}
						schreibe_ofdb_erg($lead_id, '2500', $postfeld['kbezug'], $carl1);
					} elseif ($bez_ang_kv==_ANGEBOT_) {
						include_once('inc/ofdb.php');
						$carl1=$postfeld['ofdb_carline'];
						if ($carl1=='-1') {
							$carl1='';
						}
						schreibe_ofdb_erg($lead_id, 'offer_send', $postfeld['kbezug'], $carl1);
					}
				} elseif ($lead_id>0 and $lead_quelle=='Ford LDS') {
					if ($par_kat==_PROBEFAHRT_) {
						require_once 'inc/lds.inc.php';
						$lds_erg=updateLeadSpecific($lead_id, _PROBEFAHRT_GEMACHT_);
						if (is_array($lds_erg) && $lds_erg['error']===true) {
							echo javas('alert("'._FEHLER_.' LDS! \n'.$lds_erg['info'].'");');
							$lds_dont_close=true;
						} else {
							lds_korrupdate($lds_erg, _PROBEFAHRT_, _PROBEFAHRT_, 0);
						}
					}
					if ($bez_ang_kv==_KAUFVERTRAG_) {
						require_once 'inc/lds.inc.php';
						$lds_erg=updateLeadSpecific($lead_id, _SALE_MADE_.'___'.$postfeld['kfz_typmodell']);
						if (is_array($lds_erg) && $lds_erg['error']===true) {
							echo javas('alert("'._FEHLER_.' LDS! \n'.$lds_erg['info'].'");');
							$lds_dont_close=true;
						} else {
							lds_korrupdate($lds_erg, _KAUFVERTRAG_, _KAUFVERTRAG_, 0);
							updateLeadSpecific($lead_id, _LEAD_CLOSED_.'___11');
						}
					} elseif ($bez_ang_kv==_ANGEBOT_) {
						// keine Aktion
					}
				} elseif ($lead_id>0 and $lead_quelle=='Web Jassy') { // griga 31.03.2015 -->
					//$feld=$postfeld;
					/*if ($par_kat==_PROBEFAHRT_) {
						require_once 'inc/jassy.inc.php';
						$jassyTime = $feld['pfdatum'].' '.$feld['pfzeit'].':'.$feld['pfzeit2'].' - '.$feld['pfdatumb'].' '.$feld['pfzeitb'].':'.$feld['pfzeitb2'];
						$jassy_erg = updateLeadSpecific($lead_id, _PROBEFAHRT_, '', $jassyTime);
						if (is_array($jassy_erg) && $jassy_erg['error']===true) {
							echo javas('alert("'._FEHLER_.' Web Jassy! \n'.$jassy_erg['info'].'");');							
						} else {
							
						}						
					}*/
					/*if ($bez_ang_kv==_KAUFVERTRAG_) {
						require_once 'inc/jassy.inc.php';
						if ($feld['vertrag_nwgw']=='1') {
							$fzg_status = _GEBRAUCHTWAGEN_ABKUERZUNG_;
						} else {
							$fzg_status = _NEUWAGEN_ABKUERZUNG_;
						}
						$activityText = _VERTRAG_.' '.$fzg_status;
						$activityDescr = $feld['kfz_markencode'].' '.$feld['kfz_typmodell'].' ('.$feld['vertrag_finart'].')';
						$jassy_erg = updateLeadSpecific($lead_id, $activityText, $activityDescr);
						if (is_array($jassy_erg) && $jassy_erg['error']===true) {
							echo javas('alert("'._FEHLER_.' Web Jassy! \n'.$jassy_erg['info'].'");');
						} else {
							
						}
					} elseif ($bez_ang_kv==_ANGEBOT_) {
						require_once 'inc/jassy.inc.php';
						if ($feld['vertrag_nwgw']=='1') {
							$fzg_status = _GEBRAUCHTWAGEN_ABKUERZUNG_;
						} else {
							$fzg_status = _NEUWAGEN_ABKUERZUNG_;
						}
						$activityText = _ANGEBOT_.' '.$fzg_status;
						$activityDescr = $feld['kfz_markencode'].' '.$feld['kfz_typmodell'].' ('.$feld['vertrag_finart'].')';
						$jassy_erg = updateLeadSpecific($lead_id, $activityText, $activityDescr);
						if (is_array($jassy_erg) && $jassy_erg['error']===true) {
							echo javas('alert("'._FEHLER_.' Web Jassy! \n'.$jassy_erg['info'].'");');
						} else {
							
						}
					}*/ // --> griga 31.03.2015
				} elseif ($lead_id > 0 and $lead_quelle === 'Toyota') {
                    try {
                        switch ($bez_ang_kv) {
                            case _PROBEFAHRT_:
                                $activity = 'TestdrivePerformed';
                                break;
                            case _ANGEBOT_:
                                $activity = 'OfferCreated';
                                break;
                            case _KAUFVERTRAG_:
                                $activity = 'ClosedSuccessfully';
                                break;
                            default:
                                throw new Exception('Toyota Leads: unknown activity '.$bez_ang_kv.' ('.$lead_id.')');
                        }
						ToyotaLeads::instance()->updateLead($lead_id, $activity, $postfeld);
                        /*$getf = array(
                            'action'   => 'Send milestone',
                            'lead_id'  => $lead_id,
                            'activity' => $activity
                        );
                        require 'toyota_leads.php';*/
                    } catch (Exception $e) {
                        echo javas('alert("'.p4n_mb_string('htmlspecialchars', $e->getMessage()).'");');
                    }
                } elseif ($lead_id > 0 and $lead_quelle === 'Toyota AT') {
                    try {
                        switch ($bez_ang_kv) {
                            case _PROBEFAHRT_:
                                $activity = 'TESTDRIVE_TAKEN';
                                break;
                            case _ANGEBOT_:
                                $activity = 'OFFER';
                                break;
                            case _KAUFVERTRAG_:
                                $activity = 'CONTRACT';
                                break;
                            default:
                                throw new Exception('Toyota Leads: unknown activity '.$bez_ang_kv.' ('.$lead_id.')');
                        }
						ToyotaLeadsAT::instance()->updateLead($lead_id, $activity);
                    } catch (Exception $e) {
                        echo javas('alert("'.p4n_mb_string('htmlspecialchars', $e->getMessage()).'");');
                    }
                } elseif ($lead_id > 0 && $lead_quelle === 'Ferrari') {
                    try {
                        $flclosed = false;
                        switch ($bez_ang_kv) {
                            case _PROBEFAHRT_:
                                $activity = '___S05|Test Drive';
                                break;
                            case _ANGEBOT_:
                                $activity = '___S07|Quotation';
                                break;
                            case _KAUFVERTRAG_:
                                $activity = '___S09|Car Order';
                                $flclosed = true;
                                break;
                            default:
                                throw new Exception('Ferrari Leads: unknown activity '.$bez_ang_kv.' ('.$lead_id.')');
                        }
                        $getf = array(
                            'action'     => 'Send event',
                            'lead_id'    => $lead_id,
                            'event'      => _SALES_.$activity,
                            'closed'     => $flclosed
                        );
                        require 'ferrari_leads.php';
                    } catch (Exception $e) {
                        $error = $e->getMessage();
                        echo javas('alert("'.p4n_mb_string('htmlspecialchars', $error).'");');
                    }
                } elseif ($lead_id > 0 && $lead_quelle === 'KIA' && !empty($cfg_kia_leads)) {
                    try {
                        $flclosed = false;
                        switch ($bez_ang_kv) {
                            case _PROBEFAHRT_:
                                $activity = 5;
                                break;
                            case _ANGEBOT_:
                                $activity = 8;
                                break;
                            case _KAUFVERTRAG_:
                                if (stristr($postfeld['kfz_markencode'], 'kia')) {
                                    $activity = 10;
                                } else {
                                    $activity = 11;
                                }
                                $flclosed = true;
                                break;
                            default:
                                throw new Exception('KIA Leads: unknown activity '.$bez_ang_kv.' ('.$lead_id.')');
                        }
                        $kiaResult = KiaLeads::instance()->updateLead($lead_id, $activity);
                    } catch (Exception $e) {
                        $error = $e->getMessage();
                        echo javas('alert("'.p4n_mb_string('htmlspecialchars', $error).'");');
                    }
                } elseif ($lead_id>0) {
					$feld=$postfeld;
					
					if ($cfg_leadengine_version_slmi5) {
						$cce=lead_checkcc($lead_id);
						if ($cce>=2) {
							if ($cce==2) {
								echo javas('alert("'._LEAD_.': '._LEADIT_CCLEAD_.' '._LEADIT_OFFEN_.'");');
							}
							if ($cce==3) {
								echo javas('alert("'._LEAD_.': '._LEADIT_CCLEAD3_.'");');
							}
						}
					}
					
					if ($cce<=1 and $par_kat==_PROBEFAHRT_) {
						include_once('inc/gmlead.php');
						$feld['kerg_neu']=_PROBEFAHRT_;
						$korrespondenz_art = array('contacted' => true);
						le_updatelead($lead_id, $korrespondenz_art);
					}
					
					if ($bez_ang_kv==_KAUFVERTRAG_) {
						if ($cfg_leadengine_version==5 and !$cfg_leadengine_version_slmi6) {	// and !$cfg_leadengine_version_slmi5
							$feld['kerg_neu']=_KAUFVERTRAG_.'___URL';
						} elseif ($feld['le_neugeb']=='0') {
							$feld['kerg_neu']=_KAUFVERTRAG_.'___KAUF_NEU';
						} else {
							$feld['kerg_neu']=_KAUFVERTRAG_.'___KAUF_GBR';
						}
					} elseif ($bez_ang_kv==_ANGEBOT_) {
						$feld['kerg_neu']=_ANGEBOT_;
					}
					if ($cce<=1) {
						include_once('inc/gmlead.php');
                        $korrespondenz_art = array('contacted' => true);
                        if ($bez_ang_kv==_KAUFVERTRAG_) {
                            $korrespondenz_art = array('contacted' => false, 'close' => true);
                        }
						le_updatelead($lead_id, $korrespondenz_art);
					}
                    if (!empty($cfg_toyota_toca) && !empty($cfg_toyota_leads) && $lead_quelle !== 'Makros') {
                        try {
                            switch ($bez_ang_kv) {
                                case _PROBEFAHRT_:
                                    $activity = 'TestdrivePerformed';
                                    break;
                                case _ANGEBOT_:
                                    $activity = 'OfferCreated';
                                    break;
                                default:
                                    $activity = NULL;
                            }
                            if ($activity) {
                                ToyotaLeads::instance()->updateNotToyotaLead($lead_id, $activity, $postfeld);
                            }
                        } catch (Exception $e) {
                            //$fehler_nicht_schliessen = true;
                            $error = $e->getMessage();
                            $zus_erg_text2 = $error;
                            echo javas('alert("'.p4n_mb_string('htmlspecialchars', $error).'");');
                        }
                    }
				}
				
				if (isset($postfeld['aang_schl']) or $bez_ang_kv==_ANGEBOT_) {
					if ($cce==2 and $bez_ang_kv==_KAUFVERTRAG_) {
						
					} elseif (!$lds_dont_close and !$lead_nicht_schliessen) {
						parent_k_schliessen($par_id, true);
					}
				} else {
					if ($cce==2 and $bez_ang_kv==_KAUFVERTRAG_) {
						
					} elseif (!$lds_dont_close and !$lead_nicht_schliessen) {
						parent_k_schliessen($par_id, true, $par_id_opp);
					}
				}

                if ($lead_id > 0 && in_array($lead_quelle, array('Ford LDS', 'Toyota', 'Ferrari'))) {
                    if (class_exists('Interface_Main')) {
                        Interface_Main::addLeadLog($lead_quelle, array('customers' => array($_SESSION['stammdaten_id'])));
                    }
                }
			}
			if (intval($par_id)>0) {
				if ($par_kat==_PROBEFAHRT_) {
					if (!$cfg_carlo_appserver_activity_keinekorr and $cfg_carlo_appserver_activity) {
							if ($postfeld['k3_activity']!='-1') {
								if ($postfeld['k3_activityerg']=='-1') {
									$postfeld['k3_activityerg']='';
								}
								include_once('inc/xml_io.php');
								edsxml_write_activity($par_id, $postfeld['k3_activity'], $postfeld['k3_activityerg']);
								$hat_bezug_act=true;
							}
					}
				} else {
						if (!$cfg_carlo_appserver_activity_keinekorr and $cfg_carlo_appserver_activity) {
							if ($postfeld['k_activity']!='-1') {
								if ($postfeld['k_activityerg']=='-1') {
									$postfeld['k_activityerg']='';
								}
								include_once('inc/xml_io.php');
								edsxml_write_activity($par_id, $postfeld['k_activity'], $postfeld['k_activityerg']);
								$hat_bezug_act=true;
							}
						}
				}
			}
			
			$erled=true;
			$wvl1=0;
			
			$basis_time=time();
			if ($cfg_kfzsuche_zusatzdatum_kvdatum and $postfeld['zusatzdatum1']!='') {
				$basis_time=adodb_mktime(adodb_date('H', time()), adodb_date('i', time()), 0, substr($postfeld['zusatzdatum1'], 3,2), substr($postfeld['zusatzdatum1'], 0,2), substr($postfeld['zusatzdatum1'], 6,4));
			}
			
			if ($bez_ang_kv==_ANGEBOT_ or $bez_ang_kv==_EXPOSE_ or (!$cfg_db_kaufrecht2022 and $bez_ang_kv=='Vorvertragsinformation')) {
				$erled=false;
				$stunden_wvl=24;
				if (isset($cfg_kfzsuche_angebot_wvl_stunden_alle)) {
					if ($cfg_kfzsuche_angebot_wvl_stunden_alle>0) {
						$stunden_wvl=$cfg_kfzsuche_angebot_wvl_stunden_alle;
					}
				}
				$benutzer_betreuerid=$_SESSION['user_id'];
				if (isset($cfg_angebot_wvl_stunden)) {
					$res88=$db->select(
						$sql_tab['stammdaten'],
						$sql_tabs['stammdaten']['betreuer'],
						$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
					);
					if ($row88=$db->zeile($res88)) {
						$benutzer_betreuerid=intval($row88[0]);
					}
					if (isset($cfg_angebot_wvl_stunden[$benutzer_betreuerid])) {
						if (intval($cfg_angebot_wvl_stunden[$benutzer_betreuerid])>0) {
							$stunden_wvl=intval($cfg_angebot_wvl_stunden[$benutzer_betreuerid]);
						}
					}
				}
				$wvl1=$db->dbtimestamp($basis_time+$stunden_wvl*60*60);
			}
            if (!empty($postfeld['kwvl1'])) {
                $wvl1 = $db->dbzeitdatum($postfeld['kwvl1'], $postfeld['kwvl1_z'].':'.$postfeld['kwvl1_z2']);
            }
			if ($cfg_db_kaufrecht2022 and $bez_ang_kv=='Vorvertragsinformation') {
				$erled=false;
				$wvl1=$db->dbtimestamp(time());
			}
			if ($postfeld['angebot2']=='1') {
				$bez_ang_kv=_ANGEBOT2_;
			}
			
			// Neu:
			$ltext2='';
			@reset($mpostfeld);
			while (list($pkey, $pval)=@each($mpostfeld)) {
				if ($pkey!='neukunde' and $pkey!='infotextz2') {
					if (is_array($pval)) {
						while (list($pkey2, $pval2)=@each($pval)) {
							$ltext2.=$pkey.'['.$pkey2.']==='.$pval2."#####";
						}
					} else {
						$ltext2.=$pkey.'==='.$pval."#####";
					}
				}
			}
			
			if (1) {
				if (isset($mpostfeld['vertrag_lagerort'])) {
					$res7=$db->select(
						$sql_tab['mandant'],
						array(
							$sql_tabs['mandant']['bezeichnung'],
							$sql_tabs['mandant']['firma']
						),
						$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($mpostfeld['vertrag_lagerort'])
					);
					if ($row7=$db->zeile($res7)) {
						$bez_mandlao=$row7[0];
						if ($row7[1]!='') {
							$bez_mandlao=$row7[1];
						}
						$ltext2.='fozus_lagerort==='.$bez_mandlao."#####";
					}
				}
				if (isset($mpostfeld['rechnungsempfaenger'])) {
					if (intval($mpostfeld['rechnungsempfaenger'])>0) {
						$res7=$db->select(
							$sql_tab['stammdaten_mandant'],
							array(
								$sql_tabs['stammdaten_mandant']['nummer1']
							),
							$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($mpostfeld['rechnungsempfaenger'])
						);
						if ($row7=$db->zeile($res7)) {
							$ltext2.='fozus_rechnungsempfaengerdeb==='.$row7[0]."#####";
						}
					}
				}
				$ltext2.='fozus_lpreissum==='.$merke_lpreis_sum_br."#####";
				$merke_nachl_proz_sum=0;
				$merke_nachl_betrag_sum=0;
				for ($auss_i=1; $auss_i<=50; $auss_i++) {
					if (isset($postfeld['vertrag'.$ve_zus.'_sonderrppreis'.$auss_i])) {
						$nl_p1=doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrppreis'.$auss_i]));
						$merke_nachl_proz_sum+=$nl_p1;
					}
					if (isset($postfeld['vertrag'.$ve_zus.'_sonderrpreis'.$auss_i])) {
						$nl_p1=doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrpreis'.$auss_i]));
						$merke_nachl_betrag_sum+=$nl_p1;
					}
				}
				$ltext2.='fozus_nlprozsum==='.number_format($merke_nachl_proz_sum, 2, ",", "")."#####";
				$ltext2.='fozus_fbn2==='.$merke_fbn."#####";
				$ltext2.='fozus_fbn==='.$merke_fid."#####";
				$ltext2.='fozus_fid==='.$merke_fid."#####";
			}
			
			$betre=$bez_ang_kv.' '.number_format(doubleval($gespreis), 2, ",", ".").' '.$waehrung_eur;	// $summe
			if ($bez_ang_kv2=='expose') {
				$betre=$bez_ang_kv;
			}
			if ($postfeld['vertrag_nwgw']=='1' and doubleval(str_replace(',', '.', $postfeld['fin_preis2']))>0) {
				$betre=$bez_ang_kv.' '.number_format(doubleval($opp_summe), 2, ",", ".").' '.$waehrung_eur;
			}
			if (isset($postfeld['konf_markencode'])) {
			//	$betre=$postfeld['konf_markencode'].' '.$postfeld['konf_typmodell2'].' '.number_format($gespreis, 2, ",", ".").' ';
			}
			
			if ($bez_ang_kv2!='expose' and $sonstiges2!='') {
				$ltext.="\n\n"._SONST_VEREINBARUNGEN_.': '.$sonstiges2;
			}
			if (isset($postfeld['teilebestellung']) and $postfeld['teilebestellung']!='' and $postfeld['teilebestellung_email']!='') {
				$ltext.="\n\n".'Teilebestellung'.' ('.$postfeld['teilebestellung_email'].'):'."\n".$postfeld['teilebestellung'];
			}
			
			if (!$cfg_db_kaufrecht2022 and $bez_ang_kv2=='vvi') {
				$erled=false;
				$betre=_VVI_;
				$ltext='';
				$ltext.='Abweichungen der Kaufsache: '.(isset($postfeld['vvi_1'])?'ja':'nein')."\n";
				if ($postfeld['abweichung1']!='') {
					$ltext.='Text: '.$postfeld['abweichung1']."\n";
				}
				$ltext.='Verk�rzung der Verj�hrungsfrist: '.(isset($postfeld['vvi_2'])?'ja':'nein')."\n";
				$ltext.='Ausschluss der gesetzlichen Aktualisierungspflicht: '.(isset($postfeld['vvi_3'])?'ja':'nein')."\n";
				$ltext.='Ausschluss der Beweislastumkehr beim Verkauf digitaler Produkte: '.(isset($postfeld['vvi_4'])?'ja':'nein')."\n";
			}
			
			if ($bez_ang_kv2=='skv') {
				$ltext='';
				$skv_ids='';
				$anz_skv=0;
				$ges_su=0;
				foreach ($postfeld['skv_preis'] as $skvpid => $skvpreis) {
					$res3=$db->select(
						$sql_tab['produktzuordnung'],
						array(
							$sql_tabs['produktzuordnung']['fahrgestell'],
							$sql_tabs['produktzuordnung']['markencode'],
							$sql_tabs['produktzuordnung']['typ_modell'],
							$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'],
							$sql_tabs['produktzuordnung']['hersteller'],
							$sql_tabs['produktzuordnung']['differenzbesteuerung'],	// 5
							$sql_tabs['produktzuordnung']['datum_ez'],
							$sql_tabs['produktzuordnung']['buchnummer']
						),
						$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($skvpid)
					);
					$alle_skvpreise=array();
					if ($row3=$db->zeile($res3)) {
						$anz_skv++;
						$skv_ids.=$skvpid.',';
						$skpreis=doubleval($row3[3]);
						if (doubleval(str_replace(',', '.', $skvpreis))>0) {
							$skpreis=doubleval(str_replace(',', '.', $skvpreis));
						}
						$alle_skvpreise[$skvpid]=$skpreis;
						$ges_su+=$skpreis;
						$skvid=$row3[4];
						if ($skvid=='') {
							$skvid=$row3[7];
						}
						$ltext.=$anz_skv.'. '.$row3[1].' '.$row3[2].' - '.$skvid.($row3[6]!=''?', '._KFZ_EZ_.' '.$db->unixdate($row3[6]):'').': '.number_format(doubleval($skpreis), 2, ",", ".")."\n";
					}
				}
				$ltext.=_SUMME_.': '.number_format(doubleval($ges_su), 2, ",", ".");
				$betre=_SAMMELKV_.' '.$anz_skv.' '._FAHRZEUGE_.' ('.number_format(doubleval($ges_su), 2, ",", ".").')';
				$postfeld['pid']=0;
				$skv_ids=substr($skv_ids, 0, -1);
				$db->update(
					$sql_tab['opportunity'],
					array(
						$sql_tabs['opportunity']['betrag'] => $db->dbzahl($ges_su),
						$sql_tabs['opportunity']['betrag_ist'] => $db->dbzahl($ges_su),
						$sql_tabs['opportunity']['produkt_id'] => $db->dbzahl(0),
						$sql_tabs['opportunity']['bemerkung'] => $db->str($ltext),
						$sql_tabs['opportunity']['angebot_details'] => $db->str($ltext2),
						$sql_tabs['opportunity']['bezeichnung'] => $db->str(trim($betre)),
						$sql_tabs['opportunity']['order_info'] => $db->str($skv_ids)
					),
					$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
				);
				$db->delete(
					$sql_tab['produktzuordnung_skv'],
					$sql_tabs['produktzuordnung_skv']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id'])
				);
				$db->update(
					$sql_tab['produktzuordnung'],
					array(
						$sql_tabs['produktzuordnung']['vkinfo_carlo'] => $db->str('verkauft'),
						$sql_tabs['produktzuordnung']['lock_benutzer'] => $db->dbzahl(0),
						$sql_tabs['produktzuordnung']['kaufvertrag'] => $db->dblogic(true),
						$sql_tabs['produktzuordnung']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
						$sql_tabs['produktzuordnung']['kaufvertrag_kunde'] => $db->dbzahl($_SESSION['stammdaten_id']),
						$sql_tabs['produktzuordnung']['angebot'] => $db->dblogic(false),
						$sql_tabs['produktzuordnung']['angebot_kunde'] => $db->dbzahl(0),
						$sql_tabs['produktzuordnung']['angebot2'] => $db->dblogic(false),
						$sql_tabs['produktzuordnung']['angebot2_kunde'] => $db->dbzahl(0),
						$sql_tabs['produktzuordnung']['merkeverkauf_benutzer'] => $db->dbzahl(0),
						$sql_tabs['produktzuordnung']['merkeverkauf_datum'] => $db->dbdate('')
					),
					$db->dbzahlin($skv_ids, $sql_tabs['produktzuordnung']['produktzuordnung_id'])
				);
				$skvpid_arr=explode(',', $skv_ids);
				$dvm_vkmeld='';
				if ($cfg_dvs_fm) {
				foreach ($skvpid_arr as $skvpid1) {
					$diffbest1=false;
					$res5=$db->select(
						$sql_tab['produktzuordnung'],
						array(
							$sql_tabs['produktzuordnung']['hersteller'],
							$sql_tabs['produktzuordnung']['differenzbesteuerung']
						),
						$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($skvpid1)
					);
					if ($row5=$db->zeile($res5)) {
						if ($row5[1]=='1') {
							$diffbest1=true;
						}
						if (p4n_mb_string('strlen',$row5[0])>10 or ($cfg_dvs_fm and $row5[0]!='')) {
							$postfeld['dvs_id']=$row5[0];
						}
					}
					
					$dpreis=$alle_skvpreise[$skvpid1];
					$dnetto=doubleval($dpreis*100/(100+(100*$cfg_mwst)));
					$ust1=$dpreis-$dnetto;
					$liefert=time();
					if (isset($postfeld['vertrag_liefertermin']) and $postfeld['vertrag_liefertermin']!='') {
						$datum_lt=$postfeld['vertrag_liefertermin'];
						$liefert=adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_lt,3,2),p4n_mb_string('substr',$datum_lt,0,2),p4n_mb_string('substr',$datum_lt,6,4) );
					} elseif (isset($postfeld['vertrag_liefertermin1'])) {
						if ($cfg_kfzsuche_liefertermin_monatjahr) {
							$liefert=adodb_mktime(12,0,0, $postfeld['vertrag_liefertermin1monat'], 1, $postfeld['vertrag_liefertermin2']);
						} else {
							$liefert=strtotime($postfeld['vertrag_liefertermin2'].'W'.(strlen($postfeld['vertrag_liefertermin1'])==1?'0':'').$postfeld['vertrag_liefertermin1']);
						}
					}
					$auslt=$liefert;
					include_once('webservice/nusoap.php');
					$sf_ar=array();
					$sf_ar['Verkauf']=array(
					'hasChanges' => true,
					'Verkauf_ID' => -1,
					'Verkaeufer_ID' => intval($dvs_username),
					'Datum_Verkauf' => timestamp_to_iso8601(time()),
					'Datum_Auslieferung_geplant' => timestamp_to_iso8601($auslt),
					'Datum_Auslieferung_erfolgt' => timestamp_to_iso8601($auslt),
					'Betrag_Verkaufspreis_netto' => doubleval($dnetto),
					'Betrag_Verkaufspreis_MWST_Satz' => doubleval($cfg_mwst*100),
					'Betrag_Verkaufspreis_MWST' => doubleval($ust1),
					'Betrag_Verkaufspreis_Brutto' => doubleval($dpreis),
					'Kunden_ID' => $_SESSION['stammdaten_id'],
					'Abnehmergruppe' => '0',
					'Finanzierung' => 0,
					'Garantie' => 0,
					'Versicherung' => 0,
					'Aufmerksam' => 0,
					'GW_Marke' => 0
					);
					if (isset($postfeld['vertrag_eugeschaeft'])) {
						$sf_ar['Verkauf']['Betrag_Verkaufspreis_MWST_Satz']=0;
						$sf_ar['Verkauf']['Betrag_Verkaufspreis_MWST']=0;
						$sf_ar['Verkauf']['Betrag_Verkaufspreis_Brutto']=doubleval($dnetto);
					} elseif ($diffbest1) {
						$sf_ar['Verkauf']['Betrag_Verkaufspreis_MWST_Satz']=0;
						$sf_ar['Verkauf']['Betrag_Verkaufspreis_MWST']=0;
						$sf_ar['Verkauf']['Betrag_Verkaufspreis_netto']=doubleval($dpreis);
					}
					$sf_ar['F_UID']=$postfeld['dvs_id'];
					
					$client = new nusoap_client($cfg_dvs_ws, true);
					if ($cfg_dvs_fm) {
						$client->soap_defencoding = 'UTF-8';
					}
					$result = $client->call("sellFahrzeug", dvsfm_para(array('SellCar' => $sf_ar), "sellFahrzeug"), dvsfm_ns());
					$result=dvsfm_res($result);
					if ($dvs_ws_logging_sf) {
						if ($dvs_ws_logging_alert) {
							echo javas('alert("'.p4n_mb_string('substr',str_replace(array('"', "\n", "\r"), '', $client->request), 0, 1000).'");');
							echo javas('alert("'.p4n_mb_string('substr',str_replace(array('"', "\n", "\r"), '', $client->response), 0, 1000).'");');
						}
						if ($fp=fopen('log/dvs/crm2dvs_sellFahrzeug_request_.'.adodb_date('d_m_Y_His').'_'.$skvpid1.'.xml', 'w')) {
							fwrite($fp, $client->request);
							fclose($fp);
						}
						if ($fp=fopen('log/dvs/crm2dvs_sellFahrzeug_.'.adodb_date('d_m_Y_His').'_'.$skvpid1.'.xml', 'w')) {
							fwrite($fp, $client->response);
							fclose($fp);
						}
					}
					
					if ($cfg_dvs_fm) {
						if ($fp=fopen('log/dvs/crm2dvs_sellFahrzeug_result_'.adodb_date('d_m_Y_His').'_'.$skvpid1.'.txt', 'w')) {
							fwrite($fp, print_r($result, true));
							fclose($fp);
						}
						if (isset($result['beschreibung'])) {
							$dvm_vkmeld.=$postfeld['dvs_id'].': '.$result['beschreibung'].', ';
						//	echo javas('alert("Verkaufsstatus FM: '.$result['beschreibung'].'");');
						} else {
							$dvm_vkmeld.=$postfeld['dvs_id'].': Fehler, ';
						//	echo javas('alert("Verkaufsstatus FM: Fehler");');
						}
					}
				}
				if ($cfg_dvs_fm) {
					$dvm_vkmeld=substr($dvm_vkmeld, 0, -2);
					echo javas('alert("Verkaufsstatus FM: '.$dvm_vkmeld.'");');
				}
				}
				unset($postfeld['dvs_id']);
				unset($postfeld['pid']);
			}
			
			$kfeld=array(
								$sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['wvl_datum1'] => $wvl1,
								$sql_tabs['korrespondenz']['wvl_datum2'] => 0,
								$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
								$sql_tabs['korrespondenz']['ansprechpartner_id'] => $db->dbzahl($apid),
								$sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
								$sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['eingang'] => 0,
								$sql_tabs['korrespondenz']['art'] => $db->dbzahl(11),
								$sql_tabs['korrespondenz']['kategorie'] => $db->str($bez_ang_kv),
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic($erled),
								$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($par_id),
								$sql_tabs['korrespondenz']['doclink'] => $db->str($doclink),
								$sql_tabs['korrespondenz']['betreff'] => $db->str($betre),
								$sql_tabs['korrespondenz']['beschreibung'] => $db->str($ltext),
								$sql_tabs['korrespondenz']['zusatz1'] => $db->str($ltext2),
								$sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl($postfeld['pid']),
								$sql_tabs['korrespondenz']['papierkorb'] => 0,
								$sql_tabs['korrespondenz']['kalender_id'] => 0,
								$sql_tabs['korrespondenz']['prioritaet'] => 0,
								$sql_tabs['korrespondenz']['negativ'] => 0,
								$sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_nr'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(($kamp_id>0?$kamp_id:$kampa_id)),
								$sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl($lead_id),
								$sql_tabs['korrespondenz']['quelle'] => $db->str($lead_quelle),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str($bez_ang_kv),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str($bez_ang_kv),
								$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($ang_kv_user)
		);
		if ($cfg_kfzsuche_zusatzdatum_kvdatum and $postfeld['zusatzdatum1']!='') {
			$kfeld[$sql_tabs['korrespondenz']['datum']]=$db->dbtimestamp($postfeld['zusatzdatum1'], adodb_date('H', time()), adodb_date('i', time()), 0);
		}
		
		if (isset($postfeld['co_stid'])) {
			if (intval($postfeld['co_stid'])>0) {
				$kfeld[$sql_tabs['korrespondenz']['stammdaten_id2']]=$db->dbzahl($postfeld['co_stid']);
			}
		}
		
		if (isset($cfg_kfzsuche_akv_keinewvl) and @in_array($_SESSION['stammdaten_id'], $cfg_kfzsuche_akv_keinewvl)) {
			$kfeld[$sql_tabs['korrespondenz']['wvl_datum1']]=0;
			$kfeld[$sql_tabs['korrespondenz']['erledigt']]=$db->dblogic(true);
			$kfeld[$sql_tabs['korrespondenz']['kampagne_id']]=$db->dbzahl(0);
			$kfeld[$sql_tabs['korrespondenz']['kategorie']]=$db->str('Preis '.$bez_ang_kv);
			$kfeld[$sql_tabs['korrespondenz']['ergebnis_kategorie']]=$db->str('Preis '.$bez_ang_kv);
			if ($anr>0) {
				$db->delete(
					$sql_tab['opportunity'],
					$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
				);
				$anr=0;
			}
		}
		
		if ($ist_mitdummy and ( p4n_mb_string('substr',$_SESSION['cfg_kunde'], 0, 15)=='carlo_opel_avag' or $cfg_kfzsuche_dummy_keinewvl )) {
			$kfeld[$sql_tabs['korrespondenz']['wvl_datum1']]=0;
			$kfeld[$sql_tabs['korrespondenz']['erledigt']]=$db->dblogic(true);
		}
		if (p4n_mb_string('substr',$_SESSION['cfg_kunde'], 0, 15)=='carlo_opel_avag' or $_SESSION['cfg_kunde']=='carlo_opel_psaretail') {
			$res2=$db->select(
				$sql_tab['stammdaten_gruppe'],
				$sql_tabs['stammdaten_gruppe']['gruppe_id'],
				$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str('keine Angebotswiedervorlage')
			);
			if ($row2=$db->zeile($res2)) {
				$res2=$db->select(
						$sql_tab['stammdaten_gruppe_zuordnung'],
						$sql_tabs['stammdaten_gruppe_zuordnung']['gruppe_id'],
						$sql_tabs['stammdaten_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row2[0]).' and '.
							$sql_tabs['stammdaten_gruppe_zuordnung']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
				);
				if ($db->anzahl($res2)>0) {
					$kfeld[$sql_tabs['korrespondenz']['wvl_datum1']]=0;
					$kfeld[$sql_tabs['korrespondenz']['erledigt']]=$db->dblogic(true);
				}
			}
		}
		
		tempdateien('dokumente_korrespondenz/'.$doclink, $doclink, $bez_ang_kv.' '.kundenbezeichnung($_SESSION['stammdaten_id']));
		
		// Kauf an Kroa-WS �bermitteln
		if (!$cfg_kfz_webservice_mitkunde and !$vorschau and $bez_ang_kv==_KAUFVERTRAG_ and $cfg_kfz_webservice and intval($postfeld['pid'])>0) {
			ws_kroa_kfz($postfeld['pid'], 1, '', 0, 0, 'dokumente_korrespondenz/'.$doclink);
		}
		
		if ($cfg_kfzsuche_wvlangebot_eins) {
			$res8=$db->select(
				$sql_tab['korrespondenz'],
				$sql_tabs['korrespondenz']['korrespondenz_id'],
				$sql_tabs['korrespondenz']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.$sql_tabs['korrespondenz']['erledigt'].'='.$db->dblogic(false)
			);
			if ($db->anzahl($res8)>0) {
				$kfeld[$sql_tabs['korrespondenz']['wvl_datum1']]=0;
				$kfeld[$sql_tabs['korrespondenz']['erledigt']]=$db->dblogic(true);
			}
		}
		
		if (!$cfg_db_kaufrecht2022 and $bez_ang_kv2=='vvi') {
			$kfeld[$sql_tabs['korrespondenz']['ergebnis_datum']]=$db->dbdate('');
			$kfeld[$sql_tabs['korrespondenz']['ergebnis_benutzer_id']]=$db->dbzahl(0);
			$kfeld[$sql_tabs['korrespondenz']['ergebnis_kategorie']]=$db->str('');
			$kfeld[$sql_tabs['korrespondenz']['ergebnis_text']]=$db->str('');
		}
		
		if ($anr>0) {
			$kfeld[$sql_tabs['korrespondenz']['opportunity_id']]=$db->dbzahl($anr);
		}
		
		if (isset($postfeld['kia_typ'])) {
			$kfeld[$sql_tabs['korrespondenz']['kanal']]=$db->str($postfeld['kia_typ'].';'.$postfeld['kia_motor'].';'.$postfeld['kia_bauart']);
		}
		
		$capps_keinek=true;
		
		if ($inhalt9!='') {
			$kfeld9=$kfeld;
			$kfeld9[$sql_tabs['korrespondenz']['kategorie']]=$db->str('Sanktionsabfrage');
			$kfeld9[$sql_tabs['korrespondenz']['art']]=$db->dbzahl(14);
			$kfeld9[$sql_tabs['korrespondenz']['eingang']]=$db->dbzahl(1);
			$kfeld9[$sql_tabs['korrespondenz']['doclink']]=$db->str(str_replace('dokumente_korrespondenz/', '', $doclink92));
			$kfeld9[$sql_tabs['korrespondenz']['betreff']]=$db->str('Sanktionsabfrage');
			$kfeld9[$sql_tabs['korrespondenz']['beschreibung']]=$db->str($sankt_beschr);
			
			$kfeld9[$sql_tabs['korrespondenz']['wvl_datum1']]=0;
			tempdateien($doclink92, str_replace('dokumente_korrespondenz/', '', $doclink92), $bez_ang_kv.' Sanktionsabfrage '.kundenbezeichnung($_SESSION['stammdaten_id']));
			$kfeld9[$sql_tabs['korrespondenz']['zusatz1']]=$db->str('');
			$kfeld9[$sql_tabs['korrespondenz']['ergebnis_text']]=$db->str($sankt_erg);
			$kfeld9[$sql_tabs['korrespondenz']['erledigt']]=$db->dblogic(true);
			$db->insert(
				$sql_tab['korrespondenz'],
				$kfeld9
			);
		}
		
		$allesok=$db->insert(
			$sql_tab['korrespondenz'],
			$kfeld
		);
		$ins_k_id=$db->insertid();
		
		if ($cfg_synop_vers and $synop_vers) {
			$kfeld_vers=$kfeld;
			//$kfeld_vers[$sql_tabs['korrespondenz']['parent_id']]=$db->dbzahl($ins_k_id);
			$kfeld_vers[$sql_tabs['korrespondenz']['kampagne_id']]=$db->dbzahl(0);
			$kfeld_vers[$sql_tabs['korrespondenz']['betreff']]=$db->str('DSE - Versicherung');
			$kfeld_vers[$sql_tabs['korrespondenz']['beschreibung']]=$db->str('Digital signiert');
			$kfeld_vers[$sql_tabs['korrespondenz']['kategorie']]=$db->str('DSE - Versicherung');
			$kfeld_vers[$sql_tabs['korrespondenz']['doclink']]=$db->str('');
			$kfeld_vers[$sql_tabs['korrespondenz']['art']]=$db->dbzahl(11);
			$kfeld_vers[$sql_tabs['korrespondenz']['wvl_datum1']]=0;
			$kfeld_vers[$sql_tabs['korrespondenz']['erledigt']]=$db->dblogic(true);
			$kfeld_vers[$sql_tabs['korrespondenz']['ergebnis_datum']]=$db->dbtimestamp(time());
			$kfeld_vers[$sql_tabs['korrespondenz']['ergebnis_benutzer_id']]=$db->dbzahl($ang_kv_user);
			$kfeld_vers[$sql_tabs['korrespondenz']['ergebnis_kategorie']]=$db->str('DSE - Versicherung');
			$kfeld_vers[$sql_tabs['korrespondenz']['ergebnis_text']]=$db->str('Versicherungs DSE');
			$db->insert(
				$sql_tab['korrespondenz'],
				$kfeld_vers
			);
			$ins_k_id_vers=$db->insertid();
			include_once('inc/lib_synop.php');
			$synop_auchdse=false;
			synop_create_vers($ins_k_id_vers, $ins_k_id, '', false, $synop_auchdse);
		}
		
		$ins_k_id_vvi=0;
		if ($cfg_vvi2022 and $bez_ang_kv2=='kv' and is_array($alle_zus_korr_doks) and count($alle_zus_korr_doks)>0) {
			
			if (intval($postfeld['kvvi_id'])>0) {
				$res5=$db->select(
					$sql_tab['produktzuordnung_vvi'],
					array(
						$sql_tabs['produktzuordnung_vvi']['zusatz_1']
					),
					$sql_tabs['produktzuordnung_vvi']['produktzuordnung_vvi_id'].'='.$db->dbzahl($postfeld['kvvi_id'])
				);
				if ($row5=$db->zeile($res5)) {
					if (intval($row5[0])>0) {
						$db->update(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($_SESSION['user_id']),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str(_VVI_),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_VVI_)
							),
							$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($row5[0])
						);
					}
				}
			}
			
			$ltext_vvi='';
			$ltext_vvi.='Abweichungen der Kaufsache: '.(isset($postfeld['kvvi_1'])?'ja':'nein')."\n";
			if ($postfeld['kabweichung1']!='') {
				$ltext_vvi.='Text: '.$postfeld['kabweichung1']."\n";
			}
			$ltext_vvi.='Verk�rzung der Verj�hrungsfrist: '.(isset($postfeld['kvvi_2'])?'ja':'nein')."\n";
			$ltext_vvi.='Ausschluss der gesetzlichen Aktualisierungspflicht: '.(isset($postfeld['kvvi_3'])?'ja':'nein')."\n";
			if (!$cfg_avag_de) {
				$ltext_vvi.='Information des Verbrauchers �ber die Rechtsfolgen: '.(isset($postfeld['kvvi_4'])?'ja':'nein')."\n";
			}
			$kfeld_vvi=$kfeld;
			$kfeld_vvi[$sql_tabs['korrespondenz']['parent_id']]=$db->dbzahl($ins_k_id);
			if (intval($par_id)>0) {
				$kfeld_vvi[$sql_tabs['korrespondenz']['parent_id']]=$db->dbzahl($par_id);
			}
			$kfeld_vvi[$sql_tabs['korrespondenz']['kampagne_id']]=$db->dbzahl(kamp_insert_kfzsuche(_VVI_));
			if (1 or $cfg_vvi2022_kampvonkv) {	// f�r alle
				$kfeld_vvi[$sql_tabs['korrespondenz']['kampagne_id']]=$db->dbzahl(($kamp_id>0?$kamp_id:$kampa_id));
			}
			$kfeld_vvi[$sql_tabs['korrespondenz']['betreff']]=$db->str(_VVI_);
			$kfeld_vvi[$sql_tabs['korrespondenz']['beschreibung']]=$db->str($ltext_vvi);
			$kfeld_vvi[$sql_tabs['korrespondenz']['kategorie']]=$db->str(_VVI_);
			$kfeld_vvi[$sql_tabs['korrespondenz']['doclink']]=$db->str('');
			$kfeld_vvi[$sql_tabs['korrespondenz']['wvl_datum1']]=0;
			$kfeld_vvi[$sql_tabs['korrespondenz']['erledigt']]=$db->dblogic(true);
			$kfeld_vvi[$sql_tabs['korrespondenz']['ergebnis_kategorie']]=$db->str(_VVI_);
			$kfeld_vvi[$sql_tabs['korrespondenz']['ergebnis_text']]=$db->str(_VVI_);
			$db->insert(
				$sql_tab['korrespondenz'],
				$kfeld_vvi
			);
			$ins_k_id_vvi=$db->insertid();
		}
		
		if (intval($ins_k_id_vvi)>0 and isset($alle_zus_korr_doks) and is_array($alle_zus_korr_doks)) {
			@reset($alle_zus_korr_doks);
			while (list($keyu, $valu)=@each($alle_zus_korr_doks)) {
                            $db->insert(
                                $sql_tab['korrespondenz_doks'],
                                array(
                                    $sql_tabs['korrespondenz_doks']['korrespondenz_id']	=> $db->dbzahl($ins_k_id_vvi),
                                    $sql_tabs['korrespondenz_doks']['bezeichnung'] => $db->str($keyu),
                                    $sql_tabs['korrespondenz_doks']['datei'] => $db->str($valu)
                                )
                            );
			}
		}
		
		if ($cfg_dd_vvi2022 and isset($alle_zus_korr_doks) and is_array($alle_zus_korr_doks)) {
			@reset($alle_zus_korr_doks);
			while (list($keyu, $valu)=@each($alle_zus_korr_doks)) {
                            $db->insert(
                                $sql_tab['korrespondenz_doks'],
                                array(
                                    $sql_tabs['korrespondenz_doks']['korrespondenz_id']	=> $db->dbzahl($ins_k_id),
                                    $sql_tabs['korrespondenz_doks']['bezeichnung'] => $db->str($keyu),
                                    $sql_tabs['korrespondenz_doks']['datei'] => $db->str($valu)
                                )
                            );
			}
		}
		
		if (!$cfg_db_kaufrecht2022 and $bez_ang_kv=='Vorvertragsinformation') {
			$db->insert(
				$sql_tab['produktzuordnung_vvi'],
				array(
					$sql_tabs['produktzuordnung_vvi']['datum'] => $db->dbtimestamp(time()),
					$sql_tabs['produktzuordnung_vvi']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
					$sql_tabs['produktzuordnung_vvi']['produktzuordnung_id'] => $db->dbzahl($postfeld['pid']),
					$sql_tabs['produktzuordnung_vvi']['benutzer_id'] => $db->dbzahl($_SESSION['user_id']),	// $ang_kv_user
					$sql_tabs['produktzuordnung_vvi']['doclink'] => $db->str($doclink),
					$sql_tabs['produktzuordnung_vvi']['haken_1'] => $db->dblogic($postfeld['vvi_1']),
					$sql_tabs['produktzuordnung_vvi']['haken_2'] => $db->dblogic($postfeld['vvi_2']),
					$sql_tabs['produktzuordnung_vvi']['haken_3'] => $db->dblogic($postfeld['vvi_3']),
					$sql_tabs['produktzuordnung_vvi']['haken_4'] => $db->dblogic($postfeld['vvi_4']),
					$sql_tabs['produktzuordnung_vvi']['details_1'] => $db->str($postfeld['abweichung1']),
					$sql_tabs['produktzuordnung_vvi']['zusatz_1'] => $db->str($ins_k_id)
				)
			);
		}
		
		if ($alle_zve_kids!='') {
			$alle_zve_kids=substr($alle_zve_kids, 0, -1);
			$db->update(
				$sql_tab['korrespondenz'],
				array(
					$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($ins_k_id)
				),
				$sql_tabs['korrespondenz']['korrespondenz_id'].' in ('.$alle_zve_kids.')'
			);
		}
		if (isset($korrbestid) and intval($korrbestid)>0) {
			$db->update(
				$sql_tab['korrespondenz'],
				array(
                    $sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl($postfeld['pid']),
					$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($ins_k_id)
				),
				$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($korrbestid)
			);
		}
		
		$hat_eigkamp=false;
		if ($cfg_avagneuanpassung2018) {
				$kampa_id2=0;
				if (isset($postfeld['vertrags_marketingkampagne'])) {
					if (intval($postfeld['vertrags_marketingkampagne'])>0) {
						$kampa_id2=intval($postfeld['vertrags_marketingkampagne']);
					//	$hat_eigkamp=true;
					}
					if ($postfeld['vertrags_marketingkampagne']=='-1000') {
						if (isset($postfeld['akv_zuskamp']) and intval($postfeld['akv_zuskamp'])>0) {
							$kampa_id2=intval($postfeld['akv_zuskamp']);
						//	$hat_eigkamp=true;
						}
					}
				}
				if (intval($_SESSION['stammdaten_id'])>0 and $kampa_id2>0) {
					$res99=$db->select(
								$sql_tab['korrespondenz'],
								array(
									$sql_tabs['korrespondenz']['korrespondenz_id']
								),
								$sql_tabs['korrespondenz']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
									$sql_tabs['korrespondenz']['datum'].' between '.$db->dbtimestamp(time()-180*24*60*60).' and '.$db->dbtimestamp(time()+31*24*60*60).' and '.
									$sql_tabs['korrespondenz']['kampagne_id'].'='.$db->dbzahl($kampa_id2),
								$sql_tabs['korrespondenz']['datum'].' desc'
					);
					if ($row99=$db->zeile($res99)) {
						if (1 or $bez_ang_kv==_KAUFVERTRAG_) {
							// KV soll unter Ang. eingeordnet bleiben
						} else {
							$db->update(
								$sql_tab['korrespondenz'],
								array(
									$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($row99[0])
								),
								$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($ins_k_id)
							);
						}
					} else {
						$db->insert(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($postfeld['stid']),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl($kampa_id2),
								$sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
                                $sql_tabs['korrespondenz']['wvl_datum1'] => 0,
                                $sql_tabs['korrespondenz']['wvl_datum2'] => 0,
                                $sql_tabs['korrespondenz']['ansprechpartner_id'] => $db->dbzahl(0),
                                $sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
                                $sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($ang_kv_user),
                                $sql_tabs['korrespondenz']['eingang'] => 0,
                                $sql_tabs['korrespondenz']['art'] => $db->dbzahl(14),
                                $sql_tabs['korrespondenz']['kategorie'] => $db->str(_KORRESPONDENZ_),
                                $sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
                                $sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($par_id),	// anstatt 0 hier Parentid
                                $sql_tabs['korrespondenz']['doclink'] => $db->str(''),
                                $sql_tabs['korrespondenz']['betreff'] => $db->str(_KORRESPONDENZ_),
                                $sql_tabs['korrespondenz']['beschreibung'] => $db->str(_KORRESPONDENZ_),
                                $sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl(0),
                                $sql_tabs['korrespondenz']['papierkorb'] => 0,
                                $sql_tabs['korrespondenz']['kalender_id'] => 0,
                                $sql_tabs['korrespondenz']['prioritaet'] => 0,
                                $sql_tabs['korrespondenz']['negativ'] => 0,
                                $sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
                                $sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
                                $sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_KORRESPONDENZ_),
                                $sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str(_KORRESPONDENZ_),
	                            $sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['quelle'] => $db->str(''),
								$sql_tabs['korrespondenz']['kategorie2'] => $db->str('')
							)
						);
						$par_k_id=$db->insertid();
						$db->update(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($par_k_id)
							),
							$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($ins_k_id)
						);
					}
				}
		}
		
		$ist_auslauf_gew=false;
		if ($cfg_avagneuanpassung2018) {
			if ($postfeld['vertrags_kfzauslauf']=='1') {
				$ist_auslauf_gew=true;
			}
		} else {
			$ist_auslauf_gew=(isset($postfeld['vertrags_kfzauslauf']));
		}
		if ($ist_auslauf_gew) {
			if (isset($postfeld['auswahl_kfzausl'])) {
				$db->update(
					$sql_tab['produktzuordnung'],
					array(
						$sql_tabs['produktzuordnung']['angebot2'] => $db->dblogic(false),
						$sql_tabs['produktzuordnung']['angebot2_kunde'] => $db->dbzahl(0)
					),
					$sql_tabs['produktzuordnung']['produktzuordnung_id'].'!='.$db->dbzahl($postfeld['auswahl_kfzausl']).' and '.
						$sql_tabs['produktzuordnung']['angebot2_kunde'].'='.$db->dbzahl($anr)
				);
				$db->update(
					$sql_tab['produktzuordnung'],
					array(
						$sql_tabs['produktzuordnung']['angebot2'] => $db->dblogic(true),
						$sql_tabs['produktzuordnung']['angebot2_kunde'] => $db->dbzahl($anr)
					),
					$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['auswahl_kfzausl'])
				);
			}
		}
		
		if (intval($par_id)<=0) {
			$par_id=$ins_k_id;
		}
		if (!$vorschau) {
			if ($bez_ang_kv==_ANGEBOT_) {
                //BENZ
				if (class_exists('PearAutoloader')) {
					$td = new Event_Type_Com_Offer($_SESSION['user_id'], $_SESSION['stammdaten_id'], $ins_k_id);
					$td->call();
				}
			}
			if ($bez_ang_kv==_KAUFVERTRAG_) {
                //BENZ
				if (class_exists('PearAutoloader')) {
					$td = new Event_Type_Com_Order($_SESSION['user_id'], $_SESSION['stammdaten_id'], $ins_k_id);
					$td->call();
				}
			}
			
			if (!$cfg_carlo_appserver_activity_keinekorr and !$hat_bezug_act and $cfg_carlo_appserver_activity) {
				if ($postfeld['k_activity']!='-1') {
					if ($postfeld['k_activityerg']=='-1') {
						$postfeld['k_activityerg']='';
					}
					edsxml_write_activity($ins_k_id, $postfeld['k_activity'], $postfeld['k_activityerg']);
				}
			}
			if ($bez_ang_kv==_ANGEBOT_ or ($bez_ang_kv==_KAUFVERTRAG_ and $cfg_carlo_exportdeal_sofort)) {
				if (1 or isset($postfeld['vkh_prog1'])) {	// nur auch Ang/KV ohne VKH
					if (1 or $postfeld['vkh_prog1']!='') {
						include_once('inc/ovkh.php');
						if (function_exists('vkh_addreport')) {
							vkh_addreport($anr);
						}
					}
				}
			}
		}
		
		if (($cfg_profitcalc or $cfg_kfzsuche_kalkulation) and count($kfeld_pc)>0) {
						$ltext2_neu='';
						$hat_wapc=array();
						$xpl=explode('#####', $ltext2);
						while (list($keyx, $valx)=@each($xpl)) {
							$xpl2=explode('===', $valx);
							if (count($xpl2)==2) {
								if (isset($werte_aus_pc[$xpl2[0]])) {
									$ltext2_neu.=$xpl2[0].'==='.$werte_aus_pc[$xpl2[0]].'#####';
									$hat_wapc[$xpl2[0]]=1;
								} else {
									$ltext2_neu.=$valx.'#####';
								}
							} else {
								$ltext2_neu.=$valx.'#####';
							}
						}
						@reset($werte_aus_pc);
						while (list($keyx, $valx)=@each($werte_aus_pc)) {
							if (!isset($hat_wapc[$xpl2[0]])) {
								$ltext2_neu.=$keyx.'==='.$valx.'#####';
							}
						}
			$db->update(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['zusatz1'] => $db->str($ltext2_neu)
							),
							$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($anr).' and '.
								$sql_tabs['korrespondenz']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
								$sql_tabs['korrespondenz']['kategorie'].' like '.$db->str(_NLPROFITCALC_.'%')
			);
			pc_schreibe_details($anr, $ltext2_neu);
		}
		
		for ($akv_i=0; $akv_i<$anzahl_kv_kopie; $akv_i++) {
			$kfeld[$sql_tabs['korrespondenz']['opportunity_id']]=$db->dbzahl($zus_anr[$akv_i]);
			$kfeld[$sql_tabs['korrespondenz']['doclink']]=$db->str($zus_dok[$akv_i]);
			$kfeld[$sql_tabs['korrespondenz']['parent_id']]=$db->dbzahl($par_id);
			$db->insert(
				$sql_tab['korrespondenz'],
				$kfeld
			);
			$ins_korr_kop=$db->insertid();
			
			if ($cfg_profitcalc and count($kfeld_pc)>0) {
						$ltext2_neu='';
						$hat_wapc=array();
						$xpl=explode('#####', $ltext2);
						while (list($keyx, $valx)=@each($xpl)) {
							$xpl2=explode('===', $valx);
							if (count($xpl2)==2) {
								if (isset($werte_aus_pc[$xpl2[0]])) {
									$ltext2_neu.=$xpl2[0].'==='.$werte_aus_pc[$xpl2[0]].'#####';
									$hat_wapc[$xpl2[0]]=1;
								} else {
									$ltext2_neu.=$valx.'#####';
								}
							} else {
								$ltext2_neu.=$valx.'#####';
							}
						}
						@reset($werte_aus_pc);
						while (list($keyx, $valx)=@each($werte_aus_pc)) {
							if (!isset($hat_wapc[$xpl2[0]])) {
								$ltext2_neu.=$keyx.'==='.$valx.'#####';
							}
						}
					$kfeld_pc[$sql_tabs['korrespondenz']['opportunity_id']]=$db->dbzahl($zus_anr[$akv_i]);
					$kfeld_pc[$sql_tabs['korrespondenz']['parent_id']]=$db->dbzahl($ins_korr_kop);
					$kfeld_pc[$sql_tabs['korrespondenz']['zusatz1']]=$db->str($ltext2_neu);
					$db->insert(
						$sql_tab['korrespondenz'],
						$kfeld_pc
					);
					pc_schreibe_details($zus_anr[$akv_i], $ltext2_neu);
			}
		}
		
		if ($inhalt2!='') {
			$kfeld[$sql_tabs['korrespondenz']['kategorie']]=$db->str($bez_ang_kv.' - '._ANKAUFSCHEIN_);
			$kfeld[$sql_tabs['korrespondenz']['doclink']]=$db->str($doclink3);
			$kfeld[$sql_tabs['korrespondenz']['wvl_datum1']]=0;
			$kfeld[$sql_tabs['korrespondenz']['erledigt']]=$db->dblogic(true);
			tempdateien('dokumente_korrespondenz/'.$doclink3, $doclink3, $bez_ang_kv.' '._ANKAUFSCHEIN_.' '.kundenbezeichnung($_SESSION['stammdaten_id']));
			$kfeld[$sql_tabs['korrespondenz']['zusatz1']]=$db->str(trim($postfeld['inz_auswahl']).';'.trim($postfeld['vertrags_gwpreis']).';'.trim($postfeld['vertrags_gwlieferung']).';'.trim($postfeld['vertrags_gwlagerort']));
			$kfeld[$sql_tabs['korrespondenz']['ergebnis_text']]=$db->str(trim($postfeld['vertrags_gwpreis']));
			$allesok2=$db->insert(
				$sql_tab['korrespondenz'],
				$kfeld
			);
		}
		if ($inhalt4!='') {
			$kfeld[$sql_tabs['korrespondenz']['kategorie']]=$db->str($bez_ang_kv.' - '._WIDERRUF_);
			$kfeld[$sql_tabs['korrespondenz']['betreff']]=$db->str(_WIDERRUF_.' - '.$betre);
			$kfeld[$sql_tabs['korrespondenz']['doclink']]=$db->str($doclink5);
			$kfeld[$sql_tabs['korrespondenz']['wvl_datum1']]=0;
			tempdateien('dokumente_korrespondenz/'.$doclink5, $doclink5, $bez_ang_kv.' '._WIDERRUF_.' '.kundenbezeichnung($_SESSION['stammdaten_id']));
			$kfeld[$sql_tabs['korrespondenz']['zusatz1']]=$db->str('');
			$kfeld[$sql_tabs['korrespondenz']['ergebnis_text']]=$db->str(_WIDERRUF_);
			$kfeld[$sql_tabs['korrespondenz']['erledigt']]=$db->dblogic(true);
			$allesok2=$db->insert(
				$sql_tab['korrespondenz'],
				$kfeld
			);
		}
		unset($capps_keinek);
		
		if ($bez_ang_kv==_KAUFVERTRAG_ or $bez_ang_kv==_ANGEBOT_) {
			
			if ($fgnr!='') {
				if (is_dir('dokumente/kfz_fotos/'.$fgnr)) {
							$x=array();
							dirinhalt_kfz3('dokumente/kfz_fotos/'.$fgnr);
							$xi=1;
							while (list($key, $val)=@each($x)) {
								while (list($key2, $val2)=@each($val)) {
									if (p4n_mb_string('strtolower',$val2)=='thumbs.db') {
										continue;
									}
									if (!(strtolower(substr($val2, -4))=='.jpg' or strtolower(substr($val2, 5))=='.jpeg')) {
										continue;
									}
									$xplb1=explode('.', $val2);
									$datendung=$xplb1[count($xplb1)-1];
									tempdateien('dokumente/kfz_fotos/'.$fgnr.'/'.$val2, 'bild'.$xi.'.'.$datendung, _FAHRZEUG_.' '._BILD_.' '.$xi);
									$xi++;
								}
							}
				}
			}
			
			$quoteid=$anr;
			$konfid=$anr;
			$quelle='CARLO';
			if (isset($postfeld['freiekonf'])) {
				$quelle=_FREIER_TYP_;
			}
            if (!empty($postfeld['konf_quelle'])) {
                $quelle=$postfeld['konf_quelle'];
            }
			$konf_bez=$pid_bez;

			$mpv_code='';
			$mpv_bez='';
			$mpv_mj='';
			$mpv_dnp=0;
			$mpv_preis=0;
			$fa_itemcode='';
			$fa_code='';
			$fa_bez='';
			$fa_preis=0;
			$fa_net=0;
			$fa_dnp=0;
			$tr_code='';
			$tr_bez='';
			$tr_preis=0;
			$tr_net=0;
			$tr_dnp=0;

			for ($akv_i=-1; $akv_i<$anzahl_kv_kopie; $akv_i++) {

				if ($akv_i==-1) {
					$quoteid=$anr;
					$konfid=$anr;
					$anr2=$anr;
				} else {
					$anr2=$zus_anr[$akv_i];
					$quoteid=$zus_anr[$akv_i];
					$konfid=$zus_anr[$akv_i];
				}
				$ko_options=array();

				$m_summe=$summe;

				$alle_techdaten=array();
                // Datenblatt andere Marken -->
                $datenblattMarke = null;
                // FHD Datenblatt -->
                if ($cfg_fhd && $quelle === 'FHD' && isset($postfeld['datenblatt']) && !isset($schon_datenblatt) && !empty($postfeld['tech_data'])) {
                    $datenblattMarke = 'ford';
                }
                // --> FHD Datenblatt
                // Mazda Datenblatt -->
                if ($cfg_mazda_conf && $quelle === 'Mazda' && isset($postfeld['datenblatt']) && !isset($schon_datenblatt) && !empty($postfeld['tech_data'])) {
                    $datenblattMarke = 'mazda';
                }
                // --> Mazda Datenblatt
                if ($datenblattMarke) {
                    $techData = unserialize($postfeld['tech_data']);
                    if (is_array($techData)) {
                        $schon_datenblatt = true;
                        $m_ist_docx = $ist_docx;
                        $ist_docx = false;
                        $vorlage_td = '';
                        if (is_file('inc/'.$_SESSION['cfg_kunde'].'/datenblatt_'.$datenblattMarke.'.rtf')) {
                            $vorlage_td = 'inc/'.$_SESSION['cfg_kunde'].'/datenblatt_'.$datenblattMarke.'.rtf';
                        } elseif (is_file('vorlagen/datenblatt_'.$datenblattMarke.'.rtf')) {
                            $vorlage_td = 'vorlagen/datenblatt_'.$datenblattMarke.'.rtf';
                        } elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/datenblatt_'.$datenblattMarke.'.docx')) {
                            $vorlage_td = 'inc/'.$_SESSION['cfg_kunde'].'/datenblatt_'.$datenblattMarke.'.docx';
                            $ist_docx = true;
                        } elseif (is_file('vorlagen/datenblatt_'.$datenblattMarke.'.docx')) {
                            $vorlage_td = 'vorlagen/datenblatt_'.$datenblattMarke.'.docx';
                            $ist_docx = true;
                        }
                        if ($vorlage_td != '') {
                            $inh_techdata = file_get_contents($vorlage_td);
                            $inh_techdata = p4n_sb_strreplace('<<kfz>>', $mctya_m, $inh_techdata);
                            foreach ($techData as $key_td => $val_td) {
                                $inh_techdata=p4n_sb_strreplace('<<'.$key_td.'>>', $val_td, $inh_techdata);
                            }
                            if (preg_match_all('/<<([^>]*)>>/m', $inh_techdata, $matches)) {
                                while (list($key_td, $val_td) = @each($matches[1])) {
                                    $inh_techdata = str_replace($matches[0][$key_td], '-', $inh_techdata);
                                }
                            }
                            $td_datei='temp/techdata_'.$datenblattMarke.'_'.$_SESSION['user_id'].'.rtf';
                            if ($fp2=fopen($td_datei, 'w')) {
                                fwrite($fp2, $inh_techdata);
                                fclose($fp2);
                                echo javas('window.open("'.$td_datei.'", "_blank");');
                            }
                        }
                        $ist_docx = $m_ist_docx;
                    }
                }
                // --> Datenblatt andere Marken
				$nicht_gmevc=false;
				if (isset($postfeld['konf_quelle']) and $postfeld['konf_quelle']=='CESAR') {
					$nicht_gmevc=true;
				}
				$res2=$db->select(
					$sql_tab['kfz_konfigurator_gme'],
					array(
						$sql_tabs['kfz_konfigurator_gme']['inhalt'],
						$sql_tabs['kfz_konfigurator_gme']['konfig_id'],
						$sql_tabs['kfz_konfigurator_gme']['dealercode']
					),
					$sql_tabs['kfz_konfigurator_gme']['kfz_konfigurator_gme_id'].'='.$db->dbzahl($postfeld['gme_konf_id'])
				);
				if (!$nicht_gmevc and $row2=$db->zeile($res2)) {
					$obj=simplexml_load_string(str_replace(array('&lt;', '&gt;'), array('<', '>'), $row2[0]));

					if (!isset($schon_datenblatt) and isset($postfeld['datenblatt'])) {
						$schon_datenblatt=true;
						$vorlage_td='';
						if (is_file('inc/'.$_SESSION['cfg_kunde'].'/datenblatt.rtf')) {
							$vorlage_td='inc/'.$_SESSION['cfg_kunde'].'/datenblatt.rtf';
						} elseif (is_file('vorlagen/datenblatt.rtf')) {
							$vorlage_td='vorlagen/datenblatt.rtf';
						}
						if ($vorlage_td!='') {
							$inh_techdata=file_get_contents($vorlage_td);
							if (isset($obj->wltpData)) {
								//$fueltype=utf8_decode_konfg($obj->wltpData->fuelScenarioValues->fuelType);
								$wltptech=array();
								for ($i=0; $i<30; $i++) {
									if (isset($obj->wltpData->fuelScenarioValues->cycleRanges[$i])) {
										$x1=$obj->wltpData->fuelScenarioValues->cycleRanges[$i];
										$wltptech[strval($x1->cycle).'_co2_low']=p4n_mb_string('utf8_decode',$x1->co2->low);
										$wltptech[strval($x1->cycle).'_co2_high']=p4n_mb_string('utf8_decode',$x1->co2->low);
										$wltptech[strval($x1->cycle).'_fc_low']=p4n_mb_string('utf8_decode',$x1->fc->low);
										$wltptech[strval($x1->cycle).'_fc_high']=p4n_mb_string('utf8_decode',$x1->fc->low);
									}
								}
								for ($i=0; $i<30; $i++) {
									if (isset($obj->wltpData->fuelScenarioValues->cycleValues[$i])) {
										$x1=$obj->wltpData->fuelScenarioValues->cycleValues[$i];
										$wltptech[strval($x1->cycle).'_co2']=p4n_mb_string('utf8_decode',$x1->co2->value);
										$wltptech[strval($x1->cycle).'_fc']=p4n_mb_string('utf8_decode',$x1->fc->value);
									}
								}
								while (list($key_td, $val_td)=@each($wltptech)) {
									$inh_techdata=p4n_sb_strreplace('<<'.$key_td.'>>', $val_td, $inh_techdata);
								}
							}
							if (preg_match_all('/technicalValue\stype="(.*)">(.*)<\/technicalValue/Ui', str_replace(array('&lt;', '&gt;'), array('<', '>'), $row2[0]), $ma_td)) {
								$inh_techdata=p4n_sb_strreplace('<<kfz>>', $mctya_m, $inh_techdata);
								while (list($key_td, $val_td)=@each($ma_td[1])) {
									$inh_techdata=p4n_sb_strreplace('<<'.$val_td.'>>', $ma_td[2][$key_td], $inh_techdata);
								}
								if (preg_match_all('/<<([^>]*)>>/m', $inh_techdata, $matches)) {
									while (list($key_td, $val_td)=@each($matches[1])) {
										$inh_techdata=str_replace($matches[0][$key_td], '-', $inh_techdata);
									}
								}
								$td_datei='temp/techdata_'.$_SESSION['user_id'].'.rtf';
								if ($fp2=fopen($td_datei, 'w')) {
									fwrite($fp2, $inh_techdata);
									fclose($fp2);
								//	echo javas('window.open("'.$td_datei.'", "_blank");');
								}
								
								$td_pdf='';
								if ($cfg_rtf2pdf and substr($td_datei, -4)!='.pdf') {
									$td_pdf=check_rtf2pdf($td_datei, $cfg_rtf2pdf_sleep);
									if ($td_pdf==$td_datei) {
										$td_pdf='';
									}
								} elseif (substr($td_datei, -4)=='.pdf') {
									$td_pdf=$td_datei;
								}
								if ($td_pdf!='') {
								//	tempdateien($td_pdf, str_replace('temp/', '', str_replace('.rtf', '.pdf', $td_pdf)), _DATENBLATT_);
									if ($cfg_kfzsuche_pdf_join and substr($td_pdf, -4)=='.pdf') {
										
									} else {
										echo javas('window.open("'.$td_pdf.'", "_blank");');
									}
									$alle_pdfs[45]=$td_pdf;
								} else {
									echo javas('window.open("'.$td_datei.'", "_blank");');
								}
								
							}
						}
					}

					$quelle='GMEVC';
					if ($row2[2]=='CDS') {
						$quelle='CDS';
					}
					$konfid=$row2[1];
					$konf_bez=p4nk_utf8decode($obj->mpv->name);
					$mpv_code=p4nk_utf8decode($obj->mpv->code);
					$mpv_bez=p4nk_utf8decode($obj->mpv->name);
					$mpv_mj=p4nk_utf8decode($obj->modelYear);
					$mpv_dnp=p4nk_utf8decode($obj->mpv->dnp);
					$mpv_dnp2=p4nk_utf8decode($obj->mpv->{"msrp-net"});
					$mpv_preis=p4nk_utf8decode($obj->mpv->msrp);
					if ($ustabw>0) {
						$mpv_preis=doubleval($obj->mpv->{"msrp-net"})*(1+$cfg_mwst);
                        if (is_object($obj->mpv)) {
                            $obj->mpv->msrp=$mpv_preis;
                        }
					}
					if ($cfg_kfzsuche_italien) {
						$mpv_preis-=doubleval(p4nk_utf8decode($obj->mpv->{"local-tax"}));
					}
					$fa_itemcode='';
					$fa_code=p4nk_utf8decode($obj->color->code);
					$fa_bez=p4nk_utf8decode($obj->color->name);
					$fa_preis=p4nk_utf8decode($obj->color->msrp);
					if ($ustabw>0) {
						$fa_preis=doubleval($obj->color->{"net-price"})*(1+$cfg_mwst);
                        if (is_object($obj->color)) {
                            $obj->color->msrp=$fa_preis;
                        }
					}
					$fa_net=p4nk_utf8decode($obj->color->{"net-price"});
					$fa_dnp=p4nk_utf8decode($obj->color->dnp);
					$tr_code=p4nk_utf8decode($obj->trim->code);
					$tr_bez=p4nk_utf8decode($obj->trim->name);
					$tr_preis=p4nk_utf8decode($obj->trim->msrp);
					if ($ustabw>0) {
						$tr_preis=doubleval($obj->trim->{"net-price"})*(1+$cfg_mwst);
                        if (is_object($obj->trim)) {
                            $obj->trim->msrp=$tr_preis;
                        }
					}
					$tr_net=p4nk_utf8decode($obj->trim->{"net-price"});
					$tr_dnp=p4nk_utf8decode($obj->trim->dnp);
					if ($cfg_kfzsuche_italien and $cfg_mwst!=$cfg_mwstn) {
						$fa_preis=itrechnezweitsteuer($fa_preis);
						$fa_dnp=itrechnezweitsteuer($fa_dnp);
						$fa_vat=itrechnezweitsteuer($fa_preis, false, true);
						$fa_net=$fa_preis-$fa_vat;
						$tr_preis=itrechnezweitsteuer($tr_preis);
						$tr_dnp=itrechnezweitsteuer($tr_dnp);
						$tr_vat=itrechnezweitsteuer($tr_preis, false, true);
						$tr_net=$tr_preis-$tr_vat;
						$mpv_dnp=itrechnezweitsteuer($mpv_dnp);
						$mpv_preis=itrechnezweitsteuer($mpv_preis);
					}
					$summe=0;
					$summe1=0;
					$summe2=0;
					$summe3=0;
					$summe+=doubleval($obj->mpv->msrp);
					$summe1+=doubleval($obj->mpv->dnp);
					$summe2+=doubleval($obj->mpv->{"msrp-net"});
					$summe3+=doubleval($obj->mpv->vat);
					$summe+=doubleval($obj->color->msrp);
					$summe1+=doubleval($obj->color->dnp);
					$summe2+=doubleval($obj->color->{"net-price"});
					$summe3+=doubleval($obj->color->vat);
					$summe+=doubleval($obj->trim->msrp);
					$summe1+=doubleval($obj->trim->dnp);
					$summe2+=doubleval($obj->trim->{"net-price"});
					$summe3+=doubleval($obj->trim->vat);
					
					if (isset($obj->options->option)) {
						@reset($obj->options->option);
						foreach($obj->options->option as $key => $val) {
							$attr=$val->attributes();
							$opttype='';
							foreach($attr as $key2 => $val2) {
								$opttype=$val2[0];
							}
							$parcode='';
							if ($opttype=='in-subpack' or isset($val->subpack)) {
								$parcode=strval($val->subpack);
							}
							if ($ustabw>0) {
								$opt_preis=doubleval($val->{"net-price"})*(1+$cfg_mwst);
								$val->msrp=$opt_preis;
								$val->vat=doubleval($val->{"net-price"})*($cfg_mwst);
							}
								$summe+=$preis1;
								$summe1+=doubleval($val->dnp);
								$summe2+=doubleval($val->{"net-price"});
								$summe3+=doubleval($val->vat);
								$preis1=doubleval($val->msrp);
								$preis2=doubleval($val->dnp);
								$preis3=doubleval($val->{"net-price"});
								$preis4=doubleval($val->vat);
								$seriea=false;
								if ($opttype=='standard') {
									$seriea=true;
								}
								if ($cfg_kfzsuche_italien and $cfg_mwst!=$cfg_mwstn) {
									$preis1=itrechnezweitsteuer($preis1);
									$preis2=itrechnezweitsteuer($preis2);
									$preis4=itrechnezweitsteuer($preis1, false, true);
									$preis3=$preis1-$preis4;
								}
								$ko_options[strval($val->code)]=array(
									'code' => p4nk_utf8decode($val->code),
									'bez' => p4nk_utf8decode($val->name),
									'bez2' => '',
									'kat' => '',
									'typ' => $opttype,
									'net' => $preis3,
									'preis' => $preis1,
									'dnp' => $preis2,
									'mwst' => $preis4,
									'serie' => $seriea,
									'parent_code' => $parcode,
									'loctax' => (isset($val->{"local-tax"})?doubleval($val->{"local-tax"}):0),
									'dnp2' => $preis2
								);
						}
					}
					if (isset($obj->accessories->accessory)) {
						foreach($obj->accessories->accessory as $key => $val) {
							if ($ustabw>0) {
								$opt_preis=doubleval($val->{"net-price"})*(1+$cfg_mwst);
								$val->msrp=$opt_preis;
							}
							$preis1=doubleval($val->msrp);
							$preis2=doubleval($val->dnp);
							$preis3=doubleval($val->{"net-price"});
							$preis4=doubleval($val->vat);
							$summe+=doubleval($val->msrp);
							$summe1+=doubleval($val->dnp);
							$summe2+=doubleval($val->{"net-price"});
							$summe3+=doubleval($val->vat);
							if ($cfg_kfzsuche_italien and $cfg_mwst!=$cfg_mwstn) {
								$preis1=itrechnezweitsteuer($preis1);
								$preis2=itrechnezweitsteuer($preis2);
								$preis4=itrechnezweitsteuer($preis1, false, true);
								$preis3=$preis1-$preis4;
							}
							$ko_options[strval($val->code)]=array(
									'code' => p4nk_utf8decode($val->code),
									'bez' => p4nk_utf8decode($val->name),
									'bez2' => '',
									'kat' => 'DealerFit',
									'typ' => 'Accessory',
									'net' => $preis3,
									'preis' => $preis1,
									'dnp' => $preis2,
									'mwst' => $preis4,
									'serie' => false,
									'parent_code' => '',
									'dnp2' => $preis2
							);
						}
					}

				} else {
					// Fahrzeug aus DB:
					// $postfeld['pid']
					if (intval($postfeld['vertrag_nwgw'])==8 or intval($postfeld['vertrag_nwgw'])==1) {
						// NW/VFW GW
						if (intval($postfeld['pid'])>0) {

						$res5=$db->select(
							$sql_tab['produktzuordnung'],
							array(
								$sql_tabs['produktzuordnung']['typ_modell'],
								$sql_tabs['produktzuordnung']['modelljahr'],
								$sql_tabs['produktzuordnung']['fahrzeugmodellnr'],
								$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'],
								$sql_tabs['produktzuordnung']['einstandspreis_mw'],
								$sql_tabs['produktzuordnung']['farbbezeichnung'],
								$sql_tabs['produktzuordnung']['polsterbezeichnung'],
								$sql_tabs['produktzuordnung']['fahrzeugstatus'],
								$sql_tabs['produktzuordnung']['einstandspreis_mw'],
								$sql_tabs['produktzuordnung']['standtage']
							),
							$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
						);
						if ($row5=$db->zeile($res5)) {
							$mpv_code=$row5[2];
							$mpv_bez=$row5[0];
							$mpv_mj=$row5[1];
							$mpv_preis=$row5[3];
							if (doubleval($mpv_preis)==0 or $postfeld['vertrag_nwgw']=='1') {
								if (doubleval(str_replace(',', '.', $postfeld['fin_preis2']))>0) {
									$mpv_preis=doubleval(str_replace(',', '.', $postfeld['fin_preis2']));
								}
							}
							$mpv_dnp=$row5[4];
							$fa_bez=$row5[5];
							$tr_bez=$row5[6];
							$mpv_kfzstatus=$row5[7];
							$mpv_ekp=$row5[8];
							$mpv_standtage=$row5[9];
						}

					if ($postfeld['vertrag_nwgw']!='1') {
						$res6=$db->select(
								$sql_tab['produktzuordnung_ausstattung'],
								$sql_tabs['produktzuordnung_ausstattung']['listen_preis_mwst'],
								$sql_tabs['produktzuordnung_ausstattung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid']).' and ('.$sql_tabs['produktzuordnung_ausstattung']['ausst_art'].'=1 or '.$sql_tabs['produktzuordnung_ausstattung']['ausst_art_text'].'='.$db->str('Fahrzeug').')',
								$sql_tabs['produktzuordnung_ausstattung']['rang']
						);
						if ($row6=$db->zeile($res6)) {
							$mpv_preis=$row6[0];
						}

						$res5=$db->select(
							$sql_tab['produktzuordnung_ausstattung'],
							array(
								$sql_tabs['produktzuordnung_ausstattung']['ausst_code'],
								$sql_tabs['produktzuordnung_ausstattung']['ausst_kennzeichen'],
								$sql_tabs['produktzuordnung_ausstattung']['beschreibung'],
								$sql_tabs['produktzuordnung_ausstattung']['beschreibung2'],
								$sql_tabs['produktzuordnung_ausstattung']['ausst_art'],
								$sql_tabs['produktzuordnung_ausstattung']['vk_preis_mwst'],	// 5
								$sql_tabs['produktzuordnung_ausstattung']['vk_preis'],
								$sql_tabs['produktzuordnung_ausstattung']['serienausstattung'],
								$sql_tabs['produktzuordnung_ausstattung']['ek_preis'],
								$sql_tabs['produktzuordnung_ausstattung']['mwst_betrag']
							),
							$sql_tabs['produktzuordnung_ausstattung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
						);
						while ($row5=$db->zeile($res5)) {
							if ($row5[1]=='1') {
								$fa_itemcode='';
								$fa_code=$row5[0];
								$fa_bez=trim($row5[2].' '.$row5[3]);
								$fa_preis=doubleval($row5[5]);
								$fa_net=doubleval($row5[6]);
								$fa_dnp=doubleval($row5[8]);
								$farbdaten=$fa_itemcode.'#####'.$fa_code.'#####'.$fa_bez.'#####'.$fa_preis.'#####'.$fa_net.'#####'.$fa_dnp.'#####'.doubleval($row5[9]);
							} elseif ($row5[1]=='2') {
								$tr_code=$row5[0];
								$tr_bez=trim($row5[2].' '.$row5[3]);
								$tr_preis=doubleval($row5[5]);
								$tr_net=doubleval($row5[6]);
								$tr_dnp=doubleval($row5[8]);
								$trimdaten=$tr_code.'#####'.$tr_bez.'#####'.$tr_preis.'#####'.$tr_net.'#####'.$tr_dnp.'#####'.doubleval($row5[9]);
							} elseif ($row5[4]!='1') {
								$soa_vat=doubleval($row5[5])-doubleval($row5[6]);
								$ko_options[]=array(
									'code' => $row5[0],
									'bez' => $row5[2],
									'bez2' => $row5[3],
									'kat' => '',
									'typ' => ($row5[7]=='0'?'ordered':'standard'),
									'net' => doubleval($row5[6]),
									'preis' => doubleval($row5[5]),
									'dnp' => doubleval($row5[8]),
									'mwst' => $soa_vat,
									'serie' => ($row5[7]=='1'?false:true),
									'parent_code' => '',
									'loctax' => doubleval($row5[9])
								);
							}
						}
					}
						} elseif ($postfeld['freiekonf']=='1' or (($kfz_fstatus=='Neufahrzeug - konfiguriert' or $kfz_fstatus==_VEHICLE_CONFIGURED_) and $quelle!='GMEVC')) {
							$mpv_code=$postfeld['kfz_typmodell'];
							$mpv_bez=$postfeld['kfz_typmodell'];
							$mpv_mj='';
							$mpv_preis=str_replace(',', '.', $postfeld['listenpreis5']);
							$mpv_dnp=str_replace(',', '.', $postfeld['dnp_listenpreis5']);
							$mpv_dnp2=str_replace(',', '.', $postfeld['net_listenpreis5']);
							$fa_bez=$postfeld['kfz_polster'];
							$tr_bez=$postfeld['kfz_farbe'];
						}
					}

					if ($cfg_kfzsuche_holland or $cfg_kfzsuche_vgw) {//$cfg_kfzsuche_italien or 
						$mpv_preis=str_replace(',', '.', $postfeld['listenpreis5']);
					}
				}

				$ve_zus='99';
					if (intval($postfeld['vertrag_nwgw'])>=4 and intval($postfeld['vertrag_nwgw'])!=5 and intval($postfeld['vertrag_nwgw'])!=7 and intval($postfeld['vertrag_nwgw'])!=8) {
						$ve_zus='2';
					} elseif (intval($postfeld['vertrag_nwgw'])==5 or intval($postfeld['vertrag_nwgw'])==7) {
						$ve_zus='3';
					} elseif (intval($postfeld['vertrag_nwgw'])==8) {
						$ve_zus='5';
					}

				// MBKS:
				$nichtv_weg=array();
				if (($quelle!='GMEVC' and ($kfz_fstatus=='Neufahrzeug - konfiguriert' or $kfz_fstatus==_VEHICLE_CONFIGURED_)) or $postfeld['extconf']=='OB' or (isset($postfeld['mbks_guid']) and $postfeld['mbks_guid']!='')) {
					$fa_itemcode='';
					$fa_code=kfzs_holecode($postfeld['vertrag5_farbe']);
								$fa_bez=kfzs_klammerraus($postfeld['vertrag5_farbe']);
								$fa_preis=doubleval(str_replace(',', '.', $postfeld['vertrag5_farbepreis']));
								$fa_net=doubleval(str_replace(',', '.', $postfeld['net_farbe5']));
								$fa_dnp=doubleval(str_replace(',', '.', $postfeld['net_farbe5']));
								$fa_tax=doubleval(str_replace(',', '.', $postfeld['vat_farbe5']));
								$fa_dnp2=doubleval(str_replace(',', '.', $postfeld['dnp_farbe5']));
								$farbdaten=$fa_itemcode.'#####'.$fa_code.'#####'.$fa_bez.'#####'.$fa_preis.'#####'.$fa_net.'#####'.$fa_dnp.'#####'.$fa_tax.'#####'.$fa_dnp2;
					$tr_code=kfzs_holecode($postfeld['vertrag5_trim']);
								$tr_bez=kfzs_klammerraus($postfeld['vertrag5_trim']);
								$tr_preis=doubleval(str_replace(',', '.', $postfeld['vertrag5_trimpreis']));
								$tr_net=doubleval(str_replace(',', '.', $postfeld['net_trim5']));
								$tr_dnp=doubleval(str_replace(',', '.', $postfeld['net_trim5']));
								$tr_tax=doubleval(str_replace(',', '.', $postfeld['vat_trim5']));
								$tr_dnp2=doubleval(str_replace(',', '.', $postfeld['dnp_trim5']));
								$trimdaten=$tr_code.'#####'.$tr_bez.'#####'.$tr_preis.'#####'.$tr_net.'#####'.$tr_dnp.'#####'.$tr_tax.'#####'.$tr_dnp2;
					$mpv_code=kfzs_holecode($postfeld['kfz_typmodell']);
							$mpv_bez=kfzs_klammerraus($postfeld['kfz_typmodell']);
							$mpv_mj='';
							$mpv_dnp=str_replace(',', '.', $postfeld['dnp_listenpreis5']);
							$mpv_dnp2=str_replace(',', '.', $postfeld['net_listenpreis5']);
							$tr_bez=$postfeld['kfz_polster'];
							$fa_bez=$postfeld['kfz_farbe'];
					for ($auss_i=1; $auss_i<=500; $auss_i++) {
						if ($postfeld['vertrag'.$ve_zus.'_sonder'.$auss_i]!='') {
							$ko_options[]=array(
									'code' => kfzs_holecode($postfeld['vertrag'.$ve_zus.'_sonder'.$auss_i]),
									'bez' => kfzs_klammerraus($postfeld['vertrag'.$ve_zus.'_sonder'.$auss_i]),
									'bez2' => '',
									'kat' => '',
									'typ' => 'ordered',
									'net' => doubleval(str_replace(',', '.', $postfeld['net_aus5'.$auss_i])),
									'preis' => doubleval(str_replace(',', '.', $postfeld['vertrag5_sonderpreis'.$auss_i])),
									'dnp' => doubleval(str_replace(',', '.', $postfeld['net_aus5'.$auss_i])),
									'mwst' => doubleval(str_replace(',', '.', $postfeld['vat_aus5'.$auss_i])),
									'serie' => false,
									'parent_code' => '',
									'loctax' => doubleval(str_replace(',', '.', $postfeld['lt_aus5'.$auss_i])),
									'dnp2' => doubleval(str_replace(',', '.', $postfeld['dnp_aus5'.$auss_i]))
							);
							$nichtv_weg[$auss_i]=1;
						}
					}
					for ($auss_i=1; $auss_i<=500; $auss_i++) {
						if ($postfeld['vertrag'.$ve_zus.'_sonders'.$auss_i]!='') {
							$ko_options[]=array(
									'code' => kfzs_holecode($postfeld['vertrag'.$ve_zus.'_sonders'.$auss_i]),
									'bez' => kfzs_klammerraus($postfeld['vertrag'.$ve_zus.'_sonders'.$auss_i]),
									'bez2' => '',
									'kat' => '',
									'typ' => 'standard',
									'net' => 0,
									'preis' => 0,
									'dnp' => 0,
									'mwst' => 0,
									'serie' => true,
									'parent_code' => '',
									'loctax' => 0
							);
						}
					}
				}

					$ausz1=1;
					for ($auss_i=1; $auss_i<=500; $auss_i++) {
						if (!isset($nichtv_weg[$auss_i]) and $postfeld['vertrag'.$ve_zus.'_sonder'.$auss_i]!='' and !isset($postfeld['vertrag'.$ve_zus.'_sonderpreisv'.$auss_i])) {
							$soa_p=$postfeld['vertrag'.$ve_zus.'_sonderpreis'.$auss_i];
							$soa_p=number_format(doubleval($soa_p), 2, ".", "");
							$soa_p2=number_format(doubleval(number_format(doubleval($postfeld['vertrag'.$ve_zus.'_sonderpreis'.$auss_i]), 2, ".", ""))/(1+$cfg_mwstn), 2, ".", "");
							$soa_vat=doubleval($soa_p)-doubleval($soa_p2);
							$summe+=doubleval($soa_p);
							$ko_options[]=array(
									'code' => 'CRM'.$ausz1,
									'bez' => $postfeld['vertrag'.$ve_zus.'_sonder'.$auss_i],
									'bez2' => '',
									'kat' => 'DealerFit',
									'typ' => 'DealerFit',
									'net' => doubleval($soa_p2),
									'preis' => doubleval($soa_p),
									'dnp' => doubleval($soa_p2),
									'mwst' => $soa_vat,
									'serie' => false,
									'parent_code' => '',
									'loctax' => doubleval(str_replace(',', '.', $postfeld['lt_aus5'.$auss_i])),
									'dnp2' => doubleval(str_replace(',', '.', $postfeld['dnp_aus5'.$auss_i]))
							);
							$ausz1++;
						}
					}
					for ($auss_i=1; $auss_i<=200; $auss_i++) {
						$auss_iz=$auss_i;
						if ($postfeld['vertrag'.$ve_zus.'_sonderz'.$auss_iz]!='') {
							$soa_p=str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderzpreis'.$auss_iz]);
							$soa_p2=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderzpreis'.$auss_iz]))/(1+$cfg_mwst), 2, ".", ""));
							$soa_vat=doubleval($soa_p)-doubleval($soa_p2);
							$zb_cod1=trim(kfzs_holecode($postfeld['vertrag'.$ve_zus.'_sonderz'.$auss_iz]));
							if ($cfg_kfzsuche_holland) {
								if (!preg_match('/[\d\-]/', $zb_cod1)) {
									$zb_cod1='';
								}
							}
							if ($zb_cod1=='') {
								$zb_cod1='CRM'.$ausz1;
							}
							if ($cfg_import_ownoptions_code) {
								if (isset($postfeld['vertrag'.$ve_zus.'_sonderzcode'.$auss_iz]) and $postfeld['vertrag'.$ve_zus.'_sonderzcode'.$auss_iz]!='') {
									$zb_cod1=$postfeld['vertrag'.$ve_zus.'_sonderzcode'.$auss_iz];
								}
							}
							$ko_options[]=array(
									'code' => $zb_cod1,
									'bez' => $postfeld['vertrag'.$ve_zus.'_sonderz'.$auss_iz],
									'bez2' => '',
									'kat' => 'DealerFit',
									'typ' => 'DealerFit_'.$auss_iz,
									'net' => doubleval($soa_p2),
									'preis' => doubleval($soa_p),
									'dnp' => doubleval($soa_p2),
									'mwst' => $soa_vat,
									'serie' => false,
									'parent_code' => '',
									'loctax' => doubleval(str_replace(',', '.', $postfeld['lt_aus5'.$auss_iz])),
									'dnp2' => doubleval(str_replace(',', '.', $postfeld['dnp_aus5'.$auss_iz]))
							);
							$ausz1++;
						}
					}
				if ($cfg_kfzsuche_italien) {
					$soa_p=str_replace(',', '.', $postfeld['vertrag5_neben']);
					$soa_p2=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_neben']))/(1+$cfg_mwst), 2, ".", ""));
					$soa_vat=doubleval($soa_p)-doubleval($soa_p2);
					$ko_options[]=array('code' => 'IPT', 'bez' => 'IPT', 'bez2' => '', 'kat' => 'DealerFit', 'typ' => 'DealerFit_F_IPT', 'net' => doubleval($soa_p2), 'preis' => doubleval($soa_p), 'dnp' => doubleval($soa_p2), 'mwst' => $soa_vat, 'serie' => false, 'parent_code' => '', 'loctax' => 0 );

					$soa_p=str_replace(',', '.', $postfeld['vertrag5_neben2']);
					$soa_p2=$soa_p;
					$soa_vat=0;
					$ko_options[]=array('code' => 'MSN', 'bez' => 'MSN', 'bez2' => '', 'kat' => 'DealerFit', 'typ' => 'DealerFit_F_MSN', 'net' => doubleval($soa_p2), 'preis' => doubleval($soa_p), 'dnp' => doubleval($soa_p2), 'mwst' => $soa_vat, 'serie' => false, 'parent_code' => '', 'loctax' => 0 );

					$soa_p=str_replace(',', '.', $postfeld['vertrag5_transport']);
					$soa_p2=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['vertrag5_transport']))/(1+$cfg_mwst), 2, ".", ""));
					$soa_vat=doubleval($soa_p)-doubleval($soa_p2);
					$ko_options[]=array('code' => 'MSS', 'bez' => 'MSS', 'bez2' => '', 'kat' => 'DealerFit', 'typ' => 'DealerFit_F_MSS', 'net' => doubleval($soa_p2), 'preis' => doubleval($soa_p), 'dnp' => doubleval($soa_p2), 'mwst' => $soa_vat, 'serie' => false, 'parent_code' => '', 'loctax' => 0 );

					$soa_p=str_replace(',', '.', $postfeld['add_tax1_wert']);
					$soa_p2=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['add_tax1_wert']))/(1+$cfg_mwst), 2, ".", ""));
					if ($postfeld['add_tax1v']!='1') {
						$soa_p2=$soa_p;
					}
					$soa_vat=doubleval($soa_p)-doubleval($soa_p2);
					$ko_options[]=array('code' => 'L1', 'bez' => $postfeld['add_tax1'], 'bez2' => '', 'kat' => 'DealerFit', 'typ' => 'DealerFit_F_L1', 'net' => doubleval($soa_p2), 'preis' => doubleval($soa_p), 'dnp' => doubleval($soa_p2), 'mwst' => $soa_vat, 'serie' => false, 'parent_code' => '', 'loctax' => 0 );
					$soa_p=str_replace(',', '.', $postfeld['add_tax2_wert']);
					$soa_p2=doubleval(number_format(doubleval(str_replace(',', '.', $postfeld['add_tax2_wert']))/(1+$cfg_mwst), 2, ".", ""));
					if ($postfeld['add_tax2v']!='1') {
						$soa_p2=$soa_p;
					}
					$soa_vat=doubleval($soa_p)-doubleval($soa_p2);
					$ko_options[]=array('code' => 'L2', 'bez' => $postfeld['add_tax2'], 'bez2' => '', 'kat' => 'DealerFit', 'typ' => 'DealerFit_F_L2', 'net' => doubleval($soa_p2), 'preis' => doubleval($soa_p), 'dnp' => doubleval($soa_p2), 'mwst' => $soa_vat, 'serie' => false, 'parent_code' => '', 'loctax' => 0 );
				}
				$alle_adjustments='';

				if (intval($postfeld['vertrag_nwgw'])==1) {
					$auslpreis=doubleval($postfeld['vertrag_transport'])+doubleval($postfeld['vertrag_zulassung2']);
					$hauspreis=round($gespreis);
					$summe_br1=$hauspreis;
				} else {
					$auslpreis=doubleval($postfeld['vertrag_transport'])+doubleval($postfeld['vertrag_zulassung']);
					$hauspreis=round($gespreis);
					$summe_br1=round($preis_ges1+doubleval(str_replace(',', '.', $postfeld['listenpreis']))+doubleval(str_replace(',', '.', $postfeld['vertrag_transport']))+doubleval(str_replace(',', '.', $postfeld['vertrag_zulassung'])));
				}

				for ($auss_i=1; $auss_i<=20; $auss_i++) {
					$auss_iz=$auss_i;
					if ($postfeld['vertrag'.$ve_zus.'_sonderr'.$auss_iz]!='') {
						$diff=doubleval(str_replace(',', '.', $postfeld['vertrag'.$ve_zus.'_sonderrpreis'.$auss_iz]));
						$diff=abs($diff);

						$soa_p=str_replace(',', '.', $diff);
						$soa_p2=doubleval(number_format(doubleval(str_replace(',', '.', $diff))/(1+$cfg_mwstn), 2, ".", ""));
						$soa_vat=doubleval($soa_p)-doubleval($soa_p2);

						$alle_adjustments.='-'.'___'.
							$postfeld['vertrag'.$ve_zus.'_sonderr'.$auss_iz].'___'.
							''.'___'.
							$diff.'___'.
							$soa_p2.'___'.
							$soa_vat.'___'.
							''.'___'.
							$auss_iz.'___'.
							''.'___'.
							$diff.'***';
					}
				}

				if ($summe_br1!=$hauspreis and !$cfg_carlo_appserver_ws) {
					$diff=$hauspreis-$summe_br1;
					$difftyp='-';
					if ($diff>0) {
						$difftyp='+';
					}
					$diff=abs($diff);
					$alle_adjustments.=$difftyp.'___'.
							'Differenz Hauspreis zum Gesamtpreis'.'___'.
							''.'___'.
							$diff.'___'.
							''.'___'.
							''.'___'.
							''.'___'.
							''.'___'.
							''.'___'.
							$diff.'***';

				}
				if (p4n_mb_string('substr',$alle_adjustments, -3)=='***') {
					$alle_adjustments=p4n_mb_string('substr',$alle_adjustments, 0, -3);
				}
				$uvp_betrag=$summe;
				if ($uvp_betrag<=0) {
					$uvp_betrag=$mpv_preis;
				}
				$summe=$m_summe;
				
				$alle_tradeins='';
				if (isset($postfeld['vertrags_ankauf'])) {
					$alle_tradeins.=$postfeld['vertrags_gwmarke'].'___'.
							$postfeld['vertrags_gwtyp'].'___'.
							$postfeld['ankauf_motor'].'___'.
							$postfeld['vertrags_gwfgnr'].'___'.
							p4n_mb_string('substr',($cfg_kfzsuche_holland?$postfeld['vertrags_gwez']:$postfeld['ankauf_ez']), -4).'___'.
							$postfeld['vertrags_kennz'].'___'.
							$postfeld['ankauf_km'].'___'.
							$postfeld['briefnummer'].'___'.
							$postfeld['vertrags_gwpreis'].'___'.
							$postfeld['vertrags_gwpreis'].'___'.
							$postfeld['nl_tradein6'].'___'.
							str_replace(',', '.', $postfeld['nl_tradein2']).'___'.
							$postfeld['vertrags_kmstand'].'___'.
							$postfeld['vertrags_gwez'].'___'.
							((isset($postfeld['motornet_modelle']) and $postfeld['motornet_modelle']!='-1')?$postfeld['inz_ws_typ']:'').'___'.
							((isset($postfeld['motornet_modelle']) and $postfeld['motornet_modelle']!='-1')?$postfeld['motornet_modelle']:'').'___'.
							''.'___'.
							'';//.'***';
					if (isset($postfeld['vertrags_gwpreis2'])) {
						if ($postfeld['vertrags_gwpreis2']!='' or $postfeld['vertrags_gwmarke2']!='' or $postfeld['vertrags_gwtyp2']!='' or $postfeld['vertrags_kennz2']!='') {
							$alle_tradeins.='***'.$postfeld['vertrags_gwmarke2'].'___'.
							$postfeld['vertrags_gwtyp2'].'___'.
							$postfeld['ankauf_motor2'].'___'.
							$postfeld['vertrags_gwfgnr2'].'___'.
							p4n_mb_string('substr',($cfg_kfzsuche_holland?$postfeld['vertrags_gwez2']:$postfeld['ankauf_ez2']), -4).'___'.
							$postfeld['vertrags_kennz2'].'___'.
							$postfeld['ankauf_km2'].'___'.
							$postfeld['briefnummer2'].'___'.
							$postfeld['vertrags_gwpreis2'].'___'.
							$postfeld['vertrags_gwpreis2'].'___'.
							$postfeld['nl_tradein62'].'___'.
							str_replace(',', '.', $postfeld['nl_tradein22']).'___'.
							$postfeld['vertrags_kmstand2'].'___'.
							$postfeld['vertrags_gwez2'].'___'.
							((isset($postfeld['motornet_modelle']) and $postfeld['motornet_modelle']!='-1')?$postfeld['inz_ws_typ']:'').'___'.
							((isset($postfeld['motornet_modelle']) and $postfeld['motornet_modelle']!='-1')?$postfeld['motornet_modelle']:'').'___'.
							''.'___'.
							'';
						}
					}
				}
				$sql_opp=array(
					$sql_tabs['opportunity']['bezeichnung'] => $db->str($betre),
					$sql_tabs['opportunity']['ws_eintritt'] => $db->dbzahl(100),
					$sql_tabs['opportunity']['betrag'] => $db->dbzahl($summe),
					$sql_tabs['opportunity']['betrag_ist'] => $db->dbzahl($summe),
					$sql_tabs['opportunity']['quelle'] => $db->str($quelle),
					$sql_tabs['opportunity']['zusatz3'] => $db->str(''),			// nicht benutzen!
					$sql_tabs['opportunity']['deal_id'] => $db->str($anr2),
					$sql_tabs['opportunity']['quote_id'] => $db->str($quoteid),
//					$sql_tabs['opportunity']['rabatt_bezeichnung'] => $db->str(''),	// AdjustmentTypeElement ?
					$sql_tabs['opportunity']['rabatt_betrag'] => $db->dbzahl($merke_nachl_betrag_sum),//AdjustedAmount AdjustmentAmount
					$sql_tabs['opportunity']['rabatt_prozent'] => $db->dbzahl($merke_nachl_proz_sum),
					$sql_tabs['opportunity']['zusatz5'] => $db->str($alle_adjustments),
					$sql_tabs['opportunity']['zusatz6'] => $db->str($postfeld['vertrag_finart']),
					$sql_tabs['opportunity']['zusatz7'] => $db->str($postfeld['vertrags_vereinbarungen']),
					$sql_tabs['opportunity']['zusatz8'] => $db->str($alle_tradeins),
					$sql_tabs['opportunity']['zusatz9'] => $db->str($postfeld['vertrags_vereinbarungen2']),
					$sql_tabs['opportunity']['betrag1'] => $db->dbzahl($summe),
					$sql_tabs['opportunity']['betrag2'] => $db->dbzahl(0),
					$sql_tabs['opportunity']['betrag3'] => $db->dbzahl(0),
					$sql_tabs['opportunity']['betrag4'] => $db->dbzahl($summe),
					$sql_tabs['opportunity']['inzahlungnahme'] => $db->dbzahl(0),
					$sql_tabs['opportunity']['inzahlungnahme_text'] => $db->str(''),
					$sql_tabs['opportunity']['inzahlungnahme_zusatz'] => $db->str(''),
					$sql_tabs['opportunity']['kampagne_id'] => $db->dbzahl($kampa_id)
				);
				if ($cfg_olympia and isset($postfeld['vers_olympia'])) {
					$sql_opp[$sql_tabs['opportunity']['fakturiert_text']]=$db->str($postfeld['vers_olympia']);
				}
				if ($bez_ang_kv2=='skv') {
					$sql_opp[$sql_tabs['opportunity']['betrag']]=$db->dbzahl($ges_su);
					$sql_opp[$sql_tabs['opportunity']['betrag_ist']]=$db->dbzahl($ges_su);
				}
				if ($cfg_mboe_vorlagen) {
					$kommnrneu=$retailer_prefix*10000000+intval($anr);
					$sql_opp[$sql_tabs['opportunity']['quote_id']]=$db->str($kommnrneu);	// neu Auftragsnr.
					if (intval($postfeld['pid'])>0) {
						$einhc='';
						$res5=$db->select(
							$sql_tab['produktzuordnung'],
							array(
								$sql_tabs['produktzuordnung']['hersteller']
							),
							$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
						);
						if ($row5=$db->zeile($res5)) {
							$einhc=$row5[0];
						}
						$sql_opp[$sql_tabs['opportunity']['zusatz2']]=$db->str($einhc);		// Kommnr.
					}
				}
				if ($bez_ang_kv==_ANGEBOT_) {
					$sql_opp[$sql_tabs['opportunity']['ws_eintritt']]=$db->dbzahl(0);
					$sql_opp[$sql_tabs['opportunity']['betrag_ist']]=$db->dbzahl(0);
				}
				if ($bez_ang_kv==_KAUFVERTRAG_ and $cfg_kfzsuche_sofortgenehmigung) {
					$sql_opp[$sql_tabs['opportunity']['genehmigt_benutzer_id']]=$db->dbzahl($_SESSION['user_id']);
					$sql_opp[$sql_tabs['opportunity']['genehmigt_datum']]=$db->dbtimestamp(time());
				}
				$db->update(
					$sql_tab['opportunity'],
					$sql_opp,
					$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr2)
				);

				$farbdaten=$fa_itemcode.'#####'.$fa_code.'#####'.$fa_bez.'#####'.$fa_preis.'#####'.$fa_net.'#####'.$fa_dnp.'#####'.$postfeld['lt_farbe5'].'#####'.$fa_dnp2;
				$trimdaten=$tr_code.'#####'.$tr_bez.'#####'.$tr_preis.'#####'.$tr_net.'#####'.$tr_dnp.'#####'.$postfeld['lt_trim5'].'#####'.$tr_dnp2;
				
				if ($_SESSION['cfg_kunde']=='carlo_opel_dello') {
					if (substr(strtolower($postfeld['kfz_markencode']), 0, 4)!='opel') {
						$mpv_code='';
					}
				}
				
				if ($cfg_kfzsuche_holland and doubleval(str_replace(',', '.', $postfeld['lt_listenpreis5']))==0) {
					$postfeld['lt_listenpreis5']=$postfeld['bpm'];
				}
				
				$sql_konf=array(
			$sql_tabs['produktzuordnung_konfiguration']['produktzuordnung_id'] => $db->dbzahl($postfeld['pid']),
			$sql_tabs['produktzuordnung_konfiguration']['opportunity_id'] => $db->dbzahl($anr2),
			$sql_tabs['produktzuordnung_konfiguration']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
			$sql_tabs['produktzuordnung_konfiguration']['externe_id'] => $db->str($konfid),
			$sql_tabs['produktzuordnung_konfiguration']['bezeichnung'] => $db->str($konf_bez),
			$sql_tabs['produktzuordnung_konfiguration']['datum_erstellt'] => $db->dbtimestamp(time()),		//		$daten_config['CreationDate']),
			$sql_tabs['produktzuordnung_konfiguration']['datum_aenderung'] => $db->dbtimestamp(time()),		//		$db->str($daten_config['LastModifiedDate']),
			$sql_tabs['produktzuordnung_konfiguration']['betreuer_id'] => $db->dbzahl($ang_kv_user),
			$sql_tabs['produktzuordnung_konfiguration']['betreuer'] => $db->str($_SESSION['mitarbeiter_name']),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_mpvcode'] => $db->str($mpv_code),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_mpvbezeichnung'] => $db->str($mpv_bez),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_makestring'] => $db->str(''),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_modell'] => $db->str(''),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_motor'] => $db->str(''),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_trimcode'] => $db->str(''),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_bodystyle'] => $db->str(''),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_modelljahr'] => $db->str($mpv_mj),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_basepreis'] => $db->dbzahl($mpv_preis),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_listenpreis'] => $db->dbzahl($mpv_preis),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_netpreis'] => $db->dbzahl($mpv_dnp2),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_dealernetpreis'] => $db->dbzahl($mpv_dnp),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_taxparts'] => $db->str(doubleval(str_replace(',', '.', $postfeld['lt_listenpreis5']))),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_feeparts'] => $db->str(doubleval(str_replace(',', '.', $postfeld['bpm']))),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_preis'] => $db->dbzahl($summe),
			$sql_tabs['produktzuordnung_konfiguration']['farbe_daten'] => $db->str($farbdaten),
			$sql_tabs['produktzuordnung_konfiguration']['polster_daten'] => $db->str($trimdaten),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_id'] => $db->str($fgnr),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_ordernr'] => $db->str(''),	// $daten_config['VehicleOrderNumber']?
			$sql_tabs['produktzuordnung_konfiguration']['kfz_stockstring'] => $db->str($fgnr),//['Vehicle']['VehicleStockString']?
			$sql_tabs['produktzuordnung_konfiguration']['kfz_statuscode'] => $db->str(''),//['Vehicle']['VehicleStatusCode']?
			$sql_tabs['produktzuordnung_konfiguration']['kfz_kennzeichenpreis'] => $db->dbzahl(0),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_auslieferungpreis'] => $db->dbzahl($auslpreis),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_preis2'] => $db->dbzahl(0),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_preis3'] => $db->dbzahl(0),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_preis4'] => $db->dbzahl(0),
			$sql_tabs['produktzuordnung_konfiguration']['kfz_preis5'] => $db->dbzahl(0),
			$sql_tabs['produktzuordnung_konfiguration']['optionen'] => $db->str($konf_optionen)
				);
				$db->insert(
					$sql_tab['produktzuordnung_konfiguration'],
					$sql_konf
				);
				$konf_id=$db->insertid();

				while (list($keyo, $valo)=@each($ko_options)) {
				$opt_sql=array(
				$sql_tabs['produktzuordnung_konfiguration_option']['produktzuordnung_konfiguration_id'] => $db->dbzahl($konf_id),
				$sql_tabs['produktzuordnung_konfiguration_option']['optioncode'] => $db->str($valo['code']),
				$sql_tabs['produktzuordnung_konfiguration_option']['bezeichnung'] => $db->str(p4n_mb_string('substr',$valo['bez'], 0, 255)),
				$sql_tabs['produktzuordnung_konfiguration_option']['beschreibung'] => $db->str($valo['bez2']),
				$sql_tabs['produktzuordnung_konfiguration_option']['kategorie'] => $db->str($valo['kat']),
				$sql_tabs['produktzuordnung_konfiguration_option']['typ'] => $db->str($valo['typ']),
				$sql_tabs['produktzuordnung_konfiguration_option']['vkpreis'] => $db->dbzahl($valo['net']),
				$sql_tabs['produktzuordnung_konfiguration_option']['vkpreis_mwst'] => $db->dbzahl($valo['preis']),
				$sql_tabs['produktzuordnung_konfiguration_option']['netpreis'] => $db->dbzahl($valo['net']),
				$sql_tabs['produktzuordnung_konfiguration_option']['listenpreis'] => $db->dbzahl($valo['preis']),
				$sql_tabs['produktzuordnung_konfiguration_option']['mwst'] => $db->dbzahl($valo['mwst']),
				$sql_tabs['produktzuordnung_konfiguration_option']['mwst_proz'] => $db->dbzahl(0),
				$sql_tabs['produktzuordnung_konfiguration_option']['einbaupreis'] => $db->dbzahl(0),
				$sql_tabs['produktzuordnung_konfiguration_option']['art'] => $db->str(''),
				$sql_tabs['produktzuordnung_konfiguration_option']['kennzeichen'] => $db->str(''),
				$sql_tabs['produktzuordnung_konfiguration_option']['serienausstattung'] => $db->dblogic($valo['serie']),
				$sql_tabs['produktzuordnung_konfiguration_option']['rabatt_bezeichnung'] => $db->dbzahl(0),
				$sql_tabs['produktzuordnung_konfiguration_option']['rabatt'] => $db->dbzahl($valo['loctax']),	// oder AdjustmentAmount?
				$sql_tabs['produktzuordnung_konfiguration_option']['rabatt_proz'] => $db->dbzahl($valo['dnp2']),
				$sql_tabs['produktzuordnung_konfiguration_option']['dealernetpreis'] => $db->dbzahl($valo['dnp']),
				$sql_tabs['produktzuordnung_konfiguration_option']['tax_parts'] => $db->str(''),
				$sql_tabs['produktzuordnung_konfiguration_option']['adj_parts'] => $db->str(''),
				$sql_tabs['produktzuordnung_konfiguration_option']['parent_code'] => $db->str($valo['parent_code'])
				);
				$db->insert(
					$sql_tab['produktzuordnung_konfiguration_option'],
					$opt_sql
				);
				}
			}
			
			// Inz. KM-Stand updaten
			if (isset($postfeld['vertrags_ankauf']) and isset($postfeld['inz_auswahl_k'])) {
				if (intval($postfeld['inz_auswahl_k'])>0 and intval($postfeld['vertrags_kmstand'])>0) {
					include_once('inc/xml_io.php');
					carlo_km_stand_schreiben($postfeld['inz_auswahl_k'], intval($postfeld['vertrags_kmstand']));
				}
			}
			
			// Kauf zu DVS �bermitteln
			if ($bez_ang_kv==_KAUFVERTRAG_ and $cfg_dvs and intval($postfeld['pid'])>0) {
				$res5=$db->select(
					$sql_tab['produktzuordnung'],
					$sql_tabs['produktzuordnung']['hersteller'],
					$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
				);
				if ($row5=$db->zeile($res5)) {
					if (p4n_mb_string('strlen',$row5[0])>10 or ($cfg_dvs_fm and $row5[0]!='')) {
						$postfeld['dvs_id']=$row5[0];
					}
				}
			}
			
			if ($bez_ang_kv==_KAUFVERTRAG_ and isset($postfeld['docusign']) and !empty($cfg_docusign)) {
				$res3=$db->select(
					$sql_tab['stammdaten'],
					array(
						$sql_tabs['stammdaten']['anzeigename'],
						$sql_tabs['stammdaten']['EMail_1'],
						$sql_tabs['stammdaten']['EMail_2']
					),
					$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($_SESSION['stammdaten_id'])
				);
				$row3=$db->zeile($res3);
				$emailk=$row3[1];
				if ($emailk=='') {
					$emailk=$row3[2];
				}
				if ($emailk!='') {
					$documentpfad = 'dokumente_korrespondenz/'.$doclink;
					$kundenmail = $emailk;
					$kundenname = $row3[0];
					$mailbetreff = _KAUFVERTRAG_.' - '.date('d.m.Y H:i:s');
					$mailtext = 'Bitte unterscheiben Sie den Kaufvertrag. Ihr Autohaus Prof4Net';

                    try {
                        Docusign::instance()->prepareDataAndSendToDocuSign(
                            array(
                                'opportunity_id'  => $anr,
                                'file'            => $documentpfad,
                                'email_of_signer' => $kundenmail,
                                'name_of_signer'  => $kundenname,
                                'subject'         => $mailbetreff,
                                'mail_body'       => $mailtext
                            )
                        );
                    } catch ( Exception $e ) {
                        echo javas( 'alert("DocuSign ' . _FEHLER_ . ': ' . addslashes( $e->getMessage() ) . '")' );
                    }
				}
			}
			
			// E-Mail
			if ($bez_ang_kv==_KAUFVERTRAG_) {
				
				$vorlagetext2='';
				if ($cfg_kfzsuche_kv_mail_an_kfzlao or $_SESSION['cfg_kunde']=='carlo_opel_duerkop' or $_SESSION['cfg_kunde']=='carlo_opel_dello') {
					$res99=$db->select(
						$sql_tab['email_vorlagen'],
						array(
							$sql_tabs['email_vorlagen']['htmltext'],
							$sql_tabs['email_vorlagen']['email_vorlagen_id']
						),
						$sql_tabs['email_vorlagen']['bezeichnung'].' like '.$db->str('Kaufvertrag Standort')
					);
            	    $p4n_editor = false;
	                if ($row99=$db->zeile($res99)) {
						if ($cfg_mailversand_editor && is_file('inc/lib_htmledit.php')) {
        	                global $cfg_newsletterbaukasten_p4n, $cfg_newsletterbaukasten_2_p4n, $cfg_newsletterbaukasten_p4n_ohne_tracking;
							include_once 'inc/lib_htmledit.php';
							$html_editor2 = new HTMLEditor();
							$mail_vorlage2=$html_editor2->prepare_mail($row99[1]);
							$vorlagetext2=p4n_mb_string('str_replace', array('&lt;', '&gt;'), array('<', '>'), $mail_vorlage2->Body);
        	                if ($mail_vorlage2->CharSet == 'utf-8') {
            	                $vorlagetext2=p4n_mb_string('utf8_decode', $vorlagetext2);
                	            $p4n_editor=true;
	                        }
    	                } else {
        	                $vorlagetext2=p4n_mb_string('str_replace', array('&lt;', '&gt;'), array('<', '>'), $row99[0]);
						}
					}
				}
				
				$res99=$db->select(
					$sql_tab['email_vorlagen'],
					array(
						$sql_tabs['email_vorlagen']['htmltext'],
						$sql_tabs['email_vorlagen']['email_vorlagen_id']
					),
					$sql_tabs['email_vorlagen']['bezeichnung'].' like '.$db->str('Kaufvertrag VKL')
				);
                $p4n_editor = false;
                if ($row99=$db->zeile($res99)) {
					if ($cfg_mailversand_editor && is_file('inc/lib_htmledit.php')) {
                        global $cfg_newsletterbaukasten_p4n, $cfg_newsletterbaukasten_2_p4n, $cfg_newsletterbaukasten_p4n_ohne_tracking;
						include_once 'inc/lib_htmledit.php';
						$html_editor = new HTMLEditor();
						$mail_vorlage=$html_editor->prepare_mail($row99[1]);
						$vorlagetext=p4n_mb_string('str_replace', array('&lt;', '&gt;'), array('<', '>'), $mail_vorlage->Body);
                        if ($mail_vorlage->CharSet == 'utf-8') {
                            $vorlagetext=p4n_mb_string('utf8_decode', $vorlagetext);
                            $p4n_editor=true;
                        }
                    } else {
                        $vorlagetext=p4n_mb_string('str_replace', array('&lt;', '&gt;'), array('<', '>'), $row99[0]);
					}
					
					$alle_mails=array();
					$alle_mails2=array();
					
					$lao_kfz=0;
					if (intval($postfeld['pid'])>0 and ($cfg_kfzsuche_kv_mail_an_kfzlao or $_SESSION['cfg_kunde']=='carlo_opel_duerkop' or $_SESSION['cfg_kunde']=='carlo_opel_dello')) {
						$res5=$db->select(
							$sql_tab['produktzuordnung'],
							$sql_tabs['produktzuordnung']['mandant_id'],
							$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
						);
						if ($row5=$db->zeile($res5)) {
							if (intval($row5[0])>0 and intval($row5[0])!=intval($postfeld['mvertrag_lagerort'])) {
								$lao_kfz=$row5[0];
							}
						}
					}
					
					if ($_SESSION['cfg_kunde']=='carlo_weller') {
						if ($kfz_fstatus=='AUTOproff' or $kfz_fstatus=='Gebrauchtfahrzeug') {
							$res7=$db->select(
								$sql_tab['benutzer_gruppe'],
								array(
									$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
									$sql_tabs['benutzer_gruppe']['bezeichnung']
								),
								$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('Kaufvertrag AutoProff/GW')
							);
							while ($row7=$db->zeile($res7)) {
								$res8=$db->select(
									$sql_tab['benutzer_gruppe_zuordnung'],
									$sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'],
									$sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row7[0])
								);
								while ($row8=$db->zeile($res8)) {
									$res9=$db->select(
										$sql_tab['benutzer'],
										array(
											$sql_tabs['benutzer']['email'],
											$sql_tabs['benutzer']['standard_lagerort']
										),
										$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row8[0])
									);
									if ($row9=$db->zeile($res9)) {
										if ($row9[0]!='') {
											$alle_mails[]=$row9[0];
										}
									}
								}
							}
						}
						if ($kfz_fstatus=='Neufahrzeug' or $kfz_fstatus=='Tageszulassung' or $kfz_fstatus=='Vorf�hrfahrzeug' or $kfz_fstatus=='Mietfahrzeug') {
							$res7=$db->select(
								$sql_tab['benutzer_gruppe'],
								array(
									$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
									$sql_tabs['benutzer_gruppe']['bezeichnung']
								),
								$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('Kaufvertrag NW/TZ/VFW/MW')
							);
							while ($row7=$db->zeile($res7)) {
								$res8=$db->select(
									$sql_tab['benutzer_gruppe_zuordnung'],
									$sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'],
									$sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row7[0])
								);
								while ($row8=$db->zeile($res8)) {
									$res9=$db->select(
										$sql_tab['benutzer'],
										array(
											$sql_tabs['benutzer']['email'],
											$sql_tabs['benutzer']['standard_lagerort']
										),
										$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row8[0])
									);
									if ($row9=$db->zeile($res9)) {
										if ($row9[0]!='') {
											$alle_mails[]=$row9[0];
										}
									}
								}
							}
						}
					}
					
					$res7=$db->select(
						$sql_tab['benutzer_gruppe'],
						array(
							$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
							$sql_tabs['benutzer_gruppe']['bezeichnung']
						),
						$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('Verkaufsleiter').($cfg_kvmail_verkauf?' or '.$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str(_MAIL_):'')
					);
					while ($row7=$db->zeile($res7)) {
						$res8=$db->select(
							$sql_tab['benutzer_gruppe_zuordnung'],
							$sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'],
							$sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row7[0])
						);
						while ($row8=$db->zeile($res8)) {
							$alle_auswlao_rechte=array();
							$res9=$db->select(
            			        $sql_tab['benutzer_mandant_auswertung'],
								$sql_tabs['benutzer_mandant_auswertung']['mandant_id'],
								$sql_tabs['benutzer_mandant_auswertung']['benutzer_id'].'='.$db->dbzahl($row8[0])
				            );
							while ($row9=$db->zeile($res9)) {
								$alle_auswlao_rechte[$row9[0]]=1;
							}
							$res9=$db->select(
								$sql_tab['benutzer'],
								array(
									$sql_tabs['benutzer']['email'],
									$sql_tabs['benutzer']['standard_lagerort']
								),
								$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row8[0])
							);
							if ($row9=$db->zeile($res9)) {
								if ($cfg_vkmail_stdlao) {
									if (intval($row9[1])>0 and intval($postfeld['mvertrag_lagerort'])>0 and $row9[1]==$postfeld['mvertrag_lagerort'] and $row9[0]!='') {
										$alle_mails[]=$row9[0];
									}
								} elseif (intval($postfeld['mvertrag_lagerort'])>0 and isset($alle_auswlao_rechte[$postfeld['mvertrag_lagerort']]) and $row9[0]!='') {	//$row9[1]==$postfeld['mvertrag_lagerort']
									$alle_mails[]=$row9[0];
								}
								if (intval($lao_kfz)>0 and isset($alle_auswlao_rechte[$lao_kfz]) and $row9[0]!='') {
									$alle_mails2[]=$row9[0];
								}
							}
						}
						// $postfeld['mvertrag_lagerort']
					}
					
					if (count($alle_mails)>0 and $vorlagetext!='') {
						$absender_mail2_from=$_SESSION['user_email'];
						if ($absender_mail2_from=='') {
							$absender_mail2_from=$mcs_pop3_email;
						}
						$absender_mail2=$_SESSION['mitarbeiter_name'];
						$absender_mail3=$absender_mail2;
						$absender_mail3_from=$absender_mail2_from;
						$absender_telefon='';
						$absender_name=$_SESSION['mitarbeiter_name'];
						$res100=$db->select(
							$sql_tab['benutzer'],
							array(
								$sql_tabs['benutzer']['name'],
								$sql_tabs['benutzer']['vorname'],
								$sql_tabs['benutzer']['email'],
								$sql_tabs['benutzer']['telefon']
							),
							$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($ang_kv_user)	//$row99[8]
						);
						if ($row100=$db->zeile($res100)) {
							if ($row100[2]!='') {
								$absender_mail3=$row100[0].', '.$row100[1];
								$absender_mail3_from=$row100[2];
								$absender_name=$row100[1].' '.$row100[0];
								$absender_telefon=$row100[3];
							}
						}
						
						include_once("mailconf.php");
						$mail->From     = $absender_mail3_from;
						$mail->FromName = 'CRM - '.$absender_name;
						$mail->ClearAllRecipients();
						$mail->ClearAttachments();
						$mail->ClearBCCs();
						$mail->IsHTML(true);
						$mail->Subject=_KAUFVERTRAG_.' '.$kfz_fstatus;
						$a_alle_mails2='';
						while (list($keye, $vale)=@each($alle_mails)) {
							$mail->AddAddress($vale);
							$a_alle_mails2.=$vale.'#';
						}
						$a_alle_mails2=substr($a_alle_mails2, 0, -1);
						$mail->Body='';
						if ($vorlagetext!='') {
                            if (!$cfg_mailversand_editor) {
                                $b_vorlagetext=nl2br($vorlagetext);
                                $b_vorlagetext2=nl2br($vorlagetext2);
                            } else {
                                $b_vorlagetext=$vorlagetext;
                                $b_vorlagetext2=$vorlagetext2;
                            }
							$b_vorlagetext=preg_replace('/<<mitarbeiter_telefon>>/', $absender_telefon, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<'.bef_format(_MITARBEITER_).'_'.bef_format(_TELEFON2_).'>>/', $absender_telefon, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<mitarbeiter>>/', $absender_name, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<'.bef_format(_MITARBEITER_).'>>/', $absender_name, $b_vorlagetext);
							$b_vorlagetext2=preg_replace('/<<mitarbeiter_telefon>>/', $absender_telefon, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<'.bef_format(_MITARBEITER_).'_'.bef_format(_TELEFON2_).'>>/', $absender_telefon, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<mitarbeiter>>/', $absender_name, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<'.bef_format(_MITARBEITER_).'>>/', $absender_name, $b_vorlagetext2);
							$ertragsrech='';
							if (function_exists('bruttoertrag_anzeige')) {
								$ertragsrech=bruttoertrag_anzeige($anr,true);
							}
                            $b_vorlagetext=preg_replace('/<<ertragsrechnung>>/', $ertragsrech, $b_vorlagetext);
                            $b_vorlagetext2=preg_replace('/<<ertragsrechnung>>/', $ertragsrech, $b_vorlagetext2);
							if ($_SESSION['crm_version']>60) {
								$ovkhilfen='';
								for ($vi=1; $vi<=10; $vi++) {
									if (isset($postfeld['vkh_progn'.$vi])) {
										if ($postfeld['vkh_progn'.$vi]!='') {
											$ovkhilfen.=$postfeld['vkh_progn'.$vi].': '.$postfeld['vkh_proge'.$vi].($postfeld['vkh_progp'.$vi]!=''?' ('.$postfeld['vkh_progp'.$vi].' %)':'').'<br>';
										}
									}
								}
								if ($ovkhilfen=='') {
									for ($vi=1; $vi<=10; $vi++) {
										if (isset($postfeld['vertrag5_vkhbez'.$vi])) {
											if ($postfeld['vertrag5_vkhbez'.$vi]!='') {
												$ovkhilfen.=$postfeld['vertrag5_vkhbez'.$vi].': '.$postfeld['vertrag5_vkh'.$vi].($postfeld['vkh_progp'.$vi]!=''?' ('.$postfeld['vertrag5_vkhp'.$vi].' %)':'').'<br>';
											}
										}
									}
								}
								$ovkhilfen=substr($ovkhilfen, 0, -4);
								
								$b_vorlagetext=preg_replace('/<<verkaufshilfen>>/', $ovkhilfen, $b_vorlagetext);
								$b_vorlagetext2=preg_replace('/<<verkaufshilfen>>/', $ovkhilfen, $b_vorlagetext2);
								
								$nachlaesse='';
								for ($vi=1; $vi<=10; $vi++) {
									if (isset($postfeld['vertrag5_sonderrpreis'.$vi])) {
										if ($postfeld['vertrag5_sonderrpreis'.$vi]!='') {
											$nachlaesse.=$postfeld['vertrag5_sonderr'.$vi].': '.$postfeld['vertrag5_sonderrpreis'.$vi].($postfeld['vertrag5_sonderrppreis'.$vi]!=''?' ('.$postfeld['vertrag5_sonderrppreis'.$vi].' %)':'').'<br>';
										}
									}
								}
							}
							$nachlaesse=substr($nachlaesse, 0, -4);
							$b_vorlagetext=preg_replace('/<<nachlaesse>>/', $nachlaesse, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<nachlaesse_text>>/', $nachlaesse, $b_vorlagetext);
							$b_vorlagetext2=preg_replace('/<<nachlaesse>>/', $nachlaesse, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<nachlaesse_text>>/', $nachlaesse, $b_vorlagetext2);
							
							$uvp_betrag=$postfeld['listenpreis5'];
							if (intval($postfeld['listenpreis5'])==0 and intval($postfeld['fin_preis2'])!=0) {
								$uvp_betrag=$postfeld['fin_preis2'];
							}
							$uvp_betrag=doubleval(p4n_mb_string('str_replace',',', '.', $uvp_betrag));
							if (doubleval($postfeld['vertrag5_farbepreis'])>0) {
								$uvp_betrag+=doubleval(number_format(doubleval(p4n_mb_string('str_replace',',', '.', $postfeld['vertrag5_farbepreis'])), 2, ".", ""));
							}
							if (doubleval($postfeld['vertrag5_trimpreis'])>0) {
								$uvp_betrag+=doubleval(number_format(doubleval(p4n_mb_string('str_replace',',', '.', $postfeld['vertrag5_trimpreis'])), 2, ".", ""));
							}
							for ($xi=1; $xi<500; $xi++) {
								if (isset($postfeld['vertrag5_sonder'.$xi])) {
									if (doubleval($postfeld['vertrag5_sonderpreis'.$xi])!=0) {
										$uvp_betrag+=doubleval(number_format(doubleval(p4n_mb_string('str_replace',',', '.', $postfeld['vertrag5_sonderpreis'.$xi])), 2, ".", ""));
									}
								}
							}
							
							$b_vorlagetext=preg_replace('/<<oppid>>/', $anr, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<datum>>/', adodb_date('d.m.Y', time()), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<uhrzeit>>/', adodb_date('H:i', time()), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<kundenname>>/', kundenbezeichnung($_SESSION['stammdaten_id']), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<verkaufspreis>>/', number_format(doubleval($summe), 2, ",", "."), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<uvp>>/', number_format(doubleval($uvp_betrag), 2, ",", "."), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<ber_summe>>/', number_format(doubleval($postfeld['marge2_betrag']), 2, ",", "."), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<ber_prozent>>/', number_format(doubleval($postfeld['marge2_prozent']), 2, ",", "."), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<ber_summe2>>/', number_format(doubleval($postfeld['marge2_betrag2']), 2, ",", "."), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<ber_prozent2>>/', number_format(doubleval($postfeld['marge2_prozent2']), 2, ",", "."), $b_vorlagetext);
							
							$b_vorlagetext=preg_replace('/<<standtage>>/', intval($kfz_standt), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<ekpreis>>/', number_format(doubleval($kfz_ekp), 2, ",", "."), $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<fahrzeugstatus>>/', $kfz_fstatus, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<standort>>/', $pid_standort, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<text_1>>/', $kfz_t1, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<text_2>>/', $kfz_t2, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<text_3>>/', $kfz_t3, $b_vorlagetext);
							$b_vorlagetext=preg_replace('/<<text_4>>/', $kfz_t4, $b_vorlagetext);
							
							$b_vorlagetext2=preg_replace('/<<oppid>>/', $anr, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<datum>>/', adodb_date('d.m.Y', time()), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<uhrzeit>>/', adodb_date('H:i', time()), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<kundenname>>/', kundenbezeichnung($_SESSION['stammdaten_id']), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<verkaufspreis>>/', number_format(doubleval($summe), 2, ",", "."), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<uvp>>/', number_format(doubleval($uvp_betrag), 2, ",", "."), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<ber_summe>>/', number_format(doubleval($postfeld['marge2_betrag']), 2, ",", "."), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<ber_prozent>>/', number_format(doubleval($postfeld['marge2_prozent']), 2, ",", "."), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<ber_summe2>>/', number_format(doubleval($postfeld['marge2_betrag2']), 2, ",", "."), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<ber_prozent2>>/', number_format(doubleval($postfeld['marge2_prozent2']), 2, ",", "."), $b_vorlagetext2);
							
							$b_vorlagetext2=preg_replace('/<<standtage>>/', intval($kfz_standt), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<ekpreis>>/', number_format(doubleval($kfz_ekp), 2, ",", "."), $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<fahrzeugstatus>>/', $kfz_fstatus, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<standort>>/', $pid_standort, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<zusatz1>>/', $pid_zusatz1, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<refnr>>/', $kfz_haendlerstatus, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<text_1>>/', $kfz_t1, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<text_2>>/', $kfz_t2, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<text_3>>/', $kfz_t3, $b_vorlagetext2);
							$b_vorlagetext2=preg_replace('/<<text_4>>/', $kfz_t4, $b_vorlagetext2);
							
							$m_ist_docx=$ist_docx;
							$ist_docx=false;
							$b_vorlagetext=ersetze_nwgwbed_felder($b_vorlagetext);
							$b_vorlagetext2=ersetze_nwgwbed_felder($b_vorlagetext2);
							$ist_docx=$m_ist_docx;
							
							$mail->Body=$b_vorlagetext;
							if ($p4n_editor) {
                                $mail->Body=p4n_mb_string('utf8_encode', $mail->Body);
                            }
							if (isset($sql_tabs['opportunity']['zusatz10'])) {
								
								if (intval($lao_kfz)>0) {
									if (count($alle_mails2)>0) {
										$a_alle_mails22='';
										while (list($keye, $vale)=@each($alle_mails2)) {
											$a_alle_mails22.=$vale.'#';
										}
										$a_alle_mails22=substr($a_alle_mails22, 0, -1);
										
										$subj2='Achtung, es wurde ein Fahrzeug Ihres Standorts von einer anderen Filiale verkauft - '._KAUFVERTRAG_.' '.$kfz_fstatus;
									}
								}
								
								$opp_maildaten1=$absender_mail3_from.';;;'.'CRM - '.$absender_name.';;;'.$a_alle_mails2.';;;'._KAUFVERTRAG_.' '.$kfz_fstatus.';;;'.base64_encode($b_vorlagetext).';;;'.$a_alle_mails22.';;;'.$subj2.';;;'.base64_encode($b_vorlagetext2);
								
								$db->update(
									$sql_tab['opportunity'],
									array(
										$sql_tabs['opportunity']['zusatz10'] => $db->str($opp_maildaten1)
									),
									$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr)
								);
							}
							
							if (!$cfg_kfzsuche_kvunbestaetigt) {
//							if ($cfg_carlo_exportdeal_sofort or $cfg_kvmail_verkauf) {
								$gesendet=$mail->Send();
								
								if ($fp2=fopen('inc/'.$_SESSION['cfg_kunde'].'/maillog.txt', 'a')) {
									fwrite($fp2, adodb_date('d.m.Y H:i:s', time()).': '.$row7[0].' '.($gesendet?_OK_:_FEHLER_).' - '.'VKL'.': '.$anr.' / '._BENUTZER_.': '.$_SESSION['mitarbeiter_name2']."\r\n");
									fclose($fp2);
								}
								
								if (count($alle_mails2)>0) {
									$mail->ClearAllRecipients();
									$mail->Subject='Achtung, es wurde ein Fahrzeug Ihres Standorts von einer anderen Filiale verkauft - '._KAUFVERTRAG_.' '.$kfz_fstatus;
									while (list($keye, $vale)=@each($alle_mails2)) {
										$mail->AddAddress($vale);
									}
									$mail->Body=$b_vorlagetext2;
									if ($p4n_editor) {
		                                $mail->Body=p4n_mb_string('utf8_encode', $mail->Body);
		                            }
									$gesendet2=$mail->Send();
									
									if ($fp2=fopen('inc/'.$_SESSION['cfg_kunde'].'/maillog.txt', 'a')) {
										fwrite($fp2, adodb_date('d.m.Y H:i:s', time()).': '.$row7[0].' '.($gesendet2?_OK_:_FEHLER_).' - '.'VKL anderer Standort'.': '.$anr.' / '._BENUTZER_.': '.$_SESSION['mitarbeiter_name2']."\r\n");
										fclose($fp2);
									}
								}
							}
						}
					}
				}
			}
			
			// KV zu S4-S �bermitteln
			if (isset($cfg_carlo_appserver_ip)) {
				@reset($cfg_carlo_appserver_ip);
				if (list($key, $val)=@each($cfg_carlo_appserver_ip)) {
					if (preg_match('/UDIService/i', $val)) {
						$cfg_carlo_appserver_ws=true;
					}
				}
				@reset($cfg_carlo_appserver_ip);
			}
			if ($cfg_incadeadms2017) {
				$cfg_carlo_appserver_ws=true;
			}
			if ($cfg_submitkv_profitc_konf) {
				if ($postfeld['freiekonf']=='1' or (($kfz_fstatus=='Neufahrzeug - konfiguriert' or $kfz_fstatus==_VEHICLE_CONFIGURED_) and $quelle!='GMEVC')) {
					$cfg_submitkv_profitc=true;
				} else {
					$cfg_submitkv_profitc=false;
				}
			}
			if ($cfg_submitkv_profitc_konf_nw) {
				if ($postfeld['freiekonf']=='1' or (intval($postfeld['pid'])>0 and $kfz_fstatuscode=='0') or (($kfz_fstatus=='Neufahrzeug - konfiguriert' or $kfz_fstatus==_VEHICLE_CONFIGURED_) and $quelle!='GMEVC')) {
					$cfg_submitkv_profitc=true;
				} else {
					$cfg_submitkv_profitc=false;
				}
			}
			if ($bez_ang_kv==_KAUFVERTRAG_ and $cfg_carlo_appserver and $cfg_carlo_appserver_ws and !$cfg_carlo_appserver_ws_kv_genehmigen and !$cfg_submitkv_profitc) {
				$res6=$db->select(
					$sql_tab['stammdaten_mandant'],
					array(
						$sql_tabs['stammdaten_mandant']['mandant_id'],
						$sql_tabs['stammdaten_mandant']['lagerort'],
						$sql_tabs['stammdaten_mandant']['nummer1'],
						$sql_tabs['stammdaten_mandant']['nummer2']
					),
					$sql_tabs['stammdaten_mandant']['stammdaten_id'].'='.$db->dbzahl($_SESSION['stammdaten_id']).' and '.
						'('.$sql_tabs['stammdaten_mandant']['nummer1'].'!='.$db->str('').' or '.$sql_tabs['stammdaten_mandant']['nummer2'].'!='.$db->str('').')'
				);
				if ($row6=$db->zeile($res6)) {
					uebertrage_deal($anr);
				} else {
					echo javas('alert("'._FEHLER_KVUEBER_.'");');
				}
			}
			
			if ($cfg_kfz_webservice_mitkunde and (!$cfg_carlo_appserver_ws_kv_genehmigen or $bez_ang_kv==_ANGEBOT_) and !$vorschau and ($bez_ang_kv==_KAUFVERTRAG_ or $bez_ang_kv==_ANGEBOT_) and $cfg_kfz_webservice) {
				if ($cfg_mboe_vorlagen and $bez_ang_kv==_ANGEBOT_) {
					// MBOE Angebote nicht mehr
				} else {
					ws_kroa_kfz($postfeld['pid'], 1, '', 0, 0, 'dokumente_korrespondenz/'.$doclink, $_SESSION['stammdaten_id'], $anr, $ins_k_id, $konf_id);
				}
			}
			
			// freie Inzahlungnahme:
			if (!$keine_dvssuche and $bez_ang_kv==_KAUFVERTRAG_ and $cfg_dvs and isset($postfeld['vertrags_ankauf']) and ($postfeld['dvs_id']=='' or !isset($postfeld['dvs_id']))) {
				$datum_in1=$postfeld['vertrags_gwlieferung'];
				if ($datum_in1=='') {
					$datum_in1=adodb_date('d.m.Y');
				}
				include_once('webservice/nusoap.php');
				$client = new nusoap_client($cfg_dvs_ws, true);
				$dpreis=doubleval(str_replace(',', '.', $postfeld['fin_preis']));
				$dnetto=doubleval($dpreis*100/(100+(100*$cfg_mwst)));
				$ust1=$dpreis-$dnetto;
				$liefert=time();
				if (isset($postfeld['vertrag_liefertermin']) and $postfeld['vertrag_liefertermin']!='') {
					$datum_lt=$postfeld['vertrag_liefertermin'];
					$liefert=adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_lt,3,2),p4n_mb_string('substr',$datum_lt,0,2),p4n_mb_string('substr',$datum_lt,6,4) );
				} elseif (isset($postfeld['vertrag_liefertermin1'])) {
					$liefert=strtotime($postfeld['vertrag_liefertermin2'].'W'.(strlen($postfeld['vertrag_liefertermin1'])==1?'0':'').$postfeld['vertrag_liefertermin1']);
				}
				$auslt=$liefert;
				if (isset($postfeld['vertrag_auslieferung']) and $postfeld['vertrag_auslieferung']!='') {
					$datum_lt=$postfeld['vertrag_auslieferung'];
					$auslt=adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_lt,3,2),p4n_mb_string('substr',$datum_lt,0,2),p4n_mb_string('substr',$datum_lt,6,4) );
				}

				$sf_ar=array();
				if (isset($postfeld['vertrags_ankauf'])) {
					$sf_ar=array(
						'ID' => -1,
						'DATAZ' => $postfeld['inz_auswahl'],
						'Lagerort' => intval($v_lao2),
						'Ankaufpreis' => strval(doubleval(str_replace(',', '.', $postfeld['vertrags_gwpreis']))),
						'Lieferdatum' => timestamp_to_iso8601(adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_in1,3,2),p4n_mb_string('substr',$datum_in1,0,2),p4n_mb_string('substr',$datum_in1,6,4) )),
						'Ankaeufer' => $dvs_username,
						'Steuerart' => $postfeld['vertrags_dvs_steuer'],
						'Hereinnahmeart' => $postfeld['vertrags_dvs_h1'],
						'Hereinnahmeunterart' => $postfeld['vertrags_dvs_h2'],
						'Datum_Ankauf' => timestamp_to_iso8601(adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_in1,3,2),p4n_mb_string('substr',$datum_in1,0,2),p4n_mb_string('substr',$datum_in1,6,4) )),
						'Status' => 1
					);
				}
				$result = $client->call("freieInzahlungname", array(
					'InCar' => $sf_ar
				));
				if ($dvs_ws_logging_sf) {
					if ($dvs_ws_logging_alert) {
						echo javas('alert("'.p4n_mb_string('substr',str_replace(array('"', "\n", "\r"), '', $client->request), 0, 1000).'");');
						echo javas('alert("'.p4n_mb_string('substr',str_replace(array('"', "\n", "\r"), '', $client->response), 0, 1000).'");');
					}
					if ($fp=fopen('log/dvs/crm2dvs_freieInzahlungname_request_.'.adodb_date('d_m_Y_His').'.xml', 'w')) {
						fwrite($fp, $client->request);
						fclose($fp);
					}
					if ($fp=fopen('log/dvs/crm2dvs_freieInzahlungname_.'.adodb_date('d_m_Y_His').'.xml', 'w')) {
						fwrite($fp, $client->response);
						fclose($fp);
					}
				}
				if (isset($result['freieInzahlungnameResult'])) {
					if (p4n_mb_string('strtolower',$result['freieInzahlungnameResult']['Status'])=='false') {
						echo javas('alert("Achtung: Ankauf wurde nicht nach DVS gemeldet!");');
					}
					echo javas('alert("DVS-Status: '.$result['freieInzahlungnameResult']['Beschreibung'].'.");');
				} else {
					echo javas('alert("Achtung: technischer Fehler, Ankauf wurde nicht nach DVS gemeldet!");');
				}
			}

				$dpreis=doubleval(str_replace(',', '.', $postfeld['fin_preis']));
				$dnetto=doubleval($dpreis*100/(100+(100*$cfg_mwst)));
				$ust1=$dpreis-$dnetto;
				$liefert=time();
				if (isset($postfeld['vertrag_liefertermin']) and $postfeld['vertrag_liefertermin']!='') {
					$datum_lt=$postfeld['vertrag_liefertermin'];
					$liefert=adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_lt,3,2),p4n_mb_string('substr',$datum_lt,0,2),p4n_mb_string('substr',$datum_lt,6,4) );
				} elseif (isset($postfeld['vertrag_liefertermin1'])) {
					$liefert=strtotime($postfeld['vertrag_liefertermin2'].'W'.(strlen($postfeld['vertrag_liefertermin1'])==1?'0':'').$postfeld['vertrag_liefertermin1']);
				}
				$auslt=$liefert;
				if (isset($postfeld['vertrag_auslieferung']) and $postfeld['vertrag_auslieferung']!='') {
					$datum_lt=$postfeld['vertrag_auslieferung'];
					$auslt=adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_lt,3,2),p4n_mb_string('substr',$datum_lt,0,2),p4n_mb_string('substr',$datum_lt,6,4) );
				}

			if ($bez_ang_kv==_KAUFVERTRAG_ and $cfg_dvs and $postfeld['dvs_id']!='') {
				$datum_in1=$postfeld['vertrags_gwlieferung'];
				if ($datum_in1=='') {
					$datum_in1=adodb_date('d.m.Y');
				}
				include_once('webservice/nusoap.php');
				$client = new nusoap_client($cfg_dvs_ws, true);
				$dpreis=doubleval(str_replace(',', '.', $postfeld['fin_preis']));
				$dnetto=doubleval($dpreis*100/(100+(100*$cfg_mwst)));
				$ust1=$dpreis-$dnetto;
				$liefert=time();
				if (isset($postfeld['vertrag_liefertermin']) and $postfeld['vertrag_liefertermin']!='') {
					$datum_lt=$postfeld['vertrag_liefertermin'];
					$liefert=adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_lt,3,2),p4n_mb_string('substr',$datum_lt,0,2),p4n_mb_string('substr',$datum_lt,6,4) );
				} elseif (isset($postfeld['vertrag_liefertermin1'])) {
					$liefert=strtotime($postfeld['vertrag_liefertermin2'].'W'.(strlen($postfeld['vertrag_liefertermin1'])==1?'0':'').$postfeld['vertrag_liefertermin1']);
				}
				$auslt=$liefert;
				if (isset($postfeld['vertrag_auslieferung']) and $postfeld['vertrag_auslieferung']!='') {
					$datum_lt=$postfeld['vertrag_auslieferung'];
					$auslt=adodb_mktime(12,0,0,p4n_mb_string('substr',$datum_lt,3,2),p4n_mb_string('substr',$datum_lt,0,2),p4n_mb_string('substr',$datum_lt,6,4) );
				}

			}

			if ($bez_ang_kv==_KAUFVERTRAG_) {
				$sqlt_kv=array(
					$sql_tabs['produktzuordnung']['kaufvertrag'] => $db->dblogic(true),
					$sql_tabs['produktzuordnung']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
					$sql_tabs['produktzuordnung']['kaufvertrag_kunde'] => $db->dbzahl($_SESSION['stammdaten_id']),
					$sql_tabs['produktzuordnung']['angebot'] => $db->dblogic(false),
					$sql_tabs['produktzuordnung']['angebot_kunde'] => $db->dbzahl(0),
					$sql_tabs['produktzuordnung']['angebot2'] => $db->dblogic(false),
					$sql_tabs['produktzuordnung']['angebot2_kunde'] => $db->dbzahl(0),
					$sql_tabs['produktzuordnung']['merkeverkauf_benutzer'] => $db->dbzahl(0),
					$sql_tabs['produktzuordnung']['merkeverkauf_datum'] => $db->dbdate('')
				);
				if ($cfg_kfzsuche_kvunbestaetigt) {
				//	unset($sql_tabs['produktzuordnung']['stammdaten_id']);
				}
				$res77=$db->select(
					$sql_tab['produktzuordnung'],
					array(
						$sql_tabs['produktzuordnung']['fahrzeugstatus'],
						$sql_tabs['produktzuordnung']['fahrzeugstatus_code']
					),
					$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
				);
				if ($row77=$db->zeile($res77)) {
					if (p4n_mb_string('substr',$row77[0], 0, 7)=='Locator' or intval($row77[1])==20 or intval($row77[1])==21) {
						unset($sqlt_kv[$sql_tabs['produktzuordnung']['stammdaten_id']]);
					}
				}
				$db->update(
					$sql_tab['produktzuordnung'],
					$sqlt_kv,
					$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
				);
			}
		}
		if ($bez_ang_kv==_ANGEBOT2_) {
			$db->update(
					$sql_tab['produktzuordnung'],
					array(
						$sql_tabs['produktzuordnung']['angebot'] => $db->dblogic(false),
						$sql_tabs['produktzuordnung']['angebot_kunde'] => $db->dbzahl(0),
						$sql_tabs['produktzuordnung']['angebot2'] => $db->dblogic(true),
						$sql_tabs['produktzuordnung']['angebot2_kunde'] => $db->dbzahl($_SESSION['stammdaten_id'])
					),
					$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
			);
		}
		// alphaonline
		if (isset($cfg_alphacontroller_url) and $fgnr!='' and $bez_ang_kv==_KAUFVERTRAG_) {
			include_once('inc/alphac.php');
			// rausgenommen am 10.02.2023
			//alphac_sellfahrzeug($fgnr, $summe);
		}
		if (1==2 and isset($cfg_alphacontroller_url) and $bez_ang_kv==_KAUFVERTRAG_) {
			include_once('inc/xml_io.php');
			//$url='http://alpha.alphacontroller.de/soap/server.php?name=alphacontroller';
			//$url2='http://alpha.alphacontroller.de/soap/server.php?name=authentication';
			//$cfg_alphacontroller_user='ccrm';
			//$cfg_alphacontroller_password='Hm42TFa4B';
    //        $alpha_url = 'http://alpha.alphacontroller.de/';
    //		$url='http://alpha.alphacontroller.de/soap/server.php?name=alphacontroller';
    //		$url2='http://alpha.alphacontroller.de/soap/server.php?name=authentication';

            $alpha_url = $cfg_alphacontroller_url;
            $url=$alpha_url.'soap/server.php?name=alphacontroller';
            $url2=$alpha_url.'soap/server.php?name=authentication';
            $soapaction=$alpha_url.'/services/alphacontroller/';
            $soapaction2=$alpha_url.'/services/Authentication/';
			$pref_le='acaut:';
			$utf8=true;
			//$soapaction='http://www.alphacontroller.de/services/alphacontroller/';
			//$soapaction2='http://www.alphacontroller.de/services/Authentication/';
			$erg=soapcall2($url2, $pref_le.'doLogin', array($pref_le.'loginCredentials' => array($pref_le.'login' => $cfg_alphacontroller_user, $pref_le.'password' => $cfg_alphacontroller_password)), '', '', false, false, $soapaction2.'doLogin', $utf8);
			if (isset($erg['errorMessage'])) {
				if ($erg['errorMessage']!='') {
					echo javas('alert("alphacontroller: '.$erg['errorMessage'].'");');
				}
			}
			if (isset($erg['sessionId'])) {
				if ($erg['sessionId']!='') {
					$s_id=$erg['sessionId'];
					$u_id=$erg['userId'];
					$pref_le='acalp:';
					$erg=soapcall2($url, $pref_le.'setVehicleEvent', array(
						$pref_le.'authentication' => array($pref_le.'userId' => $u_id, $pref_le.'sessionId' => $s_id),
						$pref_le.'vehicleIdentificationType' => 'vin',
						$pref_le.'vehicleEventData' => array(
							$pref_le.'vehicleIdentification' => $fgnr,
							$pref_le.'vehicleEvent' => 'sold'
						)
					), '', '', false, false, $soapaction.'setVehicleEvent', $utf8);
					$erg2=soapcall2($url, $pref_le.'setVehicleData', array(
						$pref_le.'authentication' => array($pref_le.'userId' => $u_id, $pref_le.'sessionId' => $s_id),
						$pref_le.'vehicleIdentificationType' => 'vin',
						$pref_le.'vehicleContainer' => array(
							$pref_le.'vehicleIdentification' => $fgnr,
							$pref_le.'vehicleData' => array(
								$pref_le.'category' => 'vehicleStock',
								$pref_le.'field' => 'salesPrice',
								$pref_le.'value' => $summe
							)
						)
					), '', '', false, false, $soapaction.'setVehicleData', $utf8);
					if (isset($erg['success']) and isset($erg2['success'])) {
						if ($erg['success']=='1' and $erg2['success']=='1') {
							echo javas('alert("alphacontroller: OK");');
						} else {
							echo javas('alert("alphacontroller: '.str_replace("\n", ' ', print_r($erg, true)).' / '.str_replace("\n", ' ', print_r($erg2, true)).'");');
						}
					} else {
						echo javas('alert("alphacontroller: '.str_replace("\n", ' ', print_r($erg, true)).' / '.str_replace("\n", ' ', print_r($erg2, true)).'");');
					}
				}
			}
		}
//die();
		if ($cfg_kfzsuche_avagfullservice) {
			if ($postfeld['fulls_allvalues']!='') {
				include_once('inc/fulls.php');
				
				$d_avag_bnr='044';
				$neueavd=substr($_SERVER["HTTP_HOST"], 0, 3);
				if (is_numeric($neueavd)) {
					$d_avag_bnr=$neueavd;
				}
				$res4=$db->select(
					$sql_tab['einstellungen'],
					$sql_tabs['einstellungen']['wert'],
					$sql_tabs['einstellungen']['modul'].'='.$db->str('fullservice_letzteid')
				);
				if ($row4=$db->zeile($res4)) {
		        	$letzte_fs_nr=intval($row4[0])+1;
			    } else {
					$letzte_fs_nr=intval($d_avag_bnr)*100000;
					$db->insert(
						$sql_tab['einstellungen'],
						array(
							$sql_tabs['einstellungen']['modul'] => $db->str('fullservice_letzteid'),
							$sql_tabs['einstellungen']['wert'] => $db->str($letzte_fs_nr)
						)
					);
				}
				$db->update(
					$sql_tab['einstellungen'],
					array(
						$sql_tabs['einstellungen']['wert'] => $db->str($letzte_fs_nr)
					),
					$sql_tabs['einstellungen']['modul'].'='.$db->str('fullservice_letzteid')
				);
				
				$rtf=fulls_dok();
				$rtf=sb_ersetzen('<<fullservice_id>>', $letzte_fs_nr, $rtf);
				if ($rtf=='') {
					
				} else {
					$doclink_zus9='fullservice_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'.rtf';
					$doclink_zus9=dok_korr_sp($doclink_zus9, 'fullservice');
					$doclink9='dokumente_korrespondenz/'.$doclink_zus9;
					$doclink9_m='dokumente_korrespondenz/'.$doclink_zus9;
					
					if ($fp=fopen($doclink9, 'w')) {
						fwrite($fp, $rtf);
						fclose($fp);
					}
					if ($cfg_rtf2pdf) {
						$doclink9=check_rtf2pdf($doclink9, $cfg_rtf2pdf_sleep);
						if ($doclink9!=$doclink9_m) {
							$doclink9=str_replace('.rtf', '.pdf', $doclink9);
							$doclink_zus9=str_replace('.rtf', '.pdf', $doclink_zus9);
							$alle_pdfs[27]=$doclink9;
						}
					}
					
					$weitere_kv[]=$doclink9;
					echo javas('window.open("'.$doclink9.'", "_blank");');
				}
				
				if (preg_match('/fulls_rahmenabk=1/', $postfeld['fulls_allvalues'])) {
					$rtf2=fulls_dok2();
					$rtf2=sb_ersetzen('<<fullservice_id>>', $letzte_fs_nr, $rtf2);
					if ($rtf2=='') {
						
					} else {
						$doclink_zus92='fullservice2_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'.rtf';
						$doclink_zus92=dok_korr_sp($doclink_zus92, 'fullservice');
						$doclink92='dokumente_korrespondenz/'.$doclink_zus92;
						$doclink92_m='dokumente_korrespondenz/'.$doclink_zus92;
						
						if ($fp=fopen($doclink92, 'w')) {
							fwrite($fp, $rtf2);
							fclose($fp);
						}
						if ($cfg_rtf2pdf) {
							$doclink92=check_rtf2pdf($doclink92, $cfg_rtf2pdf_sleep);
							if ($doclink92!=$doclink92_m) {
								$doclink92=str_replace('.rtf', '.pdf', $doclink92);
								$doclink_zus92=str_replace('.rtf', '.pdf', $doclink_zus92);
								$alle_pdfs[28]=$doclink92;
							}
						}
						
						$weitere_kv[]=$doclink92;
						echo javas('window.open("'.$doclink92.'", "_blank");');
					}
				}
				
				
				$beschr_text=fulls_text($postfeld['fulls_allvalues']);
				
				$summe_fs1=0;
				$xplfs1=explode('&', $postfeld['fulls_allvalues']);
				while (list($key, $val)=@each($xplfs1)) {
					$xplfs2=explode('=', $val);
					if ($xplfs2[0]=='summe') {
						$summe_fs1=doubleval(str_replace(',', '.', $xplfs2[1]));
					}
				}
				$par_id_fs=$par_id;
				if (intval($ins_k_id)>0) {
					$par_id_fs=$ins_k_id;
				}
				
				$kfeld9=array(
								$sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['wvl_datum1'] => 0,
								$sql_tabs['korrespondenz']['wvl_datum2'] => 0,
								$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
								$sql_tabs['korrespondenz']['ansprechpartner_id'] => $db->dbzahl($apid),
								$sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
								$sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['eingang'] => 0,
								$sql_tabs['korrespondenz']['art'] => $db->dbzahl(11),
								$sql_tabs['korrespondenz']['kategorie'] => $db->str('Fullservice'),
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
								$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($par_id_fs),
								$sql_tabs['korrespondenz']['doclink'] => $db->str(str_replace('dokumente_korrespondenz/', '', $doclink9)),
								$sql_tabs['korrespondenz']['betreff'] => $db->str('Fullservice'.($bez_ang_kv==_KAUFVERTRAG_?' '._VERTRAG_:'')),
								$sql_tabs['korrespondenz']['beschreibung'] => $db->str($beschr_text),
								$sql_tabs['korrespondenz']['zusatz1'] => $db->str($ltext2),
								$sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl($postfeld['pid']),
								$sql_tabs['korrespondenz']['papierkorb'] => 0,
								$sql_tabs['korrespondenz']['kalender_id'] => 0,
								$sql_tabs['korrespondenz']['prioritaet'] => 0,
								$sql_tabs['korrespondenz']['negativ'] => 0,
								$sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_nr'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['quelle'] => $db->str($lead_quelle),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str('Fullservice'.($bez_ang_kv==_KAUFVERTRAG_?' '._VERTRAG_:'')),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str('Fullservice'.($bez_ang_kv==_KAUFVERTRAG_?' '._VERTRAG_:'')),
								$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['opportunity_id'] => $db->dbzahl($anr),
								$sql_tabs['korrespondenz']['zusatz_zahl'] => $db->dbzahl($summe_fs1),
								$sql_tabs['korrespondenz']['kategorie2'] => $db->str($letzte_fs_nr)
				);
				$kupdid9=0;
				$res8=$db->select(
					$sql_tab['korrespondenz'],
					$sql_tabs['korrespondenz']['korrespondenz_id'],
					$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($anr).' and '.$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('Fullservice')
				);
				if ($row8=$db->zeile($res8)) {
					$kupdid9=$row8[0];
				}
				if ($kupdid9>0) {
					$db->update(
						$sql_tab['korrespondenz'],
						$kfeld9,
						$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($kupdid9)
					);
				} else {
					$db->insert(
						$sql_tab['korrespondenz'],
						$kfeld9
					);
					$kupdid9=$db->insertid();
				}
				$res82=$db->select(
					$sql_tab['korrespondenz_doks'],
					$sql_tabs['korrespondenz_doks']['korrespondenz_doks_id'],
					$sql_tabs['korrespondenz_doks']['korrespondenz_id'].'='.$db->dbzahl($kupdid9).' and '.$sql_tabs['korrespondenz_doks']['bezeichnung'].'='.$db->str('Fullservice')
				);
				if ($row82=$db->zeile($res82)) {
					$db->update(
						$sql_tab['korrespondenz_doks'],
							array(
							$sql_tabs['korrespondenz_doks']['korrespondenz_id'] => $db->dbzahl($kupdid9),
							$sql_tabs['korrespondenz_doks']['bezeichnung'] => $db->str('Fullservice'),
							$sql_tabs['korrespondenz_doks']['datei'] => $db->str(str_replace('dokumente_korrespondenz/', '', $doclink92))
						),
						$sql_tabs['korrespondenz_doks']['korrespondenz_doks_id'].'='.$db->dbzahl($row82[0])
					);
				} else {
					$db->insert(
						$sql_tab['korrespondenz_doks'],
							array(
							$sql_tabs['korrespondenz_doks']['korrespondenz_id'] => $db->dbzahl($kupdid9),
							$sql_tabs['korrespondenz_doks']['bezeichnung'] => $db->str('Fullservice'),
							$sql_tabs['korrespondenz_doks']['datei'] => $db->str(str_replace('dokumente_korrespondenz/', '', $doclink92))
						)
					);
				}
			}
		}
		if ($cfg_kfzsuche_avagautoabo) {
			if ($postfeld['autoabo_allvalues']!='') {
				include_once('inc/fulls.php');
				
				$d_avag_bnr='044';
				$neueavd=substr($_SERVER["HTTP_HOST"], 0, 3);
				if (is_numeric($neueavd)) {
					$d_avag_bnr=$neueavd;
				}
				$res4=$db->select(
					$sql_tab['einstellungen'],
					$sql_tabs['einstellungen']['wert'],
					$sql_tabs['einstellungen']['modul'].'='.$db->str('autoabo_letzteid')
				);
				if ($row4=$db->zeile($res4)) {
		        	$letzte_fs_nr=intval($row4[0])+1;
			    } else {
					$letzte_fs_nr=intval($d_avag_bnr)*100000;
					$db->insert(
						$sql_tab['einstellungen'],
						array(
							$sql_tabs['einstellungen']['modul'] => $db->str('autoabo_letzteid'),
							$sql_tabs['einstellungen']['wert'] => $db->str($letzte_fs_nr)
						)
					);
				}
				$db->update(
					$sql_tab['einstellungen'],
					array(
						$sql_tabs['einstellungen']['wert'] => $db->str($letzte_fs_nr)
					),
					$sql_tabs['einstellungen']['modul'].'='.$db->str('autoabo_letzteid')
				);
				
				$rtf=autoabo_dok();
				$rtf=sb_ersetzen('<<autoabo_id>>', $letzte_fs_nr, $rtf);
				if ($rtf=='') {
					
				} else {
					$doclink_zus99='autoabo_'.$_SESSION['stammdaten_id'].'_'.adodb_date('Ymd_His').'_'.$_SESSION['user_id'].'.rtf';
					$doclink_zus99=dok_korr_sp($doclink_zus99, 'autoabo');
					$doclink99='dokumente_korrespondenz/'.$doclink_zus99;
					$doclink99_m='dokumente_korrespondenz/'.$doclink_zus99;
					
					if ($fp=fopen($doclink99, 'w')) {
						fwrite($fp, $rtf);
						fclose($fp);
					}
					if ($cfg_rtf2pdf) {
						$doclink99=check_rtf2pdf($doclink99, $cfg_rtf2pdf_sleep);
						if ($doclink99!=$doclink99_m) {
							$doclink99=str_replace('.rtf', '.pdf', $doclink99);
							$doclink_zus99=str_replace('.rtf', '.pdf', $doclink_zus99);
							$alle_pdfs[29]=$doclink99;
						}
					}
					
					$weitere_kv[]=$doclink99;
					echo javas('window.open("'.$doclink99.'", "_blank");');
				}
				
				$beschr_text=autoabo_text($postfeld['autoabo_allvalues']);
				
				$summe_fs1=0;
				$xplfs1=explode('&', $postfeld['autoabo_allvalues']);
				while (list($key, $val)=@each($xplfs1)) {
					$xplfs2=explode('=', $val);
					if ($xplfs2[0]=='autoabo_rate') {
						$summe_fs1=doubleval(str_replace(',', '.', $xplfs2[1]));
					}
				}
				$par_id_fs=$par_id;
				if (intval($ins_k_id)>0) {
					$par_id_fs=$ins_k_id;
				}
				
				$kfeld9=array(
								$sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['wvl_datum1'] => 0,
								$sql_tabs['korrespondenz']['wvl_datum2'] => 0,
								$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
								$sql_tabs['korrespondenz']['ansprechpartner_id'] => $db->dbzahl($apid),
								$sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
								$sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['eingang'] => 0,
								$sql_tabs['korrespondenz']['art'] => $db->dbzahl(11),
								$sql_tabs['korrespondenz']['kategorie'] => $db->str('AUTOabo'),
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
								$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($par_id_fs),
								$sql_tabs['korrespondenz']['doclink'] => $db->str(str_replace('dokumente_korrespondenz/', '', $doclink99)),
								$sql_tabs['korrespondenz']['betreff'] => $db->str('AUTOabo'.($bez_ang_kv==_KAUFVERTRAG_?' '._VERTRAG_:'')),
								$sql_tabs['korrespondenz']['beschreibung'] => $db->str($beschr_text),
								$sql_tabs['korrespondenz']['zusatz1'] => $db->str($ltext2),
								$sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl($postfeld['pid']),
								$sql_tabs['korrespondenz']['papierkorb'] => 0,
								$sql_tabs['korrespondenz']['kalender_id'] => 0,
								$sql_tabs['korrespondenz']['prioritaet'] => 0,
								$sql_tabs['korrespondenz']['negativ'] => 0,
								$sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_nr'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['quelle'] => $db->str($lead_quelle),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str('AUTOabo'.($bez_ang_kv==_KAUFVERTRAG_?' '._VERTRAG_:'')),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str('AUTOabo'.($bez_ang_kv==_KAUFVERTRAG_?' '._VERTRAG_:'')),
								$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['opportunity_id'] => $db->dbzahl($anr),
								$sql_tabs['korrespondenz']['zusatz_zahl'] => $db->dbzahl($summe_fs1),
								$sql_tabs['korrespondenz']['kategorie2'] => $db->str($letzte_fs_nr)
				);
				$kupdid9=0;
				$res8=$db->select(
					$sql_tab['korrespondenz'],
					$sql_tabs['korrespondenz']['korrespondenz_id'],
					$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($anr).' and '.$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('AUTOabo')
				);
				if ($row8=$db->zeile($res8)) {
					$kupdid9=$row8[0];
				}
				if ($kupdid9>0) {
					$db->update(
						$sql_tab['korrespondenz'],
						$kfeld9,
						$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($kupdid9)
					);
				} else {
					$db->insert(
						$sql_tab['korrespondenz'],
						$kfeld9
					);
					$kupdid9=$db->insertid();
				}
			}
		}
		
		if ($bez_ang_kv==_KAUFVERTRAG_ and isset($postfeld['teilebestellung']) and $postfeld['teilebestellung']!='' and $postfeld['teilebestellung_email']!='') {
			$tb_liefert='';
			if ($cfg_kfzsuche_liefertermin_beides) {
				if (isset($postfeld['clieft1'])) {
					$tb_liefert=($cfg_kfzsuche_norway?'':_KW_.' ').$postfeld['vertrag_liefertermin1'].'/'.$postfeld['vertrag_liefertermin2'];
				} elseif (isset($postfeld['clieft2'])) {
					$tb_liefert=$postfeld['vertrag_liefertermin'];
				}
			} elseif ($cfg_kfzsuche_liefertermin_datum) {
				$tb_liefert=$postfeld['vertrag_liefertermin'];
			}
			include_once("mailconf.php");
							$abse='CRM Teilebestellung';
							if ($_SESSION['user_email']!='') {
								$abse=$_SESSION['user_email'];
							} elseif ($mcs_pop3_email!='') {
								$abse=$mcs_pop3_email;
							}
							$mail->ClearAllRecipients();
							$mail->ClearAttachments();
							$mail->From     = $abse;
							$mail->FromName = $abse;
							$mail->IsHTML(false);
							$mail->Subject  = 'CRM Teilebestellung '.$anr;
							$mail->AddAddress($postfeld['teilebestellung_email']);
							$mailt='Teilebestellung f�r Kaufvertrag '.$anr.' vom '.adodb_date('d.m.Y', time()).':'."\r\n-----------------------------------\r\n";
							$mailt.="\r\n".$postfeld['teilebestellung']."\r\n";
							$mailt.="\r\n-----------------------------------\r\n";
							$mailt.='Firma: '.$postfeld['firma1']."\r\n";
							$mailt.='Vorname: '.$postfeld['vorname']."\r\n";
							$mailt.='Name: '.$postfeld['name']."\r\n";
							$mailt.='Debitorennummer: '.$kdnr1."\r\n";
							$mailt.="-----------------------------------\r\n";
							$mailt.='Liefertermin (unverbindlich): '.$tb_liefert."\r\n";
							$mailt.="-----------------------------------\r\n";
							$mailt.='Fahrzeugdaten:'."\r\n";
							$mailt.='VIN: '.$postfeld['kfz_fahrgestell']."\r\n";
							$mailt.='Marke: '.$postfeld['kfz_markencode']."\r\n";
							$mailt.='Modell: '.$postfeld['kfz_typmodell'].' ('.$kfzstat1.")\r\n";
							$mailt.='Leistung: '.$postfeld['kfz_ps']."\r\n";
							$mailt.='EZ: '.$postfeld['kfz_datum_ez']."\r\n";
							$mail->Body = $mailt;
							$gesendet=$mail->Send();
							if ($fp2=fopen('inc/'.$_SESSION['cfg_kunde'].'/maillog.txt', 'a')) {
									fwrite($fp2, adodb_date('d.m.Y H:i:s', time()).': Teilebestellung '.$postfeld['teilebestellung_email'].' '.($gesendet?_OK_:_FEHLER_).' / '._BENUTZER_.': '.$_SESSION['mitarbeiter_name2']."\r\n");
									fclose($fp2);
							}
		}
		
		if ($bez_ang_kv==_KAUFVERTRAG_ and isset($postfeld['insurance_email'])) {
			$res4=$db->select(
				$sql_tab['einstellungen'],
				$sql_tabs['einstellungen']['wert'],
				$sql_tabs['einstellungen']['modul'].'='.$db->str('nl_insurance_email')
			);
			$cfg_insurance_emailtext='';
			if ($row4=$db->zeile($res4)) {
				$xpl=explode(';', $row4[0]);
				$cfg_insurance_emailtext=base64_decode($xpl[0]);
			}
			if ($cfg_insurance_emailtext!='') {
				$kfzstat1=_NEUFAHRZEUG_;
				$res5=$db->select(
							$sql_tab['produktzuordnung'],
							array(
								$sql_tabs['produktzuordnung']['fahrzeugstatus']
							),
							$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
				);
				if ($row5=$db->zeile($res5)) {
					$kfzstat1=$row5[0];
				}
				$bauj1=adodb_date('Y');
				if ($postfeld['kfz_datum_ez']!='') {
					$bauj1=p4n_mb_string('substr',$postfeld['kfz_datum_ez'], -4);
				}
				include_once("mailconf.php");
							$abse='CRM';
							if ($_SESSION['user_email']!='') {
								$abse=$_SESSION['user_email'];
							} elseif ($mcs_pop3_email!='') {
								$abse=$mcs_pop3_email;
							}
							$mail->ClearAllRecipients();
							$mail->ClearAttachments();
							$mail->From     = $abse;
							$mail->FromName = $abse;
							$mail->IsHTML(false);
							$mail->Subject  = 'Aanbieding verzekering';
							$mail->AddAddress($cfg_insurance_emailtext);
							$mailt='Aanvraag formulier autoverzekering'."\r\n-----------------------------------\r\n".'Datum: '.adodb_date('d-m-Y', time())."\r\n";
							$mailt.='Vestiging: '.'Automotions'."\r\n";	//kundenbezeichnung($_SESSION['stammdaten_id']).' ('.$_SESSION['stammdaten_id'].')'
							$mailt.='Verkoper: '.$_SESSION['mitarbeiter_name']."\r\n";
							$mailt.="\r\n".'Relatiegegevens'."\r\n-----------------------------------\r\n";
							$mailt.='Bedrijf: '.$postfeld['firma1']."\r\n";
							$mailt.='Geslacht: '.$postfeld['anrede']."\r\n";
							$mailt.='Geboortedatum: '.str_replace('.', '-', $postfeld['geburtsdatum'])."\r\n";
							$mailt.='Voorletters: '.$postfeld['vorname']."\r\n";
							$mailt.='Tussenvoegsels: '.$postfeld['firma2']."\r\n";
							$mailt.='Naam: '.$postfeld['name']."\r\n";
							$mailt.='Adres: '.$postfeld['adresse']."\r\n";
							$mailt.='Postcode: '.$postfeld['plz']."\r\n";
							$mailt.='Plaats: '.$postfeld['ort']."\r\n";
							$mailt.='Telefoonnummer: '.$postfeld['telefon'].(($cfg_kfzsuche_kontakt_pg and $postfeld['telefon2']!='')?' / '.$postfeld['telefon2']:'')."\r\n";
							$mailt.='E-mailadres: '.$postfeld['email'].(($cfg_kfzsuche_kontakt_pg and $postfeld['email2']!='')?' / '.$postfeld['email2']:'')."\r\n";
							$mailt.='Schadevrije jaren: '.$postfeld['insurance_email_jahre']."\r\n";
							$mailt.='Bonus / Malus korting: '.$postfeld['insurance_email_bm']." %\r\n";
							$mailt.="\r\n".'Autogegevens'."\r\n-----------------------------------\r\n".'Kenteken: '.$postfeld['kfz_kennzeichen']."\r\n";
							$mailt.='Merkt type: '.$postfeld['kfz_markencode'].' '.$postfeld['kfz_typmodell'].' ('.$kfzstat1.")\r\n";
							$mailt.='Gewicht: '.$postfeld['gewicht']."\r\n";
							$mailt.='Bouwjaar: '.$bauj1."\r\n";
							$mailt.='Cataloguswaarde: '.number_format(doubleval($m_listenp_hersteller), 2, ",", "")."\r\n";
							$mailt.='Waarde accessoires: '.number_format(doubleval($m_listenp_zub), 2, ",", "")."\r\n";
							$mailt.='Verwachte afleverdatum: '.($postfeld['vertrag_liefertermin']!=''?str_replace('.', '-', $postfeld['vertrag_liefertermin']):$postfeld['vertrag_liefertermin1'].'/'.$postfeld['vertrag_liefertermin2'])."\r\n";
							$mailt.='Opmerkingen: '.$postfeld['vertrags_vereinbarungen']."\r\n";
							$mail->Body = $mailt;
							$erf_insmail=$mail->Send();

							$kfeld=array(
								$sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['wvl_datum1'] => 0,
								$sql_tabs['korrespondenz']['wvl_datum2'] => 0,
								$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
								$sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
								$sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['eingang'] => 0,
								$sql_tabs['korrespondenz']['art'] => $db->dbzahl(7),
								$sql_tabs['korrespondenz']['kategorie'] => $db->str(_VERSICHERUNG_),
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic($erf_insmail),
								$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['doclink'] => $db->str(''),
								$sql_tabs['korrespondenz']['betreff'] => $db->str('Aanbieding verzekering'),
								$sql_tabs['korrespondenz']['beschreibung'] => $db->str($mailt),
								$sql_tabs['korrespondenz']['zusatz1'] => $db->str(''),
								$sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl($postfeld['pid']),
								$sql_tabs['korrespondenz']['papierkorb'] => 0,
								$sql_tabs['korrespondenz']['kalender_id'] => 0,
								$sql_tabs['korrespondenz']['prioritaet'] => 0,
								$sql_tabs['korrespondenz']['negativ'] => 0,
								$sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_nr'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_VERSICHERUNG_),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str(_VERSICHERUNG_),
								$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($ang_kv_user)
							);
				$db->insert(
					$sql_tab['korrespondenz'],
					$kfeld
				);
			}
		}
		
		if ($bez_ang_kv==_KAUFVERTRAG_ and (isset($postfeld['opel_insurance_email_yes']) or isset($postfeld['opel_insurance_email_no']))) {
				include_once("mailconf.php");
				$dealercode='';
				$res4=$db->select(
					$sql_tab['mandant'],
					$sql_tabs['mandant']['parent_id'],
					$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($postfeld['mvertrag_lagerort'])
				);
				if ($row4=$db->zeile($res4)) {
					$res4=$db->select(
						$sql_tab['mandant'],
						$sql_tabs['mandant']['dealercode'],
						$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($row4[0])
					);
					if ($row4=$db->zeile($res4)) {
						$dealercode=$row4[0];
					}
				}
				if ($dealercode=='') {
					$res4=$db->select(
						$sql_tab['mandant'],
						$sql_tabs['mandant']['dealercode'],
						$sql_tabs['mandant']['dealercode'].'!='.$db->str(''),
						$sql_tabs['mandant']['mandant_id']
					);
					if ($row4=$db->zeile($res4)) {
						$dealercode=$row4[0];
					}
				}
							$abse='CRM';
							if ($_SESSION['user_email']!='') {
								$abse=$_SESSION['user_email'];
							} elseif ($mcs_pop3_email!='') {
								$abse=$mcs_pop3_email;
							}
							$mail->ClearAllRecipients();
							$mail->ClearAttachments();
							$mail->From     = $abse;
							$mail->FromName = $abse;
							$mail->IsHTML(false);
							$mail->Subject  = 'Aanbieding verzekering';
							if (isset($cfg_nl_opelinsurance_mail_noto) and isset($postfeld['opel_insurance_email_no'])) {
								$mail->AddAddress($cfg_nl_opelinsurance_mail_noto);
							} else {
								$mail->AddAddress($cfg_nl_opelinsurance_mail_to);
							}
							if ($cfg_nl_opelinsurance_mail_tocustomer and $postfeld['email']!='') {
								$mail->AddAddress($postfeld['email']);
							}
							if ($cfg_kfzsuche_kontakt_pg and $cfg_nl_opelinsurance_mail_tocustomer and $postfeld['email2']!='') {
								$mail->AddAddress($postfeld['email2']);
							}
							$mailt='';
							if (isset($postfeld['opel_insurance_email_yes'])) {
								$mailt=$cfg_nl_opelinsurance_mail_textyes;
							} elseif (isset($postfeld['opel_insurance_email_no'])) {
								$mailt=$cfg_nl_opelinsurance_mail_textno;
							}
							$mailt=str_replace('<<salesman>>', $_SESSION['mitarbeiter_name'], $mailt);
							$mailt=str_replace('<<dealercode>>', $dealercode, $mailt);
							$mailt=str_replace('<<reason>>', $postfeld['opel_insurance_email_text'], $mailt);
							$custname1=trim($postfeld['vorname'].' '.$postfeld['firma2'].' '.$postfeld['name']);
							if ($postfeld['firma1']!='') {
								if ($custname1!='') {
									$custname1.=' / ';
								}
								$custname1=$postfeld['firma1'];
							}
							$mailt=str_replace('<<customer_name>>', $custname1, $mailt);
							$mailt=str_replace('<<customer_address>>', $postfeld['adresse'], $mailt);
							$mailt=str_replace('<<customer_postalcode>>', $postfeld['plz'], $mailt);
							$mailt=str_replace('<<customer_city>>', $postfeld['ort'], $mailt);
							$mailt=str_replace('<<customer_tel>>', $postfeld['telefon'].(($cfg_kfzsuche_kontakt_pg and $postfeld['telefon2']!='')?' / '.$postfeld['telefon2']:''), $mailt);
							$mailt=str_replace('<<customer_email>>', $postfeld['email'].(($cfg_kfzsuche_kontakt_pg and $postfeld['email2']!='')?' / '.$postfeld['email2']:''), $mailt);
							$mailt=str_replace('<<customer_mobile>>', $postfeld['mobilfon'].(($cfg_kfzsuche_kontakt_pg and $postfeld['mobilfon2']!='')?' / '.$postfeld['mobilfon2']:''), $mailt);
							
							$mail->Body = $mailt;
							$erf_insmail=$mail->Send();
							
							$kfeld=array(
								$sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['wvl_datum1'] => 0,
								$sql_tabs['korrespondenz']['wvl_datum2'] => 0,
								$sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
								$sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
								$sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($ang_kv_user),
								$sql_tabs['korrespondenz']['eingang'] => 0,
								$sql_tabs['korrespondenz']['art'] => $db->dbzahl(7),
								$sql_tabs['korrespondenz']['kategorie'] => $db->str(_VERSICHERUNG_),
								$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic($erf_insmail),
								$sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['doclink'] => $db->str(''),
								$sql_tabs['korrespondenz']['betreff'] => $db->str('Aanbieding Opel verzekering'),
								$sql_tabs['korrespondenz']['beschreibung'] => $db->str($mailt),
								$sql_tabs['korrespondenz']['zusatz1'] => $db->str(''),
								$sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl($postfeld['pid']),
								$sql_tabs['korrespondenz']['papierkorb'] => 0,
								$sql_tabs['korrespondenz']['kalender_id'] => 0,
								$sql_tabs['korrespondenz']['prioritaet'] => 0,
								$sql_tabs['korrespondenz']['negativ'] => 0,
								$sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_nr'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['formular_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl(0),
								$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
								$sql_tabs['korrespondenz']['ergebnis_text'] => $db->str('Opel '._VERSICHERUNG_),
								$sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str('Opel '._VERSICHERUNG_),
								$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($ang_kv_user)
							);
				$db->insert(
					$sql_tab['korrespondenz'],
					$kfeld
				);
		}
		
		
		if ($bez_ang_kv==_ANGEBOT_) {
			if ($postfeld['angebot2']=='1') {
				$db->update(
					$sql_tab['produktzuordnung'],
					array(
						$sql_tabs['produktzuordnung']['angebot'] => $db->dblogic(false),
						$sql_tabs['produktzuordnung']['angebot_kunde'] => $db->dbzahl(0),
						$sql_tabs['produktzuordnung']['angebot2'] => $db->dblogic(true),
						$sql_tabs['produktzuordnung']['angebot2_kunde'] => $db->dbzahl($_SESSION['stammdaten_id'])
					),
					$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
				);
			} else {
				if (isset($cfg_kfzsuche_akv_keinewvl) and @in_array($_SESSION['stammdaten_id'], $cfg_kfzsuche_akv_keinewvl)) {
					
				} else {
				$db->update(
					$sql_tab['produktzuordnung'],
					array(
						$sql_tabs['produktzuordnung']['angebot'] => $db->dblogic(true),
						$sql_tabs['produktzuordnung']['angebot_kunde'] => $db->dbzahl($_SESSION['stammdaten_id']),
                        $sql_tabs['produktzuordnung']['datum_aenderung'] => $db->dbtimestamp(time())
					),
					$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($postfeld['pid'])
				);
				}
			}
		}
		
		if ($bez_ang_kv2=='expose' and isset($postfeld['expose_lead'])) {
				$lead_data=new Lead_Data();
				$lead_data->stammdaten_id=$_SESSION['stammdaten_id'];
				$new_files_lead=array();
				$new_files_lead[name2filename(_EXPOSE_.'.rtf')]='dokumente_korrespondenz/'.$doclink;//'dokumente_korrespondenz/expose/2020_08/expose_1000000_20200828_173459_1.rtf';
				$anhaenge_pfad = json_encode(json_encode_utf8($new_files_lead));
				$moidata='#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.$anhaenge_pfad;
				$lead_data->moidata=$moidata;
				$lead_data->additionaldata='#####'._EXPOSE_.' '.$postfeld['kfz_markencode'].' '.$postfeld['kfz_typmodell'].$kfz_typ2.' '.$postfeld['kfz_fahrgestell'];
				$lead_data->source=_EXPOSE_;
				$lead_data->campaignname=_EXPOSE_;
				$lead_data->status='2';
				$lead_data->status2_time=$db->dbtimestamp(time());
				$lead_data->benutzer_id=$_SESSION['user_id'];
				$lead_data->lagerort_id=$postfeld['vertrag_lagerort'];
				$lead_data->korrespondenz_id=$ins_k_id;
				$lead_data->kampagne_id=$kampa_id;
				$ergexplead=$lead_data->save();
				
				$lead_data->load();
			//	echo 'id: '.$lead_data->kampagne_lead_id.'<br><br>';
				
				$db->update(
					$sql_tab['korrespondenz'],
					array(
						$sql_tabs['korrespondenz']['wvl_datum1'] => 0,
						$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true)
					),
					$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($ins_k_id)
				);
				$kfeldwvl=$kfeld;
				$kfeldwvl[$sql_tabs['korrespondenz']['parent_id']]=$db->dbzahl($ins_k_id);
				$kfeldwvl[$sql_tabs['korrespondenz']['wvl_datum1']]=$kfeld[$sql_tabs['korrespondenz']['datum']];
				$kfeldwvl[$sql_tabs['korrespondenz']['erledigt']]=$db->dblogic(false);
				$kfeldwvl[$sql_tabs['korrespondenz']['ergebnis_datum']]=0;
				$kfeldwvl[$sql_tabs['korrespondenz']['ergebnis_text']]=$db->str('');
				$kfeldwvl[$sql_tabs['korrespondenz']['ergebnis_kategorie']]=$db->str('');
				$kfeldwvl[$sql_tabs['korrespondenz']['ergebnis_benutzer_id']]=$db->dbzahl(0);
				$kfeldwvl[$sql_tabs['korrespondenz']['lead_id']]=$db->dbzahl($lead_data->kampagne_lead_id);
				$db->insert(
					$sql_tab['korrespondenz'],
					$kfeldwvl
				);
				$db->update(
					$sql_tab['kampagne_lead'],
					array(
						$sql_tabs['kampagne_lead']['korrespondenz_id'] => $db->dbzahl($db->insertid())
					),
					$sql_tabs['kampagne_lead']['kampagne_lead_id'].'='.$db->dbzahl($lead_data->kampagne_lead_id)
				);
		}
		
		if (isset($postfeld['finanzierung_extern'])) {
			if ($postfeld['finanzierung_extern']=='2') {
				include_once('inc/gmac.php');
				$finbankname='CALMS';
				$cfg_kfz_finanzierung_gmac_posturl=$cfg_kfz_finanzierung_gmac2_posturl;
				oeffne_gmac($anr, true);
			}
			if ($postfeld['finanzierung_extern']=='22') {
				include_once('inc/gmac.php');
				$finbankname='MILES';
				$cfg_kfz_finanzierung_gmac_posturl=$cfg_kfz_finanzierung_gmac3_posturl;
				oeffne_gmac($anr, true);
			}
			if ($postfeld['finanzierung_extern']=='3') {
				include_once('inc/gmac.php');
				oeffne_santander($anr, true);
			}
		}
			if (isset($postfeld['smit_neu'])) {
				include_once('inc/gmac.php');
				$erg=smit_startekonf($_SESSION['stammdaten_id'], $postfeld['pid'], $anr);
				if (isset($erg['url'])) {
					echo javas('window.open("'.$erg['url'].'", "smit");');
				} else {
					echo javas('alert("'.p4n_mb_string('str_replace', array("\r", "\n", '"', "'"), ' ', print_r($erg, true)).'");');
				}
				$db->update(
					$sql_tab['opportunity'],
					array(
						$sql_tabs['opportunity']['zusatz2'] => $db->str('SMIT_C_')
					),
					$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($anr2)
				);
			}
		} // Ende Vorschau

		unset($getfeld['kv']);
		unset($getfeld['skv']);
		unset($getfeld['ang']);
		unset($getfeld['pf']);
		unset($getfeld['expo']);
		unset($getfeld['vvi']);
		unset($getfeld['suchauf']);
		
		if ($cfg_kfzsuche_pdf_join) {
				$lo='';
				@unlink('temp\\akv_alles_'.$_SESSION['user_id'].'.pdf');
				$lo2='gswin64c.exe -dNOPAUSE -sDEVICE=pdfwrite -sOUTPUTFILE=temp\\akv_alles_'.$_SESSION['user_id'].'.pdf -dBATCH ';
				@krsort($alle_pdfs);
				@reset($alle_pdfs);
				while (list($keyd, $vald)=@each($alle_pdfs)) {
					$lo='"'.str_replace('/', '\\', $vald).'" '.$lo;
				}
				exec($lo2.$lo, $cmdoutput);
				if (is_file('exiftool.exe')) {
					exec('exiftool.exe -Title="'.$bez_ang_kv.'" -Author="ABC" -Subject="'.$bez_ang_kv.'" -overwrite_original temp\\akv_alles_'.$_SESSION['user_id'].'.pdf', $cmdoutput2);
				}
				if (is_file('temp/akv_alles_'.$_SESSION['user_id'].'.pdf')) {
				//	echo javas('window.open("'.'temp/akv_alles_'.$_SESSION['user_id'].'.pdf'.'", "_blank");');
					@unlink('dokumente_korrespondenz/'.$doclink);
					copy('temp/akv_alles_'.$_SESSION['user_id'].'.pdf', 'dokumente_korrespondenz/'.$doclink);
					link_dok_oeffnen('dokumente_korrespondenz/'.$doclink);//'temp/akv_alles_'.$_SESSION['user_id'].'.pdf');
					if ($fp=fopen('log_pdf2.txt', 'w')) { fwrite($fp, javas('window.open("'.'temp/akv_alles_'.$_SESSION['user_id'].'.pdf'.'", "_blank");').print_r($alle_pdfs, true).print_r($cmdoutput, true).$lo); fclose($fp); }
				}
		}
		
		if ($cfg_olympia and isset($postfeld['vers_olympia']) and substr($postfeld['vers_olympia'], 0, 2)==_JA_) {
            if ($_SESSION['design_70'] && !$cfg_design70_hybrid) {
            echo javas('wechsel_a("main","stammdaten_main.php?id='.$_SESSION['stammdaten_id'].'&nav=OM&akvid='.$anr.'&olympia_vers='.$anr.'");');
            } else
			echo javas('location.href="stammdaten_main.php?frameset_start=1&id='.$_SESSION['stammdaten_id'].'&nav=OM&akvid='.$anr.'&olympia_vers='.$anr.'";');
			fuss();
			die();
		}
		
		if (isset($sql_tabs['formular']['nach_angebot'])) {
			$fo_aufr=0;
			$res2=$db->select(
				$sql_tab['formular'],
				array(
					$sql_tabs['formular']['formular_id'],
					$sql_tabs['formular']['nach_angebot'],
					$sql_tabs['formular']['nach_kaufvertrag'],
					$sql_tabs['formular']['nach_probefahrt'],
				)
			);
			while ($row2=$db->zeile($res2)) {
				if (intval($row2[1])>0 and $bez_ang_kv==_ANGEBOT_) {
					$fo_aufr=$row2[0];
				} elseif (intval($row2[2])>0 and $bez_ang_kv==_KAUFVERTRAG_) {
					$fo_aufr=$row2[0];
				} elseif (intval($row2[3])>0 and $bez_ang_kv==_PROBEFAHRT_) {
					$fo_aufr=$row2[0];
				}
			}
			if (intval($fo_aufr)>0) {
				unset($_SESSION['crm_kv_letzte_pid']);
				if (intval($postfeld['pid'])>0) {
					$_SESSION['crm_kv_letzte_pid']=$postfeld['pid'];
				}
                if ($_SESSION['design_70'] && !$cfg_design70_hybrid) {
                echo javas('wechsel_a("main","stammdaten_main.php?id='.$_SESSION['stammdaten_id'].'&nav=Uebersicht&fo_aufruf='.$fo_aufr.'");');
                } else
				echo javas('location.href="stammdaten_main.php?frameset_start=1&id='.$_SESSION['stammdaten_id'].'&nav=Uebersicht&fo_aufruf='.$fo_aufr.'";');
				die();
			}
		}
		
		if ($cfg_kfzsuche_kv_ziel) {
			if ($cfg_kfzsuche_kv_ziel!='') {
				if ($bez_ang_kv==_KAUFVERTRAG_) {
					unset($_SESSION['crm_kv_letzte_pid']);
					if (intval($postfeld['pid'])>0) {
						$_SESSION['crm_kv_letzte_pid']=$postfeld['pid'];
					}
                    if ($_SESSION['design_70'] && !$cfg_design70_hybrid) {
                    echo javas('wechsel_a("main","'.$cfg_kfzsuche_kv_ziel.'");');
                    } else
					echo javas('location.href="'.$cfg_kfzsuche_kv_ziel.'"');
					die();
				}
			}
		}
		//if ($getfeld['zi']=='konf') {
//		if (isset($postfeld['konf_markencode'])) {
			if (isset($postfeld['dse_druck'])) {
                if ($_SESSION['design_70'] && !$cfg_design70_hybrid) {
                echo javas('wechsel_a("main","stammdaten_main.php?nav=Uebersicht&id='.$_SESSION['stammdaten_id'].'&exclude_stammdaten_tabs=1&dse1=1#dse");');
                } else {
				//	echo javas('location.href="stammdaten_main.php?frameset_start=1&id='.$_SESSION['stammdaten_id'].'&nav=Stammdaten&dse1=1#dse"');
	                echo javas('window.open("location.href="stammdaten_main.php?frameset_start=1&id='.$_SESSION['stammdaten_id'].'&nav=Stammdaten&dse1=1#dse", "main");');
				}
			} else {
                if ($_SESSION['design_70'] && !$cfg_design70_hybrid) {
                echo javas('wechsel_a("main","stammdaten_main.php?id='.$_SESSION['stammdaten_id'].'&nav=Uebersicht");');
                } else {
					//echo javas('location.href="stammdaten_main.php?frameset_start=1&id='.$_SESSION['stammdaten_id'].'&nav=Uebersicht"');
					//echo javas('location.href="stammdaten_main.php?id='.$_SESSION['stammdaten_id'].'&nav=Uebersicht"');
    	            echo javas('window.open("stammdaten_main.php?frameset_start=1&id='.$_SESSION['stammdaten_id'].'&nav=Uebersicht", "main");');
				}
			}
			die();
//		}
	}


?>