<?php

trait Lead_Trait_Lib {
    private static $categories = NULL;
    private static $constantMakes = array(
        //'Opel Lead' => 'Opel'
    );
    private static $userRoles = NULL;
    private static $openingTimes = NULL;
    private static $allOptions = array();
    protected static $campaignsPur = array();
    protected static $categoriesPur = array();

    /**
     * @param $source
     *
     * @return mixed
     */
    public static function instance($source) {
        if (!isset(self::$instance[$source])) {
            self::$instance[$source] = new self($source);
        }

        return self::$instance[$source];
    }

    /**
     * get config - return settings array for each source - $config[$source]
     *
     * @param string $source
     *
     * @return array
     */
    public static function getConfig($source = '') {
        global $db, $sql_tab, $sql_tabs;
        $like = $db->str('% '.static::$sub_name);
        if (!empty($source)) {
            $like = $db->str($source.' '.static::$sub_name);
        }
        $config = array();
        $res    = $db->select(
            $sql_tab['einstellungen'],
            array(
                $sql_tabs['einstellungen']['modul'],
                $sql_tabs['einstellungen']['wert']
            ),
            $sql_tabs['einstellungen']['modul'].' LIKE '.$like,
            ''
        );
        while ($row = $db->zeile($res)) {
            $key          = str_replace(' '.static::$sub_name, '', $row['modul']);
            $data         = json_decode_utf8(json_decode($row['wert'], true));
            $config[$key] = $data;
        }
// realised in Lead_Notification:getCfg()
//        if ($source!='') {
//            return $config[$source];
//        }
        return $config;
    }

    /**
     * @return int|mixed
     */
    public static function getConfigMailbeileadeingang() {
        global $db, $sql_tab, $sql_tabs, $mcs_pop3_email;
        $senderEmail          = $mcs_pop3_email;
        $result_einstellungen = $db->select(
            $sql_tab['einstellungen'],
            $sql_tabs['einstellungen']['wert'],
            $sql_tabs['einstellungen']['modul'].'='.$db->str('mailbeileadeingang')
        );
        if ($row_einstellungen = $db->zeile($result_einstellungen)) {
            if (is_numeric($row_einstellungen[0])) {
                if (intval($row_einstellungen[0]) > 0) {
                    $senderEmail = intval($row_einstellungen[0]);
                }
            } else {
                if ($row_einstellungen[0] != '') {
                    $email_einstellungen_explode = explode('#####', $row_einstellungen[0]);
                    $senderEmail=$email_einstellungen_explode[0];
                    if (trim($email_einstellungen_explode[1])!='') {
                        //$senderName=$email_einstellungen_explode[1];
                    }
                }
            }
        }

        return $senderEmail;
    }

    /**
     * get config mailbeileadzuordnung - return settings array
     *
     * @return array | false
     */
    public static function getConfigMailbeileadzuordnung() {
        global $db, $sql_tab, $sql_tabs;
        $res = $db->select(
            $sql_tab['einstellungen'],
            $sql_tabs['einstellungen']['wert'],
            $sql_tabs['einstellungen']['modul'].'='.$db->str('mailbeileadzuordnung')
        );
        if ($row = $db->zeile($res)) {
            return explode(';', $row[0]);
        }

        return false;
    }

    public static function saveConfigMailbeileadzuordnung($data) {
        global $db, $sql_tab, $sql_tabs;
        $result = $db->select(
            $sql_tab['einstellungen'],
            $sql_tabs['einstellungen']['wert'],
            $sql_tabs['einstellungen']['modul'].'='.$db->str('mailbeileadzuordnung')
        );
        if ($row = $db->zeile($result)) {
            $db->update(
                $sql_tab['einstellungen'],
                array(
                    $sql_tabs['einstellungen']['wert'] => $db->str($data)
                ),
                $sql_tabs['einstellungen']['modul'].'='.$db->str('mailbeileadzuordnung')
            );
        } else {
            $db->insert(
                $sql_tab['einstellungen'],
                array(
                    $sql_tabs['einstellungen']['wert']  => $db->str($data),
                    $sql_tabs['einstellungen']['modul'] => $db->str('mailbeileadzuordnung')
                )
            );
        }
    }

    public static function getAllowedLeadSources() {
        global $cfg_ford_lds, $cfg_facebook_leads, $cfg_autouncle, $cfg_ferrari_leads, $cfg_leadengine_version_slmi6, $cfg_leadengine_version_slmi5, $cfg_messengerpeople, $cfg_messengerpeople_v2;
        global $cfg_clever_lead, $cfg_kia_leads, $cfg_toyota_leads, $cfg_toyota_leads_at, $cfg_bmw_rsp, $cfg_alles_auto, $cfg_stellantis, $cfg_seat_leads;
        // Leadeingang
        $leadSources = array('Fahrzeugboersen', 'Makros', 'BDC');
        // Herstellerleads
        if (!empty($cfg_leadengine_version_slmi6) || !empty($cfg_leadengine_version_slmi5)) {
            $leadSources[] = 'Opel Lead';
            $leadSources[] = 'OFDB';
        }
        if (!empty($cfg_ford_lds)) {
            $leadSources[] = 'Ford LDS';
        }
        if (!empty($cfg_toyota_leads)) {
            $leadSources[] = ToyotaLeads_Lead::SOURCE;
        }
        if (!empty($cfg_facebook_leads)) {
            $leadSources[] = Facebook_Lead::SOURCE;
        }
        if (!empty($cfg_autouncle)) {
            $leadSources[] = AutoUncle_Lead::SOURCE;
        }
        if (!empty($cfg_ferrari_leads)) {
            $leadSources[] = Ferrari::SOURCE;
        }
        if (!empty($cfg_messengerpeople)) {
            if (!empty($cfg_messengerpeople_v2)) {
                $leadSources[] = MessengerPeopleV2_Lead::SOURCE;
            } else {
                $leadSources[] = MessengerPeople_Lead::SOURCE;
            }
        }
        if (!empty($cfg_clever_lead)) {
            $leadSources[] = CleverLead_Lead::SOURCE;
        }
        if (!empty($cfg_kia_leads)) {
            $leadSources[] = KiaLeads_Lead::SOURCE;
        }
        if (!empty($cfg_toyota_leads_at)) {
            $leadSources[] = ToyotaLeadsAT_Lead::SOURCE;
        }
        if (!empty($cfg_bmw_rsp)) {
            $leadSources[] = BmwRSP_Lead::SOURCE;
        }
        if (!empty($cfg_alles_auto)) {
            $leadSources[] = AllesAuto_Lead::SOURCE;
        }
        if (!empty($cfg_stellantis)) {
            $leadSources[] = Stellantis_Lead::SOURCE;
        }
        if (!empty($cfg_seat_leads)) {
            $leadSources[] = SeatLeads_Lead::SOURCE;
        }
        sort($leadSources);
        return $leadSources;
    }

    public static function getBenutzerTypes() {
        return array(
            'users'      => _PRO_BENUTZER_,
            'group'      => _BENUTZERGRUPPE_,
            'role'       => _BENUTZERROLLE_.' ('._LEADS_.' '._LAGERORTE_.')' //group_lead
        );
    }

    public static function getBenutzerGruppe() {
        global $db, $sql_tab, $sql_tabs;
        $userGroups = array();
        $res        = $db->select(
            $sql_tab['benutzer_gruppe'],
            array(
                $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
                $sql_tabs['benutzer_gruppe']['bezeichnung']
            ),
            '',
            $sql_tabs['benutzer_gruppe']['bezeichnung']
        );
        while ($row = $db->zeile($res)) {
            $userGroups[$row[0]] = $row[1];
        }

        return $userGroups;
    }

    /**
     * get locations
     *
     * @return array
     */
    public static function getLocationValues() {
        return Location_Helper::instance()->getListWithClients();
        /*if (empty(self::$locations)) {
            self::$locations = array();
            $res             = $db->select(
                $sql_tab['mandant'],
                array(
                    $sql_tabs['mandant']['mandant_id'],
                    $sql_tabs['mandant']['bezeichnung'],
                    $sql_tabs['mandant']['parent_id']
                ),
                '', // all & main mandants too  $sql_tabs['mandant']['parent_id'].'>'.$db->dbzahl(0),
                $sql_tabs['mandant']['bezeichnung']
            );
//          echo $db->last_sql;
            while ($row = $db->zeile($res)) {
                if (!empty($row[1])) {
                    self::$locations[$row[0]] = $row[1];
                }
            }
        }

        return self::$locations;*/
    }

    public static function getUserRoles() {
        global $db, $sql_tab, $sql_tabs;
        if (self::$userRoles === NULL) {
            self::$userRoles = array();
            $res = $db->select(
                $sql_tab['benutzer_rolle'],
                array(
                    $sql_tabs['benutzer_rolle']['benutzer_rolle_id'],
                    $sql_tabs['benutzer_rolle']['bezeichnung']
                ),
                '',
                $sql_tabs['benutzer_rolle']['bezeichnung']
            );
            while ($row=$db->zeile($res)) {
                self::$userRoles[$row[0]] = $row[1];
            }
        }
        return self::$userRoles;
    }

    /** get all campaign
     * @return array
     */
    public static function getCampaignValues() {
        global $db, $sql_tab, $sql_tabs;
        if (empty(self::$campaigns)) {
            self::$campaigns = self::$campaignsPur = array();
            $res = $db->select(
                $sql_tab['kampagne'],
                array(
                    $sql_tabs['kampagne']['kampagne_id'],
                    $sql_tabs['kampagne']['bezeichnung']
                ),
                '',
                $sql_tabs['kampagne']['bezeichnung']
            );
            while ($row = $db->zeile($res)) {
                $value = self::prepareValue($row[1]);
                if (!empty($value)) {
                    self::$campaigns[$row[0]] = $value;
                    self::$campaignsPur[$row[0]] = $row[1];
                }
            }
        }

        return array(self::$campaigns, self::$campaignsPur);
    }

    /**
     * get source options (option key / name /option values & other )
     *
     * @param $source
     *
     * @return mixed
     */
    public static function getOptions($source) {
        global $cfg_lead_absatzgruppe;
        if (empty(self::$options[$source])) {
            list ($types, $typesPur) = self::getOptionValues($source, 'type');
            list ($channels, $channelsPur) = self::getOptionValues($source, 'channel');
            list ($campaigns, $campaignsPur) = self::getCampaignValues();
            self::$options[$source] = array(
                // kampagne_lead.source  Quelle
                'source' => self::getSources($source),
                // kampagne_lead.kfzmarke  Marke
                'kfzmarke'    => self::getMakes($source),
                // kampagne_lead.type  Sparte
                'type'        => array(
                    'name'       => _SPARTE_,
                    'form-type'  => 'selectinput',
                    'values'     => $types,
                    'values-pur' => $typesPur,
                ),
                // kampagne_lead.channel  Kanal
                'channel'     => array(
                    'name'       => _KANAL_,
                    'form-type'  => 'selectinput',
                    'values'     => $channels,
                    'values-pur' => $channelsPur
                ),
                // kampagne_lead.lagerort_id
                'lagerort_id' => array(
                    'name'      => _LAGERORT_,
                    'form-type' => 'selectinput',
                    'values'    => self::getLocationValues()
                ),
                'kampagne_id' => array(
                    'name'       => _KAMPAGNE_,
                    'form-type'  => 'selectinput',
                    'values'     => $campaigns,
                    'values-pur' => $campaignsPur
                ),
                // + some 'form-type' => 'text input',
            );
            /*if ($source === 'Fahrzeugb�rsen') {
                self::$options[$source]['extra_source'] = array(
                    'name'      => 'Interne Quelle',
                    'form-type' => 'selectinput',
                    'values'    => self::getEmailLeadsSources()
                );
            }*/
            if ($cfg_lead_absatzgruppe || $_SESSION['crm_version_float']>=61300) {
                list ($absatzgruppen, $absatzgruppenPur) = self::getOptionValues($source, 'absatzgruppe');
                self::$options[$source]['absatzgruppe'] = array(
                    'name'       => _ABSATZGRUPPE_,
                    'form-type'  => 'selectinput',
                    'values'     => $absatzgruppen,
                    'values-pur' => $absatzgruppenPur
                );
            }
        }

        return self::$options;
    }

    /**
     * @param $source
     *
     * @return array
     */
    public static function getSources($source) {
        global $retailerLeads;
        if (!is_array($retailerLeads)) {
            $retailerLeads = array();
        }
        $out = array('name' => _QUELLE_);
        if (is_array($retailerLeads) && in_array($source, $retailerLeads)) {
            $out['form-type'] = 'hidden';
            $out['values']    = $source;
        } else {
            list($values, $valuesPur) = self::getSourcesValues();
            foreach ($values as $key => $value) {
                if (in_array($value, $retailerLeads)) {
                    unset($values[$key]);
                    unset($valuesPur[$key]);
                }
            }
            $values[_KATEGORIEN_] = 'OPTGROUP';
            $valuesPur[_KATEGORIEN_] = 'OPTGROUP';
            foreach (self::getCategories('source') as $category) {
                list($category, $categoryPur) = $category;
                if ($category && !isset($values[$category]) && !in_array($category, $retailerLeads)) {
                    $values[$category] = $category;
                    $valuesPur[$categoryPur] = $categoryPur;
                }
            }
            $out['form-type']  = 'selectinput';
            $out['values']     = $values;
            $out['values-pur'] = $valuesPur;
        }
        return $out;
    }

    /**
     * get array of sources from kampagne_lead
     *
     * @return array
     */
    public static function getSourcesValues() {
        global $db, $sql_tab, $sql_tabs, $retailerLeads;
        $out = $outPur = array();
        foreach ($retailerLeads as $source) {
            $out[$source] = $source;
            $outPur[$source] = $source;
        }
        $res = $db->select(
            $sql_tab['kampagne_lead'],
            array(
                'distinct '.$sql_tabs['kampagne_lead']['source'],
            ),
            '',
            $sql_tabs['kampagne_lead']['source'].' ASC'

        );
        while ($row = $db->zeile($res)) {
            $value = self::prepareValue($row[0]);
            if (!empty($value)) {
                $out[$value] = $value;
                $outPur[$row[0]] = $row[0];
            }
        }
        ksort($out);
        ksort($outPur);
        return array($out, $outPur);
    }

    /**
     * get array of Email Leads Sources
     *
     * @return array
     */
    public static function getEmailLeadsSources() {
        global $db, $sql_tab, $sql_tabs;
        $list = array();
        $res  = $db->select(
            $sql_tab['kampagne_lead_source'],
            $sql_tabs['kampagne_lead_source']['source'],
            $sql_tabs['kampagne_lead_source']['type'].'='.$db->str('Mail Lead')
        );
        while ($row = $db->zeile($res)) {
            $list[$row[0]] = $row[0];
        }

        return $list;
    }

    /**
     * get option values by source
     *
     * @param $source
     * @param $option
     *
     * @return array
     */
    public static function getOptionValues($source, $option) {
        global $db, $sql_tab, $sql_tabs;
        $out = $outPur = array($source => 'OPTGROUP');
        $res = $db->select(
            $sql_tab['kampagne_lead'],
            array(
                'distinct '.$sql_tabs['kampagne_lead'][$option],
            ),
            $sql_tabs['kampagne_lead']['source'].'='.$db->dbstr($source),
            $sql_tabs['kampagne_lead'][$option].' ASC'
        );
        while ($row = $db->zeile($res)) {
            $value = self::prepareValue($row[0]);
            if (!empty($value)) {
                $out[$value] = $value;
                $outPur[$row[0]] = $row[0];
            }
        }

        $out[_ALLE_] = 'OPTGROUP';
        if (array_key_exists($option, self::$allOptions)) {
            foreach (self::$allOptions[$option] as $value) {
                $out[$value] = $value;
                $outPur[$value] = $value;
            }
        } else {
            self::$allOptions[$option] = array();
            $res = $db->select(
                $sql_tab['kampagne_lead'],
                array(
                    'distinct '.$sql_tabs['kampagne_lead'][$option],
                ),
                '',
                $sql_tabs['kampagne_lead'][$option].' ASC'

            );
            while ($row = $db->zeile($res)) {
                $value = self::prepareValue($row[0]);
                if (!isset($out[$value]) && !empty($value)) {
                    $out[$value] = $value;
                    $outPur[$row[0]] = $row[0];
                    self::$allOptions[$option][$value] = $value;
                }
            }
        }

        $out[_KATEGORIEN_] = 'OPTGROUP';
        $outPur[_KATEGORIEN_] = 'OPTGROUP';
        foreach (self::getCategories($option) as $category) {
            list($category, $categoryPur) = $category;
            if ($category && !isset($out[$category])) {
                $out[$category] = $category;
                $outPur[$categoryPur] = $categoryPur;
            }
        }
        return array($out, $outPur);
    }

    private static function getCategories($option) {
        global $db, $sql_tab, $sql_tabs;
        if (!is_array(self::$categories)) {
            self::$categories = self::$categoriesPur = array();
            $assignment = array(
                46 => 'source',
                47 => 'channel',
                48 => 'type',
                49 => 'kfzmarke',
                92 => 'absatzgruppe'
            );

            $res = $db->select(
                $sql_tab['kategorie'],
                array(
                    $sql_tabs['kategorie']['modul'],
                    $sql_tabs['kategorie']['bezeichnung'],
                    $sql_tabs['kategorie']['zusatz1'],
                ),
                $db->dbzahlin(array(46, 47, 48, 49), $sql_tabs['kategorie']['modul'])
            );
            while ($row = $db->zeile($res)) {
                $value = trim(self::prepareValue($row['zusatz1'] ? $row['zusatz1'] : $row['bezeichnung']));
                if ($value && $value != '-1') {
                    self::$categories[$assignment[$row['modul']]][$value] = $value;
                    self::$categoriesPur[$assignment[$row['modul']]][$value] = $row['zusatz1'] ? $row['zusatz1'] : $row['bezeichnung'];
                }
            }
            foreach ($assignment as $key) {
                if (empty(self::$categories[$key])) {
                    self::$categories[$key] = array();
                    self::$categoriesPur[$key] = array();
                } else {
                    ksort(self::$categories[$key]);
                    ksort(self::$categoriesPur[$key]);
                }
            }
            //echo "<pre>";var_dump(self::$categories);echo "</pre>";
        }
        return array(self::$categories[$option], self::$categoriesPur[$option]);
    }

    private static function getMakes($source) {
        $out = array('name' => _MARKE_);
        if (isset(self::$constantMakes[$source])) {
            $out['form-type'] = 'hidden';
            $out['values']    = self::$constantMakes[$source];
        } else {
            list ($values, $valuesPur) = self::getOptionValues($source, 'kfzmarke');
            $out['form-type']  = 'selectinput';
            $out['values']     = $values;
            $out['values-pur'] = $valuesPur;
        }
        return $out;
    }

    private static function prepareValue($value) {
        $value = json_encode(p4n_mb_string('utf8_encode', $value));
        return trim(p4n_mb_string('utf8_decode', html_entity_decode($value)), '"');
    }

    private static function getOpeningTimes($leadType = null) {
        if (self::$openingTimes === NULL) {
            global $db, $sql_tab, $sql_tabs;
            self::$openingTimes = array();

            $whereLeadType = '';
            if (!empty($leadType)) {
                $result_kategorie = $db->select(
                    $sql_tab['kategorie'],
                    $sql_tabs['kategorie']['zusatz2'],
                    $sql_tabs['kategorie']['modul'].'='.$db->dbzahl(48).' AND '.$sql_tabs['kategorie']['bezeichnung'].'='.$db->dbstr($leadType)
                );
                while ($row_kategorie = $db->zeile($result_kategorie)) {
                    if ($row_kategorie['zusatz2']) {
                        $whereLeadType = ' AND '.$sql_tabs['betriebszeit']['lead_type'].'='.$db->dbstr($leadType);
                        break;
                    }
                }
            }

            if ($dbserver) {
                $handle = fopen('temp/debug.txt', 'ab+');
                fwrite($handle, date('d.m.Y H:i:s').' $whereLeadType: '.print_r($whereLeadType, true)."\n");
                fclose($handle);
            }

            $res = $db->select(
                $sql_tab['betriebszeit'],
                array(
                    $sql_tabs['betriebszeit']['wochentag'],
                    $sql_tabs['betriebszeit']['beginn'],
                    $sql_tabs['betriebszeit']['ende'],
                    $sql_tabs['betriebszeit']['mandant_id']
                ),
                $sql_tabs['betriebszeit']['wochentag'].'='.$db->dbzahl(date('N')).' and '.
                $sql_tabs['betriebszeit']['aktiv'].'='.$db->dblogic(true).$whereLeadType
            );
            while ($row = $db->zeile($res)) {
                if (!empty($row[3])) {
                    if (empty($row[1])) {
                        $row[1] = '0000-00-00 00:00:00';
                    }
                    if (empty($row[2])) {
                        $row[2] = '0000-00-00 00:00:00';
                    }
                    $day = date('Y-m-d');
                    $start = $day.' '.$db->dbzeitdatum_ausgabe($row[1], 'zeit');
                    $end = $day.' '.$db->dbzeitdatum_ausgabe($row[2], 'zeit');
                    self::$openingTimes[$row[3]] = array(strtotime($start), strtotime($end));
                }
            }
        }
        return self::$openingTimes;
    }
}