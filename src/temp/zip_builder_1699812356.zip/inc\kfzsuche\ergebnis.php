<?php

    if ($kfzs_such_nurerg) {
        $inhalt='';
    }

    $pagination=new Template_Pagination('kfzsuche_ergebnis_pagination',10);
    

    $kfzdetails_modal_inhalt = new Template_ElementList('', 'kfzdetails_modal_inhalt');
    $kfzdetails_modal = Template_Modal::init('kfzdetails_modal', null, $kfzdetails_modal_inhalt,null,'',false, false);
    $kfzdetails_modal->setRight();

    $kfzadmin_modal_inhalt = new Template_ElementList('', 'kfzadmin_modal_inhalt');
    $kfzadmin_modal = Template_Modal::init('kfzadmin_modal', null, $kfzadmin_modal_inhalt,null,'',false, false);
    $kfzadmin_modal->setRight();

    $kfzdetails_modal_inhalt_iframe = new Template_Iframe($name='',$src='',$other='id="kfzdetails_modal_inhalt_iframe"', '');
    $kfzdetails_modal_iframe = Template_Modal::init('kfzdetails_modal_iframe', null, array(Template_Default::ModalHeader('Toyota '._FINANZIERUNG_),$kfzdetails_modal_inhalt_iframe,Template_Default::ModalFooter('','')) ,null,'',false, false);
    $kfzdetails_modal_iframe->setRight();

    $carDetailsModalContent = new Template_ElementList('', 'car_details_modal_inhalt');
    $carDetailsModal = new Template_Modal('car_details_modal', null, $carDetailsModalContent);
    $carDetailsModal->setRight();
    
    $pfbalken_show=false;
    if (isset($_COOKIE['kfzsuche_pfbalken_show'])) {
        if ($_COOKIE['kfzsuche_pfbalken_show']=='1') {
            $pfbalken_show=true;
        }
    }

            
	if (isset($getfeld['submit2']) or isset($getfeld['submitnav1']) or isset($getfeld['submitnav2']) or isset($postfeld['nur_ids']) or isset($getfeld['nur_ids2'])) {
		if (($cfg_kfzsuche_norway or $cfg_kfzsuche_pfkzliste or $cfg_s4_bmw20) and isset($sql_tab['reservierung_fahrzeuge'])) {
			$alle_kennz1=array();
			$res=$db->select(
						$sql_tab['reservierung_fahrzeuge'],
						array(
							$sql_tabs['reservierung_fahrzeuge']['reservierung_fahrzeuge_id'],
							$sql_tabs['reservierung_fahrzeuge']['kennzeichen'],
							$sql_tabs['reservierung_fahrzeuge']['beschreibung'],
							$sql_tabs['reservierung_fahrzeuge']['zusatz']
						),
						'',
						$sql_tabs['reservierung_fahrzeuge']['kennzeichen']
			);
			while ($row=$db->zeile($res)) {
				$alle_kennz1[$row[0]]=$row[1].($row[2]!=''?' ('.$row[2].')':'');
			}
		}
		$alle_pf=array();
		$alle_pf2=array();
		$alle_pf3=array();
		$sqltk=array(
				$sql_tabs['kalender']['produkt_id'],
				$sql_tabs['kalender']['beginn'],
				$sql_tabs['kalender']['ende']
		);
		if (($cfg_kfzsuche_norway or $cfg_kfzsuche_pfkzliste or $cfg_s4_bmw20) and isset($sql_tab['reservierung_fahrzeuge'])) {
			$sqltk[]=$sql_tabs['kalender']['reservierung_fahrzeuge_id'];
		}
		$res3=$db->select(
			$sql_tab['kalender'],
			$sqltk,
			$sql_tabs['kalender']['produkt_id'].'>0 and '.
				$sql_tabs['kalender']['beginn'].'>='.$db->dbdate(adodb_date('d.m.Y')),
			$sql_tabs['kalender']['beginn']
		);
		while ($row3=$db->zeile($res3)) {
			if (isset($alle_pf3[$row3[0].'_'.$row3[1].'_'.$row3[2]])) {
				continue;
			}
			$alle_pf[$row3[0]]++;
			$zus1_pf='';
			if (($cfg_kfzsuche_norway or $cfg_kfzsuche_pfkzliste or $cfg_s4_bmw20) and isset($sql_tab['reservierung_fahrzeuge'])) {
				if (isset($alle_kennz1[$row3[3]])) {
					$zus1_pf=' ('.$alle_kennz1[$row3[3]].')';
				}
			}
			$alle_pf2[$row3[0]].=$db->unixdatetime($row3[1]).' - '.$db->unixdatetime($row3[2]).$zus1_pf.'<br>';
			$alle_pf3[$row3[0].'_'.$row3[1].'_'.$row3[2]]=1;
		}
		
		if ($cfg_carlo_appserver_activity) {
			$alle_haendlstat=array();
			$res3=$db->select(
							$sql_tab['crmcodes'],
							array(
								$sql_tabs['crmcodes']['crmcodes_id'],
								$sql_tabs['crmcodes']['code1'],
								$sql_tabs['crmcodes']['text1']
							),
							$sql_tabs['crmcodes']['art'].'='.$db->str('CARLO_DEALERSTATUS')
						);
						while ($row3=$db->zeile($res3)) {
							if ($row3[1]!='') {
								$alle_haendlstat[$row3[1]]=$row3[2];
							}
			}
		}
		
		$alle_kfzzu=array();
		$alle_kfzzu2=array();
		$alle_kfzzu3=array();
		if ($cfg_kfzsuche_marginkalk2) {
			$res4=$db->select(
						$sql_tab['kfzzuordnung'],
						array(
							$sql_tabs['kfzzuordnung']['id'],
							$sql_tabs['kfzzuordnung']['markencode'],
							$sql_tabs['kfzzuordnung']['typmodell'],
							$sql_tabs['kfzzuordnung']['ueberfuehrungskosten'],
							$sql_tabs['kfzzuordnung']['marge_kfz'],
							$sql_tabs['kfzzuordnung']['marge_ausst']
						)
			);
			while ($row4=$db->zeile($res4)) {
				$alle_kfzzu[strtolower($row4[1])][$row4[2]]=$row4[0];
				$alle_kfzzu2[intval($row4[0])]=$row4;
			}
			
			$res4=$db->select(
						$sql_tab['kfzzuordnung_vkh'],
						array(
							$sql_tabs['kfzzuordnung_vkh']['kfzzuordnung_id'],
							$sql_tabs['kfzzuordnung_vkh']['bezeichnung'],
							$sql_tabs['kfzzuordnung_vkh']['betrag1'],
							$sql_tabs['kfzzuordnung_vkh']['betrag2'],
							$sql_tabs['kfzzuordnung_vkh']['automatisch'],
							$sql_tabs['kfzzuordnung_vkh']['inaktiv'],
							$sql_tabs['kfzzuordnung_vkh']['zusatz1']
						),
						'',
						$sql_tabs['kfzzuordnung_vkh']['bezeichnung']
			);
			while ($row4=$db->zeile($res4)) {
				$alle_kfzzu3[intval($row4[0])][]=$row4;
			}
		}
		
		$where='';
		$slog='';
		
		$suchfeld2=array();
		
		if ($cfg_kfzsuche_bmw_keine_inthist) {
			$where.=$sql_tabs['produktzuordnung']['text_1'].' not in ('.$db->str('Vergangenheit').','.$db->str('Interesse').') and ';
		}
    
        $carStatusConditon = $getfeld['kfzstatus'] != '-1';
        if (isset($_SESSION['design_70']) && is_array($getfeld['kfzstatus'])) {
            $carStatusCondition = !array_key_exists('-1', $getfeld['kfzstatus']);
        }
        
		if ($cfg_kfzsuche_dd2020) {
			@reset($getfeld['ddkfzstat']);
			$where_stat='';
			while (list($keys, $vals)=@each($getfeld['ddkfzstat'])) {
				$where_stat.=$sql_tabs['produktzuordnung']['fahrzeugstatus'].'='.$db->str($keys).' or ';
			}
			if ($where_stat!='') {
				$where.='('.substr($where_stat, 0, -4).') and ';
				$slog.='Status='.substr($where_stat, 0, -4).', ';
			}
		} elseif ($cfg_kfzsuche_vw) {
			if ($cfg_kfzsuche_vw_vaudisnr!='') {
				$where.=$sql_tabs['produktzuordnung']['stammdaten_id'].' in ('.$cfg_kfzsuche_vw_vaudisnr.') and ';
				$slog.='STID='.$cfg_kfzsuche_vw_vaudisnr.', ';
			} else {
				$where.='1=2 and ';
			}
		} elseif ($carStatusCondition) {
            if ($_SESSION['design_70']) {
                $wkfzstatus=$getfeld['kfzstatus'];
            } else {
                $wkfzstatus=array($getfeld['kfzstatus']=>$getfeld['kfzstatus']);
            }
            if (is_array($wkfzstatus)) {
                $where_temp2='';
                foreach (array_keys($wkfzstatus) as $key) {
                    $where_temp='';
                    if ($key=='-81') {
                        if ($cfg_suche_kfzschnell) {
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'!='.$db->dbzahl(3).' and ';
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'!='.$db->dbzahl(4).' and ';
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus_vorlauf'].'='.$db->dblogic(false).' and ';
                        } else {
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'!='.$db->dbzahl(3).' and ';
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'!='.$db->dbzahl(4).' and ';
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus'].' not like '.$db->str('Kundenfahrzeug%').' and ';
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus'].' not like '.$db->str('Customer%').' and ';
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus_vorlauf'].'='.$db->dblogic(false).' and ';
                        }
                        $slog.='Status=kein Kundenfahrzeug/VL, ';
                    } elseif ($key=='-70') {
                        if ($_SESSION['cfg_kunde']=='carlo_opel_dello' || $_SESSION['cfg_kunde']=='carlo_opel_duerkop') {
                            $where_temp.='('.$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].' in (0,2) or '.
                            $db->dbstrin(array('Neufahrzeug', 'Neuwagen', 'Vorf�hrwagen', 'Vorf�hrfahrzeug'), $sql_tabs['produktzuordnung']['fahrzeugstatus']).')'.($cfg_kfzsuche_vorlauf_in_nwvfw?'':' and '.$sql_tabs['produktzuordnung']['fahrzeugstatus_vorlauf'].'='.$db->dblogic(false)).' and ';
                            $slog.='Status=NW/VFW, ';
                        } elseif ($cfg_suche_kfzschnell) {
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].' in (0,2)'.($cfg_kfzsuche_vorlauf_in_nwvfw?'':' and '.$sql_tabs['produktzuordnung']['fahrzeugstatus_vorlauf'].'='.$db->dblogic(false)).' and ';
                            $slog.='Status=NW/VFW, ';
                        } else {
                        $where_temp.='('.$sql_tabs['produktzuordnung']['fahrzeugstatus'].'='.$db->str('Neufahrzeug').' or '.
                            $sql_tabs['produktzuordnung']['fahrzeugstatus'].'='.$db->str('Testfahrzeug').' or '.
                            $sql_tabs['produktzuordnung']['fahrzeugstatus'].' like '.$db->str('NEW%').' or '.
                            $sql_tabs['produktzuordnung']['fahrzeugstatus'].' like '.$db->str('DEMO%').' or '.
                            '('.$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].' in (0,2)'.($cfg_kfzsuche_vorlauf_in_nwvfw?'':' and '.$sql_tabs['produktzuordnung']['fahrzeugstatus'].' not like '.$db->str('% - %')).') or '.
                            $sql_tabs['produktzuordnung']['fahrzeugstatus'].'='.$db->str('Vorf�hrfahrzeug').') and ';
                            $slog.='Status=NW/VFW, ';
                        }
                        if ($_SESSION['cfg_kunde']=='carlo_opel_carebus') {
                            $where_temp.='('.$sql_tabs['produktzuordnung']['fahrzeugstatus'].'='.$db->str('Neufahrzeug').' or '.
                            $sql_tabs['produktzuordnung']['fahrzeugstatus'].'='.$db->str('Vorf�hrfahrzeug').' or '.
                            $sql_tabs['produktzuordnung']['fahrzeugstatus'].'='.$db->str('V�hicule neuf').' or '.
                            $sql_tabs['produktzuordnung']['fahrzeugstatus'].'='.$db->str('V�hicule demo').') and ';
                        }
                    } elseif ($key=='-80') {
                        if ($_SESSION['cfg_kunde']=='carlo_opel_dello' or $_SESSION['cfg_kunde']=='carlo_opel_duerkop') {
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'!='.$db->dbzahl(3).' and ';
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'!='.$db->dbzahl(4).' and ';
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus'].' not like '.$db->str('Kunden%').' and ';
                        } elseif ($cfg_suche_kfzschnell) {
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'!='.$db->dbzahl(3).' and ';
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'!='.$db->dbzahl(4).' and ';
                        } else {
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'!='.$db->dbzahl(3).' and ';
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'!='.$db->dbzahl(4).' and ';
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus'].' not like '.$db->str('Kundenfahrzeug%').' and ';
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus'].' not like '.$db->str('Customer%').' and ';
                        }
                        if ($_SESSION['cfg_kunde']=='carlo_opel_carebus') {
                            $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus'].' not like '.$db->str('V�hicule client%').' and ';
                        }
                        $slog.='Status=kein Kundenfahrzeug, ';
                    } elseif ($key=='-60') {
                        $where_temp.='('.$sql_tabs['produktzuordnung']['fahrzeugstatus'].' like '.$db->str('Miet%').' or '.
                                        $sql_tabs['produktzuordnung']['fahrzeugstatus'].' like '.$db->str('Rental%').' or '.
                                        $sql_tabs['produktzuordnung']['fahrzeugstatus'].'='.$db->str('Vorf�hrfahrzeug').') and ';
                        $slog.='Status=VFW, ';
                    } elseif ($key=='-50') {
                        $where_temp.='('.$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'='.$db->dbzahl(6).' or '.
                                        $sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'='.$db->dbzahl(1).' or '.
                                        $sql_tabs['produktzuordnung']['fahrzeugstatus'].'='.$db->str('Mietwagen').' or '.
                                        $sql_tabs['produktzuordnung']['fahrzeugstatus'].'='.$db->str('Gebrauchtwagen').') and ';
                        $slog.='Status=GW/Miet, ';
                    } elseif ($key=='-40') {
                        $where_temp.='('.$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'='.$db->dbzahl(1).' or '.
                                        $sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'='.$db->dbzahl(2).' or '.
                                        $sql_tabs['produktzuordnung']['fahrzeugstatus'].'='.$db->str('Vorf�hrfahrzeug').' or '.
                                        $sql_tabs['produktzuordnung']['fahrzeugstatus'].'='.$db->str('Gebrauchtwagen').') and ';
                        $slog.='Status=GW/VFW, ';
                    } else {
                        $where_temp.=$sql_tabs['produktzuordnung']['fahrzeugstatus'].'='.$db->str($key).' and ';
                        $slog.='Status='.$getfeld['kfzstatus'].', ';
                    }
                    $where_temp2.='('.substr($where_temp,0,-5).') or ';
                }
                if ($where_temp2!='') {
                    $where.='('.substr($where_temp2,0,-4).') and ';
                }
                //echo htmlentities('('.substr($where_temp2,0,-4).') and ');exit;
            }
		}
		
		if (isset($getfeld['status_int'])) {
			if ($getfeld['status_int']!='' and $getfeld['status_int']!='-1') {
				$where.=$sql_tabs['produktzuordnung']['zusatz_crm1'].'='.$db->str($getfeld['status_int']).' and ';
				$slog.='int.Status='.$getfeld['status_int'].', ';
			}
		}
		if (isset($getfeld['status_int2'])) {
			if ($getfeld['status_int2']!='' and $getfeld['status_int2']!='-1') {
				$where.=$sql_tabs['produktzuordnung']['generation'].'='.$db->str($getfeld['status_int2']).' and ';
				$slog.='int.Status2='.$getfeld['status_int2'].', ';
			}
		}
        if  ((!$_SESSION['design_70'] && $getfeld['standort']!='' and $getfeld['standort']!='-1') || ($_SESSION['design_70'] && is_array($getfeld['standort']) && !in_array(-1,$getfeld['standort']))) {
            if ($_SESSION['design_70']) {
                $wstandort=$getfeld['standort'];
            } else {
                $wstandort=array($getfeld['standort']);
            }

            if (is_array($wstandort)) {
                $where_temp2='';
                $i=0;
                foreach ($wstandort as $value) {
                    $where_temp='';
                    $where_temp.=$sql_tabs['produktzuordnung']['standort'].'='.$db->str($value).' and ';
                    $slog.='Standort='.$value.', ';
                    if ($cfg_dvs && $i==0) {
                        $suchfeld2['Filiale']=$value;
                        $suchfeld2['Lagerort']=$value;
                    }
                    $i++;
                    $where_temp2.='('.substr($where_temp,0,-5).') or ';
                }
                if ($where_temp2!='') {
                    $where.='('.substr($where_temp2,0,-4).') and ';
                }
                //echo htmlentities('('.substr($where_temp2,0,-4).') and ');exit;
            }
		}
        
        if (!empty($getfeld['markencode']) && $getfeld['markencode'] !== '-1') {
            $isVw = false;
            $isVW = p4n_mb_string('strtolower', $getfeld['markencode']) === 'vw';
            
            $isVolkswagen = false;
            $isVolkswagen = p4n_mb_string('strtolower', $getfeld['markencode']) === 'volkswagen';
            
            if ($cfg_carlo_appserver_activity) {
                $where .= $sql_tabs['produktzuordnung']['markencode'].' like '.$db->str(str_replace('*', '%', $getfeld['markencode'])).' and ';
            } elseif ($isVW) {
                $where .= '('.$sql_tabs['produktzuordnung']['markencode'].' like '.$db->str(str_replace('*', '%', $getfeld['markencode']).'%').' or ';
                $where .= $sql_tabs['produktzuordnung']['markencode'].' like '.$db->str(str_replace('*', '%', 'volkswagen').'%').') and ';
            } elseif ($isVolkswagen) {
                $where .= '('.$sql_tabs['produktzuordnung']['markencode'].' like '.$db->str(str_replace('*', '%', $getfeld['markencode']).'%').' or ';
                $where .= $sql_tabs['produktzuordnung']['markencode'].' like '.$db->str(str_replace('*', '%', 'vw').'%').') and ';
            } else {
                $where .= $sql_tabs['produktzuordnung']['markencode'].' like '.$db->str(str_replace('*', '%', $getfeld['markencode']).'%').' and ';
            }
         
            $slog .= 'Marke='.$getfeld['markencode'].', ';
            if ($cfg_dvs) {
                $suchfeld2['Fabrikat'] = $getfeld['markencode'];
            }
        }
        
		if (isset($getfeld['markencode2'])) {
			$wheremc='';
			while (list($key, $val)=@each($getfeld['markencode2'])) {
				$wheremc.=$sql_tabs['produktzuordnung']['markencode'].' like '.$db->str(str_replace('*', '%', $key).'%').' or ';
				$slog.='Marke='.$key.', ';
			}
			if ($wheremc!='') {
				$where.='('.p4n_mb_string('substr',$wheremc, 0, -4).') and ';
			}
		}
		$vortyp='%';
		$nachtyp='';
		if ($_SESSION['user_id']==1) {
		//	$vortyp='';
		}
		if ($cfg_kfzsuche_typ_ohnestern and isset($getfeld['typ_modell_ohnestern'])) {
			$vortyp='';
		}
		if ($cfg_kfzsuche_typ_ohnestern_leer and isset($getfeld['typ_modell_ohnestern'])) {
			$nachtyp=' ';
		}
		if ($cfg_kfzsuche_dd2020 and $getfeld['ddsuchmodell']!='' and $getfeld['ddsuchmodell']!='-1') {
			$where.=$sql_tabs['produktzuordnung']['fahrzeugklassecode'].'='.$db->str($getfeld['ddsuchmodell']).' and ';
		}
		if ($getfeld['typ_modell']!='' or $getfeld['typ_modell2']!='') {
			$zus_dvs_mod2='';
			if ($hat_dvs_aus) {
				$zus_dvs_mod2=' or '.$sql_tabs['produktzuordnung']['generation'].'='.$db->str($getfeld['typ_modell2']);
			}
			if ($getfeld['typ_modell']!='' and $getfeld['typ_modell2']!='') {
				$where.='('.$sql_tabs['produktzuordnung']['typ_modell'].' like '.$db->str(str_replace('*', '%', $vortyp.$getfeld['typ_modell']).'%').' or '.
					$sql_tabs['produktzuordnung']['typ'].' like '.$db->str(str_replace('*', '%', $vortyp.$getfeld['typ_modell']).'%').' or '.
					$sql_tabs['produktzuordnung']['typ'].' like '.$db->str(str_replace('*', '%', $vortyp.$getfeld['typ_modell2']).'%').' or '.
					$sql_tabs['produktzuordnung']['typ_modell'].' like '.$db->str(str_replace('*', '%', $vortyp.$getfeld['typ_modell2']).'%').$zus_dvs_mod2.') and ';
				$slog.='Typ='.$getfeld['typ_modell'].'/'.$getfeld['typ_modell2'].', ';
				if ($cfg_dvs) {
					$suchfeld2['Modell']=$getfeld['typ_modell2'];
				}
			} elseif ($getfeld['typ_modell']!='') {
				if ($cfg_kfzsuche_typmodell_leerzeichensternsuche or $cfg_kfzsuche_typ_ohnestern_leer) {
					$where.='('.$sql_tabs['produktzuordnung']['typ_modell'].' like '.$db->str(str_replace(array('*', ' '), '%', $vortyp.$getfeld['typ_modell'])).' or '.
							$sql_tabs['produktzuordnung']['typ'].' like '.$db->str(str_replace(array('*', ' '), '%', $vortyp.$getfeld['typ_modell'])).' or '.
						$sql_tabs['produktzuordnung']['typ_modell'].' like '.$db->str('%'.str_replace(array('*', ' '), '%', $vortyp.$getfeld['typ_modell']).$nachtyp.'%').' or '.
							$sql_tabs['produktzuordnung']['typ'].' like '.$db->str('%'.str_replace(array('*', ' '), '%', $vortyp.$getfeld['typ_modell']).$nachtyp.'%').') and ';
				} else {
					$where.='('.$sql_tabs['produktzuordnung']['typ_modell'].' like '.$db->str(str_replace('*', '%', $vortyp.$getfeld['typ_modell']).'%').' or '.
						$sql_tabs['produktzuordnung']['typ'].' like '.$db->str(str_replace('*', '%', $vortyp.$getfeld['typ_modell']).'%').') and ';
				}
				$slog.='Typ='.$getfeld['typ_modell'].', ';
				if ($cfg_dvs) {
					$suchfeld2['Modell']=$getfeld['typ_modell'];
				}
			} elseif ($getfeld['typ_modell2']!='') {
				if ($_SESSION['cfg_kunde']=='carlo_opel_dello') {
					$where.='('.$sql_tabs['produktzuordnung']['fahrzeugklassecode'].'='.$db->str($getfeld['typ_modell2']).' or ('.$sql_tabs['produktzuordnung']['fahrzeugklassecode'].'='.$db->str('').' and '.$sql_tabs['produktzuordnung']['typ_modell'].' like '.$db->str(str_replace('*', '%', '%'.$getfeld['typ_modell2']).'%').')) and ';
//					$where.='('.$sql_tabs['produktzuordnung']['typ_modell'].' like '.$db->str(str_replace('*', '%', '%'.$getfeld['typ_modell2']).'%').' or '.						$sql_tabs['produktzuordnung']['typ'].' like '.$db->str(str_replace('*', '%', '%'.$getfeld['typ_modell2']).'%').' or '.$sql_tabs['produktzuordnung']['fahrzeugklassecode'].'='.$db->str($getfeld['typ_modell2']).') and ';
				} else {
					$where.='('.$sql_tabs['produktzuordnung']['typ_modell'].' like '.$db->str(str_replace('*', '%', $vortyp.$getfeld['typ_modell2']).'%').' or '.
						$sql_tabs['produktzuordnung']['typ'].' like '.$db->str(str_replace('*', '%', $vortyp.$getfeld['typ_modell2']).'%').$zus_dvs_mod2.') and ';
				}
				$slog.='Typ='.$getfeld['typ_modell2'].', ';
				if ($cfg_dvs) {
					$suchfeld2['Modell']=$getfeld['typ_modell2'];
				}
			}
		}
		if ($getfeld['fahrzeugmodellnr']!='' and $getfeld['fahrzeugmodellnr']!='-1') {
			$xpl1=explode(',', $getfeld['fahrzeugmodellnr']);
			if (count($xpl1)>=2) {
				$where_m='';
				while (list($keym, $valm)=@each($xpl1)) {
					$where_m.=$sql_tabs['produktzuordnung']['fahrzeugmodellnr'].' like '.$db->str(str_replace('*', '%', trim($valm))).' or ';
					$slog.='Modellnr='.$valm.', ';
				}
				if ($where_m!='') {
					$where.='('.p4n_mb_string('substr',$where_m, 0, -4).') and ';
				}
			} else {
				$where.=$sql_tabs['produktzuordnung']['fahrzeugmodellnr'].' like '.$db->str(str_replace('*', '%', $getfeld['fahrzeugmodellnr']).'%').' and ';
				$slog.='Modellnr='.$getfeld['fahrzeugmodellnr'].', ';
			}
		}
		if ($getfeld['bauart']!='' and $getfeld['bauart']!='-1') {
			if ($cfg_dvs and is_numeric($getfeld['bauart'])) {
				$where.='('.$sql_tabs['produktzuordnung']['bauart'].' like '.$db->str($getfeld['bauart'].'%').' or '.
					$sql_tabs['produktzuordnung']['bauart'].' like '.$db->str($cfg_dvs_aufbau[intval($getfeld['bauart'])].'%').') and ';
				$slog.='Bauart='.$cfg_dvs_aufbau[intval($getfeld['bauart'])].', ';
			} else {
				$where.=$sql_tabs['produktzuordnung']['bauart'].' like '.$db->str($getfeld['bauart'].'%').' and ';
				$slog.='Bauart='.$getfeld['bauart'].', ';
			}
			if ($cfg_dvs) {
				$dvsbagef=false;
				if (!is_numeric($getfeld['bauart'])) {
					@reset($cfg_dvs_aufbau);
					while (list($keyb, $valb)=@each($cfg_dvs_aufbau)) {
						if ($valb==$getfeld['bauart']) {
							$suchfeld2['Aufbau']=$keyb;
							$dvsbagef=true;
						}
					}
				}
				if (!$dvsbagef) {
					$suchfeld2['Aufbau']=$getfeld['bauart'];	//$dvs_aufbau[$getfeld['bauart']];
				}
			}
		}
		if ($getfeld['unfallstatus']!='' and $getfeld['unfallstatus']!='-1') {
			if ($getfeld['unfallstatus']=='1') {
				$where.=$sql_tabs['produktzuordnung']['dezimal_2'].'='.$db->dbzahl(1).' and ';
			} elseif ($getfeld['unfallstatus']=='2') {
				$where.=$sql_tabs['produktzuordnung']['dezimal_2'].' in (2,3) and ';
			}
			$slog.='Unfallstatus='.$getfeld['unfallstatus'].', ';
		}
		if ($getfeld['antriebsart']!='' and $getfeld['antriebsart']!='-1') {
			$where.=$sql_tabs['produktzuordnung']['antriebsart'].'='.$db->str($getfeld['antriebsart']).' and ';
			$slog.='Antriebsart='.$getfeld['antriebsart'].', ';
		}
		if ($getfeld['motorartcode']!='' and $getfeld['motorartcode']!='-1') {
			if ($cfg_kfzsuche_motorart_kraftstoff) {
				$where.=$sql_tabs['produktzuordnung']['kraftstoff'].'='.$db->str($getfeld['motorartcode']).' and ';
			} elseif ($cfg_carlo_kfzimport_aukategorie) {
				$where.=$sql_tabs['produktzuordnung']['kraftstoff_sorte'].'='.$db->str($getfeld['motorartcode']).' and ';
			} else {
				$where.=$sql_tabs['produktzuordnung']['kennbuchstabe_motor'].' like '.$db->str($getfeld['motorartcode'].'%').' and ';
			}
			$slog.='Motor='.$getfeld['motorartcode'].', ';
		}
                
                        
        if  ((!$_SESSION['design_70'] && $getfeld['kennbuchstabe_getriebe']!='' and $getfeld['kennbuchstabe_getriebe']!='-1') || ($_SESSION['design_70'] && is_array($getfeld['kennbuchstabe_getriebe']) && !in_array(-1,$getfeld['kennbuchstabe_getriebe']))) {  
            if ($_SESSION['design_70']) {
                $wkennbuchstabe_getriebe=$getfeld['kennbuchstabe_getriebe'];
            } else {
                $wkennbuchstabe_getriebe=array($getfeld['kennbuchstabe_getriebe']);
            }
            if (is_array($wkennbuchstabe_getriebe)) {
                $where_temp2='';
                foreach ($wkennbuchstabe_getriebe as $value) {
                    $where_temp='';
					
                    if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent' or $cfg_kfzsuche_getriebeausbezeichnung) {
						$where.=$sql_tabs['produktzuordnung']['getriebebezeichnung'].' like '.$db->str($getfeld['kennbuchstabe_getriebe']).' and ';
						$slog.='Getriebe='.$getfeld['kennbuchstabe_getriebe'].', ';
					} elseif ($_SESSION['cfg_kunde']=='carlo_opel_peugeot_bebion' or $cfg_kfzsuche_getriebe_auskfz) {
                        $where_temp.=$sql_tabs['produktzuordnung']['kennbuchstabe_getriebe'].' like '.$db->str($value).' and ';
                        $slog.='Getriebe='.$value.', ';
                    } elseif ($cfg_carlo_appserver_activity or $cfg_cross_mit_vfw) {
                        if ($value=='Automatik') {
                            $where_temp.=$sql_tabs['produktzuordnung']['kennbuchstabe_getriebe'].' like '.$db->str('%AUT%').' and ';
                            $slog.='Getriebe=Aut, ';
                        } else {
                            $where_temp.='('.$sql_tabs['produktzuordnung']['kennbuchstabe_getriebe'].' like '.$db->str('%SCH%').' or '.$sql_tabs['produktzuordnung']['kennbuchstabe_getriebe'].' like '.$db->str('%MAN%').') and ';
                            $slog.='Getriebe=Sch/Man, ';
                        }
                    } else {
                        if ($value=='5-Gang') {
                            $slog.='Getriebe=5-Gang, ';
                            $where_temp.=$sql_tabs['produktzuordnung']['getriebebezeichnung'].' like '.$db->str('%5%').' and '.
                                    $sql_tabs['produktzuordnung']['getriebebezeichnung'].' not like '.$db->str('%AUT%').' and ';
                            if ($cfg_kfzsuche_getriebe_dkg) {
                                $where_temp.=$sql_tabs['produktzuordnung']['getriebebezeichnung'].' not like '.$db->str('%DOPPEL%').' and ';
                                $where_temp.=$sql_tabs['produktzuordnung']['getriebebezeichnung'].' not like '.$db->str('%DCT%').' and ';
                            }
                            if ($cfg_dvs) {
                                    $suchfeld2['Schaltung']=2;
                            }
                        }
                        if ($value=='6-Gang') {
                            $slog.='Getriebe=6-Gang, ';
                            $where_temp.=$sql_tabs['produktzuordnung']['getriebebezeichnung'].' like '.$db->str('%6%').' and '.
                                    $sql_tabs['produktzuordnung']['getriebebezeichnung'].' not like '.$db->str('%AUT%').' and ';
                            if ($cfg_kfzsuche_getriebe_dkg) {
                                $where_temp.=$sql_tabs['produktzuordnung']['getriebebezeichnung'].' not like '.$db->str('%DOPPEL%').' and ';
                                $where_temp.=$sql_tabs['produktzuordnung']['getriebebezeichnung'].' not like '.$db->str('%DCT%').' and ';
                            }
                            if ($cfg_dvs) {
                                    $suchfeld2['Schaltung']=2;
                            }
                        }
                        if ($value=='Easytronic') {
                            $slog.='Getriebe=Easytronic, ';
                            $where_temp.=$sql_tabs['produktzuordnung']['getriebebezeichnung'].' like '.$db->str('%Easytronic%').' and ';
                            if ($cfg_dvs) {
                                    $suchfeld2['Schaltung']=1;
                            }
                        }
                        if ($value=='Automatik') {
                            $slog.='Getriebe=Automatik, ';
                            if ($_SESSION['cfg_kunde']=='carlo_opel_dello') {
                                $where_temp.='('.$sql_tabs['produktzuordnung']['getriebebezeichnung'].' like '.$db->str('%AUT%').' or '.$sql_tabs['produktzuordnung']['kennbuchstabe_getriebe'].' like '.$db->str($value).') and ';
                            } else {
                                if ($cfg_kfzsuche_getriebe_dkg) {
                                    $where_temp.='('.$sql_tabs['produktzuordnung']['getriebebezeichnung'].' like '.$db->str('%AUT%').' or '.$sql_tabs['produktzuordnung']['getriebebezeichnung'].' like '.$db->str('%DOPPEL%').' or '.$sql_tabs['produktzuordnung']['getriebebezeichnung'].' like '.$db->str('%DCT%').') and ';
                                } else {
                                    $where_temp.=$sql_tabs['produktzuordnung']['getriebebezeichnung'].' like '.$db->str('%AUT%').' and ';
                                }
                            }
                            if ($cfg_dvs) {
                                    $suchfeld2['Schaltung']=1;
                            }
                        }
                        if ($cfg_ws_avag_kroatien or (($_SESSION['cfg_kunde']=='carlo_opel_dello' or ($cfg_kfzsuche_dd2020 and $_SESSION['cfg_kunde']=='carlo_opel_duerkop')) and $value!='Automatik')) {
                            $where_temp.=$sql_tabs['produktzuordnung']['kennbuchstabe_getriebe'].' like '.$db->str($value).' and ';
                            $slog.='Getriebe='.$value.', ';
                        }
                    }
                    $where_temp2.='('.substr($where_temp,0,-5).') or ';
                }
                if ($where_temp2!='') {
                    $where.='('.substr($where_temp2,0,-4).') and ';
                }
                //echo htmlentities('('.substr($where_temp2,0,-4).') and ');exit;
            }
		}
		
		if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent' && !$_SESSION['design_70']) {
			$m_motortart=$getfeld['motorartcode2'];
                        $suchfeld2['Treibstoff']=$getfeld['motorartcode2'];
                        $getfeld['motorartcode2']=$cfg_dvs_treibstoff[$getfeld['motorartcode2']];
		}
		
        if  ((!$_SESSION['design_70'] && $getfeld['motorartcode2']!='' and $getfeld['motorartcode2']!='-1') || ($_SESSION['design_70'] && is_array($getfeld['motorartcode2']) && !in_array(-1,$getfeld['motorartcode2']))) {
            if ($_SESSION['design_70']) {
                $wmotorartcode2=$getfeld['motorartcode2'];
            } else {
                $wmotorartcode2=array($getfeld['motorartcode2']=>$getfeld['motorartcode2']);
            }
            if (is_array($wmotorartcode2)) {
                $where_temp2='';
                $i=0;
                foreach ($wmotorartcode2 as $key) {
                    if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent' && $i==0) {
                        $suchfeld2['Treibstoff']=$key;
                        $key=$cfg_dvs_treibstoff[$key];
                    }
                    $where_temp='';

                    if ($key=='Benzin') {
                        if ($cfg_dvs) {
                            $suchfeld2['Treibstoff']=1;
                            $where_temp.='('.$sql_tabs['produktzuordnung']['kraftstoff'].' like '.$db->str('B%').' or '.
                                    $sql_tabs['produktzuordnung']['motorartcode'].'='.$db->str('O').') and ';
                            $slog.='Treibstoff=Benzin, ';
                        } else {
                            if ($cfg_kfzsuche_italien) {
                                $where_temp.='('.$sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%Benzina%').' or '.$sql_tabs['produktzuordnung']['kraftstoff'].' like '.$db->str('%Benzina%').' or '.$sql_tabs['produktzuordnung']['motorartcode'].' like '.$db->str('%Benzina%').') and ';
                            } else {
                                $where_temp.='('.$sql_tabs['produktzuordnung']['kraftstoff'].' like '.$db->str('O%').' or '.
                                $sql_tabs['produktzuordnung']['kraftstoff'].' like '.$db->str('B%').' or '.
                                $sql_tabs['produktzuordnung']['motorartcode'].' like '.$db->str('Benzin').' or '.
                                $sql_tabs['produktzuordnung']['motorartcode'].'='.$db->str('O').' or ('.
                                $sql_tabs['produktzuordnung']['kraftstoff'].'='.$db->str('').' and '.
                                $sql_tabs['produktzuordnung']['motorbezeichnung'].' not like '.$db->str('%diesel%').' and '.
                                $sql_tabs['produktzuordnung']['motorbezeichnung'].' not like '.$db->str('%cdti%').' and '.
                                $sql_tabs['produktzuordnung']['motorbezeichnung'].' not like '.$db->str('%dti%').' and '.
                                $sql_tabs['produktzuordnung']['motorbezeichnung'].' not like '.$db->str('%cng%').')) and ';
                            }
                        }
                        $slog.='Treibstoff=Benzin, ';
                    } elseif ($key=='Diesel') {
                        if ($cfg_dvs) {
                            $suchfeld2['Treibstoff']=2;
                            $where_temp.='('.$sql_tabs['produktzuordnung']['kraftstoff'].' like '.$db->str('D%').' or '.
                            $sql_tabs['produktzuordnung']['motorartcode'].'='.$db->str('D').') and ';
                        } else {
                            if ($cfg_kfzsuche_italien) {
                                $where_temp.='('.$sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%diesel%').' or '.$sql_tabs['produktzuordnung']['kraftstoff'].' like '.$db->str('%diesel%').' or '.$sql_tabs['produktzuordnung']['motorartcode'].' like '.$db->str('%diesel%').') and ';
                            } else {
                                $where_temp.='('.$sql_tabs['produktzuordnung']['kraftstoff'].' like '.$db->str('D%').' or '.
                                $sql_tabs['produktzuordnung']['motorartcode'].' like '.$db->str('DIESEL').' or '.
                                $sql_tabs['produktzuordnung']['motorartcode'].'='.$db->str('D').' or ('.
                                $sql_tabs['produktzuordnung']['kraftstoff'].'='.$db->str('').' and '.
                                '('.$sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%cdti%').' or '.
                                $sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%diesel%').' or '.
                                $sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%dt%').' or '.
                                $sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%tdi%').'))) and ';
                            }
                        }
                        $slog.='Treibstoff=Diesel, ';
                    } elseif ($key=='Elektro' && $_SESSION['cfg_kunde']!='carlo_opel_dbrent') {
                        if ($cfg_kfzsuche_carlo_hybridelektro) {
                            $where_temp.=$sql_tabs['produktzuordnung']['kraftstoff'].'='.$db->str('E').' and ';
                        } else {
                            $where_temp.='('.$sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%Elektro%').' or '.$sql_tabs['produktzuordnung']['kraftstoff'].' like '.$db->str('%Elektro%').' or '.$sql_tabs['produktzuordnung']['motorartcode'].' like '.$db->str('%Elektro%').') and ';
                        }
                        $slog.='Treibstoff=Elektro, ';
                    } elseif ($key=='Hybrid') {
                        if ($cfg_kfzsuche_carlo_hybridelektro) {
                            $where_temp.=$sql_tabs['produktzuordnung']['kraftstoff'].'='.$db->str('HY').' and ';
                        } else {
                            $where_temp.=$sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%Hybrid%').' and ';
                        }
                        $slog.='Treibstoff=Hybrid, ';
                    } elseif ($key=='Plugin-Hybrid') {
                        if ($cfg_kfzsuche_carlo_hybridelektro) {
                            $where_temp.=$sql_tabs['produktzuordnung']['kraftstoff'].'='.$db->str('PHY').' and ';
                        } else {
                            $where_temp.=$sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%plug%').' and ';
                        }
                        $slog.='Treibstoff=Plugin, ';
                    } elseif ($key=='Electric') {
                        $where_temp.='('.$sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%Electric%').' or '.$sql_tabs['produktzuordnung']['kraftstoff'].' like '.$db->str('%Electric%').' or '.$sql_tabs['produktzuordnung']['motorartcode'].' like '.$db->str('%Electric%').') and ';
                        $slog.='Treibstoff=Electric, ';
                    } elseif ($key=='Natural') {
                        $where_temp.='('.$sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%Natural%').' or '.$sql_tabs['produktzuordnung']['kraftstoff'].' like '.$db->str('%Natural%').' or '.$sql_tabs['produktzuordnung']['motorartcode'].' like '.$db->str('%Natural%').') and ';
                        $slog.='Treibstoff=Natural, ';
                    } elseif ($key=='Hydrogen') {
                        $where_temp.='('.$sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%Hydrogen%').' or '.$sql_tabs['produktzuordnung']['kraftstoff'].' like '.$db->str('%Hydrogen%').' or '.$sql_tabs['produktzuordnung']['motorartcode'].' like '.$db->str('%Hydrogen%').') and ';
                        $slog.='Treibstoff=Hydrogen, ';
                    } elseif ($key=='Gas') {
                        $where_temp.='('.$sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%Gas%').' or '.$sql_tabs['produktzuordnung']['kraftstoff'].' like '.$db->str('%Gas%').' or '.$sql_tabs['produktzuordnung']['motorartcode'].' like '.$db->str('%Gas%').' or '.$sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%GPL%').' or '.$sql_tabs['produktzuordnung']['kraftstoff'].' like '.$db->str('%GPL%').' or '.$sql_tabs['produktzuordnung']['motorartcode'].' like '.$db->str('%GPL%').') and ';
                        $slog.='Treibstoff=Gas, ';
                    } elseif ($key=='CNG') {
                        if ($cfg_dvs) {
                                $suchfeld2['Treibstoff']=4;
                        }
                        $where_temp.='('.$sql_tabs['produktzuordnung']['kraftstoff'].'='.$db->str('CNG').' or '.
                                $sql_tabs['produktzuordnung']['kraftstoff'].'='.$db->str('Gas').' or '.
                                $sql_tabs['produktzuordnung']['motorartcode'].'='.$db->str('CNG').' or '.
                                $sql_tabs['produktzuordnung']['motorartcode'].'='.$db->str('E').' or '.
                                $sql_tabs['produktzuordnung']['motorartcode'].'='.$db->str('G').' or '.
                                $sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%cng%').') and ';
                        $slog.='Treibstoff=CNG, ';
                    } elseif ($key=='LPG') {
                        $where_temp.='('.$sql_tabs['produktzuordnung']['kraftstoff'].'='.$db->str('LPG').' or '.
                                $sql_tabs['produktzuordnung']['kraftstoff'].'='.$db->str('Gas').' or '.
                                $sql_tabs['produktzuordnung']['motorartcode'].'='.$db->str('GAS').' or '.
                                $sql_tabs['produktzuordnung']['motorartcode'].'='.$db->str('F').' or '.
                                $sql_tabs['produktzuordnung']['motorbezeichnung'].' like '.$db->str('%lpg%').') and ';
                        if ($cfg_dvs) {
                            $suchfeld2['Treibstoff']=9;
                        }
                        $slog.='Treibstoff=LPG, ';
                    } else {
                        if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
                            $where_temp.=$sql_tabs['produktzuordnung']['kraftstoff'].'='.$db->str($key).' and ';
                            $slog.='Treibstoff='.$key.', ';
                        }
                    }

                    $i++;
                    $where_temp2.='('.substr($where_temp,0,-5).') or ';
                }
                if ($where_temp2!='') {
                    $where.='('.substr($where_temp2,0,-4).') and ';
                    //echo htmlentities('('.substr($where_temp2,0,-4).') and ');exit;
                }
            }
		}
		
		if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent' && !$_SESSION['design_70']) {
			$getfeld['motorartcode2']=$m_motortart;
		}
		
		if (isset($cfg_kfzsuche_preisvon)) {
			if ($cfg_kfzsuche_preisvon>=1) {
				$where.=$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'].'>='.$db->dbzahl($cfg_kfzsuche_preisvon).' and ';
				$slog.='Preis gr. '.$cfg_kfzsuche_preisvon.', ';
				$suchfeld2['Preis_von']=intval($cfg_kfzsuche_preisvon);
			}
		}

		if ($getfeld['preis_von']!='') {
			if ($cfg_kfzsuche_auszpreis) {
				$where.=$sql_tabs['produktzuordnung']['auszeichnungspreis'].'>='.$db->dbzahl($getfeld['preis_von']).' and ';
				$slog.='Preis ab '.$getfeld['preis_von'].', ';
			} else {
				$where.=$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'].'>='.$db->dbzahl($getfeld['preis_von']).' and ';
				$slog.='Preis ab '.$getfeld['preis_von'].', ';
			}
			if ($cfg_dvs) {
				$suchfeld2['Preis_von']=intval($getfeld['preis_von']);
			}
		}
		if ($getfeld['preis_bis']!='') {
			if ($cfg_kfzsuche_auszpreis) {
				$where.=$sql_tabs['produktzuordnung']['auszeichnungspreis'].'<='.$db->dbzahl($getfeld['preis_bis']).' and ';
				$slog.='Preis bis '.$getfeld['preis_bis'].', ';
			} else {
				$where.=$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'].'<='.$db->dbzahl($getfeld['preis_bis']).' and ';
				$slog.='Preis bis '.$getfeld['preis_bis'].', ';
			}
			if ($cfg_dvs) {
				$suchfeld2['Preis_bis']=intval($getfeld['preis_bis']);
			}
		}
		if ($getfeld['datum_ez_von']!='') {
			if ($getfeld['datum_ez_von']==_OHNE_) {
				$where.='('.$sql_tabs['produktzuordnung']['datum_ez'].'='.$db->dbdate('01.01.1970').' or '.$sql_tabs['produktzuordnung']['datum_ez'].'='.$db->dbdate('0000-00-00').' or '.$sql_tabs['produktzuordnung']['datum_ez'].'='.$db->dbdate('').') and ';
				$slog.='EZ=ohne, ';
			} else {
				if ($cfg_kfzsuche_suche_ez_datum) {
					$where.=$sql_tabs['produktzuordnung']['datum_ez'].'>='.$db->dbdate($getfeld['datum_ez_von']).' and ';
				} else {
					if (preg_match('/^\d\.\d\d\d\d$/', $getfeld['datum_ez_von'])) {
						$where.=$sql_tabs['produktzuordnung']['datum_ez'].'>='.$db->dbdate('01.0'.$getfeld['datum_ez_von']).' and ';
					} elseif (preg_match('/\d\d\.\d\d\d\d/', $getfeld['datum_ez_von'])) {
						$where.=$sql_tabs['produktzuordnung']['datum_ez'].'>='.$db->dbdate('01.'.$getfeld['datum_ez_von']).' and ';
					} elseif (preg_match('/^\d\d\d\d\d$/', $getfeld['datum_ez_von'])) {
						$where.=$sql_tabs['produktzuordnung']['datum_ez'].'>='.$db->dbdate('01.'.substr($getfeld['datum_ez_von'], 0, 1).'.'.substr($getfeld['datum_ez_von'], 1, 4)).' and ';
					} elseif (preg_match('/\d\d\d\d\d\d/', $getfeld['datum_ez_von'])) {
						$where.=$sql_tabs['produktzuordnung']['datum_ez'].'>='.$db->dbdate('01.'.substr($getfeld['datum_ez_von'], 0, 2).'.'.substr($getfeld['datum_ez_von'], 2, 4)).' and ';
					} else {
						$where.=$sql_tabs['produktzuordnung']['datum_ez'].'>='.$db->dbdate('01.01.'.$getfeld['datum_ez_von']).' and ';
					}
				}
				$slog.='EZ ab '.$getfeld['datum_ez_von'].', ';
			}
			if ($cfg_dvs) {
				$suchfeld2['Erstzulassung_von']=intval($getfeld['datum_ez_von']);
			}
		}
		if ($getfeld['datum_ez_bis']!='') {
			if ($getfeld['datum_ez_bis']==_OHNE_) {
				$where.='('.$sql_tabs['produktzuordnung']['datum_ez'].'='.$db->dbdate('01.01.1970').' or '.$sql_tabs['produktzuordnung']['datum_ez'].'='.$db->dbdate('0000-00-00').' or '.$sql_tabs['produktzuordnung']['datum_ez'].'='.$db->dbdate('').') and ';
				$slog.='EZ=ohne, ';
			} else {
				if ($cfg_kfzsuche_suche_ez_datum) {
					$where.=$sql_tabs['produktzuordnung']['datum_ez'].'<='.$db->dbdate($getfeld['datum_ez_bis']).' and ';
				} else {
					if (preg_match('/^\d\.\d\d\d\d$/', $getfeld['datum_ez_bis'])) {
						$zieldat1=adodb_mktime(12,0,0,substr($getfeld['datum_ez_bis'], 0, 1), 1, substr($getfeld['datum_ez_bis'], 2, 4));
						$where.=$sql_tabs['produktzuordnung']['datum_ez'].'<='.$db->dbdate(adodb_date('t.m.Y', $zieldat1)).' and ';
					} elseif (preg_match('/\d\d\.\d\d\d\d/', $getfeld['datum_ez_bis'])) {
						$zieldat1=adodb_mktime(12,0,0,substr($getfeld['datum_ez_bis'], 0, 2), 1, substr($getfeld['datum_ez_bis'], 3, 4));
						$where.=$sql_tabs['produktzuordnung']['datum_ez'].'<='.$db->dbdate(adodb_date('t.m.Y', $zieldat1)).' and ';
					} elseif (preg_match('/^\d\d\d\d\d$/', $getfeld['datum_ez_bis'])) {
						$zieldat1=adodb_mktime(12,0,0,substr($getfeld['datum_ez_bis'], 0, 1), 1, substr($getfeld['datum_ez_bis'], 1, 4));
						$where.=$sql_tabs['produktzuordnung']['datum_ez'].'<='.$db->dbdate(adodb_date('t.m.Y', $zieldat1)).' and ';
					} elseif (preg_match('/\d\d\d\d\d\d/', $getfeld['datum_ez_bis'])) {
						$zieldat1=adodb_mktime(12,0,0,substr($getfeld['datum_ez_bis'], 0, 2), 1, substr($getfeld['datum_ez_bis'], 2, 4));
						$where.=$sql_tabs['produktzuordnung']['datum_ez'].'<='.$db->dbdate(adodb_date('t.m.Y', $zieldat1)).' and ';
					} else {
						$where.=$sql_tabs['produktzuordnung']['datum_ez'].'<='.$db->dbdate('31.12.'.$getfeld['datum_ez_bis']).' and ';
					}
				}
				$slog.='EZ bis '.$getfeld['datum_ez_bis'].', ';
			}
			if ($cfg_dvs) {
				$suchfeld2['Erstzulassung_bis']=intval($getfeld['datum_ez_bis']);
			}
		}
		if ($getfeld['km_von']!='') {
			$where.=$sql_tabs['produktzuordnung']['km_stand'].'>='.$db->dbzahl($getfeld['km_von']).' and ';
			$slog.='km ab '.$getfeld['km_von'].', ';
		}
		if ($getfeld['km_bis']!='') {
			$where.=$sql_tabs['produktzuordnung']['km_stand'].'<='.$db->dbzahl($getfeld['km_bis']).' and ';
			if ($cfg_dvs) {
				$suchfeld2['Laufleistung_bis']=intval($getfeld['km_bis']);
			}
			$slog.='km bis '.$getfeld['km_bis'].', ';
		}
		if ($getfeld['ps_von']!='') {
			$where.=$sql_tabs['produktzuordnung']['leistung_ps'].'>='.$db->dbzahl($getfeld['ps_von']).' and ';
			$slog.='PS von '.$getfeld['ps_von'].', ';
			if ($cfg_dvs) {
				$kw1=round(intval($getfeld['ps_von'])/1.35962);
				$suchfeld2['Leistung_von']=intval($kw1);
			}
		}
		if ($getfeld['ps_bis']!='') {
			$where.=$sql_tabs['produktzuordnung']['leistung_ps'].'<='.$db->dbzahl($getfeld['ps_bis']).' and ';
			$slog.='PS bis '.$getfeld['ps_bis'].', ';
			if ($cfg_dvs) {
				$kw1=round(intval($getfeld['ps_bis'])/1.35962);
				$suchfeld2['Leistung_bis']=intval($kw1);
			}
		}
		if ($getfeld['kw_von']!='') {
			$where.=$sql_tabs['produktzuordnung']['leistung_kw'].'>='.$db->dbzahl($getfeld['kw_von']).' and ';
			$slog.='KW von '.$getfeld['kw_von'].', ';
			if ($cfg_dvs) {
				$suchfeld2['Leistung_von']=intval($getfeld['kw_von']);
			}
		}
		if ($getfeld['kw_bis']!='') {
			$where.=$sql_tabs['produktzuordnung']['leistung_kw'].'<='.$db->dbzahl($getfeld['kw_bis']).' and ';
			$slog.='KW bis '.$getfeld['kw_bis'].', ';
			if ($cfg_dvs) {
				$suchfeld2['Leistung_bis']=intval($getfeld['kw_bis']);
			}
		}
		if ($getfeld['hubraum_von']!='') {
			$where.=$sql_tabs['produktzuordnung']['hubraum'].'>='.$db->dbzahl($getfeld['hubraum_von']).' and ';
			$slog.='Hubraum von '.$getfeld['hubraum_von'].', ';
			if ($cfg_dvs) {
				$suchfeld2['Hubraum_von']=intval($getfeld['hubraum_von']);
			}
		}
		if ($getfeld['hubraum_bis']!='') {
			$where.=$sql_tabs['produktzuordnung']['hubraum'].'<='.$db->dbzahl($getfeld['hubraum_bis']).' and ';
			$slog.='Hubraum bis '.$getfeld['hubraum_bis'].', ';
			if ($cfg_dvs) {
				$suchfeld2['Hubraum_bis']=intval($getfeld['hubraum_bis']);
			}
		}
		if ($getfeld['vorbesitzername']!='') {
			$slog.='Vorbesitzer='.$getfeld['vorbesitzername'].', ';
			$where.='('.$sql_tabs['produktzuordnung']['alter_debname'].' like '.$db->str('%'.str_replace('*', '%', $getfeld['vorbesitzername']).'%').' or '.
						$sql_tabs['produktzuordnung']['vorbesitzername'].' like '.$db->str('%'.str_replace('*', '%', $getfeld['vorbesitzername']).'%').') and ';
		}
		
		if ($getfeld['tueren']!='') {
			$slog.='T�ren='.$getfeld['tueren'].', ';
			$where.=$sql_tabs['produktzuordnung']['anzahl_tueren'].'='.$db->dbzahl($getfeld['tueren']).' and ';
		}
                
		if ($getfeld['farbe2']!='' and $getfeld['farbe2']!='-1') {
            if ($_SESSION['design_70']) {
                $wfarbe2=$getfeld['farbe2'];
            } else {
                $wfarbe2=array($getfeld['farbe2']=>$getfeld['farbe2']);
            }
            if (is_array($wfarbe2)) {
                $where_temp2='';
                $i=0;
                foreach ($wfarbe2 as $value) {
                    $where_temp='';

                    $wher2='';
                    if (isset($farben2[$value])) {
                        $slog.='Farbe='.$value.', ';
                        while (list($fkey, $fval)=@each($farben2[$value])) {
                                $wher2.=$sql_tabs['produktzuordnung']['farbbezeichnung'].' like '.$db->str('%'.$fval.'%').' or ';
                        }
                        $wher2=p4n_mb_string('substr',$wher2, 0, -4);
                        if ($wher2!='') {
                            $where_temp.='('.$wher2.') and ';
                        }
                    }
                    if ($wher2=='') {
                        $where_temp.=$sql_tabs['produktzuordnung']['farbbezeichnung'].' like '.$db->str('%'.$value.'%').' and ';
                    }
                    if ($cfg_dvs && $i==0) {
                        if (isset($dvs_farbcodes[$value])) {
                                $suchfeld2['Grundfarbe']=$dvs_farbcodes[$value];
                        }
                    }
                    $i++;
                    $where_temp2.='('.substr($where_temp,0,-5).') or ';
                }
                if ($where_temp2!='') {
                    $where.='('.substr($where_temp2,0,-4).') and ';
                }
                //echo htmlentities('('.substr($where_temp2,0,-4).') and ');exit;
            }
		} elseif ($getfeld['farbe']!='') {
			$where.=$sql_tabs['produktzuordnung']['farbbezeichnung'].' like '.$db->str('%'.$getfeld['farbe'].'%').' and ';
			$slog.='Farbe='.$getfeld['farbe'].', ';
			if ($cfg_dvs) {
				if (isset($dvs_farbcodes[p4n_mb_string('strtolower',$getfeld['farbe'])])) {
					$suchfeld2['Grundfarbe']=$dvs_farbcodes[p4n_mb_string('strtolower',$getfeld['farbe'])];
				}
			}
		}
		if (isset($getfeld['polster2'])) {
			if ($getfeld['polster2']!='' and $getfeld['polster2']!='-1') {
				$where.=$sql_tabs['produktzuordnung']['farbcode_innenausstattung'].' like '.$db->str('%'.$getfeld['polster2'].'%').' and ';
				$slog.='Polster='.$getfeld['polster2'].', ';
			} elseif ($getfeld['polster']!='') {
				$where.=$sql_tabs['produktzuordnung']['polsterbezeichnung'].' like '.$db->str('%'.$getfeld['polster'].'%').' and ';
				$slog.='Polster='.$getfeld['polster'].', ';
			}
		}
 
        $where_a = '';
		if ($getfeld['ausstattung']!='') {
			$slog.='Ausst='.$getfeld['ausstattung'].', ';
			$expl1=explode(',', $getfeld['ausstattung']);
			if (count($expl1)>1) {
                $where_zus1=array();
                $where_zus2=array();
				while (list($key1, $val1)=@each($expl1)) {
					$val1=trim($val1);
                    if ($_SESSION['cfg_kunde']=='carlo_opel_dello' or $_SESSION['cfg_kunde']=='carlo_opel_duerkop' or $_SESSION['cfg_kunde']=='carlo_opel_haeusler') {
						$where_zus1[]=$sql_tabs['produktzuordnung']['dispotext'].' like '.$db->str('%'.str_replace('*', '%', $val1).'%');
					}
					if ($cfg_kfzsuche_ausst_ohnenichtsuchen) {
						$where_zus2[]=$sql_tabs['produktzuordnung']['kommentar'].' like '.$db->str('%'.str_replace('*', '%', $val1).'%').' and '.$sql_tabs['produktzuordnung']['kommentar'].' not like '.$db->str('%ohne '.str_replace('*', '%', $val1).'%');
					} else {
	                    $where_zus2[]=$sql_tabs['produktzuordnung']['kommentar'].' like '.$db->str('%'.str_replace('*', '%', $val1).'%');
					}
				}
                $where_a1='';
                if (!empty($where_zus1)) {
                    $where_a1=' or ('.implode(' and ', $where_zus1).')';
                }
                if (!empty($where_zus2)) {
                    $where_a = '(('.implode(' and ', $where_zus2).')'.$where_a1.') and ';
                }
			} else {
				$where_zus1='';
				if ($_SESSION['cfg_kunde']=='carlo_opel_dello' or $_SESSION['cfg_kunde']=='carlo_opel_duerkop' or $_SESSION['cfg_kunde']=='carlo_opel_haeusler') {
					$where_zus1=' or '.$sql_tabs['produktzuordnung']['dispotext'].' like '.$db->str('%'.str_replace('*', '%', $getfeld['ausstattung']).'%');
				}
				if ($cfg_kfzsuche_ausst_ohnenichtsuchen) {
					$where_a = '('.$sql_tabs['produktzuordnung']['kommentar'].' like '.$db->str('%'.str_replace('*', '%', $getfeld['ausstattung']).'%').$where_zus1.') and ';
					$where_a.= '('.$sql_tabs['produktzuordnung']['kommentar'].' not like '.$db->str('%ohne '.str_replace('*', '%', $getfeld['ausstattung']).'%').$where_zus1.') and ';
				} else {
	                $where_a = '('.$sql_tabs['produktzuordnung']['kommentar'].' like '.$db->str('%'.str_replace('*', '%', $getfeld['ausstattung']).'%').$where_zus1.') and ';
				}
                $val1 = $getfeld['ausstattung'];
            }
		}
        $where .= $where_a;
		
        if ($cfg_boersen_merkmale && !empty($getfeld['boersen_merkmale'])) {
            $prodids = array();
            $resbm = $db->select(
                $sql_tab['produktzuordnung_ausst_merk'],
                $sql_tabs['produktzuordnung_ausst_merk']['produktzuordnung_id'],
                $db->dbstrin($getfeld['boersen_merkmale'], $sql_tabs['produktzuordnung_ausst_merk']['beschreibung']),
                '', $sql_tabs['produktzuordnung_ausst_merk']['produktzuordnung_id'], false, 0, 0,
                'count(distinct '.$sql_tabs['produktzuordnung_ausst_merk']['beschreibung'].')='.count($getfeld['boersen_merkmale'])
            );
            while ($rowbm = $db->zeile($resbm)) {
                $prodids[$rowbm[0]] = $rowbm[0];
            }
            if (!empty($prodids)) {
                $where .= $db->dbzahlin($prodids, $sql_tabs['produktzuordnung']['produktzuordnung_id']).' and ';
            } else {
                $where .= $sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl(-1).' and ';
            }
            $slog.='B�rsenmerkmale='.$getfeld['ausstattung'].', ';
        }

		
		if (!$cfg_kfzsuche_ignoriere_lagerortrecht and $nur_lao!='') {
			if ($cfg_cross) {
				$nur_lao.=',0';
			}
			if (preg_match('/-100/', $nur_lao)) {
				$nur_lao=str_replace('-100', '0', $nur_lao);
				$where.='('.$sql_tabs['produktzuordnung']['mandant_id'].' in ('.$nur_lao.') or '.$sql_tabs['produktzuordnung']['mandant_id'].' is null) and ';
			} else {
				$where.=$sql_tabs['produktzuordnung']['mandant_id'].' in ('.$nur_lao.') and ';
			}
			$slog.='Lagerort='.$nur_lao.', ';
		}
		
		if ($cfg_kfzsuche_dd2020) {
			if (isset($getfeld['dd_mand'])) {
				@reset($getfeld['dd_mand']);
			}
			$wherelao='';
			while (list($key, $val)=@each($getfeld['dd_mand'])) {
				if ($val!='-1') {
					$xpld=explode('_', $val);
					$dd_laoid=$xpld[0];
					$wherelao.=$sql_tabs['produktzuordnung']['mandant_id'].'='.$db->dbzahl($dd_laoid).' or ';
					$slog.='Lagerort='.$dd_laoid.', ';
					if ($xpld[1]!='') {
						$wherelao.=$sql_tabs['produktzuordnung']['standort'].'='.$db->str($xpld[1]).' or ';
						$slog.='Standort='.$xpld[1].', ';
					}
				}
			}
			
			if ($wherelao!='') {
				$wherelao=substr($wherelao, 0, -4);
				$where.='('.$wherelao.') and ';
			}
		}
		

        if ($cfg_kfzsuche_laofilter_mehrere || $_SESSION['design_70']) {
			if (is_array($getfeld['mand'])) @reset($getfeld['mand']);
			$wherelao='';
			while (list($key, $val)=@each($getfeld['mand'])) {
				if ($val!='-1') {
					if ($cfg_kfzsuche_standardmandant) {
						$wherelao.=$sql_tabs['produktzuordnung']['produkt_id'].'='.$db->dbzahl($val).' or ';
					} else {
						$wherelao.=$sql_tabs['produktzuordnung']['mandant_id'].'='.$db->dbzahl($val).' or ';
					}
					$slog.='Lagerort='.$val.', ';
				}
			}
			if ($wherelao!='') {
				$wherelao=substr($wherelao, 0, -4);
				$where.='('.$wherelao.') and ';
			}
		} elseif ($getfeld['mand']!='' and $getfeld['mand']!='-1') {
			if ($cfg_kfzsuche_standardmandant) {
				$where.=$sql_tabs['produktzuordnung']['produkt_id'].'='.$db->dbzahl($getfeld['mand']).' and ';
				$slog.='Mandant='.$getfeld['mand'].', ';
			} else {
				$where.=$sql_tabs['produktzuordnung']['mandant_id'].'='.$db->dbzahl($getfeld['mand']).' and ';
				$slog.='Mandant='.$getfeld['mand'].', ';
			}
		}
		//$ausst_keys = array();
		$dvs_such_ausst = $where_a = '';
		while (list($key, $val)=@each($getfeld['ausst'])) {
			$slog.='Ausst='.$key.', ';
            //$ausst_keys[$key][] = $key;
			$where2='';
			if ($hat_dvs_aus) {
				if (isset($getfeld['ausstdvs'][$key]) and $getfeld['ausstdvs'][$key]!='') {
					$xpl3=explode(',', $getfeld['ausstdvs'][$key]);
					while (list($key3, $val3)=@each($xpl3)) {
						$where2.=$sql_tabs['produktzuordnung']['angebotstext_sprache2'].' like '.$db->str('%,'.$val3.',%').' or ';
					}
				}
			}
			while (list($key2, $val2)=@each($ausst_suchfelder[$key])) {
                //$ausst_keys[$key][] = $val2;
				if ($val2=='Allrad') {
					$val2=' Allrad';
				}
				if ($hat_dvs_aus) {
					
				} else {
					$where2.=$sql_tabs['produktzuordnung']['kommentar'].' like '.$db->str('%'.$val2.'%').' or ';
					if ($_SESSION['cfg_kunde']=='carlo_opel_dello' or $_SESSION['cfg_kunde']=='carlo_opel_duerkop' or $_SESSION['cfg_kunde']=='carlo_opel_haeusler') {
						$where2.=$sql_tabs['produktzuordnung']['dispotext'].' like '.$db->str('%'.$val2.'%').' or ';
					}
				}
			}
            if ($where2!='') {
                $where2='('.p4n_mb_string('substr',$where2, 0, -4).') and ';
            }
                       
            $where_a.=$where2;
			if ($cfg_dvs) {
				if ($hat_dvs_aus) {
					if (isset($getfeld['ausstdvs'][$key]) and $getfeld['ausstdvs'][$key]!='') {
						$dvs_such_ausst.=$getfeld['ausstdvs'][$key].',';
					}
				} elseif (isset($cfg_dvs_ausst2[$key])) {
					$dvs_such_ausst.=$cfg_dvs_ausst2[$key].',';
				} elseif ($key=='Allrad') {
					$suchfeld2['Antrieb']='3';
				}
			}
		}
        /*if ($cfg_boersen_merkmale && !empty($ausst_keys)) {
            $ok = false;
            $prodids = $where_merk =array();
            foreach ($ausst_keys as $ausst_key) {
                $prodids2 = array();
                $resbm = $db->select(
                    $sql_tab['produktzuordnung_ausst_merk'],
                    $sql_tabs['produktzuordnung_ausst_merk']['produktzuordnung_id'],
                    $db->dbstrin($ausst_key, $sql_tabs['produktzuordnung_ausst_merk']['beschreibung'])
                );
                while ($rowbm = $db->zeile($resbm)) {
                    $prodids2[$rowbm[0]] = $rowbm[0];
                }
                if ($ok) {
                    $prodids = array_intersect($prodids, $prodids2);
                } else {
                    $prodids = $prodids2;
                }
				$slog.='B�rsenmerkmale='.$ausst_key.', ';
                $ok = true;
            }
            if (!empty($prodids)) {
                $where_a = '('.p4n_mb_string('substr', $where_a, 0, -4).' or '.$db->dbstrin($prodids, $sql_tabs['produktzuordnung']['produktzuordnung_id']).') and ';
            }
        }*/
		$where .= $where_a;
		if ($dvs_such_ausst!='') {
			$dvs_such_ausst=trim(p4n_mb_string('substr',$dvs_such_ausst, 0, -1));
			$suchfeld2['Ausstattung']=$dvs_such_ausst;
		}
		
		if ($getfeld['slagerort']!='' and $getfeld['slagerort']!='-1') {
			$where.=$sql_tabs['produktzuordnung']['text_3'].'='.$db->str($getfeld['slagerort']).' and ';
			$slog.='Lagerort2='.$getfeld['slagerort'].', ';
			$suchfeld2['Lagerort']=$getfeld['slagerort'];
		}

		if ($getfeld['text_3']!='') {
			$where.=$sql_tabs['produktzuordnung']['text_3'].' like '.$db->str('%'.$getfeld['text_3'].'%').' and ';
			$slog.='Text 3='.$getfeld['text_3'].', ';
		}

		if (isset($getfeld['zls_id'])) {
			if ($getfeld['zls_id']!='') {
				$where.=$sql_tabs['produktzuordnung']['stammdaten_id'].'='.$db->dbzahl(2000000+intval($getfeld['zls_id'])).' and ';
				$slog.='ZLS='.strval(2000000+intval($getfeld['zls_id'])).', ';
			}
		}

		if ($getfeld['text_1neu']!='') {
			$where.=$sql_tabs['produktzuordnung']['text_1'].'='.$db->str($getfeld['text_1neu']).' and ';
			$slog.='Text 1='.$getfeld['text_1neu'].', ';
		}
		if ($getfeld['text_2neu']!='') {
			$where.=$sql_tabs['produktzuordnung']['text_2'].'='.$db->str($getfeld['text_2neu']).' and ';
			$slog.='Text 2='.$getfeld['text_2neu'].', ';
		}
		// Schl�sselnr.
		if ($getfeld['text_3']!='') {
			$where.=$sql_tabs['produktzuordnung']['text_3'].'='.$db->str($getfeld['text_3']).' and ';
			$slog.='Text 3='.$getfeld['text_3'].', ';
		}
		if ($getfeld['text_4']!='') {
			$where.=$sql_tabs['produktzuordnung']['text_4'].'='.$db->str($getfeld['text_4']).' and ';
			$slog.='Text 4='.$getfeld['text_4'].', ';
		}
		if ($getfeld['textex_1']!='') {
			$where.=$sql_tabs['produktzuordnung']['text_1'].' like '.$db->str('%'.$getfeld['textex_1'].'%').' and ';
			$slog.='Text 1='.$getfeld['textex_1'].', ';
		}
		if ($getfeld['textex_2']!='') {
			$where.=$sql_tabs['produktzuordnung']['text_2'].' like '.$db->str('%'.$getfeld['textex_2'].'%').' and ';
			$slog.='Text 2='.$getfeld['textex_2'].', ';
		}
		if ($getfeld['textex_3']!='') {
			$where.=$sql_tabs['produktzuordnung']['text_3'].' like '.$db->str('%'.$getfeld['textex_3'].'%').' and ';
			$slog.='Text 3='.$getfeld['textex_3'].', ';
		}
		if ($getfeld['textex_4']!='') {
			$where.=$sql_tabs['produktzuordnung']['text_4'].' like '.$db->str('%'.$getfeld['textex_4'].'%').' and ';
			$slog.='Text 4='.$getfeld['textex_4'].', ';
		}
		if ($cfg_kfzsuche_suchschadstoff) {
			if ($getfeld['schadstoffklasse']!='' and $getfeld['schadstoffklasse']!='-1') {
				$where.=$sql_tabs['produktzuordnung']['schadstoffklasse'].'='.$db->str($getfeld['schadstoffklasse']).' and ';
				$slog.='Schadstoffklasse='.$getfeld['schadstoffklasse'].', ';
			}
		}
		if ($getfeld['schluesselnr']!='') {
			$where.=$sql_tabs['produktzuordnung']['schluesselnr'].' like '.$db->str($getfeld['schluesselnr'].'%').' and ';
			$slog.='Schl�sselnr='.$getfeld['schluesselnr'].', ';
		}
		if ($getfeld['schwackecode']!='') {
			$where.=$sql_tabs['produktzuordnung']['zusatztext1'].' like '.$db->str($getfeld['schwackecode'].'%').' and ';
			$slog.='Schwackecode='.$getfeld['schwackecode'].', ';
		}
		if ($getfeld['zusatztext1']!='' and $getfeld['zusatztext1']!='-1') {
			$where.=$sql_tabs['produktzuordnung']['zusatztext1'].'='.$db->str($getfeld['zusatztext1']).' and ';
			$slog.='Zusatztext1='.$getfeld['zusatztext1'].', ';
		}
		if ($getfeld['rd_text1']!='' and $getfeld['rd_text1']!='-1') {
			if ($getfeld['rd_text1']=='CA*') {
				$where.=$sql_tabs['produktzuordnung']['text_1'].' like '.$db->str(str_replace('*', '%', $getfeld['rd_text1'])).' and ';
			} elseif ($getfeld['rd_text1']=='TW/takt. VFW/VFW') {
				$where.='('.$sql_tabs['produktzuordnung']['text_1'].'='.$db->str('TW').' or '.$sql_tabs['produktzuordnung']['text_1'].'='.$db->str('takt. VFW').' or '.$sql_tabs['produktzuordnung']['text_1'].'='.$db->str('VFW').') and ';
			} else {
				$where.=$sql_tabs['produktzuordnung']['text_1'].'='.$db->str($getfeld['rd_text1']).' and ';
			}
			$slog.='Text 1='.$getfeld['rd_text1'].', ';
		}
		
		if ($getfeld['fahrgestell']!='') {
			if ($cfg_kfzsuche_holland) {
				$where.='('.$sql_tabs['produktzuordnung']['fahrgestell'].' like '.$db->str('%'.str_replace('*', '%', $getfeld['fahrgestell']).'%').' or '.$sql_tabs['produktzuordnung']['kba_typ'].' like '.$db->str('%'.str_replace('*', '%', $getfeld['fahrgestell']).'%').') and ';
				$slog.='VIN='.$getfeld['fahrgestell'].', ';
			} else {
				if (strlen($getfeld['fahrgestell'])==17) {
					$where.=$sql_tabs['produktzuordnung']['fahrgestell'].'='.$db->str($getfeld['fahrgestell']).' and ';
					$slog.='VIN='.$getfeld['fahrgestell'].', ';
				} else {
					if (1==2 and $_SESSION['cfg_kunde']=='carlo_opel_haeusler') {
						$where.='('.$sql_tabs['produktzuordnung']['fahrgestell'].' like '.$db->str('%'.str_replace('*', '%', $getfeld['fahrgestell']).'%').' or '.$sql_tabs['produktzuordnung']['hersteller'].' like '.$db->str('%'.str_replace('*', '%', $getfeld['fahrgestell']).'%').') and ';
					} else {
					$where.=$sql_tabs['produktzuordnung']['fahrgestell'].' like '.$db->str('%'.str_replace('*', '%', $getfeld['fahrgestell']).'%').' and ';
					$slog.='VIN='.$getfeld['fahrgestell'].', ';
				}
			}
		}
		}
		
		// ZC1
		if ($getfeld['zusatzcode_1']!='' and $getfeld['zusatzcode_1']!='-1') {
			$where.=$sql_tabs['produktzuordnung']['zusatzcode_1'].'='.$db->str($getfeld['zusatzcode_1']).' and ';
			$slog.='Code 1='.$getfeld['zusatzcode_1'].', ';
		}
		// Komissionsnr.
		if ($getfeld['einheitencode']!='') {
			$where.=$sql_tabs['produktzuordnung']['einheitencode'].'='.$db->str($getfeld['einheitencode']).' and ';
			$slog.='Kommnr='.$getfeld['einheitencode'].', ';
		}
		// EDV-Nummer
		if ($getfeld['eva_typ']!='') {
			if ($cfg_kfzsuche_edvnummerlike) {
				$where.=$sql_tabs['produktzuordnung']['eva_typ'].' like '.$db->str('%'.$getfeld['eva_typ'].'%').' and ';
			} else {
				$where.=$sql_tabs['produktzuordnung']['eva_typ'].'='.$db->str($getfeld['eva_typ']).' and ';
			}
			$slog.='EDVNr='.$getfeld['eva_typ'].', ';
		}
		if ($getfeld['zusatztext2']!='') {
			$where.=$sql_tabs['produktzuordnung']['zusatztext2'].' like '.$db->str('%'.$getfeld['zusatztext2'].'%').' and ';
			$slog.='Zusatztext2='.$getfeld['zusatztext2'].', ';
		}
		if (isset($getfeld['zusatz_crm1']) and $getfeld['zusatz_crm1']!='') {
			$where.=$sql_tabs['produktzuordnung']['zusatz_crm1'].' like '.$db->str('%'.$getfeld['zusatz_crm1'].'%').' and ';
			$slog.='ZusatzCRM1='.$getfeld['zusatz_crm1'].', ';
		}
		if ($cfg_kfzsuche_mia_suchfeld) {
			if ($getfeld['mia_id']!='') {
			    $gesucht = $getfeld['mia_id'];
				if ($cfg_kfzsuche_mia_suchfeld_sternsuche) {
                    $gesucht = '%'.str_replace(array('*', '?'), array('%', '_'), $gesucht).'%';
                    $where_interface_ref = $sql_tabs['interface_ref']['extern_id'].' like '.$db->str($gesucht);
				} else {
                    $where_interface_ref = $sql_tabs['interface_ref']['extern_id'].'='.$db->str($gesucht);
				}
				// nur in den letzten suchen
				$temp_ir_list = array();
                $result_interface_ref = $db->select(
                    $sql_tab['interface_ref'],
                    'MAX('.$sql_tabs['interface_ref']['interface_ref_id'].')',
                    $sql_tabs['interface_ref']['table_name'].'='.$db->str('produktzuordnung').' and '.$where_interface_ref,
                    '',
                    $sql_tabs['interface_ref']['table_id']
                );
				while ($row_interface_ref = $db->zeile($result_interface_ref)) {
				    $temp_ir_list[] = $row_interface_ref[0];
                }
                if (!empty($temp_ir_list)) {
                    $where_interface_ref .= ' AND '.$db->dbzahlin($temp_ir_list, $sql_tabs['interface_ref']['interface_ref_id']);
                }
                // ->
                $list_interface_ref = array();
                $result_interface_ref = $db->select(
                    $sql_tab['interface_ref'],
                    $sql_tabs['interface_ref']['table_id'],
                    $sql_tabs['interface_ref']['table_name'].'='.$db->str('produktzuordnung').' and '.
                    $where_interface_ref
                );
                while ($row_interface_ref = $db->zeile($result_interface_ref)) {
                    $table_id = $row_interface_ref[0];
                    if ($table_id) {
                        $list_interface_ref[$table_id] = $table_id;
                    }
                }
                $where_interface_ref = '';
                if (!empty($list_interface_ref)) {
                    $where_interface_ref = ' or '.$db->dbzahlin($list_interface_ref, $sql_tabs['produktzuordnung']['produktzuordnung_id']);
                }
                if ($cfg_kfzsuche_mia_suchfeld_sternsuche) {
                    $where.='('.$sql_tabs['produktzuordnung']['zusatz_crm1'].' like '.$db->str($gesucht).' or '.$sql_tabs['produktzuordnung']['buchnummer'].' like '.$db->str($gesucht).$where_interface_ref.') and ';
                } else {
                    $where.='('.$sql_tabs['produktzuordnung']['zusatz_crm1'].'='.$db->str($gesucht).' or '.$sql_tabs['produktzuordnung']['buchnummer'].'='.$db->str($gesucht).$where_interface_ref.') and ';
                }
				$slog.='Mia='.$getfeld['mia_id'].', ';
			}
		}
		if (!empty($getfeld['aus_boersen'])) {
            $list_interface_ref = array();
            $result_interface_ref = $db->select(
                $sql_tab['interface_ref'],
                $sql_tabs['interface_ref']['table_id'],
                $sql_tabs['interface_ref']['table_name'].'='.$db->str('produktzuordnung').' and '.
                $db->dbstrin(Car_Import::getAllFormatList(true), $sql_tabs['interface_ref']['interface'])
            );
            while ($row_interface_ref = $db->zeile($result_interface_ref)) {
                $table_id = $row_interface_ref[0];
                if ($table_id) {
                    $list_interface_ref[$table_id] = $table_id;
                }
            }
            if (!empty($list_interface_ref)) {
                $where .= $db->dbzahlin($list_interface_ref, $sql_tabs['produktzuordnung']['produktzuordnung_id']).' and ';
            } else {
                $where .= $sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl(-1).' and ';
            }
        }
		// Ja/Nein
		if ($getfeld['janein_1a']!='') {
			if ($getfeld['janein_1']!='-1') {
				$where.=$sql_tabs['produktzuordnung']['janein_1'].'='.$db->dblogic($getfeld['janein_1']).' and ';
				$slog.='JaNein='.$getfeld['janein_1'].', ';
			}
		}
		// Buchnummer
		if ($getfeld['buchnummer']!='') {
			if ($cfg_carlo_kfzimport_filialbuchnummer) {
				if ($cfg_kfzsuche_suchebuchnummer_alles) {
					$where.='('.$sql_tabs['produktzuordnung']['zusatztext2'].' like '.$db->str('%'.$getfeld['buchnummer'].'%').' or '.$sql_tabs['produktzuordnung']['buchnummer'].' like '.$db->str('%'.$getfeld['buchnummer'].'%').') and ';
				} else {
					$where.='('.$sql_tabs['produktzuordnung']['zusatztext2'].'='.$db->str($getfeld['buchnummer']).' or '.$sql_tabs['produktzuordnung']['buchnummer'].'='.$db->str($getfeld['buchnummer']).') and ';
				}
			} else {
				if ($cfg_kfzsuche_suchebuchnummer_alles) {
					$where.=$sql_tabs['produktzuordnung']['buchnummer'].' like '.$db->str('%'.$getfeld['buchnummer'].'%').' and ';
				} else {
					$where.=$sql_tabs['produktzuordnung']['buchnummer'].'='.$db->str($getfeld['buchnummer']).' and ';
				}
			}
			$slog.='Buchnummer='.$getfeld['buchnummer'].', ';
		}
		if ($getfeld['panummer']!='') {
			$alle_pa_ids='';
			$res8=$db->select(
				$sql_tab['produktzuordnung_dispo'],
				$sql_tabs['produktzuordnung_dispo']['produktzuordnung_id'],
				$sql_tabs['produktzuordnung_dispo']['pa_nummer'].' like '.$db->str($getfeld['panummer'].'%')
			);
			while ($row8=$db->zeile($res8)) {
				$alle_pa_ids.=$row8[0].',';
			}
			if ($alle_pa_ids!='') {
				$alle_pa_ids=substr($alle_pa_ids, 0, -1);
				$where.=$sql_tabs['produktzuordnung']['produktzuordnung_id'].' in ('.$alle_pa_ids.') and ';
			} else {
				$where.=$sql_tabs['produktzuordnung']['produktzuordnung_id'].'=-999 and ';
			}
			$slog.='PANummer='.$getfeld['panummer'].', ';
		}
		if ($getfeld['belegnummer']!='') {
			$alle_pa_ids='';
			$res8=$db->select(
				$sql_tab['produktzuordnung_dispo'],
				$sql_tabs['produktzuordnung_dispo']['produktzuordnung_id'],
				$sql_tabs['produktzuordnung_dispo']['belegnummer'].' like '.$db->str('%'.$getfeld['belegnummer'].'%')
			);
			while ($row8=$db->zeile($res8)) {
				if (intval($row8[0])>0) {
					$alle_pa_ids.=$row8[0].',';
				}
			}
			if ($alle_pa_ids!='') {
				$alle_pa_ids=substr($alle_pa_ids, 0, -1);
				$where.=$sql_tabs['produktzuordnung']['produktzuordnung_id'].' in ('.$alle_pa_ids.') and ';
			} else {
				$where.=$sql_tabs['produktzuordnung']['hersteller'].' like '.$db->str('%'.$getfeld['belegnummer'].'%').' and ';
			}
			$slog.='Belegnummer='.$getfeld['belegnummer'].', ';
		}
		if ($getfeld['hersteller']!='') {
			$where.=$sql_tabs['produktzuordnung']['hersteller'].' like '.$db->str('%'.$getfeld['hersteller'].'%').' and ';
			$slog.='Nummer='.$getfeld['hersteller'].', ';
		}
		
		if (isset($cfg_kfzsuche_zfsuche)) {
			if ($cfg_kfzsuche_zfsuche!='') {
				@reset($getfeld);
				while (list($key1, $val1)=@each($getfeld)) {
					if (substr($key1, 0, 3)=='zf_') {
						$zfid1=substr($key1, 3);
						if ($val1!='' and $val1!='-1') {
							if (isset($getfeld['zfistsel_'.$zfid1])) {
								$where.=$sql_tab['produktzuordnung'].'.zf_'.$zfid1.'='.$db->str($getfeld[$key1]).' and ';
							} else {
								$where.=$sql_tab['produktzuordnung'].'.zf_'.$zfid1.' like '.$db->str('%'.$getfeld[$key1].'%').' and ';
							}
							$slog.='ZF='.$getfeld[$key1].', ';
						}
					}
				}
			}
		}
		if ($cfg_kfzsuche_suchezusatz1) {
			if ($getfeld['zusatz1']!='') {
				$where.=$sql_tabs['produktzuordnung']['zusatz1'].' like '.$db->str('%'.$getfeld['zusatz1'].'%').' and ';
				$slog.='Zusatz1='.$getfeld['zusatz1'].', ';
			}
		}
		
		// Buchnummer
		if ($getfeld['notizen']!='') {
			$where.=$sql_tabs['produktzuordnung']['notizen'].' like '.$db->str('%'.$getfeld['notizen'].'%').' and ';
			$slog.='Notizen='.$getfeld['notizen'].', ';
		}
		// H�ndlerstatus
		if ($getfeld['haendlerstatus']!='' and $getfeld['haendlerstatus']!='-1') {
			$where.=$sql_tabs['produktzuordnung']['haendlerstatus'].'='.$db->str($getfeld['haendlerstatus']).' and ';
			$slog.='HST='.$getfeld['haendlerstatus'].', ';
		}
		// Produktbuchungsgruppe
		if ($getfeld['produktbuchungsgruppe']!='' and $getfeld['produktbuchungsgruppe']!='-1') {
            if ($_SESSION['cfg_kunde']=='crm_vw_ostmann') {
                $where.='('.$sql_tabs['produktzuordnung']['produktbuchungsgruppe'].'='.$db->str($getfeld['produktbuchungsgruppe']).' or '.$sql_tabs['produktzuordnung']['typ_modell'].' like '.$db->str(str_replace('*', '%', $getfeld['produktbuchungsgruppe']).'%').' or '.$sql_tabs['produktzuordnung']['typ'].' like '.$db->str(str_replace('*', '%', $getfeld['produktbuchungsgruppe']).'%').') and ';
            } else {
    			$where.=$sql_tabs['produktzuordnung']['produktbuchungsgruppe'].'='.$db->str($getfeld['produktbuchungsgruppe']).' and ';
            }
			$slog.='PBG='.$getfeld['produktbuchungsgruppe'].', ';
		}
		// zusatz_text_8
		if ($getfeld['zusatz_text_8']!='' and $getfeld['zusatz_text_8']!='-1') {
			$where.=$sql_tabs['produktzuordnung']['zusatz_text_8'].' like '.$db->str($getfeld['zusatz_text_8'].'%').' and ';
			$slog.='Z8='.$getfeld['zusatz_text_8'].', ';
		}
		if ($getfeld['zusatzcrm1']!='') {
			$where.=$sql_tabs['produktzuordnung']['zusatz_crm1'].' like '.$db->str('%'.str_replace('*', '%', $getfeld['zusatzcrm1']).'%').' and ';
			$slog.='Z1='.$getfeld['zusatzcrm1'].', ';
		}
		// Lieferh�ndler:
		if (isset($getfeld['lieferhaendler'])) {
			if ($getfeld['lieferhaendler']=='-20') {
				
			} elseif ($getfeld['lieferhaendler']=='-10') {
				$where.='('.$sql_tabs['produktzuordnung']['zusatz_crm1'].'='.$db->str('DE0621').' or '.$sql_tabs['produktzuordnung']['zusatz_crm1'].'='.$db->str('').') and ';
				$slog.='LH=DE0621, ';
			} else {
				$where.=$sql_tabs['produktzuordnung']['zusatz_crm1'].'='.$db->str($getfeld['lieferhaendler']).' and ';
				$slog.='LH='.$getfeld['lieferhaendler'].', ';
			}
		}
		
		if (intval($getfeld['einkaeufer'])>0) {
			$where.=$sql_tabs['produktzuordnung']['einkaeufer'].'='.$db->str($getfeld['einkaeufer']).' and ';
			$slog.='EK='.$getfeld['einkaeufer'].', ';
		}
		if (intval($getfeld['verkaeufer'])>0) {
			$slog.='VK='.$getfeld['verkaeufer'].', ';
			$verk_1='';
			$res5=$db->select(
				$sql_tab['korrespondenz'],
				$sql_tabs['korrespondenz']['produktzuordnung_id'],
				$sql_tabs['korrespondenz']['kategorie'].'='.$db->str(_KAUFVERTRAG_).' and '.
					$sql_tabs['korrespondenz']['betreuer_id'].'='.$db->dbzahl($getfeld['verkaeufer'])
			);
			while ($row5=$db->zeile($res5)) {
				if (intval($row5[0])>0) {
					$verk_1.=$row5[0].',';
				}
			}
			if ($verk_1!='') {
				$where.='('.$sql_tabs['produktzuordnung']['produktzuordnung_id'].' in ('.p4n_mb_string('substr',$verk_1, 0, -1).') or '.
					$sql_tabs['produktzuordnung']['benutzer_id'].'='.$db->dbzahl($getfeld['verkaeufer']).') and ';
			} else {
				$where.=$sql_tabs['produktzuordnung']['benutzer_id'].'='.$db->dbzahl($getfeld['verkaeufer']).' and ';
			}
		}
		if (intval($getfeld['besteuerung'])>0) {
			if ($getfeld['besteuerung']=='1') {
				$where.=$sql_tabs['produktzuordnung']['differenzbesteuerung'].'='.$db->dblogic(true).' and ';
				$slog.='Diff=ja, ';
			}
			if ($getfeld['besteuerung']=='2') {
				$where.=$sql_tabs['produktzuordnung']['differenzbesteuerung'].'='.$db->dblogic(false).' and ';
				$slog.='Diff=nein, ';
			}
		}

		if ($getfeld['kennzeichen']!='') {
			$slog.='Kennzeichen='.$getfeld['kennzeichen'].', ';
			if ($cfg_kfzsuche_holland) {
				$where.='('.$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($getfeld['kennzeichen'], 0, 2).'%'.substr($getfeld['kennzeichen'], 2, 2).'%'.substr($getfeld['kennzeichen'], 4, 2).'%').' or '.$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($getfeld['kennzeichen'], 0, 2).'%'.substr($getfeld['kennzeichen'], 2, 3).'%'.substr($getfeld['kennzeichen'], 5, 1).'%').' or '.$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(str_replace('*', '%', $getfeld['kennzeichen']).'%').' or REPLACE('.$sql_tabs['produktzuordnung']['kennzeichen'].', '.$db->str('-').', '.$db->str('').') like '.$db->str(str_replace('*', '%', $getfeld['kennzeichen']).'%').') and ';
			} else {
				
				if ($cfg_kfzsuche_kennzeichen_wie_startportal) {
					$zus_kzs='';
					$kfz_where='';
					if ($cfg_kfzsuche_holland) {
						$zus_kzs.='REPLACE('.$sql_tabs['produktzuordnung']['kennzeichen'].', '.$db->str('-').', '.$db->str('').') like '.$db->str($getfeld['kennzeichen'].'%').' or ';
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($getfeld['kennzeichen'], 0, 2).'%'.substr($getfeld['kennzeichen'], 2, 2).'%'.substr($getfeld['kennzeichen'], 4, 2).'%').' or ';
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($getfeld['kennzeichen'], 0, 2).'%'.substr($getfeld['kennzeichen'], 2, 3).'%'.substr($getfeld['kennzeichen'], 5, 1).'%').' or ';
					}
					if ($cfg_suche_kennzeichenmehr) {
						$kfzsw=str_replace(array('-', ' '), '', $getfeld['kennzeichen']);
						if (preg_match('/([\s\w\-]+)(\d+)$/Uis', $kfzsw, $ma)) {
							$kbuchst=$ma[1];
							$kzahlen=$ma[2];
							if ($kbuchst!='' and $kzahlen!='') {
								if (strlen($kbuchst)==1) {
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str($kbuchst.'_'.$kzahlen.'%').' or ';
								} elseif (strlen($kbuchst)==2) {
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'_'.substr($kbuchst, 1, 1).'_'.$kzahlen.'%').' or ';
								} elseif (strlen($kbuchst)==3) {
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'_'.substr($kbuchst, 1, 2).'_'.$kzahlen.'%').' or ';
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 2).'_'.substr($kbuchst, 2, 1).'_'.$kzahlen.'%').' or ';
								} elseif (strlen($kbuchst)==4) {
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'_'.substr($kbuchst, 1, 3).'_'.$kzahlen.'%').' or ';
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 2).'_'.substr($kbuchst, 2, 2).'_'.$kzahlen.'%').' or ';
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 3).'_'.substr($kbuchst, 3, 1).'_'.$kzahlen.'%').' or ';
								} elseif (strlen($kbuchst)==5) {
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 3).'_'.substr($kbuchst, 3, 2).'_'.$kzahlen.'%').' or ';
								}
								if (strlen($kbuchst)==1) {
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str($kbuchst.''.$kzahlen.'%').' or ';
								} elseif (strlen($kbuchst)==2) {
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'_'.substr($kbuchst, 1, 1).''.$kzahlen.'%').' or ';
								} elseif (strlen($kbuchst)==3) {
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'_'.substr($kbuchst, 1, 2).''.$kzahlen.'%').' or ';
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 2).'_'.substr($kbuchst, 2, 1).''.$kzahlen.'%').' or ';
								} elseif (strlen($kbuchst)==4) {
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'_'.substr($kbuchst, 1, 3).''.$kzahlen.'%').' or ';
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 2).'_'.substr($kbuchst, 2, 2).''.$kzahlen.'%').' or ';
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 3).'_'.substr($kbuchst, 3, 1).''.$kzahlen.'%').' or ';
								} elseif (strlen($kbuchst)==5) {
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 3).'_'.substr($kbuchst, 3, 2).''.$kzahlen.'%').' or ';
								}
							}
						} elseif (preg_match('/([\s\w\-]+)$/Uis', $kfzsw, $ma)) {
							$kbuchst=$ma[1];
							if ($kbuchst!='') {
								if (strlen($kbuchst)==4) {
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'_'.substr($kbuchst, 1, 3).'%').' or ';
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 2).'_'.substr($kbuchst, 2, 2).'%').' or ';
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 3).'_'.substr($kbuchst, 3, 1).'%').' or ';
								} elseif (strlen($kbuchst)==5) {
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 3).'_'.substr($kbuchst, 3, 2).'%').' or ';
								}
							}
						}
						if ($cfg_kfzsuche_austria) {
							if (preg_match('/([\s\w\-]+)(\d+)([\D]+)$/Uis', $kfzsw, $ma)) {
								$kbuchst=$ma[1];
								$kzahlen=$ma[2];
								$kbuchst2=$ma[3];
								if ($kbuchst!='' and $kzahlen!='') {
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str($kbuchst.'%'.$kzahlen.'%'.$kbuchst2.'%').' or ';
								}
							} elseif (preg_match('/([\s\w\-]+)(\d+)$/Uis', $kfzsw, $ma)) {
								$kbuchst=$ma[1];
								$kzahlen=$ma[2];
								if ($kbuchst!='' and $kzahlen!='') {
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'%'.substr($kbuchst, 1).'%'.$kzahlen.'%').' or ';
									$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 2).'%'.substr($kbuchst, 2).'%'.$kzahlen.'%').' or ';
								}
							}
						}
					}
					if ($getfeld['kennzeichen']!='') {
						$pkz2=$getfeld['kennzeichen'];
						$pkz2=str_replace(' ', '%', $pkz2);
						$pkz2=str_replace('-', '%', $pkz2);
						$kfz_where.='('.$zus_kzs.$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str($getfeld['kennzeichen'].'%').($pkz2!=$getfeld['kennzeichen']?' or '.$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str($pkz2.'%'):'').') and ';
		                if ($cfg_kennzeichen_telefon_schneller || $cfg_kennzeichen_schneller) {
        		            $kzneu=preg_replace('/\W/', '', $getfeld['kennzeichen']);
                		    if (substr($getfeld['kennzeichen'], -1)=='%' or substr($getfeld['kennzeichen'], -1)=='*') {
		                        $kzneu.='%';
        		            }
                		    $kfz_where='('.$sql_tabs['produktzuordnung']['kennzeichen_text'].' like '.$db->str(p4n_mb_string('str_replace', '*', '%', $kzneu)).') and ';
		                }
					}
					$where.=$kfz_where;
				} else {
					$where.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(str_replace('*', '%', $getfeld['kennzeichen']).'%').' and ';
				}
			}
		}
		if ($cfg_kfzsuche_vorbesitzer and $getfeld['anzahl_vorbesitzer']!='') {
			$where.=$sql_tabs['produktzuordnung']['anzahl_vorbesitzer'].'='.$db->dbzahl($getfeld['anzahl_vorbesitzer']).' and ';
			$slog.='Vorbesitzer='.$getfeld['anzahl_vorbesitzer'].', ';
		}
		
		if ($cfg_kfzsuche_verkaufte_nuradmin) {
			if ($_SESSION['user_gruppe']<2) {
				$where.=$sql_tabs['produktzuordnung']['kaufvertrag_kunde'].'=0'.' and '.
					$sql_tabs['produktzuordnung']['zusatzcode_1'].'!='.$db->str('Paket').' and ';
					$sql_tabs['produktzuordnung']['zusatzcode_1'].'!='.$db->str('verkauft').' and ';
				$slog.='verkaufte=nein, ';
			}
		}
		
		if (isset($getfeld['nurpfkfz'])) {
			$where.=$sql_tabs['produktzuordnung']['eva'].'='.$db->dblogic(true).' and ';
			$slog.='nurPF=ja, ';
		}
		
		if ($cfg_carlo_appserver_activity and !isset($getfeld['nurimfuhrpark'])) {
			if (isset($getfeld['auchreservierte'])) {
			//	$where.=$sql_tabs['produktzuordnung']['reservierung'].'='.$db->dblogic(true).' and ';
			} else {
				$where.=$sql_tabs['produktzuordnung']['reservierung'].'='.$db->dblogic(false).' and ';
				$slog.='nurRes=nein, ';
			}
		}
		if (isset($getfeld['nurimfuhrpark'])) {
			$where.=$sql_tabs['produktzuordnung']['janein_2'].'='.$db->dblogic(true).' and ';
			$slog.='janein2=ja, ';
		}
		if (isset($getfeld['reservierte'])) {
			$where.=$sql_tabs['produktzuordnung']['reservierung'].'>'.$db->dbzahl(0).' and ';
			$slog.='Res=ja, ';
		}
		
		if (isset($getfeld['nurverfuegbare'])) {
			$slog.='Verf�gbare=ja, ';
			$res3=$db->select(
				$sql_tab['kalender_zusatz'],
				$sql_tabs['kalender_zusatz']['kalender_zusatz_id'],
				$sql_tabs['kalender_zusatz']['bezeichnung'].'='.$db->str(_PROBEFAHRT_)
			);
			$alle_pf_ids='';
			if ($row3=$db->zeile($res3)) {
				$res3=$db->select(
					$sql_tab['kalender'],
					array(
						$sql_tabs['kalender']['produkt_id'],
						$sql_tabs['kalender']['beginn'],
						$sql_tabs['kalender']['ende']
					),
					$sql_tabs['kalender']['kalender_zusatz_id'].'='.$db->dbzahl($row3[0]).' and '.
					$sql_tabs['kalender']['produkt_id'].'>0 and ('.
						'('.$sql_tabs['kalender']['beginn'].'>='.$db->dbtimestamp(time()-60*60).' and '.
							$sql_tabs['kalender']['beginn'].'<='.$db->dbtimestamp(time()+60*60).') or '.
						'('.$sql_tabs['kalender']['beginn'].'<'.$db->dbtimestamp(time()-60*60).' and '.
							$sql_tabs['kalender']['ende'].'='.$db->str('0000-00-00 00:00:00').') or '.
						'('.$sql_tabs['kalender']['ende'].'>='.$db->dbtimestamp(time()-60*60).' and '.
							$sql_tabs['kalender']['ende'].'<='.$db->dbtimestamp(time()+60*60).') or '.
						'('.$sql_tabs['kalender']['beginn'].'<'.$db->dbtimestamp(time()-60*60).' and '.
							$sql_tabs['kalender']['ende'].'>'.$db->dbtimestamp(time()+60*60).')'.
						')'
				);
				while ($row3=$db->zeile($res3)) {
					$alle_pf_ids.=$row3[0].',';
				}
			}
			if ($alle_pf_ids!='') {
				$where.=$sql_tabs['produktzuordnung']['produktzuordnung_id'].' not in ('.p4n_mb_string('substr',$alle_pf_ids, 0, -1).') and ';
			}
		} elseif (isset($getfeld['verkauftenicht'])) {
			if ($cfg_kfzsuche_trigger_verkauftenicht) {
				$where.=$sql_tabs['produktzuordnung']['kaufvertrag'].' in (0,null) and ';
			} else {
				$where.=$sql_tabs['produktzuordnung']['vkinfo_carlo'].'='.$db->str('').' and '.$sql_tabs['produktzuordnung']['kaufvertrag_kunde'].'=0'.' and ';
			}
			if ($cfg_kfzsuche_verkaufthaken_status777) {
				$where.=$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'!='.$db->dbzahl(777).' and ';
			}
			$slog.='verkaufte=nein, ';
		}
		
		if ($cfg_kfz_pf_aktiv and !isset($getfeld['pfinaktiv'])) {
			$where.=$sql_tabs['produktzuordnung']['modelyear'].'!='.$db->str('inaktiv').' and ';
			$slog.='aktiv=ja, ';
		}
		if ($cfg_kfzsuche_intfahrer_pf and isset($getfeld['ohneintfahrer'])) {
			$where.=$sql_tabs['produktzuordnung']['interner_fahrer'].'='.$db->dbzahl(0).' and ';
			$slog.='intfahrer=nein, ';
		}
		if (!empty($getfeld['anzahl_sitze'])) {
			$where.=$sql_tabs['produktzuordnung']['anzahl_sitze'].'='.$db->dbzahl($getfeld['anzahl_sitze']).' and ';
			$slog.='anzahl_sitze='.$getfeld['anzahl_sitze'].', ';
        }
		if ($cfg_kfzsuche_anzahlsitze_vonbis and intval($getfeld['anzahl_sitze_von'])>0) {
			$where.=$sql_tabs['produktzuordnung']['anzahl_sitze'].'>='.$db->dbzahl($getfeld['anzahl_sitze_von']).' and ';
			$slog.='anzahl_sitze von '.$getfeld['anzahl_sitze_von'].', ';
        }
		if ($cfg_kfzsuche_anzahlsitze_vonbis and intval($getfeld['anzahl_sitze_bis'])>0) {
			$where.=$sql_tabs['produktzuordnung']['anzahl_sitze'].'<='.$db->dbzahl($getfeld['anzahl_sitze_bis']).' and ';
			$slog.='anzahl_sitze bis '.$getfeld['anzahl_sitze_bis'].', ';
        }
		if ($cfg_kfzsuche_suche_standtage and intval($getfeld['standtage_von'])>0) {
			$where.=$sql_tabs['produktzuordnung']['standtage'].'>='.$db->dbzahl($getfeld['standtage_von']).' and ';
			$slog.='standtage von '.$getfeld['standtage_von'].', ';
        }
		if ($cfg_kfzsuche_suche_standtage and intval($getfeld['standtage_bis'])>0) {
			$where.=$sql_tabs['produktzuordnung']['standtage'].'<='.$db->dbzahl($getfeld['standtage_bis']).' and ';
			$slog.='standtage bis '.$getfeld['standtage_bis'].', ';
        }
		if ($cfg_kfzsuche_suche_minderwertmanuell and intval($getfeld['minderwert_von'])>0) {
			$where.=$sql_tabs['produktzuordnung']['mindest_vkpreis'].'>='.$db->dbzahl($getfeld['minderwert_von']).' and ';
			$slog.='Minderwert von '.$getfeld['minderwert_von'].', ';
        }
		if ($cfg_kfzsuche_suche_minderwertmanuell and intval($getfeld['minderwert_bis'])>0) {
			$where.=$sql_tabs['produktzuordnung']['mindest_vkpreis'].'<='.$db->dbzahl($getfeld['minderwert_bis']).' and ';
			$slog.='Minderwert bis '.$getfeld['minderwert_bis'].', ';
        }
		if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent' and $getfeld['abpreisungsdatum_von']!='') {
			$where.=$sql_tabs['produktzuordnung']['rsa_exp'].'>='.$db->dbdate($getfeld['abpreisungsdatum_von']).' and ';
			$where.=$sql_tabs['produktzuordnung']['runn_time'].'>0 and ';
			$slog.='abpreisungsdatum_von '.$getfeld['abpreisungsdatum_von'].', ';
        }
		if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent' and $getfeld['abpreisungsdatum_bis']!='') {
			$where.=$sql_tabs['produktzuordnung']['rsa_exp'].'<='.$db->dbdate($getfeld['abpreisungsdatum_bis']).' and ';
			$where.=$sql_tabs['produktzuordnung']['runn_time'].'>0 and ';
			$slog.='abpreisungsdatum_bis '.$getfeld['abpreisungsdatum_bis'].', ';
        }
		if ($where=='') {
			$where='1=2';
		} else {
			$where=p4n_mb_string('substr',$where, 0, -5);
		}

		$sorto='';
		$sorto2='';
		if (isset($getfeld['sort']) and $getfeld['sort']=='10') {
			$sorto=$sql_tabs['produktzuordnung']['standtage'].' '.$getfeld['order'];
			$sorto2=$getfeld['sort'];
		} elseif (isset($getfeld['sort'])) {
			$sorto=$getfeld['sort'].' '.$getfeld['order'];
			$_GET['sort']=$getfeld['sort'];
			$_GET['order']=$getfeld['order'];
		} else {
			if ($cfg_kfzsuche_auszpreis) {
				$sorto=$sql_tabs['produktzuordnung']['auszeichnungspreis'];
				$_GET['sort']=$sql_tabs['produktzuordnung']['auszeichnungspreis'];
			} else {
				$sorto=$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'];
				$_GET['sort']=$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'];
				if ($kfzs_debug or $db->treiber=='mysql') {
					$sorto='FLOOR('.$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'].')';
					$_GET['sort']='FLOOR('.$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'].')';
				}
			}
			$_GET['order']='asc';
			if ($cfg_kfzsuche_italien or $cfg_ws_avag_kroatien or $cfg_kfzsuche_sort_standtage) {
				$_GET['sort']='10';
				$getfeld['sort']='10';
				$sorto=$sql_tabs['produktzuordnung']['standtage'].' desc';
				$sorto2=$getfeld['sort'];
				$_GET['order']='desc';
				$getfeld['order']='desc';
			}
			if ($cfg_kfzsuche_sort_tireprot) {
				$sorto=$sql_tabs['produktzuordnung']['tire_prot'];
				$_GET['sort']=$sql_tabs['produktzuordnung']['tire_prot'];
				$sorto='FLOOR('.$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'].')';
				$_GET['sort']=$sorto;
			}
			if ($cfg_kfzsuche_sort_modell) {
				$_GET['order']='asc';
				$getfeld['order']='asc';
				$_GET['sort']='crm_produktzuordnung.typ_modell';
				$getfeld['sort']='crm_produktzuordnung.typ_modell';
				$sorto=$sql_tabs['produktzuordnung']['typ_modell'];
				$sorto2=$getfeld['sort'];
			}
			if ($cfg_kfzsuche_sortezundst or $_SESSION['cfg_kunde']=='carlo_opel_dello' or $_SESSION['cfg_kunde']=='carlo_opel_duerkop') {
				$sorto=$sql_tabs['produktzuordnung']['datum_ez'].' asc, '.$sql_tabs['produktzuordnung']['standtage'].' desc';
				$_GET['sort']=$sql_tabs['produktzuordnung']['datum_ez'].' asc, '.$sql_tabs['produktzuordnung']['standtage'].' desc';
				
				$sorto='CASE WHEN '.$sql_tabs['produktzuordnung']['datum_ez'].' is null or '.$sql_tabs['produktzuordnung']['datum_ez'].'='.$db->str('0000-00-00').' or '.$sql_tabs['produktzuordnung']['datum_ez'].'='.$db->str('1970-01-01').' THEN 2 ELSE 1 END, '.$sql_tabs['produktzuordnung']['datum_ez'].', '.$sql_tabs['produktzuordnung']['standtage'].' desc';
				$_GET['sort']='CASE WHEN '.$sql_tabs['produktzuordnung']['datum_ez'].' is null or '.$sql_tabs['produktzuordnung']['datum_ez'].'='.$db->str('0000-00-00').' or '.$sql_tabs['produktzuordnung']['datum_ez'].'='.$db->str('1970-01-01').' THEN 2 ELSE 1 END, '.$sql_tabs['produktzuordnung']['datum_ez'].', '.$sql_tabs['produktzuordnung']['standtage'].' desc';
				$sorto2='';
			}
		}

		if ($cfg_kfzsuche_pfbalken) {
			$je=time();
			if (isset($getfeld['pfkal_ts'])) {
				$je=intval($getfeld['pfkal_ts']);
			}
			if (is_array($cfg_kalender_farben_abstufung)) {
				$colors=$cfg_kalender_farben_abstufung;
			} else {
				$colors=array('#E0E0D0', '#6AEC76', '#FFFF00', '#C0C000', '#FF00FF', '#FF0000');
			}
			if ($cfg_kfzsuche_pfbalken_sofeiertag_rot) {
				$vond1=adodb_mktime(0,0,0,adodb_date('m', $je-0*24*60*60), adodb_date('d', $je-0*24*60*60), adodb_date('Y', $je-0*24*60*60));
				$bisd1=adodb_mktime(23,59,59,adodb_date('m', $je+60*24*60*60), adodb_date('d', $je+60*24*60*60), adodb_date('Y', $je+60*24*60*60));
				unset($alle_ben_feiertage);
                feiertage_jebenutzer($_SESSION['user_id'], $vond1, $bisd1);
                $key1=$_SESSION['user_id'];
	       		for ($t2=$vond1; $t2<=$bisd1; $t2+=24*60*60) {
					$datum_gesamt=adodb_date('d.m.Y', $t2);
		            $zusatzinfo[$key1][$datum_gesamt] = array('urlaub' => false, 'feiertag' => false, 'sa' => false, 'so' => false);
			        if (isset($alle_ben_urlaub[$key1][$datum_gesamt]) && $alle_ben_urlaub[$key1][$datum_gesamt] > 0) {
    	    	        $zusatzinfo[$key1][$datum_gesamt]['urlaub']=true;
		            }
					if (isset($alle_ben_feiertage[$key1][$datum_gesamt])) {
                        $zusatzinfo[$key1][$datum_gesamt]['feiertag']=true;
					}
		            if (adodb_date('w', $t2)==6) {
		                $zusatzinfo[$key1][$datum_gesamt]['sa']=true;
		            }
       			    if (adodb_date('w', $t2)==0) {
		                $zusatzinfo[$key1][$datum_gesamt]['so']=true;
		            }
				}
			}
//			echo '<pre>'; print_r($zusatzinfo);
			$res4=$db->select(
				$sql_tab['kalender_zusatz'],
				$sql_tabs['kalender_zusatz']['kalender_zusatz_id'],
				$sql_tabs['kalender_zusatz']['bezeichnung'].'='.$db->str(_PROBEFAHRT_)
			);
			if ($row4=$db->zeile($res4)) {
				$pf_t=array();
				$datum1=$db->dbtimestamp(adodb_mktime(0,0,0,adodb_date('m', $je), adodb_date('d', $je), adodb_date('Y', $je)));
				$datum2=$db->dbtimestamp(adodb_mktime(23,59,59,adodb_date('m', $je+60*24*60*60), adodb_date('d', $je+60*24*60*60), adodb_date('Y', $je+60*24*60*60)));
				$res5=$db->select(
					$sql_tab['kalender'],
					array(
						$sql_tabs['kalender']['kalender_id'],
						$sql_tabs['kalender']['produkt_id'],
						$sql_tabs['kalender']['beginn'],
						$sql_tabs['kalender']['ende'],
						$sql_tabs['kalender']['stammdaten_id'],
						$sql_tabs['kalender']['betreff'],	// 5
						$sql_tabs['kalender']['betreuer'],
						$sql_tabs['kalender']['zusatztext'],
						$sql_tabs['kalender']['beschreibung'],
						$sql_tabs['kalender']['art'],
						$sql_tabs['kalender']['user_id']	// 10
					),
					$sql_tabs['kalender']['kalender_zusatz_id'].'='.$db->dbzahl($row4[0]).' and ('.
						$sql_tabs['kalender']['beginn'].' between '.$datum1.' and '.$datum2.' or '.
						$sql_tabs['kalender']['ende'].' between '.$datum1.' and '.$datum2.
						' or ('.$sql_tabs['kalender']['beginn'].'<'.$datum1.' and '.$sql_tabs['kalender']['ende'].'>'.$datum2.')'.
						')',
					$sql_tabs['kalender']['beginn']
				);
//echo $db->last_sql.'<br><br>';
				$sind_inaktive=array();
				if ($cfg_kfz_pf_aktiv) {
					$pfpids_in='';
					while ($row5=$db->zeile($res5)) {
						if (intval($row5[1])<=0) {
							if ($row5[7]!='') {
								$row5[1]=$row5[7];
							} else {
								continue;
							}
						}
						if (intval($row5[1])>0) {
							$pfpids_in.=$row5[1].',';
						}
					}
					if ($pfpids_in!='') {
						$pfpids_in=substr($pfpids_in, 0, -1);
						$res7=$db->select(
							$sql_tab['produktzuordnung'],
							array(
								$sql_tabs['produktzuordnung']['produktzuordnung_id'],
								$sql_tabs['produktzuordnung']['modelyear']
							),
							$sql_tabs['produktzuordnung']['produktzuordnung_id'].' in ('.$pfpids_in.')'
						);
						while ($row7=$db->zeile($res7)) {
							if ($row7[1]=='inaktiv') {
								$sind_inaktive[$row7[0]]=1;
							}
						}
					}
					$res5=$db->select(
					$sql_tab['kalender'],
					array(
						$sql_tabs['kalender']['kalender_id'],
						$sql_tabs['kalender']['produkt_id'],
						$sql_tabs['kalender']['beginn'],
						$sql_tabs['kalender']['ende'],
						$sql_tabs['kalender']['stammdaten_id'],
						$sql_tabs['kalender']['betreff'],	// 5
						$sql_tabs['kalender']['betreuer'],
						$sql_tabs['kalender']['zusatztext'],
						$sql_tabs['kalender']['beschreibung'],
						$sql_tabs['kalender']['art'],
						$sql_tabs['kalender']['user_id']	// 10
					),
					$sql_tabs['kalender']['kalender_zusatz_id'].'='.$db->dbzahl($row4[0]).' and ('.
						$sql_tabs['kalender']['beginn'].' between '.$datum1.' and '.$datum2.' or '.
						$sql_tabs['kalender']['ende'].' between '.$datum1.' and '.$datum2.
						' or ('.$sql_tabs['kalender']['beginn'].'<'.$datum1.' and '.$sql_tabs['kalender']['ende'].'>'.$datum2.')'.
						')',
					$sql_tabs['kalender']['beginn']
					);
				}
				while ($row5=$db->zeile($res5)) {
					if (intval($row5[1])<=0) {
						if ($cfg_dvs and $row5[7]!='') {
							$row5[1]=$row5[7];
						} else {
							continue;
						}
					}
					$pf_t[$row5[1]][$db->unixdate($row5[2])][$row5[0]]=array($row5[0], $row5[1], $row5[2], $row5[3], $row5[4], $row5[5], $row5[6], $row5[8], $row5[9], $row5[10]);
					$pf_t[$row5[1]][$db->unixdate($row5[3])][$row5[0]]=array($row5[0], $row5[1], $row5[2], $row5[3], $row5[4], $row5[5], $row5[6], $row5[8], $row5[9], $row5[10]);
					$tsd1=intval($db->unixdate_ts($row5[2]));
					$tsd2=intval($db->unixdate_ts($row5[3]));
					$tsd3=$tsd2;
					while ($tsd3>$tsd1) {
						$pf_t[$row5[1]][adodb_date('d.m.Y', $tsd3)][$row5[0]]=array($row5[0], $row5[1], $row5[2], $row5[3], $row5[4], $row5[5], $row5[6], $row5[8], $row5[9], $row5[10]);
						$tsd3-=24*60*60;
					}
				}
//				print_r($pf_t);

				$pftage=30;
				if (isset($cfg_kfzsuche_pfbalken_tage) and intval($cfg_kfzsuche_pfbalken_tage)>0) {
					$pftage=intval($cfg_kfzsuche_pfbalken_tage);
				}
				$pfb=array();
                $pfb70=array();
                $pfb70_link='';
                if ($cfg_modern) {
                    $td_st=' style="padding: 0px; margin: 0px; border: 1px solid gray; padding-left:5px;"';
                } else {
                    $td_st=' style="padding: 0px; margin: 0px; border-right: 1px solid gray;"';
                }
				$wochenansicht=false;
				if (isset($getfeld['pfkal_woche'])) {
					$wochenansicht=true;
					$woche_zur=$je-24*60*60;
					while (adodb_date('w', $woche_zur)!=adodb_date('w', $je)) {
						$woche_zur-=24*60*60;
					}
					$woche_vor=$je+24*60*60;
					while (adodb_date('w', $woche_vor)!=adodb_date('w', $je)) {
						$woche_vor+=24*60*60;
					}
				}
				if ($wochenansicht) {
					$wotage=array(_TAG_ABKUERZUNG1_, _TAG_ABKUERZUNG2_, _TAG_ABKUERZUNG3_, _TAG_ABKUERZUNG4_, _TAG_ABKUERZUNG5_, _TAG_ABKUERZUNG6_, _TAG_ABKUERZUNG7_);
					$pftage=7;
					for ($pi=$je; $pi<=($je+$pftage*24*60*60); $pi+=24*60*60) {
						$tagvor='';
						$tagnach='';
						if ($cfg_kfzsuche_pfbalken_sofeiertag_rot) {
							$datum_gesamt=adodb_date('d.m.Y', $pi);
                            if ((isset($zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['feiertag']) and $zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['feiertag']==true) or (isset($zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['so']) and $zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['so']==true)) {
								$tagvor='<font color=red><b>';
								$tagnach='</b></font>';
							}
						}
						$pfb[0].='<td'.$td_st.' '.oltext2($wotage[adodb_date('w', $pi)].', '.adodb_date('d.m.Y', $pi)).'>'.'<b>'.$tagvor.$wotage[adodb_date('w', $pi)].':</b>'.$tagnach.'</td>';
						$pfb70[0][]=new Template_Tooltip($wotage[adodb_date('w', $pi)].', '.adodb_date('d.m.Y', $pi),'<b>'.$tagvor.$wotage[adodb_date('w', $pi)].':</b>'.$tagnach);
                        for ($xi=8; $xi<=20; $xi+=2) {
							$pfb[0].='<td'.$td_st.'>'.$xi.'</td>';
                            $pfb70[0][]=$xi;
						}
					}
					if ($cfg_kfzsuche_pfhistorie) {
						$pfb[0].='<td'.$td_st.'>'.link2('<span border="0" alt="Link" class="icon icon-file">&nbsp;</span>', 'javascript: k_inhalt(\''.$phs.'?ajax=1&pfhist={fzid}\', true, '.$dbr.', '.$dho.');').'</td>';
                        $pfb70_link=Template_Link::init(_PROBEFAHRTUEBERSICHT_,'','')
                                ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&pfhist={fzid}',$callback=array($kfzdetails_modal),$time=-1,$onload=false,$requestId='',$event='');
    
                    }
				} else {
					for ($pi=$je; $pi<=($je+$pftage*24*60*60); $pi+=24*60*60) {
						$tagvor='';
						$tagnach='';
						if ($cfg_kfzsuche_pfbalken_sofeiertag_rot) {
							$datum_gesamt=adodb_date('d.m.Y', $pi);
                            if ((isset($zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['feiertag']) and $zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['feiertag']==true) or (isset($zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['so']) and $zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['so']==true)) {
                                $tagvor='<font color=red><b>';
								$tagnach='</b></font>';
							}
						}
						$pfb[0].='<td'.$td_st.'>'.$tagvor.adodb_date('j.', $pi).$tagnach.'</td>';
                        $pfb70[0][]=$tagvor.adodb_date('j.', $pi).$tagnach;
					}
					if ($cfg_kfzsuche_pfhistorie) {
						$pfb[0].='<td'.$td_st.'>'.link2('<span border="0" alt="Link" class="icon icon-file">&nbsp;</span>', 'javascript: k_inhalt(\''.$phs.'?ajax=1&pfhist={fzid}\', true, '.$dbr.', '.$dho.');').'</td>';
                        $pfb70_link=Template_Link::init(_PROBEFAHRTUEBERSICHT_,'','')
                            ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&pfhist={fzid}',$callback=array($kfzdetails_modal),$time=-1,$onload=false,$requestId='',$event='');
                    }
				}
				if ($wochenansicht) {
					while (list($keyp, $valp)=@each($pf_t)) {
						for ($pi=$je; $pi<=($je+$pftage*24*60*60); $pi+=24*60*60) {
							$tagvor='';
							$tagnach='';
							if ($cfg_kfzsuche_pfbalken_sofeiertag_rot) {
								$datum_gesamt=adodb_date('d.m.Y', $pi);
								if ((isset($zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['feiertag']) and $zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['feiertag']==true) or (isset($zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['so']) and $zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['so']==true)) {
									$tagvor='<font color=red><b>';
									$tagnach='</b></font>';
								}
							}
							$pfb[$keyp].='<td'.$td_st.' '.oltext2($wotage[adodb_date('w', $pi)].', '.adodb_date('d.m.Y', $pi)).'>'.'<b>'.$tagvor.$wotage[adodb_date('w', $pi)].':</b>'.$tagnach.'</td>';
							$pfb70[$keyp][]=new Template_Tooltip($wotage[adodb_date('w', $pi)].', '.adodb_date('d.m.Y', $pi),'<b>'.$tagvor.$wotage[adodb_date('w', $pi)].':</b>'.$tagnach);
                            //$pfb[$keyp].='<td'.$td_st.' '.oltext2($wotage[adodb_date('w', $pi)].', '.adodb_date('d.m.Y', $pi)).'>'.'<b>'.$wotage[adodb_date('w', $pi)].':</b></td>';
							$tert=array();
							$tert1=array();
							$tert_ids=array();
							$pf_artent=array();
							while (list($keyp2, $valp2)=@each($valp[adodb_date('d.m.Y', $pi)])) {
								$zuspft1='';
								if ($cfg_kfzsuche_pf_bemerkung) {
									if (preg_match('/'._BEMERKUNG_.'/i', $valp2[7])) {
										$zuspft1.="\n\n".$valp2[7];
									}
								}
//								$tert[].=$db->unixdatetime($valp2[2]).' - '.$db->unixdatetime($valp2[3]).': '.kundenbezeichnung($valp2[4]).' - '.$valp2[4].' ('.$alle_bens[$valp2[6]].')'.$zuspft1.'<hr>';
								for ($xi=8; $xi<=20; $xi+=2) {
									$dat1=adodb_mktime($xi, 0, 0, adodb_date('m', $pi), adodb_date('d', $pi), adodb_date('Y', $pi));
									$dat2=adodb_mktime($xi+2, 0, 0, adodb_date('m', $pi), adodb_date('d', $pi), adodb_date('Y', $pi))-1;
									$t_beg=$db->unixdate_ts($valp2[2]);
									$t_end=$db->unixdate_ts($valp2[3]);
//echo $xi.': '.adodb_date('d.m.Y H:i', $dat1).'-'.adodb_date('d.m.Y H:i', $dat2).' / Termin: '.adodb_date('d.m.Y H:i', $t_beg).'-'.adodb_date('d.m.Y H:i', $t_end).'<br>';
									if (($t_beg>=$dat1 and $t_beg<=$dat2) or ($t_end>=$dat1 and $t_end<=$dat2) or ($dat1>=$t_beg and $dat1<=$t_end) or ($dat2>=$t_beg and $dat2<=$t_end)) {
//echo 'drin!';
										$tert[$xi].=$db->unixdatetime($valp2[2]).' - '.$db->unixdatetime($valp2[3]).': '.kundenbezeichnung($valp2[4]).' - '.$valp2[4].' ('.$alle_bens[$valp2[6]].($valp2[6]!=$valp2[9]?' - '._ERSTELLER_.': '.$alle_bens[$valp2[9]]:'').')'.$zuspft1.'<hr>';
										$tert1[$xi]++;
										$tert_ids[$xi].=$valp2[0].',';
										$pf_artent[$valp2[8]]++;
									}
								}
							}
							
							for ($xi=8; $xi<=20; $xi+=2) {
								if (isset($tert[$xi])) {
									$tert[$xi]=p4n_mb_string('substr',$tert[$xi], 0, -4);
									$maxt=$tert1[$xi];
									if ($maxt>=count($colors)) {
										$maxt=count($colors)-1;
									}
									$bgfarbe=$colors[$maxt];
									if (isset($sind_inaktive[$keyp])) {
										$bgfarbe='red';
									}
									$mousoverhl='';
									foreach ($pf_artent as $pfakey => $pfaval) {
										$mousoverhl.=$pfakey.', ';
									}
									$mousoverhl=substr($mousoverhl, 0, -2);
									$pflink1=$phs.'?ajax=1&pfchange='.substr($tert_ids[$xi], 0, -1);
									if ($cfg_kfzsuche_pf_laden) {
										$pflink1=$phs.'?ajax=1&pf='.$keyp.'&mitkunde=1&pfkalid='.substr($tert_ids[$xi], 0, -1);
									}
									$pfb[$keyp].='<td'.$td_st.' bgcolor="'.$bgfarbe.'" '.oltext2($tert[$xi], $mousoverhl).' onClick="javascript: k_inhalt(\''.$pflink1.'\', true, '.$dbr.', '.$dho.');">'.$xi.'</td>';
                                    $pfb70[$keyp][]=Template_ElementList::init(new Template_Tooltip($tert[$xi],new Template_Link($xi,'','','','onClick="javascript: k_inhalt(\''.$pflink1.'\', true, '.$dbr.', '.$dho.');"')),'','kfzround')->setAttribute('style','background:'.$bgfarbe);
                                } else {
									$pfb[$keyp].='<td'.$td_st.'>'.$xi.'</td>';
                                    $pfb70[$keyp][]=$xi;
								}
							}
						}
						if ($cfg_kfzsuche_pfhistorie) {
							$pfb[$keyp].='<td'.$td_st.'>'.link2('<span border="0" alt="Link" class="icon icon-file">&nbsp;</span>', 'javascript: k_inhalt(\''.$phs.'?ajax=1&pfhist='.$keyp.'\', true, '.$dbr.', '.$dho.');').'</td>';
                            $pfb70_link=Template_Link::init(_PROBEFAHRTUEBERSICHT_,'','')
                                ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&pfhist='.$keyp,$callback=array($kfzdetails_modal),$time=-1,$onload=false,$requestId='',$event='');
                        }
					}
				} else {
				while (list($keyp, $valp)=@each($pf_t)) {
					for ($pi=$je; $pi<=($je+$pftage*24*60*60); $pi+=24*60*60) {
						$tert='';
						$tert1=0;
						
						$tagvor='';
						$tagnach='';
						if ($cfg_kfzsuche_pfbalken_sofeiertag_rot) {
                            $datum_gesamt=adodb_date('d.m.Y', $pi);
                            if ((isset($zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['feiertag']) and $zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['feiertag']==true) or (isset($zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['so']) and $zusatzinfo[$_SESSION['user_id']][$datum_gesamt]['so']==true)) {
                                $tagvor='<font color=red><b>';
                                $tagnach='</b></font>';
                            }
						}
						$pf_artent=array();
						while (list($keyp2, $valp2)=@each($valp[adodb_date('d.m.Y', $pi)])) {
							$zuspft1='';
							if ($cfg_kfzsuche_pf_bemerkung) {
								if (preg_match('/'._BEMERKUNG_.'/i', $valp2[7])) {
									$zuspft1.="\n\n".$valp2[7];
								}
							}
							$tert.=$db->unixdatetime($valp2[2]).' - '.$db->unixdatetime($valp2[3]).': '.kundenbezeichnung($valp2[4]).' - '.$valp2[4].' ('.$alle_bens[$valp2[6]].($valp2[6]!=$valp2[9]?' - '._ERSTELLER_.': '.$alle_bens[$valp2[9]]:'').')'.$zuspft1.'<hr>';
							$tert1++;
							$pf_artent[$valp2[8]]++;
						}
						if ($tert1>0) {
							$tert=p4n_mb_string('substr',$tert, 0, -4);
							$maxt=$tert1;
							if ($maxt>=count($colors)) {
								$maxt=count($colors)-1;
							}
							$bgfarbe=$colors[$maxt];
							if (isset($sind_inaktive[$keyp])) {
								$bgfarbe='red';
							}
							$mousoverhl='';
							foreach ($pf_artent as $pfakey => $pfaval) {
								$mousoverhl.=$pfakey.', ';
							}
							$mousoverhl=substr($mousoverhl, 0, -2);
							$pfb[$keyp].='<td'.$td_st.' bgcolor="'.$bgfarbe.'" '.oltext2($tert, $mousoverhl).'>'.$tagvor.adodb_date('j.', $pi).$tagnach.'</td>';
                            $pfb70[$keyp][]=Template_ElementList::init(new Template_Tooltip($tert,$tagvor.adodb_date('j.', $pi).$tagnach),'','kfzround')->setAttribute('style','background:'.$bgfarbe);
                            
                            
						} else {
							$pfb[$keyp].='<td'.$td_st.'>'.$tagvor.adodb_date('j.', $pi).$tagnach.'</td>';
                            $pfb70[$keyp][]=$tagvor.adodb_date('j.', $pi).$tagnach;
						}
					}
					if ($cfg_kfzsuche_pfhistorie) {
						$pfb[$keyp].='<td'.$td_st.'>'.link2('<span border="0" alt="Link" class="icon icon-file">&nbsp;</span>', 'javascript: k_inhalt(\''.$phs.'?ajax=1&pfhist='.$keyp.'\', true, '.$dbr.', '.$dho.');').'</td>';
                        $pfb70_link=Template_Link::init(_PROBEFAHRTUEBERSICHT_,'','')
                            ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&pfhist='.$keyp,$callback=array($kfzdetails_modal),$time=-1,$onload=false,$requestId='',$event='');
                    }
				}
				}
			}
		}
		
		if ($cfg_kfzsuche_keinedvssuche) {
			if ($getfeld['refnr']=='' and $getfeld['fahrgestell']=='') {
				$where.=' and '.$db->dbstrin(array('Quality', 'reserviert', 'Paket', 'Auktion vorgesehen', 'Premiumaktion vorgesehen', 'Premiumauktion vorgesehen', 'Outlet', 'Premium', 'XXL Outlet', 'Ausschreibung'), $sql_tabs['produktzuordnung']['zusatzcode_1']);
			}
		}
		
		if ($getfeld['refnr']!='') {
			$where=$sql_tabs['produktzuordnung']['haendlerstatus'].'='.$db->str($getfeld['refnr']);
			$slog.='Refnr='.$getfeld['refnr'].', ';
		}
		if ($getfeld['prodzid']!='') {
			$where=$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($getfeld['prodzid']);
			$slog.='PID='.$getfeld['prodzid'].', ';
		}

		if (isset($getfeld['pak_erg'])) {
			if ($pak_ids_suche!='') {
				$where=$sql_tabs['produktzuordnung']['produktzuordnung_id'].' in ('.p4n_mb_string('substr',$pak_ids_suche, 0, -1).')';
			} else {
				$where=$sql_tabs['produktzuordnung']['produktzuordnung_id'].' in (-99)';
			}
			$slog.='PAK, ';
		}
		if (intval($getfeld['vormerk'])>0) {
			if (intval($getfeld['vormerk'])==1) {
				$where=$sql_tabs['produktzuordnung']['merkeverkauf_benutzer'].'>0';
				$slog.='vorgemerkt, ';
			}
			if (intval($getfeld['vormerk'])==2) {
				$where=$sql_tabs['produktzuordnung']['merkeverkauf_benutzer'].'='.$db->dbzahl($_SESSION['user_id']);
				$slog.='vorgemerkt eigen, ';
			}
		}
		if ($cfg_kfz_webservice) {
			$alle_contr=ws_kroa_kfz('-99', 10);
			//getVehicleContracts
			if (isset($alle_contr['vehicle']['vin'])) {
				$alle_contr=array('vehicle' => array( 0 => $alle_contr['vehicle']));
			}
			$alle_mit_kv=array();
			while (list($key1, $val1)=@each($alle_contr['vehicle'])) {
				$alle_mit_kv[$val1['vin']]=1;
			}
			if (1 or count($alle_mit_kv)>0) {
				$res=$db->select(
					$sql_tab['produktzuordnung'],
					array(
						$sql_tabs['produktzuordnung']['produktzuordnung_id'],
						$sql_tabs['produktzuordnung']['fahrgestell'],
						$sql_tabs['produktzuordnung']['vkinfo_carlo']
					),
					$where
				);
				while ($row=$db->zeile($res)) {
					if ($row[2]=='' and isset($alle_mit_kv[$row[1]])) {
						$db->update(
							$sql_tab['produktzuordnung'],
							array(
								$sql_tabs['produktzuordnung']['vkinfo_carlo'] => $db->str('KFZ bereits verkauft')
							),
							$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($row[0])
						);
					} elseif ($row[2]=='KFZ bereits verkauft' and !isset($alle_mit_kv[$row[1]])) {
						$db->update(
							$sql_tab['produktzuordnung'],
							array(
								$sql_tabs['produktzuordnung']['vkinfo_carlo'] => $db->str('')
							),
							$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($row[0])
						);
					}
				}
			}
			//print_r($alle_mit_kv);
		}
		
	if ($kfzs_debug) {
		if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
			fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'vor 1. Select'."\r\n");
			fclose($fp);
		}
	}


		$res=$db->select(
			$sql_tab['produktzuordnung'],
			'count(*)',
			$where
		);
		$anz=0;
		if ($row=$db->zeile($res)) {
			$anz=$row[0];
		}
		//$anz=$db->anzahl($res);
		if ($_SESSION['cfg_kunde']=='carlo_opel_carebus') {
			$sql_tabs['produktzuordnung']['leistung_ps']=$sql_tabs['produktzuordnung']['zusatz_text_8'];
		}

		if (isset($postfeld['nur_ids'])) {
			ob_end_clean();
			$where=$sql_tabs['produktzuordnung']['produktzuordnung_id'].' in ('.$postfeld['nur_ids'].')';
		}
        if (isset($getfeld['nur_ids2'])) {
			//ob_end_clean();
            if ($getfeld['nur_ids2']!='')
			$where=$sql_tabs['produktzuordnung']['produktzuordnung_id'].' in ('.$getfeld['nur_ids2'].')';
		}
		$alle_kfzs_ids='';
		if (isset($kfzs_nichtids)) {
			if ($kfzs_nichtids!='') {
				if ($where!='') {
					$where='('.$where.') and '.$sql_tabs['produktzuordnung']['produktzuordnung_id'].' not in ('.$kfzs_nichtids.')';
				}
			}
		}
		if (isset($getfeld['kurz'])) {
			ob_end_clean();
			//echo '<stc1><!shd1>';
			$inhalt='';
		}
		
		$unft_da=true;
		if (!isset($sql_tabs['produktzuordnung']['unfalltext'])) {
			$unft_da=false;
			$sql_tabs['produktzuordnung']['unfalltext']=$sql_tabs['produktzuordnung']['text_2'];
		}

		$sqltp=array(
				$sql_tabs['produktzuordnung']['produktzuordnung_id'],
				$sql_tabs['produktzuordnung']['markencode'],
				$sql_tabs['produktzuordnung']['typ_modell'],
				$sql_tabs['produktzuordnung']['datum_ez'],
				$sql_tabs['produktzuordnung']['kennzeichen'],
				$sql_tabs['produktzuordnung']['km_stand'],					// 5
				$sql_tabs['produktzuordnung']['leistung_ps'],
				$sql_tabs['produktzuordnung']['istverkaufspreis_mw'],
				$sql_tabs['produktzuordnung']['debitorenname'],
				$sql_tabs['produktzuordnung']['alter_debname'],
				$sql_tabs['produktzuordnung']['kommentar'],				// 10
				$sql_tabs['produktzuordnung']['stammdaten_id'],
				$sql_tabs['produktzuordnung']['fahrzeugstatus'],
				$sql_tabs['produktzuordnung']['datum_uebernahme'],
				$sql_tabs['produktzuordnung']['einstandspreis_mw'],
				$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'],			// 15 ohne _mwst?
				$sql_tabs['produktzuordnung']['planverkaufspreis_mw'],
				$sql_tabs['produktzuordnung']['angebot'],
				$sql_tabs['produktzuordnung']['kaufvertrag'],
				$sql_tabs['produktzuordnung']['angebot_kunde'],
				$sql_tabs['produktzuordnung']['kaufvertrag_kunde'],			// 20
				$sql_tabs['produktzuordnung']['fahrgestell'],
				$sql_tabs['produktzuordnung']['farbbezeichnung'],
				$sql_tabs['produktzuordnung']['mandant_id'],
				$sql_tabs['produktzuordnung']['unfallwagen'],
				$sql_tabs['produktzuordnung']['motorbezeichnung'],		// 25
				$sql_tabs['produktzuordnung']['getriebebezeichnung'],
				$sql_tabs['produktzuordnung']['standort'],
				$sql_tabs['produktzuordnung']['reservierung'],
				$sql_tabs['produktzuordnung']['reservierung_datum'],
				$sql_tabs['produktzuordnung']['text_4'],						// 30
				$sql_tabs['produktzuordnung']['anzahl_vorbesitzer'],
				$sql_tabs['produktzuordnung']['kraftstoff'],
				$sql_tabs['produktzuordnung']['anzahl_tueren'],
				$sql_tabs['produktzuordnung']['einkaufsdatum'],
				$sql_tabs['produktzuordnung']['differenzbesteuerung'],			// 35
				$sql_tabs['produktzuordnung']['hubraum'],
				$sql_tabs['produktzuordnung']['einkaeufer'],
				$sql_tabs['produktzuordnung']['vorbesitzername'],
				$sql_tabs['produktzuordnung']['notizen'],
				$sql_tabs['produktzuordnung']['fahrzeugmodellnr'],				// 40
				$sql_tabs['produktzuordnung']['zusatz3'],		// kalk.Kosten
				$sql_tabs['produktzuordnung']['angebot2'],
				$sql_tabs['produktzuordnung']['angebot2_kunde'],
				$sql_tabs['produktzuordnung']['reservierung_bisdatum'],
				$sql_tabs['produktzuordnung']['bauart'],						// 45
				$sql_tabs['produktzuordnung']['text_3'],
				$sql_tabs['produktzuordnung']['hersteller'],
				$sql_tabs['produktzuordnung']['anlagedatum'],
				$sql_tabs['produktzuordnung']['zusatz1'],
				$sql_tabs['produktzuordnung']['zusatz2'],						// 50
				$sql_tabs['produktzuordnung']['benutzer_id'],
				$sql_tabs['produktzuordnung']['verkaeufer'],
				$sql_tabs['produktzuordnung']['abmeldedatum'],
				$sql_tabs['produktzuordnung']['fabrikationscode'],
				$sql_tabs['produktzuordnung']['zusatzcode_1'],					// 55
				$sql_tabs['produktzuordnung']['fahrzeugstatus_code'],
				$sql_tabs['produktzuordnung']['text_1'],
				$sql_tabs['produktzuordnung']['vkpreis_mwst'],
				$sql_tabs['produktzuordnung']['eva_typ'],
				$sql_tabs['produktzuordnung']['auszeichnungspreis'],			// 60
				$sql_tabs['produktzuordnung']['buchnummer'],
				$sql_tabs['produktzuordnung']['einheitencode'],
				$sql_tabs['produktzuordnung']['haendlerstatus'],
				$sql_tabs['produktzuordnung']['produktbuchungsgruppe'],
				$sql_tabs['produktzuordnung']['vkinfo_carlo'],					// 65
				$sql_tabs['produktzuordnung']['typ'],
				$sql_tabs['produktzuordnung']['leistung_kw'],
				$sql_tabs['produktzuordnung']['merkeverkauf_benutzer'],
				$sql_tabs['produktzuordnung']['merkeverkauf_datum'],
				$sql_tabs['produktzuordnung']['merkeverkauf_text'],				// 70
				$sql_tabs['produktzuordnung']['aktuellervkpreis_mw'],
				$sql_tabs['produktzuordnung']['aktueller_listenpreis_mwst'],
				$sql_tabs['produktzuordnung']['zusatzcode_2'],
				$sql_tabs['produktzuordnung']['mindest_vkpreis'],
				$sql_tabs['produktzuordnung']['bereifung'],						// 75
				$sql_tabs['produktzuordnung']['dezimal_2'],
				$sql_tabs['produktzuordnung']['text_2'],
				$sql_tabs['produktzuordnung']['janein_1'],
				$sql_tabs['produktzuordnung']['unfalltext'],
				$sql_tabs['produktzuordnung']['standtage'],						// 80
				(($_SESSION['cfg_kunde']=='carlo_opel_schorr')?$sql_tabs['produktzuordnung']['bereifung_seit']:$sql_tabs['produktzuordnung']['ekpreis_neuester']),
				$sql_tabs['produktzuordnung']['zusatz_crm1'],
				$sql_tabs['produktzuordnung']['produkt_id'],
				$sql_tabs['produktzuordnung']['dezimal_1'],
				($cfg_greek?$sql_tabs['produktzuordnung']['eva']:$sql_tabs['produktzuordnung']['schluesselnr']),					// 85
				$sql_tabs['produktzuordnung']['kalkulation_daten'],
				$sql_tabs['produktzuordnung']['zusatztext1'],
				$sql_tabs['produktzuordnung']['zusatztext2'],
				$sql_tabs['produktzuordnung']['polsterbezeichnung'],
				$sql_tabs['produktzuordnung']['bonus_malus'],					// 90
				$sql_tabs['produktzuordnung']['kosten_proz'],		// limitpreis
				$sql_tabs['produktzuordnung']['einstandspreis_ds'],	// nova verrechnet
				$sql_tabs['produktzuordnung']['brutto_ertrag_proz']	// nova prozentsatz
		);
		if ($cfg_kfz_pf_aktiv) {
			$sqltp[8]=$sql_tabs['produktzuordnung']['modelyear'];
			$sqltp[58]=$sql_tabs['produktzuordnung']['powertr_exp'];
			$sqltp[60]=$sql_tabs['produktzuordnung']['rsa_exp'];
			$sqltp[90]=$sql_tabs['produktzuordnung']['reservierung_name'];
		}
		if (!isset($sql_tabs['produktzuordnung']['kalkulation_daten'])) {
		//	unset($sqltp[86]);
		}
		if (isset($sql_tabs['produktzuordnung']['dispotext'])) {
			$sqltp[]=$sql_tabs['produktzuordnung']['dispotext'];	// 94
			$sqltp[]=$sql_tabs['produktzuordnung']['nat_code'];		// 95
			$sqltp[]=$sql_tabs['produktzuordnung']['modelljahr'];	// 96
			$sqltp[]=$sql_tabs['produktzuordnung']['liefer_datum'];	// 97
			$sqltp[]=$sql_tabs['produktzuordnung']['preis_manuell'];	// 98
		}
		$baseanz_i=98;
		if ($cfg_carlo_appserver_activity) {
			$sqltp[74]=$sql_tabs['produktzuordnung']['generation'];
			$sqltp[81]=$sql_tabs['produktzuordnung']['video_url'];
		}
		if ($cfg_kfzsuche_motorgetriebe_beips) {
			$sqltp[70]=$sql_tabs['produktzuordnung']['kennbuchstabe_getriebe'];
		}
		if ($cfg_kfzimport_logdatum) {
			$sqltp[]=$sql_tabs['produktzuordnung']['kmstand_datum'];
			$sqltp[]=$sql_tabs['produktzuordnung']['kmstand_quelle'];
			$sqltp[]=$sql_tabs['produktzuordnung']['preis_datum'];
			$sqltp[]=$sql_tabs['produktzuordnung']['preis_quelle'];
			$baseanz_i+=4;
		}
		if ($cfg_kfzsuche_dd2020) {
			$sqltp[]=$sql_tabs['produktzuordnung']['vkpreis'];				// UPEBrut
			$sqltp[]=$sql_tabs['produktzuordnung']['vkpreis_dbberechnung'];	// UPENet
			$sqltp[]=$sql_tabs['produktzuordnung']['ekpreis_neuester'];		// Fracht
			$baseanz_i+=3;
		}
		if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
			$sqltp[]=$sql_tabs['produktzuordnung']['klasse'];
			$sqltp[]=$sql_tabs['produktzuordnung']['factory_exp'];
			$sqltp[]=$sql_tabs['produktzuordnung']['vermarktungslinie'];
			$baseanz_i++;
			$baseanz_i++;
			$baseanz_i++;
			if (isset($sql_tabs['produktzuordnung']['schaden_rep_text'])) {
				$sqltp[]=$sql_tabs['produktzuordnung']['schaden_rep_text'];
				$sqltp[]=$sql_tabs['produktzuordnung']['schaden_unrep_text'];
				$sqltp[]=$sql_tabs['produktzuordnung']['schaden_bem'];
				$baseanz_i++;
				$baseanz_i++;
				$baseanz_i++;
			}
		}
		if ($cfg_mboe_vorlagen or $s4c_neu) {
			$sqltp[]=$sql_tabs['produktzuordnung']['abgas_cozwei'];		// co2 nefz
			$sqltp[]=$sql_tabs['produktzuordnung']['abgas_nox'];		// co2 wltp
			$sqltp[]=$sql_tabs['produktzuordnung']['brutto_ertrag_mw'];	// novasatz 2
			$sqltp[]=$sql_tabs['produktzuordnung']['abgas_partikel'];	// Bonus2
			
			$baseanz_i+=4;
		}
		$art_pzf=-1;
		$bez_pzf='';
		$merke_intf_base=0;
		if ($cfg_internerfahrer or $_SESSION['crm_version']>64) {
			$sqltp[]=$sql_tabs['produktzuordnung']['interner_fahrer'];
			$baseanz_i++;
			$merke_intf_base=$baseanz_i;
		}
		if (isset($cfg_kfzsuche_zf_anzeige) and intval($cfg_kfzsuche_zf_anzeige)>0) {
			$res4=$db->select(
									$sql_tab['produktzuordnung_zusatzfelder'],
									array(
										$sql_tabs['produktzuordnung_zusatzfelder']['produktzuordnung_zusatzfelder_id'],
										$sql_tabs['produktzuordnung_zusatzfelder']['bezeichnung'],
										$sql_tabs['produktzuordnung_zusatzfelder']['art'],
										$sql_tabs['produktzuordnung_zusatzfelder']['groesse'],
										$sql_tabs['produktzuordnung_zusatzfelder']['nur_lesend']
									),
									$sql_tabs['produktzuordnung_zusatzfelder']['rang'].'='.$db->dbzahl($cfg_kfzsuche_zf_anzeige),
									$sql_tabs['produktzuordnung_zusatzfelder']['rang']
			);
			if ($row4=$db->zeile($res4)) {
				$sqltp[]=$sql_tab['produktzuordnung'].'.zf_'.$row4[0];
				$art_pzf=intval($row4[2]);
				$bez_pzf=$row4[1];
				if ($art_pzf==7) {
					$res4=$db->select(
						$sql_tab['benutzer'],
						array(
							$sql_tabs['benutzer']['benutzer_id'],
							$sql_tabs['benutzer']['vorname'],
							$sql_tabs['benutzer']['name']
						)
					);
					while ($row4=$db->zeile($res4)) {
						$alle_pzf_ben[$row4[0]]=$row4[1].' '.$row4[2];
					}
				}
				$baseanz_i++;
			}
		}
        $sqltp[]=$sql_tabs['produktzuordnung']['standtage_standort'];
        $sqltp[]=$sql_tabs['produktzuordnung']['kba_hersteller'];
        $sqltp[]=$sql_tabs['produktzuordnung']['kba_typ'];

		if ($kfzs_debug) {
			if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
				fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'vor 2. Select'."\r\n");
				fclose($fp);
			}
		}
		
		$lim1='1000';
		if (isset($getfeld['limitauswahl'])) {
			if ($getfeld['limitauswahl']==_ALLE_) {
				$lim1='5000';
			} else {
				$lim1=$getfeld['limitauswahl'];
			}
		}
		
		$ges_anz1=0;
		$kdopp_pids='';
		$kd_alle_opps=array();
		if (1==2 and $cfg_kfzsuche_keindispo) {
			if ($kfzs_debug) {
				if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
					fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'vor 3. Select'."\r\n");
					fclose($fp);
				}
			}
			$res=$db->select(
				$sql_tab['produktzuordnung'],
				$sql_tabs['produktzuordnung']['produktzuordnung_id'],
				$where,
			$sorto,
			'',
			false,
			$lim1
			);
			if ($kfzs_debug) {
				if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
					fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'nach 3. Select'."\r\n");
					fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.$db->last_sql."\r\n");
					fclose($fp);
				}
			}
			$kd_alle_pids='';
			while ($row=$db->zeile($res)) {
				$ges_anz1++;
				$kd_alle_pids.=$row[0].',';
			}
			if ($kfzs_debug) {
				if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
					fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'nach 3. Select-Schleife'."\r\n");
					fclose($fp);
				}
			}
			$kd_alle_pids=substr($kd_alle_pids, 0, -1);
			if ($kd_alle_pids!='') {
				$res3=$db->select(
						$sql_tab['opportunity'],
						array(
							$sql_tabs['opportunity']['opportunity_id'],
							$sql_tabs['opportunity']['stammdaten_id'],
							$sql_tabs['opportunity']['bemerkung'],
							$sql_tabs['opportunity']['phase'],
							$sql_tabs['opportunity']['betrag'],
							$sql_tabs['opportunity']['datum_eintrag'],
							$sql_tabs['opportunity']['benutzer_id'],
							$sql_tabs['opportunity']['produkt_id']
						),
						$sql_tabs['opportunity']['produkt_id'].' in ('.$kd_alle_pids.') and '.$sql_tabs['opportunity']['phase'].'='.$db->str(_ANGEBOT_),
						$sql_tabs['opportunity']['datum_eintrag'].' desc'
				);
				if ($kfzs_debug) {
					if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
						fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'nach Opp-Select'."\r\n");
						fclose($fp);
					}
				}
				while ($row3=$db->zeile($res3)) {
					$kd_alle_opps[$row3[7]].='<b>'._ANGEBOT_.' '.$db->unixdatetime($row3[5]).': '.kundenbezeichnung($row3[1]).' ('.number_format(doubleval($row3[4]), 2, ",", ".").' '.$waehrung_eur.' - '.$alle_bens[$row3[6]].' - '.$row3[3].')</b><br>'.$row3[2].'<hr>';
				}
				if ($kfzs_debug) {
					if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
						fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'nach Opp-Schleife'."\r\n");
						fclose($fp);
					}
				}
			}
		}
		
		if ($kfzs_debug) {
			if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
				fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'vor Select'."\r\n");
				fclose($fp);
			}
		}
		
		$interfacesList = array();
		foreach ($db->getRepository('interface_ref')->getByConditions(array('table_name' => 'produktzuordnung')) as $row_ref) {
            if ($row_ref['table_id'] && $row_ref['extern_id']) {
                $interfacesList[$row_ref['table_id']][$row_ref['interface']] = $row_ref['extern_id'];
            }
        }
		
        

        if ($_SESSION['design_70']) {
            $res=$db->select(
                $sql_tab['produktzuordnung'],
                $sqltp,
                $where,
                $sorto,
                '',
                false
            );
            $anz=$db->anzahl($res);
            $pagination->create($anz);
        }
        
        //$feld_tabellen, $felder='', $where='', $orderby='', $groupby='', $feld_joins=false, $limit=0, $von=0, $having=''
		$res=$db->select(
			$sql_tab['produktzuordnung'],
			$sqltp,
			$where,
			$sorto,
			'',
			false,
			($_SESSION['design_70']?$pagination->limit():$lim1),
            ($_SESSION['design_70']?$pagination->von():0)
		);
//		echo 'anz: '.$ges_anz1;
		
		if ($kfzs_debug) {
			if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
				fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'nach Select'."\r\n");
				fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.$db->last_sql."\r\n");
				fclose($fp);
			}
		}
		
//echo $db->last_sql;
		if (isset($postfeld['nur_ids']) || isset($getfeld['nur_ids2'])) {
			$anz=$db->anzahl($res);
		}
		$i=0;
		$zi=0;
		$mit_export=false;
		if (isset($getfeld['export_csv']) or isset($getfeld['export_pdf'])) {
			$mit_export=true;

			$csv_block='Marke;Typ/Modell;KM-Stand;Erstzulassung;PS;Farbe;Preis inkl. gesetzl. MwSt.;Filiale/Standort;FG-Nr.;Ausstattung;Ref.-Nr.;Aufbau;T�ren;Hubraum;Motor;KW;Kaufvertrag;Reservierung'."\r\n";
			$csv_blockh='Marke;Typ/Modell;KM-Stand;Erstzulassung;PS;Farbe;Preis zzgl. gesetzl. MwSt.;Filiale/Standort;FG-Nr.;Ausstattung;Ref.-Nr.;Aufbau;T�ren;Hubraum;Motor;KW;Kaufvertrag;Reservierung'."\r\n";
			
			$csv_block=_MARKE_.';'.$lang['_PZ-TYP-MODELL_'].';'._KMSTAND_.';'.$lang['_PZ-ERSTZULASSUNG_'].';PS;'._FARBE_.';'._PREIS_.' '._INKL_GESETZL_MWST_.';'._STANDORT_.';'._FAHRGESTELL_.';'._AUSSTATTUNG_.';Ref.-Nr.;'._BAUART_.';'._TUEREN_.';'._HUBRAUM_.';'._MOTORART_.';KW;'._KAUFVERTRAG_.';'._RESERVIERUNG_.($cfg_kfzsuche_holland?';':'').($cfg_dvs?';':'').';'._NETTO_.';Text 2'.($cfg_kfzsuche_suchebuchnummer?';'.$lang_db_f['produktzuordnung_preishistorie']['buchnummer']:'')."\r\n";
			$csv_blockh=_MARKE_.';'.$lang['_PZ-TYP-MODELL_'].';'._KMSTAND_.';'.$lang['_PZ-ERSTZULASSUNG_'].';PS;'._FARBE_.';'._PREIS_.' '._ZZGL_GESETZL_MWST_.';'._STANDORT_.';'._FAHRGESTELL_.';'._AUSSTATTUNG_.';Ref.-Nr.;'._BAUART_.';'._TUEREN_.';'._HUBRAUM_.';'._MOTORART_.';KW;'._KAUFVERTRAG_.';'._RESERVIERUNG_.($cfg_kfzsuche_holland?';':'').($cfg_dvs?';':'').';'._NETTO_.';Text 2'.($cfg_kfzsuche_suchebuchnummer?';'.$lang_db_f['produktzuordnung_preishistorie']['buchnummer']:'')."\r\n";
			if ($_SESSION['cfg_kunde']=='carlo_opel_buschmann') {
				$csv_block=substr($csv_block, 0, -2).';;;;'.$lang['_PZ-KENNZEICHEN_'].";Standtage;Motorart\r\n";
				$csv_blockh=substr($csv_blockh, 0, -2).';;;;'.$lang['_PZ-KENNZEICHEN_'].";Standtage;Motorart\r\n";
			}
			if ($cfg_kfzsuche_holland) {
				$csv_block=substr($csv_block, 0, -2).';'.$lang['_PZ-KENNZEICHEN_']."\r\n";
				$csv_blockh=substr($csv_blockh, 0, -2).';'.$lang['_PZ-KENNZEICHEN_']."\r\n";
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_tamsen') {
				$csv_block=substr($csv_block, 0, -2).';;;;'._POLSTER_.';'._DIFFBESTEUERUNG_."\r\n";
				$csv_blockh=substr($csv_blockh, 0, -2).';;;;'._POLSTER_.';'._DIFFBESTEUERUNG_."\r\n";
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_ruhrdeich') {
				$csv_block=substr($csv_block, 0, -2).';Text 1;Abmeldedatum;Standtage;Brutto UPE;PA Nummer;Verk�ufer;Kennzeichen'."\r\n";
				$csv_blockh=substr($csv_blockh, 0, -2).';Text 1;Abmeldedatum;Standtage;Brutto UPE;PA Nummer;Verk�ufer;Kennzeichen'."\r\n";
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_duerkop') {
				$csv_block=substr($csv_block, 0, -2).';-;Netto Verkauf;Text 1/2/3/4;Buchnummer;Standtage;Listenpreis;EK brutto;EK netto;WEM'."\r\n";
				$csv_blockh=substr($csv_blockh, 0, -2).';-;Netto Verkauf;Text 1/2/3/4;Buchnummer;Standtage;Listenpreis;EK brutto;EK netto;WEM'."\r\n";
			}
            if ($_SESSION['cfg_kunde']=='carlo_opel_toennemann') {
				$csv_block=substr($csv_block, 0, -2).';;;;'.$lang['_PZ-KENNZEICHEN_'].";Standtage;".$lang_db_f['produktzuordnung']['standtage_standort'].";Motorart\r\n";
				$csv_blockh=substr($csv_blockh, 0, -2).';;;;'.$lang['_PZ-KENNZEICHEN_'].";Standtage;".$lang_db_f['produktzuordnung']['standtage_standort'].";Motorart\r\n";
			}
            if ($cfg_kfzsuche_exportcsv_standtage) {
				$csv_block=substr($csv_block, 0, -2).';'._STANDTAGE_."\r\n";
				$csv_blockh=substr($csv_blockh, 0, -2).';'._STANDTAGE_."\r\n";
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_at_mboe_ws') {
				$csv_block=substr($csv_block, 0, -2).';"'.'Text 1'.'"'."\r\n";
				$csv_blockh=substr($csv_blockh, 0, -2).';"'.'Text 1'.'"'."\r\n";
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
				$csv_block='Marke;Typ/Modell;KM-Stand;Erstzulassung;PS;Farbe;Preis inkl. gesetzl. MwSt.;Filiale/Standort;FG-Nr.;Ausstattung;Ref.-Nr.;Aufbau;T�ren;Hubraum;Motor;KW;Minderwerte;Schaden repariert;Schaden unrepariert;Schaden Bemerkung'."\r\n";
				$csv_blockh='Marke;Typ/Modell;KM-Stand;Erstzulassung;PS;Farbe;Preis zzgl. gesetzl. MwSt.;Filiale/Standort;FG-Nr.;Ausstattung;Ref.-Nr.;Aufbau;T�ren;Hubraum;Motor;KW;Minderwerte;Schaden repariert;Schaden unrepariert;Schaden Bemerkung'."\r\n";
			}
		}

		$dblock=array();
		$sblock=array();
//echo $db->last_sql;
		$anz_dvs=0;
		if (!isset($getfeld['kurz']) && !$cfg_modern) {
			$inhalt.='<br>';
		}
		$inhalt.='<!shd2><!shd1>'.css_kopf('{anz_kfz} '._FAHRZEUGE_GEFUNDEN_.':');
		if (isset($postfeld['nur_ids'])) {
            if ($cfg_modern) {
                Modern_Helper_Request::requestStart();
            }
			echo '<!shd2><!shd1>'.css_kopf('<b>'._BESTANDSFAHRZEUG_.':</b> '.$anz.' '._FAHRZEUGE_GEFUNDEN_.', '.$postfeld['atext'].':');
		}
		$kfzslog_sel='';
		
        $table_data=array();
        $pagination_zaehler=0;
		//$inhalt.='<br>'.$anz.' Fahrzeuge gefunden:';
		while ($row=$db->zeile($res)) {
            $isInactive = $row['modelyear'] === 'inaktiv';

            $cols_view=array();
			$i++;
			if ($kfzs_debug) {
				$kfzslog_sel.=adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'KFZ '.$i."\r\n";
			}
			
			$dispohinw='';
			$dispohinw2='';
			$dispohinw_vorl='';
			
			$ist_dvskfz=false;
			if ($row[56]=='30') {
				$ist_dvskfz=true;
			}
			
			$zust_dispo2='';
			$zust_dispo_zusatz2='';
			$suche_dispo=false;
			if ($cfg_kfzsuche_suchebelegnummer) {
				if (isset($getfeld['belegnummer'])) {
					if ($getfeld['belegnummer']!='') {
						$suche_dispo=true;
					}
				}
			}
			$belegnr='';
			if ($suche_dispo or (!$cfg_kfzsuche_keindispo and (preg_match('/vorlauf/i', $row[12]) or $cfg_carlokfzimport_dispo_text2))) {
				$sqlt_d=array(
					$sql_tabs['produktzuordnung_dispo']['auftragstyp'],
					$sql_tabs['produktzuordnung_dispo']['auftragsnummer'],
					$sql_tabs['produktzuordnung_dispo']['pa_nummer'],
					$sql_tabs['produktzuordnung_dispo']['ereignis'],
					$sql_tabs['produktzuordnung_dispo']['ereignis_datum'],
					$sql_tabs['produktzuordnung_dispo']['bestelldatum'],	// 5
					$sql_tabs['produktzuordnung_dispo']['gmordernr'],
					$sql_tabs['produktzuordnung_dispo']['kundenname'],
					$sql_tabs['produktzuordnung_dispo']['liefertermin'],
					$sql_tabs['produktzuordnung_dispo']['belegnummer']
				);
				if ($cfg_carlokfzimport_dispo_text2) {
					$sqlt_d[]=$sql_tabs['produktzuordnung_dispo']['text_2'];
				}
				if ($cfg_carlokfzimport_dispo_text1_zusatz2) {
					$sqlt_d[]=$sql_tabs['produktzuordnung_dispo']['zusatz2'];
				}
				$where_dispo = $sql_tabs['produktzuordnung_dispo']['fahrgestellnummer'].'='.$db->str($row[21])
                    .' or '.$sql_tabs['produktzuordnung_dispo']['produktzuordnung_id'].'='.$db->dbzahl($row[0]);
				if (!empty($row[47])) {
                    $where_dispo .= ' or '.$sql_tabs['produktzuordnung_dispo']['belegnummer'].'='.$db->str($row[47]);
                }
				$res3=$db->select(
				$sql_tab['produktzuordnung_dispo'],
				$sqlt_d,
				$where_dispo
				);
				if ($row3=$db->zeile($res3)) {
					$belegnr=$row3[9];
					$zust_dispo2=$row3[10];
					if ($cfg_carlokfzimport_dispo_text1_zusatz2) {
						if ($cfg_carlokfzimport_dispo_text2) {
							$zust_dispo_zusatz2=$row3[11];
						} else {
							$zust_dispo_zusatz2=$row3[10];
						}
					}
					if ($row3[8]!='' and (p4n_mb_string('strlen',$row3[8])==8 or preg_match('/\d{8}/', $row3[8]))) {
						$row3[8]=p4n_mb_string('substr',$row3[8], 0, 4).', '._MONAT_.' '.p4n_mb_string('substr',$row3[8], 4, 2).', '._TERMIN_WOCHE_.' '.p4n_mb_string('substr',$row3[8], 6, 2).p4n_mb_string('substr',$row3[8], 8);
					}
					$dispohinw_vorl=' '.oltext(_LIEFERTERMIN_.': '.$row3[8].'<br><br>'.$lang['_AUFTRAG-K_'].': '.$row3[7].'<br>'.$lang['_PRODUKTKAUF-AUFTRAGSNUMMER_'].': '.$row3[1].'<br>PA: '.$row3[2].'<br>'.$row3[3].' ('.$db->unixdate($row3[4]).')<br>'._BESTELLDATUM_.': '.$db->unixdate($row3[5]).'<br>GM Order: '.$row3[6], 'Dispo');
				}
			}
			if (!$cfg_dvs_fm and $_SESSION['cfg_kunde']!='carlo_opel_dello' and $cfg_kfzsuche_keindispo and (preg_match('/vorlauf/i', $row[12]) or $cfg_carlokfzimport_dispo_text2)) {
				if ($row[94]!='') {
					$dispohinw_vorl=' '.oltext($row[94], 'Dispo');
				}
			}
			if ($cfg_kfz_webservice_dispotext and intval($row[11])==$cfg_kfz_webservice_stid) {
				if ($row[94]!='') {
					$dispohinw_vorl=' '.oltext($row[94], 'Dispo');
				}
			}
			
			if (!$cfg_kfzsuche_keindispo and ($_SESSION['cfg_kunde']=='carlo_opel_wzimmer' or $cfg_kfzsuche_dispoverkauft_rot)) {
			if ($row[56]!='1' and $row[56]!='3') {
			$res3=$db->select(
				$sql_tab['produktzuordnung_dispo'],
				array(
					$sql_tabs['produktzuordnung_dispo']['auftragstyp'],
					$sql_tabs['produktzuordnung_dispo']['auftragsnummer'],
					$sql_tabs['produktzuordnung_dispo']['pa_nummer'],
					$sql_tabs['produktzuordnung_dispo']['ereignis'],
					$sql_tabs['produktzuordnung_dispo']['ereignis_datum'],
					$sql_tabs['produktzuordnung_dispo']['bestelldatum'],
					$sql_tabs['produktzuordnung_dispo']['gmordernr'],
					$sql_tabs['produktzuordnung_dispo']['kundenname']
				),
				$sql_tabs['produktzuordnung_dispo']['fahrgestellnummer'].'='.$db->str($row[21])
					.' or '.$sql_tabs['produktzuordnung_dispo']['belegnummer'].'='.$db->str($row[47])
			);
			if ($row3=$db->zeile($res3)) {
				if ($row3[0]=='0' or p4n_mb_string('strtolower',$row3[0])=='verkauft' or trim($row3[7])!='') {
					$dispohinw=oltext2($lang['_AUFTRAG-K_'].': '.$row3[7].'<br>'.$lang['_PRODUKTKAUF-AUFTRAGSNUMMER_'].': '.$row3[1].'<br>PA: '.$row3[2].'<br>'.$row3[3].' ('.$db->unixdate($row3[4]).')<br>'._BESTELLDATUM_.': '.$db->unixdate($row3[5]).'<br>GM Order: '.$row3[6], 'Dispo: '._KFZ_VERKAUFT_.'');
					$dispohinw2=$lang['_AUFTRAG-K_'].': '.$row3[7].'<br>'.$lang['_PRODUKTKAUF-AUFTRAGSNUMMER_'].': '.$row3[1].'<br>PA: '.$row3[2].'<br>'.$row3[3].' ('.$db->unixdate($row3[4]).')<br>'._BESTELLDATUM_.': '.$db->unixdate($row3[5]).'<br>GM Order: '.$row3[6];
				}
			}
			}
			}
			
			if ($cfg_kfzsuche_keindispo and ($_SESSION['cfg_kunde']=='carlo_opel_wzimmer' or $cfg_kfzsuche_dispoverkauft_rot)) {
				if ($row[94]!='') {
					$dispohinw=oltext2($row[94], 'Dispo: '._KFZ_VERKAUFT_.'');
					$dispohinw2=$row[94];
				}
			}
			
			if ($row[65]!='') {
				if ($dispohinw2!='') {
					$dispohinw2='<br><br>'.$dispohinw2;
				}
				if (isset($lang_db_f['produktzuordnung']['vkinfo_carlo'])) {
					$dispohinw=oltext2($row[65].$dispohinw2, $lang_db_f['produktzuordnung']['vkinfo_carlo'].': '._KFZ_VERKAUFT_);
				} else {
					$dispohinw=oltext2($row[65].$dispohinw2, 'CARLO: '._KFZ_VERKAUFT_);
				}
			}
			
			$farbe=$row[22];
			
			$unfa='';
			if ($row[24]=='1') {
				$unf2t=intval($row[76]);
				if ($unft_da and $row[79]!='') {
					$unfa='<p style="background-color: lightblue; display: inline;">'.oltext($row[79], '<font color=red>'.p4n_mb_string('substr',_UNFALLW_, 0, 3).'</font>').'</p> ';
				} elseif ($cfg_dvs and isset($dvs_unfall2[$unf2t])) {
					$unfa='<p style="background-color: lightblue; display: inline;">'.oltext($dvs_unfall2[$unf2t], '<font color=red>'.p4n_mb_string('substr',_UNFALLW_, 0, 3).'</font>').'</p> ';
				} else {
					$unfa='<p style="background-color: lightblue; display: inline;"><font color=red>'.p4n_mb_string('substr',_UNFALLW_, 0, 3).'</font></p> ';
				}
                
			} elseif ($cfg_kfzsuche_unfalltextbeiunfallfrei and $row[79]!='') {
				$unfa='<p style="background-color: lightblue; display: inline;">'.oltext($row[79], '<font color=green>'.p4n_mb_string('substr',_KFZPFLEGE_UNFALLTEXT_, 0, 3).'</font>').'</p> ';
			}
			
			$zusk='';
			if (intval($row[11])>0) {
				if (function_exists('oltext_tab')) {
					$zusk=oltext_tab(1,kundenbezeichnung($row[11]), '! '.$row[11], 'stammdaten_main.php?id='.$row[11].'&nav=Fahrzeuge', $row[12]).' ';
				} else {
					$zusk=oltext(kundenbezeichnung($row[11]), '! '.$row[11], 'stammdaten_main.php?id='.$row[11].'&nav=Fahrzeuge', $row[12]).' ';
				}
			}
			$vbest='';
			if (preg_match('/ - (.*)/', $row[12], $matc)) {
				$vbest='/'.p4n_mb_string('substr',$matc[1], 0, 1);
			}
			$zusk.=p4n_mb_string('substr',$row[12], 0, 1).$vbest.' - ';

			$standtage=0;
				if ($db->unixdate_ts($row[34])>0) {
					$standtage=(time()-$db->unixdate_ts($row[34]))/(24*60*60);
				}
			if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
				if (intval($row[80])>0) {
					$standtage=intval($row[80]);
				}
			}
			$zus_st_farbe='';
			if ($cfg_kfzsuche_standtage_farbe_nw and (preg_match('/neu/i', $row[12]) or $row[56]=='0') and isset($cfg_kfzsuche_standtage_farben)) {
				$zus_st_farbe='';
					$f_abbr=false;
					@reset($cfg_kfzsuche_standtage_farben);
					while (!$f_abbr and list($stf_key, $stf_val)=@each($cfg_kfzsuche_standtage_farben)) {
						if (is_numeric($stf_key)) {
							if ($standtage>$stf_key) {
								$zus_st_farbe=$cfg_kfzsuche_standtage_farben[$stf_key];
								$f_abbr=true;
							}
						}
					}
				if ($zus_st_farbe!='') {
					$zus_st_farbe='<p style="background-color: '.$zus_st_farbe.'" '.oltext2(intval($standtage)).'>&nbsp;</p>';
				}
			}
			if ($cfg_kfzsuche_italien and isset($cfg_kfzsuche_standtage_farben)) {
				$standtage2=0;
				if ($db->unixdate_ts($row[53])>0) {
					$standtage2=(time()-$db->unixdate_ts($row[53]))/(24*60*60);//abmeldedatum
				}
				$zus_st_farbe='';
				if ($row[53]=='' and preg_match('/\-/', $row[12])) {
					$zus_st_farbe=$cfg_kfzsuche_standtage_farben['leer_vorlauf'];
				} elseif ($row[53]=='') {
					$zus_st_farbe=$cfg_kfzsuche_standtage_farben['leer'];
				} else {
					$f_abbr=false;
					@reset($cfg_kfzsuche_standtage_farben);
					while (!$f_abbr and list($stf_key, $stf_val)=@each($cfg_kfzsuche_standtage_farben)) {
						if (is_numeric($stf_key)) {
							if ($standtage2>$stf_key) {
								$zus_st_farbe=$cfg_kfzsuche_standtage_farben[$stf_key];
								$f_abbr=true;
							}
						}
					}
				}
				if ($zus_st_farbe!='') {
					$zus_st_farbe='<p style="background-color: '.$zus_st_farbe.'" '.oltext2($db->unixdate($row[53])).'>&nbsp;</p>';
				}
			}

/*			if (p4n_mb_string('substr',$row[12], 0, 7)=='Vorf�hr') {
				if ($db->unixdate_ts($row[3])>0) {
					$standtage=(time()-$db->unixdate_ts($row[3]))/(24*60*60);
				}
			}
			if (p4n_mb_string('substr',$row[12], 0, 7)=='Gebrauc') {
				if ($db->unixdate_ts($row[13])>0) {
					$standtage=(time()-$db->unixdate_ts($row[13]))/(24*60*60);
				}
			}
*/
			$aktion='';
            $aktion70=array();
            $aktion70_tooltip='';
			$maktion2='';
			
			if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
				$vml=$row['vermarktungslinie'];
				$vmls=array(
						'1' => 'nicht gew�hlt',
						'2' => 'Premium',
						'3' => 'Quality',
						'4' => 'Outlet',
						'5' => 'XXL Outlet',
						'6' => 'Nutzer�bernahme',
						'7' => 'Ausschreibung',
						'8' => 'Aussonderung',
						'10'=> 'Sofortkaufaktion'
				);
				if (isset($vmls[$vml])) {
					$vml=$vmls[$vml];
				}
			}
			
			if ($ist_dvskfz and !$cfg_dvs_fm and $row[55]!='') {
				$aktion=$row[55].' ';
                $aktion70_tooltip=$row[55].' ';
				if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
					$aktion.='/ '.$vml.' ';
                    $aktion70_tooltip.='/ '.$vml.' ';
				}
				if ($_SESSION['user_gruppe']==2) {
					$aktion.=link2(_DATEN_.' '._AKTUALISIEREN_, $phs.'?dvs_update='.$row[0]).'<br>';
                    $aktion70[]=new Template_Link(_DATEN_.' '._AKTUALISIEREN_, $phs.'?dvs_update='.$row[0]);
				}
			}
			$aktion_kurz='';
			$akt_kl=false;
			$akt_kl2=false;
			$akt_kl3=false;
			$akt_kl4=false;	// keine DVS-Reserv.
			if ($ist_dvskfz and $row[55]=='Dekra Reklamation') {
				$akt_kl4=true;
			}
			
			$mk_vkben='';
			
			$ang_kv_info='';
			if ($ist_dvskfz and $row[55]=='verkauft') {
				$akt_kl2=true;
			}
			if ($row[17]=='1' or $row[18]=='1' or $row[42]=='1') {
				if (($row[17]=='1' or $row[42]=='1')) {
					$ang_text='';
					if ($cfg_kfzsuche_keindispo) {
						$ang_text='{at_'.$row[0].'}';//$kd_alle_opps[$row[0]];
						//$ang_text=$kd_alle_opps[$row[0]];
						$kdopp_pids.=$row[0].',';
					} else {
					$res3=$db->select(
						$sql_tab['opportunity'],
						array(
							$sql_tabs['opportunity']['opportunity_id'],
							$sql_tabs['opportunity']['stammdaten_id'],
							$sql_tabs['opportunity']['bemerkung'],
							$sql_tabs['opportunity']['phase'],
							$sql_tabs['opportunity']['betrag'],
							$sql_tabs['opportunity']['datum_eintrag'],
							$sql_tabs['opportunity']['benutzer_id']
						),
						$sql_tabs['opportunity']['produkt_id'].'='.$db->dbzahl($row[0]).' and '.$sql_tabs['opportunity']['phase'].'='.$db->str(_ANGEBOT_),
						$sql_tabs['opportunity']['datum_eintrag'].' desc'
					);
					while ($row3=$db->zeile($res3)) {
						$ang_text.='<b>'.($row[42]=='1'?_ANGEBOT2_:_ANGEBOT_).' '.$db->unixdatetime($row3[5]).': '.kundenbezeichnung($row3[1]).' ('.number_format(doubleval($row3[4]), 2, ",", ".").' '.$waehrung_eur.' - '.$alle_bens[$row3[6]].' - '.$row3[3].')</b><br>'.$row3[2].'<hr>';
					}
					}
					
					$okuid=$row[19];
					if ($row[42]=='1') {
						$okuid=$row[43];
						$akt_kl3=true;
					}

					$aktion.=oltext($ang_text, '<font color=black>'.($row[42]=='1'?_ANGEBOT2_:_ANGEBOT_).'</font>', '', ($row[42]=='1'?_ANGEBOT2_:_ANGEBOT_), 500).' - '.link2(kundenbezeichnung($okuid), 'stammdaten_main.php?id='.$okuid.'&nav=Uebersicht').'<br>';   
                    $aktion70_tooltip.=$ang_text.'<br>';
                    
                    $aktion_kurz.=oltext($ang_text, '<font color=black>'.($row[42]=='1'?_ANGEBOT2_:_ANGEBOT_).'</font>', '', ($row[42]=='1'?_ANGEBOT2_:_ANGEBOT_), 500).' - '.link2(kundenbezeichnung($okuid), 'stammdaten_main.php?id='.$okuid.'&nav=Uebersicht').'<br>';
				}
				$kv_oppid='';
				if ($row[18]=='1') {
					if (!isset($_SESSION['kfzsuche_kvloeschen'])) {
						$kannkvloe=false;
						$res8=$db->select(
							$sql_tab['benutzer_gruppe'],
							$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
							$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str(_KAUFVERTRAG_.' '._LOESCHEN_)
						);
						if ($row8=$db->zeile($res8)) {
							$res8=$db->select(
								$sql_tab['benutzer_gruppe_zuordnung'],
								$sql_tabs['benutzer_gruppe_zuordnung']['benutzer_gruppe_id'],
								$sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row8[0]).' and '.
									$sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id'])
							);
							if ($row8=$db->zeile($res8)) {
								$kannkvloe=true;
							}
						}
						$_SESSION['kfzsuche_kvloeschen']=$kannkvloe;
					}
					$zus_loekvlink='';
                    $zus_loekvlink70='';
					if ($_SESSION['kfzsuche_kvloeschen']) {
						$zus_loekvlink=' ('.link2(_STATUS_.' '._LOESCHEN_, $phs.'?loekv1='.$row[0], '', _VORGANG_ABFRAGE_).')';
                        $zus_loekvlink70=new Template_Link(_KAUFVERTRAG_.' '._STATUS_.' '._LOESCHEN_, $phs.'?loekv1='.$row[0], '', _VORGANG_ABFRAGE_);
					}
					$vkinfo='';
					$res5=$db->select(
						$sql_tab['korrespondenz'],
						array(
							$sql_tabs['korrespondenz']['betreuer_id'],
							$sql_tabs['korrespondenz']['stammdaten_id'],
							$sql_tabs['korrespondenz']['opportunity_id']
						),
//						$sql_tabs['korrespondenz']['stammdaten_id'].'='.$db->dbzahl($row[20]).' and '.
							$sql_tabs['korrespondenz']['kategorie'].'='.$db->str(_KAUFVERTRAG_).' and '.
							$sql_tabs['korrespondenz']['produktzuordnung_id'].'='.$db->dbzahl($row[0]),
						$sql_tabs['korrespondenz']['datum'].' desc'
					);
					if ($row5=$db->zeile($res5)) {
						$row[20]=$row5[1];
						$kv_oppid=$row5[2];
						
						if ($cfg_mboe_vorlagen) {
							$res8=$db->select(
								$sql_tab['opportunity'],
								array(
									$sql_tabs['opportunity']['status2_benutzer_id'],
									$sql_tabs['opportunity']['status2'],
									$sql_tabs['opportunity']['fakturiert_benutzer_id'],
									$sql_tabs['opportunity']['fakturiert_datum'],
									$sql_tabs['opportunity']['fakturiert_text']
								),
								$sql_tabs['opportunity']['opportunity_id'].'='.$db->dbzahl($kv_oppid)
							);
							if ($row8=$db->zeile($res8)) {
								if (!$cfg_letztevkp_genehmigung2_mail) {
									if (intval($row8[2])=='-1') {
										$vkinfo.='<font color=red>'._DATENSCHUTZ1K_N_.' ('.$db->unixdate($row8[3]).($row8[4]!=''?' - '.$row8[4]:'').')</font><br>';
									}
								}
								if (intval($row8[0])>0) {
									$vkinfo.='<font color=red>'._DATENSCHUTZ1K_N_.' ('.$db->unixdate($row8[1]).')</font><br>';
								}
							}
						}
						
						$vkinfo.=_BENUTZER_.': '.$alle_bens[$row5[0]].'<br>';
						$mk_vkben=$alle_bens[$row5[0]];
//					}
						$aktion.='<font color=red>'._KAUFVERTRAG_.'</font>'.$zus_loekvlink.' - '.link2(kundenbezeichnung($row[20]), 'stammdaten_main.php?id='.$row[20].'&nav=Uebersicht').'<br>'.$vkinfo;
                        $aktion70[]=$zus_loekvlink70;
                        $aktion_tooltip.=$vkinfo;
                        
                        $aktion_kurz.='<font color=red>'._KAUFVERTRAG_.'</font>'.$zus_loekvlink.' - '.link2(kundenbezeichnung($row[20]), 'stammdaten_main.php?id='.$row[20].'&nav=Uebersicht').'<br>'.$vkinfo;
//					$akt_kl=true;
						$akt_kl2=true;
						if ($getfeld['refnr']!='' and $ist_dvskfz) {
							echo javas('alert("Fahrzeug ist bereits verkauft.");');
						}
					} elseif ($ist_dvskfz) {
						$aktion.='<font color=red>'._KAUFVERTRAG_.'</font> ';
						$akt_kl2=true;
						if ($getfeld['refnr']!='') {
							echo javas('alert("Fahrzeug ist bereits verkauft.");');
						}
					}
				}
			}
			
			$ang_kv_info.=$aktion_kurz;
			
			$nr_zust='';
            $nr_zust70='';
			$details_fotos='';
			if ($cfg_kfzsuche_fotolink and intval($row[0])>0) {
				if (is_dir('dokumente/kfz_fotos/'.$row[21].'/thumb')) {
					$details_fotos='<br>'.oltext(_BILDER_, _BILDER_, 'javascript: k_inhalt(\'produktzuordnung.php?pidbilder='.$row[0].'\', true, '.$dbr.', '.$dho.');', _BILDER_);
					if ($cfg_kfzsuche_fotovorn) {
						$x=array();
						dirinhalt_kfz3('dokumente/kfz_fotos/'.$row[21]);
						$xi=1;
						while ($nr_zust=='' and list($key, $val)=@each($x)) {
							$vals=$val;
							while (list($key2, $val2)=@each($vals)) {
								if (preg_match('/\_(\d+)\_/', $val2, $mat1)) {
									$neu1=$mat1[1];
									if (strlen($mat1[1])==1) {
										$neu1='0'.$mat1[1];
										$val2=str_replace($mat1[0], '_'.$neu1.'_', $val2);
									}
								}
								if (substr($val2, 0, 4)=='Fzg_') {
									$val2=substr($val2, 4);
								}
								$vals[$key2]=$val2;
							}
							@asort($vals);
							@reset($vals);
							while (list($key2, $val2)=@each($vals)) {
								$vals[$key2]=$val[$key2];
							}
							$val=$vals;
							@reset($val);
							while ($nr_zust=='' and list($key2, $val2)=@each($val)) {
								if (p4n_mb_string('strtolower',$val2)=='thumbs.db' or strtolower(substr($val2, -4))!='.jpg') {
									continue;
								}
								if (!(strtolower(substr($val2, -4))=='.jpg' or strtolower(substr($val2, 5))=='.jpeg')) {
									continue;
								}
								$nr_zust='<a href="javascript: k_inhalt(\'produktzuordnung.php?pidbilder='.$row[0].'\', true, '.$dbr.', '.$dho.');"><img src="'.'dokumente/kfz_fotos/'.$row[21].'/thumb/'.$val2.'" alt="" /></a>';
                                $nr_zust70=new Template_Link(new Template_Image('dokumente/kfz_fotos/'.$row[21].'/thumb/'.$val2,'120px'), $bild, '','','onclick="k_inhalt(\'produktzuordnung.php?pidbilder='.$row[0].'\', true, '.$dbr.', '.$dho.');"');
                            }
						}
					}
				}
			}

			$finlink='';
            $finlink70=array();
			$finlink2='';
			if ($cfg_kfzsuche_finkalk) {
				$leasuvp=$row[72];
				if (preg_match('/gebraucht/i', $row[12])) {
					$leasuvp=$row[15];
				}
				$finlink=' '.link2(_FINRECHNER_, 'javascript: oeffne_finkalk(\''.number_format(doubleval($row[15]), 2, ',', '').'\', \''.$row[0].'\', \''.number_format(doubleval($leasuvp), 2, ',', '').'\');');
				$finlink70[]=new Template_Link(_FINRECHNER_, 'javascript: oeffne_finkalk(\''.number_format(doubleval($row[15]), 2, ',', '').'\', \''.$row[0].'\', \''.number_format(doubleval($leasuvp), 2, ',', '').'\');');
                
                $finlink2=' '.$form->submit2('finkalkinfo['.$row[0].']', _FINRECHNER_, 'style="'.$but_style.'" onClick="oeffne_finkalk(\''.number_format(doubleval($row[15]), 2, ',', '').'\', \''.$row[0].'\', \''.number_format(doubleval($leasuvp), 2, ',', '').'\'); return false;"');
			}
			if ($cfg_kfzsuche_preisinfo_fotoauswahl and $details_fotos!='') {
				$finlink.=' '.link2(_BILDER_, 'javascript: k_inhalt(\'produktzuordnung.php?pi=1&pidbilder='.$row[0].'\', true, '.$dbr.', '.$dho.');');
				$finlink70[]=Template_Link::init(_BILDER_)
                ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='produktzuordnung.php',$werte='options_menu=0&pi=1&pidbilder='.$row[0],$callback=array($kfzdetails_modal));
                
                $finlink2.=' '.$form->submit2('finkalkinfo['.$row[0].']', _BILDER_, 'style="'.$but_style.'" onClick="k_inhalt(\'produktzuordnung.php?pi=1&pidbilder='.$row[0].'\', true, '.$dbr.', '.$dho.'); return false;"');
			}
			if ($cfg_ocapi) {
				$finlink.=' / '.link2('MB Finanzierung', 'javascript: nicht=true; k_inhalt(\'stammdaten_main.php?nav=OM&ocapi=0&pid='.$row[0].'&stid='.$_SESSION['stammdaten_id'].'\', true, '.$dbr.', '.$dho.');').'';
				$finlink2.=' '.$form->submit2('ksubmit9ocapi['.$row[0].']', 'MB Finanzierung', ' style="width: '.$button_breite.'px; border: 1px solid black; margin: 2px;" onClick="nicht=true; k_inhalt(\'stammdaten_main.php?nav=OM&ocapi=0&pid='.$row[0].'&stid='.$_SESSION['stammdaten_id'].'\', true, '.$dbr.', '.$dho.');"');
			}
			
			if ($_SESSION['cfg_kunde']=='carlo_opel_tamsen') {
				if ($row[82]!='') {
					$details_fotos.='<br>ONL: '.($row[82]=='1'?_NEIN_:'').($row[82]=='0'?_JA_:'');
				}
			}
			
			// EnVKV
			if (substr($_SESSION['cfg_kunde'], 0, 14)!='carlo_opel_nl_' and substr($_SESSION['cfg_kunde'], 0, 14)!='carlo_opel_kr_' and substr($_SESSION['cfg_kunde'], 0, 24)!='carlo_opel_avag_kroatien' and substr($_SESSION['cfg_kunde'], 0, 14)!='carlo_opel_gr_') {
				if (!isset($cfg_envkvda)) {
					if (is_file('vorlagen/envkv.rtf')) {
						$cfg_envkvda=true;
					}
				}
				if ($cfg_envkvda) {
					$finlink.=' / '.link2('EnVKV', 'javascript: k_inhalt(\''.$phs.'?ajax=1&envkv='.$row[0].'\', true, '.$dbr.', '.$dho.');');
                    $finlink70[]=Template_Link::init('EnVKV')
                    ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&envkv='.$row[0],$callback=array($kfzdetails_modal));
//					$finlink2=' / '.$form->submit2('envkv['.$row[0].']', 'EnVKV', 'style="'.$but_style.'" onClick="oeffne_envkv(\''.$row[0].'\'); return false;"');
				}
			}
			if ($cfg_toyota_rechner && !empty($toyotaDealerId)) {
                $finlink .= ' / '.link2('Toyota '._FINANZIERUNG_, 'javascript: P4nBoxHelper.iframe(\'toyota_rechner_frame\', \'toyota_rechner.php?dealer_id='.$toyotaDealerId.'&price='.intval($row[15]).'\', false, \'100%\', \'100%\');');
                $finlink70[]=Template_Link::init('Toyota '._FINANZIERUNG_)
                ->setRequest($art='SRC',$kfzdetails_modal_inhalt_iframe,$url='toyota_rechner.php',$werte='dealer_id='.$toyotaDealerId.'&price='.intval($row[15]),$callback=array($kfzdetails_modal_iframe));
            }

            $maktion2=$aktion;
            $maktion2_70=$aktion70;
			
			$zusabfr1_pf='';
			$zusabfr1='';
			$zusabfr2='';
			if ($akt_kl2) {
				$zusabfr1=' if (!confirm(\''._VORGANG_ABFRAGE_.' ('._ANGEBOT_.')\')) { return false; } ';
				$zusabfr2=' if (!confirm(\''._VORGANG_ABFRAGE_.' ('._KAUFVERTRAG_.')\')) { return false; } ';
			}
			if ($cfg_ws_avag_kroatien or $cfg_kfz_webservice or $cfg_letztevkp_genehmigung2_mail) {
				$zusabfr1_pf=' var erg_kroa=check_kroa_status2('.$row[0].'); if (!erg_kroa) { return false; } ';
				$zusabfr1=' var erg_kroa=check_kroa_status2('.$row[0].'); if (!erg_kroa) { return false; } ';
				$zusabfr2=' var erg_kroa=check_kroa_status2('.$row[0].'); if (!erg_kroa) { return false; } ';
			}

			$keine_pf=false;
			if ($cfg_kfzsuche_keinepf or ($cfg_kfzsuche_keinepfnw and ($row[12]=='Neufahrzeug' or $row[56]=='0')) or ($cfg_kfzsuche_keinepfmiet and ($row[12]=='Mietfahrzeug' or $row[12]=='Mietwagen' or $row[56]=='6'))) {
				$keine_pf=true;
			}
			
			if (isset($cfg_kfzsuche_keinang) and $cfg_kfzsuche_keinang) {
				
			} else {
				$cfg_kfzsuche_keinang=false;
			}
			if ($cfg_vkinfo_keinangkvpf) {
				$cfg_kfzsuche_keinang=false;
				$cfg_kfzsuche_keinkv=false;
			}
			if ($row[65]!='' and $cfg_vkinfo_keinangkvpf) {
				if ($cfg_kfzsuche_kv_vfw_pf and ($row[56]=='2' or p4n_mb_string('substr',$row[12], 0, 7)=='Vorf�hr' or p4n_mb_string('substr',$row[12], 0, 4)=='Test' or p4n_mb_string('substr',$row[12], 0, 5)=='Tages')) {
					// doch PF anzeigen
				} else {
					$keine_pf=true;
				}
				$cfg_kfzsuche_keinang=true;
				$cfg_kfzsuche_keinkv=true;
			}
			
			if (isset($cfg_kfzhandel_bgr) and $cfg_kfzhandel_bgr!='') {
						$res7=$db->select(
							$sql_tab['benutzer_gruppe'],
							array(
								$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
								$sql_tabs['benutzer_gruppe']['bezeichnung']
							),
							$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str($cfg_kfzhandel_bgr)
						);
						if ($row7=$db->zeile($res7)) {
							if (preg_match('/,'.$row7[0].',/', ','.$_SESSION['rechte_bgruppen'].',')) {
								// in Gruppe darf sehen
							} else {
								$cfg_kfzsuche_keinang=true;
								$cfg_kfzsuche_keinkv=true;
							}
						}
			}
			
			if ($cfg_kfz_pf_aktiv) {
				if ($row[8]=='inaktiv') {
					$keine_pf=true;
				}
			}
			if ($_SESSION['cfg_kunde']=='crm_ford_bhs' and $row[11]=='20661') {
				$keine_pf=false;
				if ($cfg_vkinfo_keinangkvpf) {
					$cfg_kfzsuche_keinang=false;
					$cfg_kfzsuche_keinkv=false;
				}
				//$cfg_kfzsuche_keinang=true;
				//$cfg_kfzsuche_keinkv=true;
			}
			
			if ($cfg_kfzsuche_pf_nurkfzlao_intf and $_SESSION['user_gruppe']!=2) {
				if ($_SESSION['user_id']==intval($row[$merke_intf_base])) {
					// int. Fahrer, ok
				} else {
					if (!isset($nur_mand[$row[23]])) {
						$keine_pf=true;
					}
				}
				if (intval($row[$merke_intf_base])>0 and $_SESSION['user_id']!=intval($row[$merke_intf_base])) {
					$keine_pf=true;
				}
			} else {
				if ($cfg_kfzsuche_pf_nurstdlao) {
					if ($_SESSION['user_gruppe']!=2 and intval($_SESSION['user_standard_lagerort'])>0) {
						if (intval($_SESSION['user_standard_lagerort'])!=intval($row[23])) {
							$keine_pf=true;
						}
					}
				}
				if ($cfg_kfzsuche_intfahrer_pf and $_SESSION['user_gruppe']!=2) {
					if (intval($row[$merke_intf_base])>0) {
						if ($_SESSION['user_id']!=intval($row[$merke_intf_base])) {
							$keine_pf=true;
						}
					}
				}
			}
			$aktion4='';
            $aktion70_tooltip='';
			$loc_reserv=false;
			$loc_reserv_keinkv=false;
			if ($row[56]=='20' or $row[56]=='21') {//$row[12]=='Locator'
				$angelegt=$db->unixdate_ts($row[48]);
				if ($row[50]=='1') {
					if ($cfg_kfzsuche_avag_austria) {
						$res_bis=$angelegt+2*24*60*60;
						$aktion4.='<br><font color=red>'._RESERVIERUNG_.' 2 '._TAGE_.' ('._BIS_.' '.adodb_date('d.m.Y', $res_bis).')</font>';
					} else {
						$res_bis=$angelegt+1*24*60*60;
						$aktion4.='<br><font color=red>'._RESERVIERUNG_.' 1 '._TAG_.' ('._BIS_.' '.adodb_date('d.m.Y', $res_bis).')</font>';
					}
					$loc_reserv=true;
				} elseif ($row[50]=='2') {
					if ($cfg_kfzsuche_avag_austria) {
						$res_bis=$angelegt+60*24*60*60;
						$aktion4.='<br><font color=red>'._RESERVIERUNG_.' 60 '._TAGE_.' ('._BIS_.' '.adodb_date('d.m.Y', $res_bis).')</font>';
					} else {
						$res_bis=$angelegt+30*24*60*60;
						$aktion4.='<br><font color=red>'._RESERVIERUNG_.' 30 '._TAGE_.' ('._BIS_.' '.adodb_date('d.m.Y', $res_bis).')</font>';
					}
					$loc_reserv=true;
				} elseif ($row[50]=='4') {
					$loc_reserv=true;
				//	$loc_reserv_keinkv=true;
				}
				$aktion4.='<br>Locator ID: '.$row[49].' / '.$alle_bens[$row[51]].'/'.$row[52];
                $aktion70_tooltip.=$aktion4;
			}
			
			if ($cfg_kfzsuche_verkauftbutton) {
				if ($row[65]!='') {
					if ($ist_vkleiter or $row[43]==$_SESSION['user_id']) {
						$aktion.=link2(_LOESCHEN_.': '._KFZ_VERKAUFT_, $phs.'?vkinfloe='.$row[0].'&vkinfloe_vin='.$row[21], '', _ABFRAGE_LOESCHEN_).' ';
                        $aktion70[]=new Template_Link(_LOESCHEN_.': '._KFZ_VERKAUFT_, $phs.'?vkinfloe='.$row[0].'&vkinfloe_vin='.$row[21], '', _ABFRAGE_LOESCHEN_);
                        
					}
				} else {
					$aktion.=$form->submit2('vkbu'.$row[0], _VERKAUFT_, 'onClick="oeffne_verkform(\''.$row[0].'\', \''.$row[21].'\')"');
                    $aktion70[]=new Template_Link(_VERKAUFT_,'','','','onClick="oeffne_verkform(\''.$row[0].'\', \''.$row[21].'\')"');
         
					$aktion_kurz.=$form->submit2('vkbu1['.$row[0].']', _VERKAUFT_, 'style="'.$but_style.'" onClick="oeffne_verkform(\''.$row[0].'\', \''.$row[21].'\')"');
				}
			}
			
			if ($cfg_kfzsuche_ang_expose) {
				$aktion.=$form->submit2('expo'.$row[0], _EXPOSE_, 'onClick="'.$zusabfr1.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&expo='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_summe(); try{new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} catch(e) {}"');
				 $aktion70[]=Template_Link::init(_EXPOSE_,'','','',' onClick="'.$zusabfr1.'"')
                ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&kfznl=1&expo='.$row[0],$callback=array($kfzdetails_modal,'rechne_summe();'));
                           
                $aktion_kurz.=$form->submit2('expo1['.$row[0].']', _EXPOSE_, 'style="'.$but_style.'" onClick="'.$zusabfr1.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&expo='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_summe(); return false;"');
            }
			if ($cfg_dd_sammelkv and isset($alle_im_korb2[$row[0]]) and !isset($alle_im_korb[$row[0]])) {
				$aktion.=_WARENKORB_;
				$loc_reserv=true;
			} elseif ($akt_kl3) {
				if ($_SESSION['user_gruppe']==2) {
					$aktion.=link2(_ANGEBOT2_.' '._LOESCHEN_, $phs.'?stid='.$row[43].'&delang='.$row[0], '', _VORGANG_ABFRAGE_);
                    $aktion70[]=Template_Link::init(_ANGEBOT2_.' '._LOESCHEN_, $phs.'?stid='.$row[43].'&delang='.$row[0], '', _VORGANG_ABFRAGE_);
                    
					$aktion_kurz.=$form->submit2('angloe['.$row[0].']', _ANGEBOT2_.' '._LOESCHEN_, 'style="'.$but_style.'" onClick="if (confirm(\''._VORGANG_ABFRAGE_.'\')) { window.open(\''.$phs.'?stid='.$row[43].'&delang='.$row[0].'\', \'main\');"');//link2(_ANGEBOT2_.' '._LOESCHEN_, $phs.'?stid='.$row[43].'&delang='.$row[0], '', _VORGANG_ABFRAGE_);
				}

				if (!$cfg_kfzsuche_keinkv and !$loc_reserv_keinkv/*and !$loc_reserv*/) {
					$aktion.='<br>'.$form->submit2('kv'.$row[0], ($cfg_kfzsuche_buttons_abk?_KV_KURZ_:_KAUFVERTRAG_), 'onClick="'.$zusabfr2.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&kv='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_summe(); try{new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} catch(e) {} "');//location.href=\''.$phs.'?kv='.$row[0].'\'
                    
                    $aktion70[]=Template_Link::init(($cfg_kfzsuche_buttons_abk?_KV_KURZ_:_KAUFVERTRAG_),'','','',' onClick="'.$zusabfr2.'"')
                    ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&kfznl=1&kv='.$row[0],$callback=array($kfzdetails_modal,'rechne_summe();'),$time=-1,$onload=false,$requestId='',$event='');
                    
                    //$(\'message\').makeResizable( {handle: div_rez} );  $(\'DivShim\').makeResizable( {handle: div_rez} );
					$aktion_kurz.=$form->submit2('kv1['.$row[0].']', _KAUFVERTRAG_, 'style="'.$but_style.'" onClick="'.$zusabfr2.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&kv='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_summe(); return false;"');
				}

				if (!$cfg_kfzsuche_keinekfzinfo) {
					$aktion.='<br>'.link2(($cfg_kfzsuche_buttons_abk?'FI':_FAHRZEUG_.' '._INFO_), $phs.'?info=1&pid='.$row[0], '','', 'target="status"');
					$aktion70[]=Template_Link::init(($cfg_kfzsuche_buttons_abk?'FI':_FAHRZEUG_.' '._INFO_), $phs.'?info=1&pid='.$row[0], '','', 'target="status"');
      
                    $aktion_kurz.=$form->submit2('kfzinfo['.$row[0].']', _FAHRZEUG_.' '._INFO_, 'style="'.$but_style.'" onClick="window.open(\''.$phs.'?info=1&pid='.$row[0].'\', \'status\'); return false;"');
				}
				if (!$cfg_kfzsuche_keinepreisinfo) {
                    if (!$_SESSION['design_70'])
					$aktion.=' / '.preisinfolink($row[0]).$finlink;
                    
                    if ($_SESSION['design_70']) {
                        $preisinfolink=preisinfolink($row[0]);
                        if (is_array($preisinfolink)) {
                             $aktion70=array_merge($aktion70,$preisinfolink);
                        } else {
                             $aktion70[]=preisinfolink($row[0]);
                        }

                        $aktion70=array_merge($aktion70,$finlink70);
                    }
                    
                    if (!$_SESSION['design_70'])
					$aktion_kurz.=preisinfolink($row[0], true).$finlink2;//$form->submit2('preisinfo['.$row[0].']', $lang['_P-PREIS_'].' '._INFO_, 'style="'.$but_style.'" onClick="window.open(\''.$phs.'?preis=1&info=1&pid='.$row[0].'\', \'status\'); return false;"');
				} else {
					$aktion.=' / '.$finlink;
                    $aktion70=array_merge($aktion70,$finlink70);
				}
				
				//$aktion='-';
			} elseif ($akt_kl2) {
				if ($_SESSION['user_gruppe']==2) {
					$aktion.=link2(_KAUFVERTRAG_.' '._LOESCHEN_, $phs.'?stid='.$row[20].'&delkv='.$row[0], '', _VORGANG_ABFRAGE_);
                    $aktion70[]=new Template_Link(_KAUFVERTRAG_.' '._LOESCHEN_, $phs.'?stid='.$row[20].'&delkv='.$row[0], '', _VORGANG_ABFRAGE_);
			//		$aktion_kurz.=link2(_KAUFVERTRAG_.' '._LOESCHEN_, $phs.'?stid='.$row[20].'&delkv='.$row[0], '', _VORGANG_ABFRAGE_);
					$aktion_kurz.=$form->submit2('kvloesch['.$row[0].']', _KAUFVERTRAG_.' '._LOESCHEN_, 'style="'.$but_style.'" onClick="if (confirm(\''._VORGANG_ABFRAGE_.'\')) { window.open(\''.$phs.'?stid='.$row[20].'&delkv='.$row[0].'\', \'main\'); } return false;"');
				}
				//$aktion='-';
			} elseif (!$akt_kl) {
				if (!$keine_pf) {	//!$loc_reserv and !$loc_reserv_keinkv and
					$aktion.=$form->submit2('pf'.$row[0], ($cfg_kfzsuche_buttons_abk?_PF_KURZ_:_PROBEFAHRT_), 'onClick="'.$zusabfr1_pf.' k_inhalt(\''.$phs.'?ajax=1&pf='.$row[0].((isset($getfeld['vonlead']) or isset($postfeld['vonlead']))?'&vonlead=1':'').'\', true, '.$dbr.', '.$dho.'); try {new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} catch(e) {}"');//, 'droppables': droppables // document.getElementById(\'overlay\').className=\'dunkel\';
                    
                    $isFromLead = isset($getfeld['vonlead']) || isset($postfeld['vonlead']);
                    
                    $linkText = $cfg_kfzsuche_buttons_abk ? _PF_KURZ_ : _PROBEFAHRT_;
                    if ($isInactive) {
                        $linkText = '<span style="color: lightgrey;">'.($cfg_kfzsuche_buttons_abk ? _PF_KURZ_ : _PROBEFAHRT_).'</span> ';
                        $linkText .= '<span style="color: red;">(inaktiv)</span>';
                    }
                    $link = new Template_Link($linkText, '');
                    $link->onClick($zusabfr1_pf);
                    $link->setRequest(
                        'GET',
                        $kfzdetails_modal_inhalt,
                        'kfzsuche.php',
                        'options_menu=0&ajax=1&pf='.$row[0].($isFromLead ? '&vonlead=1' : ''),
                        array($kfzdetails_modal),
                        -1,
                        false,
                        '',
                        ''
                    );
                    $aktion70[] = $link;
                    
                    $temp_pfb70_link = clone $pfb70_link;
                    Template_Trait_Obj_Helper::strreplace($temp_pfb70_link, '{fzid}', $row[0]);
                    if ($isInactive) {
                        $linkText = '<span style="color: lightgrey;">'.$temp_pfb70_link->elements[0]->text.'</span>';
                        $linkText .= '<span>&nbsp;</span>';
                        $linkText .= '<span style="color: red;">(inaktiv)</span>';
                        $temp_pfb70_link->elements[0]->text = $linkText;
                        $aktion70[] = $temp_pfb70_link;
                    } else {
                        $aktion70[] = $temp_pfb70_link;
                    }
                    // $(\'message\').makeResizable( {handle: div_rez} );  $(\'DivShim\').makeResizable( {handle: div_rez} );
					$aktion_kurz.=$form->submit2('pf1['.$row[0].']', _PROBEFAHRT_, 'style="'.$but_style.'" onClick="'.$zusabfr1_pf.' k_inhalt(\''.$phs.'?ajax=1&pf='.$row[0].((isset($getfeld['vonlead']) or isset($postfeld['vonlead']))?'&vonlead=1':'').'\', true, '.$dbr.', '.$dho.'); return false;"');
                }
				if (isset($alle_pf[$row[0]])) {
					$aktion.=oltext($alle_pf2[$row[0]], '('.$alle_pf[$row[0]].')').' ';
                    $aktion70_tooltip.=$alle_pf2[$row[0]].'<br>';
					$aktion_kurz.=oltext($alle_pf2[$row[0]], '('.$alle_pf[$row[0]].')').' ';
				}
				if (!$cfg_kfzsuche_keinang) {
					$aktion.=$form->submit2('ang'.$row[0], ($cfg_kfzsuche_buttons_abk?_ANG_KURZ_:($cfg_db_kaufrecht2022?'Vorvertragsinformation':_ANGEBOT_)), 'onClick="'.$zusabfr1.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&ang='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_summe(); try{new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} catch(e) {}"');//, 'droppables': droppables // document.getElementById(\'overlay\').className=\'dunkel\';
				
                    $aktion70[]=Template_Link::init(($cfg_kfzsuche_buttons_abk?_ANG_KURZ_:($cfg_db_kaufrecht2022?'Vorvertragsinformation':_ANGEBOT_)),'','','',' onClick="'.$zusabfr1.'"')
                    ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&kfznl=1&ang='.$row[0],$callback=array($kfzdetails_modal,'rechne_summe();'),$time=-1,$onload=false,$requestId='',$event='');
    
                    // $(\'message\').makeResizable( {handle: div_rez} );  $(\'DivShim\').makeResizable( {handle: div_rez} );
					$aktion_kurz.=$form->submit2('ang1['.$row[0].']', _ANGEBOT_, 'style="'.$but_style.'" onClick="'.$zusabfr1.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&ang='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_summe(); return false;"');
				}
				
				if ($cfg_vvi2022) {
					$aktion.=$form->submit2('vvi'.$row[0], _VVI_, 'onClick="'.$zusabfr1.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&vvi='.$row[0].'\', true, '.$dbr.', '.$dho.'); try{new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} catch(e) {}"');
					
                    $aktion70[]=Template_Link::init(_VVI_,'','','',' onClick="'.$zusabfr1.'"')
                    ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&kfznl=1&vvi='.$row[0],$callback=array($kfzdetails_modal),$time=-1,$onload=false,$requestId='',$event='');

                    $aktion_kurz.=$form->submit2('vvi1['.$row[0].']', _VVI_, 'style="'.$but_style.'" onClick="'.$zusabfr1.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&vvi='.$row[0].'\', true, '.$dbr.', '.$dho.'); return false;"');
				}
				
				if (!$cfg_kfzsuche_keinkv and !$loc_reserv_keinkv /*and !$loc_reserv*/) {
					$aktion.=$form->submit2('kv'.$row[0], ($cfg_kfzsuche_buttons_abk?_KV_KURZ_:_KAUFVERTRAG_), 'onClick="'.$zusabfr2.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&kv='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_summe();"');//location.href=\''.$phs.'?kv='.$row[0].'\'
					
                    $aktion70[]=Template_Link::init(($cfg_kfzsuche_buttons_abk?_KV_KURZ_:_KAUFVERTRAG_),'','','',' onClick="'.$zusabfr2.'"')
                    ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&kfznl=1&kv='.$row[0],$callback=array($kfzdetails_modal,'rechne_summe();'),$time=-1,$onload=false,$requestId='',$event='');

                    
                    // $(\'message\').makeResizable( {handle: div_rez} );  $(\'DivShim\').makeResizable( {handle: div_rez} );
					$aktion_kurz.=$form->submit2('kv1['.$row[0].']', _KAUFVERTRAG_, 'style="'.$but_style.'" onClick="'.$zusabfr2.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&kv='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_summe(); return false;"');
				}
				
				if ($cfg_dd_sammelkv) {
					if (isset($alle_im_korb[$row[0]])) {
						$aktion.=$form->submit2('skv'.$row[0], _IMWARENKORB_, 'onClick="'.$zusabfr2.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&skv='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_skv();" style="background-color: green"');
					
                        $aktion70[]=Template_Link::init(_IMWARENKORB_,'','','',' onClick="'.$zusabfr2.'"')
                        ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&kfznl=1&skv='.$row[0],$callback=array($kfzdetails_modal,'rechne_skv();'),$time=-1,$onload=false,$requestId='',$event='');

                        
                    } elseif (isset($alle_im_korb2[$row[0]])) {
						$aktion.=_WARENKORB_;
					} else {
						$aktion.=$form->submit2('skv'.$row[0], _WARENKORB_, 'onClick="'.$zusabfr2.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&skv='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_skv(); "');
					
                        $aktion70[]=Template_Link::init(_WARENKORB_,'','','',' onClick="'.$zusabfr2.'"')
                        ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&kfznl=1&skv='.$row[0],$callback=array($kfzdetails_modal,'rechne_skv();'),$time=-1,$onload=false,$requestId='',$event='');
                    }
				}
				
				if ($cfg_kfzsuche_interne_fahrt) {
					$aktion.=$form->submit2('pfint'.$row[0], _INTERNEFAHRT_, 'onClick="'.$zusabfr1_pf.' k_inhalt(\''.$phs.'?ajax=1&intpf=1&pf='.$row[0].'\', true, '.$dbr.', '.$dho.'); try {new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} catch(e) {}"');
					$aktion_kurz.=$form->submit2('pf1int['.$row[0].']', _INTERNEFAHRT_, 'style="'.$but_style.'" onClick="'.$zusabfr1_pf.' k_inhalt(\''.$phs.'?ajax=1&intpf=1&pf='.$row[0].'\', true, '.$dbr.', '.$dho.'); return false;"');
				
                    $aktion70[]=Template_Link::init(_INTERNEFAHRT_,'','','',' onClick="'.$zusabfr1_pf.'"')
                        ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&intpf=1&pf='.$row[0],$callback=array($kfzdetails_modal),$time=-1,$onload=false,$requestId='',$event='');

                }
				if ($_SESSION['cfg_kunde']=='carlo_opel_greiner' &&  $row[21]!='') {
					$aktion.=$form->submit2('eco_dms', 'EcoDMS', 'onClick="P4nBoxHelper.iframe(\'ecodms_iframe\', \'eco_dms.php?vin='.$row[21].'\', false, \'100%\', \'100%\');"');
					$aktion_kurz.=$form->submit2('eco_dms', 'EcoDMS', 'onClick="P4nBoxHelper.iframe(\'ecodms_iframe\', \'eco_dms.php?vin='.$row[21].'\', false, \'100%\', \'100%\');"');
                    
                    $ecoDMSLink = new Template_Link('EcoDMS');
                    $ecoDMSLink->setRequest('GET', $kfzdetails_modal_inhalt, 'eco_dms.php', array('vin='.$row[21]), array($kfzdetails_modal));
					$aktion70[] = $ecoDMSLink;
				}
				if (!$cfg_kfzsuche_keinekfzinfo) {
					$aktion.='<br>'.link2(($cfg_kfzsuche_buttons_abk?'FI':_FAHRZEUG_.' '._INFO_), $phs.'?info=1&pid='.$row[0], '','', 'target="status"');
					$aktion_kurz.=$form->submit2('kfzinfo['.$row[0].']', _FAHRZEUG_.' '._INFO_, 'style="'.$but_style.'" onClick="window.open(\''.$phs.'?info=1&pid='.$row[0].'\', \'status\'); return false;"');
				
                    $aktion70[]=Template_Link::init(_FAHRZEUG_.' '._INFO_,'','','',' onClick="window.open(\''.$phs.'?info=1&pid='.$row[0].'\', \'status\');"');
                }
				if (!$cfg_kfzsuche_keinepreisinfo) {
                    if (!$_SESSION['design_70'])
					$aktion.=' / '.preisinfolink($row[0]).$finlink;
                    
                    if ($_SESSION['design_70']) {
                        $preisinfolink=preisinfolink($row[0]);
                        if (is_array($preisinfolink)) {
                             $aktion70=array_merge($aktion70,$preisinfolink);
                        } else {
                             $aktion70[]=preisinfolink($row[0]);
                        }

                        $aktion70=array_merge($aktion70,$finlink70);
                    }
                    
                    if (!$_SESSION['design_70'])
					$aktion_kurz.=preisinfolink($row[0], true).$finlink2;
				} else {
					$aktion.=' / '.$finlink;
                    $aktion70=array_merge($aktion70,$finlink70);
				}
			}
            if ($akt_kl2 and $cfg_kfzsuche_immer_pf and !$keine_pf) {	// and !$loc_reserv_keinkv
				$aktion.=' '.$form->submit2('pf2'.$row[0], _PROBEFAHRT_, 'onClick="'.$zusabfr1_pf.' k_inhalt(\''.$phs.'?ajax=1&pf='.$row[0].'\', true, '.$dbr.', '.$dho.'); try{new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} catch(e) {}"');

                $linkText = _PROBEFAHRT_;
                if ($isInactive) {
                    $linkText = '<span style="color: lightgrey;">'._PROBEFAHRT_.'</span> ';
                    $linkText .= '<span style="color: red;">(inaktiv)</span>';
                }
                $aktion70[] = Template_Link::init($linkText, '', '', '', ' onClick="'.$zusabfr1_pf.'"')
                    ->setRequest($art = 'GET', $kfzdetails_modal_inhalt, $url = 'kfzsuche.php', $werte = 'options_menu=0&ajax=1&pf='.$row[0], $callback = array($kfzdetails_modal));
                
                $temp_pfb70_link = clone $pfb70_link;
                Template_Trait_Obj_Helper::strreplace($temp_pfb70_link, '{fzid}', $row[0]);
                if ($isInactive) {
                    $linkText = '<span style="color: lightgrey;">'.$temp_pfb70_link->elements[0]->text.'</span>';
                    $linkText .= ' <span style="color: red;">(inaktiv)</span>';
                    $temp_pfb70_link->elements[0]->text = $linkText;
                    $aktion70[] = $temp_pfb70_link;
                } else {
                    $aktion70[] = $temp_pfb70_link;
                }
                
                $aktion_kurz.=$form->submit2('pf['.$row[0].']', _PROBEFAHRT_, 'style="'.$but_style.'" onClick="'.$zusabfr1_pf.'k_inhalt(\''.$phs.'?ajax=1&pf='.$row[0].'\', true, '.$dbr.', '.$dho.'); return false;"');
			} elseif ($akt_kl2 and $cfg_kfzsuche_kv_vfw_pf and ($row[56]=='2' or p4n_mb_string('substr',$row[12], 0, 7)=='Vorf�hr' or p4n_mb_string('substr',$row[12], 0, 4)=='Test' or p4n_mb_string('substr',$row[12], 0, 5)=='Tages') and !$keine_pf) {
				$aktion.=' '.$form->submit2('pf2'.$row[0], _PROBEFAHRT_, 'onClick="'.$zusabfr1_pf.' k_inhalt(\''.$phs.'?ajax=1&pf='.$row[0].'\', true, '.$dbr.', '.$dho.'); try{new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} catch(e) {}"');
                
                $linkText = _PROBEFAHRT_;
                if ($isInactive) {
                    $linkText = '<span style="color: lightgrey;">'._PROBEFAHRT_.'</span> ';
                    $linkText .= '<span style="color: red;">(inaktiv)</span>';
                }
                $aktion70[] = Template_Link::init($linkText, '', '', '', ' onClick="'.$zusabfr1_pf.'"')
                    ->setRequest(
                        'GET',
                        $kfzdetails_modal_inhalt,
                        'kfzsuche.php',
                        'options_menu=0&ajax=1&pf='.$row[0],
                        array($kfzdetails_modal)
                    );
                
                $temp_pfb70_link = clone $pfb70_link;
                Template_Trait_Obj_Helper::strreplace($temp_pfb70_link, '{fzid}', $row[0]);
                if ($isInactive) {
                    $linkText = '<span style="color: lightgrey;">'.$temp_pfb70_link->elements[0]->text.'</span>';
                    $linkText .= ' <span style="color: red;">(inaktiv)</span>';
                    $temp_pfb70_link->elements[0]->text = $linkText;
                    $aktion70[] = $temp_pfb70_link;
                } else {
                    $aktion70[] = $temp_pfb70_link;
                }
                
                $aktion_kurz.=$form->submit2('pf['.$row[0].']', _PROBEFAHRT_, 'style="'.$but_style.'" onClick="'.$zusabfr1_pf.'k_inhalt(\''.$phs.'?ajax=1&pf='.$row[0].'\', true, '.$dbr.', '.$dho.'); return false;"');
			} elseif ($akt_kl2 and $cfg_kfzsuche_kv_vfw_mw_pf and ($row[56]=='2' or $row[56]=='6') and !$keine_pf) {
				$aktion.=' '.$form->submit2('pf2'.$row[0], _PROBEFAHRT_, 'onClick="'.$zusabfr1_pf.' k_inhalt(\''.$phs.'?ajax=1&pf='.$row[0].'\', true, '.$dbr.', '.$dho.'); try{new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} catch(e) {}"');
                
                $linkText = _PROBEFAHRT_;
                if ($isInactive) {
                    $linkText = '<span style="color: lightgrey;">'._PROBEFAHRT_.'</span> ';
                    $linkText .= '<span style="color: red;">(inaktiv)</span>';
                }
                $aktion70[] = Template_Link::init($linkText, '', '', '', ' onClick="'.$zusabfr1_pf.'"')
                    ->setRequest($art = 'GET', $kfzdetails_modal_inhalt, $url = 'kfzsuche.php', $werte = 'options_menu=0&ajax=1&pf='.$row[0], $callback = array($kfzdetails_modal));
                
                $temp_pfb70_link = clone $pfb70_link;
                Template_Trait_Obj_Helper::strreplace($temp_pfb70_link, '{fzid}', $row[0]);
                if ($isInactive) {
                    $linkText = '<span style="color: lightgrey;">'.$temp_pfb70_link->elements[0]->text.'</span>';
                    $linkText .= ' <span style="color: red;">(inaktiv)</span>';
                    $temp_pfb70_link->elements[0]->text = $linkText;
                    $aktion70[] = $temp_pfb70_link;
                } else {
                    $aktion70[] = $temp_pfb70_link;
                }
                
                $aktion_kurz.=$form->submit2('pf['.$row[0].']', _PROBEFAHRT_, 'style="'.$but_style.'" onClick="'.$zusabfr1_pf.' k_inhalt(\''.$phs.'?ajax=1&pf='.$row[0].'\', true, '.$dbr.', '.$dho.'); return false;"');
			}
            
			$aktion.=$aktion4; //tooltip in design70 weiter oben
			$aktion_kurz.=$aktion4;
			
			$zuspreis='';
            $zuspreis70='';
			// Diffbest:
			if ($row[35]=='1') {
				$zuspreis='<br><font size=1>'._DIFFBEST_.'</font>';
                $zuspreis70=_DIFFBEST_;
				//	Differenzsteuer = Verkaufsbetrag = VK-(VK-EK)/1.19 (nur zur Info)
				//  bruttoertrag: VK - (EK/1.19) - WEM
				// Verkaufspreis-Einkaufspreis/Ergebnis :1,19 UST/Ergebnis -WEM = Bruttoertrag.
			} else {
				$zuspreis='<br><font size=1>'._REGELBEST_.'</font>';
                $zuspreis70=_REGELBEST_;
			}

			if ($cfg_kfzsuche_auszpreis) {
				if (doubleval($row[60])>0) {
					$row[15]=$row[60];
				}
			}
			$m_preis1=0;
			if ($row[54]!='') {
				if ($row[56]=='2' and doubleval($row[7])>0) {
					$m_preis1=doubleval($row[15]);
					$row[15]=doubleval($row[7]);
				}
			}
			
			$m_waehrung_eur=$waehrung_eur;
			if ($cfg_ws_avag_kroatien) {
				$waehrung_eur='Kn';
			}
			$preis='<table>';
			$preis.='<tr><td>'._AKTUELLERVKPREIS_.'</td><td>'.number_format(doubleval($row[15]), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
			if ($cfg_kfzsuche_kein_wem) {
				
			} else {
				$preis.='<tr><td>WEM</td><td>'.number_format(doubleval($row[16]), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
			}
			if ($kein_ek or $cfg_kfzsuche_kein_ekpreis or ($cfg_kfzsuche_kein_ekpreis_nichtadmin and $_SESSION['user_gruppe']<2)) {

			} else {
				$preis.='<tr><td>'._EKPREIS_.'</td><td>'.number_format(doubleval($row[14]), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				$preis.='<tr><td>&nbsp;</td></tr>';
			}
			$bruttoertrag=doubleval($row[15])/(1+$cfg_mwst)-doubleval($row[16])-doubleval($row[14]);
			if ($row[35]=='1') {
				//$bruttoertrag=doubleval($row[15])-doubleval($row[14])/1.19-doubleval($row[16]);
				$bruttoertrag=(doubleval($row[15])-doubleval($row[14]))/(1+$cfg_mwst)-doubleval($row[16]);
			}
			if ($cfg_kfzsuche_kein_be or ($cfg_kfzsuche_kein_be_nichtadmin and $_SESSION['user_gruppe']<2)) {

			} else {
				$preis.='<tr><td>'._BRUTTOERTRAG_.'</td><td>'.number_format(doubleval($bruttoertrag), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				$preis.='<tr><td>&nbsp;</td></tr>';
			}
			if ($cfg_kfzsuche_keine_kalkkosten) {

			} else {
				$preis.='<tr><td>'._KALKKOSTEN_.'</td><td>'.number_format(doubleval($row[41]), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
			}
			if (doubleval($row[98])>0) {
				$preis.='<tr><td>'._HAUSPREIS_.' '._MANUELL_.'</td><td>'.number_format(doubleval($row[98]), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
			}
			
			
			if ($cfg_kfzsuche_marginkalk2) {
				$preis='<table>';
				$ist_diffb=false;
				if ($row[35]=='1') {	// Diff.best.
					$ist_diffb=true;
				}
				$beneu=doubleval($row[15]);
				$beneu2=doubleval($row[15])/(1+$cfg_mwst);
				if ($ist_diffb) {
					$preis.='<tr><td>'._AKTUELLERVKPREIS_.'</td><td>'.number_format(doubleval($row[15]), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				} else {
					$preis.='<tr><td>'._AKTUELLERVKPREIS_.'</td><td>'.number_format(doubleval($row[15]), 2, ',', '.').' '.$waehrung_eur.''.'</td><td>'.number_format($beneu2, 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				}
				if ($ist_diffb) {
					$beneu-=doubleval($row[14]);
				} else {
					$beneu-=doubleval($row[14])*(1+$cfg_mwst);
				}
				$beneu2-=doubleval($row[14]);
				if ($ist_diffb) {
					$preis.='<tr><td>'._EKPREIS_.'</td><td>-'.number_format(doubleval($row[14]), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				} else {
					$preis.='<tr><td>'._EKPREIS_.'</td><td>-'.number_format(doubleval($row[14])*(1+$cfg_mwst), 2, ',', '.').' '.$waehrung_eur.''.'</td><td>-'.number_format(doubleval($row[14]), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				}
				
				$standkosten=doubleval($row[16]);
				$intkosten=0;
				$intkostenbez='';
				$vkhilfen=0;
				$vkhilfenbez='';
				$beneu-=doubleval($standkosten);
				$beneu2-=doubleval($standkosten)/(1+$cfg_mwst);
				if ($ist_diffb) {
					$preis.='<tr><td>'.'interne Kosten (Standkosten)'.'</td><td>-'.number_format(doubleval($standkosten), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				} else {
					$preis.='<tr><td>'.'interne Kosten (Standkosten)'.'</td><td>-'.number_format(doubleval($standkosten), 2, ',', '.').' '.$waehrung_eur.''.'</td><td>-'.number_format(doubleval($standkosten)/(1+$cfg_mwst), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				}
				
				if (isset($alle_kfzzu[strtolower($row[1])])) {
					$typm2=$row[2];
					$expl2=preg_split('/\W/', $typm2);
					$typm2=trim($expl2[0]);
					$kfzzid=0;
					@reset($alle_kfzzu[strtolower($row[1])]);
					while ($kfzzid==0 and list($keym, $valm)=@each($alle_kfzzu[strtolower($row[1])])) {
						if (preg_match('/'.$typm2.'/i', $keym)) {
							$kfzzid=intval($valm);
						}
					}
					if ($kfzzid>0) {
						if (isset($alle_kfzzu3[$kfzzid])) {
							@reset($alle_kfzzu3[$kfzzid]);
							while (list($keym, $valm)=@each($alle_kfzzu3[$kfzzid])) {
								if ($valm[6]=='1') {
									$intkosten+=doubleval($valm[2]);
									$intkostenbez.=$valm[1].', ';
								} else {
									$vkhilfen+=doubleval($valm[2]);
									$vkhilfenbez.=$valm[1].', ';
								}
							}
						}
					}
				}
				if ($intkosten>0) {
					$intkostenbez=substr($intkostenbez, 0, -2);
					$beneu-=doubleval($intkosten);
					$beneu2-=doubleval($intkosten)/(1+$cfg_mwst);
					if ($ist_diffb) {
						$preis.='<tr><td>'.'interne Kosten ('.$intkostenbez.')'.'</td><td>-'.number_format(doubleval($intkosten), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
					} else {
						$preis.='<tr><td>'.'interne Kosten ('.$intkostenbez.')'.'</td><td>-'.number_format(doubleval($intkosten), 2, ',', '.').' '.$waehrung_eur.''.'</td><td>-'.number_format(doubleval($intkosten)/(1+$cfg_mwst), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
					}
				}
				if ($ist_diffb and $beneu>=0) {
					$mbeneu=$beneu;
					$usteuer=$beneu*$cfg_mwst;
					$beneu-=doubleval($usteuer);
					$preis.='<tr><td>'.'MwSt'.'</td><td>-'.number_format(doubleval($usteuer), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				}
				if ($vkhilfen>0) {
					$vkhilfenbez=substr($vkhilfenbez, 0, -2);
					$beneu+=doubleval($vkhilfen);
					$beneu2+=doubleval($vkhilfen)/(1+$cfg_mwst);
					$preis.='<tr><td>'.'Verkaufshilfen ('.$vkhilfenbez.')'.'</td><td>+'.number_format(doubleval($vkhilfen), 2, ',', '.').' '.$waehrung_eur.''.'</td><td>+'.number_format(doubleval($vkhilfen)/(1+$cfg_mwst), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				}
				if ($ist_diffb) {
					$preis.='<tr><td>'._BRUTTOERTRAG_.'</td><td>'.number_format(doubleval($beneu), 2, ',', '.').' '.$waehrung_eur.''.'</td><td>'._NETTO_.': '.number_format(doubleval($beneu)/(1+$cfg_mwst), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				} else {
					$preis.='<tr><td>'._BRUTTOERTRAG_.'</td><td>'.number_format(doubleval($beneu), 2, ',', '.').' '.$waehrung_eur.''.'</td><td>'.number_format(doubleval($beneu2), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				}
			}
			
			if ($cfg_carlo_import_limitpreis) {
				$preis.='<tr><td>Limitpreis</td><td>'.number_format(doubleval($row[91]), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_dello' or $_SESSION['cfg_kunde']=='carlo_opel_duerkop') {
				$preis.='<tr><td>H�ndlerpreis</td><td>'.number_format(doubleval($row[7]), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
			}
			
			$zusdetails2='';
			if ($s4c_neu) {
				$nova_ver='';
				if ($row[92]=='1') {
					$nova_ver=_JA_;
				}
				if ($row[92]=='0') {
					$nova_ver=_NEIN_;
				}
				$preis.='<tr><td>NoVA abgef�hrt:</td><td>'.$nova_ver.'</td></tr>';
				if ($cfg_novap_bm_natc) {
					if ($cfg_mboe_vorlagen or $s4c_neu) {
						$anz_co2=$row['abgas_cozwei'];
						$anz_nova=$row['brutto_ertrag_proz'];
						$anz_bonus=$row['bonus_malus'];
						if (intval($row['abgas_nox'])>0) {
							$anz_co2=$row['abgas_nox'];
							$anz_nova=$row['brutto_ertrag_mw'];
							$anz_bonus=$row['abgas_partikel'];
						}
						$preis.='<tr><td>NoVA %:</td><td>'.number_format(doubleval($anz_nova), 2, ",", "").' % (CO2: '.$anz_co2.')</td></tr>';
						$preis.='<tr><td>Bonus/Malus:</td><td>'.number_format(doubleval($anz_bonus), 2, ",", "").'</td></tr>';
					} else {
						$preis.='<tr><td>NoVA %:</td><td>'.number_format(doubleval($row[93]), 2, ",", "").' %</td></tr>';
						$preis.='<tr><td>Bonus/Malus:</td><td>'.number_format(doubleval($row[90]), 2, ",", "").'</td></tr>';
					}
					if ($row[95]!='') {
						$zusdetails2.=' / Nat. Code: '.$row[95];
					}
				}
				if ($cfg_behaltefrist) {
					$preis.='<tr><td>Behaltefrist:</td><td>'.$db->unixdate($row[97]).'</td></tr>';
				}
			}
			
			
			if ($_SESSION['cfg_kunde']=='carlo_opel_neff') {
				$preis.='<tr><td>&nbsp;</td></tr>';
				$preis.='<tr><td>Text 2:</td><td>'.$row[77].'</td></tr>';
				$preis.='<tr><td>Text 3:</td><td>'.$row[46].'</td></tr>';
			}

			if ($cfg_kfzsuche_preispopup_zusatztext1 or $cfg_kfzsuche_preispopup_zusatztext2 or $cfg_kfzsuche_preispopup_zusatztext3 or $cfg_kfzsuche_preispopup_zusatztext4) {
				$preis.='<tr><td>&nbsp;</td></tr>';
			}
			if ($cfg_kfzsuche_preispopup_zusatztext1) {
				$preis.='<tr><td>Text 1:</td><td>'.$row[57].'</td></tr>';
			}
			if ($cfg_kfzsuche_preispopup_zusatztext2) {
				$preis.='<tr><td>Text 2:</td><td>'.$row[77].'</td></tr>';
			}
			if ($cfg_kfzsuche_preispopup_zusatztext3) {
				$preis.='<tr><td>Text 3:</td><td>'.$row[46].'</td></tr>';
			}
			if ($cfg_kfzsuche_preispopup_zusatztext4) {
				$preis.='<tr><td>Text 4:</td><td>'.$row[30].'</td></tr>';
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_kramm') {
				$preis.='<tr><td>Dezimal 1:</td><td>'.number_format(doubleval($row[84]), 2, ",", ".").'</td></tr>';
				$preis.='<tr><td>Dezimal 2:</td><td>'.number_format(doubleval($row[76]), 2, ",", ".").'</td></tr>';
			}
			$preis.='</table>';
			$waehrung_eur=$m_waehrung_eur;

			if ($row[54]!='') {
				$preis.='<br>'.$row[54].' ('.$row[7].')';
				if ($m_preis1>0) {
					$preis.=' - normal: '.number_format(doubleval($m_preis1), 2, ",",".");
				}
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_toennemann') {
				$preis.='<br>UPE: '.number_format(doubleval($row[58]), 2, ",",".").' '.$waehrung_eur.'';
			}
			if (intval($row[72])>0) {
				$preis.='<br>'._LISTENPREIS_.' '._INKL_.' '._STEUER_.': '.number_format(doubleval($row[72]), 2, ",",".").' '.$waehrung_eur.'';
			}

			if ($s4c_neu) {
			//	$preis.='<br>'._LISTENPREIS_.' inkl. Steuern: '.number_format($row[74], 2, ",",".").' ';	// MINDESTVK
			//	$preis.='<br>'.'VK-Preis inkl. Steuern: '.number_format($row[81], 2, ",",".").' ';	// EKPREIS neuester
			}

			$waehr='&euro;';
			if ($cfg_ws_avag_kroatien) {
				$waehr='Kn';
			}
			if ($cfg_kfzsuche_norway) {
				$waehr='NOK';
			}
			if ($cfg_gmekonf_land=='CH') {
				$waehr='CHF';
			}
			
			if ($cfg_greek) {
				$preis='<table>';
				$preis.='<tr><td>'._AKTUELLERVKPREIS_.'</td><td>'.number_format(doubleval($row[15]), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				$preis.='<tr><td>'._LOCALTAX_.'</td><td>'.number_format(doubleval($row[90]), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				$preis.='<tr><td>'._LISTENPREIS_.' '._INKL_.' '._STEUER_.'</td><td>'.number_format(doubleval($row[90])+doubleval($row[15]), 2, ',', '.').' '.$waehrung_eur.''.'</td></tr>';
				$preis.='</table>';
			}
			
			if ($cfg_kfzsuche_keinpreispopup) {
				$preis=number_format(doubleval($row[15]), 2, ',', '.').' '.$waehr.$zuspreis;
                $preis70=number_format(doubleval($row[15]), 2, ',', '.').' '.$waehr;
			} else {
				$preis=oltext(str_replace(array("'", '&#39;'), ' ', $preis), number_format(doubleval($row[15]), 2, ',', '.').' '.$waehr.$zuspreis);
                $preis70=number_format(doubleval($row[15]), 2, ',', '.').' '.$waehr;
			}
			if ($cfg_kein_ekpreis) {
				$preis=number_format(doubleval($row[15]), 2, ',', '.').' '.$waehrung_eur.$zuspreis;
                $preis70=number_format(doubleval($row[15]), 2, ',', '.').' '.$waehrung_eur;
			}
			
			if ($s4c_neu) {
				$cfg_kfzsuche_preisrechner=false;
			}
			
			if ($cfg_kfzsuche_preisrechner) {
				$vorg_vkh_r=0;
				if ($cfg_kfzsuche_vkh_manuell_rechner) {
					$vorg_vkh_r+=doubleval($row[91]);
					$vorg_vkh_r+=doubleval($row[74]);
					$vorg_vkh_r+=doubleval($row[58]);
				}
				$prk1=$row[15];
				$prk2=$row[14];
				$prk3=$row[16];
				$prk4=$row[41];
				$prk5='';
				$prk6='';
				if ($cfg_kfzsuche_vkh_manuell_rechner) {
					$prk6=$vorg_vkh_r;
				}
				if ($row[86]!='') {
					$xpl1=explode(';', $row[86]);
					$prk1=$xpl1[0];
					$prk2=$xpl1[1];
					$prk3=$xpl1[2];
					$prk4=$xpl1[3];
					$prk5=str_replace('_SEMI_', ';', $xpl1[4]);
					$prk6=$xpl1[5];
				}
				$preis.=link2('Calc', 'javascript: oeffne_rechner(\''.number_format(doubleval($prk1), 2, ",", ".").'\', \''.number_format(doubleval($prk2), 2, ",", ".").'\', \''.number_format(doubleval($prk3), 2, ",", ".").'\', \''.number_format(doubleval($prk4), 2, ",", ".").'\', \''.$row[35].'\', \''.$prk5.'\', \''.$row[0].'\', \''.number_format(doubleval($prk6), 2, ",", ".").'\');', 'fragezeichen.gif');
			}

			$details_dvs='';
			if ($ist_dvskfz) {
				if ($_SESSION['cfg_kunde']=='carlo_opel_dello' or $_SESSION['cfg_kunde']=='carlo_opel_duerkop' or $_SESSION['cfg_kunde']=='carlo_opel_haeusler') {
					$preis=oltext('Angebotspreis: '.number_format(doubleval($row[15]), 2, ",", ".").' '.$waehrung_eur.'<br>'.'Internetpreis: '.number_format(doubleval($row[7]), 2, ",", ".").' '.$waehrung_eur.'<br>'.'Haendlerpreis: '.number_format(doubleval($row[71]), 2, ",", ".").' '.$waehrung_eur.'', number_format(doubleval($row[15]), 2, ",", ".").' '.$waehrung_eur).$zuspreis;
				} else {
					$preis=oltext('Angebotspreis: '.number_format(doubleval($row[7]), 2, ",", ".").' '.$waehrung_eur.'<br>'.'Internetpreis: '.number_format(doubleval($row[15]), 2, ",", ".").' '.$waehrung_eur.'<br>'.'Haendlerpreis: '.number_format(doubleval($row[71]), 2, ",", ".").' '.$waehrung_eur.' NETTO', number_format(doubleval($row[15]), 2, ",", ".").' '.$waehrung_eur);
				}
				if ($_SESSION['cfg_kunde']=='carlo_opel_dello' or $_SESSION['cfg_kunde']=='carlo_opel_duerkop' or $_SESSION['cfg_kunde']=='carlo_opel_haeusler') {
					if ($cfg_dvs_fm) {
						$details_dvs=' '.oltext($row[94], 'FM', 'javascript: k_inhalt(\''.$phs.'?fuid='.$row[47].'&dvsdetail=1\', true, '.$dbr.', '.$dho.');', 'FM');
						$details_dvs.=' | '.link2('Expos�', $phs.'?fmexpose='.base64_encode($row[47]), '', '', 'target="fmexposewindow"');
					} else {
						$details_dvs=' '.oltext($row[94], 'DVM', 'javascript: k_inhalt(\''.$phs.'?fuid='.$row[47].'&dvsdetail=1\', true, '.$dbr.', '.$dho.');', 'DVM');
					}
				} else {
					$details_dvs=' '.oltext('Klick f�r Details DVS', 'DVS', 'javascript: k_inhalt(\''.$phs.'?fuid='.$row[47].'&dvsdetail=1\', true, '.$dbr.', '.$dho.');', 'DVS');
				}
			}
			
			if ($cfg_kfzsuche_dd2020) {
				$listedd=doubleval($row['vkpreis'])+doubleval($row['ekpreis_neuester']);
				$preisdd='<table><tr><td>UPE lt. Hersteller netto:</td><td style="text-align: right;">'.number_format(doubleval($row['vkpreis_dbberechnung']), 2, ",", ".").' '.$waehrung_eur.'</td></tr>';
				$ddmwst=doubleval($row['vkpreis_dbberechnung'])*$cfg_mwst;
				$preisdd.='<tr><td>Mehrwertsteuer ('.($cfg_mwst*100).' %):</td><td style="text-align: right;">'.number_format(doubleval($ddmwst), 2, ",", ".").' '.$waehrung_eur.'</td></tr>';
				$preisdd.='<tr><td>Frachtkosten:</td><td style="text-align: right;">'.number_format(doubleval($row['ekpreis_neuester']), 2, ",", ".").' '.$waehrung_eur.'</td></tr>';
				$preisdd.='</table>';
				$preis.='<br>'.oltext($preisdd, number_format(doubleval($listedd), 2, ",", ".").' '.$waehrung_eur);
			} elseif ($cfg_kfzsuche_sortlistenpreis) {
				$preis.='<br>'.number_format(doubleval($row[72]), 2, ",", ".").' '.$waehrung_eur;
			}
			
			if ($cfg_kfzsuche_suche_minderwertmanuell and doubleval($row[74])>0) {
				$preis.='<br>'.number_format(doubleval($row[74]), 2, ",", ".").' '.$waehrung_eur;
			}
			
			$markenc=$row[1];
			$m_markenc=$markenc;
			$markencz='';
			if ($row[9]!='') {
				$markencz.=_ALTERDEB_.': '.$row[9].' ';
			}
			if ($row[38]!='') {
				$markencz.=_VORBESITZER_.': '.$row[38].' ';
			}
			if ($row[39]!='') {
				$markencz.='<br>'._KTYP15_.': '.$row[39].' ';
			}
			if ($markencz!='') {
				$markenc=oltext($markencz, $markenc);
			}
			
			if ($_SESSION['cfg_kunde']=='carlo_opel_huebner') {
				if ($row[82]!='' and $row[82]!='DE0621') {
					$markenc.=' / LH: '.$row[82];
				}
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_lautsch') {
				if ($row[82]!='') {
					$markenc.=' / <font size=1>'.$row[82].'</font>';
				}
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_dello') {
				if ($row[82]!='') {
					$markenc.=' / <font size=1>ID '.$row[82].'</font>';
				}
				if ($row[87]!='') {
					$markenc.=' / <font size=1>Lagerstatus: '.$row[87].'</font>';
				}
			}
			if ($cfg_kfzsuche_ergebnis_zusatzcrm1) {
				if (!empty($interfacesList[$row[0]])) {
                    $markenc .= '<br>ID: ';
                    $tmp = array();
				    foreach ($interfacesList[$row[0]] as $interface => $interfaceId) {
				        $tmp[] = '<span style="color:'.(strstr($interface, '_inactive') ? 'red' : 'green').'" title="'.$interface.'">'.$interfaceId.'</span>';
                    }
                    $markenc .= implode(',', $tmp);
                } else if ($row[82]!='') {
                    $markenc.='<br>ID: '.$row[82];
                }
			}
			if ($cfg_mboe_vorlagen) {
				if ($row[47]!='') {
					$markenc.='<br>Komm.Nr.: '.$row[47];
				}
			}
			if ($cfg_kfzsuche_keinlagerort) {
				$mandtext='<br><font size=1>'.$row[27].'</font>';
			} else {
				$mandtext='<br><font size=1>'.$row[27].' / '.($cfg_kfzsuche_ergebnis_mandant?$alle_mands[$row[83]].' - ':'').$alle_mands[$row[23]].'</font>';
                $mandtext70=$row[27].(!empty($row[27])?' / ':'').($cfg_kfzsuche_ergebnis_mandant?$alle_mands[$row[83]].' - ':'').$alle_mands[$row[23]];
			}
			if ($_SESSION['cfg_kunde']!='carlo_opel_dello' and $_SESSION['cfg_kunde']!='carlo_opel_duerkop' and $row[56]=='30' and $row[57]!='') {
				$mandtext.='<br><font color=red>Transportauftrag: '.$row[57].'</font>';
			}

			$zzus='';
            $zzus70='';
			if ($cfg_kfzsuche_reservierung_nuradmin and $_SESSION['user_gruppe']<2) {
				$cfg_kfzsuche_keinereservierung=true;
			}
			
			$keine_res2=false;
			if (isset($retailer_prefix) and intval($retailer_prefix)>0 and intval($row[83])==$cfg_kfz_webservice_mandant) {
				$keine_res2=true;
			}
			
			$laokeineres=false;
			if (isset($cfg_kfzsuche_dbrent_reslao)) {
							$laokeineres=true;
							if (isset($cfg_kfzsuche_dbrent_reslao[$row[46]])) {
								if (intval($_SESSION['user_standard_lagerort'])>0) {
									if (intval($_SESSION['user_standard_lagerort'])==$cfg_kfzsuche_dbrent_reslao[$row[46]]) {
										$laokeineres=false;
									}
								}
							}
			}
			if ($laokeineres) {
				$keine_res2=true;
			}
			
			if ($cfg_dvs) {
						if (!$cfg_dvs_fm and $ist_dvskfz and ($row[55]=='Auktion vorgesehen' or $row[55]=='Premiumaktion vorgesehen' or $row[55]=='Ausschreibung')) {
							$keine_dvs_res=true;	// keine Res.
							if (isset($row['factory_exp'])) {
								$rts=$db->unixdate_ts($row['factory_exp']);
								if (adodb_date('Y', $rts)=='1900' or $row['factory_exp']=='') {
									$keine_dvs_res=false;
								} else {
									$bis_res=$rts-3*24*60*60;
									$bis_res=adodb_mktime(23,59,59, adodb_date('m', $bis_res), adodb_date('d', $bis_res), adodb_date('Y', $bis_res));
									if (time()<=$bis_res) {
										// Res. noch bis 3 Tage vor Ende
										$keine_dvs_res=false;
									}
								}
							} else {
								$keine_dvs_res=false;
							}
							if ($keine_dvs_res) {
								$keine_res2=true;
							}
						}
			}
			
			if (!$akt_kl2 and !$akt_kl3 and !$akt_kl4 and !$cfg_kfzsuche_keinereservierung and !$loc_reserv and !$keine_res2) {
				if ($cfg_kfzsuche_reservierung_frei) {
					$aktion.=' / '.link2(($cfg_kfzsuche_buttons_abk?'Res.':_RESERVIERUNG_), 'javascript: oeffne_resform(\''.$row[0].'\', 0,  \''.$row[21].'\');');
					$aktion70[]=new Template_Link(($cfg_kfzsuche_buttons_abk?'Res.':_RESERVIERUNG_), 'javascript: oeffne_resform(\''.$row[0].'\', 0,  \''.$row[21].'\');');
                    $aktion_kurz.=$form->submit2('reserv['.$row[0].']', _RESERVIERUNG_, 'style="'.$but_style.'" onClick="oeffne_resform(\''.$row[0].'\', 0,  \''.$row[21].'\'); return false;"');
				} else {
					$aktion.=' / '.link2(($cfg_kfzsuche_buttons_abk?'Res.':_RESERVIERUNG_), $phs.'?res='.$row[0], '', '', 'onClick="return confirm(\''._RESERVIERUNG_.'?\');"');
					$aktion70[]=new Template_Link(($cfg_kfzsuche_buttons_abk?'Res.':_RESERVIERUNG_), $phs.'?res='.$row[0], '', '', 'onClick="return confirm(\''._RESERVIERUNG_.'?\');"');
                    $aktion_kurz.=$form->submit2('reserv['.$row[0].']', _RESERVIERUNG_, 'style="'.$but_style.'" onClick="if (confirm(\''._RESERVIERUNG_.'?\')) { window.open(\''.$phs.'?res='.$row[0].'\', \'main\'); } return false;"');
				}
			}
			// reserviert?
			if (intval($row[28])>0) {
				$rdatum=$db->unixdate_ts($row[29]);
				if ($row[44]!='') {
					$zielz=$db->unixdate_ts($row[44]);
				} else {

				$rstd=48;
				if (isset($cfg_kfzsuche_reservierung_stunden)) {
					$rstd=$cfg_kfzsuche_reservierung_stunden;
				}

				$zielz=$rdatum+$rstd*60*60;
				$sdat=$rdatum;
				while ($sdat<=$zielz) {
					if (adodb_date('w', $sdat)==0 or adodb_date('w', $sdat)==6) {
						if ($cfg_kfzsuche_reservierung_nursonntag and adodb_date('w', $sdat)==6) {
						} else {
							$zielz+=24*60*60;
						}
					}
					$sdat+=24*60*60;
				}
				}

				$res_zusname='';
				if ($cfg_kfzsuche_reservierung_frei or $cfg_kfzsuche_resfrei_gruppe) {
					$res5=$db->select(
						$sql_tab['produktzuordnung'],
						$sql_tabs['produktzuordnung']['reservierung_name'],
						$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($row[0])
					);
					$row5=$db->zeile($res5);
					$res_zusname=' - '.$row5[0];
				}

				if (time() > $zielz) {
					// Reservierung nach x Stunden l�schen:
					$db->update(
						$sql_tab['produktzuordnung'],
						array(
							$sql_tabs['produktzuordnung']['reservierung'] => $db->dbzahl(0),
							$sql_tabs['produktzuordnung']['reservierung_datum'] => $db->dbtimestamp(null),
							$sql_tabs['produktzuordnung']['reservierung_bisdatum'] => $db->dbtimestamp(null)
						),
						$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($row[0])
					);
					if ($cfg_kfzsuche_reservierung_frei) {
						$db->update(
							$sql_tab['produktzuordnung'],
							array(
								$sql_tabs['produktzuordnung']['reservierung_name'] => $db->str('')
							),
							$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($row[0])
						);
					}
				} else {
					$zzus='class="red" style="'.($cfg_modern?'':'background-color: red;').'"';
                    $zzus70='red';
					$aktion=_RESERVIERT_.' ('._BIS_.' '.adodb_date('d.m.Y H:i', $zielz).' '._VON_.': '.$alle_bens[$row[28]].')'.$res_zusname;
                    $aktion70_tooltip=_RESERVIERT_.' ('._BIS_.' '.adodb_date('d.m.Y H:i', $zielz).' '._VON_.': '.$alle_bens[$row[28]].')'.$res_zusname;
                    $aktion70=array();
                    
					if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
						$aktion.='/ '.$vml.' ';
                        $aktion70_tooltip.='/ '.$vml.' ';
					}
					if ($cfg_kfz_pf_aktiv and $row[90]!='') {
						$aktion.=' - '.$row[90];
                        $aktion70_tooltip.=' - '.$row[90];
					}
					if ($cfg_kfzsuche_res_overlib) {
						$aktion=oltext($aktion, p4n_mb_string('substr', _RESERVIERUNG_, 0, 3).'.');
					}
					$aktion_kurz=_RESERVIERT_.' ('._BIS_.' '.adodb_date('d.m.Y H:i', $zielz).' '._VON_.': '.$alle_bens[$row[28]].')'.$res_zusname;
					$ist_eigene_res=false;
					if ($row[28]==$_SESSION['user_id'] or $_SESSION['user_gruppe']==2) {
						$ist_eigene_res=true;
						if ($cfg_kfzsuche_res_overlib) {
							$aktion.=' '.link2(_LOESCHEN_.': '._RESERVIERUNG_, $phs.'?resl='.$row[0].'&resl_vin='.$row[21], 'loesch.gif', '', 'onClick="return confirm(\''._LOESCHEN_.': '._RESERVIERUNG_.'?\');"');
                            $aktion70[]=new Template_Link(_LOESCHEN_.': '._RESERVIERUNG_, $phs.'?resl='.$row[0].'&resl_vin='.$row[21], '', '', 'onClick="return confirm(\''._LOESCHEN_.': '._RESERVIERUNG_.'?\');"');
                        } else {
							$aktion.='<br>'.link2(_LOESCHEN_.': '._RESERVIERUNG_, $phs.'?resl='.$row[0].'&resl_vin='.$row[21], '', '', 'onClick="return confirm(\''._LOESCHEN_.': '._RESERVIERUNG_.'?\');"');
                            $aktion70[]=new Template_Link(_LOESCHEN_.': '._RESERVIERUNG_, $phs.'?resl='.$row[0].'&resl_vin='.$row[21], '', '', 'onClick="return confirm(\''._LOESCHEN_.': '._RESERVIERUNG_.'?\');"');
                        }
						$aktion_kurz.=$form->submit2('resloe['.$row[0].']', _LOESCHEN_.' '._RESERVIERUNG_, 'style="'.$but_style.'" onClick="if (confirm(\''._LOESCHEN_.': '._RESERVIERUNG_.'?\')) { window.open(\''.$phs.'?resl='.$row[0].'\', \'main\'); return false; }"');//'<br>'.link2(_LOESCHEN_.': '._RESERVIERUNG_, $phs.'?resl='.$row[0], '', '', 'onClick="return confirm(\''._LOESCHEN_.': '._RESERVIERUNG_.'?\');"');
					}
					if ($ang_kv_info!='') {
						$ang_kv_info=str_replace('=red', '=black', $ang_kv_info);
						$aktion.='<br>'.$ang_kv_info;
                        $aktion70_tooltip.='<br>'.$ang_kv_info;
						$aktion_kurz.='<br>'.$ang_kv_info;
					}
					if ($cfg_kfzsuche_ang_expose) {
						$aktion.=$form->submit2('expo'.$row[0], _EXPOSE_, 'onClick="'.$zusabfr1.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&expo='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_summe(); try{new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} catch(e) {}"');
						$aktion70[]=Template_Link::init(_EXPOSE_,'','','','onClick="'.$zusabfr1.'"')
                        ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&kfznl=1&expo='.$row[0],$callback=array($kfzdetails_modal,'rechne_summe();'));
                        
                        $aktion_kurz.=$form->submit2('expo1['.$row[0].']', _EXPOSE_, 'style="'.$but_style.'" onClick="'.$zusabfr1.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&expo='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_summe(); return false;"');
					}
					if ($cfg_kfzsuche_reserv_pf or ($ist_eigene_res and $cfg_kfzsuche_eigreserv_pf)) {
						if (!$keine_pf) {	//!$loc_reserv and !$loc_reserv_keinkv and
							$aktion.='<br>'.$form->submit2('ang'.$row[0], ($cfg_kfzsuche_buttons_abk?_PF_KURZ_:_PROBEFAHRT_), 'onClick=" k_inhalt(\''.$phs.'?ajax=1&pf='.$row[0].((isset($getfeld['vonlead']) or isset($postfeld['vonlead']))?'&vonlead=1':'').'\', true, '.$dbr.', '.$dho.');"');
                            
                            $linkText = ($cfg_kfzsuche_buttons_abk ? _PF_KURZ_ : _PROBEFAHRT_);
                            if ($isInactive) {
                                $linkText = '<span style="color: lightgrey;">'.$linkText.'</span> ';
                                $linkText .= '<span style="color: red;">(inaktiv)</span>';
                            }
                            $aktion70[] = Template_Link::init($linkText, '', '', '', '')
                                ->setRequest(
                                    'GET',
                                    $kfzdetails_modal_inhalt,
                                    'kfzsuche.php', 'options_menu=0&ajax=1&pf='.$row[0].((isset($getfeld['vonlead']) or isset($postfeld['vonlead'])) ? '&vonlead=1' : ''),
                                    array($kfzdetails_modal)
                                );
                            
                            $temp_pfb70_link = clone $pfb70_link;
                            Template_Trait_Obj_Helper::strreplace($temp_pfb70_link, '{fzid}', $row[0]);
                            if ($isInactive) {
                                $linkText = '<span style="color: lightgrey;">'.$temp_pfb70_link->elements[0]->text.'</span>';
                                $linkText .= ' <span style="color: red;">(inaktiv)</span>';
                                $temp_pfb70_link->elements[0]->text = $linkText;
                                $aktion70[] = $temp_pfb70_link;
                            } else {
                                $aktion70[] = $temp_pfb70_link;
                            }
                            
                            $aktion_kurz.='<br>'.$form->submit2('pf1['.$row[0].']', _PROBEFAHRT_, 'style="'.$but_style.'" onClick=" k_inhalt(\''.$phs.'?ajax=1&pf='.$row[0].((isset($getfeld['vonlead']) or isset($postfeld['vonlead']))?'&vonlead=1':'').'\', true, '.$dbr.', '.$dho.'); return false;"');
						}
					}
					if ($cfg_kfzsuche_reserv_ang or ($ist_eigene_res and $cfg_kfzsuche_eigreserv_ang)) {
						if (!$loc_reserv and !$loc_reserv_keinkv) {
							if (!$cfg_kfzsuche_reserv_pf) {
								$aktion.='<br>';
								$aktion_kurz.='<br>';
							}
							$aktion.=$form->submit2('ang'.$row[0], ($cfg_kfzsuche_buttons_abk?_ANG_KURZ_:_ANGEBOT_), 'onClick="'.$zusabfr1.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&angpfh=1&ang='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_summe(); try{new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} catch(e) {}"');
							
                            $aktion70[]=Template_Link::init(($cfg_kfzsuche_buttons_abk?_ANG_KURZ_:_ANGEBOT_),'','','','onClick="'.$zusabfr1.'"')
                            ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&kfznl=1&angpfh=1&ang='.$row[0],$callback=array($kfzdetails_modal,'rechne_summe();'));
                            
                            $aktion_kurz.=$form->submit2('ang1['.$row[0].']', _ANGEBOT_, 'style="'.$but_style.'" onClick="'.$zusabfr1.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&angpfh=1&ang='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_summe(); return false;"');
						}
					}
					
					if ($cfg_vvi2022 and $cfg_vvi2022_reserv) {
						$aktion.=$form->submit2('vvi'.$row[0], _VVI_, 'onClick="'.$zusabfr1.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&vvi='.$row[0].'\', true, '.$dbr.', '.$dho.'); try{new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} catch(e) {}"');
						
                        $aktion70[]=Template_Link::init(_VVI_,'','','','onClick="'.$zusabfr1.'"')
                            ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&kfznl=1&vvi='.$row[0],$callback=array($kfzdetails_modal));
                            
                        $aktion_kurz.=$form->submit2('vvi1['.$row[0].']', _VVI_, 'style="'.$but_style.'" onClick="'.$zusabfr1.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&vvi='.$row[0].'\', true, '.$dbr.', '.$dho.'); return false;"');
					}
					
					if ($cfg_kfzsuche_reserv_kv or ($ist_eigene_res and $cfg_kfzsuche_eigreserv_kv)) {
						if (!$loc_reserv and !$loc_reserv_keinkv) {
							if (!$cfg_kfzsuche_reserv_pf) {
								$aktion.='<br>';
								$aktion_kurz.='<br>';
							}
							$aktion.=$form->submit2('kv'.$row[0], ($cfg_kfzsuche_buttons_abk?_KV_KURZ_:_KAUFVERTRAG_), 'onClick="'.$zusabfr2.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&kv='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_summe();"');
							
                            $aktion70[]=Template_Link::init(($cfg_kfzsuche_buttons_abk?_KV_KURZ_:_KAUFVERTRAG_),'','','','onClick="'.$zusabfr2.'"')
                            ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&ajax=1&kfznl=1&kv='.$row[0],$callback=array($kfzdetails_modal,'rechne_summe();'));
                            
                            
                            $aktion_kurz.=$form->submit2('kv1['.$row[0].']', _KAUFVERTRAG_, 'style="'.$but_style.'" onClick="'.$zusabfr2.' k_inhalt(\''.$phs.'?ajax=1&kfznl=1&kv='.$row[0].'\', true, '.$dbr.', '.$dho.'); rechne_summe(); return false;"');
                        }
					}

					if (!$cfg_kfzsuche_keinekfzinfo) {
						$aktion.='<br>'.link2(($cfg_kfzsuche_buttons_abk?'FI':_FAHRZEUG_.' '._INFO_), $phs.'?info=1&pid='.$row[0], '','', 'target="status"');
						
                        $aktion70[]=new Template_Link(($cfg_kfzsuche_buttons_abk?'FI':_FAHRZEUG_.' '._INFO_), $phs.'?info=1&pid='.$row[0], '','', 'target="status"');
                        
                        $aktion_kurz.=$form->submit2('kfzinfo['.$row[0].']', _FAHRZEUG_.' '._INFO_, 'style="'.$but_style.'" onClick="window.open(\''.$phs.'?info=1&pid='.$row[0].'\', \'status\'); return false;"');
					}
					if (!$cfg_kfzsuche_keinepreisinfo) {
                        if (!$_SESSION['design_70'])
                        $aktion.=' / '.preisinfolink($row[0]).$finlink;

                        if ($_SESSION['design_70']) {
                            $preisinfolink=preisinfolink($row[0]);
                            if (is_array($preisinfolink)) {
                                 $aktion70=array_merge($aktion70,$preisinfolink);
                            } else {
                                 $aktion70[]=preisinfolink($row[0]);
                            }

                            $aktion70=array_merge($aktion70,$finlink70);
                        }

                        if (!$_SESSION['design_70'])
                        $aktion_kurz.=preisinfolink($row[0], true).$finlink2;
					}
				}
			}
            
            if (!empty($cfg_fzg_expose_link)) {
                $aktion .= ' / '.link2('Expose', $phs.'?expose='.$row[0], '', '', 'target="status"');
                $aktion70[] = new Template_Link(_EXPOSE_, $phs.'?expose='.$row[0], '', '', 'target="status"');
            }
            
            if (!empty($cfg_eautoseller) && file_exists('inc/'.$_SESSION['cfg_kunde'].'/fahrzeuge_detail35.html')) {
                $aktion .= ' / '.link2('Expose', 'javascript: k_inhalt(\'stammdaten_main.php?id='.$row[11].'&detail35=1&nur_labels=1&ohnep=1&nav=Fahrzeuge&pnr='.$row[0].'\', true, 900, 500);');//fahrgestell
                
                $aktion70[] = Template_Link::init(_EXPOSE_, '')
                    ->setRequest(
                        'GET',
                        $kfzdetails_modal_inhalt,
                        'stammdaten_main.php',
                        'options_menu=0&id='.$row[11].'&detail35=1&nur_labels=1&ohnep=1&nav=Fahrzeuge&pnr='.$row[0],
                        $kfzdetails_modal
                    );
            }
            
            if (!empty($cfg_alphacontroller_url)) {
                $aktion .= ' / '.$form->submit2('but_alphac_kfz', 'AC Fahrzeug', 'class="btn2" onClick="submitx(); window.open(\''.$cfg_alphacontroller_url.'/?thema=bridge&detail=vehicle&vin='.$row[21].'\', \'alphacontroller_kfz\');"');
                
                $aktion70[]=new Template_Link('AC Fahrzeug', '','','','onClick=" window.open(\''.$cfg_alphacontroller_url.'/?thema=bridge&detail=vehicle&vin='.$row[21].'\', \'alphacontroller_kfz\');"');
            }
			
			if ($cfg_vvi2022 && isset($rechte_['vvi_maengel'])) {
				$aktion .= ' / '.link2('VVI M�ngel', 'javascript: k_inhalt(\''.$phs.'?vvim='.$row[0].'\', true, 900, 500);');
                $aktion70[] = Template_Link::init('VVI M�ngel','','','','')
                    ->setRequest(
                        'GET',
                        $kfzdetails_modal_inhalt,
                        'kfzsuche.php',
                        'options_menu=0&vvim='.$row[0],
                        array($kfzdetails_modal)
                    );
			}
			
			$hat_paket_recht=false;
			$inpaketaktiv=false;
			if ($cfg_kfzsuche_pakete) {
				if (($row[21]!='' and isset($alle_paket_ids[trim($row[21])])) or ($row[47]!='' and isset($alle_paket_ids[trim($row[47])]))) {
					$pakbez=$alle_paket_ids[trim($row[21])];
					if ($pakbez=='') {
						$pakbez=$alle_paket_ids[trim($row[47])];
					}
					if (isset($getfeld['paket']) and $getfeld['paket']!='-1' and ($getfeld['paket']==$alle_paket_ids2[trim($row[21])] or $getfeld['paket']==$alle_paket_ids2[trim($row[47])])) {
						$aktion.='<br><font color=red>'._PAKET_.': '.$pakbez.'</font>';
                        $aktion70_tooltip.='<br><font color=red>'._PAKET_.': '.$pakbez.'</font>';
						$hat_paket_recht=true;
					} else {
						$inpaketaktiv=true;
						$aktion='<br><font color=red>'._PAKET_.': '.$pakbez.'</font>';
                        $aktion70_tooltip='<br><font color=red>'._PAKET_.': '.$pakbez.'</font>';
                        $aktion70=array();
					}
				}
			}

			if ($ist_dvskfz and $row[73]!='' and !$hat_paket_recht and !$cfg_dvs_fm) {
				$aktion=$maktion2.'<br><font color=red>'._PAKET_.': '.$row[73].'</font>';
                $aktion70_tooltip=$maktion2.'<br><font color=red>'._PAKET_.': '.$pakbez.'</font>';
                $aktion70=array();
				$inpaketaktiv=true;
			}
			
			if ($ist_dvskfz and !$cfg_dvs_fm and ($row[55]=='Auktion' or $row[55]=='Auktion vorgesehen' or $row[55]=='Premiumaktion vorgesehen' or $row[55]=='Ausschreibung')) {
				$anz_dvs_auktionsdat=$db->unixdate($row['factory_exp']);
				if (adodb_date('Y', $db->unixdate_ts($row['factory_exp']))==1900) {
					$anz_dvs_auktionsdat='noch nicht bekannt';
				}
				$aktion.='<br>Auktionsdatum: '.$anz_dvs_auktionsdat;
                $aktion70_tooltip.='<br>Auktionsdatum: '.$anz_dvs_auktionsdat;
			}
			
			$sortindex='';
			if ($sorto2=='10') {
				$sortindex=$standtage;
			} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['markencode']) {
							$sortindex=$row[1];
						} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['typ_modell']) {
							$sortindex=$row[2];
						} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['leistung_ps']) {
							$sortindex=intval($row[6]);
						} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['farbbezeichnung']) {
							$sortindex=$row[22];
						} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['datum_ez']) {
							$sortindex=$db->unixdate_ts($row[3]);
						} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['kennzeichen']) {
							$sortindex=$row[4];
						} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['km_stand']) {
							$sortindex=intval($row[5]);
						} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst']) {
							$sortindex=intval($row[15]);
						} else {
							$sortindex=intval($row[15]);
						}
//echo $sortindex.'<br>';
			$auzus='';
			if ($_SESSION['cfg_kunde']=='carlo_opel_toennemann') {
				if ($row[30]!='') {
					$auzus=' / '.trim($row[30]);
				}
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_neustadt' or $_SESSION['cfg_kunde']=='carlo_opel_lindenberg' or $_SESSION['cfg_kunde']=='carlo_opel_ruhrdeich') {
				if ($row[57]!='') {
					$auzus=' / '.trim($row[57]);
				}
			}
			if (intval($row[33])>0) {
				$auzus.=' / '._TUEREN_.': '.$row[33];
			}
			if (intval($row[36])>0) {
				$auzus.=' / '.$row[36].'ccm';
			}
			if (intval($row[37])>0) {
				$auzus.=' / '._EINKAEUFER_.': '.$alle_bens[$row[37]];
			}
			if (preg_match('/vorlauf/i', $row[12]) and $_SESSION['cfg_kunde']=='carlo_opel_tamsen') {
				$auzus.=' / Erw. Lieferd.: '.$db->unixdate($row[48]);
			}
			if ($row[40]!='') {
				$auzus.=' / '.$row[40];
			}
			if ($row[45]!='') {
				$auzus.=' / '.$row[45];
			}
			if ($row[46]!='') {
				$auzus.=' / '.$row[46];
			}
			if ($row[59]!='') {
				$auzus.=' / '.$row[59];
			}
			if ($cfg_kfzsuche_text2_ergebnis and $row[77]!='') {
				$auzus.=' / '.$row[77];
			}
			if ($cfg_kfzsuche_janein1) {
				$auzus.=' / '._FELD_.' 1: '.($row[78]=='1'?_JA_:_NEIN_);
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_haeusler') {
				if ($row[61]!='') {
					$auzus.=' / BN: '.trim($row[61]);
				}
				if ($row[62]!='') {
					$auzus.=' / KommN: '.trim($row[62]);
				}
				if ($row[63]!='') {
					$auzus.=' / H�.st: '.trim($row[63]);
				}
				if ($row[64]!='') {
					$auzus.=' / PBG: '.trim($row[64]);
				}
			} elseif ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
				if ($row[62]!='') {
					$auzus.=' / KommN: '.trim($row[62]);
				}
			} elseif ($cfg_kfzsuche_kommnr) {
				if ($row[62]!='') {
					$auzus.=' / KommN: '.trim($row[62]);
				}
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_dornig') {
				if ($row[63]!='') {
					$auzus.=' / H�.st: '.trim($row[63]);
				}
			}
			$ez_zus='';
			if (!$cfg_kfzsuche_italien and $row[53]!='') {
				$ez_zus=$db->unixdate($row[53]);
				if ($ez_zus!='') {
					if ($cfg_kfzsuche_abmeldedatum_ol) {
						$ez_zus='<br>'.oltext($ez_zus, 'Abmeld.');
					} else {
						$ez_zus='<br>'.oltext('Abmeldedatum', '<font color=red>'.$ez_zus.'</font>');
					}
				}
			}
			if ($cfg_kfzsuche_sortezundst or $_SESSION['cfg_kunde']=='carlo_opel_dello' or $_SESSION['cfg_kunde']=='carlo_opel_duerkop') {
				if ($row[3]!='' && $row[3]!='0000-00-00' && $row[3]!='1970-01-01') {
					$tageseit_ez=round((time()-$db->unixdate_ts($row[3]))/(24*60*60));
					$ez_zus.='<br>'.$tageseit_ez.' Tage seit EZ';
				}
			}
			$zus_stao='';
			if ($cfg_kfzsuche_text4_ma) {
				$zu_stao_t1=$row[30];
				$zu_stao_t2=p4n_mb_string('substr',$row[30], 0, 30).'..';
				if (isset($alle_bens5[$row[30]])) {
					$zu_stao_t1=$alle_bens5[$row[30]].' ('.$row[30].')';
					$zu_stao_t2=_VERKAEUFER_;
				}
				if ($row[30]!='') {
					$zus_stao='<br>'.oltext($zu_stao_t1, $zu_stao_t2, '', _VERKAEUFER_.' - Text 4');
				}
				if ($_SESSION['cfg_kunde']=='carlo_opel_duerkop' or $_SESSION['cfg_kunde']=='carlo_opel_dello') {
					$t41=$row[30];
					if ($_SESSION['cfg_kunde']=='carlo_opel_duerkop' and isset($alle_bens5[$row[30]])) {
						$t41=$alle_bens5[$row[30]].' ('.$row[30].')';
					}
					$zu_stao_t1='<br>Text 1: '.trim($row[57]);
					$zu_stao_t1.='<br>Text 2: '.trim($row[77]);
					$zu_stao_t1.='<br>Text 3: '.trim($row[46]);
					$zu_stao_t1.='<br>Text 4: '.trim($t41);
					$zus_stao='<br>'.oltext($zu_stao_t1, 'Text 1-4', '', 'Text 1-4');
				}
			}

			if ($ist_dvskfz and $row[75]!='') {
				//$zus_stao.=' / '.$row[75];
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent' and isset($row['klasse']) and $row['klasse']!='') {
				$zus_stao.='<br>SN: '.$row['klasse'];
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_haeusler' or $_SESSION['cfg_kunde']=='carlo_opel_tamsen') {
				if ($row[63]!='') {
					$zus_stao.='<br>H�.st: '.trim($row[63]);
				}
			}
			
			if ($_SESSION['cfg_kunde']=='carlo_opel_lindenberg') {
				$mandtext.='<font size=1> / '.$row[55].' / '.$row[57].'</font>';
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_nossmann' or $_SESSION['cfg_kunde']=='carlo_opel_gerds') {
				$mandtext.=' / '.$row[57];
			}
			if (p4n_mb_string('substr',$_SESSION['cfg_kunde'], 0, p4n_mb_string('strlen','carlo_opel_avag'))=='carlo_opel_avag' and $row[82]!='') {
				$mandtext.=' / '.$row[82];
			}
			if ($ist_dvskfz and $row[75]!='') {
				//$zus_stao.=' / '.$row[75];
				$mandtext.=' / '.$row[75];
			}
			
			$m_ausst1=$row[10];
			// Locator Ausst. besser:
			if ($row[56]=='20' or $row[56]=='21') {
				$ausst_neu='<table>';
				$xpl1=explode("\n", $row[10]);
				while (list($keyl, $vall)=@each($xpl1)) {
					$xpl2=explode(' EUR ', $vall);
					$ausst_neu.='<tr><td>'.trim($xpl2[0]).'</td><td>'.trim(trim($xpl2[1], ',')).'</td><td>'.trim($xpl2[2])."\n".'</td></tr>';
				}
				$ausst_neu.='</table>';
				$row[10]=$ausst_neu;
			}
			if ($row[56]=='30') {
				$ausst2='';
				$expl=explode(',',  $row[10]);
				while (list($akey, $aval)=@each($expl)) {
					$ausst2.=trim($aval).'<br>';
				}
				$row[10]=p4n_mb_string('substr',$ausst2, 0, -4);
			}

			if ($zust_dispo2!='') {
				$row[10]=$zust_dispo2."\n".$row[10];
			}
			$zusdl1='';
            $zusdl1_70=array();
			if (is_array($zusdoklinks) and count($zusdoklinks)>0) {
				@reset($zusdoklinks);
				while (list($keyzd, $valzd)=@each($zusdoklinks)) {
					$zusdl1.=link2($keyzd, $phs.'?zvl='.$valzd.'&info=1&pid='.$row[0], '','', 'target="status"').' / ';
                    $zusdl1_70[]=new Template_Link($keyzd, $phs.'?zvl='.$valzd.'&info=1&pid='.$row[0], '','', 'target="status"');
				}
			}
			if ($zusdl1!='') {
				$zusdl1=substr($zusdl1, 0, -3);
				$aktion.='<br>'.$zusdl1;
                $aktion70=array_merge($aktion70,$zusdl1_70);
			}
			
			if (isset($postfeld['nur_ids'])) {
//				$aktion='-';
                $aktion70=array();
                $aktion_tooltip='';
			}
			if (!$akt_kl2 and $cfg_kfzsuche_pakete and is_numeric($getfeld['paket']) and intval($getfeld['paket'])>0 and $row[21]!='') {
				$aktion.='<br>'.$form->checkinput('paketaenderung['.$row[0].']', ((isset($aktive_ids[$row[21]]) or isset($aktive_ids[$row[47]]))?true:false), 'onClick="dazu1=0; if (this.checked) { dazu1=1; } aendere_paket(\''.$row[21].'\', dazu1);"').' '.$paket_t;
			}
			if ($cfg_kfzsuche_verkaufmerken and !$inpaketaktiv) {
				if (intval($row[68])>0) {
					if ($row[68]!=$_SESSION['user_id']) {
						$aktion='';
                        $aktion70=array();
                        $aktion70_tooltip='';
					}
					$aktion.='<br><font color=red>'._KFZ_VERKAUFT_.' ('._VERKAUF_VORMERKEN_.')</font><br>'.$alle_bens[$row[68]].', '.$db->unixdatetime($row[69]).' '.(($row[68]==$_SESSION['user_id'] or $_SESSION['user_gruppe']==2)?link2(_LOESCHEN_, $phs.'?verkaufmerkenl=1&pid='.$row[0], '', '', 'onClick="return confirm(\''._VERKAUF_VORMERKEN_.': '._LOESCHEN_.'?\');"'):'');
				
                    if (($row[68]==$_SESSION['user_id'] or $_SESSION['user_gruppe']==2)) {
                        $aktion70[]=new Template_Link(_LOESCHEN_.' ('._KFZ_VERKAUFT_.' - '._VERKAUF_VORMERKEN_.')'.' - '.$alle_bens[$row[68]].', '.$db->unixdatetime($row[69]), $phs.'?verkaufmerkenl=1&pid='.$row[0], '', '', 'onClick="return confirm(\''._VERKAUF_VORMERKEN_.': '._LOESCHEN_.'?\');"');
                    }
                    
                } elseif (!$akt_kl2) {
				//	$aktion.='<br>'.link2(_VERKAUF_VORMERKEN_, $phs.'?verkaufmerken=1&pid='.$row[0], '', '', 'onClick="return confirm(\''._VERKAUF_VORMERKEN_.'?\');"');
				}
			}

			if ($ist_dvskfz and ($row[55]=='Auktion' or $row[55]=='Wiederholer')) {	// $row[55]=='Auktion vorgesehen' or
				$aktion=$row[55];
                $aktion70=array();
                $aktion70_tooltip=$row[55];
				if ($_SESSION['user_gruppe']==2) {
					$aktion.=link2(_DATEN_.' '._AKTUALISIEREN_, $phs.'?dvs_update='.$row[0]).'<br>';
                    $aktion70[]=new Template_Link(_DATEN_.' '._AKTUALISIEREN_, $phs.'?dvs_update='.$row[0]);
				}
				$aktion.=$form->submit2('pf'.$row[0], ($cfg_kfzsuche_buttons_abk?_PF_KURZ_:_PROBEFAHRT_), 'onClick="'.$zusabfr1_pf.' k_inhalt(\''.$phs.'?ajax=1&pf='.$row[0].'\', true, '.$dbr.', '.$dho.'); try {new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} catch(e) {}"');
                
                $linkText = ($cfg_kfzsuche_buttons_abk ? _PF_KURZ_ : _PROBEFAHRT_);
                if ($isInactive) {
                    $linkText = '<span style="color: lightgrey;">'.$linkText.'</span> ';
                    $linkText .= '<span style="color: red;">(inaktiv)</span>';
                }
                $aktion70[] = Template_Link::init($linkText, '', '', '', 'onClick="'.$zusabfr1_pf.'"')
                    ->setRequest($art = 'GET', $kfzdetails_modal_inhalt, $url = 'produktzuordnung.php', $werte = 'options_menu=0&ajax=1&pf='.$row[0], $callback = array($kfzdetails_modal));
                
                $temp_pfb70_link = clone $pfb70_link;
                Template_Trait_Obj_Helper::strreplace($temp_pfb70_link, '{fzid}', $row[0]);
                if ($isInactive) {
                    $linkText = '<span style="color: lightgrey;">'.$temp_pfb70_link->elements[0]->text.'</span>';
                    $linkText .= ' <span style="color: red;">(inaktiv)</span>';
                    $temp_pfb70_link->elements[0]->text = $linkText;
                    $aktion70[] = $temp_pfb70_link;
                } else {
                    $aktion70[] = $temp_pfb70_link;
                }
                
                $aktion_kurz='';
			}
            if ($ist_dvskfz and ($row[55]=='in Kl�rung')) {
				$aktion=$row[55];
                $aktion70=array();
                $aktion70_tooltip=$row[55];
				if ($_SESSION['user_gruppe']==2) {
					$aktion.=link2(_DATEN_.' '._AKTUALISIEREN_, $phs.'?dvs_update='.$row[0]).'<br>';
                    $aktion70[]=new Template_Link(_DATEN_.' '._AKTUALISIEREN_, $phs.'?dvs_update='.$row[0]);
				}
                $aktion_kurz='';
            }
			if ($cfg_kfzsuche_kundenkfz_keineaktion and ($row[56]=='3' or $row[56]=='4')) {
				$aktion='';
                $aktion70=array();
                $aktion70_tooltip='';
				$aktion_kurz='';
			}
			if ($cfg_kfzsuche_keinebuttons_pfangkv) {
				$aktion='';
                $aktion70=array();
                $aktion70_tooltip='';
				$aktion_kurz='';
			}

			$ausst3='';
			if ($ist_dvskfz) {
				$ausst3=str_replace(';', ',', $m_ausst1);
			} else {
			$row[10]=str_replace('ZV M', 'ZVM', $row[10]);
			if (preg_match_all('/(\w{2,7})\s{2,}(.*)/i', $row[10], $matc)) {
				while (list($akey, $aval)=@each($matc[2])) {
					if (p4n_mb_string('substr',trim($aval), 0, 4)!='3220' and !preg_match('/transport/i', $aval) and !preg_match('/werterh/i', $aval) and !preg_match('/\d\d\.\d\d\.\d\d\d\d/i', $aval)) {
						$aval=trim(str_replace('Serienausstattung', '', $aval));
						if ($aval!='') {
							$aval=str_replace(';', ',', $aval);
							$ausst3.=trim($aval).', ';
						}
					}
				}
			}
			$ausst3=p4n_mb_string('substr',$ausst3, 0, -2);
			}
			$stao_csv=trim($alle_mands3[$row[23]]);
			if ($stao_csv=='') {
				$stao_csv=trim($alle_mands[$row[23]]);
			}
			if (trim($row[27])!='' and trim($row[27])!=$stao_csv) {
				$stao_csv=trim($row[27]);
			}
			$datum_ez1=$row[3];
			if ($datum_ez1=='0000-00-00' or $datum_ez1=='1970-01-01') {
				$datum_ez1='';
			}

			$mindwerte='';
			if ($row[74]>0 and $ist_dvskfz) {
				$mindwerte='Minderwerte: '.number_format($row[74], 2, ",", ".");
			}
			
			$fgnr_anzeige=$row[21];
			if ($fgnr_anzeige==$row[0]) {
				$fgnr_anzeige='';
			}
			
			if (intval($row[20])<=0 or $cfg_kfzsuche_csvexport_auchmitkv) {
				$nettopcsv=doubleval(str_replace(',', '.', $row[71]));//doubleval($row[15])-(doubleval($row[15])*$cfg_mwst);
				if ($ist_dvskfz and intval($row[71])>0) {
					$nettopcsv=$row[71];
				}

				if ($mit_export) {
					if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
						$csv_block.='"'.$m_markenc.'";"'.trim($row[2].' '.$row[66]).'";"'.$row[5].'";"'.$datum_ez1.'";"'.$row[6].'";"'.$farbe.'";"'.str_replace('.', ',', number_format(doubleval($row[15]), 2, ".", "")).'";"'.$stao_csv.'";"'.$fgnr_anzeige.'";"'.$ausst3.'";"'.($row[63]!=''?$row[63]:$row[0]).'";"'.$row[45].'";"'.$row[33].'";"'.$row[36].'";"'.$row[32].'";"'.$row[67].'";"'.$mindwerte.'";"'.$row['schaden_rep_text'].'";"'.$row['schaden_unrep_text'].'";"'.$row['schaden_bem'].'"'."\r\n";
						$csv_blockh.='"'.$m_markenc.'";"'.trim($row[2].' '.$row[66]).'";"'.$row[5].'";"'.$datum_ez1.'";"'.$row[6].'";"'.$farbe.'";"'.str_replace('.', ',', number_format(doubleval($nettopcsv), 2, ".", "")).'";"'.$stao_csv.'";"'.$fgnr_anzeige.'";"'.$ausst3.'";"'.($row[63]!=''?$row[63]:$row[0]).'";"'.$row[45].'";"'.$row[33].'";"'.$row[36].'";"'.$row[32].'";"'.$row[67].'";"'.$mindwerte.'";"'.$row['schaden_rep_text'].'";"'.$row['schaden_unrep_text'].'";"'.$row['schaden_bem'].'"'."\r\n";
					} else {
						$kvinfo=_NEIN_;
						if ($row[65]!='' and intval($row[18])>0) {
							$kvinfo=_JA_.', Carlo+CRM';
						} elseif (intval($row[18])>0) {
							$kvinfo=_JA_.', CRM';
							if ($kv_oppid!='' and $_SESSION['cfg_kunde']=='carlo_opel_tamsen') {
								$kvinfo.=' '.$kv_oppid.'';
							}
						} elseif ($row[65]!='') {
							$kvinfo=_JA_.', Carlo';
						}
						$rtext2=$row[77];
						$kommatrenner='.';
						$nettopcsv2=$nettopcsv;
						if ($_SESSION['cfg_kunde']=='carlo_opel_ruhrdeich') {
							$rtext2=trim($row[77].' '.$row[46].' '.$row[30]);
							$kommatrenner=',';
							$nettopcsv2=number_format(doubleval($nettopcsv), 2, $kommatrenner, "");
						}
						
						if ($_SESSION['cfg_kunde']=='carlo_opel_dello') {
							$ausst3=p4n_mb_string('str_replace', array("\r\n", "\n"), ', ', $ausst3);
						}
						$ausst3=p4n_mb_string('str_replace', '"', '', $ausst3);
						
						$csv_block.='"'.$m_markenc.'";"'.trim($row[2].' '.$row[66]).'";"'.$row[5].'";"'.$datum_ez1.'";"'.$row[6].'";"'.$farbe.'";"'.str_replace('.', ',', number_format(doubleval($row[15]), 2, ".", "")).'";"'.$stao_csv.'";"'.$fgnr_anzeige.'";"'.$ausst3.'";"'.($row[63]!=''?$row[63]:$row[0]).'";"'.$row[45].'";"'.$row[33].'";"'.$row[36].'";"'.$row[32].'";"'.$row[67].'";"'.$kvinfo.'";"'.(intval($row[28])>0?_JA_:_NEIN_).'"'.($cfg_kfzsuche_holland?';"'.$row[4].'"':'').';'.($cfg_dvs?'"'.$mindwerte.'";':'').'"'.$nettopcsv2.'";"'.$rtext2.'"'.($cfg_kfzsuche_suchebuchnummer?';"'.$row[61].'"':'')."\r\n";
						$csv_blockh.='"'.$m_markenc.'";"'.trim($row[2].' '.$row[66]).'";"'.$row[5].'";"'.$datum_ez1.'";"'.$row[6].'";"'.$farbe.'";"'.str_replace('.', ',', number_format(doubleval($nettopcsv), 2, ".", "")).'";"'.$stao_csv.'";"'.$fgnr_anzeige.'";"'.$ausst3.'";"'.($row[63]!=''?$row[63]:$row[0]).'";"'.$row[45].'";"'.$row[33].'";"'.$row[36].'";"'.$row[32].'";"'.$row[67].'";"'.$kvinfo.'";"'.(intval($row[28])>0?_JA_:_NEIN_).'"'.($cfg_kfzsuche_holland?';"'.$row[4].'"':'').';'.($cfg_dvs?'"'.$mindwerte.'";':'').'"'.str_replace('.', ',', number_format(doubleval($row[15]), 2, $kommatrenner, "")).'";"'.$rtext2.'"'.($cfg_kfzsuche_suchebuchnummer?';"'.$row[61].'"':'')."\r\n";
					}
					if ($_SESSION['cfg_kunde']=='carlo_opel_tamsen') {
						$csv_block=substr($csv_block, 0, -2).';"'.$row[89].'";"'.($row[35]=='1'?_DIFFBEST_:_REGELBEST_).'"'."\r\n";
						$csv_blockh=substr($csv_blockh, 0, -2).';"'.$row[89].'";"'.($row[35]=='1'?_DIFFBEST_:_REGELBEST_).'"'."\r\n";
					}
					if ($_SESSION['cfg_kunde']=='carlo_opel_buschmann') {
						$csv_block=substr($csv_block, 0, -2).';"'.$row[4].'";"'.$row[80].'";"'.$row[32].'"'."\r\n";
						$csv_blockh=substr($csv_blockh, 0, -2).';"'.$row[4].'";"'.$row[80].'";"'.$row[32].'"'."\r\n";
					}
					if ($_SESSION['cfg_kunde']=='carlo_opel_ruhrdeich') {
						$verk1='';
						if (isset($alle_bens[$row[51]]) and $row[52]!='') {	//preg_match('/vorlauf/i', $row[12])
							$verk1=$alle_bens[$row[51]];
						}
						if ($mk_vkben!='') {
							$verk1=$mk_vkben;
						}
							$panr='';
							$res3=$db->select(
								$sql_tab['produktzuordnung_dispo'],
								array(
									$sql_tabs['produktzuordnung_dispo']['pa_nummer'],
									$sql_tabs['produktzuordnung_dispo']['benutzer_id']
								),
								$sql_tabs['produktzuordnung_dispo']['fahrgestellnummer'].'='.$db->str($row[21])
									.' or '.$sql_tabs['produktzuordnung_dispo']['belegnummer'].'='.$db->str($row[47])
							);
							if ($row3=$db->zeile($res3)) {
								$panr=$row3[0];
								if ($mk_vkben=='' and isset($alle_bens[$row3[1]])) {	// preg_match('/vorlauf/i', $row[12]) and 
									$verk1=$alle_bens[$row3[1]];
								}
							}
							
						$csv_block=substr($csv_block, 0, -2).';"'.$row[57].'";"'.$db->unixdate($row[53]).'";"'.$row[80].'";"'.number_format(doubleval($row[72]), 2, $kommatrenner, "").'";"'.$panr.'";"'.$verk1.'";"'.$row[4].'"'."\r\n";
						$csv_blockh=substr($csv_blockh, 0, -2).';"'.$row[57].'";"'.$db->unixdate($row[53]).'";"'.$row[80].'";"'.number_format(doubleval($row[72]), 2, $kommatrenner, "").'";"'.$panr.'";"'.$verk1.'";"'.$row[4].'"'."\r\n";
					}
					if ($_SESSION['cfg_kunde']=='carlo_opel_duerkop') {
						$csv_block=substr($csv_block, 0, -2).';"'.$row[80].'";"'.str_replace('.', ',', number_format(doubleval($row[72]), 2, ".", "")).'";"'.str_replace('.', ',', number_format(doubleval($row[14])*(1+$cfg_mwst), 2, ".", "")).'";"'.str_replace('.', ',', number_format(doubleval($row[14]), 2, ".", "")).'";"'.str_replace('.', ',', number_format(doubleval($row[16]), 2, ".", "")).'"'."\r\n";
						$csv_blockh=substr($csv_blockh, 0, -2).';"'.$row[57].'"'."\r\n";
					}
                    if ($_SESSION['cfg_kunde']=='carlo_opel_toennemann') {
                        $csv_block=substr($csv_block, 0, -2).';"'.$row[4].'";"'.$row[80].'";"'.$row['standtage_standort'].'";"'.$row[32].'"'."\r\n";
						$csv_blockh=substr($csv_blockh, 0, -2).';"'.$row[4].'";"'.$row[80].'";"'.$row['standtage_standort'].'";"'.$row[32].'"'."\r\n";
                    }
					if ($cfg_kfzsuche_exportcsv_standtage) {
						$csv_block=substr($csv_block, 0, -2).';"'.round($standtage).'"'."\r\n";
						$csv_blockh=substr($csv_blockh, 0, -2).';"'.round($standtage).'"'."\r\n";
					}
					if ($_SESSION['cfg_kunde']=='carlo_opel_at_mboe_ws') {
						$csv_block=substr($csv_block, 0, -2).';"'.$row[57].'"'."\r\n";
						$csv_blockh=substr($csv_blockh, 0, -2).';"'.$row[57].'"'."\r\n";
					}
				}
			}
			
			$alle_kfzs_ids.=$row[0].',';
			
			$kfz_bez1=trim($row[2].' '.$row[66]);
			$kfz_bez2=trim($row[2].' '.$row[66]);
			if ($row[2]==$row[66]) {
				$kfz_bez1=trim($row[2]);
				$kfz_bez2=trim($row[2]);
			}
			$kfzl2='javascript: k_inhalt(\'stammdaten_main.php?nav=Fahrzeuge&detail=1&id='.$row[11].'&pnr='.$row[0].'\', true, 900, 550);';
			$mbez2=$kfz_bez2;
			if ($cfg_kfzsuche_mitmodelljahr and $row[96]!='' and intval($row[96])>0) {
				$row[66].=' / MJ'.$row[96];
			}
			if (p4n_mb_string('strlen',$kfz_bez2)>25) {
				$kfz_bez2=oltext($kfz_bez2, abkuerzung($kfz_bez2, 23), $kfzl2);
			} else {
				$kfz_bez2=link2($kfz_bez2, $kfzl2);
			}
			
			$row[25]='';
			if (intval($row[6])>0) {
				$row[25]=$row[6].' '._PS_;
			}
			
			$kfz_bez2_zus=' '.oltext($mbez2.'<br><br><font size=3><pre>'.$row[10].'</pre></font>', _DETAILS_, $kfzl2, _AUSSTATTUNG_.' - '.$row[25].' / '.$row[26].$auzus.' / '.intval($row[31]).' '._VORBESITZER_, 500);
			if (!preg_match('/'.str_replace('/', ' ', $row[1]).'/i', $kfz_bez1)) {
				$kfz_bez1=trim($row[1]).' '.$kfz_bez1;
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_auto-team') {
				if ($row[57]!='') {
					$details_dvs.=' <b><font color=red>'.$row[57].'</font></b>';
				}
			}
			
			$kfz_art1=$row[12];
			if ($kfz_art1=='') {
				$kfz_art1=$carlocodes_fahrzeugstatus[$row[56]];
			}
			if ($row[45]!='') {
				$kfz_art1=$row[45].' ('.$kfz_art1.')';
			}
			$kwps=trim($row[67].'/'.$row[6]);
			if ($kwps=='0/0' or $kwps=='/0' or $kwps=='0/') {
				$kwps='';
			} elseif (p4n_mb_string('substr',$kwps, 0, 1)=='/') {
				$kwps=$row[6].' PS';
			} elseif (p4n_mb_string('substr',$kwps, -1)=='/') {
				$kwps=$row[67].' KW';
			}

			if ($cfg_ws_avag_kroatien) {
				$dispohinw_vorl.='<br>JobNo: '.$row[57].'/Ulaz: '.$row[77].'/Model: '.$row[46].($row[30]!=''?'<b><font color=red>'.$row[30].'</font></b>':'');
				if (doubleval($row[84])!=0) {
					$dispohinw_vorl.='<br>ExtraBonus: '.number_format(doubleval($row[84]), 2, ",", ".");
				}
				if (doubleval($row[73])!='') {
					$dispohinw_vorl.='<br>Prod.stat.: '.$row[73];
				}
			}

            $mfol = '';
            if ($cfg_boersen_merkmale) {
                $marketFeatures = '';
                $car = new Car_Data($row[0]);
                foreach ($car->getMarketFeatures() as $featureId => $feature) {
                    $marketFeatures .= $feature['beschreibung']."\n";
                }
                if (!empty($marketFeatures)) {
                    $mfol = ' '.oltext($marketFeatures, _BOERSENMERKMALE_);
                }
            }
            $kfz_bez2_zus .= $mfol;

			$typzeile=$unfa.$kfz_bez2.'<br><font size=1>'.$kfz_art1.$kfz_bez2_zus.'<br>'.$fgnr_anzeige.$dispohinw_vorl.'</font>';
			$bildlink='';
			if (is_file('bilder/marken/'.p4n_mb_string('strtolower',trim($row[1])).'2.gif')) {
				$bildlink='<img border=1 align="bottom" src="bilder/marken/'.p4n_mb_string('strtolower',trim($row[1])).'2.gif">';
				$typzeile='<table style="margin:0px;padding:0px;border:0px;align:left;"><tr><td>'.$bildlink.'</td><td>'.$unfa.$kfz_bez2.'<br><font size=1>'.$kfz_art1.$kfz_bez2_zus.'<br>'.$fgnr_anzeige.$dispohinw_vorl.'</font></td></tr></table>';
			} elseif (is_file('bilder/marken/'.p4n_mb_string('strtolower',trim($row[1])).'2.jpg')) {
				$bildlink='<img border=1 align="bottom" src="bilder/marken/'.p4n_mb_string('strtolower',trim($row[1])).'2.jpg">';
				$typzeile='<table style="margin:0px;padding:0px;border:0px;align:left;"><tr><td>'.$bildlink.'</td><td>'.$unfa.$kfz_bez2.'<br><font size=1>'.$kfz_art1.$kfz_bez2_zus.'<br>'.$fgnr_anzeige.$dispohinw_vorl.'</font></td></tr></table>';
			}

			if ($_SESSION['cfg_kunde']=='carlo_opel_toennemann') {
				$zus_stao3='';
							$zus_stao2=array();
							$m_letzte=time();
							$res3=$db->select(
								$sql_tab['produktzuordnung_logstandort'],
								array(
									$sql_tabs['produktzuordnung_logstandort']['benutzer_id'],
									$sql_tabs['produktzuordnung_logstandort']['standort'],
									$sql_tabs['produktzuordnung_logstandort']['standort_alt'],
									$sql_tabs['produktzuordnung_logstandort']['datum']
								),
								$sql_tabs['produktzuordnung_logstandort']['produktzuordnung_id'].'='.$db->dbzahl($row[0]),
								$sql_tabs['produktzuordnung_logstandort']['datum'].' desc'
							);
							while ($row3=$db->zeile($res3)) {
								$dat_ts=$db->unixdate_ts($row3[3]);
								$tagelang=0;
								if ($m_letzte>0) {
									$tagelang=($m_letzte-$dat_ts)/(24*60*60);
								}
								$seitt=number_format($tagelang, 1, ",", "").' '._TAGE_;
								if (!isset($xzyt)) {
									$xzyt=1;
									$seitt=_SEIT_.' '.number_format($tagelang, 1, ",", "").' '._TAGEN_;
								}
								$zus_stao2[$dat_ts]='<tr><td>'.$db->unixdatetime($row3[3]).'</td><td>'.$row3[1].'</td><td>'.$alle_bens[$row3[0]].'</td><td>'.$seitt.'</td></tr>';
								$m_letzte=$dat_ts;
							}
							if (count($zus_stao2)>0) {
								@krsort($zus_stao2);
								@reset($zus_stao2);
								while (list($key4, $val4)=@each($zus_stao2)) {
									$zus_stao3.=$val4;
								}
								$zus_stao.='<br>'.oltext('<table><tr><th>'._DATUM_.'</th><th>'._STANDORT_.' '._NEU_.'</th><th>'._BENUTZER_.'</th><th>'._TAGE_.'</th></tr>'.$zus_stao3.'</table>', _HISTORIE_);
							}
			}


			$zusd_fgnr='';
			if ($cfg_kfzsuche_suchebuchnummer) {
				if ($_SESSION['cfg_kunde']=='carlo_opel_duerkop') {
					$rbs1=doubleval($row[91])+doubleval($row[74])+doubleval($row[58]);
					$zusd_fgnr=' / RB: '.number_format($rbs1, 2, ",", "");
				} elseif ($row[61]!='') {
					$zusd_fgnr=' / BN: '.trim($row[61]);
				}
			}
			if ($cfg_greek) {
				if ($row[85]=='1') {
					$zusd_fgnr.=' / '._PROBEFAHRT_;
				}
			}
			if ($cfg_kfzsuche_edvnummer_vin) {
				if ($row[59]!='') {
					$zusd_fgnr.=' / EDV: '.trim($row[59]);
				}
			}
			if ($cfg_kfzsuche_buchnr_vin_anzeige) {
				if ($row[61]!='') {
					$zusd_fgnr=' / '.(isset($cfg_kfzsuche_buchnr_vin_anzeige_text)?$cfg_kfzsuche_buchnr_vin_anzeige_text:'BN').': '.trim($row[61]);
				}
			}
			if ($cfg_carlo_appserver_activity or $cfg_kfzsuche_eurotax_anzeige) {
				if ($row[95]!='') {
					$zusd_fgnr.=' / Eurotax: '.trim($row[95]);
				}
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_gerster') {
				if ($row[85]!='') {
					$zusd_fgnr.=' / Schl�sselnr.: '.trim($row[85]);
				}
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_eigenthaler') {
				if ($row[57]!='') {
					$zusd_fgnr.=' / Ordernr.: '.trim($row[57]);
				}
			}
			if ($_SESSION['cfg_kunde']=='carlo_opel_tamsen') {
				if ($row[85]!='') {
					$zusd_fgnr.=' / Briefnr.: '.trim($row[85]);
				}
			}
			
			if (p4n_mb_string('substr',$_SESSION['cfg_kunde'], 0, 17)=='carlo_opel_eisner') {
				if ($row[88]!='') {
					$zusd_fgnr.=' / '.trim($row[88]);
				}
			}
			
			if ($cfg_carlo_kfzimport_filialbuchnummer) {
				if ($row[88]!='') {
					$zusd_fgnr.=' / FBN: '.trim($row[88]);
				}
			}
			if ($cfg_kfzsuche_suchebelegnummer) {
				if ($belegnr!='') {
					$zusd_fgnr.=' / Belegnr.: '.trim($belegnr);
				}
			}
			if ($_SESSION['cfg_kunde']=='crm_ford_bhs') {
				if ($row[62]!='') {
					$zusd_fgnr.='<br>Kred.Best.Nr.: '.trim($row[62]);
				}
			}
			if ($cfg_dvs_fm) {
				if ($row[97]!='') {
					$zusd_fgnr.='<br>Verf�gbar ab: '.$db->unixdate($row[97]);
				}
			}
			if ($cfg_kfzsuche_pbg_vin_anzeige) {
				if ($row[64]!='') {
					$zusd_fgnr.=' / PBG: '.trim($row[64]);
				}
			}
			
			$zusd_schnsu='';
			if ($cfg_fahrzeug_liveabruf) {
				$zusd_fgnr.='<br>'.link2(_AKTUALISIEREN_, $phs.'?aktua='.$row[0]);
				$zusd_schnsu.='<br><font size=1>'.link2(_AKTUALISIEREN_, $phs.'?aktua='.$row[0], '', '', 'target="status"').'</font>';
			}
			if ($cfg_kfzsuche_liste_zusatz1rot and $row[49]!='') {
				$zusd_fgnr.='<br><font size=2 color=red>'.$row[49].'</font>';
			}
			if ($cfg_kfzsuche_modellnr_vin_anzeige and $row[40]!='') {
				$zusd_fgnr.='<br>'.$row[40];
			}
			
			$zusspalte_n='';
			$zusspalte_n2='';
			if ($cfg_kfzsuche_notizsuche) {
				$anznottext=$row[39];
				if ($cfg_carlokfzimport_dispo_text2 and $zust_dispo_zusatz2!='') {
					if ($anznottext!='') {
						$anznottext.="\n";
					}
					$anznottext.=$zust_dispo_zusatz2;
				}
				$zusspalte_n='<td>'.nl2br($anznottext).'</td>';
				$zusspalte_n2='<th>'._NOTIZEN_.'</th>';
			}
			
			if ($cfg_carlo_appserver_activity) {
				if ($row[81]!='') {
					$details_dvs=' | '.link2('B�rse', $row[81], '', '', 'target="_blank"');
				}
				if ($row[74]!='') {
					$mandtext.='<br>'.$row[74];
				}
			}
			if ($art_pzf>=0) {
				$anz_pf=$row[$baseanz_i];
				if ($art_pzf==7) {
					if (isset($alle_pzf_ben[$anz_pf])) {
						$anz_pf=$alle_pzf_ben[$anz_pf];
					}
				}
				if ($anz_pf!='') {
					$mandtext.='<br>'.$bez_pzf.': '.$anz_pf;
				}
			}
            
            $intfahrer = '';
			if ($cfg_internerfahrer or $_SESSION['crm_version']>64) {
				if (intval($row[$merke_intf_base])>0) {
					if (!isset($alle_intf[$row[$merke_intf_base]])) {
						$res88=$db->select(
							$sql_tab['benutzer'],
							array(
								$sql_tabs['benutzer']['vorname'],
								$sql_tabs['benutzer']['name']
							),
							$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row[$merke_intf_base])
						);
						$row88=$db->zeile($res88);
						$alle_intf[$row[$merke_intf_base]]=$row88[0].' '.$row88[1];
					}
					$mandtext.='<br>'._INTFAHRER_.': '.$alle_intf[$row[$merke_intf_base]];
                    $intfahrer = $alle_intf[$row[$merke_intf_base]];
				}
			}
			
			$zusanz_kms='';
					$zusanz_preis='';
					if ($cfg_kfzimport_logdatum) {
						if ($row[100]!='') {
							$zusanz_kms=oltext($row[100].': '.$db->unixdatetime($row[99]), _INFO_);
						}
						if ($row[102]!='') {
							$zusanz_preis=oltext($row[102].': '.$db->unixdatetime($row[101]), _INFO_);
						}
					}
			
			$pszus1='';
			if ($cfg_kfzsuche_motorgetriebe_beips) {
				$getr_bez=$row[70];
				if ($getr_bez=='') {
					$getr_bez=$row[26];
				}
				if (strlen($getr_bez)>0) {
					$getr_bez=substr($getr_bez, 0, 3);
				}
				$motor_bez=$row[32];
				if (strlen($motor_bez)>0) {
					$motor_bez=substr($motor_bez, 0, 3);
				}
				if ($motor_bez!='' or $getr_bez!='') {
					$pszus1='<br>';
					if ($motor_bez!='') {
						$pszus1.=$motor_bez;
					}
					if ($getr_bez!='') {
						if ($motor_bez!='') {
							$pszus1.='/';
						}
					}
					$pszus1.=$getr_bez;
				}
			}
			
			$zus_markc='';
			if ($cfg_kfz_pf_aktiv and ($row[12]=='Vorf�hrfahrzeug' or $cfg_kfz_pf_aktiv_ohnenachberechnung)) {
				$ist_inak=false;
				if ($row[8]=='inaktiv') {
					$ist_inak=true;
				}
				
				if (!$ist_inak) {
					if ($row[60]!='') {
						$zielende=adodb_mktime(23,59,59,adodb_date('m', $db->unixdate_ts($row[60])), adodb_date('d', $db->unixdate_ts($row[60])), adodb_date('Y', $db->unixdate_ts($row[60])));
						if ($zielende<time()) {
							$ist_inak=true;
							$row[8]='inaktiv';
							$row[58]='';
							$row[60]='';
							$db->update(
								$sql_tab['produktzuordnung'],
								array(
									$sql_tabs['produktzuordnung']['modelyear'] => $db->str('inaktiv'),
									$sql_tabs['produktzuordnung']['bodystylecode'] => $db->str('inaktiv;'.time().';1'),
									$sql_tabs['produktzuordnung']['powertr_exp'] => $db->str(''),
									$sql_tabs['produktzuordnung']['rsa_exp'] => $db->str(''),
									$sql_tabs['produktzuordnung']['extwar_exp'] => $db->dbtimestamp(time())
								),
								$sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($row[0])
							);
						}
					}
				}
				
				$zusinakt='';
				if ($row[58]!='' and $row[60]!='') {// and $ist_inak) {
					$zusinakt=' (aktiv: '.$db->unixdate($row[58]).'-'.$db->unixdate($row[60]).')';
				}
				if ($_SESSION['user_gruppe']==2) {
					
					$typpf=$row[66];
					$d_ez=$db->unixdate($row[3]);
						$dat1=adodb_mktime(12,0,0, substr($d_ez, 3, 2), substr($d_ez, 0, 2), substr($d_ez, 6, 4));
						$zielz=$dat1+6*30*24*60*60;
						if (substr($typpf, 0, 2)=='A7' or substr($typpf, 0, 2)=='A8' or substr($typpf, 0, 2)=='Q7' or substr($typpf, 0, 2)=='Q8') {
							$zielz=$dat1+9*30*24*60*60;
						}
					if ($zielz<time()) {
						$zielz=time()+24*60*60;
					}
					$vorg_dat1=adodb_date('d.m.Y', $dat1);
					$vorg_dat2=adodb_date('d.m.Y', $zielz);
					
					$zusin_eing='<div id="divdatink'.$row[0].'">aktiv von/bis: '.$form->datuminput('inakdat1'.$row[0], $db->unixdate($row[58])).'-'.$form->datuminput('inakdat2'.$row[0], $db->unixdate($row[60])).$form->submit2('inaksub'.$row[0], _OK_, 'onClick="if (this.form.elements[\'pfinaktiv'.$row[0].'\'].checked) { iapar1=2; } else { iapar1=1; } var xmlhttp; try { xmlhttp = new XMLHttpRequest(); } catch (error) { try { xmlhttp = new ActiveXObject(\'Microsoft.XMLHTTP\'); } catch (error) { return false; } } xmlhttp.open(\'POST\', \''.$phs.'\', false); xmlhttp.setRequestHeader(\'Content-Type\', \'application/x-www-form-urlencoded\'); xmlhttp.send(\'setinaktiv=\'+iapar1+\'&iapidk=\'+'.$row[0].'+\'&dat1=\'+this.form.elements[\'inakdat1'.$row[0].'\'].value+\'&dat2=\'+this.form.elements[\'inakdat2'.$row[0].'\'].value); response=xmlhttp.responseText; if (response!=\'\') { alert(response); }"').'</div>';
					
					$zus_markc='<br>'.$form->checkinput('pfinaktiv'.$row[0], $ist_inak, 'onClick="if (this.checked) { iapar1=2; } else { iapar1=1; } if (iapar1==1) { this.form.elements[\'inakdat1'.$row[0].'\'].value=\''.$vorg_dat1.'\'; this.form.elements[\'inakdat2'.$row[0].'\'].value=\''.$vorg_dat2.'\'; } else { this.form.elements[\'inakdat1'.$row[0].'\'].value=\'\'; this.form.elements[\'inakdat2'.$row[0].'\'].value=\'\'; } "').' inaktiv'.$zusinakt.$zusin_eing;
					//if (iapar1==2) { document.getElementById(\'divdatink'.$row[0].'\').style.display=\'\'; } else { document.getElementById(\'divdatink'.$row[0].'\').style.display=\'none\'; 
					// var xmlhttp; try { xmlhttp = new XMLHttpRequest(); } catch (error) { try { xmlhttp = new ActiveXObject(\'Microsoft.XMLHTTP\'); } catch (error) { return false; } } xmlhttp.open(\'POST\', \''.$phs.'\', false); xmlhttp.setRequestHeader(\'Content-Type\', \'application/x-www-form-urlencoded\'); xmlhttp.send(\'setinaktiv=\'+iapar1+\'&iapidk=\'+'.$row[0].'); response=xmlhttp.responseText; if (response!=\'\') { alert(response); }
				} elseif (1 or $ist_inak) {
					if ($ist_inak) {
						$zus_markc='<br><font color=red><b>'.$row[8].$zusinakt.'</b></font>';
					} else {
						$zus_markc='<br><b>'.$row[8].$zusinakt.'</b>';
					}
				}
			}
			
			if (isset($getfeld['kurz']) and !isset($postfeld['nur_ids'])) {
				if (preg_match_all('/(<input.*>)/Uis', $aktion_kurz, $expl1)) {
//				print_r($expl1);
					$aktion_kurz2='';
					$akt_anz=0;
					while (list($keyk, $valk)=@each($expl1[1])) {
						$aktion_kurz2.=$valk;
						$akt_anz++;
						if ($akt_anz==3) {
							$aktion_kurz2.='<br>';
							$akt_anz=0;
						}
						$aktion_kurz=str_replace($valk, '', $aktion_kurz);
					}
					$aktion_kurz=$aktion_kurz2.'<br>'.$aktion_kurz;
					$aktion_kurz=str_replace('<br><br>', '<br>', $aktion_kurz);
				}
                if (isset($_GET['bdc_form'])) {

                    $aktion_kurz=$form->submit2('',_UEBERNEHMEN_,'onclick="this.disabled=true; parent.fahrzeugToBdc(\''.$_GET['bdc_form'].'\','.$row[0].(isset($_GET['bdc_lead'])?',\''.$_GET['bdc_lead'].(isset($_GET['bdc_pid2'])?'&bdc_pid2='.$_GET['bdc_pid2']:'').(isset($_GET['bdc_alternativkfz'])?'&bdc_alternativkfz='.$_GET['bdc_alternativkfz']:'').'\'':'').');"');
                
                    $aktion70=array(
                        Template_Button::init('',_UEBERNEHMEN_,'','','','','xs','','quadratic')
                                ->setRequest('POST','hidden_elementlist','stammdaten_main.php?nav=lead','neueskfz='.$row[0].'&korrid='.$_GET['bdc_form'].'&leadid='.$_GET['bdc_lead'].(isset($_GET['bdc_pid2'])?'&bdc_pid2='.$_GET['bdc_pid2']:'').(isset($_GET['bdc_alternativkfz'])?'&bdc_alternativkfz='.$_GET['bdc_alternativkfz']:''))
                    );

                }
				$block='<tr><th class="'.($cfg_neustyle?'header':'ueberschrift').'" style="height: '.$css_lh.'px; line-height:'.$css_lh.'px; padding-left:5px; margin-top:0px; font-size:8pt;" colspan=10>{nr}. '.$kfz_bez1.$zus_st_farbe.'</th></tr><tr'.tr_zeile().$zzus.'>
					<td>'.$typzeile.'</td>
					<td>'.$row[5].'km'.$zusanz_kms.'<br>'.($db->unixdate($row[3])==''?'':adodb_date('m/Y', $db->unixdate_ts($row[3]))).$ez_zus.'<br><font size=1>'.$row[4].'</font></td>
					<td style="font-size:8pt;">'.($kwps!=''?$kwps.'<br>':'').($pszus1!=''?str_replace('<br>', ' ', $pszus1).'<br>':'').(p4n_mb_string('strlen',$farbe)>15?oltext($farbe, abkuerzung($farbe, 13)):$farbe).$details_fotos.'</td>
					<td>'.$preis.$zusanz_preis.$zusd_schnsu.'</td>
					<td>'.$stao_csv.$zus_stao.'<br>'.round($standtage).'</td>
					<td'.($dispohinw!=''?' bgcolor="red" '.$dispohinw:'').'>'.$aktion_kurz.'</td></tr>';
			} else {
				$zus_rd234='';
				if ($_SESSION['cfg_kunde']=='carlo_opel_ruhrdeich') {
					$zus_rd234='<td>'.trim($row[77].' '.$row[46].' '.$row[30].' '.$zust_dispo_zusatz2.' '.$zust_dispo2).'</td>';
				}
				if (function_exists('oltext_tab')) {
					$olt=oltext_tab(1,'<font size=3><pre>'.$row[10].'</pre></font>', _DETAILS_, ((!$cfg_kfzsuche_details_neu and intval($row[11])>0)?'stammdaten_main.php?id='.$row[11].($cfg_kfzsuche_details_neu?'&detail3=1':'').'&ohnep=1&nav=Fahrzeuge&pnr='.$row[0]:''), _AUSSTATTUNG_.' - '.$row[25].' / '.$row[26].$auzus.' / '.intval($row[31]).' '._VORBESITZER_.$zusdetails2, 500);
				} else {
					$olt=oltext('<font size=3><pre>'.$row[10].'</pre></font>', _DETAILS_, (intval($row[11])>0?'stammdaten_main.php?id='.$row[11].'&ohnep=1&nav=Fahrzeuge&pnr='.$row[0]:''), _AUSSTATTUNG_.' - '.$row[25].' / '.$row[26].$auzus.' / '.intval($row[31]).' '._VORBESITZER_.$zusdetails2, 500);
				}
				$olt .= $mfol;
				$haestat=$row[63];
				if ($cfg_carlo_appserver_activity) {
					if (isset($alle_haendlstat[$row[63]])) {
						$haestat=$alle_haendlstat[$row[63]];
					}
				}
                if (isset($_GET['bdc_form'])) {
                    if ($_GET['bdc_form'] === 'tvd') {
                        $tvdData = array(
                            $db->str($row[1].' '.$row[2]), $db->str($row[21]), $row[5], $db->str($db->unixdate($row[3])),
                            $db->str($row['kba_hersteller']), $db->str($row['kba_typ']), $row[67], $row[6],
                            round($row[15])
                        );
                        $aktion=$form->submit2('',_UEBERNEHMEN_,'onclick="this.disabled=true; parent.tvd_iframe_iframe.fahrzeugToTVD(Array('.implode(',', $tvdData).'), '.$row[0].')"');
                    
                        $aktion70=array(
                            new Template_Button('',_UEBERNEHMEN_,'onclick="this.disabled=true; parent.tvd_iframe_iframe.fahrzeugToTVD(Array('.implode(',', $tvdData).'), '.$row[0].')"','','','','xs')
                        );
                    } else {

                        $aktion=$form->submit2('',_UEBERNEHMEN_,'onclick="this.disabled=true; parent.fahrzeugToBdc(\''.$_GET['bdc_form'].'\','.$row[0].(isset($_GET['bdc_lead'])?',\''.$_GET['bdc_lead'].(isset($_GET['bdc_pid2'])?'&bdc_pid2='.$_GET['bdc_pid2']:'').(isset($_GET['bdc_alternativkfz'])?'&bdc_alternativkfz='.$_GET['bdc_alternativkfz']:'').'\'':'').')"');

                        $aktion70=array(
                            Template_Button::init('',_UEBERNEHMEN_,'','','','','xs','','quadratic')
                                ->setRequest('POST','hidden_elementlist','stammdaten_main.php?nav=lead','neueskfz='.$row[0].'&korrid='.$_GET['bdc_form'].'&leadid='.$_GET['bdc_lead'].(isset($_GET['bdc_pid2'])?'&bdc_pid2='.$_GET['bdc_pid2']:'').(isset($_GET['bdc_alternativkfz'])?'&bdc_alternativkfz='.$_GET['bdc_alternativkfz']:''))
                        );
                    }
                }
				if ($cfg_kfzsuche_listeohnetypnr and trim($row[66])!='') {
					$row[2]='';
				}
				if ($_SESSION['cfg_kunde']=='carlo_opel_schorr' and $row[75]!='') {
					$zus_markc.='<br>'.oltext($row[75].' '._SEIT_.' '.$db->unixdate($row[81]), '<font color=red>Radsatz eingelagert</font>');
				}
                if ($_SESSION['cfg_kunde']=='carlo_opel_kramm' and $row[55]!='') {
                    $aktion.=' / '.$row[55].' '; //Zusatzcode_1 EkUser aus Attribute
                }
				$groe_vinanz=1;
				if (isset($cfg_kfzsuche_vinanzeige_gross) and intval($cfg_kfzsuche_vinanzeige_gross)>0) {
					$groe_vinanz=$cfg_kfzsuche_vinanzeige_gross;
				}
				$block='<tr'.tr_zeile().$zzus.'><td>{nr}'.$nr_zust.$zus_st_farbe.'</td><td>'.$unfa.$zusk.$markenc.$mandtext.$zus_markc.'</td><td>'.$row[32].' '.(intval($row[11])>0?linkToTab(trim($row[2].' '.$row[66]), 'stammdaten_main.php?id='.$row[11].'&nav=Fahrzeuge&pnr='.$row[0].($cfg_kfzsuche_details_neu?'&detail3=1':''),'','','',1):trim($row[2].' '.$row[66])).' '.$olt.$details_dvs.'<br><font size='.$groe_vinanz.'>'.$fgnr_anzeige.($ist_dvskfz?' / '.$row[63]:'').$zusd_fgnr.$dispohinw_vorl.'</font></td>'.$zus_rd234.'<td>'.$row[6].$pszus1.'</td><td>'.$farbe.$details_fotos.'</td><td>'.$db->unixdate($row[3]).$ez_zus.'</td>'.($cfg_kfzsuche_ergebnis_keinkennzeichen?'':'<td>'.$row[4].'</td>').($cfg_carlo_appserver_activity?'<td>'.$haestat.'</td>':'').'<td>'.$row[5].$zusanz_kms.'</td><td>'.$preis.$zusanz_preis.'</td><td>'.round($standtage).$zus_stao.'</td><td'.($dispohinw!=''?' bgcolor="red" '.$dispohinw:'').'>'.$aktion.'</td>'.$zusspalte_n.'</tr>';
                    //$row[12]
                if ($nr_zust70=='') {
                    $nr_zust70=new Template_Image('bilder/platzhalter_auto.png','120px');
                }
                
                if (isset($_SESSION['design_70'])) {
                    $cols_view[0] = $nr_zust70;
                    
                    $carModel = trim($row['typ_modell'].' '.$row['typ']) ?: '-';
                    if ((int)$row['stammdaten_id'] > 0) {
                        $carModelLink = new Template_Link(new Template_Text($carModel, 35, array('bold')));
                        $modalParams = [
                            'nav' => 'Fahrzeuge',
                            'produktzuordnung_tab' => 'tab_fahrzeuge_tab_details',
                            'aendern' => $row['produktzuordnung_id'],
                            'pnr' => $row['produktzuordnung_id']
                        ];
                        if ($cfg_kfzsuche_details_neu) {
                            $modalParams['kfzsuche'] = 1;
                        }
                        if ($cfg_avag_de) {
                            $carModelLink->setRequest(
                                'GET',
                                $carDetailsModalContent,
                                'stammdaten_main.php',
                                http_build_query($modalParams),
                                $carDetailsModal
                            );
                        } else {
                            $carModelLink->setModalWeiterleitung(
                                'GET',
                                'stammdaten_main.php',
                                'nav=Fahrzeuge&su=1&id='.$row['stammdaten_id'],
                                http_build_query($modalParams),
                                'produktzuordnung_modal',
                                false,
                                '_tab'
                            );
                        }
                    } else {
                        $carModelLink = new Template_Text($carModel);
                    }
                    $cols_view[1] = new Template_ElementList(
                        array(
                            $carModelLink,
                            new Template_Text($row['fahrzeugstatus'] ?: '-'),
                            $fgnr_anzeige ?: '-'
                        ), '', 'vertical'
                    );
                    
                    $cols_view[2] = new Template_ElementList(
                        array(
                            Template_Text::init($preis70 ?: '-', -1, array('bold')),
                            $zuspreis70 ?: '-',
                            '&nbsp;'
                        ), '', 'vertical'
                    );
                    
                    $cols_view[3] = new Template_ElementList(
                        array(
                            new Template_Text($mandtext70 ?: '-', -1, array('bold')),
                            $intfahrer ?: '-',
                            '&nbsp;'
                        ), '', 'vertical'
                    );
                    
                    $cols_view[4] = new Template_ElementList(
                        array(
                            new Template_Text($row[6].$pszus1, -1, array('bold')),
                            $farbe ?: '-',
                            '&nbsp;'
                        ), '', 'vertical'
                    );
                    
                    $cols_view[5] = new Template_ElementList(
                        array(
                            Template_Text::init($db->unixdate($row[3]), -1, array('bold')),
                            $row[5],
                            '&nbsp;'
                        ), '', 'vertical'
                    );
                    
                    $cols_view[6] = new Template_ElementList(
                        array(
                            new Template_Text(round($standtage), -1, array('bold')),
                            ($cfg_kfzsuche_ergebnis_keinkennzeichen ? '' : $row[4]) ?: '-'
                        ), '', 'vertical'
                    );
                    
                    // Inactivity settings link.
                    if (!empty($cfg_kfz_pf_aktiv_ohnenachberechnung)) {
                        $inactiveLink = new Template_Link('Inaktivit�t', '');
                        $inactiveLink->setRequest(
                            'GET',
                            $kfzdetails_modal_inhalt,
                            'kfzsuche.php',
                            'action=inactivity&options_menu=0&ajax=1&pf='.$row[0],
                            array($kfzdetails_modal)
                        );
                        $aktion70[] = $inactiveLink;
                    }
                    
                    if ($cfg_avag_de && !isset($_GET['vonlead']) && !isset($_GET['bdc_lead'])) {
                        if ($_SESSION['AVAG_KFZSUCHE_REMEMBER_CAR_VIN'] === $row['fahrgestell']) {
                            $rememberCarBtn = new Template_Button('', _KFZ_.' '._VERGESSEN_, '', '', '', '', 'xs', 'grey', 'quadratic');
                            $rememberCarBtn->onClick('avag_onRememberCarBtnClick(\' \');');
                        } else {
                            $rememberCarBtn = new Template_Button('', _KFZ_.' '._MERKEN_, '', '', '', '', 'xs', '', 'quadratic');
                            $rememberCarBtn->onClick('avag_onRememberCarBtnClick(\''.$row['fahrgestell'].'\');');
                        }
                        $aktion70 = [$rememberCarBtn];
                    }
                    $actionMenu = Template_InlineMenu::init($aktion70, '', array('position' => 'right bottom'));
                    $hiddenActs = [];
                    $hasTestDriveLink = $hasTestDriveOverviewLink = false;
                    foreach ($aktion70 as $i => $link) {
                        if (
                            is_array($link->elements) &&
                            count($link->elements) === 0 ||
                            $link->elements[0]->phpClass !== 'Template_Text'
                        ) {
                            continue;
                        }
                        $linkTextEl = $link->elements[0];
                        if (stripos($linkTextEl->text, _PROBEFAHRT_) !== false) {
                            $hasTestDriveLink = true;
                        }
                        if (stripos($linkTextEl->text, _PROBEFAHRTUEBERSICHT_) !== false) {
                            $hasTestDriveOverviewLink = true;
                        }
                        
                        if (
                            $cfg_avag_de &&
                            $linkTextEl->text !== 'EnVKV' &&
                            (
                                stripos($linkTextEl->text, _ANGEBOT_) !== false ||
                                stripos($linkTextEl->text, _ANG_KURZ_) !== false ||
                                stripos($linkTextEl->text, _KV_KURZ_) !== false ||
                                stripos($linkTextEl->text, _KAUFVERTRAG_) !== false ||
                                stripos($linkTextEl->text, _VVI_) !== false
                            )
                        ) {
                            if (!in_array($linkTextEl->text, $hiddenActs)) {
                                $hiddenActs[] = $linkTextEl->text;
                            }
                            $aktion70[$i]->addCustomClass('d-none');
                        }
                    }

                    $actionTooltipTestDriveInfo = array();
                    if (!$hasTestDriveLink) {
                        $actionTooltipTestDriveInfo[] = 'Es k�nnen keine Probefahrten erstellt werden, da das Fahrzeug inaktiv ist.';
                    }
                    if (!$hasTestDriveOverviewLink) {
                        $actionTooltipTestDriveInfo[] = 'Die Probefahrten�bersicht ist nicht verf�gbar, da das Fahrzeug inaktiv ist.';
                    }
                    
                    if (count($actionTooltipTestDriveInfo)) {
                        $aktion70_tooltip = implode('<br>', $actionTooltipTestDriveInfo).'<br>'.$aktion70_tooltip;
                    }
                    
                    if ($aktion70_tooltip != '') {
                        $aktion70_tooltip = Template_Tooltip::init($aktion70_tooltip, new Template_Icon('help'))->addCustomClass('mb-16');
                    }
                    $cols_view[7] = new Template_ElementList(array($aktion70_tooltip, new Template_ElementList(array($actionMenu->getTriggerButtonAndMenu()), '', 'vertical')), '', 'horizontal');
                    
                    if (count($aktion70) == 1) {
                        $cols_view[7] = $aktion70[0];
                    }
                }
            }
                                
            if (empty($cols_view[0])) {
                $cols_view[0]=' ';
            }        

            ksort($cols_view);
            if (!$table_data_i) {
                $table_data_i = 1;
            }
            
			$zusblock='';
			if ($cfg_kfzsuche_pfbalken and !isset($postfeld['nur_ids'])) {
				$tbl=' style="font-size: 8pt;"';
				$kfzid_pf=intval($row[0]);
				if (isset($pfb[$row[0]])) {
					if ($cfg_kfzsuche_pfhistorie) {
						$pfb[$row[0]]=str_replace('{fzid}', $row[0], $pfb[$row[0]]);
                        Template_Trait_Obj_Helper::strreplace($pfb70[$row[0]],'{fzid}', $row[0]);
                        $temp_pfb70_link=clone $pfb70_link;
                        Template_Trait_Obj_Helper::strreplace($temp_pfb70_link,'{fzid}', $row[0]);
					}
					$zusblock='<tr><td>{nr}</td><td colspan=100><table'.$tbl.'>'.$pfb[$row[0]].'</table></td></tr>';
                    $zusblock70=$pfb70[$row[0]];
                    
				} elseif ($cfg_dvs and $row[47]!='' and isset($pfb[$row[47]])) {
					if ($cfg_kfzsuche_pfhistorie) {
						$pfb[$row[47]]=str_replace('{fzid}', $row[47], $pfb[$row[47]]);
                        Template_Trait_Obj_Helper::strreplace($pfb70[$row[47]],'{fzid}', $row[47]);
                        $temp_pfb70_link=clone $pfb70_link;
                        Template_Trait_Obj_Helper::strreplace($temp_pfb70_link,'{fzid}', $row[47]);
					}
					$zusblock='<tr><td>{nr}</td><td colspan=100><table'.$tbl.'>'.$pfb[$row[47]].'</table></td></tr>';
                    $zusblock70=$pfb70[$row[47]];
				} else {
					$anz_pfb=$pfb[0];
                    $anz_pfb70=$pfb70[0];
					if ($cfg_kfzsuche_pfhistorie) {
						$anz_pfb=str_replace('{fzid}', $row[0], $anz_pfb);
                        Template_Trait_Obj_Helper::strreplace($anz_pfb70,'{fzid}', $row[0]);
                        $temp_pfb70_link=clone $pfb70_link;
                        Template_Trait_Obj_Helper::strreplace($temp_pfb70_link,'{fzid}', $row[0]);
					}
					$zusblock='<tr><td>{nr}</td><td colspan=100><table'.$tbl.'>'.$anz_pfb.'</table></td></tr>';
                    $zusblock70='<tr><td colspan=100>{nr}<table'.$tbl.'>'.$anz_pfb.'</table></td></tr>';
                    $zusblock70=$anz_pfb70;
				}
				if (isset($getfeld['kurz']) and !isset($postfeld['nur_ids'])) {
					$zusblock=str_replace('<td>{nr}</td>', '', $zusblock);
				}
                
                $zusblock70=new Template_Timeline($zusblock70, null, 1, true, false);
                $zusblock70->addCustomClass('test');
                
				if ($cfg_kfzsuche_pfkal_woche_scrollen and $wochenansicht and $kfzid_pf>0) {
					$navzur=link2(_STAMMDATEN_NAV_ZURUECK_, 'javascript: lade_wkal(\''.$woche_zur.'\', \'pftr'.$kfzid_pf.'\'); void(0);', 'pfeil_l.gif');	//
                    $navzur70=new Template_IconButton('','','onclick="lade_wkal(\''.$woche_zur.'\', \'pftr'.$kfzid_pf.'\');"','chevron_left',$href='',$abfrage='', $sizeClass = 'xs');
					$navvor=link2(_STAMMDATEN_NAV_VOR_, 'javascript: lade_wkal(\''.$woche_vor.'\', \'pftr'.$kfzid_pf.'\'); void(0);', 'pfeil_r.gif');
                    $navvor70=new Template_IconButton('', '','onclick="lade_wkal(\''.$woche_vor.'\', \'pftr'.$kfzid_pf.'\');"','chevron_right',$href='',$abfrage='', $sizeClass = 'xs');
					$zusblock=str_replace('{nr}', $navzur.'<div style="display:inline;">W'.intval(adodb_date('W', $je)).'</div>'.$navvor, $zusblock);
                    
                    $zusblock70=new Template_ElementList(array($navzur70,'W'.intval(adodb_date('W', $je)),$navvor70,$zusblock70),'pftr'.$kfzid_pf,'horizontal nowrap kfzweekmenu');
                    
					$zusblock='<tr id="pftr'.$kfzid_pf.'"'.p4n_mb_string('substr', $zusblock, 3);
                  //  $zusblock70='<tr id="pftr'.$kfzid_pf.'"'.p4n_mb_string('substr', $zusblock70, 3);
				}
			}
			if (isset($getfeld['export_keineliste'])) {
				
			} else {
				if ($cfg_kfzsuche_pfkal_farbzeilen) {
					$cl1=' class="odd" ';
					if (!($zi%2)) {
						$cl1=' class="even" ';
					}
					$block='<tr '.p4n_mb_string('substr', $block, 3);
					$zusblock='<tr '.p4n_mb_string('substr', $zusblock, 3);
                  //  $zusblock70='<tr '.p4n_mb_string('substr', $zusblock70, 3);
				}
				$dblock[$zi]=$block.$zusblock;
				$sblock[$zi]=$sortindex;
                
                $new_list=array();
                for ($i=0;$i<51;$i++) {
                    $new_list[$i]=$i;
                  //  $icons[$i]=new Template_Text($i);
                }
                
                $cols_view[0]=array($cols_view[0],Template_ElementList::init($zusblock70)->setAttribute('style','position:absolute;width:calc(100% - 32px);bottom:0px')->addCustomClass('pfbalken'));
               // $table_data[serialize(Template_TableRow::init($table_data_i++)->addCustomClass($zzus70))] = $cols_view2;
			}
			$zi++;
                        
                
                        
            $temp_row=Template_TableRow::init($table_data_i++)->addCustomClass($zzus70);
            if ($cfg_kfzsuche_pfbalken) {
                $temp_row->addCustomClass('kfzsuchepfbalken');
                if ($pfbalken_show) {
                    $temp_row->addCustomClass('show');
                }
            }
            
            $activeColor = Template_TableCol::init()->addCustomClass('colored')->setAttribute('class', 'status-bar');
            $activeColor->setAttribute('style', $ist_inak ? 'background-color: #ff0000' : '');
            array_unshift($cols_view, $activeColor);
            
            $table_data[serialize($temp_row)] = $cols_view;
            $pagination_zaehler++;
		}
		
		if ($kfzs_debug) {
			if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
				fwrite($fp, $kfzslog_sel);
				fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'nach Schleife'."\r\n");
				fclose($fp);
			}
		}
		
		if (!$cfg_kfzsuche_keinedvssuche and !$keine_dvssuche and $cfg_dvs and ($getfeld['refnr']!='' or ($dvs_suchen and !isset($postfeld['nur_ids']) and intval($getfeld['vormerk'])<=0 and ($getfeld['kfzstatus']=='-80' or $getfeld['kfzstatus']=='-1' or $getfeld['kfzstatus']=='Gebrauchtfahrzeug')))) {
			if ($kfzs_debug) {
				if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
					fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'vor DVS-Suche'."\r\n");
					fclose($fp);
				}
			}
			
			if (intval($getfeld['dvs_status'])>0) {
				$suchfeld2['Status']=intval($getfeld['dvs_status']);
			}

			if (!isset($cfg_dvs_maxds)) {
				$cfg_dvs_maxds=100;
			}

			$dvs_sortorder=array(
				$sql_tabs['produktzuordnung']['markencode'] => 'Fabrikat',
				$sql_tabs['produktzuordnung']['typ_modell'] => 'VK_BEZ',
				$sql_tabs['produktzuordnung']['leistung_ps'] => 'Leistung_PS',
				$sql_tabs['produktzuordnung']['farbbezeichnung'] => 'Farbschema',
				$sql_tabs['produktzuordnung']['datum_ez'] => 'Erstzulassung',
				$sql_tabs['produktzuordnung']['kennzeichen'] => 'Internetpreis',
				$sql_tabs['produktzuordnung']['km_stand'] => 'km_Stand',
				$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'] => 'Internetpreis',
				'10' => 'Standtage'
			);
			$sorto1='';
			if (isset($dvs_sortorder[$getfeld['sort']])) {
				$sorto1=$dvs_sortorder[$getfeld['sort']];
			}
			$dvs_vorgabe=array(
				'Fabrikat' => "",
				'Modell' => "",
				'Treibstoff' => 0,
				'Aufbau' => 0,
				'Antrieb' => 0,
				'Grundfarbe' => 0,
				'Schaltung' => 0,
				'Laufleistung_bis' => 10000000,
				'Leistung_von' => 0,
				'Leistung_bis' => 10000,
				'Hubraum_von' => 0,
				'Hubraum_bis' => 32000,
				'Erstzulassung_von' => 1900,
				'Erstzulassung_bis' => 2200,
				'Preis_von' => 1,
				'Preis_bis' => 99999999,
				'Ausstattung' => "",
				'Filiale' => "",
				'Lagerort' => "",
				'MaxDS' => $cfg_dvs_maxds,
				'SortOder' => $sorto1,
				'Order' => ''
			);
			if ($getfeld['order']=='asc') {
				$dvs_vorgabe['Order']='ASC';
			} elseif ($getfeld['order']=='desc') {
				$dvs_vorgabe['Order']='DESC';
			}
			if (count($suchfeld2)>0 or isset($getfeld['pak_erg']) or $getfeld['refnr']!='') {
				$suchfeld3=array();
				while (list($keyv, $valv)=@each($dvs_vorgabe)) {
					if (isset($suchfeld2[$keyv])) {
						$suchfeld3[$keyv]=$suchfeld2[$keyv];
					} else {
						if ($valv>-1) {
							$suchfeld3[$keyv]=$valv;
						}
					}
				}
				if (count($suchfeld3)>0 or isset($getfeld['pak_erg']) or $getfeld['refnr']!='') {
					$_SESSION['crm_kfzsuche_dvs']=array();
					include_once('webservice/nusoap.php');
					$client = new nusoap_client($cfg_dvs_ws, true);
					
					if ($_SESSION['cfg_kunde']=='carlo_opel_dello') {
						$client->useHTTPPersistentConnection();
						$client->setHTTPEncoding();
					}
					
					if ($getfeld['refnr']!='') {
						$result=array();
						$result2 = $client->call("getFahrzeug", array('DVSGWID' => trim($getfeld['refnr']), 'WhichID' => 'Fremd_ID'));
//echo p4n_mb_string('htmlspecialchars',$client->request, ENT_QUOTES);
//print_r($result2);

					if ($dvs_ws_logging or $_SESSION['user_id']==1) {
						if ($dvs_ws_logging_alert) {
							echo javas('alert("'.p4n_mb_string('substr',str_replace(array('"', "\n", "\r"), '', $client->request), 0, 1000).'");');
							echo javas('alert("'.p4n_mb_string('substr',str_replace(array('"', "\n", "\r"), '', $client->response), 0, 1000).'");');
						}
						if ($fp=fopen('log/dvs/crm2dvs_getFahrzeug_request_.'.adodb_date('d_m_Y_His').'.xml', 'w')) {
							fwrite($fp, $client->request);
							fclose($fp);
						}
						if ($fp=fopen('log/dvs/crm2dvs_getFahrzeug_.'.adodb_date('d_m_Y_His').'.xml', 'w')) {
							fwrite($fp, $client->response);
							fclose($fp);
						}
					}
						if (isset($result2['dvsFahrzeug'])) {
							if (isset($result2['dvsFahrzeug']['Status']) and ($result2['dvsFahrzeug']['Status']=='1' or $result2['dvsFahrzeug']['Status']=='3' or $result2['dvsFahrzeug']['Status']=='10' or $result2['dvsFahrzeug']['Status']=='17' or $result2['dvsFahrzeug']['Status']=='12' or $result2['dvsFahrzeug']['Status']=='20' or $result2['dvsFahrzeug']['Status']=='22' or $result2['dvsFahrzeug']['Status']=='25' or $result2['dvsFahrzeug']['Status']=='26' or $result2['dvsFahrzeug']['Status']=='27')) {
								if ($result2['dvsFahrzeug']['Status']=='19' or (($result2['dvsFahrzeug']['Status']=='10' or $result2['dvsFahrzeug']['Status']=='22') and intval($result2['dvsFahrzeug']['Angebotspreis'])==0)) {
									// vorher auch Auktion vorgesehen: $result2['dvsFahrzeug']['Status']=='12' or
								} else  {
									$result['getFahrzeugListeResult']['cFahrzeug'][]=$result2['dvsFahrzeug'];
								}
							}
						}
					} elseif (isset($getfeld['pak_erg'])) {
						$expl1=array();
						if ($pak_ids_suche_dvs) {
							$expl1=explode(',', p4n_mb_string('substr',$pak_ids_suche_dvs, 0, -1));
						}
						$result=array();
						while (list($key2, $val2)=@each($expl1)) {
							$result2 = $client->call("getFahrzeug", array('DVSGWID' => $val2, 'WhichID' => 'F_UID'));
							if (isset($result2['dvsFahrzeug'])) {
								$result['getFahrzeugListeResult']['cFahrzeug'][]=$result2['dvsFahrzeug'];
							}
						}
					} else {
/*echo '<pre>';
print_r($suchfeld3);
die();
*/					$result = $client->call("getFahrzeugListe", array($suchfeld3));
//print_r($result);
//die();
					if ($dvs_ws_logging or $_SESSION['user_id']==1) {
						if ($dvs_ws_logging_alert) {
							echo javas('alert("'.p4n_mb_string('substr',str_replace(array('"', "\n", "\r"), '', $client->request), 0, 1000).'");');
							echo javas('alert("'.p4n_mb_string('substr',str_replace(array('"', "\n", "\r"), '', $client->response), 0, 1000).'");');
						}
						if ($fp=fopen('log/dvs/crm2dvs_getFahrzeugListe_request_.'.adodb_date('d_m_Y_His').'.xml', 'w')) {
							fwrite($fp, $client->request);
							fclose($fp);
						}
						if ($fp=fopen('log/dvs/crm2dvs_getFahrzeugListe_.'.adodb_date('d_m_Y_His').'.xml', 'w')) {
							fwrite($fp, $client->response);
							fclose($fp);
						}
					}
					if (isset($result['getFahrzeugListeResult']['cFahrzeug']['F_UID'])) {
						$m=$result['getFahrzeugListeResult']['cFahrzeug'];
						unset($result);
						$result['getFahrzeugListeResult']['cFahrzeug'][]=$m;
					}
					}
					$anz_dvs=0;
					if ($kfzs_debug) {
						if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
							fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'nach DVS-Suche'."\r\n");
							fclose($fp);
						}
					}
					$kfzslog_sel='';
					if (isset($result['getFahrzeugListeResult']['cFahrzeug'])) {
					$anz_dvs=count($result['getFahrzeugListeResult']['cFahrzeug']);
					$zi2=0;
					while ($zi2<$cfg_dvs_maxds and list($rkey, $rval)=@each($result['getFahrzeugListeResult']['cFahrzeug'])) {
						if (intval($rval['Status'])==19) {
							continue;
						}
						if ($kfzs_debug) {
							$kfzslog_sel.=adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'DVS-KFZ '.$zi2."\r\n";
						}
						$res5=$db->select(
							$sql_tab['produktzuordnung'],
							$sql_tabs['produktzuordnung']['produktzuordnung_id'],
							$sql_tabs['produktzuordnung']['fahrgestell'].'='.$db->str($rval['Fahrgestellnummer']).' and '.
								$sql_tabs['produktzuordnung']['fahrzeugstatus_code'].'!=30'	/*.' and '.
								$sql_tabs['produktzuordnung']['hersteller'].'='.$db->str($rval['F_UID'])*/
						);
						if ($row5=$db->zeile($res5)) {
							kfz_dvs2crm($rval);
							if (p4n_mb_string('strlen',$rval['Fahrgestellnummer'])>10) {
								@reset($dblock);
								while (list($keyb, $valb)=@each($dblock)) {
									if (preg_match('/'.$rval['Fahrgestellnummer'].'/i', $valb)) {
										unset($dblock[$keyb]);
										unset($sblock[$keyb]);
									}
								}
							}
							@reset($dblock);
							//continue;
						} else {
							$res5=$db->select(
								$sql_tab['produktzuordnung'],
								$sql_tabs['produktzuordnung']['produktzuordnung_id'],
								$sql_tabs['produktzuordnung']['fahrgestell'].'='.$db->str($rval['Fahrgestellnummer'])
							);
							if ($row5=$db->zeile($res5)) {
								continue;
							}
						}
						$_SESSION['crm_kfzsuche_dvs'][$rval['F_UID']]=serialize($rval);

						$unfa='';
						if (intval($rval['Unfall_Status'])>=2) {
							$unfa='<p style="background-color: lightblue; display: inline;">'.oltext($dvs_unfall2[intval($rval['Unfall_Status'])], '<font color=red>'.p4n_mb_string('substr',_UNFALLW_, 0, 3).'</font>').'</p> ';
//							$unfa='<font color=red>'.$dvs_unfall2[$rval['Unfall_Status']].'</font> ';
						}
						$dat_ez=$db->unixdate(p4n_mb_string('substr',$rval['Erstzulassung'], 0, 10));
						$dat_ez2=$db->unixdate_ts(p4n_mb_string('substr',$rval['Erstzulassung'], 0, 10));
						$kennz='';
						while (list($key2, $val2)=@each($rval['Attribute']['cFAttr'])) {
							if ($val2['AttrName']=='Kennzeichen') {
								$kennz=$val2['AttrValue'];
							}
						}
						$aktion='';
                        $aktion70=array();
                        $aktion70_tooltip='';
						$zusafarbe='';
						$m_res1='';

						$res5=$db->select(
							$sql_tab['produktzuordnung_reservierung'],
							array(
								$sql_tabs['produktzuordnung_reservierung']['kunde'],
								$sql_tabs['produktzuordnung_reservierung']['datum_von'],
								$sql_tabs['produktzuordnung_reservierung']['datum_bis'],
								$sql_tabs['produktzuordnung_reservierung']['benutzer_id'],
								$sql_tabs['produktzuordnung_reservierung']['produktzuordnung_reservierung_id']
							),
							$sql_tabs['produktzuordnung_reservierung']['fahrzeug_nummer'].'='.$db->str($rval['F_UID'])
						);
						if ($db->anzahl($res5)==0) {
							$res5=$db->select(
							$sql_tab['produktzuordnung_reservierung'],
								array(
								$sql_tabs['produktzuordnung_reservierung']['kunde'],
								$sql_tabs['produktzuordnung_reservierung']['datum_von'],
								$sql_tabs['produktzuordnung_reservierung']['datum_bis'],
								$sql_tabs['produktzuordnung_reservierung']['benutzer_id'],
								$sql_tabs['produktzuordnung_reservierung']['produktzuordnung_reservierung_id']
								),
								$sql_tabs['produktzuordnung_reservierung']['fahrzeug_nummer'].'='.$db->str($rval['Fremd_ID'])
							);
						}
						$res_ja=false;
						$ist_eigene_res=false;
						$m_rese=0;
						if ($row5=$db->zeile($res5)) {
							$rdatum=$db->unixdate_ts($row5[1]);
							$zielz=time()+124*60*60;
							if ($row5[2]!='') {
								$zielz=$db->unixdate_ts($row5[2]);
							}
							if (time() > $zielz) {
								// Reservierung nach x Stunden l�schen:
								/*$db->delete(
									$sql_tab['produktzuordnung_reservierung'],
									$sql_tabs['produktzuordnung_reservierung']['produktzuordnung_reservierung_id'].'='.$db->dbzahl($row5[4])
								);
								*/
								if ($db->unixdate_ts($row5[1])<=time() and $db->unixdate_ts($row5[2])>=time()) {
									$db->update(
										$sql_tab['produktzuordnung_reservierung'],
										array(
											$sql_tabs['produktzuordnung_reservierung']['datum_bis'] => $db->dbtimestamp(time()),
											$sql_tabs['produktzuordnung_reservierung']['bemerkung'] => $db->str(_LOESCHUNG_)
										),
										$sql_tabs['produktzuordnung_reservierung']['produktzuordnung_reservierung_id'].'='.$db->dbzahl($row5[4])
									);
								}
							} else {
								$m_res1='<br>'._RESERVIERT_.' ('._BIS_.' '.adodb_date('d.m.Y', $db->unixdate_ts($row5[2])).' '._VON_.': '.$alle_bens[$row5[3]].') '.$row5[0];
								$aktion.='<br>'._RESERVIERT_.' ('._BIS_.' '.adodb_date('d.m.Y', $db->unixdate_ts($row5[2])).' '._VON_.': '.$alle_bens[$row5[3]].') '.$row5[0];
                                $aktion70_tooltip.='<br>'._RESERVIERT_.' ('._BIS_.' '.adodb_date('d.m.Y', $db->unixdate_ts($row5[2])).' '._VON_.': '.$alle_bens[$row5[3]].') '.$row5[0];
								
                                $dvsresid='';
								if (isset($rval['Reservierung']['cReservierung'])) {
								$resarr=$rval['Reservierung']['cReservierung'];
								if (isset($rval['Reservierung']['cReservierung']['Res_ID'])) {
									$resarr=array($rval['Reservierung']['cReservierung']);
								}
								while (list($keyr, $valr)=@each($resarr)) {
									if ($valr['Res_State']=='3') {
										continue;
									}
									if ($valr['Res_State']=='1') {
										$dvsresid=$valr['Res_ID'];
									}
								}
								}
								$zusafarbe=' style="background-color:red;"';
								if ($row5[3]==$_SESSION['user_id'] or $_SESSION['user_gruppe']==2) {
									$ist_eigene_res=true;
									$aktion.='<br>'.link2(_LOESCHEN_.': '._RESERVIERUNG_, $phs.'?fremdid='.$rval['Fremd_ID'].'&fuid='.$rval['F_UID'].'&dvsresid='.$dvsresid.'&resl2='.$row5[4], '', '', 'onClick="return confirm(\''._LOESCHEN_.': '._RESERVIERUNG_.'?\');"');
                                    
                                    $aktion70[]=new Template_Link(_LOESCHEN_.': '._RESERVIERUNG_, $phs.'?fremdid='.$rval['Fremd_ID'].'&fuid='.$rval['F_UID'].'&dvsresid='.$dvsresid.'&resl2='.$row5[4], '', '', 'onClick="return confirm(\''._LOESCHEN_.': '._RESERVIERUNG_.'?\');"');
                                }
								$res_ja=true;
								$m_rese=$row5[4];
							}
						}
						if (1 or !$res_ja) {
							if (isset($rval['Reservierung']['cReservierung'])) {
								$resarr=$rval['Reservierung']['cReservierung'];
								if (isset($rval['Reservierung']['cReservierung']['Res_ID'])) {
									$resarr=array($rval['Reservierung']['cReservierung']);
								}
								$nlb=false;
								while (list($keyr, $valr)=@each($resarr)) {
									if ($valr['Res_State']=='3') {
										continue;
									}
									if (intval($dvsresid)<=0 or (intval($dvsresid)>0 and intval($dvsresid)!=intval($valr['Res_ID']))) {
										$aktion.='<br>'.'DVS-Res.: '._BIS_.' '.$db->unixdate(p4n_mb_string('substr',$valr['Res_bis'],0,10)).' '.link2(_LOESCHEN_.': '._RESERVIERUNG_, $phs.'?fuid='.$rval['F_UID'].'&dvsresid='.$valr['Res_ID'].'&resl2='.$m_rese, '', '', 'onClick="return confirm(\''._LOESCHEN_.': '._RESERVIERUNG_.'?\');"');
										
                                        $aktion70[]=new Template_Link('DVS-Res.: '._BIS_.' '.$db->unixdate(p4n_mb_string('substr',$valr['Res_bis'],0,10)).' '._LOESCHEN_.': '._RESERVIERUNG_, $phs.'?fuid='.$rval['F_UID'].'&dvsresid='.$valr['Res_ID'].'&resl2='.$m_rese, '', '', 'onClick="return confirm(\''._LOESCHEN_.': '._RESERVIERUNG_.'?\');"');
                                        
                                        if (intval($rval['Status'])!=1) {
											$res_ja=true;
										} else {
											$nlb=true;
										}
									}
								}
								if ($nlb) {
									$aktion.='<br>';
								}
							}
						}
						
						if ($cfg_kfzsuche_ang_expose) {
							$aktion.=$form->submit2('expo'.$rval['F_UID'], _EXPOSE_, 'onClick=" k_inhalt(\''.$phs.'?zi=konf&dvs=1&ajax=1&kfznl=1&expo=-1&kfznl=1&dvs_id='.$rval['F_UID'].'\', true, '.$dbr.', '.$dho.');"');
						
                            $aktion70[]=Template_Link::init(_EXPOSE_,'','','','')
                            ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&zi=konf&dvs=1&ajax=1&kfznl=1&expo=-1&kfznl=1&dvs_id='.$rval['F_UID'],$callback=array($kfzdetails_modal));
                        }
						if (!$res_ja or ($res_ja and $ist_eigene_res)) {
							$aktion.=$form->submit2('angpr'.$rval['F_UID'], _PROBEFAHRT_, 'onClick=" k_inhalt(\''.$phs.'?zi=konf&dvs=1&ajax=1&pf=-1&dvs_id='.$rval['F_UID'].'\', true, '.$dbr.', '.$dho.');"');
                            
                            $linkText = _PROBEFAHRT_;
                            if ($isInactive) {
                                $linkText = '<span style="color: lightgrey;">'.$linkText.'</span> ';
                                $linkText .= '<span style="color: red;">(inaktiv)</span>';
                            }
                            $aktion70[] = Template_Link::init($linkText, '', '', '', '')
                                ->setRequest(
                                    'GET',
                                    $kfzdetails_modal_inhalt,
                                    'kfzsuche.php',
                                    'options_menu=0&zi=konf&dvs=1&ajax=1&pf=-1&dvs_id='.$rval['F_UID'],
                                    array($kfzdetails_modal)
                                );
                            
                            $temp_pfb70_link = clone $pfb70_link;
                            Template_Trait_Obj_Helper::strreplace($temp_pfb70_link, '{fzid}', $rval['F_UID']);
                            if ($isInactive) {
                                $linkText = '<span style="color: lightgrey;">'.$temp_pfb70_link->elements[0]->text.'</span>';
                                $linkText .= ' <span style="color: red;">(inaktiv)</span>';
                                $temp_pfb70_link->elements[0]->text = $linkText;
                                $aktion70[] = $temp_pfb70_link;
                            } else {
                                $aktion70[] = $temp_pfb70_link;
                            }
                            
                            $aktion.=$form->submit2('ang'.$rval['F_UID'], _ANGEBOT_, 'onClick="k_inhalt(\''.$phs.'?zi=konf&dvs=1&ajax=1&ang=-1&kfznl=1&dvs_id='.$rval['F_UID'].'\', true, '.$dbr.', '.$dho.');"');
							if (!$cfg_kfzsuche_keinkv and !$loc_reserv_keinkv /*and !$loc_reserv*/) {
								$aktion.=$form->submit2('kv'.$rval['F_UID'], _KAUFVERTRAG_, 'onClick="k_inhalt(\''.$phs.'?zi=konf&dvs=1&ajax=1&kfznl=1&kv=-1&dvs_id='.$rval['F_UID'].'\', true, '.$dbr.', '.$dho.');"');
                                $aktion70[]=Template_Link::init(_KAUFVERTRAG_,'','','','')
                                ->setRequest($art='GET',$kfzdetails_modal_inhalt,$url='kfzsuche.php',$werte='options_menu=0&zi=konf&dvs=1&ajax=1&kfznl=1&kv=-1&dvs_id='.$rval['F_UID'],$callback=array($kfzdetails_modal));
							}
						}
						if (!$cfg_kfzsuche_keinekfzinfo) {
							$aktion.='<br>'.link2(_FAHRZEUG_.' '._INFO_, $phs.'?info=1&pid=1_'.$rval['F_UID'], '','', 'target="status"');
                            $aktion70[]=new Template_Link(_FAHRZEUG_.' '._INFO_, $phs.'?info=1&pid=1_'.$rval['F_UID'], '','', 'target="status"');
						}
						if (!$cfg_kfzsuche_keinepreisinfo) {
                            if (!$_SESSION['design_70'])
							$aktion.=' / '.preisinfolink('1_'.$rval['F_UID']); //link2($lang['_P-PREIS_'].' '._INFO_, $phs.'?preis=1&info=1&pid=1_'.$rval['F_UID'], '','', 'target="status"');
						
                            if ($_SESSION['design_70']) {
                                $preisinfolink=preisinfolink('1_'.$rval['F_UID']);
                                if (is_array($preisinfolink)) {
                                     $aktion70=array_merge($aktion70,$preisinfolink);
                                } else {
                                     $aktion70[]=preisinfolink($row[0]);
                                }
                            }
                        }
						
						$kstatus=$dvs_stati[intval($rval['Status'])];
						if (!$cfg_dvs_fm and ($kstatus=='Auktion vorgesehen' or $kstatus=='Premiumaktion vorgesehen' or $kstatus=='Ausschreibung')) {
							$res_ja=true;	// keine Res.
							if (isset($rval['Auktionsdatum'])) {
								$rts=$db->unixdate_ts($rval['Auktionsdatum']);
								if (adodb_date('Y', $rts)=='1900' or $rval['Auktionsdatum']=='') {
									$res_ja=false;
								} else {
									$bis_res=$rts-3*24*60*60;
									$bis_res=adodb_mktime(23,59,59, adodb_date('m', $bis_res), adodb_date('d', $bis_res), adodb_date('Y', $bis_res));
									if (time()<=$bis_res) {
										// Res. noch bis 3 Tage vor Ende
										$res_ja=false;
									}
								}
							} else {
								$res_ja=false;
							}
						}
						
						if (isset($cfg_kfzsuche_dbrent_reslao)) {
							$laokeineres=true;
							if (isset($cfg_kfzsuche_dbrent_reslao[$rval['Lagerort']])) {
								if (intval($_SESSION['user_standard_lagerort'])>0) {
									if (intval($_SESSION['user_standard_lagerort'])==$cfg_kfzsuche_dbrent_reslao[$rval['Lagerort']]) {
										$laokeineres=false;
									}
								}
							}
						}
						
						if (!$laokeineres and !$res_ja and !$akt_kl4 and !$cfg_kfzsuche_keinereservierung) {
						if ($cfg_kfzsuche_reservierung_frei) {
							$aktion.=' / '.link2(_RESERVIERUNG_, 'javascript: oeffne_resform(\'1_'.$rval['F_UID'].'___'.$rval['Fremd_ID'].'\', '.doubleval($rval['Internetpreis']).');');
						
                            $aktion70[]=new Template_Link(_RESERVIERUNG_, 'javascript: oeffne_resform(\'1_'.$rval['F_UID'].'___'.$rval['Fremd_ID'].'\', '.doubleval($rval['Internetpreis']).');');
                        } else {
							$aktion.=' / '.link2(_RESERVIERUNG_, $phs.'?res=1_'.$rval['F_UID'], '', '', 'onClick="return confirm(\''._RESERVIERUNG_.'?\');"');
                            $aktion70[]=new Template_Link(_RESERVIERUNG_, $phs.'?res=1_'.$rval['F_UID'], '', '', 'onClick="return confirm(\''._RESERVIERUNG_.'?\');"');
						}
						}
						if (intval($rval['Status'])!=1) {
//							$aktion=$m_res1;
						}
						$inpaketaktiv=false;
						if ($cfg_kfzsuche_pakete) {
							if (($rval['F_UID']!='' and isset($alle_paket_ids[trim($rval['F_UID'])])) or ($rval['Fahrgestellnummer']!='' and isset($alle_paket_ids[trim($rval['Fahrgestellnummer'])]))) {
								$pakbez=$alle_paket_ids[trim($rval['F_UID'])];
								if ($pakbez=='') {
									$pakbez=$alle_paket_ids[trim($rval['Fahrgestellnummer'])];
								}
								if (isset($getfeld['paket']) and $getfeld['paket']!='-1' and ($getfeld['paket']==$alle_paket_ids2[trim($rval['F_UID'])] or $getfeld['paket']==$alle_paket_ids2[trim($rval['Fahrgestellnummer'])])) {
									$aktion.='<br><font color=red>'._PAKET_.': '.$pakbez.'</font>';
                                    $aktion70_tooltip.='<br><font color=red>'._PAKET_.': '.$pakbez.'</font>';
								} else {
									$inpaketaktiv=true;
									$aktion='<br><font color=red>'._PAKET_.': '.$pakbez.'</font>';
                                    $aktion70=array();
                                    $aktion70_tooltip='<br><font color=red>'._PAKET_.': '.$pakbez.'</font>';
								}
//								$aktion.='<br><font color=red>'._PAKET_.': '.$pakbez.'</font>';
							} elseif (isset($rval['Paket']) and $rval['Paket']!='') {
								$inpaketaktiv=true;
								$aktion='<br><font color=red>'._PAKET_.': '.$rval['Paket'].'</font>';
                                $aktion70=array();
                                $aktion70_tooltip='<br><font color=red>'._PAKET_.': '.$rval['Paket'].'</font>';
							}
						}

						if ($cfg_kfzsuche_pakete and is_numeric($getfeld['paket']) and intval($getfeld['paket'])>0) {
							$aktion.='<br>'.$form->checkinput('paketaenderung['.$rval['F_UID'].']', (isset($aktive_ids[$rval['F_UID']])?true:false), 'onClick="dazu1=0; if (this.checked) { dazu1=1; } aendere_paket(\''.$rval['F_UID'].'\', dazu1);"').' '.$paket_t;
						}
						if ($cfg_kfzsuche_verkaufmerken and !$inpaketaktiv and !$res_ja) {
						//	$aktion.='<br>'.link2(_VERKAUF_VORMERKEN_, $phs.'?verkaufmerken=1&fuid='.$rval['F_UID'], '', '', 'onClick="return confirm(\''._VERKAUF_VORMERKEN_.'?\');"');
						}
						if (intval($rval['Status'])==10 or intval($rval['Status'])==22) {	// or intval($rval['Status'])==12 
							$aktion='';
                            $aktion70=array();
                            $aktion70_tooltip='';
							$aktion.=$form->submit2('angpr'.$rval['F_UID'], _PROBEFAHRT_, 'onClick=" k_inhalt(\''.$phs.'?zi=konf&dvs=1&ajax=1&pf=-1&dvs_id='.$rval['F_UID'].'\', true, '.$dbr.', '.$dho.');"');

                            $linkText = _PROBEFAHRT_;
                            if ($isInactive) {
                                $linkText = '<span style="color: lightgrey;">'.$linkText.'</span> ';
                                $linkText .= '<span style="color: red;">(inaktiv)</span>';
                            }
                            $aktion70[] = Template_Link::init($linkText, '', '', '', '')
                                ->setRequest($art = 'GET', $kfzdetails_modal_inhalt, $url = 'kfzsuche.php', $werte = 'options_menu=0&zi=konf&dvs=1&ajax=1&pf=-1&dvs_id='.$rval['F_UID'], $callback = array($kfzdetails_modal));
                            
                            if ($isInactive) {
                                $linkText = '<span style="color: lightgrey;">'.$temp_pfb70_link->elements[0]->text.'</span>';
                                $linkText .= ' <span style="color: red;">(inaktiv)</span>';
                                $temp_pfb70_link->elements[0]->text = $linkText;
                                $aktion70[] = $temp_pfb70_link;
                            } else {
                                $aktion70[] = $temp_pfb70_link;
                            }
                        }

						$kstatus=$dvs_stati[intval($rval['Status'])];
						
						if (!$cfg_dvs_fm and ($kstatus=='Auktion' or $kstatus=='Auktion vorgesehen' or $kstatus=='Premiumaktion vorgesehen' or $kstatus=='Ausschreibung') and isset($rval['Auktionsdatum'])) {
							$anz_dvs_auktionsdat=$db->unixdate($rval['Auktionsdatum']);
							if (adodb_date('Y', $db->unixdate_ts($rval['Auktionsdatum']))==1900) {
								$anz_dvs_auktionsdat='noch nicht bekannt';
							}
							$aktion.='<br>Auktionsdatum: '.$anz_dvs_auktionsdat;
                            $aktion70_tooltip.='<br>Auktionsdatum: '.$anz_dvs_auktionsdat;
						}
						
						//$standtage=(time()-$db->unixdate_ts(p4n_mb_string('substr',$rval['Ankauf']['Datum_Ankauf'], 0, 10))) / (24*60*60);
						$standtage=$rval['Standtage'];
						$zus_schln='';
						if ($rval['Schluesselnummer']!='') {
							$zus_schln.='<br>SN: '.$rval['Schluesselnummer'];
						}
						$preis=number_format(doubleval($rval['Internetpreis']), 2, ",", ".").' '.$waehrung_eur;
						$preis_anz=oltext('Angebotspreis: '.number_format(doubleval($rval['Angebotspreis']), 2, ",", ".").' '.$waehrung_eur.'<br>'.'Internetpreis: '.number_format(doubleval($rval['Internetpreis']), 2, ",", ".").' '.$waehrung_eur.'<br>'.'Haendlerpreis: '.number_format(doubleval($rval['Haendlerpreis']), 2, ",", ".").' '.$waehrung_eur.' NETTO', $preis);
						$stao='<br>'.oltext('<font size=1>Lagerort: './*$rval['Filiale'].' / '.*/(isset($dvs_lagerorte2[$rval['Lagerort']])?$dvs_lagerorte2[$rval['Lagerort']]:$rval['Lagerort']).' / Standort: '.(isset($dvs_lagerorte2[$rval['Standort']])?$dvs_lagerorte2[$rval['Standort']]:$rval['Standort']).'</font>', '<font size=1>'.(isset($dvs_lagerorte2[$rval['Lagerort']])?$dvs_lagerorte2[$rval['Lagerort']]:$rval['Lagerort']).'</font>');

						if (isset($rval['Stellplatz'])) {
							if ($rval['Stellplatz']!='') {
								$stao.=' / '.$rval['Stellplatz'];
							}
						}
						if (isset($rval['Transportauftrag'])) {
							if ($rval['Transportauftrag']!='' and p4n_mb_string('strlen',$rval['Transportauftrag'])>=2) {
								$stao.='<br><font color=red>Transportauftrag: '.$rval['Transportauftrag'].'</font>';
							}
						}

//						$dvs_laot=$dvs_lagerorte2;
//						unset($dvs_laot[$rval['Lagerort']]);
//						$stao2='<br>'._NEU_.': '.$form->selectinput('laoaenderung['.$rval['F_UID'].']', $dvs_laot, -99, _KEINE_AUSWAHL_).$form->submit2('laoaenderung_button['.$rval['F_UID'].']', _OK_, 'onClick="if (this.form.elements[\'laoaenderung['.$rval['F_UID'].']\'].selectedIndex>0) { if (confirm(\''._VORGANG_ABFRAGE_.'\')) { aendere_lao(\''.$rval['F_UID'].'\', this.form.elements[\'laoaenderung['.$rval['F_UID'].']\'].value); }}"');

						$ausst2='';
						$expl=explode(',', $rval['Ausstattung_Text']);
						while (list($akey, $aval)=@each($expl)) {
							$ausst2.=trim($aval).'<br>';
						}
						$ausst2=p4n_mb_string('substr',$ausst2, 0, -4);
						$ausst=$ausst2;//$rval['Ausstattung_Text'];
/*						if (isset($rval['Ausstattung_List']['cAusstattung']['AShort_ID'])) {
							$val2=$rval['Ausstattung_List']['cAusstattung'];
							if ($val2['AShort_Text']!='') {
								$ausst.='<br>'.$val2['AShort_MappID'].' '.$val2['AShort_Text'];
							}
						} else {
							while (list($key2, $val2)=@each($rval['Ausstattung_List']['cAusstattung'])) {
								if ($val2['AShort_Text']!='') {
									$ausst.='<br>'.$val2['AShort_MappID'].' '.$val2['AShort_Text'];
								}
							}
						}
*/
						if (trim($rval['VK_BEZ'])=='') {
							$rval['VK_BEZ']=trim($rval['Modell'].' '.$rval['Version']);
						}
						$stao_csv=(isset($dvs_lagerorte2[$rval['Lagerort']])?$dvs_lagerorte2[$rval['Lagerort']]:$rval['Lagerort']);
						if (isset($dvs_lagerorte2[$rval['Standort']]) and $dvs_lagerorte2[$rval['Standort']]!=$stao_csv) {
							if ($dvs_lagerorte2[$rval['Standort']]!='') {
								$stao_csv=$dvs_lagerorte2[$rval['Standort']];
							}
						}

						$mindwerte='';
						if (isset($rval['Minderwert_Manuell']) and doubleval($rval['Minderwert_Manuell'])>0) {
							$mindwerte='Minderwerte: '.number_format(doubleval($rval['Minderwert_Manuell']), 2, ",", ".");
						}
						$farbe1=$dvs_farbcodes2[intval($rval['Farbschema'])];
						if (isset($rval['Attribute']['item'])) {
							while (list($key22, $val22)=@each($rval['Attribute']['item'])) {
								$val22=$val22['value']['cFAttr'];
								if ($val22['AttrName']=='Farbe_Aussen' and $val22['AttrValue']!='') {
									$farbe1=$val22['AttrValue'];
								}
							}
						}
						if ($mit_export) {
							$csv_block.='"'.$rval['Fabrikat'].'";"'.trim($rval['VK_BEZ']).'";"'.$rval['km_Stand'].'";"'.p4n_mb_string('substr',$rval['Erstzulassung'], 0, 10).'";"'.$rval['Leistung_PS'].'";"'.$farbe1.'";"'.number_format(doubleval($rval['Internetpreis']), 2, ",", "").'";"'.$stao_csv.'";"'.$rval['Fahrgestellnummer'].'";"'.str_replace(array("\n", "\r", '<br>'), ', ', $ausst).'";"'.($rval['Fremd_ID']!=''?$rval['Fremd_ID']:$rval['DVS_ID']).'";"'.$cfg_dvs_aufbau[$rval['Art_Aufbau']].'";"";"'.$rval['Hubraum'].'";"'.$cfg_dvs_treibstoff[$rval['Art_Treibstoff']].'";"'.$rval['Leistung_KW'].'";"'.$mindwerte.'"'."\r\n";
							$csv_blockh.='"'.$rval['Fabrikat'].'";"'.trim($rval['VK_BEZ']).'";"'.$rval['km_Stand'].'";"'.p4n_mb_string('substr',$rval['Erstzulassung'], 0, 10).'";"'.$rval['Leistung_PS'].'";"'.$farbe1.'";"'.number_format(doubleval($rval['Haendlerpreis']), 2, ",", "").'";"'.$stao_csv.'";"'.$rval['Fahrgestellnummer'].'";"'.str_replace(array("\n", "\r", '<br>'), ', ', $ausst).'";"'.($rval['Fremd_ID']!=''?$rval['Fremd_ID']:$rval['DVS_ID']).'";"'.$cfg_dvs_aufbau[$rval['Art_Aufbau']].'";"";"'.$rval['Hubraum'].'";"'.$cfg_dvs_treibstoff[$rval['Art_Treibstoff']].'";"'.$rval['Leistung_KW'].'";"'.$mindwerte.'"'."\r\n";
						}
						$groe_vinanz=1;
						if (isset($cfg_kfzsuche_vinanzeige_gross) and intval($cfg_kfzsuche_vinanzeige_gross)>0) {
							$groe_vinanz=$cfg_kfzsuche_vinanzeige_gross;
						}
						$block='<tr'.tr_zeile().'><td>{nr}</td><td>'.$unfa.$rval['Fabrikat'].$stao.'</td><td>'.oltext('<font size=3><pre>'.$ausst.'</pre></font>', $rval['VK_BEZ'], 'javascript: k_inhalt(\''.$phs.'?fuid='.$rval['F_UID'].'&dvsdetail=1\', true, '.$dbr.', '.$dho.');', _DETAILS_).'<br><font size='.$groe_vinanz.'>'.$rval['Fahrgestellnummer'].' / '.$rval['Fremd_ID'].'</font></td><td>'.$rval['Leistung_PS'].'</td><td>'.$farbe1.'</td><td>'.$dat_ez.'</td><td>'.$kennz.'</td><td>'.$rval['km_Stand'].'</td><td>'.$preis_anz.'</td><td>'.round($standtage).$zus_schln.'</td><td'.$zusafarbe.'>'.$kstatus.' '.$aktion.$stao2.'</td></tr>';
						
						$zusblock='';
						if ($cfg_kfzsuche_pfbalken and !isset($postfeld['nur_ids'])) {
							$tbl=' style="font-size: 8pt;"';
							if (isset($pfb[$rval['DVS_ID']])) {
								$zusblock='<tr><td>{nr}</td><td colspan=100><table'.$tbl.'>'.$pfb[$rval['DVS_ID']].'</table></td></tr>';
							} else {
								$zusblock='<tr><td>{nr}</td><td colspan=100><table'.$tbl.'>'.$pfb[0].'</table></td></tr>';
							}
						}
						if (isset($getfeld['export_keineliste'])) {
							
						} else {
							
						$dblock[$zi]=$block.$zusblock;
						$sortindex='';
						if ($getfeld['sort']==$sql_tabs['produktzuordnung']['markencode']) {
							$sortindex=$rval['Fabrikat'];
						} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['typ_modell']) {
							$sortindex=$rval['VK_BEZ'];
						} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['leistung_ps']) {
							$sortindex=intval($rval['Leistung_PS']);
						} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['farbbezeichnung']) {
							$sortindex=$dvs_farbcodes2[intval($rval['Farbschema'])];
						} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['datum_ez']) {
							$sortindex=$dat_ez2;
						} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['kennzeichen']) {
							$sortindex=$kennz;
						} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['km_stand']) {
							$sortindex=intval($rval['km_Stand']);
						} elseif ($getfeld['sort']==$sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst']) {
							$sortindex=intval($rval['Internetpreis']);
						} elseif ($getfeld['sort']=='10') {
							$sortindex=$standtage;
						} else {
							$sortindex=intval($rval['Internetpreis']);
						}
							$sblock[$zi]=$sortindex;
						}
						$sorto2='1';
						$zi++;
						$zi2++;
					}

					}// Ende if (isset($result['getFahrzeugListeResult']['cFahrzeug'])) {
					$anz_dvs=$zi2;
//					echo 'Anzahl DVS: '.$anz_dvs.'<br>';
				}
				
				if ($kfzs_debug) {
					if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
						fwrite($fp, $kfzslog_sel);
						fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'nach DVS-Schleife'."\r\n");
						fclose($fp);
					}
				}
				
/*				echo '<pre>';
				print_r($suchfeld3);
				echo '</pre>';
*/			}
		}

	}
	$zus_anz1=intval($anz+$anz_dvs);
	if ($ges_anz1==0) {
		$ges_anz1=$zus_anz1;
	}
//echo $zus_anz1.'/ i: '.$i.' / '.$ges_anz1;
	if (isset($getfeld['limitauswahl']) and $ges_anz1>0 and $ges_anz1!=intval($i)) {
		if (1 or intval($getfeld['limitauswahl'])>0) {
			$zus_anz1=$i.' / '.$ges_anz1;
		}
	}
	
	$inhalt=str_replace('{anz_kfz}', $zus_anz1, $inhalt);

					if ($kfzs_debug) {
						if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
							fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'vor Sortierung'."\r\n");
							fclose($fp);
						}
					}

	if (is_array($dblock) && count($dblock)>0) {
	//	if ($tabe!='') {

		if ($sorto2!='') {
			if ($getfeld['order']=='asc')
				@array_multisort($sblock, SORT_ASC, $dblock);
			elseif ($getfeld['order']=='desc')
				@array_multisort($sblock, SORT_DESC, $dblock);
			else {
				@array_multisort($sblock, SORT_ASC, $dblock);
			}
		}
					if ($kfzs_debug) {
						if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
							fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'nach Sortierung'."\r\n");
							fclose($fp);
						}
					}


		$tabe='';
		$zi=1;
		while (list($key, $val)=@each($dblock)) {
/*			if (!($zi%10)) {
				$ges2.=$zkopf;
			}
*/
			$val=str_replace('{nr}', $zi, $val);
			$tabe.=$val;
			$zi++;
		}
		
		if ($cfg_kfzsuche_keindispo) {
					if ($kfzs_debug) {
						if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
							fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'vor Dispoersetzung'."\r\n");
							fclose($fp);
						}
					}
			if ($kdopp_pids!='') {
				$kd_alle_opps=array();
				$kdopp_pids=substr($kdopp_pids, 0, -1);
				$res3=$db->select(
						$sql_tab['opportunity'],
						array(
							$sql_tabs['opportunity']['opportunity_id'],
							$sql_tabs['opportunity']['stammdaten_id'],
							$sql_tabs['opportunity']['bemerkung'],
							$sql_tabs['opportunity']['phase'],
							$sql_tabs['opportunity']['betrag'],
							$sql_tabs['opportunity']['datum_eintrag'],
							$sql_tabs['opportunity']['benutzer_id'],
							$sql_tabs['opportunity']['produkt_id']
						),
						$sql_tabs['opportunity']['produkt_id'].' in ('.$kdopp_pids.') and '.$sql_tabs['opportunity']['phase'].'='.$db->str(_ANGEBOT_),
						$sql_tabs['opportunity']['datum_eintrag'].' desc'
				);
					if ($kfzs_debug) {
						if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
							fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'nach Select Dispoersetzung'."\r\n");
							fclose($fp);
						}
					}
				while ($row3=$db->zeile($res3)) {
					$kd_alle_opps[$row3[7]].='<b>'._ANGEBOT_.' '.$db->unixdatetime($row3[5]).': '.kundenbezeichnung($row3[1]).' ('.number_format(doubleval($row3[4]), 2, ",", ".").' '.$waehrung_eur.' - '.$alle_bens[$row3[6]].' - '.$row3[3].')</b><br>'.$row3[2].'<hr>';
				}
				while (list($key1, $val1)=@each($kd_alle_opps)) {
					$tabe=p4n_mb_string('str_replace', '{at_'.$key1.'}', olovertext($val1), $tabe);
				}
					if ($kfzs_debug) {
						if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
							fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'nach Dispoersetzung'."\r\n");
							fclose($fp);
						}
					}
			}
		}
		$zuspsue='';
		if ($cfg_kfzsuche_motorgetriebe_beips) {
			$zuspsue=' - M/G';
		}
		if (isset($getfeld['kurz']) and !isset($postfeld['nur_ids'])) {
			$kopf='<tr><th>'._MARKENCODE_.' {sort-2} '.$lang['_PZ-TYP-MODELL_'].' {sort-3}<br>'._FAHRGESTELL_.'</th>
				<th>'._KM_.' {sort-8} '._KFZ_EZ_.' {sort-6}<br>'._KZKURZ_.'</th>
				<th>'.'KW/PS {sort-4}'.'<br>'._FARBE_.' {sort-5}</th>
				<th>'._AKTUELLERVKPREIS_.'<br>{sort-9}'.($cfg_kfzsuche_sortlistenpreis?'<br>'._LISTENPREIS_.'<br>{sort-11}':'').'</th>
				<th>'._STANDORT_.'<br>'._STANDTAGE_.' {sort-10}</th><th>'._AKTION_.'</th></tr>';
		} else {
				$zus_rd234='';
				if ($_SESSION['cfg_kunde']=='carlo_opel_ruhrdeich') {
					$zus_rd234='<th>Notizen</th>';
				}
		//<th>'.'Plan-VKPreis'.'</th><!--<th>'.'WEM'.'</th>--><th>'.'EK-Preis'.'</th>
$kopf='<tr><th>'._NR_.'</th><th>'._MARKENCODE_.'<br>{sort-2}</th><th>'.$lang['_PZ-TYP-MODELL_'].'<br>{sort-3}</th>'.$zus_rd234.'<th>'._PS_.$zuspsue.'<br>{sort-4}'.'</th><th>'._FARBE_.'<br>{sort-5}</th><th>'.$lang['_PZ-ERSTZULASSUNG_'].'<br>{sort-6}</th>'.($cfg_kfzsuche_ergebnis_keinkennzeichen?'':'<th>'.$lang['_PZ-KENNZEICHEN_'].'<br>{sort-7}</th>').($cfg_carlo_appserver_activity?'<th>H�ndlerstatus</th>':'').'<th>'._KMSTAND_.'<br>{sort-8}</th><th>'._AKTUELLERVKPREIS_.'<br>{sort-9}'.($cfg_kfzsuche_sortlistenpreis?'<br>'.($cfg_kfzsuche_dd2020?'UPE lt. Hersteller (inkl.Fracht)':_LISTENPREIS_).'<br>{sort-11}':'').($cfg_kfzsuche_suche_minderwertmanuell?'<br>Minderwert<br>{sort-12}':'').'</th><th>'._STANDTAGE_.'<br>{sort-10}</th><th>'._AKTION_.'</th>'.$zusspalte_n2.'</tr>';//<th>'.'Vorbesitzer'.'</th><th>'.'Anzahl Vorbesitzer'.'</th>
		}

		$sodb=array(
			2 => $sql_tabs['produktzuordnung']['markencode'],
			3 => $sql_tabs['produktzuordnung']['typ_modell'],
			4 => $sql_tabs['produktzuordnung']['leistung_ps'],
			5 => $sql_tabs['produktzuordnung']['farbbezeichnung'],
			6 => $sql_tabs['produktzuordnung']['datum_ez'],
			7 => $sql_tabs['produktzuordnung']['kennzeichen'],
			8 => $sql_tabs['produktzuordnung']['km_stand'],
			9 => $sql_tabs['produktzuordnung']['aktuellervkpreis_mw_mwst'],
			10 => '10',
			11 => $sql_tabs['produktzuordnung']['aktueller_listenpreis_mwst'],
			12 => $sql_tabs['produktzuordnung']['mindest_vkpreis']
		);
		
		if ($cfg_kfzsuche_verkaufthaken) {
			$getfeld['verkauftenicht2']=$getfeld['verkauftenicht'];
		}
		@reset($getfeld);
		while (list($key, $val)=@each($getfeld)) {
			if ($val!=='' and $key!='sort') {
				if (is_array($val)) {
					@reset($val);
					while (list($key2, $val2)=@each($val)) {
						if ($val2!='' and ($key2!='sort' or is_numeric($key2))) {
							$getsort_add.=$key.'['.$key2.']='.$val2.'&';
						}
					}
				} else {
					$getsort_add.=$key.'='.$val.'&';
				}
			}
		}
		$sv='';
		for ($si=1; $si<=15; $si++) {
			$val[1]=$sodb[$si];
			if (isset($getfeld['kurz'])) {
				$sortl=link2('', 'javascript: lade_ergebnis(\'v2=1&'.$getsort_add.'sort'.$sv.'='.$val[1].'&order=asc'.'\');', 'pfeil_oben'.(($_GET['sort'.$sv]==$val[1] and $_GET['order']=='asc')?'_a':'').'.gif').link2('', 'javascript: lade_ergebnis(\'v2=1&'.$getsort_add.'sort'.$sv.'='.$val[1].'&order=desc'.'\');', 'pfeil_unten'.(($_GET['sort'.$sv]==$val[1] and $_GET['order']=='desc')?'_a':'').'.gif');
			} else {
				$sortl=link2('', $phs.'?'.$getsort_add.'sort'.$sv.'='.$val[1].'&order=asc', 'pfeil_oben'.(($_GET['sort'.$sv]==$val[1] and $_GET['order']=='asc')?'_a':'').'.gif').link2('', $phs.'?'.$getsort_add.'sort'.$sv.'='.$val[1].'&order=desc', 'pfeil_unten'.(($_GET['sort'.$sv]==$val[1] and $_GET['order']=='desc')?'_a':'').'.gif');
			}
			if (isset($postfeld['nur_ids'])) {
				$sortl='';
			}
			$kopf=str_replace('{sort-'.$si.'}', $sortl, $kopf);
		}

		$inhalt.='<table class="table-jsfixed moderntable table-art-2" '.($cfg_kfzsuche_pfkal_farbzeilen?'data-nth="2"':'').'>'.$kopf.$tabe.'</table>';
					if ($kfzs_debug) {
						if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
							fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'vor Ausgabe'."\r\n");
							fclose($fp);
						}
					}


		if (isset($postfeld['nur_ids'])) {
			$tabe=str_replace('k_inhalt', 'parent.k_inhalt', $tabe);
			$tabe=str_replace('rechne_summe', 'parent.rechne_summe', $tabe);
			echo '<table class="table-margin-bottom">'.$kopf.$tabe.'</table>';
/*
$x1=ob_get_contents();
ob_end_clean();
echo p4n_mb_string('htmlentities',$x1);
 * 
            */
            if ($cfg_modern) {
                Modern_Helper_Request::requestFlush();
            }
            die();
		}
		if (isset($getfeld['kurz'])) {
			$inhalt.=javas('function lade_ergebnis(url1) {
			try {
				xmlhttp = new XMLHttpRequest();
			} catch (error) {
				try {
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (error) {}
			}
			xmlhttp.open("POST", "'.$phs.'", false);
			xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			xmlhttp.send(url1);
			response=xmlhttp.responseText;
			divxyz=document.getElementById("ergframe");
			divxyz.innerHTML=response;
			}
			');
		}
		
		if ($cfg_kfzsuche_pfkal_woche_scrollen) {
			$inhalt.=javas('
			function lade_wkal(vz, ziel1) {
                if (typeof p4ntoken == "undefined") {p4ntoken="";}
                                var xmlhttp;
                                try { xmlhttp = new XMLHttpRequest(); } catch (error) {
                                        try { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); } catch (error) { return false;	}
                                }

                                xmlhttp.open("POST", "'.$phs.'", false);
                                
                                xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                                xmlhttp.setRequestHeader("X-Requested-With", "XMLHttpRequest"); 
                                
                                xmlhttp.onreadystatechange=function() { 
                                        if (xmlhttp.readyState==4 && xmlhttp.status==200) {
                                            if (typeof getNewToken == "function") {
                                                p4ntoken = getNewToken(xmlhttp.getResponseHeader("p4ntoken"));
                                            }
                                            response=xmlhttp.responseText;
                                            document.getElementById(ziel1).innerHTML=response;
                                            if (design_70) {
                                                document_ready();
                                                window_load();
                                            }
                                        }
                                };
                                xmlhttp.send("genpfwoche="+vz+"&pftrid="+ziel1+"&p4ntoken="+p4ntoken);
			}');
		}
		
		if ($cfg_ws_avag_kroatien or $cfg_kfz_webservice or $cfg_letztevkp_genehmigung2_mail) {
			$inhalt.=javas('
				function check_kroa_status2(pid1) {
				var xmlhttp;
				try { xmlhttp = new XMLHttpRequest(); } catch (error) {
					try { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); } catch (error) { return false;	}
				}
				xmlhttp.open("POST", "'.$phs.'", false);
				xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
				xmlhttp.send("check_kroa_status=1&pidk="+pid1);
				response=xmlhttp.responseText;
				var ret=true;
				if (response!="") {
					alert(response);
'.($cfg_kfz_webservice?'ret=false;':'').'
				}
				return ret;
			}
			');
		}

		if (isset($getfeld['pfkal'])) {
		$res=$db->select(
				$sql_tab['kalender_zusatz'],
				$sql_tabs['kalender_zusatz']['kalender_zusatz_id'],
				$sql_tabs['kalender_zusatz']['bezeichnung'].'='.$db->str(_PROBEFAHRT_)
		);
		if ($row=$db->zeile($res)) {
				include_once('kalender_class.php');
/*				include_once("class.overlib.php");
				$ol = new Overlib();
				$ol->set("width",500);
*/
				$inhalt.=javas('var merke=new Array(35);
		var merke2=new Array(35);
		function ze1(zelle, tag) {
			merke[tag]=zelle.style.borderColor;
			merke2[tag]=zelle.style.borderStyle;
			zelle.style.borderColor="#000000";
			zelle.style.borderStyle="solid";
			zelle.style.borderWidth="1px";
		}
		function ze2(zelle, tag) {
			zelle.style.borderColor=merke[tag];
			zelle.style.borderStyle=merke2[tag];
		}');

				$uid=$_SESSION['user_id'];
				$zusatz_id=$row[0];
				$_SESSION['kalender_benutzername']=' - '._PROBEFAHRT_;
				$stid=0;
				$m_phs=$phs;
				$phs='kalender.php';

				$cfg_kalendertermin_ersteller=true;
				
				$_SESSION['pf_termincheck']=true;
				if (isset($getfeld['pfkal_kfz'])) {
					$allepfkal_kids='0';
					if ($alle_kfzs_ids!='') {
						$alle_kfzs_ids=substr($alle_kfzs_ids, 0, -1);
						$_SESSION['pf_nurpids']=$alle_kfzs_ids;
					}
				}
				$kal_lese=true;
				$kal=new event_calendar();
				$month=adodb_date('m');
				$year=adodb_date('Y');
				$kal->set_date(1, $month, $year);
				$monat1=$kal->gen_month_table($uid, $zusatz_id, $stid);

				$t2=time();
				while (adodb_date('m', $t2)==$month) {
					$t2+=24*60*60;
				}
				$month2=adodb_date('m', $t2);
				$year2=adodb_date('Y', $t2);
				$kal->set_date(1, $month2, $year2);
				$monat2=$kal->gen_month_table($uid, $zusatz_id, $stid);

				while (adodb_date('m', $t2)==$month2) {
					$t2+=24*60*60;
				}
				$month3=adodb_date('m', $t2);
				$year3=adodb_date('Y', $t2);
				$kal->set_date(1, $month3, $year3);
				$monat3=$kal->gen_month_table($uid, $zusatz_id, $stid);
				$inhalt.='<table><tr><td>'.$lang['_MONAT'.intval($month).'_'].' '.$year.'<br>'.$monat1.'</td><td>'.$lang['_MONAT'.intval($month2).'_'].' '.$year2.'<br>'.$monat2.'</td><td>'.$lang['_MONAT'.intval($month3).'_'].' '.$year3.'<br>'.$monat3.'</td></tr></table>';
				unset($_SESSION['pf_termincheck']);
				unset($_SESSION['pf_nurpids']);
				$phs=$m_phs;
		}
		}
	}
	
	if ($alle_kfzs_ids!='') {
		$_SESSION['pf_mallepids']=trim($alle_kfzs_ids, ',');
	}
	
	$inhalt.=$form->ende();
    if ($cfg_modern) {
        $inhalt.='</div>';//neu  
    }
					if ($kfzs_debug) {
						if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
							fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'nach Ausgabe'."\r\n");
							fclose($fp);
						}
					}
	
	
	$sgr_tab=6;
	$pdf_variante2=false;
	if ($_SESSION['cfg_kunde']=='carlo_opel_toennemann') {
		$pdf_variante2=true;
		$sgr_tab=8;
	}
	
	if (isset($kfzs_nurdaten)) {
		ob_end_clean();
		$alle_kfzs_ids=p4n_mb_string('substr',$alle_kfzs_ids, 0, -1);
		echo $obdaten1;
		return;
	}
	
if ($mit_export) {
					if ($kfzs_debug) {
						if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
							fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'vor Export'."\r\n");
							fclose($fp);
						}
					}


	for ($z=1; $z<=2; $z++) {

		$dateizus='';
		$dateizus2='';
		if ($z==2) {
			$csv_block=$csv_blockh;
			$dateizus=' '._NETTOPREISE_;
			$dateizus2='_h';
		}
	if ($csv_block!='') {
		if (p4n_mb_string('substr_count',$csv_block, '";"')>10) {
			// PDF:
			$inhalt.='<!shd2><!shd1>'.css_kopf(_EXPORT_);
			if (isset($getfeld['export_pdf'])) {
				include_once('p4n_pdf/p4n_pdf.php');
				$pdf_doc = new p4n_pdf('L');
				$pdf_doc->setMargin(20);
				$pdf_doc->setInformation(_STAMMDATEN_NAV_LISTE_.' '._FAHRZEUGE_, _STAMMDATEN_NAV_LISTE_.' '._FAHRZEUGE_, $_SESSION['mitarbeiter_name']);
				if ($pdf_variante2) {
					$pdf_doc->setKopfZeile(true, _HAENDLER_.' '._OM_PHASE3_, 'B', 14);
				} else {
					$pdf_doc->setKopfZeile(true, _STAMMDATEN_NAV_LISTE_.' '._FAHRZEUGE_, 'B', 14);
				}
				$pdf_doc->AddPage();

				$tabdata='<TABLE border=1>';
				$tabdata.='<TR><TD>'._REFERENZZEICHEN_.'</TD><TD>'._FAHRGESTELLNUMMER_.'</TD><TD>'._TRVTYPMODELL_.'</TD><TD></TD><TD></TD><TD>'._STANDORT_.'</TD><TD>'._STELLPLATZ_.'</TD><TD>'._PREIS_.'</TD></TR>';
				$tabdata.='<TR><TD></TD><TD>'._AUFBAU_TUEREN_.'</TD><TD>ccm '._KW_LEISTUNG_.'</TD><TD>'._KFZ_EZ_.'</TD><TD>'._KMSTAND_.'</TD><TD>'._FARBE_.'</TD><TD>'._AUSSTATTUNG_.'</TD><TD>'._BEMERKUNG_.'</TD></TR>';
				$datenp=preg_split("/\r\n/", $csv_block);
				$anz=0;
				$neuseite=false;
				$anz2=0;
				while (list($key, $val)=@each($datenp)) {
					$expl=explode('";"', $val);
					$expl[0]=ltrim($expl[0], '"');
					$expl[count($expl)-1]=rtrim($expl[count($expl)-1], '"');
					if (count($expl)<5) {
						continue;
					}
					if ($neuseite or $key==0) {
						if ($neuseite) {
							$pdf_doc->AddPage();
						}
						$tabdata2=array();
						if ($pdf_variante2) {
							$tabdata2[0]=array(_REFERENZZEICHEN_, _FAHRGESTELLNUMMER_, _KFZ_EZ_,           _KMSTAND_, _PREIS_, _PREIS_);
							$tabdata2[1]=array('',         _AUFBAU_TUEREN_,    'ccm '._KW_LEISTUNG_, _FARBE_, _INKL_GESETZL_MWST_, _NETTO_);
						} else {
							$tabdata2[0]=array(_REFERENZZEICHEN_, _FAHRGESTELLNUMMER_, _KFZ_EZ_,           _KMSTAND_, _STANDORT_, _PREIS_);
							$tabdata2[1]=array('',         _AUFBAU_TUEREN_,    'ccm '._KW_LEISTUNG_, _FARBE_,    '', ($z==2?_ZZGL_GESETZL_MWST_:_INKL_GESETZL_MWST_));
						}
						$pdf_doc->writeTable($tabdata2, $header = '', $align = 'J', $fontsize = $sgr_tab, $breite = 0, $border = 0, $spacing = 1);
						$pdf_doc->drawLine(false, '', '', 0.2);
						$neuseite=false;
						if ($key==0) {
							continue;
						}
					}
					$tabdata2=array();
					$datum_ez=$db->unixdate($expl[3]);
					if ($datum_ez=='') {
						$datum_ez=_OHNE_;
					}
					
					if ($pdf_variante2) {
						if ($z==2) {
							$mp1=$expl[6];
							$expl[6]=$expl[19];
							$expl[19]=$mp1;
						}
						$expl[6]=doubleval(str_replace(',', '.', $expl[6]));
						$p1_brutto=number_format($expl[6], 2, ",", ".");
						if ($expl[6]==0) {
							$p1_brutto=_PREIS_AUF_ANFRAGE_;
						}
						$prn1=$expl[19];
						if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
							$prn1=$expl[17];
						}
						$prn1=doubleval(str_replace(',', '.', $prn1));
						$p1_netto=number_format($prn1, 2, ",", ".");
						if ($prn1==0) {
							$p1_netto=_PREIS_AUF_ANFRAGE_;
						}

						if ($z==2) {
							$p1_brutto=$expl[20];
							if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
								$p1_brutto=$expl[17];
							}
							$p1_netto='';
							if ($p1_brutto=='') {
								$p1_brutto=_PREIS_AUF_ANFRAGE_;
								$p1_netto=_PREIS_AUF_ANFRAGE_;
							}
						}

						$tabdata2[$anz]=array($expl[10], $expl[8].($cfg_kfzsuche_holland?' / '.$expl[18]:''), $datum_ez, $expl[2].' km', $p1_brutto, $p1_netto);
					} else {
						$tabdata2[$anz]=array($expl[10], $expl[8].($cfg_kfzsuche_holland?' / '.$expl[18]:''), $datum_ez, $expl[2].' km', $expl[7], number_format(doubleval($expl[6]), 2, ",", "."));
					}
					$anz++;
					$fe18=$expl[18];
					if ($_SESSION['cfg_kunde']=='carlo_opel_dbrent') {
						$fe18=$expl[16];
					}
					if ($pdf_variante2) {
						$tabdata2[$anz]=array('', trim($expl[11].' '.($expl[12]==0?'':$expl[12])), trim(($expl[13]=='0'?'-':$expl[13]).'  '.($expl[14]=='0'?'-':$expl[14]).'  '.($expl[15]=='0'?'-':$expl[15]).'/'.($expl[4]=='0'?'-':$expl[4])), $expl[5], '', '');
					} else {
						$tabdata2[$anz]=array('', trim($expl[11].' '.($expl[12]==0?'':$expl[12])), trim(($expl[13]=='0'?'-':$expl[13]).'  '.($expl[14]=='0'?'-':$expl[14]).'  '.($expl[15]=='0'?'-':$expl[15]).'/'.($expl[4]=='0'?'-':$expl[4])), $expl[5], '', ($z==2?$fe18:''));
					}
					$anz++;
//$csv_block='0Marke;1Typ/Modell;2KM-Stand;3Erstzulassung;4PS;5Farbe;6Preis;7Filiale/Standort;8FG-Nr.;9Ausstattung;10Ref.-Nr.;11Aufbau;12T�ren;13Hubraum;14Motor;15KW;16MWerte'."\r\n";
					// Refnr, FGNR           Marke, Typ                 Standort   Farbe         Bemerkung
					//	      Aufbau  T�ren  ccm Diesel KW EZ km Stand  Stellplatz  Ausstattung          Preis
					$tabdata.='<TR><TD>'.$expl[10].'</TD><TD>'.$expl[8].'</TD><TD>'.$expl[0].', '.$expl[1].'</TD><TD></TD><TD></TD><TD>'.$expl[7].'</TD><TD></TD><TD>'.number_format(doubleval($expl[6]), 2, ",", ".").'</TD></TR>';
					$tabdata.='<TR><TD></TD><TD>'.trim($expl[11].' '.($expl[12]==0?'':$expl[12])).'</TD><TD>'.trim(($expl[13]=='0'?'':$expl[13]).'  '.($expl[14]=='0'?'':$expl[14]).'  '.($expl[15]=='0'?'':$expl[15])).'</TD><TD>'.$db->unixdate($expl[3]).'</TD><TD>'.$expl[2].' km</TD><TD>'.$expl[5].'</TD><TD>'.$expl[900].'</TD><TD></TD></TR>';

					$anz2++;
					$pdf_doc->SetFont('trebuc', '', $sgr_tab);
					$pdf_doc->addText(true, $expl[0].' '.$expl[1], 'L', 'B');
					$pdf_doc->writeTable($tabdata2, $header = '', $align = 'J', $fontsize = $sgr_tab, $breite = 0, $border = 0, $spacing = 1);
					$pdf_doc->addText(true, $expl[9], 'L', '', 6);
					$pdf_doc->lineBreak();
					$pdf_doc->drawLine(false, '', '', 0.2);
					if ($anz2==3) {
						$neuseite=true;
						$anz2=0;
					}
//					$tabdata.='</TABLE><TABLE border=1><TR><TD>'.$expl[9].'</TD></TR>';
				}
				$tabdata.='</TABLE>';
//				echo $tabdata2;
//				$pdf_doc->writeHTML($tabdata, 6);
//				$pdf_doc->writeTable($tabdata2, $header = '', $align = 'J', $fontsize = 5, $breite = 0, $border = 1, $spacing = 5);
				$pdf_doc->save('temp/kfz_liste_'.$_SESSION['user_id'].$dateizus2.'.pdf');
				$inhalt.=''.link2(_STAMMDATEN_NAV_LISTE_.' (PDF)'.$dateizus, 'temp/kfz_liste_'.$_SESSION['user_id'].$dateizus2.'.pdf?t1='.time(), '', '', 'target="_blank"').'<br>';
				tempdateien('temp/kfz_liste_'.$_SESSION['user_id'].$dateizus2.'.pdf', 'kfz_liste_'.$_SESSION['user_id'].$dateizus2.'.pdf', _STAMMDATEN_NAV_LISTE_.' '._FAHRZEUGE_.' (.PDF)'.$dateizus);
			
                $pdf_export_download[]=Template_Link::init(_STAMMDATEN_NAV_LISTE_.' (PDF)'.$dateizus, 'temp/kfz_liste_'.$_SESSION['user_id'].$dateizus2.'.pdf?t1='.time(), '', '', 'target="_blank"');
            }
			if ($fp=fopen('temp/kfz_liste_'.$_SESSION['user_id'].$dateizus2.'.csv', 'w')) {
				fwrite($fp, $csv_block);
				fclose($fp);
				$inhalt.=''.link2(_STAMMDATEN_NAV_LISTE_.' (CSV)'.$dateizus, 'temp/kfz_liste_'.$_SESSION['user_id'].$dateizus2.'.csv?t1='.time(), '', '', 'target="_blank"').'<br>';
				tempdateien('temp/kfz_liste_'.$_SESSION['user_id'].$dateizus2.'.csv', 'kfz_liste_'.$_SESSION['user_id'].$dateizus2.'.csv', _STAMMDATEN_NAV_LISTE_.' '._FAHRZEUGE_.' (.CSV)'.$dateizus);
                $csv_export_download[]=Template_Link::init(_STAMMDATEN_NAV_LISTE_.' (CSV)'.$dateizus, 'temp/kfz_liste_'.$_SESSION['user_id'].$dateizus2.'.csv?t1='.time(), '', '', 'target="_blank"');
                
            }
		}
	}
	}
					if ($kfzs_debug) {
						if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
							fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'nach Export'."\r\n");
							fclose($fp);
						}
					}
	}


    echo $inhalt;

    if ($_SESSION['design_70']) {

        $x=ob_get_contents();
        ob_end_clean();

        preg_match_all('/<script[^>]*>(.*)<\/script>/Uis',$x,$matches,PREG_SET_ORDER);

        foreach ($matches as $match) {
            echo $match[0];
        }

        
        echo Template_Stylesheet::init('kfzsuche')->getHtml();
        echo Template_Script::init('kfzsuche')->getHtml();

        $btn=new Template_IconButton('','','','settings','','','sm','transparent-blue');
        $action_list=array();
        if ($_SESSION['user_gruppe']==2 and $cfg_kfzsuche_infotexte) {
            $action_list[0] = Template_Link::init('sonstiges A+KV','','settings')->setRequest('GET', $kfzadmin_modal_inhalt, 'kfzsuche.php', array('admin_sv=1&tab_kfzsuche_admin2=tab_kfzsuche_a_infotexte'), array($kfzadmin_modal));
        }
        if ($_SESSION['crm_version']>63 and $_SESSION['user_gruppe']==2) {
            $action_list[1] = Template_Link::init('sonstiges PF','','settings')->setRequest('GET', $kfzadmin_modal_inhalt, 'kfzsuche.php', array('admin_svp=1&tab_kfzsuche_admin2=tab_kfzsuche_a_infotexte_pf'), array($kfzadmin_modal));
        }
        if ($_SESSION['user_gruppe']==2 and $cfg_kfzsuche_finkalk) {
            $action_list[2] = Template_Link::init('Finanzierungsrechner','','settings')->setRequest('GET', $kfzadmin_modal_inhalt, 'kfzsuche.php', array('admin_fc=1&tab_kfzsuche_admin2=tab_kfzsuche_a_finrech'), array($kfzadmin_modal));
        }
        if ($_SESSION['user_gruppe']==2) {
            $action_list[3] = Template_Link::init('Links Zubeh�r','','settings')->setRequest('GET', $kfzadmin_modal_inhalt, 'kfzsuche.php', array('admin_zub=1&tab_kfzsuche_admin2=tab_kfzsuche_a_zubehoer'), array($kfzadmin_modal));
        }
        if ($_SESSION['user_gruppe']==2 and $cfg_kfzsuche_garantietexte) {
            $action_list[4] = Template_Link::init('Garantien','','settings')->setRequest('GET', $kfzadmin_modal_inhalt, 'kfzsuche.php', array('admin_gar=1&tab_kfzsuche_admin2=tab_kfzsuche_a_garantien'), array($kfzadmin_modal));
        }
        if ($_SESSION['user_gruppe']==2 and $cfg_kfzsuche_nebenkosten_auswahl) {
            $action_list[5] = Template_Link::init(_ZULASSUNG_NEBENKOSTEN_,'','settings')->setRequest('GET',$kfzadmin_modal_inhalt,'kfzsuche.php','admin_neben=1&tab_kfzsuche_admin2=tab_kfzsuche_a_neben', array($kfzadmin_modal));
        }
        if ($_SESSION['user_gruppe']==2 and $cfg_kfzsuche_italien) {
            $action_list[6] = Template_Link::init('Tax 1/2','','settings')->setRequest('GET',$kfzadmin_modal_inhalt,'kfzsuche.php','admin_ittax=1&tab_kfzsuche_admin2=tab_kfzsuche_a_ittax', array($kfzadmin_modal));
        }
        $actionMenu= Template_InlineMenu::init($action_list,$btn);
        echo Template_ContentHeader::init(new Template_Breadcrumps(array('Fahrzeugsuche')), $actionMenu->getTriggerButtonAndMenu(), false, true)->getHtml();

        $page_filter = new Template_Filter();
        $filterDefaultValues = array('markencode[]' => '');
        $filterDefaultValueKFZStatus = $filterDefaultValueKFZStatus ?: [];
        $filterDefaultValues = array_merge($filterDefaultValues, $filterDefaultValueKFZStatus);
        
        if ($cfg_avag_de) {
            $filter[] = new Template_HiddenInput('avag_remember_car', false);
        }
        
        $page_filter->initPageFilter($filter, $phs, 'GET', '', '', true, 'suchform', '', $filterDefaultValues);
        $page_filter->addCustomClass('kfzsuche_filter');
        $page_filter->confirmButton->addCustomClass('confirm-filter-btn');
        
        $tableHeader = array(
            _INAKTIV_,
            '&nbsp;',
            _MODELL_.'/'._STATUS_.'/'.'FIN',
            _PREIS_.'/'._BESTEUERUNG_,
            _STANDORT_.'/'._INTFAHRER_,
            _PS_.'/'._FARBE_,
            _ERSTZUDATUM_.'/'._KMSTAND_,
            ($cfg_kfzsuche_ergebnis_keinkennzeichen ? _STANDTAGE_ : _STANDTAGE_.'/'._KENNZEICHEN_),
            _AKTION_
        );

        $priority = array(
            'Test'
        );

        $sort=array(
            'Test'
        );

        $search=array(
            'Test'
        );

       // $pagination->create($pagination_zaehler);
       
        $pagination->setRequest('POST', 'main', $phs,'pagination_alt='. base64_encode(serialize($getfeld)));


        $action_list=array(
            Template_Link::init('Export','','mdi-file-document-edit-outline','','onclick="templateTabsChange(\'tab_kfzsuche_export\');"')->openModal('kfzsuche_export'),
            Template_Link::init('Suchauftrag Kunde','','mdi-file-document-edit-outline','','onclick="templateTabsChange(\'tab_kfzsuche_suchauftrag\');"')->openModal('kfzsuche_export'),
        );
        $actionMenuButton = Template_IconTextButton::init('',_AKTIONEN_,'', 'keyboard_arrow_down__right','','','sm','blue')->addCustomClass('round-32 text-bold font-size-16');
        $actionMenuContent = new Template_LinkList($action_list);
        Template_InlineOverlay::prepare($actionMenuButton, $actionMenuContent, 'kfsuche_activities');
        
        $right=new Template_ElementList(array(new Template_ElementList(array(new Template_Text('Probefahrten anzeigen'),Template_Switch::init('',$name = '', $checked = $pfbalken_show, $other = 'onclick=" if (this.checked) { RequestHelper.get(\'start.php?storage_helper_set=kfzsuche_pfbalken_show\', function (response) { });  $(\'.kfzsuchepfbalken\').addClass(\'show\'); } else { RequestHelper.get(\'start.php?storage_helper_setfalse=kfzsuche_pfbalken_show\', function (response) { }); $(\'.kfzsuchepfbalken\').removeClass(\'show\'); } "', $value = '', $left = _NEIN_, $right = _JA_, $allowChange=true)),'','horizontal nowrap'),$actionMenuButton,$actionMenuContent),'','horizontal');

        $message='';
        if ((is_array($table_data) && count($table_data)==0) && $_GET['submit']=='PAGE_FILTER_SUBMIT') {
           $message=new Template_ElementList(new Template_Text('Keine Ergebnisse vorhanden.',-1,array('bold')),'','pl-16 pt-16');
           $message=$message->getHtml();
        }
        if (!is_array($table_data)) {
           $message=new Template_ElementList(new Template_Text('Bitte Fahrzeuge selektieren!',-1,array('bold')),'','pl-16 pt-16');
           $message=$message->getHtml();
        }
        
        $card = Template_Default::Table(
            $tableHeader,
            $table_data,
            array(
                'message' => $message,
                'hideColumnTitle' => array($tableHeader[0]),
                'sort' => array(
                    _MODELL_,
                    _PS_,
                    _FARBE_,
                    _ERSTZUDATUM_,
                    _KENNZEICHEN_,
                    _KMSTAND_,
                    _PREIS_,
                    _STANDTAGE_
                ),
                'dataType' => array(
                    _PREIS_ => 'NUMERIC',
                    _KMSTAND_ => 'NUMERIC',
                    _PS_ => 'NUMERIC',
                    _ERSTZUDATUM_ => 'DATE',
                    _STANDTAGE_ => 'NUMERIC'
                )
            ),
            $page_filter,
            $search,
            $right,
            $pagination,
            true,
            '',
            array(
                'fullContentHeight',
                'paginationInCard' => true,
                'sidebarOptions' => array('openStatus' => 'OPEN')
            )
        );

        //$card->fullContentHeight();
        //$card->addScrollBar();
        echo $suchauftrag->getHtml();
        echo $card->getHtml();

        echo $kfzdetails_modal_iframe->getHtml();
        echo $kfzdetails_modal->getHtml();
        echo $kfzadmin_modal->getHtml();
        echo $kfzsuche_export->getHtml();
        echo $carDetailsModal->getHtml();
        
        if (isset($getfeld['export_csv']) || isset($getfeld['export_pdf'])) {
            Modern_Helper_Request::requestStart();

            $export_erg=Template_Default::Card('Links zum Download', null, array(
                new Template_ElementList(array(
                    (isset($getfeld['export_csv'])?$csv_export_download:null),
                    (isset($getfeld['export_pdf'])?$pdf_export_download:null)
                ),'','vertical'),
            ));
            $export_erg->addCustomClass('mt-16');
            echo $export_erg->getHtml();

            exit;
        }


    } 
//	echo javas('alert("Zeit: '.zeitnahme().'");');

	echo '<!shd2><!stc2>';

	$weiteres='';
	if ($_SESSION['user_gruppe']==2 and $cfg_kfzsuche_garantietexte) {
		$weiteres.=(($cfg_modern)?'<tr><td>':'<br>').link2(($cfg_modern?'':_SP_VERWALTUNG_.': ')._INFOTEXTE_.' '._GARANTIE_, $phs.'?admin_gar=1').(($cfg_modern)?'</td></tr>':'');
	}
	if ($_SESSION['user_gruppe']==2 and $cfg_kfzsuche_infotexte) {
		$weiteres.=(($cfg_modern)?'<tr><td>':'<br>').link2(($cfg_modern?'':_SP_VERWALTUNG_.': ')._INFOTEXTE_.' '._SONST_VEREINBARUNGEN_, $phs.'?admin_sv=1').(($cfg_modern)?'</td></tr>':'');
	}
	if ($_SESSION['user_gruppe']==2 and $cfg_kfzsuche_finkalk) {
		$weiteres.=(($cfg_modern)?'<tr><td>':'<br>').link2(($cfg_modern?'':_SP_VERWALTUNG_.': ')._FINRECHNER_, $phs.'?admin_fc=1').(($cfg_modern)?'</td></tr>':'');
	}
	if ($_SESSION['user_gruppe']==2 and $cfg_kfzsuche_italien) {
		$weiteres.=(($cfg_modern)?'<tr><td>':'<br>').link2(($cfg_modern?'':_SP_VERWALTUNG_.': ').'Tax 1/2', $phs.'?admin_ittax=1').(($cfg_modern)?'</td></tr>':'');
	}
	if ($_SESSION['user_gruppe']==2 and $cfg_kfzsuche_nebenkosten_auswahl) {
		$weiteres.=(($cfg_modern)?'<tr><td>':'<br>').link2(($cfg_modern?'':_SP_VERWALTUNG_.': ')._ZULASSUNG_NEBENKOSTEN_, $phs.'?admin_neben=1').(($cfg_modern)?'</td></tr>':'');
	}
	if ($_SESSION['user_gruppe']==2) {
		$weiteres.=(($cfg_modern)?'<tr><td>':'<br>').link2(($cfg_modern?'':_SP_VERWALTUNG_.': ')._LINKS_.' '._ZUBEHOER_, $phs.'?admin_zub=1').(($cfg_modern)?'</td></tr>':'');
	}
	if ($_SESSION['crm_version']>63 and $_SESSION['user_gruppe']==2) {
		$weiteres.=(($cfg_modern)?'<tr><td>':'<br>').link2(($cfg_modern?'':_SP_VERWALTUNG_.': ')._INFOTEXTE_.' '._SONST_VEREINBARUNGEN_.' '._PROBEFAHRT_, $phs.'?admin_svp=1').(($cfg_modern)?'</td></tr>':'');
	}
	if (!$kfzs_such_nurerg and $weiteres!='') {
        $weiteres=($cfg_modern?'<table class="moderntable table-nohover">'.$weiteres.'</table>':$weiteres);
        if (!$_SESSION['design_70'])
		echo '<!stc1><!shd1>'.(($cfg_modern)?'<div id="verwalt" class="table-margin-top">':'').css_kopf(_SP_VERWALTUNG_).$weiteres.(($cfg_modern)?'</div>':'').'<!shd2><!stc2>';
	}
	
	if ($slog!='') {
		$slog=substr($slog, 0, -2);
		$_SESSION['slowlog_quelle']=$slog;
	}
	fuss();
					if ($kfzs_debug) {
						if ($fp=fopen('log/kfzsuche_'.$_SESSION['user_id'].'.txt', 'a')) {
							fwrite($fp, adodb_date('d.m.Y H:i:s', time()).': '.zeitnahme().': '.'Ende nach parsen'."\r\n");
							fclose($fp);
						}
					}

?>