<?php
    session_start();
    if ($_SESSION['user_id']>0) {
        $noauth=true;
    }
    include_once('inc/session.php');
	$exploded = explode('&',$_POST['navto']);
	if (sizeof($exploded)>1) {
		$_POST['navto'] = $exploded[0];
		$exploded2 = explode('=',$exploded[1]);
		if (sizeof($exploded2)>1) {
			$_POST[$exploded2[0]] = $exploded2[1];
        }
    }
    /*echo'<pre>';
    print_r($_POST);
    echo'</pre>';*/
    $postfeld=$_POST;
	$getfeld=$_GET;
	$feld=$_POST;
	$feld2=$_GET;
	$files=$_FILES;
    
	$cfg_leadprozess_schneller=true;
	
	if (count_p4n($postfeld)==0 and count_p4n($getfeld)==0) {
		unset($_SESSION['leadprozess']);
	}
    //$debug=new Modern_Debug();
    //$debug->debug('testpim.txt','');
    
    
    $user = new User_Data($_SESSION['user_id']);
    $user->load();
    
    $pim_modal_inhalt = new Template_ElementList('', 'pim_modal_inhalt');
    //($name,$trigger=null, $elements=null,$footer=null,$other='',$modal=false, $header=true, $closeCallback=null, $refreshPrev=false)
    $pim_modal = Template_Modal::init('pim_modal', null, $pim_modal_inhalt,null,'',false, false,null,false);
    $pim_modal->setRight();

	$pim_modal_level2_inhalt = new Template_ElementList('', 'pim_modal_level2_inhalt');
	$pim_modal_level2 = new Template_Modal('pim_modal_level2', null, $pim_modal_level2_inhalt, null, '', false, false, null, true);
	$pim_modal_level2->setRight();
    
    $korrespondenzen_modal_inhalt = new Template_ElementList('', 'korrespondenzen_modal_inhalt');
    $korrespondenzen_modal = Template_Modal::init('korrespondenzen_modal', null, $korrespondenzen_modal_inhalt,null,'',false, false,null,false);
    $korrespondenzen_modal->setRight();
    
    $statfeld = array(0 => _NEU_, 1 => _BM_STATUS3_, 2 => _BM_STATUS3_, 3 => _BM_STATUS3_, 4 => _BM_STATUS3_, 5 => _BM_STATUS4_);
	$statfeld2=array(0 => _NEU_, 1 => _BM_STATUS3_, 2 => _BM_STATUS2_, 3 => _OFFEN_, 4 => _KONTAKTIERT_, 5 => _BM_STATUS4_, 99 => _NICHT_ABGESCHLOSSEN_);
     /*$statfeld2[1]=_BM_STATUS1_;
					$statfeld2[2]=_BM_STATUS2_;
					$statfeld2[3]=_BM_STATUS3_;
					$statfeld2[4]=_BM_STATUS4_;*/
    

	$isLeadPimInPim = lead_pim_in_pim();

/*	if ($_POST['justdate']) {
		debug_logging('$_SESSION: '.print_r($_SESSION,true));
		if (isset($_SESSION['pim_and_leadstatus']) || isset($_POST['pim_and_leadstatus'])) {
			$_SESSION['pim_and_leadstatus'] = -1;
		}
		if (isset($_SESSION['pim_kamp1']) || isset($_POST['pim_kamp1'])) {
			$_SESSION['pim_kamp1'] = -1;
		}
		if (isset($_SESSION['leadprozess_lagerort']) || isset($_POST['leadprozess_lagerort'])) {
			$_SESSION['leadprozess_lagerort'] = -1;
		}
	}
*/
    debug_logging('$_POST: '.print_r($_POST,true));
	if (isset($feld['multiroute'])) {
		$alle_mr=array();
		foreach($feld['multiroute'] as $skey => $sval) {
			$xpl=explode('_', $skey);
			if ($xpl[0]!='') {
				$alle_mr[$xpl[0]]=$xpl[0];
			}
		}
		if (count($alle_mr)>0) {
			$multi=new MultiRoute();
			$multiroute_link=$multi->sendDataList($alle_mr);
			if ($multiroute_link!='') {
				echo javas('window.open("'.$multiroute_link.'", "multiroute");');
			}
		}
	}
	
    if ($_SESSION['crm_version']<65) {
        $cfg_pim_erledigt=true;
    }
	if (!isset($cfg_ordner_kdokumente_pfad) or $cfg_ordner_kdokumente_pfad=='')
		$cfg_ordner_kdokumente_pfad=$cfg_ordner_kdokumente;
	
	if (isset($_SESSION['kdokpfad']) and $_SESSION['kdokpfad']!='') {
		$cfg_ordner_kdokumente_pfad=$_SESSION['kdokpfad'];
	}
	
    if (isset($_POST['pim_filter_clear'])) {
        session_start();
        unset($_SESSION['pim_filter_ids']);
        exit;
    }
    if (isset($feld2['multiroute'])) {
    	try {
    		$multiRoute = new MultiRoute();
    		$link = $multiRoute->sendData($feld2['multiroute']);
    		echo javas('window.open(\''.$link.'\')');
		} catch (Exception $e) {
			echo '<span style="color:red">MultiRoute: '.$e->getMessage().'</span>';
		}
	}
	
    $pim_keincount=true;
	$zeitdebug=false;
	if (1==2) {
		$zeitdebuglog=true;
	}
	if (1==2) {
		$zeitdebug=true;
	}
	$cfg_merke_zeit=microtime();

	$noCorrespondenceLimit = false;
	//Date Flag
	debug_logging('At Post->Session');

	if (isset($feld2['filterdatum_start']) and !isset($feld['filterdatum_start'])) {
		$feld['filterdatum_start']=$feld2['filterdatum_start'];
	}
	if (isset($feld2['filterdatum_ende']) and !isset($feld['filterdatum_ende'])) {
		$feld['filterdatum_ende']=$feld2['filterdatum_ende'];
	}
	if (isset($feld2['wfilterdatum_start']) and !isset($feld['wfilterdatum_start'])) {
		$feld['wfilterdatum_start']=$feld2['wfilterdatum_start'];
	}
	if (isset($feld2['wfilterdatum_ende']) and !isset($feld['wfilterdatum_ende'])) {
        $feld['wfilterdatum_ende']=$feld2['wfilterdatum_ende'];
	}
    if (isset($feld2['wfilterdatum_endeKorr']) and !isset($feld['wfilterdatum_endeKorr'])) {
        $feld['wfilterdatum_endeKorr']=$feld2['wfilterdatum_endeKorr'];
	}
    if (isset($feld2['wfilterdatum_startKorr']) and !isset($feld['wfilterdatum_startKorr'])) {
		$feld['wfilterdatum_startKorr']=$feld2['wfilterdatum_startKorr'];
	}
	if (isset($feld2['wfilter_alter']) && !isset($feld['wfilter_alter'])) {
		$feld['wfilter_alter']=$feld2['wfilter_alter'];
	}

	if (isset($feld['wfilter_alter']) && $feld['wfilter_alter'] > 0) {
		$now = new DateTime();
		$now->modify("-{$feld['wfilter_alter']} day");
		$feld['wfilterdatum_start'] = '';
		$feld['wfilterdatum_ende'] = $now->format('d.m.Y');
		$noCorrespondenceLimit = true;
	}
 
	if ($cfg_kfz_zf) {
		prod_zf_tabsmeta();
	}
    
    $p_cache=array();
    $p_cache_link70=array();
    $p_cache_link70_2=array();
    $res=$db->select(
        $sql_tab['stammdaten_zusatz'],
        array(
            $sql_tabs['stammdaten_zusatz']['zusatz_id'],
            $sql_tabs['stammdaten_zusatz']['bezeichnung'],
            $sql_tabs['stammdaten_zusatz']['art']
        )
    );
    $lang_db_f['zf']['']=_ZUSATZFELDER_;
    $lang_db_f['zusatzfelder']['']=_ZUSATZFELDER_;
    while ($row=$db->zeile($res)) {
        $row[1]=p4n_mb_string('str_replace', '.','',$row[1]);

        if (isset($cfg_dmsbezeichnung)) {
            if ($cfg_dmsbezeichnung!='') {
                $row[1]=str_replace('Carlo', $cfg_dmsbezeichnung, $row[1]);
            }
        }

        $zugelassen['zf'][$row[0]]=$row[1];

        $sfeld4[$sql_tab['zusatzfelder'].'.'.'zf_'.$row[0]]=_ZUSATZFELDER_.' - '.$row[1];

//			$lang_db_f['zf'][$row[0].':'.$row[1]]=$row[1];
        $lang_db_f['zf'][$row[0]]=$row[1];
        $lang_db_f['zusatzfelder']['zf_'.$row[0]]=$row[1];

        if ($row[2]=='1') {
            $sql_meta['zusatzfelder']['zf_'.$row[0]]=array('D');
        } elseif ($row[2]=='2') {
            $sql_meta['zusatzfelder']['zf_'.$row[0]]=array('F');
        } elseif ($row[2]=='4') {
            $sql_meta['zusatzfelder']['zf_'.$row[0]]=array('X');
        } elseif ($row[2]=='6') {
            $sql_meta['zusatzfelder']['zf_'.$row[0]]=array('T');
        } elseif ($row[2]=='8') {
            $sql_meta['zusatzfelder']['zf_'.$row[0]]=array('L');
        } else {
            $sql_meta['zusatzfelder']['zf_'.$row[0]]=array('C');
        }
        $sql_meta['zusatzfelder'][cutforsql_j($row[1])]=$sql_meta['zusatzfelder']['zf_'.$row[0]];
        $sql_tabs['zusatzfelder']['zf_'.$row[0]]=$sql_tab['zusatzfelder'].'.zf_'.$row[0];
        if ($row[2]=='7') {
            $sql_meta['zusatzfelder']['zf_'.$row[0]]=array('I');
            $sql_tab_ids[$sql_tabs['zusatzfelder']['zf_'.$row[0]]]=$sql_tabs['benutzer']['benutzer_id'];
        }
    }
    
	$tababk2=array();
    $tababk=array(
		'produktzuordnung_reservierung' => 'pres',
         'produktzuordnung_versicherung' => 'versicherung',
         'produktzuordnung' => 'pzo',
         'stammdaten_ansprechpartner' => 'stap'
     );
     while (list($key, $val)=@each($tababk)) {
	 	$tababk2[$val]=$key;
         if (isset($lang_db_f[$key])) {
             $lang_db_f[$val]=$lang_db_f[$key];
             $sql_tab[$val]=$sql_tab[$key];
             $sql_tabs[$val]=$sql_tabs[$key];
             $sql_meta[$val]=$sql_meta[$key];
         }
     }
        if ($cfg_leadmanagement_2020) {
            $allCategories = Plugin_System_LeadTracker::getInternalCategories();

            $spalten_name = $lang_db_f['kampagne_lead_status'][''];
            $old_lead_status_lang_dbf = $lang_db_f['kampagne_lead_status'];
            unset($lang_db_f['kampagne_lead_status']);
            if (!empty($allCategories)) {
                $lang_db_f['kampagne_lead_status'][''] = $spalten_name;
                foreach ($allCategories as $status_number => $status_label) {
                    $lang_db_f['kampagne_lead_status']['status'.$status_number] = $status_label;
                    $lang_db_f['kampagne_lead_status']['status'.$status_number.'_datum'] = $status_label.' - '.p4n_mb_string('ucwords', _DATUM_);
                }
                $lang_db_f['kampagne_lead_status']['lead_stage'] = $old_lead_status_lang_dbf['lead_stage'];
            }
            @reset($lang_db_f['kampagne_lead_status']);
        }
	ob_start();
	if ((function_exists('session_status') && session_status() !== PHP_SESSION_ACTIVE) || !session_id()) {
        session_start();
    }
    $userid_pim=$_SESSION['user_id'];
    if ($_SESSION['leadprozess']=='pim') {
        $userid_pim=$_SESSION['pim_and_ben_lead'];
		if (isset($_SESSION['pim_and_ben'])) {
			$userid_pim=$_SESSION['pim_and_ben'];
		}
    } elseif ($_SESSION['leadprozess']=='pim_vkl') {
        $userid_pim=$_SESSION['pim_and_ben_vkl'];
    } elseif (isset($_SESSION['pim_and_ben'])) {
		$userid_pim=$_SESSION['pim_and_ben'];
	}
    
    if (isset($feld['ou_pim'])) {
		$_SESSION['pim_and_ben']=$feld['ou_pim'];
		$userid_pim=$feld['ou_pim'];
	} 
    
    	if (isset($feld['filter_kart'])) {
			$_SESSION['pim_kart1']=$feld['filter_kart'];
		} elseif (isset($_SESSION['pim_kart1'])) {
			$feld['filter_kart']=$_SESSION['pim_kart1'];
		}
		if (isset($feld['filter_kamp'])) {
			$_SESSION['pim_kamp1']=$feld['filter_kamp'];
		} elseif (isset($_SESSION['pim_kamp1'])) {
			$feld['filter_kamp']=$_SESSION['pim_kamp1'];
		}
		
		if (isset($feld['filter_korrkat'])) {
			$_SESSION['pim_korrkat1']=$feld['filter_korrkat'];
		} elseif (isset($_SESSION['pim_korrkat1'])) {
			$feld['filter_korrkat']=$_SESSION['pim_korrkat1'];
		}
		
        if (isset($feld['filterdatum_start'])) {
			$_SESSION['pim_filterdatum_start']=$feld['filterdatum_start'];
		} elseif (isset($_SESSION['pim_filterdatum_start'])) {
			$feld['filterdatum_start']=$_SESSION['pim_filterdatum_start'];
		}
        if (isset($feld['filterdatum_ende'])) {
			$_SESSION['pim_filterdatum_ende']=$feld['filterdatum_ende'];
		} elseif (isset($_SESSION['pim_filterdatum_ende'])) {
			$feld['filterdatum_ende']=$_SESSION['pim_filterdatum_ende'];
		}
        if (isset($feld['wfilterdatum_start'])) {
			$_SESSION['pim_wfilterdatum_start']=$feld['wfilterdatum_start'];
		} elseif (isset($_SESSION['pim_wfilterdatum_start'])) {
			$feld['wfilterdatum_start']=$_SESSION['pim_wfilterdatum_start'];
		}

        if (isset($feld['wfilterdatum_ende'])) {
			$_SESSION['pim_wfilterdatum_ende']=$feld['wfilterdatum_ende'];
		} elseif (isset($_SESSION['pim_wfilterdatum_ende'])) {
			$feld['wfilterdatum_ende']=$_SESSION['pim_wfilterdatum_ende'];
		}
        
        //korr datum
        if (isset($feld['wfilterdatum_endeKorr'])) {
			$_SESSION['wfilterdatum_endeKorr']=$feld['wfilterdatum_endeKorr'];
            $feld['wfilterdatum_ende']=$_SESSION['wfilterdatum_endeKorr'];
		} elseif (isset($_SESSION['wfilterdatum_endeKorr']) && !$_POST['leadprozess']) {
			$feld['wfilterdatum_ende']=$_SESSION['wfilterdatum_endeKorr'];
            $feld['wfilterdatum_endeKorr']=$_SESSION['wfilterdatum_endeKorr'];
		}
        if (isset($feld['wfilterdatum_startKorr'])) {
			$_SESSION['wfilterdatum_startKorr']=$feld['wfilterdatum_startKorr'];
            $feld['wfilterdatum_start']=$_SESSION['wfilterdatum_startKorr'];
		} elseif (isset($_SESSION['wfilterdatum_startKorr']) && !$_POST['leadprozess']) {
			$feld['wfilterdatum_start']=$_SESSION['wfilterdatum_startKorr'];
            $feld['wfilterdatum_startKorr']=$_SESSION['wfilterdatum_startKorr'];
		}
        
		if (isset($feld['wfilter_alter'])) {
			$_SESSION['pim_wfilter_alter']=$feld['wfilter_alter'];
		}
		elseif (isset($_SESSION['pim_wfilter_alter']) && $_SESSION['pim_wfilter_alter'] > 0) {
			$feld['wfilter_alter']=$_SESSION['pim_wfilter_alter'];
			$now = new DateTime();
			$now->modify("-{$feld['wfilter_alter']} day");
			$feld['wfilterdatum_start'] = '';
			$feld['wfilterdatum_ende'] = $now->format('d.m.Y');
		}
       
	ob_end_clean();
    
     
    if (isset($_POST['module_widget_save'])) {
        Modern_Helper_Request::requestStart();
        $widget_save=json_decode($_POST['module_widget_save']);
        $widget_save= serialize($widget_save);

        $res=$db->select(
        $sql_tab['benutzer'],
        array(
            $sql_tabs['benutzer']['pim_anordnung']
        ),
        $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($userid_pim)
        );
        if ($row=$db->zeile($res)) {
           // if ($row[0]!='') {

                $pim_xlp=explode('/', $row[0]);

                $pim_neu=$pim_xlp[0].'/'.$pim_xlp[1].'/'.$widget_save;
                $db->update(
                    $sql_tab['benutzer'],
                    array(
                        $sql_tabs['benutzer']['pim_anordnung']=>$db->str($pim_neu)
                    ),
                    $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($userid_pim)
                );
          //  }
        }
        exit;
    }
    
    
    
    if (isset($_POST['module_widget_save2'])) {
        Modern_Helper_Request::requestStart();
            if (isset($_POST['pim_widget_filter'])) {
                $user = new User_Data($userid_pim);
                $user->load();
                $user['pim_anordnung_filter']=$_POST['pim_widget_filter'];
                $user->save();  
            }

            if (isset($_POST['pim_widget_korrespondenz']) && $_POST['pim_widget_korrespondenz']!='' && $_POST['pim_widget_korrespondenz']!=-1) {
                $user = new User_Data($userid_pim);
                $user->load();
                $user['pim_korrespondenz_view_auswahl']=$_POST['pim_widget_korrespondenz'];
                $user->save();  
            }
            if (isset($_POST['pim_widget_bm']) && $_POST['pim_widget_bm']!='' && $_POST['pim_widget_bm']!=-1) {
                $user = new User_Data($userid_pim);
                $user->load();
                $user['pim_bm_view_auswahl']=$_POST['pim_widget_bm'];
                $user->save();  
            }
            if (isset($_POST['pim_widget_lead']) && $_POST['pim_widget_lead']!='' && $_POST['pim_widget_lead']!=-1) {
                $user = new User_Data($userid_pim);
                $user->load();
                $user['pim_lead_view_auswahl']=$_POST['pim_widget_lead'];
                $user->save();  
            }
            if (isset($_POST['pim_widget_opp']) && $_POST['pim_widget_opp']!='' && $_POST['pim_widget_opp']!=-1) {
                $user = new User_Data($userid_pim);
                $user->load();
                $user['pim_opp_view_auswahl']=$_POST['pim_widget_opp'];
                $user->save();  
            }
        exit;
    }
    
	
	if (isset($_POST['genkal'])) {
		ob_start();
		include_once('kalender_class.php');
		include_once('class.overlib.php');
		$ol = new Overlib();
        if ($cfg_modern) {
            Modern_Helper_Request::requestStart();
        } else {
		ob_end_clean();
        }
		$phs=$kln1;//'kalender.php';
		$kal=new event_calendar();
        if ($cfg_pimkal_ohne_auslieferung) {
            $kal->ohne_auslieferung=true;
        }
		$month=$_POST['m'];
		$year=$_POST['j'];
		$kal->set_date(1, $month, $year);
		$kalender=$kal->gen_month_table($userid_pim, 0);
		echo $kalender;
        if ($cfg_modern) {
            Modern_Helper_Request::requestFlush();
        }
		die();
	}
	
	if (isset($_POST['notiz_datum'])) {
		ob_end_clean();
		$res=$db->select(
			$sql_tab['notizen'],
			array(
				$sql_tabs['notizen']['inhalt']
			),
			$sql_tabs['notizen']['benutzer_id'].'='.$db->dbzahl($userid_pim).' and '.
				$sql_tabs['notizen']['datum'].'='.$db->dbdate($_POST['notiz_datum'])
		);
		$row=$db->zeile($res);
		echo $row[0];
		
		die();
	}
	
	if (isset($_POST['notiz_save'])) {
		ob_end_clean();
		
		$res=$db->select(
			$sql_tab['notizen'],
			array(
				$sql_tabs['notizen']['notizen_id']
			),
			$sql_tabs['notizen']['benutzer_id'].'='.$db->dbzahl($userid_pim).' and '.
				$sql_tabs['notizen']['datum'].'='.$db->dbdate($_POST['notiz_d'])
		);
		if ($row=$db->zeile($res)) {
			$db->update(
				$sql_tab['notizen'],
				array(
					$sql_tabs['notizen']['inhalt'] => $db->str(p4n_mb_string('utf8_decode',$_POST['notiz_save']))
				),
				$sql_tabs['notizen']['notizen_id'].'='.$db->dbzahl($row[0])
			);
		} else {
			$db->insert(
				$sql_tab['notizen'],
				array(
					$sql_tabs['notizen']['inhalt'] => $db->str(p4n_mb_string('utf8_decode',$_POST['notiz_save'])),
					$sql_tabs['notizen']['benutzer_id'] => $db->dbzahl($userid_pim),
					$sql_tabs['notizen']['datum'] => $db->dbdate($_POST['notiz_d'])
				)
			);
		}
		
		die();
	}
	
	if (isset($_POST['pim_filter_id'])) {
		ob_end_clean();
		
                $fausgabe='';
              //  $ffilter=explode(',',$_POST['pim_filter_id']);
             //   foreach ($ffilter as $fid) {
             
    @reset($kontakt_typ_db);
    @reset($kontakt_typ);
    while (list($key, $val)=@each($kontakt_typ_db)) {
        list($key2, $val2)=@each($kontakt_typ);
        $fname=p4n_mb_string('str_replace', array(' ','-'), array('_',''), $val);
        $fname2=p4n_mb_string('str_replace', array(' ','-'), array('_',''), $val2);
        $lang_db_f['stammdaten'][$fname]=$fname2;
    }      
	$sprachenfeld=$cfg_benutzer_sprache;
	@reset($sprachenfeld);
	$spi=0;
	$m_sp=0;
	while (list($skey, $sval)=@each($sprachenfeld)) {
		if ($skey==$_SESSION['sprache']) {
			$m_sp=$spi;
		}
		$spi++;
	}
	$res=$db->select(
		$sql_tab['formular'],
		array(
			$sql_tabs['formular']['formular_id'],
			$sql_tabs['formular']['bezeichnung'],
			$sql_tabs['formular']['datum'],
			$sql_tabs['formular']['benutzer_id'],
			$sql_tabs['formular']['benutzer_gruppe_id'],
			$sql_tabs['formular']['vorlage']
		),
		$sql_tabs['formular']['bezeichung']
	);
    $ar_sum=array(_SUMME_=>'sum', _ANZAHL_=>'count', _MINIMUM_=>'min', _MAXIMUM_=>'max', _DURCHSCHNITT_=>'avg', 'min' => 'min', 'max' => 'max', 'sum' => 'sum', 'count' => 'count', 'avg' => 'avg');
	while ($row=$db->zeile($res)) {
		if (intval($row[4])>0 and p4n_mb_string('strpos',','.$_SESSION['rechte_bgruppen'].',', ','.$row[4].',')===false) {
			continue;
		}
		
		$sql_tab['formular_'.$row[0]]=$prefix.'formular_'.$row[0];
		$sql_tabs['formular_'.$row[0]]['stammdaten_id']=$prefix.'formular_'.$row[0].'.stammdaten_id';
		$sql_tabs['formular_'.$row[0]]['bemerkung']=$prefix.'formular_'.$row[0].'.bemerkung';
		$sql_meta['formular_'.$row[0]]['bemerkung']=array('X');
		$lang_db_f['formular_'.$row[0]]['']=$row[1];
		$lang_db_f['formular_'.$row[0]]['bemerkung']=_BEMERKUNG_;
		$zugelassen['formular_'.$row[0]][]='bemerkung';
		
		$res2=$db->select(
			$sql_tab['formular_fragen'],
			array(
				$sql_tabs['formular_fragen']['frage_id'],
				$sql_tabs['formular_fragen']['frage'],
				$sql_tabs['formular_fragen']['frage2'],
				$sql_tabs['formular_fragen']['frage3'],
				$sql_tabs['formular_fragen']['frage4'],
				$sql_tabs['formular_fragen']['feldtyp']
			),
			$sql_tabs['formular_fragen']['formular_id'].'='.$db->dbzahl($row[0]),
			$sql_tabs['formular_fragen']['rang']
		);
		while ($row2=$db->zeile($res2)) {
			$feldty = $row2[5];
			if ($feldty=='9') {
				continue;
			}
			
			$zugelassen['formular_'.$row[0]][]='feld_'.$row2[0];
			
			$lang_db_f['formular_'.$row[0]]['feld_'.$row2[0]]=$row2[1+$m_sp];
			$sql_tabs['formular_'.$row[0]]['feld_'.$row2[0]]=$prefix.'formular_'.$row[0].'.'.'feld_'.$row2[0];
			
			if ($feldty=='1') {
				$sql_meta['formular_'.$row[0]]['feld_'.$row2[0]]=array('I');
			} elseif ($feldty=='2' or $feldty=='6') {
				$sql_meta['formular_'.$row[0]]['feld_'.$row2[0]]=array('C');
			} elseif ($feldty=='3') {
				$sql_meta['formular_'.$row[0]]['feld_'.$row2[0]]=array('X');
			} elseif ($feldty=='4') {
				$sql_meta['formular_'.$row[0]]['feld_'.$row2[0]]=array('D');
			} elseif ($feldty=='5') {
				$sql_meta['formular_'.$row[0]]['feld_'.$row2[0]]=array('T');
			} elseif ($feldty=='7' or $feldty=='12') {
				$sql_meta['formular_'.$row[0]]['feld_'.$row2[0]]=array('L');
			} elseif ($feldty=='8') {
				$sql_meta['formular_'.$row[0]]['feld_'.$row2[0]]=array('F');
			} elseif ($feldty=='13') {
				$sql_meta['formular_'.$row[0]]['feld_'.$row2[0]]=array('I');
                $sql_tab_ids[$sql_tabs['formular_'.$row[0]]['feld_'.$row2[0]]]=$sql_tabs['mandant']['mandant_id'];
			} elseif ($feldty=='14') {
				$sql_meta['formular_'.$row[0]]['feld_'.$row2[0]]=array('I');
				$sql_tab_ids[$sql_tabs['formular_'.$row[0]]['feld_'.$row2[0]]]=$sql_tabs['benutzer']['benutzer_id'];
			}
		}
		$joins[]=array('stammdaten' => 'id', 'formular_'.$row[0] => 'stammdaten_id');
	}
		
                $res2=$db->select(
                                $sql_tab['filter'],
                                array(
                                    $sql_tabs['filter']['name'],
                                    $sql_tabs['filter']['sql'],
                                    $sql_tabs['filter']['filter_id'],
                                    $sql_tabs['filter']['ausschluss']
                                ),
                                $sql_tabs['filter']['filter_id'].'='.$db->dbzahl($_POST['pim_filter_id'])
                    );
                
                $x=0;
             if ($row2=$db->zeile($res2)) {
                 $row2[1]=$db->checksql($row2[1], true);
                 $merke_sql3=$row2[1];
					if ($cfg_kfz and preg_match('/'.$prefix.'produktzuordnung/', $merke_sql3)) {	//\.checkliste
						if (preg_match('/^select (.*) from .*/Ui', $merke_sql3, $matc)) {
							$pr_from=$matc[1];
							if (preg_match('/'.preg_quote($sql_tab['produktzuordnung']).' /i', $pr_from) or preg_match('/'.preg_quote($sql_tab['produktzuordnung']).',/i', $pr_from)) {
								$pr_from.=','.$sql_tabs['produktzuordnung']['produktzuordnung_id'];
								$merke_sql3=p4n_mb_string('str_replace', $matc[1], $pr_from, $merke_sql3);
								$row2[1]=$merke_sql3;
							}
						}
					}
				
				if (trim($row2[3])!='') {
					$where_auss='';
					$k_ids=array();
					$res3=$db->select(
						$sql_tab['filter'],
						array(
							$sql_tabs['filter']['sql'],
							$sql_tabs['filter']['name']
						),
						$db->dbzahlin($row2[3],$sql_tabs['filter']['filter_id'])
					);
					while ($row3=$db->zeile($res3)) {
                        if ($cfg_db_subselects) {
							$sqls1=$row3[0];
							if (preg_match('/select (.*) from/i', $sqls1, $ma1)) {
								$sqls1=p4n_mb_string('str_replace', $ma1[1], $sql_tabs['stammdaten']['id'], $sqls1);
							}
							$sqls1=$db->checksql($sqls1, 1);
                            $where_auss.=' and '.$sql_tabs['stammdaten']['id'].' NOT IN ('.$sqls1.')';
						} else {
							$res4=$db->select2($row3[0]);
							while ($row4=$db->zeile($res4)) {
								$k_ids[$row4[0]]=1;
							}
						}
					}
					$alle_ids='';
					if (count($k_ids)>0) {
						while (list($ukey, $uval)=@each($k_ids)) {
							$alle_ids.=$ukey.',';
						}
						$alle_ids=p4n_mb_string('substr',$alle_ids, 0, -1);
					}
					
					$filter_sql=$row2[1];
					$cf_feld=filter_get_comp($filter_sql);
					if (trim($alle_ids)!='') {
						$filter_sql=p4n_mb_string('str_replace', $cf_feld[1], $cf_feld[1].' and '.$db->dbzahlin($alle_ids,$sql_tabs['stammdaten']['id'],'NOT IN'), $filter_sql);
					}
					if ($cfg_db_subselects and $where_auss!='') {
						$filter_sql=p4n_mb_string('str_replace', $cf_feld[1], $cf_feld[1].$where_auss, $filter_sql);
					}
					$row2[1]=$filter_sql;
				}
                if ($_SESSION['crm_version']>61) {
                    $f2_sql=$row2[1];
					$sqlgr=sql_gruppe($sql_tabs['stammdaten']['id']);
                    if (preg_match('/'.$sql_tab['stammdaten_gruppe_zuordnung'].'/', $sqlgr)) {//TT: zeile 1915 wird das hinzugefuegt aber ans Ende
                        if (preg_match('/LEFT JOIN/i', $f2_sql)) {
                            $f2_sql=preg_replace('/(.*from )(.*)( LEFT JOIN.*)( where.*)/i', '\\1\\2\\3,'.$sql_tab['stammdaten_gruppe_zuordnung'].'\\4', $f2_sql);
                        } else {
                            $f2_sql=preg_replace('/(.*from )(.*)( where.*)/i', '\\1\\2,'.$sql_tab['stammdaten_gruppe_zuordnung'].' \\3', $f2_sql);
                            if ($row2[1]==$f2_sql) {
                                $f2_sql=preg_replace('/(.*from )([^\s]*)(.*)/i', '\\1\\2,'.$sql_tab['stammdaten_gruppe_zuordnung'].' \\3', $f2_sql);
                            }
                        }
					}
                    if (preg_match('/where/i', $f2_sql) && !stristr($f2_sql, $sqlgr)) {
                        if (preg_match('/'.$sql_tab['stammdaten_gruppe_zuordnung'].'/', $sqlgr)) {
                            $f2_sql=preg_replace('/(.*)(where )(.*)/i', '\\1\\2'.$sql_tabs['stammdaten_gruppe_zuordnung']['stammdaten_id'].'='.$sql_tabs['stammdaten']['id'].' and '.$sqlgr.' and \\3', $f2_sql);
						} else{
							$f2_sql=preg_replace('/(.*)(where )(.*)/i', '\\1\\2 '.$sqlgr.' and \\3', $f2_sql);
						}
					}
                    $row2[1]=$f2_sql;
                }
                
                    $pagination=new Template_Pagination('pagination_widget_filter_'.$_POST['pim_filter_id']);
                
					$anzahl_pro_seite=10;
					$fi_start=0;
					$seite=1;
					if (isset($_POST['pim_filter_seite']) and intval(isset($_POST['pim_filter_seite']))>0) {
						$seite=$_POST['pim_filter_seite'];
					}
					$fi_start=$anzahl_pro_seite*($seite-1);
					if ($_SESSION['pim_filter_ids'][$row2[2]] == '') {
					    $res3=$db->select2($row2[1]);
					    $anz1=$db->anzahl($res3);
					    $_SESSION['pim_filter_ids'][$row2[2]] = $anz1;
					} else {
					    $anz1 = $_SESSION['pim_filter_ids'][$row2[2]];
					}
                    $pagination->create($anz1);
					
					$gesamtseiten=intval($anz1/$anzahl_pro_seite) + (($anz1 / $anzahl_pro_seite - intval($anz1/$anzahl_pro_seite))!=0);
					
					$anz0='';
					
					$nav_string='';
					if ($anz1>0 and $anz1>$anzahl_pro_seite) {
						$anz0=intval(1+$fi_start).'-'.intval($anzahl_pro_seite+$fi_start).' '._VON_.' ';
						if ($seite>1) {
							$nav_string.=link2('&lt;&lt;', 'javascript: lade_in_div(\'fi_'.$row2[2].'\', \''.$phs.'\', \'pim_filter_id='.$row2[2].'&pim_filter_seite='.intval($seite-1).'\');');
						} else {
							$nav_string.='&lt;&lt;';
						}
						$nav_string.=' '._SEITE_.' '.$seite.' ';
						if ($seite<$gesamtseiten) {
						$nav_string.=link2('&gt;&gt;', 'javascript: lade_in_div(\'fi_'.$row2[2].'\', \''.$phs.'\', \'pim_filter_id='.$row2[2].'&pim_filter_seite='.intval($seite+1).'\');');
						} else {
							$nav_string.='&gt;&gt;';
						}
					}
                    
                    $pagination->setRequest('POST', 'fi_'.$row2[2], 'pim.php', array('pim_filter_id='.$row2[2].'&pagination_filter_=1'));
                    
                    
                    if ($_SESSION['design_70']) {
                        $fi_start=$pagination->von();
                    }
                    if ($_SESSION['design_70']) {
                        $anzahl_pro_seite=$pagination->limit();
                    }
                    
					$res3=$db->select2($row2[1], $fi_start, $anzahl_pro_seite);
					unset($tf_kopf);
					$fzi=0;
					$dbselect = true;
                    $cols_header=array();
                    $table_data=array();
					while ($fzi<$anzahl_pro_seite) {
                        $cols_view=array();
					    if (is_array($_SESSION['pim_filter_ids'][$row2[2].$fi_start.$anzahl_pro_seite][$fzi])) {
                            $row3=$_SESSION['pim_filter_ids'][$row2[2].$fi_start.$anzahl_pro_seite][$fzi];
                            if (!$row3) {
                                break;
                            }
                            $dbselect = false;
					    } elseif ($dbselect) {
                            $row3=$db->zeile($res3);
                            if ($row3===false) {
                                break;
                            }
                            $_SESSION['pim_filter_ids'][$row2[2].$fi_start.$anzahl_pro_seite][$fzi] = $row3;
					    }
					    
					    
						if (!isset($tf_kopf)) {
							$fi_spalten=0;
							reset($row3);
							$tf_kopf.='<tr>';
							while (list($keyf, $valf)=@each($row3)) {
								if ($keyf=='produktzuordnung_id') {
									continue;
								}
                                if (!is_numeric($keyf)) {
									
									$erg=explode('___', $keyf);
									if (isset($tababk2[$erg[0]])) {
										$keyf=$tababk2[$erg[0]].substr($keyf, strlen($erg[0]));
										$erg=explode('___', $keyf);
									}
						$bez='';
						$zb_sql_feld='';
						$ktabfe='';
                        if (count($erg)==3) {
							$ktabfe=$erg[1];
							if ($erg[1]=='zusatzfelder') {
								if (preg_match('/zf_(\d+)/', $erg[2], $zfma)) {
									$bez=p4n_mb_string('ucfirst',$erg[0]).': '.p4n_mb_string('ucfirst',$lang_db_f['zusatzfelder']['zf_'.$zfma[1]]);
								} else {
									$bez=p4n_mb_string('ucfirst',$erg[0]).': '.p4n_mb_string('ucfirst',$erg[2]);
								}
								$zb_sql_feld=$erg[0].'.'.$erg[2];
							} else {
								$bez=p4n_mb_string('ucfirst',$erg[0]).': '.p4n_mb_string('ucfirst',$lang_db_f[$erg[1]]['']).'_'.p4n_mb_string('ucfirst',$lang_db_f[$erg[1]][$erg[2]]);
								$zb_sql_feld=$erg[1].'.'.$erg[2];
							}
						} elseif (count($erg)==2) {
							$ktabfe=$erg[count($erg)-2];
                            if ($erg[count($erg)-2]=='zusatzfelder') {
								$bez=$erg[count($erg)-1];
								if (preg_match('/zf_(\d+)/', $bez, $zfma)) {
									$bez=$lang_db_f['zusatzfelder']['zf_'.$zfma[1]];
								}
								$zb_sql_feld=$erg[0].'.'.$erg[1];
							} else {
                                $bez=p4n_mb_string('ucfirst',$lang_db_f[$erg[count($erg)-2]][$erg[count($erg)-1]]);
                                if ($bez == '') {
                                    $bez=p4n_mb_string('ucfirst',$erg[count($erg)-1]);
                                }
								$zb_sql_feld=$erg[0].'.'.$erg[1];
							}
						} else {
							$ktabfe=$keyf;
							if ($key=='Stammdaten_ID') {
								$key=$lang_db_f['stammdaten']['id'];
							}
							$bez=p4n_mb_string('ucfirst',$key);
							$zb_sql_feld=$key;
						}
									$anztabfe=$bez;
                                    $bez70=$bez;
									if (isset($lang_db_f[$ktabfe][''])) {
										$anztabfe=oltext(ucfirst($lang_db_f[$ktabfe]['']).' - '.$bez, $bez);
                                        $bez70=ucfirst($lang_db_f[$ktabfe]['']).' - '.$bez;
									}
									$tf_kopf.='<th class="th">'.$anztabfe.'</th>';
                                    $cols_header[]=$bez70;
									$fi_spalten++;
								}
							}
							$tf_kopf.='</tr>';
							reset($row3);
						}
				$stid=0;
				if (isset($row3['stammdaten___id']))
					$stid=$row3['stammdaten___id'];
				elseif (isset($row3['Stammdaten_ID']))
					$stid=$row3['Stammdaten_ID'];
				elseif (isset($row3['stammdaten_id']))
					$stid=$row3['stammdaten_id'];
				elseif (isset($row3['id']))
					$stid=$row3['id'];
				else {
					$stid=0;
					continue;
				}
               
						$tf_kopf.='<tr '.tr_zeile().' class="'.($x%2?'even':'odd').'">';// onClick="if (b!=1) { location.href=\'stammdaten_main.php?nav=Uebersicht&id='.$stid.'\'; } else { b=0; }"
                        $x++;
                        
						while (list($keyf, $valf)=@each($row3)) {
								if ($keyf=='produktzuordnung_id') {
									continue;
								}
							if (!is_numeric($keyf)) {
								$erg=explode('___', $keyf);
								if (isset($tababk2[$erg[0]])) {
									$keyf=$tababk2[$erg[0]].substr($keyf, strlen($erg[0]));
								}
					$m_val=$val;
					$val=$valf;
					$tfeld='';
					$erg=explode('___', $keyf);
					$ziffer=false;
					
					$sqlt1_tab='';
					$sqlt1_feld='';
                    if ($ar_sum[$erg[0]]==$ar_sum[_MINIMUM_] or $ar_sum[$erg[0]]==$ar_sum[_MAXIMUM_]) {
                        $erg[0]=$erg[1];
                        $erg[1]=$erg[2];
                        unset($erg[2]);
                    }
                    if ($ar_sum[$erg[0]]!=$ar_sum[_ANZAHL_] and $ar_sum[$erg[0]]!=$ar_sum[_SUMME_] and $ar_sum[$erg[0]]!=$ar_sum[_MINIMUM_] and $ar_sum[$erg[0]]!=$ar_sum[_MAXIMUM_]) {
					//if ($erg[0]!=_ANZAHL_ and $erg[0]!=_SUMME_ and $erg[0]!=_MINIMUM_ and $erg[0]!=_MAXIMUM_) {
						for($i=1; $i<count($erg); $i++) {
							$tfeld.=$erg[$i].'_';
                        }
						$tfeld=p4n_mb_string('substr',$tfeld,0,-1);
						
						$exp_typ[$ap_zi]='S';
                        if (is_array($sql_meta[$erg[0]][$tfeld])) {
                            if (@in_array('D', $sql_meta[$erg[0]][$tfeld])) {
                                $val=$db->unixdate($val);
                                $exp_typ[$ap_zi]='D';
                            } elseif (@in_array('T', $sql_meta[$erg[0]][$tfeld])) {
                                $val=$db->unixdatetime($val);
                                $exp_typ[$ap_zi]='T';
                            } elseif (@in_array('L', $sql_meta[$erg[0]][$tfeld])) {
                                $val=($val=='1'?_JA_:_NEIN_);
                                $exp_typ[$ap_zi]='S';
                            } elseif (@in_array('F', $sql_meta[$erg[0]][$tfeld]) or @in_array('N', $sql_meta[$erg[0]][$tfeld])) {
                                $val=p4n_mb_string('str_replace', '.', ',', $val);
                                $ziffer=true;
                                $exp_typ[$ap_zi]='Z';
                            }
                        }
						
						if (isset($sql_tab_ids[$sql_tabs[$erg[0]][$tfeld]])) {
//							echo 'vorher:'.$val;
							$val=anzeige_idwert($sql_tabs[$erg[0]][$tfeld], $val);
//							echo ' nachher: '.$val.'<br>';
						}
						
						$sqlt1_tab=$erg[0];
						$sqlt1_feld=$tfeld;
						
					} else {
						if ($ar_sum[$erg[0]]==$ar_sum[_ANZAHL_] or $ar_sum[$erg[0]]==$ar_sum[_SUMME_]) {
							$exp_typ[$ap_zi]='Z';
							
						//	$val=number_format($val, 2, ",", ".");
						//	$val=p4n_mb_string('str_replace', '.', ',', $val);
							$ziffer=true;
						} else {
							$exp_typ[$ap_zi]='S';
                            if (is_array($sql_meta[$erg[1]][$erg[2]])) {
                                if (@in_array('D', $sql_meta[$erg[1]][$erg[2]])) {
                                    $val=$db->unixdate($val);
                                    $exp_typ[$ap_zi]='D';
                                }
                                if (@in_array('T', $sql_meta[$erg[1]][$erg[2]])) {
                                    $val=$db->unixdatetime($val);
                                    $exp_typ[$ap_zi]='T';
                                }
                                if (@in_array('L', $sql_meta[$erg[1]][$erg[2]])) {
                                    $val=($val=='1'?_JA_:_NEIN_);
                                    $exp_typ[$ap_zi]='S';
                                }
                                if (@in_array('F', $sql_meta[$erg[1]][$erg[2]]) or @in_array('N', $sql_meta[$erg[1]][$erg[2]])) {
                                    $val=p4n_mb_string('str_replace', '.', ',', $val);
                                    $ziffer=true;
                                    $exp_typ[$ap_zi]='Z';
                                }
                            }
						}
						
						$sqlt1_tab=$erg[1];
						$sqlt1_feld=$erg[2];
					}
					
					if (p4n_mb_string('strpos',$sql_feld_geldbetrag, ','.$sql_tabs[$sqlt1_tab][$sqlt1_feld].',')!==false) {
						if ($aktuelle_kartei=='Export') {
							$val=number_format(doubleval(p4n_mb_string('str_replace', ',', '.', $val)), 2, ",", "");
						} else {
							$val=number_format(doubleval(p4n_mb_string('str_replace', ',', '.', $val)), 2, ",", ".");
						}
					}
					
					if ($val=='') {
						$wert_h='&nbsp;';
					} else {
						if ($_SESSION['cfg_kunde']=='carlo_opel_russland') {
							$wert_h=$val;
						} elseif ($erg[0]=='korrespondenz' and ($erg[1]=='beschreibung' or $erg[1]=='ergebnis_text')) {
							$wert_h=p4n_mb_string('str_replace', "\n", '<br>', p4n_mb_string('htmlentities',p4n_mb_string('str_replace', '<br>', "\n", $val)));
						} else {
							$val=p4n_mb_string('str_replace', array('&lt;', '&gt;'), array('<', '>'), $val);
							if ($aktuelle_kartei=='Export') {
								
							} else {
								$wert_h=p4n_mb_string('htmlentities',$val);
							}
						}
					}
					if ($sqlt1_tab=='stammdaten' and $sqlt1_feld=='id') {
                        $wert_h=linkToTab($wert_h, 'stammdaten_main.php?nav=Uebersicht&id='.$stid, '', '', '', 1);
                    } elseif ($sqlt1_tab=='opportunity' and $sqlt1_feld=='opportunity_id') {
                        $wert_h=linkToTab($wert_h, 'stammdaten_main.php?nav=OM&id='.$stid.'&akvid='.$wert_h, '', '', '', 1);
					}
					// Dateilink:
					if (p4n_mb_string('strpos',$sql_feld_dateilinks, $sql_tabs[$erg[0]][$tfeld])!==false) {
						$tpfad=$cfg_ordner_kdokumente_pfad;
                        if (p4n_mb_string('substr',$wert_h, 0, 5)=='http:' || p4n_mb_string('substr',$wert_h, 0, 6)=='https:') {
                            $tpfad='';
                        } elseif (p4n_mb_string('strstr',$wert_h, ':')!=false and p4n_mb_string('strstr',$wert_h, '\\')!=false and p4n_mb_string('strstr',$wert_h, '/')!=false) {
                            $tpfad='file://';
                        }
						if ($wert_h=='' or $wert_h=='&nbsp;') {
							$dlink=$wert_h;
						} else {
							$dbil=docbild($wert_h, true);
							if ($dbil=='Link') {
								$dbil='';
							}
							$dlink=link2(_LINKTO_, $tpfad.$wert_h, $dbil, '', 'target="_blank" onClick="b=1;"');
						}
						$wert_h=$dlink;
					}
					
					$val=$m_val;
								$tf_kopf.='<td class="td">'.$wert_h.'</td>';// anstatt $valf
                                $cols_view[]=$wert_h;
							}
						}
						$tf_kopf.='</tr>';
						$fzi++;
                        
                        ksort($cols_view);
                        if (!$table_data_i) {
                            $table_data_i = 1;
                        }
                        $table_data[$table_data_i++] = $cols_view;
					}
					if ($anz1==0) {
						$tf_kopf='<tr class="odd"><td class="td" colspan='.$fi_spalten.'>'._KEIN_ERGEBNIS_.'</td></tr>';
					}
                    $nav_string70='';
                    if (!empty($cfg_multiroute) && stristr($row2[0], 'multiroute')) {
                    	$nav_string .= ' / '.link2(_UEBERTRAGEN_.' (MultiRoute)', $phs.'?multiroute='.$_POST['pim_filter_id']);
                        $nav_string70=new Template_Button('',_UEBERTRAGEN_.' (MultiRoute)','','', $phs.'?multiroute='.$_POST['pim_filter_id'],'','xs','darkgrey-outline');
					}
                    $answer='<table class="'.($cfg_modern?'table-ignore2 moderntable':'hori2').'"><!sbl><tr><th class="th" colspan='.$fi_spalten.'>'.link2($row2[0], 'stammdaten_main.php?filterneu='.$_POST['pim_filter_id']).' ('.$anz0.$anz1.') '.$nav_string.'</th></tr>'.$tf_kopf.'</table>';
                    if ($_SESSION['design_70']) {
                        
                        if ((count($table_data)>0)) {} else {
                            $cols_header=array(_KEIN_ERGEBNIS_);
                            $table_data[1][0]='';
                            $pagination->create(1);
                        }
                        $reload_btn=Template_IconButton::init('','','','refresh','',$abfrage='', $sizeClass = 'xs')->setRequest('POST', 'fi_'.$row2[2], 'pim.php', array('pim_filter_id='.$row2[2].'&pagination_filter_=1'));
                        $table=Template_Default::Table($cols_header,$table_data,array('size'=>'sm','sort'=>false,'collapse'=>false,'minHeight'=>250,'maxHeight'=>250),array(),array(),new Template_ElementList(array($nav_string70,$reload_btn,Template_IconButton::init('','','','launch','',$abfrage='', $sizeClass = 'xs')->setRequest('GET','_tab','stammdaten_main.php','filterneu='.$_POST['pim_filter_id'])),'','horizontal'),$pagination,true, _FILTER_.' ('.$row2[0].')',array('paginationInCard'=>true,'cardOptions'=>array('border'),'addScrollBar'=>true));
                        //$card=Template_Default::Card(_FILTER_.' ('.$row2[0].')',new Template_ElementList(array(new Template_IconButton('','','','launch','stammdaten_main.php?filterneu='.$_POST['pim_filter_id'],$abfrage='', $sizeClass = 'xs')),'','hozizontal'),array($table,$pagination));
                        $table=new Template_ElementList($table,'','filter_widget');
                        echo $table->getHtml();
                        $table_data=array();
                        if (isset($_POST['pagination_filter_'])) {
                           // echo javas('pim_autoheight_();');
                        }
                    } else {
                        echo (($cfg_modern)?Modern_Helper_Request::requestParse($answer):$answer);
                    }
            }
		die();
	}
	
    $alle_bens=array();
	$alle_bens2=array();
	$res=$db->select(
		$sql_tab['benutzer'],
		array(
			$sql_tabs['benutzer']['benutzer_id'],
			$sql_tabs['benutzer']['vorname'],
			$sql_tabs['benutzer']['name'],
			$sql_tabs['benutzer']['gruppe']
		)
	);
	while ($row=$db->zeile($res)) {
		$alle_bens[$row[0]]=trim($row[2].', '.$row[1]);
		if (($row[3])>=1) {
			$alle_bens2[$row[0]]=trim($row[2].', '.$row[1]);
		}
	}
	@asort($alle_bens2);

    $bens_pim=array();
    if ($cfg_pim_otherusers) {
        $rechte_ = array();
        if (is_a($menuRights, 'Rights_MenuPoint')) {
            $rechte_ = $menuRights->getConfigurationFromUser($_SESSION['user_id']);
        }
        if (!empty($rechte_) && (isset($rechte_['only_self_user']) || isset($rechte_['only_standard_lagerort_user']) || isset($rechte_['only_mandant_auswertung_user']))) {
            if (isset($rechte_['only_self_user'])) {
                include_once('inc/lib_sn.php');
                $benutzer_weiter = get_benutzer_weiterleitung($_SESSION['user_id']);
                if (count($benutzer_weiter)>1) {
                    $res=$db->select(
                        $sql_tab['benutzer'],
                        array(
                            $sql_tabs['benutzer']['benutzer_id'],
                            $sql_tabs['benutzer']['vorname'],
                            $sql_tabs['benutzer']['name'],
                            $sql_tabs['benutzer']['gruppe']
                        ),
                        $db->dbzahlin($benutzer_weiter, $sql_tabs['benutzer']['benutzer_id'])
                    );
                    while ($row=$db->zeile($res)) {
                        $bens_pim[$row[0]]=trim($row[2].', '.$row[1]);
                    }
                }
            } elseif (isset($rechte_['only_standard_lagerort_user'])) {
                if (intval($_SESSION['user_standard_lagerort'])>0) {
                    $res=$db->select(
                        $sql_tab['benutzer'],
                        array(
                            $sql_tabs['benutzer']['benutzer_id'],
                            $sql_tabs['benutzer']['vorname'],
                            $sql_tabs['benutzer']['name'],
                            $sql_tabs['benutzer']['gruppe']
                        ),
                        $sql_tabs['benutzer']['standard_lagerort'].'='.$db->dbzahl($_SESSION['user_standard_lagerort'])
                    );
                    while ($row=$db->zeile($res)) {
                        $bens_pim[$row[0]]=trim($row[2].', '.$row[1]);
                    }
                }
            } elseif (isset($rechte_['only_mandant_auswertung_user'])) {
                if ($_SESSION['benutzer_mandant_auswertung']=='-1') {
                    $zusatz_lagerort = $sql_tabs['benutzer']['standard_lagerort'].'>'.$db->dbzahl(0);
                } else {
                    $zusatz_lagerort = $db->dbzahlin($_SESSION['benutzer_mandant_auswertung'], $sql_tabs['benutzer']['standard_lagerort']);
                }
                $bens_pim = rbenutzer(1, true, $sql_tabs['benutzer']['gruppe'].'>='.$db->dbzahl(0).' and '.$zusatz_lagerort);
            }
            @asort($bens_pim);
        } else {
            $res7=$db->select(
                $sql_tab['benutzer_gruppe'],
                array(
                    $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
                    $sql_tabs['benutzer_gruppe']['bezeichnung']
                ),
                $sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('VK-Leiter').' or '.$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('Verkaufsleiter')
                    .($cfg_pim_otherusers_vkl!=''?' or '.$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str($cfg_pim_otherusers_vkl):'')
            );
            while ($row7=$db->zeile($res7)) {
                if ($_SESSION['rechte_bgruppen']=='-1' or preg_match('/,'.$row7[0].',/', ','.$_SESSION['rechte_bgruppen'].',')) {
                    $bens_pim=$alle_bens2;
                }
            }
            if (count($bens_pim)==0 and intval($_SESSION['user_standard_lagerort'])>0) {
                $res7=$db->select(
                    $sql_tab['benutzer_gruppe'],
                    array(
                        $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
                        $sql_tabs['benutzer_gruppe']['bezeichnung']
                    ),
                    $sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('Filial-Leiter')
                        .($cfg_pim_otherusers_fl!=''?' or '.$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str($cfg_pim_otherusers_fl):'')
                );
                if ($row7=$db->zeile($res7)) {
                    if ($_SESSION['rechte_bgruppen']=='-1' or preg_match('/,'.$row7[0].',/', ','.$_SESSION['rechte_bgruppen'].',')) {
                        $alle_bens2=array();
                        $res=$db->select(
                            $sql_tab['benutzer'],
                            array(
                                $sql_tabs['benutzer']['benutzer_id'],
                                $sql_tabs['benutzer']['vorname'],
                                $sql_tabs['benutzer']['name'],
                                $sql_tabs['benutzer']['gruppe']
                            ),
                            $sql_tabs['benutzer']['standard_lagerort'].'='.$db->dbzahl($_SESSION['user_standard_lagerort'])
                        );
                        while ($row=$db->zeile($res)) {
                            $alle_bens2[$row[0]]=trim($row[2].', '.$row[1]);
                        }
                        @asort($alle_bens2);
                        $bens_pim=$alle_bens2;
                    }
                }
            }
        }
    }
    
	function pim_wvlblock($filterwvl=0) {
		global $inhalt,$inhalt70,$tab70,$card70, $db, $sql_tab, $sql_tabs, $awhere, $sortorder, $kblock, $stammdaten_korrespondenz, $merke_offene, $ol, $kftext, $ebene, $k_art_symbole, $kfz_weitere, $cfg_kfz,$kfz_eintraege, $cfg_ordner_kdokumente_pfad, $lang, $form, $anzahl_a, $cb_erlfeld, $gesamt_anzahl, $ohne_where, $limit, $cfg_pim_ergebnishaken, $cfg_kerfolg_balken, $alle_bens, $alle_kamps, $alle_kamps2, $where_weitl, $cfg_pim_erledigt, $feld, $cfg_leadengine, $cfg_neustyle, $cfg_pim_korralle_keine_erl, $cfg_ws_avag_kroatien, $userid_pim, $alle_kamps_man, $carlo_tw, $carlo_hk,$cfg_modern, $cfg_akvkorr_nurstdlao;
		global $cfg_pim_defkorrart;
		global $cfg_pim_nurwvlkamp;
		global $pim_keincount, $zeitdebug, $artkorr, $merke_awhere, $ist_standard, $alle_korrdaten, $pim_langsamer;
		global $hbBlock, $handbuch, $cfg_leadmanagement_2020;
        global $dashboard, $bens_pim, $alle_bens2, $alle_bens, $alle_kunden, $alle_leads, $plugin_list, $cfg_pim_filter_kat, $cfg_just_show_running_kamps, $cfg_avag_teilehandel2021, $js_multiroute, $multiroute_link, $cfg_pim_eva_anzeigen;
        global $pagination, $filterwvl_temp;
        global $isLeadPimInPim;
        global $pim_modal_inhalt, $pim_modal;
        global $debug, $user, $cfg_leadprozess_schneller;
        global $stammdaten_korrespondenz_filter, $cfg_pim_multiroute;
		
        //$debug->debug('testpim.txt','pim wvlblock START');
        
        $filterwvl_temp=$filterwvl;
        
		if ($pim_langsamer) {
			$pim_keincount=false;
		}
        
		if (!isset($alle_kamps_man)) {
			$alle_kamps_man=array(0 => _IMPORT_KEINE_ZUORDNUNG_);
			$alle_k_ids='';
			$alle_k_ids2=array();
			if ($cfg_pim_nurwvlkamp  || $_SESSION['design_70']) {
			$res=$db->select(
						$sql_tab['korrespondenz'],
						'distinct '.$sql_tabs['korrespondenz']['kampagne_id'],
                        $sql_tabs['korrespondenz']['kampagne_id'].'>'.$db->dbzahl(0).' and '.
						$sql_tabs['korrespondenz']['betreuer_id'].$where_weitl
							.' and '.$sql_tabs['korrespondenz']['erledigt'].'=0'
			);
//							.' and '.$sql_tabs['korrespondenz']['kampagne_id'].'>0'
			while ($row=$db->zeile($res)) {
				if (intval($row[0])>0) {
					if (!isset($alle_k_ids2[$row[0]])) {
						$alle_k_ids.=$row[0].',';
					}
					$alle_k_ids2[$row[0]]=1;
				}
			}
			if ($alle_k_ids!='') {
				$alle_k_ids=substr($alle_k_ids, 0, -1);
				$res2=$db->select(
					$sql_tab['kampagne'],
					array(
						$sql_tabs['kampagne']['beginn'],
						$sql_tabs['kampagne']['ende'],
						$sql_tabs['kampagne']['bezeichnung'],
						$sql_tabs['kampagne']['kampagne_id']
					),
					$sql_tabs['kampagne']['kampagne_id'].' in ('.$alle_k_ids.')',
					$sql_tabs['kampagne']['bezeichnung']
				);
				while ($row2=$db->zeile($res2)) {
					$alle_kamps_man[$row2[3]]=$row2[2].' ('.($row2[0]!=''?$db->unixdate($row2[0]):'').' - '.($row2[1]!=''?$db->unixdate($row2[1]):'').')';
				}
			}
			} else {
				$kamp_where = $cfg_just_show_running_kamps?$sql_tabs['kampagne']['ende'].'>NOW() or '.$sql_tabs['kampagne']['ende'].' is null':'';
				$res2=$db->select(
					$sql_tab['kampagne'],
					array(
						$sql_tabs['kampagne']['beginn'],
						$sql_tabs['kampagne']['ende'],
						$sql_tabs['kampagne']['bezeichnung'],
						$sql_tabs['kampagne']['kampagne_id']
					),
					$kamp_where,
					$sql_tabs['kampagne']['bezeichnung']
				);
				while ($row2=$db->zeile($res2)) {
					$alle_kamps_man[$row2[3]]=$row2[2].' ('.($row2[0]!=''?$db->unixdate($row2[0]):'').' - '.($row2[1]!=''?$db->unixdate($row2[1]):'').')';
				}
			}
		}
        $joins_lead = false;
        $tabelle_leads = array();
        $leadawhere= '';
        $keine_leadbedingung = $sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(0);
        global $cfg_mb_nl, $noCorrespondenceLimit;
        if ($cfg_mb_nl) {
            $tabelle_leads = array(1 => $sql_tab['kampagne_lead']);
            $joins_lead['_LJ_'.$sql_tabs['korrespondenz']['lead_id']]=$sql_tabs['kampagne_lead']['kampagne_lead_id'];
            $leadawhere = ' and '.$sql_tabs['kampagne_lead']['leadid'].' not like '.$db->str('CRM_%');
            
            $keine_leadbedingung = '('.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(0).' or ('.$sql_tabs['korrespondenz']['lead_id'].'!='.$db->dbzahl(0).' and '.$sql_tabs['kampagne_lead']['leadid'].' like '.$db->str('CRM_%').'))';
        }
        
		$ksel1=$form->selectinput('filter_kamp', $alle_kamps_man, $feld['filter_kamp'], _ALLE_, 'style="width: 90px"');
		
		if ($cfg_pim_filter_kat) {
			if (!isset($_SESSION['pim_korrkats'])) {
				$alle_korrkats=array();
				$res3=$db->select(
					$sql_tab['korrespondenz'],
					'distinct '.$sql_tabs['korrespondenz']['kategorie']
				);
				while ($row3=$db->zeile($res3)) {
					if ($row3[0]!='' and $row3[0]!='-1') {
						$alle_korrkats[$row3[0]]=$row3[0];
					}
				}
				@ksort($alle_korrkats);
				$_SESSION['pim_korrkats']=$alle_korrkats;
			} else {
				$alle_korrkats=$_SESSION['pim_korrkats'];
			}
			if (count($alle_korrkats)>0) {
				$ksel1.=' | '._KATEGORIE_.': '.$form->selectinput('filter_korrkat', $alle_korrkats, $feld['filter_korrkat'], _ALLE_, 'style="width: 90px"');
			}
		}
		
		//$ksel1=kampagnen_select('filter_kamp', true, $feld['filter_kamp'], true, 100, '', ' style="width: 90px"');	// $form->selectinput('filter_kamp', $alle_kamps, $feld['filter_kamp'], _ALLE_, 'style="width: 60px"')
				
			if ($cfg_pim_ergebnishaken) {
						$inhalt=preg_replace('/<th[^>]*>'._ERGEBNIS_.'<\/th>/i', '', $inhalt);
						$inhalt=preg_replace('/<td[^>]*>\{k_ergebnis\}<\/td>/i', '', $inhalt);
			}

			if (preg_match_all("/{block-k-start\}(.*){block-k-ende}/Uis", $inhalt, $kblock, PREG_SET_ORDER)) {
				$kblock=$kblock[0][1];
			}
			
            if ($carlo_tw && (!$feld['wfilterdatum_ende'] || $feld['wfilterdatum_ende']=='') && (!$feld['wfilterdatum_start'] || $feld['wfilterdatum_start']=='')) {
                $awhere.=' and '.$sql_tabs['korrespondenz']['wvl_datum1'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59');
				//$awhere .= ' and ' . $sql_tabs['korrespondenz']['wvl_datum1'] . ' is not null';
            }
			if ($cfg_akvkorr_nurstdlao) {
				$alle_ausschl=ausschluss_stdlao_akv();
				if ($alle_ausschl!='') {
					$awhere.=' and '.$sql_tabs['korrespondenz']['betreuer_id'].' not in ('.$alle_ausschl.')';
				}
			}
			if ($_SESSION['cfg_kunde'] === 'carlo_koltes') {
                $awhere.=' and '.$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->str('');
                //$awhere.=' and '.$sql_tabs['korrespondenz']['betreff'].'!='.$db->str('Preisblattaktualisierung');
            }
			if ($zeitdebug) {
				echo 'vor selects: '.zeitnahme().'<br>';
			}
			if ($cfg_mb_nl) {
				$pim_keincount=false;
			}
			if ($merke_awhere!=$awhere) {
				$pim_keincount=false;
			}
			if ($cfg_pim_eva_anzeigen || $_SESSION['leadprozess']=='pim_vkl' || $_SESSION['leadprozess']=='pim' || isset($_POST['pim_lead_php'])) {
				// EVA anzeigen
			} else {
				$awhere.=' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('EVA-Import');
			}
            $korreinlesen=false;
            $user_role_rights = array();
            if ($cfg_leadmanagement_2020 && $_SESSION['leadprozess']=='pim_vkl') {
                if (!empty($_SESSION['user_role_rights'])) {
                    $user_role_rights = $_SESSION['user_role_rights'];
                }
            }
			if ($pim_keincount) {
				if ($zeitdebug) {
					echo 'pim_keincount: '.zeitnahme().'<br>';
				}
                $where_array=array();
                $betreuer_where=$sql_tabs['korrespondenz']['betreuer_id'].$where_weitl;
				if ($merke_awhere==$awhere) {
					$ist_standard=true;
				}
				$korreinlesen=true;
                
                $sql_kor=array(
						$sql_tabs['korrespondenz']['korrespondenz_id'],
						$sql_tabs['korrespondenz']['datum'],
						$sql_tabs['korrespondenz']['wvl_datum1'],
						$sql_tabs['korrespondenz']['wvl_datum2'],
						$sql_tabs['korrespondenz']['ersteller_id'],
						$sql_tabs['korrespondenz']['betreuer_id'],
						$sql_tabs['korrespondenz']['eingang'],
						$sql_tabs['korrespondenz']['art'],
						$sql_tabs['korrespondenz']['kategorie'],
						$sql_tabs['korrespondenz']['erledigt'],
						$sql_tabs['korrespondenz']['parent_id'], // 10
						$sql_tabs['korrespondenz']['doclink'],
						$sql_tabs['korrespondenz']['betreff'],
						$sql_tabs['korrespondenz']['beschreibung'],
						$sql_tabs['korrespondenz']['produktzuordnung_id'],
						$sql_tabs['korrespondenz']['papierkorb'],
						$sql_tabs['korrespondenz']['kalender_id'],
						$sql_tabs['korrespondenz']['prioritaet'],
						$sql_tabs['korrespondenz']['negativ'],
						$sql_tabs['korrespondenz']['stammdaten_id'],
						$sql_tabs['korrespondenz']['datum2'],		// 20
						$sql_tabs['korrespondenz']['ergebnis_text'],
						$sql_tabs['korrespondenz']['ergebnis_datum'],
						$sql_tabs['korrespondenz']['ergebnis_kategorie'],
						$sql_tabs['korrespondenz']['kampagne_id'],
						$sql_tabs['korrespondenz']['wvlkampagne_id'], //25
						$sql_tabs['korrespondenz']['ansprechpartner_id'],
                    	$sql_tabs['korrespondenz']['aus_workflow'],
                        $sql_tabs['korrespondenz']['lead_id']//28
					);    
                
                $rechte_ = array();
                if (class_exists('Rights_MenuPoint')) {
                    $menuRights = new Rights_MenuPoint('pim.php');
                    $rechte_ = $menuRights->getConfigurationFromUser($_SESSION['user_id']);
                }
                
                $orderBy = $sql_tabs['korrespondenz']['datum'].' desc';
                $alle_leads_kampagne_lead_status=array();
                $where_leadprozess='';
				$tabelle_leads=array();
                if (isset($_POST['leadprozess'])) {
					
					$orderBy=$sql_tabs['korrespondenz']['korrespondenz_id'].' desc';   
                    
					if ($cfg_leadprozess_schneller) {
						$where_leadprozess_alternative='1=1';
						if ($_SESSION['pim_lead_datum_start']!='') {
							$where_leadprozess_alternative=$sql_tabs['kampagne_lead']['status1_time'].'>='.$db->dbdate($_SESSION['pim_lead_datum_start']);
						}
						if ($_SESSION['pim_lead_datum_ende']!='') {
							$where_leadprozess_alternative.=' and '.$sql_tabs['kampagne_lead']['status1_time'].'<='.$db->dbdate($_SESSION['pim_lead_datum_ende']);
						}
					} else {
	                    $where_leadprozess_alternative=$sql_tabs['kampagne_lead_status']['kampagne_lead_id'].'='.$sql_tabs['kampagne_lead']['kampagne_lead_id'];
					}
					$where_leadprozess_alternative2='1=1';
					if ($_SESSION['pim_lead_datum_start']!='') {
						$where_leadprozess_alternative2=$sql_tabs['kampagne_lead_status']['status1_datum'].'>='.$db->dbdate($_SESSION['pim_lead_datum_start']);
					}
					if ($_SESSION['pim_lead_datum_ende']!='') {
						$where_leadprozess_alternative2.=' and '.$sql_tabs['kampagne_lead_status']['status1_datum'].'<='.$db->dbdate($_SESSION['pim_lead_datum_ende']);
					}
                    $sql_kamp=array();
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['lagerort_id'];
					if ($cfg_leadprozess_schneller) {
						$sql_kamp[]=$sql_tabs['kampagne_lead']['status5_time'];
					} else {
	                    $sql_kamp[]=$sql_tabs['kampagne_lead_status']['lead_stage'];
					}
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['status1_time'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['type'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['leadid'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['kampagne_lead_id'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['additionaldata'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['kfzmarke'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['source'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['channel'];
					$sql_kamp[]=$sql_tabs['kampagne_lead']['erfassungsdatum'];
					$sql_kamp[]=$sql_tabs['kampagne_lead']['status'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['kamp_kategorie'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['kfzmarke'];
                    
                    if ($_SESSION['leadprozess']=='pim_vkl') {
                        if ($_SESSION['pim_and_leadstatus']!=-1) {
							if (!$cfg_leadprozess_schneller) {
	                            $where_leadprozess_alternative.=' and '.$db->dbzahlin($_SESSION['pim_and_leadstatus'], $sql_tabs['kampagne_lead_status']['lead_stage']);
							}
							$where_leadprozess_alternative2.=' and '.$db->dbzahlin($_SESSION['pim_and_leadstatus'], $sql_tabs['kampagne_lead_status']['lead_stage']);
                        }
                    } elseif ($_SESSION['leadprozess']=='pim' || isset($_POST['pim_lead_php'])) {
                        if ($_POST['show_lead']=='link_closed') {
                            $where_leadprozess_alternative.=' and '.$sql_tabs['kampagne_lead']['status'].'='.$db->dbzahl(5);
                            $where_leadprozess.=' and '.$sql_tabs['korrespondenz']['erledigt'].'='.$db->dblogic(1);
                        } elseif ($_POST['show_lead']=='link_edit') {
                            $where_leadprozess_alternative.=' and '.$db->dbzahlin(array(1,2,3,4,5),$sql_tabs['kampagne_lead']['status']);
                            $where_leadprozess.=' and '.$sql_tabs['korrespondenz']['erledigt'].'='.$db->dblogic(0);
                        } else {
                            if (isset($_SESSION['design_70'], $_POST['pim_lead_php'])) {
                                $where_leadprozess .= ' and '.$sql_tabs['korrespondenz']['erledigt'].'='.$db->dblogic(0);
                            } else {
                                $where_leadprozess.=' and '.$sql_tabs['korrespondenz']['parent_id'].'='.$db->dbzahl(0).' and '.$sql_tabs['korrespondenz']['erledigt'].'='.$db->dblogic(0);
                            }
                        }
                        if (!empty($rechte_)) {
                            if (isset($rechte_['sort_order_leadpim_wvl_asc'])) {
                                $orderBy='CASE WHEN '.$sql_tabs['korrespondenz']['wvl_datum1'].' is null or '.$sql_tabs['korrespondenz']['wvl_datum1'].'='.$db->str('0000-00-00').' or '.$sql_tabs['korrespondenz']['wvl_datum1'].'='.$db->str('1970-01-01').' THEN 2 ELSE 1 END, '.$sql_tabs['korrespondenz']['wvl_datum1'].' asc, '.$sql_tabs['korrespondenz']['datum'].' asc';
                            } elseif (isset($rechte_['sort_order_leadpim_wvl_desc'])) {
                                $orderBy=$sql_tabs['korrespondenz']['wvl_datum1'].' desc, '.$sql_tabs['korrespondenz']['datum'].' desc';
                            } elseif (isset($rechte_['sort_order_leadpim_date_asc'])) {
                                $orderBy=$sql_tabs['korrespondenz']['datum'].' asc';
                            } elseif (isset($rechte_['sort_order_leadpim_date_desc'])) {
                                $orderBy=$sql_tabs['korrespondenz']['datum'].' desc';
                            }
                        }
                    }
                    
                    $where_leadprozess_alternative.=' and '.$sql_tabs['kampagne_lead']['benutzer_id'].$where_weitl;
                    $betreuer_where='1=1';
                    if (isset($_POST['leadprozess_lagerort'])) {
                        $where_leadprozess_lag=array();
                        require_once('inc/lib_sn.php');
                        $get_mandanten = get_mandanten(true, 2);
                        $alle_dealer = $get_mandanten[2];
                        foreach ($alle_dealer as $lag => $mand) {
                            if (intval($_POST['leadprozess_lagerort'])==-1 || $_POST['leadprozess_lagerort']==$mand || $_POST['leadprozess_lagerort']==$lag) {
                                $where_leadprozess_lag[$lag]=$lag;
                            }
                        }
                        if (!empty($where_leadprozess_lag)) {
                            $where_leadprozess_alternative.=' and '.$db->dbzahlin($where_leadprozess_lag, $sql_tabs['kampagne_lead']['lagerort_id']);
                        }
                    }
					if ($zeitdebug) {
						echo 'vor Lead-select: '.zeitnahme().'<br>';
					}
					
					if ($cfg_leadprozess_schneller) {
						// status1_datum
						$result_kamp_lead=$db->select(
							$sql_tab['kampagne_lead_status'],
							array(
								$sql_tabs['kampagne_lead_status']['kampagne_lead_id'],
								$sql_tabs['kampagne_lead_status']['lead_stage']
							),
							$where_leadprozess_alternative2
						);
						if ($zeitdebug) {
							echo 'nach Leadstatus-select: '.zeitnahme().'<br>';
							echo $db->anzahl($result_kamp_lead).': '.htmlentities($db->last_sql).'<br>'; echo '<br>';
						}
						$alle_leadstatus=array();
						while ($row_kamp_lead = $db->zeile($result_kamp_lead)) {
							$alle_leadstatus[$row_kamp_lead[0]]=$row_kamp_lead[1];
						}
						if ($zeitdebug) {
							echo 'vor Lead-select: '.zeitnahme().'<br>';
						}
						$result_kamp_lead=$db->select(
							$sql_tab['kampagne_lead'],
							$sql_kamp,
							$where_leadprozess_alternative
						);
						if ($zeitdebug) {
							echo 'nach Lead-select: '.zeitnahme().'<br>';
							echo $db->anzahl($result_kamp_lead).': '.htmlentities($db->last_sql).'<br>'; echo '<br>';
						}
						while ($row_kamp_lead = $db->zeile($result_kamp_lead)) {
							if (isset($alle_leadstatus[$row_kamp_lead[5]])) {
								$row_kamp_lead[1]=$alle_leadstatus[$row_kamp_lead[5]];
								$row_kamp_lead['lead_stage']=$alle_leadstatus[$row_kamp_lead[5]];
	        	                $alle_leads_kampagne_lead_status[$row_kamp_lead['kampagne_lead_id']]=$row_kamp_lead;
							}
            	        }
						if ($zeitdebug) {
							echo 'nach Lead-select, Anzahl - '.count($alle_leads_kampagne_lead_status).': '.zeitnahme().'<br>';
						}
					} else {
	                    $result_kamp_lead = $db->select(
    	                    array(
        	                    $sql_tab['kampagne_lead'],
            	                $sql_tab['kampagne_lead_status']
                	        ),
                    	    $sql_kamp,
	                        $where_leadprozess_alternative
    	                );
						if ($zeitdebug) {
							echo 'nach Lead-select: '.zeitnahme().'<br>';
							echo $db->anzahl($result_kamp_lead).': '.htmlentities($db->last_sql).'<br>'; echo '<br>';
						}
						debug_logging('kamp_lead query: '.$db->last_sql());
    	                while ($row_kamp_lead = $db->zeile($result_kamp_lead)) {
        	                $alle_leads_kampagne_lead_status[$row_kamp_lead['kampagne_lead_id']]=$row_kamp_lead;
            	        }
					}
					
                    if (!empty($alle_leads_kampagne_lead_status)) {
						if ($cfg_leadprozess_schneller) {
							if ($_SESSION['pim_lead_datum_start']!='') {
								$where_leadprozess.=' and '.$sql_tabs['korrespondenz']['datum'].'>='.$db->dbdate($_SESSION['pim_lead_datum_start']);
							}
							if ($_SESSION['pim_lead_datum_ende']!='') {
								$where_leadprozess.=' and '.$sql_tabs['korrespondenz']['datum'].'<='.$db->dbdate($_SESSION['pim_lead_datum_ende']);
							}
						}
                        $where_leadprozess.=' and '.$db->dbzahlin(array_keys($alle_leads_kampagne_lead_status), $sql_tabs['korrespondenz']['lead_id']);
                    } else {
                        $where_leadprozess=' and 1=2';
                    }
                    $noCorrespondenceLimit=true;
                } else {
                    if (!empty($rechte_)) {
                        if (isset($rechte_['sort_order_pim_wvl_asc'])) {
                            $orderBy='CASE WHEN '.$sql_tabs['korrespondenz']['wvl_datum1'].' is null or '.$sql_tabs['korrespondenz']['wvl_datum1'].'='.$db->str('0000-00-00').' or '.$sql_tabs['korrespondenz']['wvl_datum1'].'='.$db->str('1970-01-01').' THEN 2 ELSE 1 END, '.$sql_tabs['korrespondenz']['wvl_datum1'].' asc, '.$sql_tabs['korrespondenz']['datum'].' asc';
                        } elseif (isset($rechte_['sort_order_pim_wvl_desc'])) {
                            $orderBy=$sql_tabs['korrespondenz']['wvl_datum1'].' desc, '.$sql_tabs['korrespondenz']['datum'].' desc';
                        } elseif (isset($rechte_['sort_order_pim_date_asc'])) {
                            $orderBy=$sql_tabs['korrespondenz']['datum'].' asc';
                        } elseif (isset($rechte_['sort_order_pim_date_desc'])) {
                            $orderBy=$sql_tabs['korrespondenz']['datum'].' desc';
                        }
                    }
                }
				if (!isset($_GET['sort'])) {
					$sortorder=$orderBy;
				}
         		if ($db->treiber=='mysql' and $sortorder==$sql_tabs['korrespondenz']['datum'].' desc') {
					$sortorder='CAST('.$sql_tabs['korrespondenz']['datum'].' as DATETIME) desc';
				}
         		if ($db->treiber=='mysql' and $sortorder==$sql_tabs['korrespondenz']['datum'].' asc') {
					$sortorder='CAST('.$sql_tabs['korrespondenz']['datum'].' as DATETIME) asc';
				}
				if ($db->treiber=='mysql' and $sortorder==$sql_tabs['korrespondenz']['korrespondenz_id'].' desc') {
					$sortorder='CAST('.$sql_tabs['korrespondenz']['korrespondenz_id'].' as UNSIGNED) desc';	// INTEGER
				}
				$orderBy=$sortorder;
				
                $where_array[] = '(('.$betreuer_where.'))';
                if ($carlo_tw) {
                    $where_array[] = $keine_leadbedingung;
                    $where_array[] = $sql_tabs['korrespondenz']['wvlkampagne_id'].'='.$db->dbzahl(0);
                }
				
				$sqlt_tabs=array($sql_tab['korrespondenz']);
				
				$where_th='';
				if ($cfg_avag_teilehandel2021 or $cfg_pim_multiroute) {
					$sqlt_tabs[]=$sql_tab['stammdaten_adresse'];
					$sql_kor[]=$sql_tabs['stammdaten_adresse']['adresse'];
					$sql_kor[]=$sql_tabs['stammdaten_adresse']['plz'];
					$sql_kor[]=$sql_tabs['stammdaten_adresse']['ort'];
					$where_leadprozess.=' and '.$sql_tabs['korrespondenz']['stammdaten_id'].'='.$sql_tabs['stammdaten_adresse']['stammdaten_id'];
					$where_th.=' and '.$sql_tabs['korrespondenz']['stammdaten_id'].'='.$sql_tabs['stammdaten_adresse']['stammdaten_id'];
				}
				
                $res=$db->select(
        	        $sqlt_tabs+$tabelle_leads,
					$sql_kor,
					implode(' and ', $where_array).$awhere.$where_leadprozess,
					$orderBy,	//$sql_tabs['korrespondenz']['wvl_datum1'].' desc, '.
					'',
					false,
                    ($noCorrespondenceLimit ? 0 : 10000)
				);
				debug_logging('where_leadprozess query: '.$db->last_sql());
                if ($db->anzahl($res)>=30000) {
                    if (!isset($_POST['leadprozess'])) {
                        $korreinlesen=false;
                        $pim_keincount=false;
                    }
                }
				if ($zeitdebug) {
					echo 'nach select: '.zeitnahme().'<br>';
					echo $db->anzahl($res).': '.htmlentities($db->last_sql).'<br>'; echo '<br>';
				}
				$auch_le=false;
				$anz_le=0;
				$auch_auto=false;
				$anz_auto=0;
				$auch_auto2=false;
				$anz_auto2=0;
				$kfz_eintraege=0;
				$nurwvl_eintraege=0;
				$auch_erl=false;
				$anz_erl=0;
				$heute_start=adodb_mktime(0,0,0,adodb_date('m', time()), adodb_date('d', time()), adodb_date('Y', time()));
				$heute_ende=adodb_mktime(23,59,59,adodb_date('m', time()), adodb_date('d', time()), adodb_date('Y', time()));
				$alle_korrdaten = $alle_leads = $alle_kunden = array();
				$alle_korrdaten[10]=0;
				$alle_korrdaten[11]=0;
				
				$bed_workshop=true;
				if ($_SESSION['sprache']!='lang_de' and $row[8]=='Workshop') {
					$bed_workshop=false;
				}
                //$dtNow = new DateTime();
				while ($korreinlesen and $row=$db->zeile($res)) {		//Korrespondenz query row Flag
					/*if (empty($row[2]) && $_POST['filterdatum_start']=='' and $_POST['filterdatum_ende']=='') {
						$dt = new DateTime($row[1]);

                        if ($dt->getTimestamp() >= $dtNow->getTimestamp()) {
                            continue;
                        }
					}*/
					
                    if (!empty($alle_leads_kampagne_lead_status[$row[28]])) {
                        foreach ($alle_leads_kampagne_lead_status[$row[28]] as $result_key => $row_value_neu) {
                            if (is_numeric($result_key) || isset($row[$result_key])) {
                                continue;
                            }
                            $row[$result_key]=$row_value_neu;
                        }
                    }
                    
					if ($cfg_pim_eva_anzeigen || $_SESSION['leadprozess']=='pim_vkl' || $_SESSION['leadprozess']=='pim' || isset($_POST['pim_lead_php'])) {
						// EVA anzeigen
					} else {
						// EVA nicht anzeigen
						if ($row[8]=='EVA-Import') {
							continue;
						}
					}
				    if ($_SESSION['leadprozess']=='pim_vkl') {
                        $prove_art = ($row['type']!='') ? $row['type'] : -1;
                        if (!empty($user_role_rights['sparten_zuordnung'])) {
                            if (!in_array($prove_art, $user_role_rights['sparten_zuordnung'])) {
                                continue;
                            }
                        }
                        $prove_channel = ($row['channel']!='') ? $row['channel'] : -1;
                        if (!empty($user_role_rights['kanal_zuordnung'])) {
                            if (!in_array($prove_channel, $user_role_rights['kanal_zuordnung'])) {
                                continue;
                            }
                        }
                        $prove_source = ($row['source']!='') ? $row['source'] : -1;
                        if (!empty($user_role_rights['quelle_zuordnung'])) {
                            if (!in_array($prove_source, $user_role_rights['quelle_zuordnung'])) {
                                continue;
                            }
                        }
                        $prove_marke = ($row['kfzmarke']!='') ? $row['kfzmarke'] : -1;
                        if (!empty($user_role_rights['marken_zuordnung'])) {
                            if (!in_array($prove_marke, $user_role_rights['marken_zuordnung'])) {
                                continue;
                            }
                        }
                    }
                    
				    if (intval($row[19]) > 0) {
                        $alle_kunden[$row[19]] = $row[19];
                    }
                    if (intval($row[9])==0 and $row[8]!='TKP Termin' and $row[8]!='WPS Termin' and $row[8]!='WS Termin' and $bed_workshop) {
						if ($db->unixdate_ts($row[1])<=$heute_ende and ($db->unixdate_ts($row[2])<=$heute_ende or $row[2]=='' or $row[2]=='0000-00-00 00:00:00')) {
							if (intval($row[28])>0) {
                                $alle_korrdaten[1][]=$row;
                            }
							if (intval($row[27])>0) {
								$alle_korrdaten[2][]=$row;
							}
							if (intval($row[25])>0) {
								$alle_korrdaten[3][]=$row;
							}
							if (intval($row[27])==0 and intval($row[28])==0 and intval($row[25])==0) {
								if ($row[2]!='' and $row[2]!='1970-01-01 00:00:00' and $row[2]!='0000-00-00 00:00:00') {
									$tswv=$db->unixdate_ts($row[2]);
								} else {
									$tswv=$db->unixdate_ts($row[1])-365*24*60*60;
								}
								while (isset($alle_korrdaten[4][$tswv])) {
									$tswv++;
								}
								$alle_korrdaten[4][$tswv]=$row;
							}
						}
					}
                    if (intval($row[9])==0 and intval($row[28])>0) {
                        $anz_le++;
                        $auch_le=true;
                        $alle_leads[$row[28]] = $row[28];
                    }
					if (intval($row[9])==0 and intval($row[27])>0) {
						$anz_auto++;
						$auch_auto=true;
					}
					if (intval($row[9])==0 and intval($row[25])>0) {
						$anz_auto2++;
						$auch_auto2=true;
					}
					if (intval($row[9])==0) {
						$kfz_eintraege++;
					}
					if (intval($row[9])==0 and intval($row[28])==0 and intval($row[27])==0 and intval($row[25])==0) {
						if ($row[8]!='TKP Termin' and $row[8]!='WPS Termin' and $row[8]!='WS Termin' and $row[8]!='Workshop') {
							$nurwvl_eintraege++;
						}
					}
					if (intval($row[9])==1 && $cfg_pim_erledigt) {
						if ($row[8]!='TKP Termin' and $row[8]!='WPS Termin' and $row[8]!='WS Termin' and $row[8]!='Workshop') {
							if (($db->unixdate_ts($row[1])>=$heute_start and $db->unixdate_ts($row[1])<=$heute_ende) or ($db->unixdate_ts($row[2])>=$heute_start and $db->unixdate_ts($row[2])<=$heute_ende) or ($db->unixdate_ts($row[22])>=$heute_start and $db->unixdate_ts($row[22])<=$heute_ende)) {
								$auch_erl=true;
                                $anz_erl++;
                                $alle_korrdaten[5][]=$row;
							}
						}
					}
					if (($db->unixdate_ts($row[1])>=$heute_start and $db->unixdate_ts($row[1])<=$heute_ende) or ($db->unixdate_ts($row[2])>=$heute_start and $db->unixdate_ts($row[2])<=$heute_ende) or ($db->unixdate_ts($row[22])>=$heute_start and $db->unixdate_ts($row[22])<=$heute_ende)) {
						if (intval($row[9])==1) {
							$alle_korrdaten[10]++;
						} else {
							$alle_korrdaten[11]++;
						}
					}
				}
				if ($zeitdebug) {
					echo 'nach selects: '.zeitnahme().'<br>';
				}
			}
			
			$leadproz_wert='';
			if (isset($_POST['leadprozess'])) {
				$leadproz_wert=$_POST['leadprozess'];
			}
			if ($leadproz_wert!='1' and !$korreinlesen) {
                //$debug->debug('testpim.txt','pim wvlblock !$korreinlesen');
    //			if ($filterwvl==0) {
                $auch_le=false;
                $anz_le=0;
                if (1==1 or $cfg_leadengine or $carlo_tw or $carlo_hk) {
					if ($zeitdebug) {
						echo 'vor select Lead: '.zeitnahme().'<br>';
					}
                    $res=$db->select(
                            array($sql_tab['korrespondenz'])+$tabelle_leads,
                            'count('.$sql_tabs['korrespondenz']['korrespondenz_id'].')',
                            $sql_tabs['korrespondenz']['betreuer_id'].$where_weitl
                                .' and '.$sql_tabs['korrespondenz']['erledigt'].'=0 '
                                .' and '.$sql_tabs['korrespondenz']['lead_id'].'!=0 '
                                .$awhere.$leadawhere,
                                '',
                                '',
                                $joins_lead
                    );
					if ($zeitdebug) {
						echo 'nach select Leads: '.zeitnahme().'<br>';
						echo $db->anzahl($res).': '.htmlentities($db->last_sql).'<br>'; echo '<br>';
					}
                    if ($row=$db->zeile($res)) {
                        $anz_le=$row[0];
                        if ($anz_le>0) {
                            $auch_le=true;
                        }
                    }
                    if ($_SESSION['design_70']) {
                        $auch_le=false;
                    }
                }
                $auch_auto=false;
				if ($zeitdebug) {
					echo 'vor select Makro: '.zeitnahme().'<br>';
				}
                $res=$db->select(
                    $sql_tab['korrespondenz'],
                    'count('.$sql_tabs['korrespondenz']['korrespondenz_id'].')',
                    $sql_tabs['korrespondenz']['betreuer_id'].$where_weitl
                        .' and '.$sql_tabs['korrespondenz']['erledigt'].'=0 '
                        .' and '.$sql_tabs['korrespondenz']['aus_workflow'].'='.$db->dblogic(true).' '
                        .($carlo_tw ? ' and '.$keine_leadbedingung.' '
                        .' and '.$sql_tabs['korrespondenz']['wvlkampagne_id'].'='.$db->dbzahl(0).' ' : '')
                        .$awhere
                );
				if ($zeitdebug) {
					echo 'nach select Makro: '.zeitnahme().'<br>';
					echo $db->anzahl($res).': '.htmlentities($db->last_sql).'<br>'; echo '<br>';
				}
                if ($row=$db->zeile($res)) {
                    $anz_auto=$row[0];
                    if ($anz_auto>0) {
                        $auch_auto=true;
                    }
                }

                $auch_auto2=true;
				if ($zeitdebug) {
					echo 'vor select WVL-Kamp: '.zeitnahme().'<br>';
				}
                $res=$db->select(
                            $sql_tab['korrespondenz'],
                            'count('.$sql_tabs['korrespondenz']['korrespondenz_id'].')',
                            $sql_tabs['korrespondenz']['betreuer_id'].$where_weitl
                                .' and '.$sql_tabs['korrespondenz']['erledigt'].'=0 '
                                .' and '.$sql_tabs['korrespondenz']['wvlkampagne_id'].'>0 '
                                .($carlo_tw ? ' and '.$keine_leadbedingung : '')
                                .$awhere
                );
				if ($zeitdebug) {
					echo 'nach select WVL: '.zeitnahme().'<br>';
					echo $db->anzahl($res).': '.htmlentities($db->last_sql).'<br>'; echo '<br>';
				}
                if ($row=$db->zeile($res)) {
                    $anz_auto2=$row[0];
                    if ($anz_auto2>0) {
                        $auch_auto2=true;
                    }
                }



    //			if ($cfg_kfz) {
				if ($zeitdebug) {
					echo 'vor select korr: '.zeitnahme().'<br>';
				}
                $res=$db->select(
                        $sql_tab['korrespondenz'],
                        'count('.$sql_tabs['korrespondenz']['korrespondenz_id'].')',
                        $sql_tabs['korrespondenz']['betreuer_id'].$where_weitl
                            .' and '.$sql_tabs['korrespondenz']['erledigt'].'=0 '
                            .$awhere
                );
                $kfz_eintraege=0;
				if ($zeitdebug) {
					echo 'nach select korr: '.zeitnahme().'<br>';
					echo $db->anzahl($res).': '.htmlentities($db->last_sql).'<br>'; echo '<br>';
				}
                if ($row=$db->zeile($res)) {
                    $kfz_eintraege=$row[0];
                }
               /* echo '$kfz_eintraege '.$kfz_eintraege.' '.htmlentities($sql_tabs['korrespondenz']['betreuer_id'].$where_weitl
                            .' and '.$sql_tabs['korrespondenz']['erledigt'].'=0 '
                            .$awhere).'<br>';*/

    //            $kfz_eintraege=$db->anzahl($res);
    //			}

				if ($zeitdebug) {
					echo 'vor select korr 2: '.zeitnahme().'<br>';
				}
                $res=$db->select(
                    array($sql_tab['korrespondenz'])+$tabelle_leads,
                    'count('.$sql_tabs['korrespondenz']['korrespondenz_id'].')',
                    $sql_tabs['korrespondenz']['betreuer_id'].$where_weitl
                        .' and '.$sql_tabs['korrespondenz']['erledigt'].'=0 '
                        .$awhere.' and '.$sql_tabs['korrespondenz']['wvlkampagne_id'].'=0'.
                        ' and '.$sql_tabs['korrespondenz']['aus_workflow'].'=0'.
                        ' and '.$keine_leadbedingung.' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('TKP Termin')
                        .' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('WPS Termin')
                        .' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('WS Termin')
                        .' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('Workshop'),
                        '',
                        '',
                        $joins_lead
                );
				if ($zeitdebug) {
					echo 'nach select korr 2: '.zeitnahme().'<br>';
					echo $db->anzahl($res).': '.htmlentities($db->last_sql).'<br>'; echo '<br>';
				}
                $nurwvl_eintraege=0;
                if ($row=$db->zeile($res)) {
                    $nurwvl_eintraege=$row[0];
                }

                $auch_erl=false;
                $anz_erl=0;
                if ($cfg_pim_erledigt) {
                    $dat1_erl=adodb_date('d.m.Y');
                    if ($feld['filterdatum_start']!='' and p4n_mb_string('strlen',$feld['filterdatum_start'])==10 && !isset($_POST['leadprozess'])) {
                        $dat1_erl=$feld['filterdatum_start'];
                    }
                    $dat2_erl=adodb_date('d.m.Y');
                    if ($feld['filterdatum_ende']!='' and p4n_mb_string('strlen',$feld['filterdatum_ende'])==10 && !isset($_POST['leadprozess'])) {
                        $dat2_erl=$feld['filterdatum_ende'];
                    }
					if ($zeitdebug) {
						echo 'vor select korr 3: '.zeitnahme().'<br>';
					}
                    $res=$db->select(
                    $sql_tab['korrespondenz'],
                    'count('.$sql_tabs['korrespondenz']['korrespondenz_id'].')',
                    $sql_tabs['korrespondenz']['betreuer_id'].$where_weitl
                        .' and '.$sql_tabs['korrespondenz']['erledigt'].'=1 '.
                    ' and (('.$sql_tabs['korrespondenz']['datum'].' between '.$db->dbzeitdatum($dat1_erl, '00:00:00').
                    ' and '.$db->dbzeitdatum($dat2_erl, '23:59:59').
                    ') or ('.$sql_tabs['korrespondenz']['wvl_datum1'].' between '.$db->dbzeitdatum($dat1_erl, '00:00:00').
                    ' and '.$db->dbzeitdatum($dat2_erl, '23:59:59').
                    ') or ('.$sql_tabs['korrespondenz']['ergebnis_datum'].' between '.$db->dbzeitdatum($dat1_erl, '00:00:00').
                    ' and '.$db->dbzeitdatum($dat2_erl, '23:59:59').'))'.' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('TKP Termin')
                    .' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('WPS Termin')
                    .' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('WS Termin')
                    .' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('Workshop')
                    );
					if ($zeitdebug) {
						echo 'nach select korr 3: '.zeitnahme().'<br>';
						echo $db->anzahl($res).': '.htmlentities($db->last_sql).'<br>'; echo '<br>';
					}
                    if ($row=$db->zeile($res)) {
                        $anz_erl=$row[0];
                        if ($anz_erl>0) {
                            $auch_erl=true;
                        }
                    }
                }


			}
            
            $kfz_eintraege2=$nurwvl_eintraege+$anz_auto+$anz_auto2+$anz_erl;
            
            

            // Ende if ($pim_keincount) {
            
				$filt_zus='';
				$l_aktiv=array(
					'', '', '', '', '', '', ''
				);
                
                if (!isset($feld['wvlart']) && isset($_SESSION['wvlart'])) {
                    $feld['wvlart']=$_SESSION['wvlart'];
                    $_POST['wvlart']=$_SESSION['wvlart'];
                }
                if (isset($feld['wvlart']) && !$cfg_pim_defkorrart && !isset($_POST['leadprozess'])) {
                    $_SESSION['wvlart']=$feld['wvlart'];
                }
                
				if (!isset($feld['wvlart'])) {
					if (isset($cfg_pim_defkorrart)) {
						if ($cfg_pim_defkorrart>0) {
							$feld['wvlart']=strval($cfg_pim_defkorrart);
						}
					}
				}

				if ($feld['wvlart']=='0') {
					$l_aktiv[0]='_a';
                    $aktiv='tab_0';
				}
				if ($feld['wvlart']=='1') {
					$l_aktiv[1]='_a';
                    $aktiv='tab_1';
				}
				if ($feld['wvlart']=='2') {
					$l_aktiv[2]='_a';
                    $aktiv='tab_5';
				}
				if ($feld['wvlart']=='3') {
					$l_aktiv[3]='_a';
                    $aktiv='tab_3';
				}
				if ($feld['wvlart']=='4') {
					$l_aktiv[4]='_a';
                    $aktiv='tab_4';
				}
				if ($feld['wvlart']=='5') {
					$l_aktiv[5]='_a';
                    $aktiv='tab_2';
				}
				if (!isset($feld['wvlart'])) {
					$l_aktiv[0]='_a';
                    $aktiv='tab_0';
				}
				$wvor1='<td class="menu_karte">';
				$wnach1='</td>';
				
				if ($cfg_neustyle) {
					
					$stiln1='';
					if ($cfg_neustyle) {
						if (isset($_SESSION['stil'])) {
							if (preg_match('/style(.*)\.css/i', $_SESSION['stil'], $sma1)) {
								$stiln1=$sma1[1];
							}
							if (!is_file('img/verlauf'.$stiln1.'.jpg')) {
								$stiln1='';
							}
						}
					}
					
					$mr1=0;
					if (preg_match('/MSIE/i', $_SERVER["HTTP_USER_AGENT"])) {
						$mr1=15;
					}
					$wvor1='<li';
					$wnach1='</li>';
					
					$filt_zus.='<td class="leer" style="background: #fff url(img/verlauf'.$stiln1.'.jpg) repeat-x top left; vertical-align:bottom; text-align: right;"><div style="margin-right: '.$mr1.'pt;"><div id="header" style="height: 35px;"><div id="nav"><ul>';
					
					//$text='<td class="menu_karten_liste" width="40%" style="background: #fff url(img/verlauf.jpg) repeat-x top left; vertical-align:middle; text-align: center;">'.$ztext.'</td><td class="leer" width="60%" style="background: #fff url(img/verlauf.jpg) repeat-x top left; vertical-align:bottom; text-align: right;"><div id="header" style="height: 48px"><div id="nav"><ul> <li class="first/active"></li>';
					//$text.='</ul></div></div></td><td width="1px;" style="background: #fff url(img/verlauf.jpg) repeat-x top left;"></td>';
				}
				
                //$debug->debug('testpim.txt','pim wvlblock tab erstellung');
                
				$filt_zus.=$wvor1.($cfg_neustyle?($l_aktiv[0]!=''?' class="active">':' class="first">'):'').'<!SMke1>'.link2(_ALLE_.' ('.$kfz_eintraege.')', 'javascript: lade_wvl(\'wvlart=0\')', '', '', ($cfg_neustyle?'':'style="font-size:12px;" class="karten'.$l_aktiv[0].'"')).'<!SMke2>'.$wnach1;
				$tab_links['tab_0'] = Template_Link::init(_ALLE_.' ('.$kfz_eintraege2.')')->setRequest('POST', 'pim_modal_inhalt', 'pim.php?pagination_korr_1=1&reset_pagnination=1', 'wvlart=0&noautotabclick=1');

                if ($auch_le && !$isLeadPimInPim) {		//Leads Flag
					$filt_zus.=$wvor1.($cfg_neustyle?($l_aktiv[1]!=''?' class="active">':'>'):'').'<!SMke1>'.link2(_LEADS_.' ('.$anz_le.')', 'javascript: lade_wvl(\'wvlart=1\')', '', '', ($cfg_neustyle?'':'style="font-size:12px;" class="karten'.$l_aktiv[1].'"')).'<!SMke2>'.$wnach1;
                    //$tab_links['tab_1'] = Template_Link::init(_LEADS_.' ('.$anz_le.')')->setRequest('POST', 'pim_modal_inhalt', 'pim.php?pagination_korr_1=1', 'wvlart=1&noautotabclick=1');
                }
				$filt_zus.=$wvor1.($cfg_neustyle?($l_aktiv[5]!=''?' class="active">':'>'):'').'<!SMke1>'.link2(_WVL_.' ('.$nurwvl_eintraege.')', 'javascript: lade_wvl(\'wvlart=5\')', '', '', ($cfg_neustyle?'':'style="font-size:12px;" class="karten'.$l_aktiv[5].'"')).'<!SMke2>'.$wnach1;
				$tab_links['tab_2'] = Template_Link::init(_WVL_.' ('.$nurwvl_eintraege.')')->setRequest('POST', 'pim_modal_inhalt', 'pim.php?pagination_korr_1=1&reset_pagnination=1', 'wvlart=5&noautotabclick=1');
                if ($auch_auto) {
					$filt_zus.=$wvor1.($cfg_neustyle?($l_aktiv[3]!=''?' class="active">':'>'):'').'<!SMke1>'.link2(_MAKROS_.' ('.$anz_auto.')', 'javascript: lade_wvl(\'wvlart=3\')', '', '', ($cfg_neustyle?'':'style="font-size:12px;" class="karten'.$l_aktiv[3].'"')).'<!SMke2>'.$wnach1;
                    $tab_links['tab_3'] = Template_Link::init(_MAKROS_.' ('.$anz_auto.')')->setRequest('POST', 'pim_modal_inhalt', 'pim.php?pagination_korr_1=1&reset_pagnination=1', 'wvlart=3&noautotabclick=1');
                }
				if ($auch_auto2) {
					$filt_zus.=$wvor1.($cfg_neustyle?($l_aktiv[4]!=''?' class="active">':'>'):'').'<!SMke1>'.link2(_KAMPP_.' ('.$anz_auto2.')', 'javascript: lade_wvl(\'wvlart=4\')', '', '', ($cfg_neustyle?'':'style="font-size:12px;" class="karten'.$l_aktiv[4].'"')).'<!SMke2>'.$wnach1;
                    $tab_links['tab_4'] =  Template_Link::init(_KAMPP_.' ('.$anz_auto2.')')->setRequest('POST', 'pim_modal_inhalt', 'pim.php?pagination_korr_1=1&reset_pagnination=1', 'wvlart=4&noautotabclick=1');
                }
				if ($auch_erl) {
					$filt_zus.=$wvor1.($cfg_neustyle?($l_aktiv[2]!=''?' class="active">':'>'):'').'<!SMke1>'.link2($lang['_VERTRAG-ERLEDIGT_'].' ('.$anz_erl.')', 'javascript: lade_wvl(\'wvlart=2\')', '', '', ($cfg_neustyle?'':'style="font-size:12px;" class="karten'.$l_aktiv[2].'"')).'<!SMke2>'.$wnach1;	// .' | '
                    $tab_links['tab_5'] = Template_Link::init($lang['_VERTRAG-ERLEDIGT_'].' ('.$anz_erl.')')->setRequest('POST', 'pim_modal_inhalt', 'pim.php?pagination_korr_1=1&reset_pagnination=1', 'wvlart=2&noautotabclick=1');
                }
				if ($cfg_neustyle) {
					$filt_zus.='</ul></div></div></div></td>';
				}
                
                if (is_array($kfz_eintraege2) && is_array($pim_kennzahl_status))
                $pim_kennzahl_status=array_merge(array('alle Leads'=>$kfz_eintraege2),$pim_kennzahl_status);
                
				$filterdatumTmp = '<!SMfe1>'.(($cfg_modern)?'<!SMfl1>'._KORRP_.'<!SMfl2>':'').$form->datuminput('filterdatum_start', $feld['filterdatum_start']).''.
					''.' - '.''.
					''.$form->datuminput('filterdatum_ende', $feld['filterdatum_ende']) . '<!SMfe2>';

                $filterdatum1= $filterdatumTmp .
                        '<!NULL>'.' '.'<!NULL>'.
                        '<!NULL>'.$form->submit('submit', _AUFTRAG_FILTERDATUMSUBMIT_).'<!NULL>';

                $filterdatum2='<!NULL>'.' '.'<!NULL>'.
                        '<!SMfe1><!SMfl1>'._WVL_.': '.'<!SMfl2>'.
                        $form->datuminput('wfilterdatum_startKorr', $feld['wfilterdatum_startKorr']).''.
                        ''.' - '.''.
                        ''.$form->datuminput('wfilterdatum_endeKorr', $feld['wfilterdatum_endeKorr']);
                if ($_SESSION['crm_version'] > 64) {
                	$ageTypes = array(
						-1 => ' - ',
                		30 => '&gt; 30',
						60 => '&gt; 60',
						90 => '&gt; 90',
					);
                	$fancyScript =
					"function onWvlAgeChanged(ageField) {
						var af;
						if (ageField.jquery) {
							af = ageField
						}
						else {
							af = jQuery(ageField);
						}
                		
                		var date = new Date();
						var options = {day: '2-digit', year: 'numeric', month: '2-digit'};
                			
                		if (af.val() > 0) {
                			jQuery(\"input[name='wfilterdatum_start']\").prop('disabled', true);
                			jQuery(\"input[name='wfilterdatum_ende']\").prop('disabled', true);
                			var age = af.val();
                			date.setDate(date.getDate() - age);
                			jQuery(\"input[name='wfilterdatum_ende']\").val(date.toLocaleDateString('de-DE', options));
                		}
                		else {
                			jQuery(\"input[name='wfilterdatum_start']\").prop('disabled', false);
                			jQuery(\"input[name='wfilterdatum_ende']\").prop('disabled', false);
                			
                			//jQuery(\"input[name='wfilterdatum_ende']\").val(date.toLocaleDateString('de-DE', options)).trigger(\"onblur\");
                		}
                	}
                	jQuery(document).ready(function() {
                		onWvlAgeChanged(jQuery(\"select[name='wfilter_alter']\"));
                	});";
                	$tspanDropdown = javas($fancyScript);
					$tspanDropdown .= ' ' . _ODER_ . ' ' . $lang['_K-ALTER_'] . ' ' . $form->selectinput('wfilter_alter', $ageTypes, $feld['wfilter_alter'], false, 'onchange="onWvlAgeChanged(this)"') . ' ' . _NAECHSTEN_TAGE_;
//					if (isset($feld['wvlart'])) {
//						$tspanDropdown .= $form->hidden('wvlart', $feld['wvlart']);
//					}
                    $filterdatum2 .= "$tspanDropdown<!SMfe2> ";

                }
                else {
                    $filterdatum2 .= '<!SMfe2>';
                }

                if ($cfg_modern) {
                    $temp = new Modern_Template_SubMenu();
                    $temp->class='kartei';
                    $temp->kartei_floatleft=true;
                 //$temp->mobile_id='pim_kartei';
                    $temp->wrapper_small=true;
                    $temp->wrapper_wauto=true;
                    $temp->wrapper_nowrap=true;
         
                    $temp->target1="#pimwvlkopf";
                    $temp->targetgesamt="#pimwvlkopfgesamt";
                    $temp->abstand=100;
                    //$temp->setTitle(_KORRP_);
                    $temp->setKarteiString($filt_zus);
                    $temp->setHtml();


                    $temp2 = new Modern_Template_SubMenu();
                    $temp2->filter_marginright=true;
                    $temp2->wrapper_marginbottom=false;
                    $temp2->wrapper_small=true;
                    $temp2->filter_oneline=false;
                    $temp2->setFilterValues(array(
                          array(_KAMPAGNE_, '{filt_kamp}'),
                          array(_ART_,'{filt_art}'),
                         )
                    );
                     $temp2->setFilterString($filterdatum1);
                     $temp2->setFilterString($filterdatum2.'<!SMfe1>'.$form->submit('submit', _AUFTRAG_FILTERDATUMSUBMIT_).'<!SMfe2>');
                     $temp2->setHtml();

                    $extraTitle = '';
                    if (!empty($hbBlock) && $hbBlock === 'wvl') {
                        $extraTitle = $handbuch;
                    }

                    $filter=new Modern_Template_Filter;
                    $filter->filter_display=false;
                    $filter->setTitle2('
                            <table class="table-ignore2 moderntable table-header small table-replace-icons">
                            <tr class="heading" id="pimwvlkopfgesamt">
                            <th class="th" style="border-right:0px;">
                            <div style="float:left" id="pimwvlkopf">'._KORRP_.$extraTitle.'</div>'.$filter->getFilterLink().'
                            </th>
                            <td style="padding:0px;width:10px;border-top:1px solid -P4Nc1-heading_border-P4Nc2-;border-right:1px solid -P4Nc1-heading_border-P4Nc2-">
                            <div style="border-left:1px solid -P4Nc1-body-P4Nc2-;">
                            '.$temp->getHtml().'
                                </div>
                            </td>
                            </tr>
                            </table>');
                     
                    //$filter->setTargetId('TableFilterListe');
                    $filter->setFilterValue(_KAMPAGNE_,'{filt_kamp}');
                    $filter->setFilterValue(_ART_,'{filt_art}');
                    $filter->setFilterString($filterdatum1);
                    $filter->setFilterString($filterdatum2);
       
                    $filter->setSubmit();
                    $filter->setHtml();
                    //Modern_Template_StructureJs::pushFooter('
                       // TableFilterHelper.init("#TableFilterListe","#filter");
                   //');

                    $inhalt=p4n_mb_string('str_replace', '{TableFilterListe}', $filter->getHtml(), $inhalt);

                    $inhalt=p4n_mb_string('str_replace', '{wvl_reiter}', '', $inhalt);
                    $inhalt=p4n_mb_string('str_replace', '{filterdatum}', '', $inhalt);
                }
//				$filt_zus=p4n_mb_string('substr',$filt_zus, 0, -3);
				$inhalt=p4n_mb_string('str_replace', '{wvl_reiter}', '<table width="100%" cellspacing="0" cellpadding="0" class="karten"><tr>'.$filt_zus.'</tr></table>', $inhalt);
				
				// Datumsfilter
                $inhalt=p4n_mb_string('str_replace', '{filterdatum}', $filterdatum1.$filterdatum2, $inhalt);
                if ($_SESSION['crm_version']>99) {
                    asort($stammdaten_korrespondenz, SORT_NATURAL | SORT_FLAG_CASE);
                }
                $inhalt=p4n_mb_string('str_replace', '{filt_art}', (($cfg_modern)?'':'<br>').$form->selectinput('filter_kart', $stammdaten_korrespondenz, $feld['filter_kart'], _ALLE_).(($cfg_modern)?'':$form->submit('submit', _AUFTRAG_FILTERDATUMSUBMIT_)), $inhalt);
                $inhalt=p4n_mb_string('str_replace', '{filt_kamp}', ''.$ksel1.(($cfg_modern)?'':$form->submit('submit', _AUFTRAG_FILTERDATUMSUBMIT_)), $inhalt);
			
                if (isset($_GET['noautotabclick'])) {
                    $_POST['noautotabclick']=$_GET['noautotabclick'];
                }
                $tabs=new Template_Tabs($tab_links,array());
                $tabs->active($tab_links[$aktiv],(isset($_POST['noautotabclick'])?false:true));
                $tabs->addCustomClass('tabs-transparent');
                $tab70=$tabs;
                
//			echo lade_divinhalt('stammdaten_main.php?nav=Uebersicht&kbew=1&id='.$_SESSION['stammdaten_id'], 500, 400, _KERGEBNIS_, true);
			
			$kftext='';
			$ebene=0;
				
				// hier war die Funktion kdatensatz
				
				$ktext='';
				
				$m_awhere=$awhere;
				if ($auch_auto or $auch_erl) {
					$awhere.=' and ('.$sql_tabs['korrespondenz']['aus_workflow'].'='.$db->dblogic(false).' or '.$sql_tabs['korrespondenz']['aus_workflow'].' is null)';
				}
				if ($auch_auto2) {
					$awhere.=' and ('.$sql_tabs['korrespondenz']['wvlkampagne_id'].'=0 or '.$sql_tabs['korrespondenz']['wvlkampagne_id'].' is null)';
				}
				if ($auch_le) {
					$awhere.=' and ('.$sql_tabs['korrespondenz']['lead_id'].'=0 or '.
						$sql_tabs['korrespondenz']['lead_id'].' is null)';
				}
				$m_normal=$awhere;
				
				if ($filterwvl>0) {
                    //$debug->debug('testpim.txt','pim wvlblock andere where');
					$auch_erl=false;
					if ($filterwvl==1) { // leads
						$awhere=$m_awhere.' and '.$sql_tabs['korrespondenz']['lead_id'].'!=0';
						$artkorr=1;
                        if (!$_SESSION['design_70'] || isset($_POST['leadprozess'])) {
                            //$debug->debug('testpim.txt','WHERE1 ausf�hren!');
                            $ktext.=kdatensatz(0, true);
                        } else {
                            //$debug->debug('testpim.txt','WHERE2 ausf�hren!');
                            $ktext70[]=kdatensatz(0, true);
                        }
					} elseif ($filterwvl==2) { //erledigte
						$auch_erl=true;
					} elseif ($filterwvl==3) { //makros
                        if ($carlo_tw) {
                            $awhere=$m_awhere.' and '.$sql_tabs['korrespondenz']['aus_workflow'].'='.$db->dblogic(true).' and '.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(0).' and '.$sql_tabs['korrespondenz']['wvlkampagne_id'].'='.$db->dbzahl(0);
                        } else {
							$awhere=$m_awhere.' and '.$sql_tabs['korrespondenz']['aus_workflow'].'='.$db->dblogic(true);
						}
						$artkorr=2;
                        if (!$_SESSION['design_70'] || isset($_POST['leadprozess']))
						$ktext.=kdatensatz(0, true);
                        else
                        $ktext70[]=kdatensatz(0, true);
					} elseif ($filterwvl==4) { //kamp
                        if ($carlo_tw) {
                            $awhere=$m_awhere.' and '.$sql_tabs['korrespondenz']['wvlkampagne_id'].'>0 and '.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(0);
                        } else {
						$awhere=$m_awhere.' and '.$sql_tabs['korrespondenz']['wvlkampagne_id'].'>0';
                        }
						$artkorr=3;
                        if (!$_SESSION['design_70'] || isset($_POST['leadprozess']))
						$ktext.=kdatensatz(0, true);
                        else
                        $ktext70[]=kdatensatz(0, true);
					} elseif ($filterwvl==5) { // wvl
						$awhere=$m_awhere.' and '.$sql_tabs['korrespondenz']['wvlkampagne_id'].'=0';
						$awhere.=' and '.$sql_tabs['korrespondenz']['aus_workflow'].'=0';
						$awhere.=' and '.$sql_tabs['korrespondenz']['lead_id'].'=0';
						$artkorr=4;
                        if (!$_SESSION['design_70'] || isset($_POST['leadprozess']))
						$ktext.=kdatensatz(0, true);
                        else
                        $ktext70[]=kdatensatz(0, true);
					}
				} else {
                    if ($_SESSION['design_70'] && !isset($_POST['leadprozess'])) {
                             //$debug->debug('testpim.txt','pim wvlblock meine where');
                            $awhere=$m_awhere.' and (('.$sql_tabs['korrespondenz']['lead_id'].'=0) or '; //weil es ja die Lead�bersicht als Widget gibt
                            
                            //Makros
                            if ($carlo_tw) {
                                $awhere.=' ('.$sql_tabs['korrespondenz']['aus_workflow'].'='.$db->dblogic(true).' and '.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(0).' and '.$sql_tabs['korrespondenz']['wvlkampagne_id'].'='.$db->dbzahl(0).') or ';
                            } else {
                                $awhere.=' ('.$sql_tabs['korrespondenz']['aus_workflow'].'='.$db->dblogic(true).') or ';
                            }
                            
                            //Kampagnen
                            if ($carlo_tw) {
                                $awhere.=' ( '.$sql_tabs['korrespondenz']['wvlkampagne_id'].'>0 and '.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(0).') or ';
                            } else {
                                $awhere.=' ('.$sql_tabs['korrespondenz']['wvlkampagne_id'].'>0) or ';
                            }
                            
                            //WVL
                            $awhere.=' (('.$sql_tabs['korrespondenz']['wvlkampagne_id'].'=0 or '.$sql_tabs['korrespondenz']['wvlkampagne_id'].' is null) ';
                            $awhere.=' and ('.$sql_tabs['korrespondenz']['aus_workflow'].'='.$db->dblogic(false).' or '.$sql_tabs['korrespondenz']['aus_workflow'].' is null)';
                            $awhere.=' and ('.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dblogic(false).' or '.$sql_tabs['korrespondenz']['lead_id'].' is null))) ';
  
                            //$awhere=' and '.$sql_tabs['korrespondenz']['betreuer_id'].$where_weitl.' and '.$sql_tabs['korrespondenz']['erledigt'].'=0 '.$m_awhere;
                            $artkorr=0;
                            if (isset($_GET['pagination_korr_1'])) {
                                // $debug->debug('testpim.txt','WHERE ausf�hren!');
                            $ktext70[]=kdatensatz(0,true);
                            }
                            
                    } else {
                        //echo 'hier nicht immer<br>';
                        // aus Lead Engine:
                        if ($auch_le && !$isLeadPimInPim) {
                            $neukblock=(($cfg_modern)?'<tr><th class="th" colspan="6">'._LEADS_.':'.'</th></tr>':$kblock);
                            $neukblock=p4n_mb_string('str_replace', '{k_datum}',_LEADS_.':', $neukblock);
                            $neukblock=p4n_mb_string('str_replace', array("{k_ergebnis}", "{k_produktzuordnungid}", '{k_erledigt}', '{k_art}', '{k_betreff}', '{k_beschreibung}', '{k_stammid}'),'&nbsp;', $neukblock);
                            $ktext.=$neukblock;
                            $temp=array();
                            $temp[][0]=Template_TableCol::init('',new Template_Text(_LEADS_,-1,array('bold')))->setAttribute('colspan', 4);
                            $ktext70[]=$temp;

                            $kftext='';
                            $ebene=0;
                            $anzahl_a=0;
                            $awhere=$m_awhere.' and '.$sql_tabs['korrespondenz']['lead_id'].'!=0';
                            $artkorr=1;
                            if (!$_SESSION['design_70'] || isset($_POST['leadprozess']))
                            $ktext.=kdatensatz();
                            else
                            $ktext70[]=kdatensatz();

                            $neukblock=($cfg_modern)?'':$kblock;
                            $neukblock=p4n_mb_string('str_replace', '{k_datum}', '&nbsp;', $neukblock);
                            $neukblock=p4n_mb_string('str_replace', array("{k_ergebnis}", "{k_produktzuordnungid}", '{k_erledigt}', '{k_art}', '{k_betreff}', '{k_beschreibung}', '{k_stammid}'),'&nbsp;', $neukblock);
                            $ktext.=$neukblock;

                            $kftext='';
                            $ebene=0;
                            $anzahl_a=0;
                            $awhere=$m_normal;
                        }

                        // normale WVL:
                        if ($_SESSION['crm_version']>60) {
                            $neukblock=(($cfg_modern)?'<tr><th class="th" colspan="6">'._WVL_.' ('._EIGENE_.'):'.'</th></tr>':$kblock);
                            $neukblock=p4n_mb_string('str_replace', '{k_datum}',_WVL_.' ('._EIGENE_.'):', $neukblock);
                            $neukblock=p4n_mb_string('str_replace', array("{k_ergebnis}", "{k_produktzuordnungid}", '{k_erledigt}', '{k_art}', '{k_betreff}', '{k_beschreibung}', '{k_stammid}'),'&nbsp;', $neukblock);
                            $ktext.=$neukblock;
                            $temp=array();
                            $temp[][0]=Template_TableCol::init('',new Template_Text(_WVL_.' ('._EIGENE_.')',-1,array('bold')))->setAttribute('colspan', 4);;
                            $ktext70[]=$temp;
                        }
                        $artkorr=4;
                        if (!$_SESSION['design_70'] || isset($_POST['leadprozess']))
                        $ktext.=kdatensatz();
                        else
                        $ktext70[]=kdatensatz();
                        $artkorr=0;

                        if ($kfz_weitere or $_SESSION['cfg_kunde']=='carlo_kurlaender') {
                            $inhalt=preg_replace2('/{block-k-ende}.*<\/table>/Uis', "{block-k-ende}\n</table>".$form->submit('button', _WEITERE_.(intval($kfz_eintraege-$limit)>0?' ('.intval($kfz_eintraege-$limit).')':''), 'onClick="location.href=\''.$phs.'?keinlimit=1&filterdatum_start=\'+this.form.filterdatum_start.value+\'&filterdatum_ende=\'+this.form.filterdatum_ende.value+\'&wfilterdatum_start=\'+this.form.wfilterdatum_startKorr.value+\'&wfilterdatum_ende=\'+this.form.wfilterdatum_endeKorr.value; return false;"').(($cfg_modern)?'':''), $inhalt);
                        }

                        if ($anzahl_a>=3 and !$cfg_pim_ergebnishaken) {
                            $neukblock=$kblock;
                            $neukblock=p4n_mb_string('str_replace', array("{k_ergebnis}", "{k_produktzuordnungid}", '{k_datum}', '{k_art}', '{k_betreff}', '{k_beschreibung}'),'&nbsp;', $neukblock);
                            $neukblock=preg_replace('/\{k_erledigt\}/is', $form->submit2('', _ALLE_, 'onClick="'.$cb_erlfeld.'"'), $neukblock);
                            $neukblock=p4n_mb_string('str_replace', '{k_stammid}',$form->submit('submit', _PIM_ERLEDIGT_), $neukblock);
                            $ktext.=$neukblock;
                        } else {
                            $ktext=preg_replace('/ <input[^>]*>/', '', $ktext);
                        }

                        // alle automatischen:
                        if ($auch_auto) {
                            $neukblock=($cfg_modern)?'<tr><th class="th" colspan="6">'._MAKROS_.':'.'</th></tr>':$kblock;

                            $neukblock=p4n_mb_string('str_replace', '{k_datum}',_MAKROS_.':', $neukblock);
                            $neukblock=p4n_mb_string('str_replace', array("{k_ergebnis}", "{k_produktzuordnungid}", '{k_erledigt}', '{k_art}', '{k_betreff}', '{k_beschreibung}', '{k_stammid}'),'&nbsp;', $neukblock);
                            $ktext.=$neukblock;

                            $temp=array();
                            $temp[][0]=Template_TableCol::init('',new Template_Text(_MAKROS_,-1,array('bold')))->setAttribute('colspan', 4);;
                            $ktext70[]=$temp;

                            $kftext='';
                            $ebene=0;
                            $anzahl_a=0;
                            if ($carlo_tw) {
                                $awhere=$m_awhere.' and '.$sql_tabs['korrespondenz']['aus_workflow'].'='.$db->dblogic(true).' and '.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(0).' and '.$sql_tabs['korrespondenz']['wvlkampagne_id'].'='.$db->dbzahl(0);
                            } else {
                                $awhere=$m_awhere.' and '.$sql_tabs['korrespondenz']['aus_workflow'].'='.$db->dblogic(true);
                            }
                            $artkorr=2;
                            if (!$_SESSION['design_70'] || isset($_POST['leadprozess']))
                            $ktext.=kdatensatz();
                            else
                            $ktext70[]=kdatensatz();
                        }
                        // alle automatischen2:
                        if ($auch_auto2) {
                            $neukblock=($cfg_modern)?'<tr><th class="th" colspan="6">'._KAMPAGNE_.' ('._VORGABE_.')'.':'.'</th></tr>':$kblock;

                            $neukblock=p4n_mb_string('str_replace', '{k_datum}', _KAMPAGNE_.' ('._VORGABE_.')'.':', $neukblock);
                            $neukblock=p4n_mb_string('str_replace', array("{k_ergebnis}", "{k_produktzuordnungid}", '{k_erledigt}', '{k_art}', '{k_betreff}', '{k_beschreibung}', '{k_stammid}'),'&nbsp;', $neukblock);
                            $ktext.=$neukblock;

                            $temp=array();
                            $temp[][0]=Template_TableCol::init('',new Template_Text(_KAMPAGNE_.' ('._VORGABE_.')',-1,array('bold')))->setAttribute('colspan', 4);
                            $ktext70[]=$temp;

                            $kftext='';
                            $ebene=0;
                            $anzahl_a=0;
                            if ($carlo_tw) {
                                $awhere=$m_awhere.' and '.$sql_tabs['korrespondenz']['wvlkampagne_id'].'>0 and '.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(0);
                            } else {
                                $awhere=$m_awhere.' and '.$sql_tabs['korrespondenz']['wvlkampagne_id'].'>0';
                            }
                            $artkorr=3;
                            if (!$_SESSION['design_70'] || isset($_POST['leadprozess']))
                            $ktext.=kdatensatz();
                            else
                            $ktext70[]=kdatensatz();
                        }
                    } // Ende von if ($filterwvl>0) {
                }
                if ($cfg_pim_korralle_keine_erl) {
                    if ($filterwvl==0) {
                        $auch_erl=false;
                    }
                }

                // alle erledigten:
                if ($auch_erl && !($_SESSION['design_70'] && !isset($_POST['leadprozess']) && $filterwvl_temp==0)) {
                   //$debug->debug('testpim.txt','// alle erledigten:');
                    //echo '<br>$auch_erl:'.$auch_erl.' <br>';
                    $neukblock=($cfg_modern)?'<tr><th class="th" colspan="6">{k_datum}</th></tr>':$kblock;

                    $ohne_where=true;

                    // Vorgaben:
                    $vorg=array();
                    $res2=$db->select(
                        $sql_tab['kampagne_vorgabe'],
                        array(
                            $sql_tabs['kampagne_vorgabe']['anzahl_korrespondenz_tag'],
                            $sql_tabs['kampagne_vorgabe']['anzahl_korrespondenz_erledigt_tag'],
                            $sql_tabs['kampagne_vorgabe']['kampagne_id']
                        ),
                        $sql_tabs['kampagne_vorgabe']['benutzer_id'].'='.$db->dbzahl($userid_pim).' or '.$sql_tabs['kampagne_vorgabe']['benutzer_id'].'='.$db->dbzahl(0),
                        $sql_tabs['kampagne_vorgabe']['benutzer_id']
                    );
                    while ($row2=$db->zeile($res2)) {
                        if ($row2[0]>0 or $row2[1]>0) {
                            $vorg[$row2[2]]=array($row2[1], $row2[0]);
                        }
                    }
                    $anz_v1=0;
                    $anz_v2=0;
                    while (list($key2, $val2)=@each($vorg)) {
//					echo $key2.'--'.$val2[0].'/'.$val2[1].'<br>';
                        if (intval($key2)==0) {
                            $anz_v1+=intval($val2[0]);
                            $anz_v2+=intval($val2[1]);
                        } else {
                            $res2=$db->select(
                                $sql_tab['kampagne'],
                                array(
                                    $sql_tabs['kampagne']['kampagne_id'],
                                    $sql_tabs['kampagne']['bezeichnung'],
                                    $sql_tabs['kampagne']['benutzer_gruppen']
                                ),
                                '('.$sql_tabs['kampagne']['beginn'].' is null or '.$sql_tabs['kampagne']['beginn'].'<='.$db->dbtimestamp(time()).') and ('.$sql_tabs['kampagne']['ende'].' is null or '.$sql_tabs['kampagne']['ende'].'>='.$db->dbtimestamp(time()).')'
                            );
                            if ($row2=$db->zeile($res2)) {
                                $anz_v1+=intval($val2[0]);
                                $anz_v2+=intval($val2[1]);
                            }
                        }
                    }

                    $kftext='';
                    $ebene=0;
                    $anzahl_a=0;
                    /*$awhere=$sql_tabs['korrespondenz']['betreuer_id'].'='.$db->dbzahl($userid_pim)
                            .' and '.$sql_tabs['korrespondenz']['erledigt'].'=1 '.
                        ' and (('.$sql_tabs['korrespondenz']['datum'].'>='.$db->dbzeitdatum(adodb_date('d.m.Y'), '00:00:00').
                        ' and '.$sql_tabs['korrespondenz']['datum'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').
                        ') or ('.$sql_tabs['korrespondenz']['wvl_datum1'].'>='.$db->dbzeitdatum(adodb_date('d.m.Y'), '00:00:00').
                        ' and '.$sql_tabs['korrespondenz']['wvl_datum1'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').
                        ') or ('.$sql_tabs['korrespondenz']['ergebnis_datum'].'>='.$db->dbzeitdatum(adodb_date('d.m.Y'), '00:00:00').
                        ' and '.$sql_tabs['korrespondenz']['ergebnis_datum'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').'))';
                    */

                    $startd1=$db->dbzeitdatum(adodb_date('d.m.Y'), '00:00:00');
                    $endd1=$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59');
                    if ($feld['filterdatum_start']!='' and p4n_mb_string('strlen',$feld['filterdatum_start'])==10 && !isset($_POST['leadprozess'])) {
                        $startd1=$db->dbzeitdatum($feld['filterdatum_start'], '00:00:00');
                    }
                    if ($feld['filterdatum_ende']!='' and p4n_mb_string('strlen',$feld['filterdatum_ende'])==10 && !isset($_POST['leadprozess'])) {
                        $endd1=$db->dbzeitdatum($feld['filterdatum_ende'], '23:59:59');
                    }

                    $awhere=$sql_tabs['korrespondenz']['betreuer_id'].$where_weitl
                            .' and '.$sql_tabs['korrespondenz']['erledigt'].'=1 '.
                        ' and (('.$sql_tabs['korrespondenz']['datum'].' between '.$startd1.
                        ' and '.$endd1.
                        ') or ('.$sql_tabs['korrespondenz']['wvl_datum1'].' between '.$startd1.
                        ' and '.$endd1.
                        ') or ('.$sql_tabs['korrespondenz']['ergebnis_datum'].' between '.$startd1.
                        ' and '.$endd1.'))';
                    $me_awhere=$awhere;

                    if (isset($feld['filter_kart']) and intval($feld['filter_kart'])>=0) {
                        $awhere.=' and '.$sql_tabs['korrespondenz']['art'].'='.$db->dbzahl($feld['filter_kart']);
                    }
                    if (isset($feld['filter_kamp']) and intval($feld['filter_kamp'])>=0) {
                        $awhere.=' and '.$sql_tabs['korrespondenz']['kampagne_id'].'='.$db->dbzahl($feld['filter_kamp']);
                    }
                    if (isset($feld['filter_korrkat']) and $feld['filter_korrkat']!='' and $feld['filter_korrkat']!='-1') {
                        $awhere.=' and '.$sql_tabs['korrespondenz']['kategorie'].'='.$db->str($feld['filter_korrkat']);
                    }
                    if ($_SESSION['cfg_kunde']=='carlo_kurlaender') {
                        $awhere.=' and '.$sql_tabs['korrespondenz']['art'].'!='.$db->dbzahl(9);
                    }

                    $vort1='';
                    $vort2='';
                    if ($anz_v1>0 or $anz_v2>0) {
                        if ($ist_standard and $me_awhere==$awhere and $startd1==$db->dbzeitdatum(adodb_date('d.m.Y'), '00:00:00') and $endd1==$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59')) {
                            $anz1_erl=$alle_korrdaten[10];
                        } else {
                            $res2=$db->select(
                                $sql_tab['korrespondenz'],
                                $sql_tabs['korrespondenz']['korrespondenz_id'],
                                $awhere
                            );
                            $anz1_erl=$db->anzahl($res2);
                        }
                        $vort1=$anz1_erl.' / '.$anz_v1.' ';

                        $awhere2=$awhere;
                        $awhere2=p4n_mb_string('str_replace', ' and '.$sql_tabs['korrespondenz']['erledigt'].'=1', '', $awhere2);
                        if ($ist_standard and $me_awhere==$awhere and $startd1==$db->dbzeitdatum(adodb_date('d.m.Y'), '00:00:00') and $endd1==$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59')) {
                            $anz1_unerl=$alle_korrdaten[11];
                        } else {
                            $res2=$db->select(
                                $sql_tab['korrespondenz'],
                                $sql_tabs['korrespondenz']['korrespondenz_id'],
                                $awhere2
                            );
                            $anz1_unerl=$db->anzahl($res2);
                        }
                        $vort2=' '.p4n_mb_string('ucwords', _GESAMT_).': '.$anz1_unerl.' / '.$anz_v2.'';
                    }

                    $artkorr=5;
					if ($zeitdebug) {
						echo 'filter_vwl '.$filterwvl.': '.zeitnahme().'<br>';
					}
                    if ($filterwvl>0) {
                        if (!$_SESSION['design_70'] || isset($_POST['leadprozess']))
                        $ktext_erl=kdatensatz(0, true);
                        else
                        $ktext70[]=kdatensatz(0,true);
                    } else {
                        if (!$_SESSION['design_70'] || isset($_POST['leadprozess']))
                        $ktext_erl=kdatensatz();
                        else
                        $ktext70[]=kdatensatz();
                    }
                    if ($ktext_erl!='') {
                        $neukblock=p4n_mb_string('str_replace', '{k_datum}', p4n_mb_string('ucwords', _ERLEDIGT_).': '.$vort1.' - '.$vort2, $neukblock);
                        $neukblock=p4n_mb_string('str_replace', array("{k_ergebnis}", "{k_produktzuordnungid}", '{k_erledigt}', '{k_art}', '{k_betreff}', '{k_beschreibung}', '{k_stammid}'),'&nbsp;', $neukblock);
                        $ktext.=$neukblock;
                        $ktext.=$ktext_erl;
                    }
                }
                
                // echo 'final $awhere:'.htmlentities($awhere).'<br>';


                if ($_SESSION['design_70'] && !isset($_POST['leadprozess'])) {
                    $temp = array(
                        $lang['_K-DATUM_'].' / '._WVL_,
                        $lang['_K-STAMMID_'],
                        $lang['_K-ART_'].' / '.$lang['_K-BETREFF_'],
                        _ERGEBNIS_,
                    );
                    
                    $temp = array(
                        'F�lligkeit',
                        _KUNDE_,
                        $lang['_K-BETREFF_'].'/'._KATEGORIE_,
                        _KAMPAGNE_.'/'._ART_,
                        _FAHRZEUG_,
                        _BEARBEITER_,
                        _AKTION_
                    );

                    if (!is_array($stammdaten_korrespondenz_filter)) {
                        $stammdaten_korrespondenz_filter=array();
                    }
                    
                    $filter=new Template_Filter();
                    $filter->initPageFilter(array(
                        new Template_SelectInput(_KAMPAGNE_,'filter_kamp', $alle_kamps_man, $_SESSION['pim_kamp1'], _ALLE_),
                        new Template_SelectInput(_ART_,'filter_kart', $stammdaten_korrespondenz_filter, $_SESSION['pim_kart1'], _ALLE_),
                        new Template_ElementList(array(
                            Template_DatumInput::init(_KORRESPONDENZ_.' '.$lang['_K-DATUM_'].' '._VON_.'/'._BIS_,'filterdatum_start',$_SESSION['pim_filterdatum_start']),
                            Template_DatumInput::init('&nbsp;','filterdatum_ende',$_SESSION['pim_filterdatum_ende']
                        )),'','horizontal'),
                        new Template_ElementList(array(
                            Template_DatumInput::init(_WVL_.' - '.$lang['_K-DATUM_'].' '._VON_.'/'._BIS_,'wfilterdatum_start',$_SESSION['pim_wfilterdatum_start']),
                            Template_DatumInput::init('&nbsp;','wfilterdatum_ende',$_SESSION['pim_wfilterdatum_ende']
                        )),'','horizontal'),
                        new Template_SelectInput('Anstelle '._WVL_.' - '.$lang['_K-DATUM_'] . ' ' . $lang['_K-ALTER_'].' '._NAECHSTEN_TAGE_,'wfilter_alter', $ageTypes, $_SESSION['pim_wfilter_alter'], false, 'onchange="onWvlAgeChanged(this)"'),
                    ),'pim.php?pagination_korr_1=1&reset_pagnination=1', 'POST', 'pim_modal_inhalt','');

                    

                    $search = array(
                        'F�lligkeit',
                        _KUNDE_,
                        $lang['_K-BETREFF_'].'/'._KATEGORIE_,
                        _KAMPAGNE_.'/'._ART_,
                        _FAHRZEUG_,
                        _BEARBEITER_
                    );

                    $sort=array(
                        'F�lligkeit',
                    );

                    $priority = array(
                        'F�lligkeit',
                        _KUNDE_,
                        $lang['_K-BETREFF_'].'/'._KATEGORIE_,
                        _AKTION_
                    );

                    $daten=array();
                    $i=1;
                    if (is_array($ktext70)) {
                        foreach($ktext70 as $table_row) {
                            foreach ($table_row as $row) {
                            $daten[$i++]=$row;
                            }
                        }
                    }
                    
                    /*$table=Template_Default::Table($temp,$daten,array('sort'=>$sort,'priority'=>$priority,'multiple'=>true,'size'=>'sm')/*,$filter,$search*//*);
                    $temp=array();
                    $temp[]=$table;
                    if ($filterwvl>0 || ($_SESSION['design_70'] && !isset($_POST['leadprozess']) && $filterwvl==0)) {
                        $temp[]=$pagination;
                    }
                    
                    $card70=Template_Default::Card('','',array($temp),array('border','padding','shadow'),false);
                    */
                    $card70=Template_Default::Table($temp,$daten,$optionsTable=array('sort'=>$sort,'priority'=>$priority,'multiple'=>true),$filter,$search,null,$pagination,$card=true, '', null);
                    
                    if (isset($_GET['pagination_korr_1'])){
                        
                       // $debug->debug('testpim.txt','_KORRESPONDENZEN_ hier starten die kennzahlen (pagination_korr_1) mit exit!');
                        
                        Modern_Helper_Request::requestStart();
                        echo Template_Default::ModalHeader(_KORRESPONDENZEN_)->getHtml();
                        echo $tab70->getHtml();
                        echo $card70->addCustomClass('mb-0')->gethtml();
                        echo Template_Default::cancelModalButton()->getHtml();
                        echo javas($fancyScript);
                        //echo javas('pim_autoheight_();');
                        exit;
                    } else { 
                        //$debug->debug('testpim.txt','_KORRESPONDENZEN_ hier starte das modal (nicht pagination_korr_1) ohne exit geht an inhalt70');
                        $card70=Template_Module::PimKennzahlenCard(_KORRESPONDENZEN_.$extraTitle,Template_IconButton::init('','','','open_in_new','','',$sizeClass = 'sm',  'transparent-black', 'round')
                                ->setRequest('GET',$pim_modal_inhalt,'pim.php','pagination_korr_1=1',array($pim_modal)),null,
                            array(
                                'offene Korrespondenzen'=>$kfz_eintraege2,
                                //'Leads'=>$anz_le,
                                'WVL'=>$nurwvl_eintraege,
                                'Makros'=>$anz_auto,
                                'Kampagnen'=>$anz_auto2,
                                'erledigt' => $anz_erl
                            ),(($user['pim_korrespondenz_view_auswahl']=='graph')?true:false)
                        );
                    }
                    $ktext=$card70->gethtml();
                    
                }
                
                $inhalt70= $ktext;
				
				
				if (($cfg_avag_teilehandel2021 or $cfg_pim_multiroute) and isset($js_multiroute) and $js_multiroute!='') {
					$ktext.=$form->submit2('sub2_alle', 'alle markieren', 'onclick="'.$js_multiroute.'"').' '.$form->submit('sub2_mr', 'zu MultiRoute').((isset($multiroute_link) and $multiroute_link!='')?' | '.link2('MultiRoute', $multiroute_link, '', '', 'target="_blank"'):'');
				}
				
				$inhalt=preg_replace2('/\{block-k-start\}(.*)\{block-k-ende\}/Uis', $ktext, $inhalt);
				$inhalt=p4n_mb_string('str_replace', array('<!wvl1>', '<!wvl2>'), '', $inhalt);
	}
	
	function kdatensatz($parent_id=0, $ohnelimit=false) {
				global $db, $sql_tab, $sql_tabs, $awhere, $sortorder, $kblock, $stammdaten_korrespondenz, $merke_offene, $ol, $kftext, $ebene, $k_art_symbole, $kfz_weitere, $cfg_kfz,$kfz_eintraege,$kfz_eintraege2, $cfg_ordner_kdokumente_pfad, $lang, $form, $anzahl_a, $cb_erlfeld, $gesamt_anzahl, $ohne_where, $limit, $cfg_pim_ergebnishaken, $cfg_kerfolg_balken, $alle_kamps, $alle_kamps2, $alle_kamps3, $where_weitl, $cfg_neustyle, $cfg_pim_kbes_laenge, $cfg_pim_name_abk, $userid_pim,$cfg_modern,$carlo_tw, $zeitdebug, $artkorr, $ist_standard, $pim_keincount, $alle_korrdaten;
				global $dashboard, $bens_pim, $alle_bens2, $alle_bens, $alle_kunden, $alle_leads, $plugin_list, $cfg_pim_eva_anzeigen, $cfg_leadmanagement_2020, $p_cache, $cfg_leadprozess_schlank, $cfg_avag_teilehandel2021, $cfg_multiroute, $js_multiroute, $xu;
				global $pagination,$filterwvl_temp, $cfg_lead_gmac_cb;
                global $pim_modal_inhalt,$pim_modal;
                global $statfeld,$statfeld2;
                global $debug,$user, $stammdaten_korrespondenz_filter;
                global $p_cache_link70,$p_cache_link70_2, $cfg_pim_multiroute;
				global $pim_modal_level2, $pim_modal_level2_inhalt, $cfg_avag_de, $leadzuordnung_eva_mahag;
				
                $ist_vkl = false;
                $res7 = $db->select(
                    $sql_tab['benutzer_gruppe'],
                    array(
                        $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
                        $sql_tabs['benutzer_gruppe']['bezeichnung']
                    ),
                    $sql_tabs['benutzer_gruppe']['bezeichnung'] . ' like ' . $db->str('Verkaufsleiter')
                );
                if ($row7 = $db->zeile($res7)) {
                    if ($_SESSION['rechte_bgruppen'] == '-1' or preg_match('/,' . $row7[0] . ',/', ',' . $_SESSION['rechte_bgruppen'] . ',')) {
                        $ist_vkl = true;
                    }
                }
                
				if ($zeitdebug) {
					echo 'kdatensatz '.$artkorr.' Start ('.htmlentities($awhere.$leadawhere).'): '.zeitnahme().'<br>';
				}
				$leadprozess = isset($_POST['leadprozess']);
                
				$limit=0;
				$kfz_weitere=false;
				if ($cfg_kfz) {
					$limit=5;
					if ($_SESSION['cfg_kunde']=='carlo_kurlaender') {
						$limit=20;
					}
					if ($_GET['keinlimit']=='1') {
						$limit=0;
						if ($_SESSION['cfg_kunde']=='carlo_kurlaender') {
//							$limit=100;
						}
					}
					if ($kfz_eintraege>$limit and !isset($_GET['keinlimit']))
						$kfz_weitere=true;
				} else {
					$limit=10;
					if ($_GET['keinlimit']=='1') {
						$limit=0;
					}
					if ($kfz_eintraege>$limit and !isset($_GET['keinlimit']))
						$kfz_weitere=true;
				}
				if ($ohnelimit) {
					$kfz_weitere=false;
					$limit=500;
				}
				
				$where_eva=' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('EVA-Import');
				if ($cfg_pim_eva_anzeigen || $_SESSION['leadprozess']=='pim_vkl' || $_SESSION['leadprozess']=='pim' || isset($_POST['pim_lead_php'])) {
					$where_eva='';
				}
                $user_role_rights = array();
                if ($cfg_leadmanagement_2020 && $_SESSION['leadprozess']=='pim_vkl') {
                    if (!empty($_SESSION['user_role_rights'])) {
                        $user_role_rights = $_SESSION['user_role_rights'];
                    }
                }
				
                $joins_lead = false;
                $tabelle_leads = array();
                $leadawhere= '';
                global $cfg_mb_nl;
                if ($cfg_mb_nl) {
                    $tabelle_leads = array(1 => $sql_tab['kampagne_lead']);
                    $joins_lead['_LJ_'.$sql_tabs['korrespondenz']['lead_id']]=$sql_tabs['kampagne_lead']['kampagne_lead_id'];
                    
                    $keine_leadbedingung = '('.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(0).' or ('.$sql_tabs['korrespondenz']['lead_id'].'!='.$db->dbzahl(0).' and '.$sql_tabs['kampagne_lead']['leadid'].' like '.$db->str('CRM_%').'))';
                    if (p4n_mb_string('strpos', $awhere, $sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(0))!==false) {
                        $awhere = p4n_mb_string('str_replace', $sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(0), $keine_leadbedingung, $awhere);
                    } elseif (p4n_mb_string('strpos', $awhere, $sql_tabs['korrespondenz']['lead_id'])!==false) {
                        $leadawhere = ' and '.$sql_tabs['kampagne_lead']['leadid'].' not like '.$db->str('CRM_%');
                    }
					$ist_standard=false;
                }

                if ($leadprozess) {
                    $eva_nummer_list = array();
                    $res_eva = $db->select(
                        $sql_tab['stammdaten'],
                        array(
                            $sql_tabs['stammdaten']['id'],
                            $sql_tabs['stammdaten']['meinvpb']
                        ),
                        $db->dbzahlin($alle_kunden, $sql_tabs['stammdaten']['id'])
                    );
                    while ($row_eva = $db->zeile($res_eva)) {
                        $eva_nummer_list[$row_eva[0]] = $row_eva[1];
                    }
                    $pim_keincount=false;
                }

                $currentDateTime = date('Y-m-d H:i:s');
				$ist_vondb=true;
				if ($pim_keincount and $ist_standard and $artkorr>=1 and $artkorr<=5 and $sortorder==$sql_tabs['korrespondenz']['wvl_datum1'].' desc, '.$sql_tabs['korrespondenz']['datum'].' desc') {
                    @reset($alle_korrdaten[$artkorr]);
					if ($artkorr==4) {
						@krsort($alle_korrdaten[$artkorr]);
					}
					$ist_vondb=false;
				} else {

                $betreuer_where = $sql_tabs['korrespondenz']['betreuer_id'].$where_weitl;   
                    
                $sql_kor=array(
                    $sql_tabs['korrespondenz']['korrespondenz_id'],
                    $sql_tabs['korrespondenz']['datum'],
                    $sql_tabs['korrespondenz']['wvl_datum1'],
                    $sql_tabs['korrespondenz']['wvl_datum2'],
                    $sql_tabs['korrespondenz']['ersteller_id'],
                    $sql_tabs['korrespondenz']['betreuer_id'],
                    $sql_tabs['korrespondenz']['eingang'],
                    $sql_tabs['korrespondenz']['art'],
                    $sql_tabs['korrespondenz']['kategorie'],
                    $sql_tabs['korrespondenz']['erledigt'],
                    $sql_tabs['korrespondenz']['parent_id'], // 10
                    $sql_tabs['korrespondenz']['doclink'],
                    $sql_tabs['korrespondenz']['betreff'],
                    $sql_tabs['korrespondenz']['beschreibung'],
                    $sql_tabs['korrespondenz']['produktzuordnung_id'],
                    $sql_tabs['korrespondenz']['papierkorb'],
                    $sql_tabs['korrespondenz']['kalender_id'],
                    $sql_tabs['korrespondenz']['prioritaet'],
                    $sql_tabs['korrespondenz']['negativ'],
                    $sql_tabs['korrespondenz']['stammdaten_id'],
                    $sql_tabs['korrespondenz']['datum2'],		// 20
                    $sql_tabs['korrespondenz']['ergebnis_text'],
                    $sql_tabs['korrespondenz']['ergebnis_datum'],
                    $sql_tabs['korrespondenz']['ergebnis_kategorie'],
                    $sql_tabs['korrespondenz']['kampagne_id'],
                    $sql_tabs['korrespondenz']['wvlkampagne_id'], //25
                    $sql_tabs['korrespondenz']['ansprechpartner_id'],
                    $sql_tabs['korrespondenz']['aus_workflow'],
                    $sql_tabs['korrespondenz']['lead_id'],//28
                    $sql_tabs['korrespondenz']['betreff']//28
                );
                $rechte_ = array();
                if (class_exists('Rights_MenuPoint')) {
                    $menuRights = new Rights_MenuPoint('pim.php');
                    $rechte_ = $menuRights->getConfigurationFromUser($_SESSION['user_id']);
                    $menuRightsVkl = new Rights_MenuPoint('leadprozess_vkl.php');
                    $rechteVkl_ = $menuRightsVkl->getConfigurationFromUser($_SESSION['user_id']);
                }
                $alle_leads_kampagne_lead_status=array();
                
                if ($leadprozess) {
                    $filterActiveCount=0;
                    $where_leadprozess_filter='';
                    
                    if (isset($_POST['filter_phase'])) {
                        $_SESSION['pim_filter_phase'.(isset($_POST['stammdaten_lead_php'])?'1':'').(isset($_POST['pim_lead_php'])?'2':'')]=$_POST['filter_phase'];
                    } elseif (isset($_SESSION['pim_filter_phase'.(isset($_POST['stammdaten_lead_php'])?'1':'').(isset($_POST['pim_lead_php'])?'2':'')])) {
                        $_POST['filter_phase']=$_SESSION['pim_filter_phase'.(isset($_POST['stammdaten_lead_php'])?'1':'').(isset($_POST['pim_lead_php'])?'2':'')];
                    }
                    
                    
                    if (isset($_POST['filter_phase']) && $_POST['filter_phase']!='-1' && $_POST['filter_phase']!='') {
                        $_SESSION['pim_filter_phase'.(isset($_POST['stammdaten_lead_php'])?'1':'').(isset($_POST['pim_lead_php'])?'2':'')]=$_POST['filter_phase'];
                        if (!isset($_POST['just_show_table'])) {
                            if (isset($_SESSION['design_70'])) {
                                $where_leadprozess_filter .= ' and '.$db->dbzahlin($_POST['filter_phase'], $sql_tabs['kampagne_lead_status']['lead_stage']);
                            } else {
                                $where_leadprozess_filter.=' and '.$sql_tabs['kampagne_lead_status']['lead_stage'].'='.$db->dbzahl($_POST['filter_phase']);
                            }
                        $filterActiveCount++;
                        }
                    }
                    $sortorder=$sql_tabs['korrespondenz']['korrespondenz_id'].' desc';
                    
                    $where_leadprozess_alternative=$sql_tabs['kampagne_lead_status']['kampagne_lead_id'].'='.$sql_tabs['kampagne_lead']['kampagne_lead_id'];
                    $sql_kamp=array();
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['lagerort_id'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead_status']['lead_stage'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['status1_time'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['type'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['leadid'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['kampagne_lead_id'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['additionaldata'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['kfzmarke'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['source'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['channel'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['erfassungsdatum'];
					$sql_kamp[]=$sql_tabs['kampagne_lead']['status'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['kamp_kategorie'];
                    $sql_kamp[]=$sql_tabs['kampagne_lead']['kfzmarke'];
                    $sql_kamp[] = $sql_tabs['kampagne_lead']['produktzuordnung_id'] . ' as lead_produktzuordnung_id';
                    
                    if (isset($_POST['leadprozess_id'])) {
                        $where_leadprozess_alternative.=' and '.$sql_tabs['kampagne_lead']['kampagne_lead_id'].'='.$db->dbzahl($_POST['leadprozess_id']);
                    }
                    $leadreiterPost=false;
                    if (isset($_POST['id']) && $_POST['id']>0) {
                        // D70 - Do not query for stid.
                        if (isset($_SESSION['design_70'])) {
                            if (!isset($_POST['pim_lead_php'])) {
                                $betreuer_where = $sql_tabs['korrespondenz']['stammdaten_id'].'='.$db->dbzahl($_POST['id']);
                                $where_leadprozess_alternative.=' and '.$sql_tabs['kampagne_lead']['stammdaten_id'].'='.$db->dbzahl($_POST['id']);
                            }
                        } else {
                            $betreuer_where = $sql_tabs['korrespondenz']['stammdaten_id'].'='.$db->dbzahl($_POST['id']);
                            $where_leadprozess_alternative.=' and '.$sql_tabs['kampagne_lead']['stammdaten_id'].'='.$db->dbzahl($_POST['id']);
                        }
                        $awhere='';
                        $leadreiterPost=true;
                    } elseif ($_SESSION['leadprozess']=='pim_vkl') {
                        if ($_SESSION['pim_and_leadstatus']!=-1) {
                            $where_leadprozess_alternative.=' and '.$db->dbzahlin($_SESSION['pim_and_leadstatus'], $sql_tabs['kampagne_lead_status']['lead_stage']);
                        }
                        if (!empty($_SESSION['pim_lead_datum_start'])) {
                            $where_leadprozess_alternative.=' and '.$sql_tabs['kampagne_lead']['status1_time'].'>='.$db->dbzeitdatum($_SESSION['pim_lead_datum_start'], '00:00:00');
                        }
                        if (!empty($_SESSION['pim_lead_gmac_cb']) && $cfg_lead_gmac_cb) {
                            $where_leadprozess_alternative.=' and '.$sql_tabs['kampagne_lead']['type'].'!='.$db->str('GMAC');
                        }
                        if (!empty($_SESSION['pim_lead_datum_ende'])) {
                            $where_leadprozess_alternative.=' and '.$sql_tabs['kampagne_lead']['status1_time'].'<='.$db->dbzeitdatum($_SESSION['pim_lead_datum_ende'], '23:59:59');
                        }//conditions Flag
						debug_logging('last query 3: '.$db->last_sql());
                        
						if (!empty($_SESSION['leadstatus'])) {
							debug_logging('In leadstatus Session');
                            $where_leadprozess_alternative.=' and '.$sql_tabs['kampagne_lead']['status'].'='.$db->dbzahl($_SESSION['leadstatus']);
                        }
                        if (!empty($rechteVkl_)) {
                                if (isset($rechteVkl_['sort_order_pim_wvl_asc'])) {
                                $sortorder='CASE WHEN '.$sql_tabs['korrespondenz']['wvl_datum1'].' is null or '.$sql_tabs['korrespondenz']['wvl_datum1'].'='.$db->str('0000-00-00').' or '.$sql_tabs['korrespondenz']['wvl_datum1'].'='.$db->str('1970-01-01').' THEN 2 ELSE 1 END, '.$sql_tabs['korrespondenz']['wvl_datum1'].' asc, '.$sql_tabs['korrespondenz']['datum'].' asc';
                            } elseif (isset($rechteVkl_['sort_order_pim_wvl_desc'])) {
                                $sortorder=$sql_tabs['korrespondenz']['wvl_datum1'].' desc, '.$sql_tabs['korrespondenz']['datum'].' desc';
                            } elseif (isset($rechteVkl_['sort_order_pim_date_asc'])) {
                                $sortorder=$sql_tabs['korrespondenz']['datum'].' asc';
                            } elseif (isset($rechteVkl_['sort_order_pim_date_desc'])) {
                                $sortorder=$sql_tabs['korrespondenz']['datum'].' desc';
                            }
                        }
                    } elseif ($_SESSION['leadprozess']=='pim' || isset($_POST['pim_lead_php'])) {
						debug_logging('In leadprozess elseif.  Post: '.print_r($_POST,true));
                        if ($_POST['show_lead']=='link_closed') {
                             $where_leadprozess_alternative.=' and '.$sql_tabs['kampagne_lead']['status'].'='.$db->dbzahl(5);
                            $where_leadprozess.=' and '.$sql_tabs['korrespondenz']['erledigt'].'='.$db->dblogic(1);
                        } elseif ($_POST['show_lead']=='link_edit') {
                            $where_leadprozess_alternative.=' and '.$db->dbzahlin(array(1,2,3,4,5),$sql_tabs['kampagne_lead']['status']);
                            $where_leadprozess.=' and '.$sql_tabs['korrespondenz']['erledigt'].'='.$db->dbzahl(0);
                        } else {
                            if (isset($_SESSION['design_70'], $_POST['pim_lead_php'])) {
                                $where_leadprozess .= ' and '.$sql_tabs['korrespondenz']['erledigt'].'='.$db->dblogic(0);
                            } else {
                                $where_leadprozess .= ' and '.$sql_tabs['korrespondenz']['parent_id'].'='.$db->dbzahl(0).' and '.$sql_tabs['korrespondenz']['erledigt'].'='.$db->dblogic(0);
                            }
                        }
                        if (!empty($rechte_)) {
                            if (isset($rechte_['sort_order_leadpim_wvl_asc'])) {
                                $sortorder='CASE WHEN '.$sql_tabs['korrespondenz']['wvl_datum1'].' is null or '.$sql_tabs['korrespondenz']['wvl_datum1'].'='.$db->str('0000-00-00').' or '.$sql_tabs['korrespondenz']['wvl_datum1'].'='.$db->str('1970-01-01').' THEN 2 ELSE 1 END, '.$sql_tabs['korrespondenz']['wvl_datum1'].' asc, '.$sql_tabs['korrespondenz']['datum'].' asc';
                            } elseif (isset($rechte_['sort_order_leadpim_wvl_desc'])) {
                                $sortorder=$sql_tabs['korrespondenz']['wvl_datum1'].' desc, '.$sql_tabs['korrespondenz']['datum'].' desc';
                            } elseif (isset($rechte_['sort_order_leadpim_date_asc'])) {
                                $sortorder=$sql_tabs['korrespondenz']['datum'].' asc';
                            } elseif (isset($rechte_['sort_order_leadpim_date_desc'])) {
                                $sortorder=$sql_tabs['korrespondenz']['datum'].' desc';
                            }
                        }
                    }
                    if (!$leadreiterPost && !isset($_POST['avagpim_vkchancen'])) {
                        $leadsId=array();
                        $resLeads=$db->select($sql_tab['korrespondenz'],$sql_tabs['korrespondenz']['lead_id'],$sql_tabs['korrespondenz']['lead_id'].'!='.$db->dbzahl(0).' and '.$sql_tabs['korrespondenz']['betreuer_id'].$where_weitl);
                        while ($rowLead=$db->zeile($resLeads)) {
                            $leadsId[$rowLead[0]]=$rowLead[0];
                        }
                        $where_leadprozess_alternative.=' and '.$db->dbzahlin($leadsId,$sql_tabs['kampagne_lead']['kampagne_lead_id']);
                        $betreuer_where='1=1';
                    }
                    if (isset($_POST['leadprozess_lagerort'])) {
                        $where_leadprozess_lag=array();
                        require_once('inc/lib_sn.php');
                        $get_mandanten = get_mandanten(true, 2);
                        $alle_dealer = $get_mandanten[2];
                        foreach ($alle_dealer as $lag => $mand) {
                            if (intval($_POST['leadprozess_lagerort'])==-1 || $_POST['leadprozess_lagerort']==$mand || $_POST['leadprozess_lagerort']==$lag) {
                                $where_leadprozess_lag[$lag]=$lag;
                            }
                        }
                        if (!empty($where_leadprozess_lag)) {
                            $where_leadprozess_alternative.=' and '.$db->dbzahlin($where_leadprozess_lag, $sql_tabs['kampagne_lead']['lagerort_id']);
                        }
                    }
					//The query Flag
					//Session date Flag
                    /*if (!empty($_SESSION['pim_lead_datum_start'])) {
						$where_leadprozess_alternative.=' and '.$sql_tabs['kampagne_lead']['status1_time'].'>='.$db->dbzeitdatum($_SESSION['pim_lead_datum_start'], '00:00:00');
						debug_logging('$where_leadprozess_alternative'.$where_leadprozess_alternative);
					}
					if (!empty($_SESSION['pim_lead_datum_ende'])) {
						$where_leadprozess_alternative.=' and '.$sql_tabs['kampagne_lead']['status1_time'].'<='.$db->dbzeitdatum($_SESSION['pim_lead_datum_ende'], '23:59:59');
					}
					if ($_SESSION['pim_and_leadstatus']!=-1) {
						$where_leadprozess_alternative.=' and '.$db->dbzahlin($_SESSION['pim_and_leadstatus'], $sql_tabs['kampagne_lead_status']['lead_stage']);
					}*/
					if ($zeitdebug) {
						echo 'vor Lead/Kamplead: '.zeitnahme().'<br>';
					}
                    
                    if (isset($_POST['avagpim_vkchancen'])) {
                        include_once('inc/wsdispo.php');
                        $r=avagpim_vkchancen($_SESSION['user_id']);
                        if (isset($_POST['avagpim_vkchancen2'])) {
                            $r=$r[1];
                        } else if (isset($_POST['avagpim_vkchancen3'])) {
                            $r=$r[2];
                        } else {
                            $r=$r[0];
                        }
                        $where_leadprozess_alternative.=' and '.$db->dbzahlin(explode(',',$r),$sql_tabs['kampagne_lead']['kampagne_lead_id']);
                    }

                    // D70 - AVAG - Apply filter for lead status coming from the lead widget links.
                    if ($_SESSION['design_70'] && $cfg_avag_de && isset($_POST['lead_status'])) {
                        $where_leadprozess_alternative .= ' AND ';
                        switch ($_POST['lead_status']) {
                            case _NEU_:
                                $leadStatus = [0];
                                break;
                            case _BM_STATUS3_:
                                $leadStatus = [1, 2, 3, 4, 99, 100, 101];
                                break;
                            case _BM_STATUS4_:
                                $leadStatus = [5];
                                break;
                            default:
                                $leadStatus = [];
                        }
                        $where_leadprozess_alternative .= $db->dbzahlin($leadStatus, $sql_tabs['kampagne_lead']['status']);
                    }
                   
                    $result_kamp_lead = $db->select(
                        array(
                            $sql_tab['kampagne_lead'],
                            $sql_tab['kampagne_lead_status']
                        ),
                        $sql_kamp,
                        $where_leadprozess_alternative.$where_leadprozess_filter
                    );
					if ($zeitdebug) {
						echo 'nach Lead/Kamplead: '.zeitnahme().'<br>';
						echo $db->anzahl($result_kamp_lead).': '.htmlentities($db->last_sql).'<br>'; echo '<br>';
					}
					debug_logging('Select query 2: '.$db->last_sql());
                    while ($row_kamp_lead = $db->zeile($result_kamp_lead)) {
                        $alle_leads_kampagne_lead_status[$row_kamp_lead['kampagne_lead_id']]=$row_kamp_lead;
                    }
                    if (!empty($alle_leads_kampagne_lead_status)) {
                        $where_leadprozess.=' and '.$db->dbzahlin(array_keys($alle_leads_kampagne_lead_status), $sql_tabs['korrespondenz']['lead_id']);
                    } else {
                        $where_leadprozess=' and 1=2';
                    }
                } else {
                    $where_leadprozess.=' and '.$sql_tabs['korrespondenz']['erledigt'].'=0';
                    if (!empty($rechte_)) {
                        if (isset($rechte_['sort_order_pim_wvl_asc'])) {
                            $sortorder='CASE WHEN '.$sql_tabs['korrespondenz']['wvl_datum1'].' is null or '.$sql_tabs['korrespondenz']['wvl_datum1'].'='.$db->str('0000-00-00').' or '.$sql_tabs['korrespondenz']['wvl_datum1'].'='.$db->str('1970-01-01').' THEN 2 ELSE 1 END, '.$sql_tabs['korrespondenz']['wvl_datum1'].' asc, '.$sql_tabs['korrespondenz']['datum'].' asc';
                        } elseif (isset($rechte_['sort_order_pim_wvl_desc'])) {
                            $sortorder=$sql_tabs['korrespondenz']['wvl_datum1'].' desc, '.$sql_tabs['korrespondenz']['datum'].' desc';
                        } elseif (isset($rechte_['sort_order_pim_date_asc'])) {
                            $sortorder=$sql_tabs['korrespondenz']['datum'].' asc';
                        } elseif (isset($rechte_['sort_order_pim_date_desc'])) {
                            $sortorder=$sql_tabs['korrespondenz']['datum'].' desc';
                        }
                    }
                    //$where_leadprozess.=' and '.$sql_tabs['korrespondenz']['art'].'!='.$db->dbzahl(112).' ';
                }
                
                
                if (isset($_SESSION['design_70'])) {
                    if (isset($_POST['sort_column']) && $_POST['sort_order']!='NONE') {
                        switch ($_POST['sort_column']) {
                            case _ID_:
                                $sortorder=$sql_tabs['korrespondenz']['lead_id'].' '.$_POST['sort_order'];
                                break;
                            case _BETREFF_:
                                $sortorder=$sql_tabs['korrespondenz']['betreff'].' '.$_POST['sort_order'];
                                break;
                            case _BESCHREIBUNG_:
                                $sortorder=$sql_tabs['korrespondenz']['beschreibung'].' '.$_POST['sort_order'];
                                break;
                            case _KAMPAGNE_:
                                $sortorder=$sql_tabs['korrespondenz']['kampagne_id'].' '.$_POST['sort_order'];
                                break;
                            case _KATEGORIE_:
                                $sortorder=$sql_tabs['korrespondenz']['kategorie'].' '.$_POST['sort_order'];
                                break;
                            case _BETREUER_:
                                $sortorder=$sql_tabs['korrespondenz']['betreuer_id'].' '.$_POST['sort_order'];
                                break;
                            case _ART_:
                                $sortorder=$sql_tabs['korrespondenz']['art'].' '.$_POST['sort_order'];
                                break;
                            case _TRVKUNDENNAME_:
                                $sortorder=$sql_tabs['korrespondenz']['stammdaten_id'].' '.$_POST['sort_order'];
                                break;
                        }
                    }
                }
          
                $sammle_korr=array();
                

				$sqlt_tabs=array($sql_tab['korrespondenz']);
				
				$where_th='';
				if ($cfg_avag_teilehandel2021 or $cfg_pim_multiroute) {
					$sqlt_tabs[]=$sql_tab['stammdaten_adresse'];
					$sql_kor[]=$sql_tabs['stammdaten_adresse']['adresse'];
					$sql_kor[]=$sql_tabs['stammdaten_adresse']['plz'];
					$sql_kor[]=$sql_tabs['stammdaten_adresse']['ort'];
				//	$where_leadprozess.=' and '.$sql_tabs['korrespondenz']['stammdaten_id'].'='.$sql_tabs['stammdaten_adresse']['stammdaten_id'];
					$where_th.=' and '.$sql_tabs['korrespondenz']['stammdaten_id'].'='.$sql_tabs['stammdaten_adresse']['stammdaten_id'];
				}
				
         		if ($db->treiber=='mysql' and $sortorder==$sql_tabs['korrespondenz']['datum'].' desc') {
					$sortorder='CAST('.$sql_tabs['korrespondenz']['datum'].' as DATETIME) desc';
				}
         		if ($db->treiber=='mysql' and $sortorder==$sql_tabs['korrespondenz']['datum'].' asc') {
					$sortorder='CAST('.$sql_tabs['korrespondenz']['datum'].' as DATETIME) asc';
				}
				if ($db->treiber=='mysql' and $sortorder==$sql_tabs['korrespondenz']['korrespondenz_id'].' desc') {
					$sortorder='CAST('.$sql_tabs['korrespondenz']['korrespondenz_id'].' as UNSIGNED) desc';	// INTEGER
				}
                $artkorr_anzahl=0;
                
                //$debug->debug('testpim.txt','isset($_POST[leadprozess]):'.isset($_POST['leadprozess']).', isset($_POST[stammdaten_lead_php])'.isset($_POST['stammdaten_lead_php']));
               // $debug->debug('testpim.txt','isset($_POST[pim_lead_php]):'.isset($_POST['pim_lead_php']).', $filterwvl_temp:'.$filterwvl_temp);
               // $debug->debug('testpim.txt','isset($_POST[leadprozess_id]):'.isset($_POST['leadprozess_id']));
                
               
                if ($_SESSION['design_70'] && !isset($_POST['leadprozess']) && isset($_GET['pagination_korr_1'])) {
                    
                  //echo 'ja <br>';
                  //echo '$ohne_where:'.$ohne_where.'<br>';
                  //echo htmlentities(($ohne_where?'':'(('.$betreuer_where.'))'.$where_leadprozess).$awhere.$leadawhere.$where_eva).'<br>';
                    $pagination=new Template_Pagination('widget_pagination_korr_1',5);
                    $res=$db->select($sqlt_tabs+$tabelle_leads,
					'count('.$sql_tabs['korrespondenz']['korrespondenz_id'].')',
					($ohne_where?'':'(('.$betreuer_where.'))'.$where_leadprozess)
					//.' and '.$sql_tabs['korrespondenz']['parent_id'].'='.$parent_id
					.$awhere.$leadawhere.$where_eva.(($_SESSION['design_70'] && !isset($_POST['leadprozess']) && $filterwvl_temp==0 && 1==2)?'':' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('TKP Termin')
						.' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('WPS Termin')
						.' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('WS Termin')
						.' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('Workshop')),
                       // .' and ('.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(7133).' OR '.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(7132).' OR '.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(7131).')',
					$sortorder,
					'',
					$joins_lead
                    );
                    if ($row=$db->zeile($res)) {
                        $artkorr_anzahl=$row[0];
                    }

                    
                   // $debug->debug('testpim.txt','COUNT ABFRAGE '.htmlentities($db->last_sql));
                   // echo $artkorr_anzahl; 
                    //exit;
                }
                
                if ($_SESSION['design_70'] && (isset($_POST['stammdaten_lead_php']) || isset($_POST['pim_lead_php']))) {
                    $pagination=new Template_Pagination('pagination_stammdaten_lead'.(isset($_POST['stammdaten_lead_php'])?'1':'').(isset($_POST['pim_lead_php'])?'2':''),5);
                }
                
                if (isset($_GET['reset_pagnination'])) {
                    $pagination->clear();
                }
                
                //extra data sort helper
                $idsExpected='';
                if (isset($_POST['leadprozess'])) {
					$sortorder_lp=$sql_tabs['korrespondenz']['korrespondenz_id'].' desc';
					if ($db->treiber=='mysql') {
						$sortorder_lp='CAST('.$sql_tabs['korrespondenz']['korrespondenz_id'].' as UNSIGNED) desc';	// INTEGER
					}
                    $resSort=$db->select(
                        $sqlt_tabs+$tabelle_leads,
                        $sql_kor,
                        ($ohne_where?'':'(('.$betreuer_where.'))'.$where_leadprozess)
    /*					.' and '.$sql_tabs['korrespondenz']['parent_id'].'='.$parent_id
    */					.$awhere.$leadawhere.$where_eva.' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('TKP Termin')
                            .' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('WPS Termin')
                            .' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('WS Termin')
                            .' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('Workshop').$where_th,
                           // .' and ('.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(7133).' OR '.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(7132).' OR '.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(7131).')',
                        $sortorder_lp,
                        '',
                        $joins_lead,
                        (isset($_POST['pim_lead_php'])?0:(($_SESSION['design_70'] && !isset($_POST['leadprozess']) && isset($_GET['pagination_korr_1']))?$pagination->limit():$limit)),
                        (isset($_POST['pim_lead_php'])?0:(($_SESSION['design_70'] && !isset($_POST['leadprozess']) && isset($_GET['pagination_korr_1']))?$pagination->von():0))   
                    );
                    $leadFound=array();
                    //get last korrespondenz for lead
                    while ($rowSort=$db->zeile($resSort)) {
                        if (!isset($leadFound[$rowSort['lead_id']])) {
                            $leadFound[$rowSort['lead_id']]=$rowSort['korrespondenz_id'];
                        }
                    }
                    if (!empty($leadFound)) {
                        $idsExpected=' and '.$db->dbzahlin($leadFound,$sql_tabs['korrespondenz']['korrespondenz_id']);
                    }
                }
                
                if (isset($_POST['avagpim_vkchancen'])) {
                    include_once('inc/wsdispo.php');
                    $r=avagpim_vkchancen($_SESSION['user_id']);

                    $res=$db->select(
                        $sqlt_tabs+$tabelle_leads,
                        $sql_kor,
                        $db->dbzahlin(array_keys($alle_leads_kampagne_lead_status), $sql_tabs['korrespondenz']['lead_id']),
                           // .' and ('.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(7133).' OR '.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(7132).' OR '.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(7131).')',
                        $sortorder,
                        '',
                        $joins_lead,
                        (isset($_POST['pim_lead_php'])?0:(($_SESSION['design_70'] && !isset($_POST['leadprozess']) && isset($_GET['pagination_korr_1']))?$pagination->limit():$limit)),
                        (isset($_POST['pim_lead_php'])?0:(($_SESSION['design_70'] && !isset($_POST['leadprozess']) && isset($_GET['pagination_korr_1']))?$pagination->von():0))  
                    );
                } else {
                    if (isset($_POST['initialLoad'])) {
                        $_POST['wfilterdatum_ende'] = date('d.m.Y');
                    }
                    
                    if (
                        isset($_POST['wfilterdatum_start']) &&
                        $_POST['wfilterdatum_start']
                    ) {
                        $awhere .= ' AND '.$sql_tabs['korrespondenz']['wvl_datum1'].'>='.$db->dbzeitdatum($_POST['wfilterdatum_start'], '00:00:00');
                    }
                    
                    if (
                        isset($_POST['wfilterdatum_ende']) &&
                        $_POST['wfilterdatum_ende']
                    ) {
                        $awhere .= ' AND '.$sql_tabs['korrespondenz']['wvl_datum1'].'<='.$db->dbzeitdatum($_POST['wfilterdatum_ende'], '23:59:59');
                    }
                    $res=$db->select(
                        $sqlt_tabs+$tabelle_leads,
                        $sql_kor,
                        ($ohne_where?'':'(('.$betreuer_where.'))'.$where_leadprozess)
    /*					.' and '.$sql_tabs['korrespondenz']['parent_id'].'='.$parent_id
    */					.$awhere.$leadawhere.$where_eva.' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('TKP Termin')
                            .' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('WPS Termin')
                            .' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('WS Termin')
                            .' and '.$sql_tabs['korrespondenz']['kategorie'].'!='.$db->str('Workshop').$where_th.$idsExpected,
                           // .' and ('.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(7133).' OR '.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(7132).' OR '.$sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl(7131).')',
                        $sortorder,
                        '',
                        $joins_lead,
                        (isset($_POST['pim_lead_php'])?0:(($_SESSION['design_70'] && !isset($_POST['leadprozess']) && isset($_GET['pagination_korr_1']))?$pagination->limit():$limit)),
                        (isset($_POST['pim_lead_php'])?0:(($_SESSION['design_70'] && !isset($_POST['leadprozess']) && isset($_GET['pagination_korr_1']))?$pagination->von():0))  
                    );
                }
               // $debug->debug('testpim.txt','nochmal:? '."\n".htmlentities($db->last_sql));
                
                //$debug->debug('testpim.txt','Limit: '.(isset($_POST['pim_lead_php'])?0:(($_SESSION['design_70'] && !isset($_POST['leadprozess']) && isset($_GET['pagination_korr_1']))?$pagination->limit():$limit)));
                
				debug_logging('where_leadprozess query 2: '.$db->last_sql());
                
                }
				
            	if ($_SESSION['cfg_kunde']=='carlo_opel_aov_bundk') {
					if ($fp3=fopen('_log_pim_'.$_SESSION['user_id'].'.txt', 'a')) {
						fwrite($fp3, adodb_date('d.m.Y H:i:s', time()).': '.$db->anzahl($res).' - '.$db->last_sql."\r\n");
						fclose($fp3);
					}
				}
                
                if (!isset($anzahl_a)) {
					$anzahl_a=0;
				}
				$gesamtkblock='';
				unset($row);
				$abbruch=false;

                $kamp_infos = array();
                $x=0;
                //$dtNow = new DateTime();
                $alle_leads_speicher = array();
                
                $table_data=array();
                $table_data_pim=array();
                
                $aendern_modal_inhalt = new Template_ElementList('', 'pim_aendern_modal_inhalt');
                $aendern_modal = new Template_Modal('pim_aendern_modal', null, $aendern_modal_inhalt,null,'',false,false, null, 'tab_lead');
                $aendern_modal->setRight();

                include_once('inc/class_bdc_email.php');
                $bdc_mail=new bdcMail();
                $pagination_anzahl=0;
                //check
                $korrExtraControl=array();
                $pim_kennzahl_status=array();
                foreach ($statfeld as $val_kzs) {
                    $pim_kennzahl_status[$val_kzs]=0;
                }
                
                $rechte__lead = array();
                if (class_exists('Rights_MenuPoint')) {
                    $menuRights = new Rights_MenuPoint('stammdaten_main.php?nav=lead');
                    $rechte__lead = $menuRights->getConfigurationFromUser($_SESSION['user_id']);
                }
                global $benutzer_to_see;
                while (!$abbruch and ($ist_vondb?$row=$db->zeile($res):(list($cakey, $row)=@each($alle_korrdaten[$artkorr])))) { //Startwhile Flag
                    if (!$leadreiterPost && !in_array($row[5],$benutzer_to_see) && !isset($_POST['avagpim_vkchancen'])) {
                        continue;
                    }
                    $cols_view = $cols_detail = array();
                    $cols_view_pim = array();
                    //echo '<br>test '.$row['lead_id'].' - '.$row['korrespondenz_id'].' - '.$row[2].' st: '.$row['stammdaten_id'].' el: '.$row['erledigt'];
                    if (!empty($alle_leads_kampagne_lead_status[$row[28]]) && !isset($_POST['avagpim_vkchancen'])) {
                        foreach ($alle_leads_kampagne_lead_status[$row[28]] as $result_key => $row_value_neu) {
                            if (is_numeric($result_key) || isset($row[$result_key])) {
                                continue;
                            }
                            $row[$result_key]=$row_value_neu;
                        }
                    }
                    
                    if (!empty($row['lead_stage'])) {
                        $catList = Plugin_System_LeadTracker::getLeadCategoryList();
                        $leadStatus70=@$catList[$row['lead_stage']];
                    }
                    
                    
                    $pim_kennzahl_status[$statfeld[$alle_leads_kampagne_lead_status[$row['lead_id']]['status']]]++;

                    $additional=$bdc_mail->extractAdditionalDataString($row['additionaldata']);

                    if ($limit!=0 and $anzahl_a>$limit-1) {
						$abbruch=true;
						continue;
					}
                    
					if ($leadprozess && $row[28]>0) {
                        if (isset($alle_leads_speicher[$row[28]])) {
                            continue;
                        }
                        $alle_leads_speicher[$row[28]]=1;
                        $prove_art = ($row['type']!='') ? $row['type'] : -1;
                        if (!empty($user_role_rights['sparten_zuordnung']) && !isset($_POST['avagpim_vkchancen'])) {
                            if (!in_array($prove_art, $user_role_rights['sparten_zuordnung'])) {
                                continue;
                            }
                        }
                        $prove_channel = ($row['channel']!='') ? $row['channel'] : -1;
                        if (!empty($user_role_rights['kanal_zuordnung']) && !isset($_POST['avagpim_vkchancen'])) {
                            if (!in_array($prove_channel, $user_role_rights['kanal_zuordnung'])) {
                                continue;
                            }
                        }
                        $prove_source = ($row['source']!='') ? $row['source'] : -1;
                        if (!empty($user_role_rights['quelle_zuordnung']) && !isset($_POST['avagpim_vkchancen'])) {
                            if (!in_array($prove_source, $user_role_rights['quelle_zuordnung'])) {
                                continue;
                            }
                        }
                        $prove_marke = ($row['kfzmarke']!='') ? $row['kfzmarke'] : -1;
                        if (!empty($user_role_rights['marken_zuordnung']) && !isset($_POST['avagpim_vkchancen'])) {
                            if (!in_array($prove_marke, $user_role_rights['marken_zuordnung'])) {
                                continue;
                            }
                        }
                        
                    }
                    $pagination_anzahl++;
                    
                    if ($_SESSION['design_70'] && (isset($_POST['stammdaten_lead_php']) || isset($_POST['pim_lead_php']))) {
                        if (!$pagination->cancelWhile()) {
                            continue;
                        }
                    }
                    

					if ($_SESSION['cfg_kunde']=='carlo_opel_aov_bundk') {
						if ($fp3=fopen('_log_pim_'.$_SESSION['user_id'].'.txt', 'a')) {
							fwrite($fp3, adodb_date('d.m.Y H:i:s', time()).' '.$anzahl_a.': '.print_r($row, true)."\r\n");
							fclose($fp3);
						}
					}
					
					$zustext = $color = '';
					
					// Kampagneninfos:
                    $kamp_info = $kampagnen_kategorie_name = '';
                    if (intval($row[24])>0 or intval($row[25])>0) {
						if (intval($row[24])>0) {
						if (!isset($kamp_infos[$row[24]])) {
							$res2=$db->select(
								$sql_tab['kampagne'],
								array(
									$sql_tabs['kampagne']['beginn'],
									$sql_tabs['kampagne']['ende'],
									$sql_tabs['kampagne']['bezeichnung'],
									$sql_tabs['kampagne']['beschreibung'],
									$sql_tabs['kampagne']['datei1'],
									$sql_tabs['kampagne']['datei2'],
									$sql_tabs['kampagne']['datei3'],
                                    $sql_tabs['kampagne']['kategorie']
								),
								$sql_tabs['kampagne']['kampagne_id'].'='.$db->dbzahl($row[24])
							);
							$row2=$db->zeile($res2);
							$k_olt='<br>'._DAUER_.': '.$db->unixdate($row2[0]).' - '.$db->unixdate($row2[1]).'<br><br>';
                            $alle_kamps3[$row[24]] = $row2[7];
							$alle_kamps_endungen[$row[24]] = $row2[1];
							$alle_kamps_kategorien[$row[24]] = $row2[7];
							
							if ($row2[3]!='') {
								$k_olt.=$row2[3].'<br><br>';
							}
							$k_js='';
							for ($di=0; $di<3; $di++) {
								if ($row2[$di+4]!='') {
									$k_olt.=_DATEI_.': '.p4n_mb_string('substr',$row2[$di+4], 37).'<br>';
									$k_js.='window.open(\''.'dokumente/'.$row2[$di+4].'\', \'_blank\'); ';
								}
							}
							$js_extr='';
							if ($k_js!='') {
								$js_extr='onClick="'.$k_js.'"';
							}
                            $link_temp = '#';
                            if ($row[24] > 0 && $_SESSION['crm_version']>60) {
                                $link_temp = 'stammdaten_main.php?nav=Korrespondenz&id=x&filter_kamp='.$row[24];	// '.$row[19].' x
                                $link_temp70= 'stammdaten_main.php?nav=Korrespondenz&id='.$row[19].'&filter_kamp='.$row[24];// x '.$row[19].'
                            }
                            $kamp_infos[$row[24]]=oltext($k_olt, '<img src="bilder/kampagne.gif">', $link_temp, _KAMPAGNE_.': '.$row2[2], 300, $js_extr);
                            $kamp_infos70[]=new Template_Tooltip($k_olt, new Template_Icon('mdi-bullhorn'), $link_temp70, _KAMPAGNE_.': '.$row2[2], 300, $js_extr);
                            $alle_kamps[$row[24]] = $row2[2];
						}
						}
                        if (intval($row[25])>0) {
							if (!isset($alle_kamps2[$row[25]])) {
							$res2=$db->select(
								$sql_tab['wvlkampagne'],
								array(
									$sql_tabs['wvlkampagne']['bezeichnung'],
									$sql_tabs['wvlkampagne']['beschreibung']
								),
								$sql_tabs['wvlkampagne']['kampagne_id'].'='.$db->dbzahl($row[25])
							);
							$row2=$db->zeile($res2);
							$k_olt='<br>'._DAUER_.': '.$db->unixdate($row2[0]).' - '.$db->unixdate($row2[1]).'<br><br>';
							if ($row2[3]!='') {
								$k_olt.=$row2[3].'<br><br>';
							}
                            $link_temp = '#';
                            if ($row[25] > 0 && $_SESSION['crm_version']>60) {
                                $link_temp = 'stammdaten_main.php?nav=Korrespondenz&id=x&filter_kamp='.$row[25];// x '.$row[19].'
                                $link_temp70= 'stammdaten_main.php?nav=Korrespondenz&id='.$row[19].'&filter_kamp='.$row[25];// x '.$row[19].'
                            }
							$alle_kamps2[$row[25]]=oltext($k_olt, '<img src="bilder/kampagne.gif">', $link_temp, _KAMPAGNE_.': '.$row2[2], 300, $js_extr);
                            $alle_kamps270[$row[25]]=new Template_Tooltip($k_olt, new Template_Icon('help'), $link_temp70, _KAMPAGNE_.': '.$row2[2], 300, $js_extr);
						}
						}
						
						if (intval($row[24])>0 and intval($row[25])>0) {
							$kamp_info=$kamp_infos[$row[24]].' ';
                            $kamp_info70=$kamp_infos70[$row[24]];
							$kamp_info=p4n_mb_string('str_replace', 'id=x', 'id='.$row[19], $kamp_info);
						} elseif (intval($row[24])>0) {
							$kamp_info=$kamp_infos[$row[24]].' ';
                            $kamp_info70=$kamp_infos70[$row[24]];
							$kamp_info=p4n_mb_string('str_replace', 'id=x', 'id='.$row[19], $kamp_info);
						} elseif (intval($row[25])>0) {
							$kamp_info=$alle_kamps2[$row[25]].' ';
                            $kamp_info70=$alle_kamps270[$row[25]];
							$kamp_info=p4n_mb_string('str_replace', 'id=x', 'id='.$row[19], $kamp_info);
						}
                        $kampagnen_kategorie_name = $alle_kamps3[$row[24]];
					}
                    
                    $anzz=count($row);
					for ($ri=0; $ri<$anzz; $ri++) {
						if ($row[$ri]=='') {
							$row[$ri]='&nbsp;';
                        }
                    }
					$neukblock=$kblock;
                    $neukblock=p4n_mb_string('str_replace', "{oddeven}",'class="'.($x%2?'even':'odd').'"', $neukblock);
                    $x++;
					if ($row[18]==1)
						$neukblock=p4n_mb_string('str_replace', "normal", 'normalrot', $neukblock);
					$dazu='';
					if ($ebene>0) {
						$dazu=str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;',$ebene-1).'<img src="bilder/pfeil_down.gif" border=0>';
					} else
						$dazu='&nbsp;';
					$neukblock=p4n_mb_string('str_replace', "{k_nummer}",$dazu, $neukblock);
					$kdatum=$db->unixdatetime($row[1]);
                    $kdatum70=$db->unixdatetime($row[1]);
                    $kwvl70='';
/*					if ($row[20]!=0) {
						$kdatum.=' - '.$db->unixdatetime($row[20]);
					}
*/					if ($row[2] != 0 && $row['erledigt']!=1) {
						$kdatum .= ($leadprozess ? ' / ' : '<br><font size=1 color=green>').''._WVL_.': '.$db->unixdatetime($row[2]);
                        $kwvl70=$db->unixdatetime($row[2]);
						if ($row[3] != 0) {
							$kdatum .= ' - '.$db->unixdatetime($row[3]);
                            $kwvl70.=' - '.$db->unixdatetime($row[3]);
						}
						$kdatum .= ($leadprozess ? '' : '</font>');
						if ($currentDateTime > $row[2]) {
                            $color = '#E07C7C';
                        }
					}
					if ((empty($row[2]) || $row[2] === '&nbsp;') && (empty($row[3]) || $row[3] === '&nbsp;')) {
						$kwvl70 = $db->unixdatetime($row['datum']) ?: '-';
					}
				
					$neukblock=p4n_mb_string('str_replace', "{k_datum}",$kamp_info.$kdatum, $neukblock);
                    //$cols_view_pim[0][]=$kdatum70;
                    $cols_view_pim[0][0]=new Template_Text($kwvl70,-1,array('bold'));
                    $cols_view_pim[0][1]='&nbsp;';
        
                    //$cols_view_pim[3][0]=($kamp_info70!=''?$kamp_info70:'&nbsp;');
                    //$cols_view_pim[2][1]=$kampagnen_kategorie_name;
                    
                    
                  //  $cols_view[4]=$kdatum70;
                   // $cols_view[5]=$kwvl70;
                    
                    $cols_detail[2][0]=new Template_Label(_DATUM_,$kdatum70);
                    $cols_detail[2][1]=new Template_Label(_WVL_,$kwvl70);
                    					
					$st_id=$row[19];
					if (!isset($kubez[$row[19]])) {
						$kubez[$row[19]]=kundenbezeichnung($row[19]);
					}
					$st_zeige1=$kubez[$row[19]];
					if (isset($cfg_pim_name_abk)) {
						if (intval($cfg_pim_name_abk)>1) {
							$st_zeige1=abkuerzung($st_zeige1, $cfg_pim_name_abk);
						}
					}
					
					if ($st_zeige1=='0') {
						$anzeige_stid='-';
					} else {
                        $nav='Uebersicht';
                        if (isset($_POST['navto']) && $row[28]>0) {
                            $leadprozess_lead_id='&lead='.$row[28];
                            $nav=$_POST['navto'];
                        }

						$anzeige_stid=linkToTab($st_zeige1, 'stammdaten_main.php?nav='.$nav.'&id='.$st_id.$leadprozess_lead_id, '', '', 'target="main"', 1);
                        if (isset($_POST['stammdaten_lead_php'])) {
                            $anzeige_stid70=$st_zeige1;
                        } else {
                            $anzeige_stid70=linkToTab70($st_zeige1, 'stammdaten_main.php?nav='.$nav.'&id='.$st_id.$leadprozess_lead_id, '', '', 'target="main"', 1);
                        }
                        
						$anzeige_stid=($leadprozess ? '' : link2($st_zeige1, 'javascript: lade_in_message(\''.'stammdaten_main.php?id='.$st_id.'&nav='.$nav.'&druckoptimierung=1&kurzk='.$row[7].'\', 900, 500);', 'datensatz.png').' ').$anzeige_stid;
						$anzeige_stid_link=link2($st_zeige1, 'javascript: lade_in_message(\''.'stammdaten_main.php?id='.$st_id.'&nav='.$nav.'&druckoptimierung=1&kurzk='.$row[7].'\', 900, 500);', 'datensatz.png');
                        $anzeige_stid_link70=new Template_Link('', 'javascript: lade_in_message(\''.'stammdaten_main.php?id='.$st_id.'&nav='.$nav.'&druckoptimierung=1&kurzk='.$row[7].'\', 900, 500);', 'person');
                        
                        
                        if ($leadprozess) {
                            if (!empty($eva_nummer_list[$row[19]])) {
                                $anzeige_stid .= ' (<b>Eva Nummer:</b> '.$eva_nummer_list[$row[19]].')';
                            }
                        }
					}
					if (($cfg_avag_teilehandel2021 or $cfg_pim_multiroute) and intval($st_id)>0) {
						if ($cfg_multiroute) {
							if (!isset($xu)) {
								$xu=1;
							} else {
								$xu++;
							}
							$anzeige_stid=$form->checkinput('multiroute['.$st_id.'_'.$xu.']').' '.$anzeige_stid;
							$js_multiroute.=' if (!this.form.elements[\'multiroute['.$st_id.'_'.$xu.']\'].checked) { this.form.elements[\'multiroute['.$st_id.'_'.$xu.']\'].click(); } ';
						}
						if (isset($row['adresse'])) {
							$adr_anz=trim($row['adresse'].', '.$row['plz'].' '.$row['ort']);
							if ($adr_anz!=',') {
								$anzeige_stid.='<br>'.$adr_anz;
							}
						}
					}
					if (intval($row[26])>0) {
						$anzeige_stid.='<br><font size=1>'.apbezeichnung($row[26]).'</font>';
					}
                    //$db->setfetchmodeP4n(2);
                    if ($leadprozess)
                    $row[14]=$row['lead_produktzuordnung_id'];
					if (is_numeric($row[14]) and !isset($p_cache[$row[14]])) {
                        if ($row[14]>0) {
                            if ($cfg_kfz) {
                                $res2=$db->select($sql_tab['produktzuordnung'],
                                    array(
                                        $sql_tabs['produktzuordnung']['produktzuordnung_id'],//0
                                        $sql_tabs['produktzuordnung']['kennzeichen'],//1
                                        $sql_tabs['produktzuordnung']['typ_modell'],//2
                                        $sql_tabs['produktzuordnung']['datum_ez'],//3
                                        $sql_tabs['produktzuordnung']['fahrgestell'],//4
                                        $sql_tabs['produktzuordnung']['stammdaten_id'],//5
                                        $sql_tabs['produktzuordnung']['markencode'],//6
                                        $sql_tabs['produktzuordnung']['typ']//7
                                    ),
                                    $sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($row[14]).' and '.
                                    $sql_tabs['produktzuordnung']['produktzuordnung_id'].'>'.$db->dbzahl(0)
                                );
                                if ($row2=$db->zeile($res2)) {
                                    $p_cache[$row[14]]=link2(($leadprozess ? $row2[6] : '<font size=1>'.$row2[1]).' / '.produktbezeichnung($row2[2], $row2[4], $row2[0]).'<br>('._KFZ_EZ_.': '.$db->unixdate($row2[3]).')'.($leadprozess ? '' : '</font>'), $phs.'?pnr='.$row2[0], '', '', 'id=1');
                                    if ($_SESSION['cfg_kunde']=='carlo_koltes') {
                                        $p_cache_link[$row[14]]=link2(($leadprozess ? $row2[6] : '<font size=1>'.$row2[1]).' / '.produktbezeichnung($row2[2], $row2[4], $row2[0]).($leadprozess ? '' : '</font>'), $phs.'fahrzeug_pflege.php?produktzuordnung_id='.$row[14], '', '', 'id=1');
                                        $p_cache_link70[$row[14]]=new Template_link(($leadprozess ? $row2[6]:''), 'fahrzeug_pflege.php?produktzuordnung_id='.$row[14], 'mdi-car', '', 'id=1');
                                        $p_cache_link70_2[$row[14]]=new Template_Tooltip($row2[6],new Template_link('', 'fahrzeug_pflege.php?produktzuordnung_id='.$row[14], 'mdi-car', '', 'id=1 target="main"'));
                                    } else {
                                        $p_cache_link[$row[14]]=link2(($leadprozess ? $row2[6] : '<font size=1>'.$row2[1]).' / '.produktbezeichnung($row2[2], $row2[4], $row2[0]).($leadprozess ? '' : '</font>'), $phs.'stammdaten_main.php?nav=Fahrzeuge'.(intval($row2[5])>0?'&id='.$row2[5]:'&id='.$st_id).'&pnr='.$row2[0], '', '', 'id=1');
                                        $p_cache_link70[$row[14]]=new Template_Link(($leadprozess ? $row2[6] : ''), 'stammdaten_main.php?nav=Fahrzeuge'.(intval($row2[5])>0?'&id='.$row2[5]:'&id='.$st_id).'&pnr='.$row2[0].'&exclude_stammdaten_tabs=1', 'mdi-car', '', 'id=1 target="main"');
                                        
                                        $customerId = (int)$row2[5] > 0 ? $row2[5] : $st_id;
                                        $carLink = new Template_Link('', '', 'mdi-car');
                                        $carLink->setAttribute('id', 1);
                                        $carLink->setModalWeiterleitung(
                                            'GET',
                                            'stammdaten_main.php',
                                            'nav=Fahrzeuge&id=' . $customerId,
                                            'nav=Fahrzeuge&produktzuordnung_tab=tab_fahrzeuge_tab_details&aendern=' . $row2[0] . '&pnr=' . $row2[0],
                                            'produktzuordnung_modal',
                                            false
                                        );
                                        $p_cache_link70_2[$row[14]] = new Template_Tooltip($row2[6], $carLink);
                                    }
                                    //.' ('._KFZ_EZ_.': '.$db->unixdate($row2[3]).')
                                } else {
                                    $p_cache[$row[14]]='-';//$row[14];
                                    $p_cache_link70_2[$row[14]]='-';
                                }
                            } else {
                                $res2=$db->select($sql_tab['produkt'],
                                    array(
                                        $sql_tabs['produkt']['produkt_id'],
                                        $sql_tabs['produkt']['bezeichnung']
                                    ),
                                    $sql_tabs['produkt']['produkt_id'].'='.$db->dbzahl($row[14])
                                );
                                if ($row2=$db->zeile($res2)) {
                                    $p_cache[$row[14]]=$row2[1];
                                    $p_cache_link70_2[$row[14]]=$row2[1];
                                } else {
                                    $p_cache[$row[14]]='-';//$row[14];
                                    $p_cache_link70_2[$row[14]]='-';
                                }
                            }
                        } else {
                            $p_cache[$row[14]]='-';
                            $p_cache_link70_2[$row[14]]='-';
                        }
					}
					if (isset($p_cache_link[$row[14]]) && !$leadprozess) {
						$anzeige_stid.='<br>'.$p_cache_link[$row[14]];
					}
                    if ($leadprozess) {
                        $neukblock=p4n_mb_string('str_replace', "{k_fzg}", '<span class="fzg">'.$p_cache_link[$row[14]].'</span>', $neukblock);
                        $neukblock=p4n_mb_string('str_replace', "{k_man}", '<span class="k_man">'.$row[28].'</span>', $neukblock);
                       // $cols_view[11]=new Template_ElementList($p_cache_link[$row[14]],'','fzg');
                        $cols_detail[8][0]=new Template_Label(_FAHRZEUG_,$p_cache_link[$row[14]]);
                     
                        $cols_view[5][0]=($row['kfzmarke']!=''?new Template_Text($row['kfzmarke'],-1,array('bold')):'-');
                        $cols_view[8]=$p_cache_link70_2[$row[14]];
                    }
                    $cols_view_pim[4][0]=$p_cache_link70_2[$row[14]];
                    $cols_view_pim[4][1]='&nbsp;';
                    
                    $farbe='#fff';
                   // echo ($ist_vondb?$row[27]:$row[28]).'<br>';
                            
                            
                    if ($dashboard && 1==2) {
                        $dashboard->rawData=$dashboard->getLead($row[28]);
                        foreach ($dashboard->rawData as $dashboard_lead) {
                            foreach ($dashboard_lead as $r) {
                                $farbe=$dashboard->tableRow($r, false,true);
                            }
                        }
                    }
                    if (empty($color)) {
                        if (empty($farbe)) {
                            $color = '#fff';
                        } else {
                            $color = $farbe;
                        }
                    }
                    if (intval($row[9])==1) {
                        $color = '#fff';
                    }
                 //   echo $farbe.'<br>';


                    $neukblock= p4n_mb_string('str_replace', '{color}', $color, $neukblock);
                   // $cols_view[0]=new Template_TableCol('', $color);
                   // $cols_view[0]->addCustomClass('colored')->setAttribute('style','background-color:'.$color);
                    
                    $cols_view[1][0]=new Template_Text($row['lead_id'],-1,array('bold'));
                
					$neukblock=p4n_mb_string('str_replace', "{k_stammid}", $anzeige_stid, $neukblock);

                    /*$customerLink = linkToTab70(
                        $st_zeige1,
                        'stammdaten_main.php?nav=Uebersicht&exclude_stammdaten_tabs=1&id='.$st_id,
                        '',
                        '',
                        '',
                        1
                    );*/
                    
                    $customerLink=Template_link::init($st_zeige1)
                        ->setModalWeiterleitung('GET','stammdaten_main.php','nav=Korrespondenz&ohnep=1&id='.$st_id,'nav=Korrespondenz&aendern='.$row[0],'korrespondenzen_modal',false,'_tab');
                    
                    
                    if (is_object($customerLink)) {
                        $customerLink->addCustomClass('text-bold');
                    }
					$cols_view_pim[1][0] = $customerLink;
                    $cols_view_pim[1][1]='&nbsp;';
                    
                    
                    //$cols_view_pim[5][1]=$anzeige_stid_link70;
                    //$cols_view_pim[5][4]=$p_cache_link70;
                    
                    $cols_detail[1][0]=new Template_Label(_KUNDE_,$anzeige_stid);
					$k_symbol='bilder/'.$k_art_symbole[$row[7]];
                    if ($_SESSION['crm_version']>61 && $row[7]==14) {
                        $k_symbol='img/link_gespraechsnotiz.gif';
                    }
					$neukblock=p4n_mb_string('str_replace', "{k_art}", oltext($stammdaten_korrespondenz[$row[7]], '<img src="'.$k_symbol.'" border=0>', '', $lang['_K-ART_']), $neukblock);
                    $cols_view_pim[3][1]=($stammdaten_korrespondenz[$row[7]]!=''?new Template_Text($stammdaten_korrespondenz[$row[7]]):'&nbsp;');
                    
                    if ($stammdaten_korrespondenz[$row[7]]!='') {
                        $stammdaten_korrespondenz_filter[$row[7]]=$stammdaten_korrespondenz[$row[7]];
                    }
                    
					$neukblock=p4n_mb_string('str_replace', "{k_kategorie}",$row[8], $neukblock);
                    $cols_view_pim[2][1]=($row[8]!=''?new Template_Chip($row[8]):'&nbsp;');
					
					$zustext.='<br>'.$lang['_K-ART_'].': '.($row[8]=='&nbsp;'?'-':$row[8]);
					
					$ketext=grafikhaken($row[9], true);
                    $ketext70=$ketext;
                    
					if ($_SESSION['cfg_kunde']=='carlo_koltes' && $row[14] > 0 && $row[9] != '1' && $kampagnen_kategorie_name == 'Link zu FP') {
                        $ketext = link2('fahrzeug_'.$row[14], $phs.'fahrzeug_pflege.php?produktzuordnung_id='.$row[14], $ketext);
                        $ketext70=new Template_Link('fahrzeug_'.$row[14], $phs.'fahrzeug_pflege.php?produktzuordnung_id='.$row[14], $ketext70);
                    } else {
                        
                        if ($cfg_pim_ergebnishaken) {
                            if ($row[9]!='1') {
                                $js_zus1='';

                                if (intval($st_id)<=0) {
                                    if ($cfg_leserecht) {
                                        $ketext=grafikhaken($row[9], false);
                                        $ketext70=$ketext;
                                    } elseif ($row[9]==0) {
                                        $ketext=link2('', $phs.'?erledigt='.$row[0], $ketext);
                                        $ketext70=new Template_Link('', $phs.'?erledigt='.$row[0], $ketext70);
                                    } elseif ( $_SESSION['user_gruppe']==2 or (time()<=($db->unixdate_ts($row[1])+3600) and $userid_pim==$row[4]) ) {
                                        $ketext=link2('', $phs.'?unerledigt='.$row[0], $ketext);
                                        $ketext70=new Template_Link('', $phs.'?unerledigt='.$row[0], $ketext70);
                                    } else {
                                        $ketext=grafikhaken($row[9], false);
                                        $ketext70=$ketext;
                                    }
                                } else {
    //							
                                if ($cfg_kerfolg_balken) {
                                    $res2=$db->select(
                                        $sql_tab['stammdaten'],
                                        $sql_tabs['stammdaten']['abteilung'],
                                        $sql_tabs['stammdaten']['id'].'='.$db->dbzahl($st_id)
                                    );
                                    $row2=$db->zeile($res2);
                                    $js_zus1=' var mySlide = new Slider($(\'area\'), $(\'knob\'), { steps: 100, onChange: function(step){ $(\'upd\').value=step;} }).set('.intval($row2[0]).');';
                                }
                                $ketext=link2(_ERGEBNIS_, 'javascript: k_inhalt(\'stammdaten_main.php?nav=Uebersicht&kbew=1&ajax=1&ohnep=1&id='.$row[19].'&kid='.$row[0].'&druckoptimierung=1&tziel=pim.php&kurzk='.$row[7].'\', true, 700, 520);'.$js_zus1.' if (typeof cfg_modern!==typeof undefined && cfg_modern==true) {} else {new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} void(0);', $ketext);
                                $ketext70=new Template_Link('', 'javascript: k_inhalt(\'stammdaten_main.php?nav=Uebersicht&kbew=1&ajax=1&ohnep=1&id='.$row[19].'&kid='.$row[0].'&druckoptimierung=1&tziel=pim.php&kurzk='.$row[7].'\', true, 700, 520);'.$js_zus1.' if (typeof cfg_modern!==typeof undefined && cfg_modern==true) {} else {new Drag.Move(\'message\', {\'container\': crm_body, \'handle\':angdiv}); new Drag.Move(\'DivShim\', {\'container\': crm_body, \'handle\':angdiv});} void(0);', $ketext70);
                                
                                }
                            } else {
                                $ketext=grafikhaken($row[9], false);
                                $ketext70=$ketext;
                            }
                        } else {

                        if ($cfg_leserecht) {
                            $ketext=grafikhaken($row[9], false);
                            $ketext70=$ketext;
                        } elseif ($row[9]==0) {
                            $ketext=link2('', $phs.'?erledigt='.$row[0], $ketext);
                            $ketext70=new Template_Link('', $phs.'?erledigt='.$row[0], $ketext70);
                        } elseif ( $_SESSION['user_gruppe']==2 or (time()<=($db->unixdate_ts($row[1])+3600) and $userid_pim==$row[4]) ) {
                            $ketext=link2('', $phs.'?unerledigt='.$row[0], $ketext);
                            $ketext70=new Template_Link('', $phs.'?unerledigt='.$row[0], $ketext70);
                        } else {
                            $ketext=grafikhaken($row[9], false);
                            $ketext70=$ketext;
                        }

                        $ketext.=' '.$form->checkinput('cb_erl['.$row[0].']');
                        $cb_erlfeld.='if (!this.form.elements[\'cb_erl['.$row[0].']\'].checked) { this.form.elements[\'cb_erl['.$row[0].']\'].click(); } ';
                        }
					}
					$neukblock=p4n_mb_string('str_replace', "{k_erledigt}",$ketext, $neukblock);
                    //$cols_view_pim[5][0]=$ketext70;
					$neukblock=p4n_mb_string('str_replace', "{k_eingang}",keinaus($row[6]), $neukblock);                
					$dlink = array();
                    if ($row[11]!='' && $row[11]!='&nbsp;') {
                        $tpfad=$cfg_ordner_kdokumente_pfad;
                        if (p4n_mb_string('substr',$row[11], 0, 5)=='http:' || p4n_mb_string('substr',$row[11], 0, 6)=='https:') {
                            $tpfad='';
                        }
                        if ($leadprozess) {
                            $dbil='inc/Modern/images/stil_6_menu_bueroklammer_a.png';
                        } else {
                            $dbil=docbild($row[11], true);
                            if ($dbil=='Link') {
                                $dbil='';
                            }                            
                        }
						$dlink[]=link2(_LINKTO_, $tpfad.$row[11], $dbil, '', 'target="_blank"');
                    }
                    if ($leadprozess) {
                        $dbil='inc/Modern/images/stil_6_menu_bueroklammer_a.png';
                        $res_korr_doks=$db->select(
                            $sql_tab['korrespondenz_doks'],
                            array(
                                $sql_tabs['korrespondenz_doks']['bezeichnung'],
                                $sql_tabs['korrespondenz_doks']['datei']
                            ),
                            $sql_tabs['korrespondenz_doks']['korrespondenz_id'].'='.$db->dbzahl($row[0])
                        );
                        while ($row_korr_doks=$db->zeile($res_korr_doks)) {
                            $tpfad=$cfg_ordner_kdokumente_pfad;
                            if (p4n_mb_string('substr',$row_korr_doks[1], 0, 5)=='http:' || p4n_mb_string('substr',$row_korr_doks[1], 0, 6)=='https:') {
                                $tpfad='';
                            }
                            $dlink[]=link2(_LINKTO_, $tpfad.$row_korr_doks[1], $dbil, '', 'target="_blank"');
                        }
                        if ($leadzuordnung_eva_mahag and $row[28]>0) {
                            $res9=$db->select(
                                $sql_tab['korrespondenz'],
                                $sql_tabs['korrespondenz']['korrespondenz_id'],
                                $sql_tabs['korrespondenz']['lead_id'].'='.$db->dbzahl($row[28]).' and '.
                                    $sql_tabs['korrespondenz']['kategorie'].'='.$db->str('EVA-�bertragung')
                            );
                            if ($row9=$db->zeile($res9)) {
                                $dlink[]='Bearbeitung in EVA';
                            }
                        }
                    }
                    
                    $neukblock=p4n_mb_string('str_replace', "{k_doclink}", (!empty($dlink) ? implode(' ', $dlink) : '-'), $neukblock);
                   // $cols_view[3]=(!empty($dlink) ? implode(' ', $dlink) : '-');
                    
                  //  $color_z[]=array('#ffe003','#000000');
                  //  $color_z[]=array('#002b5e','#ffffff');
                  //  $color_z[]=array('#d5281b','#ffffff');
                   // $rand=rand(0,2);
                    
                    
                    $cols_detail[0][0]=new Template_Label(_DATEI_,(!empty($dlink) ? implode(' ', $dlink) : '-'));
                    	
					$ersteller=$alle_bens[$row[4]];
					$betreuer=$alle_bens[$row[5]];
                    //if ($leadprozess && !$leadreiterPost) {
                    //    $betreuer=$alle_bens[get_benutzer_id_from_lead($row[28])];		//Using lead benutzer_id instead Flag
                    //}
                    $zustext.='<br>'.$lang['_K-BETREUER_'].': '.$betreuer;
                    $cols_view_pim[5][0]=new Template_Text($betreuer,-1,array('bold'));
                    $cols_view_pim[5][1]='&nbsp;';
                    
					$zustext.='<br>'.$lang['_ADMINFILTER-BENUTZER_'].': '.$ersteller;

                    
                    $campaign70=$alle_kamps[$row[24]];
                    $cols_view_pim[3][0]=($campaign70!=''?new Template_Text($campaign70,-1,array('bold')):'&nbsp;');
                    
                    if ($leadprozess) {
                        $leadStatus = '';
                        $leadStatus70='';
                        if (!empty($row['lead_stage'])) {
                            $catList = Plugin_System_LeadTracker::getLeadCategoryList();
                            $leadStatus = '<b>'._PHASE_.'</b><br>'.@$catList[$row['lead_stage']];
                            $leadStatus70=@$catList[$row['lead_stage']];
                        }
                        $leadImportDate = '';
                        if (!empty($row['status1_time'])) {
                            $zahl_in_text_explode = explode(', ', zahl_seconds(time()-$db->unixdate_ts($row['status1_time'])));
                            $leadImportDate = '<b>'._LEAD_.' '.$lang['_K-ALTER_'].'</b><br>'.trim($zahl_in_text_explode[0].' '.$zahl_in_text_explode[1]);
                            $leadImportDate70=trim($zahl_in_text_explode[0].' '.$zahl_in_text_explode[1]);
                        }
                        $leadType = '';
                        if (!empty($row['type'])) {
                            $extra_info=array();
                            if ($row['kampagne_lead_id']>0) {
                                $extra_info[]='ID: '.$row['kampagne_lead_id'];
                            }
                            if ($row['leadid']!='') {
                                $extra_info[]='Ext.-ID: '.$row['leadid'];
                            }
                            if ($row['additionaldata']!='') {
                                $merke_bemerkung_explode=explode('#####', $row['additionaldata']); //additionaldata
                                if (!empty($merke_bemerkung_explode) && isset($merke_bemerkung_explode[1])) {
                                    $extra_info[]=$merke_bemerkung_explode[1];
                                }
                            }
                         
                            $leadType = '<b>'._LEAD_.' '._ART_.'</b><span '.(!empty($extra_info) ? oltext2(implode('<br>', $extra_info), '') : '').'class="icon icon-help">&nbsp;</span><br>'.$row['type'];
                            $leadType70=new Template_ElementList(array(
                                $row['type'],
                                (!empty($extra_info) ? new Template_Tooltip(new Template_Html(html_entity_decode(nl2br(implode("<br>", $extra_info)))), new Template_Icon('help')):'')
                            ));
                        }
                        $campaign = '';
                        if (isset($alle_kamps[$row[24]])) {
                            $campaign = '<b>'._KAMPAGNE_.'</b><br>'.$alle_kamps[$row[24]];
                            $campaign70=$alle_kamps[$row[24]];
                        }
                        //$neukblock=p4n_mb_string('str_replace', "{k_betreuer}", '<b>'.(($row['art']=='112') ? _VERKAUFSLEITER_ : $lang['_K-BETREUER_']).'</b><br>'.(($row['art']=='112') ? $ersteller : $betreuer), $neukblock);
                        $neukblock=p4n_mb_string('str_replace', "{k_betreuer}", '<b>'.$lang['_K-BETREUER_'].'</b><br>'.$betreuer, $neukblock);
                      //  $cols_view[10]=$betreuer;
                        $cols_detail[7][0]=new Template_Label($lang['_K-BETREUER_'],$betreuer);
                        $neukblock=p4n_mb_string('str_replace', "{l_status}", $leadStatus, $neukblock);
                      //  $cols_view[9]=$leadStatus70;
                        $cols_detail[6][0]=new Template_Label(_PHASE_,$leadStatus70);
                        
                        $neukblock=p4n_mb_string('str_replace', "{l_art}", $leadType, $neukblock);
                      //  $cols_view[8]=$leadType70;
                        $cols_detail[5][0]=new Template_Label(_LEAD_.' '._ART_,$leadType70);
                        $neukblock=p4n_mb_string('str_replace', "{l_import_datum}", $leadImportDate, $neukblock);
                      //  $cols_view[6]=$leadImportDate70;
                        $cols_detail[3][0]=new Template_Label(_LEAD_.' '.$lang['_K-ALTER_'],$leadImportDate70);
                        $neukblock=p4n_mb_string('str_replace', "{k_kampagne}", $campaign, $neukblock);
                      //  $cols_view[7]=$campaign70;
                        $cols_detail[4][0]=new Template_Label(_KAMPAGNE_,$campaign70);
                        
                        $cols_view[2][0]=Template_Link::init(new Template_Text($st_zeige1,-1,array('bold')))->setModalWeiterleitung('GET','stammdaten_main.php','nav=lead&id='.$row[19],'lead='.$row['lead_id'].'&modal=1','pim_aendern_modal');
                        //$cols_view[1][1]=new Template_Chip($leadStatus70,'#0181db','#ffffff');
                        $cols_view[1][1]=new Template_Chip($leadStatus70,'#f4f4f4','#4b4b4b');
                        
                        
                        // $cols_view[2][1] = $leadImportDate70;
                        // 27.07.2023 - Sales Feedback - F�lligkeitsdatum statt Alter.
                        $cols_view[2][1] = '-';
                        if ($row['wvl_datum1']) {
                            $cols_view[2][1] = date('d.m.Y H:i', strtotime($row['wvl_datum1']));
                        }
						
                        $cols_view[4][0]=($campaign70!=''?new Template_Text($campaign70,-1,array('bold')):'-');
                        //new Template_ElementList(array(new Template_Text($campaign70,-1,array('bold')),($row['type']!=''?$row['type']:'-')),'','vertical');
                        $cols_view[5][1]=($row['type']!=''?$row['type']:'-');
                        $cols_view[6]=new Template_ElementList(array(new Template_Text($prove_source,-1,array('bold')),$prove_channel),'','vertical table-cell-vertical');
                        $cols_view[7][0]=$betreuer;
                    }
                    $cols_view[5]=new Template_ElementList($cols_view[5],'','vertical');
                    $cols_view[2]=new Template_ElementList($cols_view[2],'','vertical');
                    $cols_view[1]=new Template_ElementList($cols_view[1],'','vertical');

					$neukblock=p4n_mb_string('str_replace', "{k_erstellerid}", $ersteller.$ztext, $neukblock);
					
					$olex1='';
					$knavlink=($row[19]>0?'stammdaten_main.php?id='.$row[19].'&nav=Korrespondenz':'#');
					$knavlink2=($row[19]>0?'stammdaten_main.php?id='.$row[19].'&nav=Korrespondenz&text='.$row[0]:'#');
					if ($row[19]>0) {
						$olex1='target="_blank"';
					}
					
					$laengeabk=10;
					if (isset($cfg_pim_kbes_laenge)) {
						if (intval($cfg_pim_kbes_laenge)>1) {
							$laengeabk=$cfg_pim_kbes_laenge;
						}
					}
                    if ($_SESSION['design_70']) {
                        $laengeabk=20;
                    }
					
					$neukblock=p4n_mb_string('str_replace', "{k_betreff}", oltext($row[12].'<br><br>'.$lang['_ADMINFILTER-BENUTZER_'].': '.$ersteller, abkuerzung($row[12], $laengeabk), $knavlink2, $lang['_K-BETREFF_'],'500', $olex1), $neukblock).(($cfg_modern)?'':'</a>');
					
                    
					$ztext='';
					if ( $_SESSION['user_gruppe']==2 or (time()<=($db->unixdate_ts($row[1])+3600) and $userid_pim==$row[4]) ) {
						$ztext=' '.link2(_KLOESCH_, 'pim.php?loesch='.$row[0], 'loesch.gif', _ABFRAGE_LOESCHEN_);
					}
					if (!$_SESSION['design_70']) {
                        $zustext.='<br>'.$lang['_K-PRODUKT_'].': '.$p_cache[$row[14]];
                    }
					$neukblock=p4n_mb_string('str_replace', "{k_produktzuordnungid}",$textp, $neukblock);
					
					$row[13]=p4n_mb_string('str_replace', array('$'), array('&#36;'), $row[13]);
					
                    if ($_SESSION['design_70'] && $laengeabk > 50) {
                        $laengeabk=50;
                    }
                    if ($laengeabk > 0 && !$_SESSION['design_70']) {
                    //Thomas: sollte gemacht werden, damit Beschreibungstexte mit HTML inhalten, die abgeschnitten werden nicht die PIM zerschie�en
                        $row[13]=p4n_mb_string('str_replace', '<br>', "\n", $row[13]);
                        $row[13]=p4n_mb_string('html_entity_decode',$row[13]);
                        $row13_short=strip_tags($row[13]);
                        $row[13]=p4n_mb_string('htmlentities', $row[13]);
                        $row[13]=strip_tags($row[13]);
                        //$row13_short70=str_replace('<br>','',$row13_short);
                    }
					$zustext=p4n_mb_string('str_replace', array('$'), array('&#36;'), $zustext);
					$neukblock=p4n_mb_string('str_replace', "{k_beschreibung}", oltext($row[13].'<br>'.$zustext, abkuerzung($row13_short, $laengeabk), $knavlink, $lang['_K-BESCHREIBUNG_'],'500'), $neukblock);
                    
                    $temp_text=new Template_Text($row[12],$laengeabk,array('bold'));
                    $temp_text->tooltip=false;
                    $cols_view_pim[2][0]=new Template_Tooltip($row[13].'<br>'.$zustext,$temp_text,'',$row[12]);
                    
                    
                    //$cols_view_pim[3][1]=new Template_Tooltip($row[12].'<br>'.$row[13].'<br>'.$zustext, '', new Template_Link(abkuerzung($row[12], $laengeabk),$knavlink,'','','target="main"'), $lang['_K-BETREFF_'],'500', $olex1);
                    
                    if ($leadprozess) {
                        $betreff=($additional['betreff']!=''?new Template_Tooltip($additional['beschreibung'], new Template_Text($additional['betreff'], 20,array('bold')),'', _BESCHREIBUNG_,'500', $olex1):'-');
                        $cols_view[3][0]=new Template_Text($additional['betreff'], 20,array('bold'));
                        $cols_view[3][1]=new Template_Tooltip($additional['beschreibung'],new Template_Text($additional['beschreibung'], 20,array('')),'',_BESCHREIBUNG_);
                        ksort($cols_view[3]);
                        $cols_view[3]=new Template_ElementList($cols_view[3],'','vertical');

                       // $cols_view[4][1]=Template_Chip::init($row['kategorie'],'#e4e4e4','#292929');
                        $cols_view[4][1]=$row['kategorie'];
                        $cols_view[4]=new Template_ElementList($cols_view[4],'','vertical');
                    }
                    
					if ($row[21]!='&nbsp;' or $row[21]!='&nbsp;') {
						$erge=oltext($db->unixdatetime($row[22]).': '.$row[21], ($row[23]!='&nbsp;'?$row[23]:abkuerzung($row[21], 20)), '', _KERGEBNIS_,'500');
                        $erge70=new Template_Tooltip($db->unixdatetime($row[22]).': '.$row[21], ($row[23]!='&nbsp;'?$row[23]:abkuerzung($row[21], 20)), '', _KERGEBNIS_,'500');
					} else {
						$erge=link2(_ERGEBNIS_, 'javascript: lade_in_message(\'stammdaten_main.php?nav=Uebersicht&kbew=1&id='.$row[19].'&kid='.$row[0].'&druckoptimierung=1&kurzk='.$row[7].'\', 500, 400);');
                        $erge70=new Template_Link('', 'javascript: lade_in_message(\'stammdaten_main.php?nav=Uebersicht&kbew=1&id='.$row[19].'&kid='.$row[0].'&druckoptimierung=1&kurzk='.$row[7].'\', 500, 400);','mail');
                        
                    }
					$neukblock=p4n_mb_string('str_replace', "{k_ergebnis}", $erge, $neukblock);
                      
					//$cols_view_pim[5][2]=$erge70;
					
					if ($row[9]==0) {
						$merke_offene[$row[0]]=$db->unixdate($row[1]).': '.abkuerzung($row[12]);
                    }
                    if ($leadprozess && $_POST['show_lead']=='link_closed') {
                        $sammle_korr[$row[28]]=$neukblock;
                    }

					if( $cfg_leadprozess_schlank ) {
						/*
						echo '<pre>$alle_leads_kampagne_lead_status: ';
						print_r($alle_leads_kampagne_lead_status);
						
						echo '<pre>$alle_kamps_man: ';
						print_r($alle_kamps_man);
						
						echo '$alle_kamps_kategorien: ';
						print_r($alle_kamps_kategorien);
						
						echo '<pre>$row: ';
						//print_r($row);
						echo 'kampagne_id: '.$row['kampagne_id'];
						echo '</pre>';
						
						echo 'ActualKampagne: '.actual_kampagne($row['kampagne_id'],$alle_kamps_endungen);
						echo '<br> not_finished_lead'.not_finished_lead($alle_leads_kampagne_lead_status[$row['lead_id']]['status']).'<br>';
						*/
                        
						$leads_lead = p4n_mb_string('strpos',$alle_kamps_kategorien[$row['kampagne_id']],'Leads') !== false;
						$actual_kampagne = strtotime($alle_kamps_endungen[$row['kampagne_id']]) > time();
						$lead_status = $alle_leads_kampagne_lead_status[$row['lead_id']]['status'];
						$not_finished_lead = in_array($lead_status,array(0,1,2,3,4,99,100,101)) && $lead_status!='';
						if( $_POST['leadprozess'] && $_SESSION['leadprozess']=='pim_vkl' && $leads_lead && ($actual_kampagne ||	$not_finished_lead)){
							$kftext.=$neukblock;
						}
						else if( !$_POST['leadprozess'] ){
							$kftext.=$neukblock;
						}
						else if ($_SESSION['leadprozess']=='pim' || isset($_POST['pim_lead_php']) || $_POST['leadprozess']=='1') {
							$kftext.=$neukblock;
						}
					}
					else {
						$kftext.=$neukblock;
					}
/*					$ebene++;
					kdatensatz($row[0]);
					$ebene--;
*/					$anzahl_a++;

                    $action_list=array();
                    if (isset($_POST['stammdaten_lead_php'])) {
                        $action_list[0] = Template_Link::init('Aktivit�ten','','history')->setRequest('GET', $aendern_modal_inhalt, "stammdaten_lead.php", array('lead='.$row['kampagne_lead_id'].'&modal=1'), array($aendern_modal));
                        $action_list[1] = Template_Link::init(_FAHRZEUG_,'','mdi-car-outline')->setRequest('GET', $aendern_modal_inhalt, "stammdaten_lead.php", array('lead='.$row['kampagne_lead_id'].'&modal=1&stammdaten_lead_tab=tab_fahrzeug'), array($aendern_modal));
                        
                        if (isset($rechte__lead['lead_zurueckgeben']) && $rechte__lead['lead_zurueckgeben'] && isset($_SESSION['lead']) && isset($_SESSION['lead'][$_SESSION['stammdaten_id']]) && $_SESSION['lead'][$_SESSION['stammdaten_id']] !== '') {
                            if (intval($row['status']) !== 5) {
                                $action_list[2] = Template_Link::init(_ZURUECKGEBEN_, '', 'undo')->setRequest('GET', $aendern_modal_inhalt, "stammdaten_lead.php", array('lead='.$row['kampagne_lead_id'].'&modal=1&stammdaten_lead_tab=tab_handback'), array($aendern_modal));
                            }
                        }

                        //$action_list[3]= new Template_Link($row['status']);
                        
                        
                    } elseif (isset($_POST['pim_lead_php']))  {
                        // $action_list[0] = Template_Link::init(_DETAILS_,'','remove_red_eye')->setRequest('GET', $aendern_modal_inhalt, "leadzuordnung_gm.php", array('st_id='.$st_id.'&ap_id='.$row[26].'&pim_lead_php=1&action=show_modal&modal_action=tab_details&leadId='.$row['kampagne_lead_id']), array($aendern_modal));
                        $action_list = array(
                            Template_Link::init(_NOTIZ_, '', 'mdi-file-document-edit-outline')
                                ->setRequest(
                                    'GET',
                                    $aendern_modal_inhalt,
                                    'stammdaten_main.php',
                                    array('nav=Korrespondenz&kurzk=103&ajax=1&pzid='.$row[14].'&leadid='.$row['kampagne_lead_id'].'&form_target=hidden_elementlist&kziel=&id='.$st_id),
                                    array($aendern_modal)
                                ),
                            Template_Link::init(_TELEFON_, '', 'phonelink_ring')
                                ->setRequest(
                                    'GET',
                                    $aendern_modal_inhalt,
                                    'stammdaten_main.php',
                                    array('nav=Korrespondenz&kurzk=102&ajax=1&pzid='.$row[14].'&leadid='.$row['kampagne_lead_id'].'&form_target=hidden_elementlist&kziel=&id='.$st_id),
                                    array($aendern_modal)
                                ),
                            Template_Link::init(_EMAIL_, '', 'mail_outline')
                                ->setRequest(
                                    'GET',
                                    $aendern_modal_inhalt,
                                    'stammdaten_main.php',
                                    array('nav=Korrespondenz&kurzk=101&ajax=1&pzid='.$row[14].'&leadid='.$row['kampagne_lead_id'].'&form_target=hidden_elementlist&keineausgabe=1&kziel=&id='.$st_id),
                                    array($aendern_modal)
                                ),
                            (defined('_WHATSAPP_') ? Template_Link::init(_WHATSAPP_, '', 'mdi-whatsapp', '', 'style="display:none;" id="button_whatsapp"')->setRequest('GET', $aendern_modal_inhalt, 'stammdaten_main.php', array('nav=lead&lead='.$row['kampagne_lead_id'].'&chat=1'), array($aendern_modal)) : ''),
                            (defined('_TELEGRAM_') ? Template_Link::init(_TELEGRAM_, '', 'mdi-telegram', '', 'style="display:none;" id="button_telegram"')->setRequest('GET', $aendern_modal_inhalt, 'stammdaten_main.php', array('nav=lead&lead='.$row['kampagne_lead_id'].'&chat=1'), array($aendern_modal)) : ''),
                            Template_Link::init(_MASSNAHME_, '', 'mdi-progress-alert', '', (!$ist_vkl ? 'onclick="return false" disabled="disabled"' : ''))
                                ->setRequest(
                                    'GET',
                                    $aendern_modal_inhalt,
                                    'stammdaten_main.php',
                                    array('nav=Korrespondenz&kurzk=104&ajax=1&pzid='.$row[14].'&leadid='.$row['kampagne_lead_id'].'&form_target=hidden_elementlist&kziel=&id='.$st_id),
                                    array($aendern_modal)
                                ),
                            ($cfg_avag_de?'':Template_Link::init('EVA', '', 'exit_to_app')
                                ->setRequest(
                                    'GET',
                                    $aendern_modal_inhalt,
                                    'stammdaten_main.php',
                                    array('nav=Korrespondenz&kurzk=103&istsa=1&ajax=1&navto=lead&pzid='.$row[14].'&leadid='.$row['kampagne_lead_id']),
                                    array($aendern_modal)
                                ))
                        );
                    } else {
                        $action_list[0] = Template_Link::init(_DETAILS_,'','remove_red_eye')->setRequest('POST', $aendern_modal_inhalt, "pim.php", array('wvlart=1&leadprozess=1&navto=lead&leadprozess_id='.$row['kampagne_lead_id']), array($aendern_modal));
                     
                        $action_list=array(
                            Template_Link::init(_NOTIZ_,'','mdi-file-document-edit-outline')->setRequest('GET', $aendern_modal_inhalt, 'stammdaten_main.php', array('nav=Korrespondenz&kurzk=103&ajax=1&pzid=' . $row[14] . '&leadid=' . $row['kampagne_lead_id'].'&form_target=hidden_elementlist&kziel='), array($aendern_modal)),
                            Template_Link::init(_TELEFON_,'','phonelink_ring')->setRequest('GET', $aendern_modal_inhalt, 'stammdaten_main.php', array('nav=Korrespondenz&kurzk=102&ajax=1&pzid=' . $row[14] . '&leadid=' . $row['kampagne_lead_id'].'&form_target=hidden_elementlist&kziel='), array($aendern_modal)),
                            Template_Link::init(_EMAIL_,'','mail_outline')->setRequest('GET', $aendern_modal_inhalt, 'stammdaten_main.php', array('nav=Korrespondenz&kurzk=101&ajax=1&pzid=' . $row[14] . '&leadid=' . $row['kampagne_lead_id'].'&form_target=hidden_elementlist&keineausgabe=1&kziel='), array($aendern_modal)),
                            (defined('_WHATSAPP_')?Template_Link::init(_WHATSAPP_,'', 'mdi-whatsapp','','style="display:none;" id="button_whatsapp"')->setRequest('GET', $aendern_modal_inhalt, 'stammdaten_main.php', array('nav=lead&lead=' . $row['kampagne_lead_id'] . '&chat=1'), array($aendern_modal)):''),
                            (defined('_TELEGRAM_')?Template_Link::init(_TELEGRAM_,'', 'mdi-telegram','','style="display:none;" id="button_telegram"')->setRequest('GET', $aendern_modal_inhalt, 'stammdaten_main.php', array('nav=lead&lead=' . $row['kampagne_lead_id'] . '&chat=1'), array($aendern_modal)):''),
                            Template_Link::init(_MASSNAHME_,'', 'mdi-progress-alert','',(!$ist_vkl ? 'onclick="return false" disabled="disabled"' : ''))->setRequest('GET', $aendern_modal_inhalt, 'stammdaten_main.php', array('nav=Korrespondenz&kurzk=104&ajax=1&pzid=' . $row[14] . '&leadid=' . $row['kampagne_lead_id'].'&form_target=hidden_elementlist&kziel='), array($aendern_modal)),
                            Template_Link::init('EVA','','exit_to_app')->setRequest('GET', $aendern_modal_inhalt, 'stammdaten_main.php', array('nav=Korrespondenz&kurzk=103&istsa=1&ajax=1&navto=lead&pzid=' . $row[14] . '&leadid=' . $row['kampagne_lead_id']), array($aendern_modal))
                        );
                    }
                    $actionMenuButton = new Template_IconButton('','','', 'more_vert',$href='',$abfrage='', $sizeClass = 'md');
                    $actionMenuContent = new Template_LinkList($action_list);
                    Template_InlineOverlay::prepare($actionMenuButton, $actionMenuContent, 'actionMenuLeadprozess_'.$_POST['stammdaten_lead_php'].'_' . $row[0]);
                    $cols_view[9] = array($actionMenuButton, $actionMenuContent);

                    ksort($cols_view);
                    if (!$table_data_i) {
                        $table_data_i = 1;
                    }
                    $table_data[$table_data_i++] = $cols_view;
					
                    // $actionlist = array(
                    //         1=>Template_Link::init('Kontakteintrag','','mdi-account-voice')
                    //         ->setModalWeiterleitung('GET','stammdaten_main.php','nav=Korrespondenz&ohnep=1&id='.$st_id,'ergart1=1&nav=Uebersicht&kbew=1&ajax=1&ohnep=1&id='.$st_id.'&kid='.$row[0].'&druckoptimierung=1&tziel=stammdaten_main.php&kurzk=3','korrespondenzen_modal'),
                    //         2=>Template_Link::init('E-Mail schreiben','','mdi-at')
                    //         ->setModalWeiterleitung('GET','stammdaten_main.php','nav=Korrespondenz&ohnep=1&id='.$st_id,'ergart2=1&nav=Uebersicht&kbew=1&ajax=1&ohnep=1&id='.$st_id.'&kid='.$row[0].'&druckoptimierung=1&tziel=stammdaten_main.php&kurzk=7','korrespondenzen_modal'),
                    //         3=>Template_Link::init('Brief erstellen','','mdi-email-outline')
                    //         ->setModalWeiterleitung('GET','stammdaten_main.php','nav=Korrespondenz&ohnep=1&id='.$st_id,'ergart4=1&nav=Uebersicht&kbew=1&ajax=1&ohnep=1&id='.$st_id.'&kid='.$row[0].'&druckoptimierung=1&tziel=stammdaten_main.php&kurzk=8', 'korrespondenzen_modal'),
                    //         4=>Template_Link::init('SMS versenden','','mdi-message-text-outline')
                    //         ->setModalWeiterleitung('GET','stammdaten_main.php','nav=Korrespondenz&ohnep=1&id='.$st_id,'ergart3=1&nav=Uebersicht&kbew=1&ajax=1&ohnep=1&id='.$st_id.'&kid='.$row[0].'&druckoptimierung=1&tziel=stammdaten_main.php&kurzk=15', 'korrespondenzen_modal')
                    // );
					
					// region 13.07.2023 - These action links should no longer redirect the user to the customer, instead the correspondence form should be opened in a level 2 modal.
					$actionlist = array(
						1 => (new Template_Link('Kontakteintrag', '', 'mdi-account-voice'))
							->setRequest(
								'GET',
								$pim_modal_level2_inhalt,
								'stammdaten_main.php',
								'ergart1=1&nav=Uebersicht&kbew=1&ajax=1&ohnep=1&id='.$st_id.'&kid='.$row[0].'&druckoptimierung=1&tziel=stammdaten_main.php&kurzk=3&keineausgabe=1&requestTarget=pim_modal',
								array($pim_modal_level2)
							),
						2 => (new Template_Link('E-Mail schreiben', '', 'mdi-at'))
							->setRequest(
								'GET',
								$pim_modal_level2_inhalt,
								'stammdaten_main.php',
								'ergart2=1&nav=Uebersicht&kbew=1&ajax=1&ohnep=1&id='.$st_id.'&kid='.$row[0].'&druckoptimierung=1&tziel=stammdaten_main.php&kurzk=7&keineausgabe=1&requestTarget=pim_modal',
								array($pim_modal_level2)
							),
						3 => (new Template_Link('Brief erstellen', '', 'mdi-email-outline'))
							->setRequest(
								'GET',
								$pim_modal_level2_inhalt,
								'stammdaten_main.php',
								'ergart4=1&nav=Uebersicht&kbew=1&ajax=1&ohnep=1&id='.$st_id.'&kid='.$row[0].'&druckoptimierung=1&tziel=stammdaten_main.php&kurzk=8&keineausgabe=1&requestTarget=pim_modal',
								array($pim_modal_level2)
							),
						4 => (new Template_Link('SMS versenden', '', 'mdi-message-text-outline'))
							->setRequest(
								'GET',
								$pim_modal_level2_inhalt,
								'stammdaten_main.php',
								'ergart3=1&nav=Uebersicht&kbew=1&ajax=1&ohnep=1&id='.$st_id.'&kid='.$row[0].'&druckoptimierung=1&tziel=stammdaten_main.php&kurzk=15&keineausgabe=1&requestTarget=pim_modal',
								array($pim_modal_level2)
							)
					);
					// endregion
					
					if (empty($row['stammdaten_id']) || (int)$row['stammdaten_id'] === 0) {
						$actionlist = array(
							(new Template_Link(
								ucfirst('als erledigt markieren'),
								'',
								'mdi-reply',
								'',
								'onclick="RequestHelper.get(\'korrespondenz.php?erledigt=' . $row['korrespondenz_id'] . '\');"'
							))->setRequest('GET', $pim_modal_inhalt, 'pim.php', 'pagination_korr_1=1', array($pim_modal))
						);
					}
			        
                    $trigger_menu=Template_IconButton::init('', '', '', 'more_vert',$href='',$abfrage='', $sizeClass = 'sm')->addCustomClass('p0');
                    $actionMenu= Template_InlineMenu::init($actionlist,$trigger_menu);
                    $cols_view_pim[6]=$actionMenu->getTriggerButtonAndMenu();
                    
                    ksort($cols_view_pim[0]);
                    $cols_view_pim[0]=new Template_ElementList($cols_view_pim[0],'','vertical');
                    ksort($cols_view_pim[1]);
                    $cols_view_pim[1]=new Template_ElementList($cols_view_pim[1],'','vertical');
                    ksort($cols_view_pim[2]);
                    $cols_view_pim[2]=new Template_ElementList($cols_view_pim[2],'','vertical');
                    ksort($cols_view_pim[3]);
                    $cols_view_pim[3]=new Template_ElementList($cols_view_pim[3],'','vertical');
                    ksort($cols_view_pim[4]);
                    $cols_view_pim[4]=new Template_ElementList($cols_view_pim[4],'','vertical');
                    ksort($cols_view_pim[5]);
                    $cols_view_pim[5]=new Template_ElementList($cols_view_pim[5],'','vertical');
                    
                    ksort($cols_view_pim);
                    if (!$table_data_i_pim) {
                        $table_data_i_pim = 1;
                    }
                    $table_data_pim[$table_data_i_pim++] = $cols_view_pim;
				}//endwhile Flag
				if ($zeitdebug) {
					echo 'kdatensatz '.$artkorr.' Ende: '.zeitnahme().'<br>';
				}
             
                if (is_array($sammle_korr) && count($sammle_korr)>1) {
                    $kftext='';
                    foreach ($sammle_korr as $sk) {
                        $kftext.=$sk;
                    }
                }
            
                $pim_kennzahl_status=array_merge(array('alle Leads'=>$pagination_anzahl),$pim_kennzahl_status);
               
                
                if ($_SESSION['design_70'] && !isset($_POST['leadprozess_id']) && isset($_POST['leadprozess'])) {
                    if (!isset($_POST['pagination_stammdaten_lead1']) && isset($_POST['pim_lead_php'])) {
                       // $debug->debug('testpim.txt','echo karte !isset($_POST[pagination_stammdaten_lead1]) && isset($_POST[pim_lead_php])');
                        return Template_Module::PimKennzahlenCard(
                            'Leads',
                            Template_IconButton::init('', '', '', 'open_in_new', '', '', 'sm', 'transparent-black', 'round')
                                ->setRequest(
                                    'POST',
                                    $pim_modal_inhalt,
                                    'pim.php',
                                    array(
                                        'pagination_stammdaten_lead1=1'.
                                        (isset($_POST['stammdaten_lead_php']) ? '&stammdaten_lead_php='.$_POST['stammdaten_lead_php'] : '').
                                        (isset($_POST['pim_lead_php']) ? '&pim_lead_php='.$_POST['pim_lead_php'] : '').
                                        '&wvlart='.$_POST['wvlart'].
                                        '&leadprozess='.$_POST['leadprozess'].
                                        '&navto='.$_POST['navto'].
                                        '&id='.$_POST['id'].
                                        '&filter_phase='.$_POST['filter_phase'].
                                        '&initialLoad=1'
                                    ),
                                    $pim_modal
                                ),
                            null,
                            $pim_kennzahl_status,
                            (($user['pim_lead_view_auswahl'] == 'graph') ? true : false)
                        )->getHtml();
                    } else {
                        $temp = array(
                            _ID_.'/'._PHASE_,//2    
                            _TRVKUNDENNAME_.'/'._WVL_.' '._DATUM_,//3 $lang['_K-ALTER_']
                            _BETREFF_.'/'._BESCHREIBUNG_,//4
                            _KAMPAGNE_.'/'._KATEGORIE_,
                            _MARKE_.'/'._ART_,
                            _QUELLE_.'/'._KANAL_,
                            _BETREUER_,
                            'QA',
                            _AKTION_
                        );

                        $table_data_priority = array(
                            _AKTION_,
                           // 'colored',
                            _ID_.'/'._PHASE_,
                            _BETREFF_.'/'._BESCHREIBUNG_,
                        );
                        
                        if (isset($_POST['stammdaten_lead_php']) || isset($_POST['pim_lead_php'])) {
                            $pagination->create($pagination_anzahl);
                            $pagination->setRequest(
                                'POST',
                                (!isset($_POST['pim_lead_php']) ? 'pagination_stammdaten_lead1' : 'pim_modal_inhalt'),
                                'pim.php',
                                array(
                                    'pagination_stammdaten_lead1=1'.
                                    (isset($_POST['stammdaten_lead_php']) ? '&stammdaten_lead_php='.$_POST['stammdaten_lead_php'] : '').
                                    (isset($_POST['pim_lead_php']) ? '&pim_lead_php='.$_POST['pim_lead_php'] : '').
                                    '&wvlart='.$_POST['wvlart'].
                                    '&leadprozess='.$_POST['leadprozess'].
                                    '&navto='.$_POST['navto'].
                                    '&id='.$_POST['id'].'&filter_phase='.$_POST['filter_phase'].
                                    '&sort_column='.$_POST['sort_column'].
                                    '&sort_order='.$_POST['sort_order'].(isset($_POST['avagpim_vkchancen']) ? '&avagpim_vkchancen=1' : '').(isset($_POST['avagpim_vkchancen2']) ? '&avagpim_vkchancen2=1' : '').(isset($_POST['avagpim_vkchancen3']) ? '&avagpim_vkchancen3=1' : '').
                                    '&wfilterdatum_start='.$_POST['wfilterdatum_start'].
                                    '&wfilterdatum_ende='.$_POST['wfilterdatum_ende']
                                )
                            );
                        }

                        $leadCategoryList = Plugin_System_LeadTracker::getLeadCategoryList();
                        $leadStatusOptions = [_PHASE_ => 'OPTGROUP'];
                        foreach ($leadCategoryList as $key => $value) {
                            $leadStatusOptions[$key] = $value;
                        }
                        $leadStatusOptions[_GRUPPIERUNG_] = 'OPTGROUP';
                        $leadStatusOptions['9,6,5'] = _IN_ARBEIT_;
                        
                        $filter70 = array(
                            new Template_SelectInput(
                                _PHASE_,
                                'filter_phase',
                                $leadStatusOptions,
                                $_POST['filter_phase'],
                                _KEINE_AUSWAHL_
                            ),
                            new Template_ElementList(
                                [
                                    new Template_DatumInput(
                                        _WVL_.' - '.$lang['_K-DATUM_'].' '._VON_.'/'._BIS_,
                                        'wfilterdatum_start',
                                        $_POST['wfilterdatum_start']
                                    ),
                                    new Template_DatumInput(
                                        '&nbsp;',
                                        'wfilterdatum_ende',
                                        $_POST['wfilterdatum_ende']
                                    )
                                ], '', 'horizontal'
                            )
                        );
                        $filter = new Template_Filter();
                        $filter->initPageFilter($filter70, $formAction='pim.php', $formMethod = 'POST', $target=(isset($_POST['stammdaten_lead_php'])?'tab_lead':(!isset($_POST['pim_lead_php'])?'pagination_stammdaten_lead1':'pim_modal_inhalt')),(isset($_POST['pim_lead_php'])?'pim_lead_php=1&':'').(isset($_POST['stammdaten_lead_php'])?'stammdaten_lead_php=1&':'').'pagination_stammdaten_lead1=1&wvlart=1&leadprozess=1&navto=lead&id='.$_SESSION['stammdaten_id'].'&sort_column='.$_POST['sort_column'].'&sort_order='.$_POST['sort_order'].(isset($_POST['avagpim_vkchancen'])?'&avagpim_vkchancen=1':'').(isset($_POST['avagpim_vkchancen2'])?'&avagpim_vkchancen2=1':'').(isset($_POST['avagpim_vkchancen3'])?'&avagpim_vkchancen3=1':''));
                     
                        $tableOptions=array(
                            'priority' => $table_data_priority,
                            'sort' => array(_ID_,_BETREFF_,_BESCHREIBUNG_,_KAMPAGNE_,_KATEGORIE_,_BETREUER_,_ART_,_TRVKUNDENNAME_),
                            'sortType' => 'REQUEST',
                            'sortRequestOptions' => [
                                'url' => 'pim.php',
                                'method' => 'POST',
                                'callback' => '',
                                'target'=>'#tab_lead',
                                'parameter'=>'stammdaten_lead_php=1&wvlart=1&leadprozess=1&navto=lead&id='.$_SESSION['stammdaten_id']
                            ],
                            'multiple' => true,
                            'hideColumnTitle' => [
                                'QA',
                            ],
                            'fullContentHeight' => true,
                            'sortDefaultOrder'=>array($_POST['sort_column'] => $_POST['sort_order'])
                        );
                        
                        if (isset($_POST['pim_lead_php'])) {
                            unset($tableOptions['fullContentHeight']);
                        }
                        
                        $newLeadBtn = Template_Button::init('new_lead', '+ '._NEUES_.' '._LEAD_, '', '', '', '', '', 'blue', 'rect');
                        $newLeadBtn->setRequest(
                            'GET',
                            $aendern_modal_inhalt,
                            'bdc.php',
                            'schnellauswahl2=lead&stid='.$_SESSION['stammdaten_id'].'&bdc_ziel=stammdaten',
                            $aendern_modal
                        );
                        if (isset($_POST['pim_lead_php'])) {
                            $newLeadBtn = null;
                        }
                        
                        if (!is_array($table_data)) $table_data = array();
                        $table = Template_Default::Table(
                            $temp,
                            $table_data,
                            $tableOptions,
                            $filter,
                            array(_ID_.'/'._PHASE_, _BETREFF_.'/'._BETREUER_),
                            $newLeadBtn,
                            $pagination,
                            true,
                            '',
                            array(
                            	'filterActiveCount' => $filterActiveCount,
								'resetSearchValueOnCustomerChange' => true
							)
                        );
                        $table->addCustomClass('mb-0');

                        if (isset($_POST['pim_lead_php'])) {
                            Modern_Helper_Request::requestStart();
                            if (isset($_POST['avagpim_vkchancen'])) {
                                echo Template_Default::ModalHeader('Verkaufschancen')->getHtml();
                            } else {
                                echo Template_Default::ModalHeader('Leads')->getHtml();
                            }
                            
                            echo $table->addCustomClass('mb-0')->getHtml();
                            echo Template_Default::cancelModalButton()->getHtml();
                            echo $aendern_modal->getHtml();
                            //echo (isset($_POST['pim_lead_php'])?javas('pim_autoheight_();'):'');
                            exit;
                        } else {
                            $contentSidebar = new Template_ContentSidebar('', new Template_ElementList($table,'pagination_stammdaten_lead1'), null, null);
                            return $contentSidebar->getHtml().$aendern_modal->getHtml();  
                        }
                    }
                
                }
                if ($_SESSION['design_70'] && isset($_POST['leadprozess_id']) && isset($_POST['leadprozess'])) {
                    $breadcrumps_list = array();
                    $breadcrumps_list[] = new Template_Link(_ANFRAGEN_.'/'._LEADUEBERSICHT_, $phs);
                    $breadcrumps_list[] = new Template_Text(_DETAILS_);
                    $contentHeader = new Template_ContentHeader(new Template_Breadcrumps($breadcrumps_list));
                    
                    $card = new Template_Card('', new Template_GridTable($cols_detail), array('border','padding','shadow'));
                    
                    $btn = Template_Button::init('', _ABBRECHEN_)->setAttribute('class', 'close_trigger');
                    return $contentHeader->getHtml().$card->getHtml().$btn->getHtml();
                }
                
                if ($_SESSION['design_70'] && !isset($_POST['leadprozess'])) {
   
                    if (($_SESSION['design_70'] && !isset($_POST['leadprozess']) && isset($_GET['pagination_korr_1']))) {
                        $pagination->create($artkorr_anzahl);
                    }
                    
                    
                    if (($_SESSION['design_70'] && !isset($_POST['leadprozess']) && isset($_GET['pagination_korr_1']))) {
                        $pagination->setRequest('GET', 'pim_modal_inhalt', 'pim.php', array('pagination_korr_1=1&noautotabclick=1'));
                    }
                   //echo 'JUP';
                  //  $table=Template_Default::Table($temp,$table_data_pim,array('sort'=>$sort,'priority'=>$priority,'multiple'=>true),$filter,$search);
                    return $table_data_pim;
                    
                }
 
				return $kftext;
			}// Funktionsende
	
	
	if (isset($_POST['wvlart'])) {
        //$debug->debug('testpim.txt','$_POST[wvlart]');
		include_once('class.overlib.php');
		
		if ($cfg_carlo_appserver_activity) {
			if (!isset($cfg_pim_defkorrart)) {
				$cfg_pim_defkorrart=5;
			}
			if (!isset($cfg_pim_kbes_laenge)) {
				$cfg_pim_kbes_laenge=40;
			}
			//$cfg_pim_erledigt=false;
		}
		
		$ol = new Overlib();
		ob_end_clean();
		ob_start();
		if ($_SESSION['sprache']=='lang_rus.php') {
			header('Content-Type: text/html; charset=Windows-1251');	// koi8-r 	
		} elseif ($_SESSION['sprache']=='lang_kr.php') {
			header('Content-Type: text/html; charset=Windows-1250');
		} elseif ($_SESSION['db_utf8'] or is_file('inc/_gr.php')) {
			header('Content-Type: text/html; charset=UTF-8');
		} else {
			header('Content-Type: text/html; charset=ISO-8859-1');
		}
		
	if ($zeitdebug) {
		echo 'vor Weiterleitung: '.zeitnahme().'<br>';
	}
    if ($_SESSION['leadprozess']=='pim_vkl' && $userid_pim == -1 && !empty($_SESSION['pim_alle_ben_vkl'])) {
        $bens_pim = $_SESSION['pim_alle_ben_vkl'];
    }
    $benutzer_to_see = array();
    if ($userid_pim == -1) {
        if (!empty($bens_pim)) {
            foreach ($bens_pim as $user_id_ => $user_name) {
                $benutzer_to_see[$user_id_] = $user_id_;
            }
        }
    } else {
        $benutzer_to_see = array($userid_pim => $userid_pim);
    }
    foreach ($benutzer_to_see as $user_id_) {
        $weitl=bweiterl($user_id_);
        if ($weitl!='') {
            foreach (explode(',', $weitl) as $ben_weit) {
                $benutzer_to_see[$ben_weit] = $ben_weit;
            }
        }
    }
    if (!empty($benutzer_to_see)) {
       $benutzer_to_see_temp=$benutzer_to_see;
       foreach ($benutzer_to_see_temp as $keyValue) {
           if (!is_numeric($keyValue)) {
               $benutzer_to_see=getUserPimIds($keyValue, $benutzer_to_see);
               unset($benutzer_to_see[$keyValue]);
           }
       }
    }
    
    $where_weitl=' in ('.$db->dbzahlin($benutzer_to_see).')';
    
    if ($zeitdebug) {
		echo 'nach Weiterleitung: '.zeitnahme().'<br>';
	}
	if ($_SESSION['cfg_kunde']=='carlo_kurlaender') {
		$cfg_pim_ergebnishaken=true;
	}
	$awhere='';
	$pnr='';
	
	if (!isset($cfg_ordner_kdokumente_pfad) or $cfg_ordner_kdokumente_pfad=='')
		$cfg_ordner_kdokumente_pfad=$cfg_ordner_kdokumente;
	
	if (isset($_SESSION['kdokpfad']) and $_SESSION['kdokpfad']!='') {
		$cfg_ordner_kdokumente_pfad=$_SESSION['kdokpfad'];
	}
	
	if ($feld2['pnr']) {
		if ($feld2['pnr']=='-1') {
			$awhere='';
			$pnr='';
		} else {
			$pnr=$feld2['pnr'];
			$awhere=' and '.$sql_tabs['korrespondenz']['produktzuordnung_id'].'='.$db->dbzahl($pnr);
		}
	}
	
	if ($feld2['sort']) {
		if ($feld2['sort']=='plz') {
			$sortorder=$sql_tabs['stammdaten_adresse'][$feld2['sort']].' '.$feld2['order'];
		} elseif ($feld2['sort']=='datum' or $feld2['sort']=='wvl_datum1') {
			$sortorder=$sql_tabs['korrespondenz'][$feld2['sort']].' '.$feld2['order'];
/*			if ($feld2['sort']=='wvl_datum1') {
				$awhere.=' and '.$sql_tabs['korrespondenz']['wvl_datum1'].' is not null and '.$sql_tabs['korrespondenz']['wvl_datum1'].'>='.$db->dbdate('01.01.1970');
			}
*/		} else {
			$sortorder=$sql_tabs['korrespondenz']['wvl_datum1'].' desc, '.$sql_tabs['korrespondenz'][$feld2['sort']].' '.$feld2['order'];
		}
	} else
		$sortorder=$sql_tabs['korrespondenz']['wvl_datum1'].' desc, '.$sql_tabs['korrespondenz']['datum'].' desc'; //sortiert nach datum
	
	
	$alle_bens=array();
	$res=$db->select(
		$sql_tab['benutzer'],
		array(
			$sql_tabs['benutzer']['benutzer_id'],
			$sql_tabs['benutzer']['vorname'],
			$sql_tabs['benutzer']['name'],
			$sql_tabs['benutzer']['standard_lagerort']
		)
	);
	while ($row=$db->zeile($res)) {
		$alle_bens[$row[0]]=trim($row[2].', '.$row[1]);
	}
	$merke_awhere='';
		if (($cfg_pim_korr_bis_heute or $_SESSION['cfg_kunde']=='carlo_aag' or $_SESSION['cfg_kunde']=='carlo_kurlaender' or $_SESSION['cfg_kunde']=='carlo_opel_huebner' or $_SESSION['cfg_kunde']=='carlo_opel_linck') and $feld['filterdatum_start']=='' and $feld['filterdatum_ende']=='' and $feld['wfilterdatum_start']=='' and $feld['wfilterdatum_ende']=='') {	// and !isset($feld2['keinlimit'])
		// nur von heute:
/*		$awhere.=' and (('.$sql_tabs['korrespondenz']['datum'].'>='.$db->dbzeitdatum(adodb_date('d.m.Y'), '00:00:00');
		$awhere.=' and '.$sql_tabs['korrespondenz']['datum'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').') or (';
		$awhere.=''.$sql_tabs['korrespondenz']['wvl_datum1'].'>='.$db->dbzeitdatum(adodb_date('d.m.Y'), '00:00:00');
		$awhere.=' and '.$sql_tabs['korrespondenz']['wvl_datum1'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').'))';
*/
		// bis heute:
        if ($_SESSION['leadprozess']!='pim_vkl') {  
            if (isset($cfg_pim_korr_datumtagezurueck) and intval($cfg_pim_korr_datumtagezurueck)>0) {
                $abdat=time()-($cfg_pim_korr_datumtagezurueck*24*60*60);
                $awhere.=' and '.$sql_tabs['korrespondenz']['datum'].' between '.$db->dbtimestamp($abdat).' AND '.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59');
                $awhere.=' and ('.$sql_tabs['korrespondenz']['wvl_datum1'].' between '.$db->dbtimestamp($abdat).' AND '.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').' or '.$sql_tabs['korrespondenz']['wvl_datum1'].' is null)';
                $merke_awhere.=' and '.$sql_tabs['korrespondenz']['datum'].' between '.$db->dbtimestamp($abdat).' AND '.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59');
                $merke_awhere.=' and ('.$sql_tabs['korrespondenz']['wvl_datum1'].' between '.$db->dbtimestamp($abdat).' AND '.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').' or '.$sql_tabs['korrespondenz']['wvl_datum1'].' is null)';

            } else {
                $awhere.=' and '.$sql_tabs['korrespondenz']['datum'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59');
                $awhere.=' and ('.$sql_tabs['korrespondenz']['wvl_datum1'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').' or '.$sql_tabs['korrespondenz']['wvl_datum1'].' is null)';
                $merke_awhere.=' and '.$sql_tabs['korrespondenz']['datum'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59');
                $merke_awhere.=' and ('.$sql_tabs['korrespondenz']['wvl_datum1'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').' or '.$sql_tabs['korrespondenz']['wvl_datum1'].' is null)';
            }
        }
	} else {
        //check
        if ($_SESSION['leadprozess']!='pim_vkl' && (($_SESSION['design_70'] && isset($_GET['pagination_korr_1'])) || !$_SESSION['design_70'])) {        
            if ($feld['filterdatum_start']!='' and p4n_mb_string('strlen',$feld['filterdatum_start'])==10 && !isset($_POST['leadprozess'])) {
                $awhere.=' and '.$sql_tabs['korrespondenz']['datum'].'>='.$db->dbzeitdatum($feld['filterdatum_start'], '00:00:00');
                //$awhere .= ' and ' . $sql_tabs['korrespondenz']['datum'] . ' is not null';
            }
            if ($feld['filterdatum_ende']!='' and p4n_mb_string('strlen',$feld['filterdatum_ende'])==10) {
                $awhere.=' and '.$sql_tabs['korrespondenz']['datum'].'<='.$db->dbzeitdatum($feld['filterdatum_ende'], '23:59:59');
                //$awhere .= ' and ' . $sql_tabs['korrespondenz']['datum'] . ' is not null';
            }
            if ($feld['wfilterdatum_start']!='' and p4n_mb_string('strlen',$feld['wfilterdatum_start'])==10) {
                $awhere.=' and '.$sql_tabs['korrespondenz']['wvl_datum1'].'>='.$db->dbzeitdatum($feld['wfilterdatum_start'], '00:00:00');
                //$awhere .= ' and ' . $sql_tabs['korrespondenz']['wvl_datum1'] . ' is not null';
            }
            if ($feld['wfilterdatum_ende']!='' and p4n_mb_string('strlen',$feld['wfilterdatum_ende'])==10) {
                $awhere.=' and '.$sql_tabs['korrespondenz']['wvl_datum1'].'<='.$db->dbzeitdatum($feld['wfilterdatum_ende'], '23:59:59');
                if ($feld['filterdatum_ende']=='') {
                    $awhere.=' and '.$sql_tabs['korrespondenz']['datum'].'<='.$db->dbzeitdatum($feld['wfilterdatum_ende'], '23:59:59');
                }
            }
        }
	}		//Inside the query
	if ((isset($feld['filter_kart']) and intval($feld['filter_kart'])>=0) && (($_SESSION['design_70'] && isset($_GET['pagination_korr_1'])) || !$_SESSION['design_70'])) {
		$awhere.=' and '.$sql_tabs['korrespondenz']['art'].'='.$db->dbzahl($feld['filter_kart']);
	}
	if ((isset($feld['filter_kamp']) and intval($feld['filter_kamp'])>=0) && (($_SESSION['design_70'] && isset($_GET['pagination_korr_1'])) || !$_SESSION['design_70'])) {
		$awhere.=' and '.$sql_tabs['korrespondenz']['kampagne_id'].'='.$db->dbzahl($feld['filter_kamp']);
	}
	if ((isset($feld['filter_korrkat']) and $feld['filter_korrkat']!='' and $feld['filter_korrkat']!='-1') && (($_SESSION['design_70'] && isset($_GET['pagination_korr_1'])) || !$_SESSION['design_70'])) {
		$awhere.=' and '.$sql_tabs['korrespondenz']['kategorie'].'='.$db->str($feld['filter_korrkat']);
	}
	
	if ($_SESSION['cfg_kunde']=='carlo_kurlaender') {
		$awhere.=' and '.$sql_tabs['korrespondenz']['art'].'!='.$db->dbzahl(9);
	}
		$art=intval($_POST['wvlart']);
		
		if ($art==1) {
			// LE
		} elseif ($art==2) {
			// ERLEDIGT
		} elseif ($art==3) {
			// Makro
		} elseif ($art==4) {
			// Kampagne
		} elseif ($art==5) {
			// pers.WVL
		} elseif ($art==0) {
			// alle
		}
		
		if (is_file('inc/'.$_SESSION['cfg_kunde'].'/pim.html')) {
			$pdatei='inc/'.$_SESSION['cfg_kunde'].'/pim.html';
		} else {
			$pdatei="template/pim.html";
		}
        
        if (isset($_POST['leadprozess'])) {
            $pdatei="template/leadprozess/pim_wvl2.html";
   
         //   include('inc/class_lead_dashboard'.($dashboard_neu?'_1':'').'.php');
          //  $dashboard = new LeadDashboard(true,($dashboard_neu?true:false),true,false);
        }
        
		$keine_leerzeile=1;
		$kftext='';
		if ($inhalt=template($pdatei)) {
			if (preg_match_all("/<!wvl1>(.*)<!wvl2>/Uis", $inhalt, $kblock, PREG_SET_ORDER)) {
				$inhalt=$kblock[0][1];
			}
            if ($_SESSION['design_70']) {
            $inhalt='{block-k-start}{block-k-ende}';
            }
			if ($cfg_avag_teilehandel2021 or $cfg_pim_multiroute) {
				$inhalt=str_replace($lang['_K-STAMMID_'].' </th>', ($cfg_multiroute?'Multiroute ':'').$lang['_K-STAMMID_'].' PLZ {sort-plz}</th>', $inhalt);
				if (preg_match_all("/\{sort\-([^\}]+)/is",$inhalt,$feld_sort,PREG_SET_ORDER)) {
				while (list($key,$val)=@each($feld_sort)) {
					$sv='';
					$merke=$val[1];
					if (p4n_mb_string('substr', $val[1], 0, 1)=='2' and !$t_nicht_sort_para2) {
						$sv='2';
						$val[1]=p4n_mb_string('substr', $val[1], 1);
					}
					if (isset($_GET['keinlimit'])) {
						$getsort_add='keinlimit=1&';
					}
					$inhalt=p4n_mb_string('str_replace', '{sort-'.$merke.'}', link2('', $phs.'?'.$getsort_add.'sort'.$sv.'='.$val[1].'&order=asc', 'pfeil_oben'.(($_GET['sort'.$sv]==$val[1] and $_GET['order']=='asc')?'_a':'').'.gif').link2('', $phs.'?'.$getsort_add.'sort'.$sv.'='.$val[1].'&order=desc', 'pfeil_unten'.(($_GET['sort'.$sv]==$val[1] and $_GET['order']=='desc')?'_a':'').'.gif'), $inhalt);
				}
				}
			}
			$form=new htmlform();
			$dummyx=$form->start('kform_pim', 'pim.php', 'POST', true);
           // $debug->debug('testpim.txt','pim_wvlblock($art); '.'pim_wvlblock('.$art.');');
			pim_wvlblock($art);
		}
        if ($_SESSION['design_70'] && !isset($_POST['leadprozess'])) {
            Modern_Helper_Request::requestStart();
            echo $inhalt70;
            exit;
        }
		if (isset($_POST['leadprozess'])) {
			$_SESSION['slowlog_quelle']='Leadprozess';
			fuss_zeitmesser();
		}
        if ($_SESSION['design_70'] && isset($_POST['leadprozess'])) {
            Modern_Helper_Request::requestStart();
            echo $inhalt;
            $merke_phs=$phs;
            $phs='stammdaten_lead.php';
            echo Template_Trait_Request_Helper::ModalWeiterleitung();
            $phs=$merke_phs;
            exit;
        }
        if ($cfg_modern) {
		echo Modern_Helper_Request::requestParse($inhalt);
        } else {
		echo $inhalt;
		fuss();
        }
        die();
	}
	
	if ($cfg_modern) {
        define('PIMPHP', '1');
    }

    $handbuch = '<span class="handbuch" style="display:none;">'.link2('', 'handbuch_suche.php?source=pim.php', 'overlib.gif', '', 'target="_blank"').'</span>';

	if ($_SESSION['user_id']==1) {
	//	$zeitdebug=true;
	}
	
	include_once("mailconf.php");
	include_once("class.overlib.php");
	include_once('kalender_class.php');
	
	if ($cfg_carlo_appserver_activity) {
			if (!isset($cfg_pim_defkorrart)) {
				$cfg_pim_defkorrart=5;
			}
			if (!isset($cfg_pim_kbes_laenge)) {
				$cfg_pim_kbes_laenge=40;
			}
			//$cfg_pim_erledigt=false;
	}
	
	$def_korrart=0;
	if (isset($cfg_pim_defkorrart)) {
		if ($cfg_pim_defkorrart>0) {
			$def_korrart=$cfg_pim_defkorrart;
		}
	} else if (isset($_SESSION['wvlart'])) {
        $def_korrart=$_SESSION['wvlart'];
    }

if (!isset($lang['_BMART_'])) {
    $lang['_BMART_']=_ART_;
    define('_BMART_', _ART_);
}
         if (isset($getfeld['holemodelle2']) && $getfeld['holemodelle2'] != '' && $cfg_neuanlage_interessent) {
            $sammle2='';
            $to = ob_get_level();
            for ($i = 0; $i < $to; $i++) {
                ob_end_clean();
            }
            $sammle = array();
            $res = $db->select(
                    $sql_tab['kfzzuordnung'], array(
                $sql_tabs['kfzzuordnung']['typmodell']
                    ), $sql_tabs['kfzzuordnung']['markencode'] . ' = ' . $db->str($getfeld['holemodelle2']).' AND '.$sql_tabs['kfzzuordnung']['inaktiv'].' = '.$db->dblogic(false), $sql_tabs['kfzzuordnung']['typmodell'] . ' ASC'
            );
            while ($row = $db->zeile($res)) {
                if (!isset($sammle[$row[0]])) {
                   // $sammle2[]= '<option value="' . (($getfeld['mitmarkencode']=='1' && $row[0]!='' && $row[0]!=-1)?$getfeld['holemodelle2'].' ':'').$row[0] . '">' . (($getfeld['mitmarkencode']=='1' && $row[0]!='' && $row[0]!=-1)?$getfeld['holemodelle2'].' ':'').$row[0] . '</option>';

                    $sammle2.=(($getfeld['mitmarkencode']=='1' && $row[0]!='' && $row[0]!=-1)?$getfeld['holemodelle2'].' ':'').$row[0].'##';
                }
                $sammle[$row[0]] = $row[0];
            }

            echo (($sammle2!='')?p4n_mb_string('substr',$sammle2, 0,-2):'');

            exit;
        }
        
	echo javas('
		var merke=new Array(35);
		var merke2=new Array(35);
		function ze1(zelle, tag) {
			merke[tag]=zelle.style.borderColor;
			merke2[tag]=zelle.style.borderStyle;
			zelle.style.borderColor="#000000";
			zelle.style.borderStyle="solid";
		}
		function ze2(zelle, tag) {
			zelle.style.borderColor=merke[tag];
			zelle.style.borderStyle=merke2[tag];
		}');
	$ol = new Overlib();
	$ol->set("width", 500); 
/*	$ol->set("sticky", true);
	$ol->set("mouseoff", true);
	$ol->set("closetext", _SCHLIESSEN_);
//	$ol->set("fixx", 10);
	$ol->set("vauto", true);
	$ol->set("fixy", 10);
*/	
	$ol->set("hauto", true);
	$ol->set("vauto", true);
	
	if ($_SESSION['cfg_kunde']=='crm_sensus') {
		$lang['_NOTIZ_']='Sales Diary';
	}
	if ($zeitdebug) {
		echo 'Start: '.zeitnahme().'<br>';
	}
	if (!$_SESSION['design_70']) {
        echo '<script type="text/javascript" src="js/mootools.v1.11.js"></script>';
    }
	echo lade_divinhalt('stammdaten_main.php?nav=Uebersicht&kbew=1&id='.$_SESSION['stammdaten_id'], 500, 500, '', true);
	
    if (!$cfg_modern) { echo '<script type="text/javascript" src="js/jquery.min.js"></script>'; }
    if ($cfg_neuanlage_interessent) {
        echo '<script type="text/javascript" src="js/VehicleSelector.js?'.time().'"></script>';
    }
   // if (!$cfg_modern) { echo '<script type="text/javascript" src="js/jquery.jeditable.mini.js"></script>'; }
    echo '<script type="text/javascript" src="js/jquery.jeditable.mini.js"></script>';
		
//	echo '<link rel="stylesheet" href="css/ui-lightness/jquery-ui-1.8.2.custom.css" type="text/css" media="all" />';
    if (!$cfg_modern) { echo '<script type="text/javascript" src="js/jquery-ui.custom.min.js"></script>'; }
	echo '<style>
	.ui-autocomplete {
		max-height: 150px;
		overflow-y: auto;
		overflow-x: hidden;
		padding-right: 20px;
	}
	* html .ui-autocomplete {
		height: 150px;
	}
	</style>';
        if (!$cfg_modern) { echo '<script type="text/javascript">jQuery.noConflict();</script>'; }
                echo '
                   <script type="text/javascript">
                   if (typeof hole_modelle != "function") {
                       function hole_modelle(a, id, zusatz, callback) {
                       try {
                           document.getElementById(id).innerHTML="";
                           if (typeof p4ntoken == "undefined") {p4ntoken="";}
                           var xmlhttp;
                           try { xmlhttp = new XMLHttpRequest(); } catch (error) {
                                   try { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); } catch (error) { return false;	}
                           }
                           if (typeof zusatz == "undefined") {zusatz="";}
                           xmlhttp.open("GET","pim.php?holemodelle2="+a.value+"&p4ntoken="+p4ntoken+zusatz,false);
	
                           xmlhttp.setRequestHeader("X-Requested-With", "XMLHttpRequest");

                           xmlhttp.onreadystatechange=function() {
                               if (xmlhttp.readyState==4 && xmlhttp.status==200) {

                                   if (typeof getNewToken == "function") {
                                       p4ntoken = getNewToken(xmlhttp.getResponseHeader("p4ntoken"));
                                   }

                                   var test=xmlhttp.responseText;
                                   var res = test.split("##"); 

                                   for (var i=0; i<res.length; i++) {
                                       var option = document.createElement("option");
                                       var text = document.createTextNode(res[i]);
                                       option.appendChild(text);
                                       option.setAttribute("value", res[i]);
                                       var select = document.getElementById(id);
                                       select.appendChild(option);
                                   }

                                   if (typeof(callback) == "function") {
                                       callback();
                                   }
                               }
                           }
                           xmlhttp.send();
                       } catch(e) {}
                   }
               }</script>';
        
	// wvl, kalender, gebkurz, geblang, aufgaben, pinnwand, useronline, opp, bm, pm, notizen, tkpwps
	$pim_bloecke=array(
		'wvl' => '<!wvl1><div id="pim_wvl" style="height: auto; overflow: auto;">
<!hl1>_KORRP_ {filterdatum}<!hl2>
{wvl_reiter}
<table><!sbl>
<tr>
	<th>_K-DATUM_ {sort-datum}
	_WVL_ {sort-wvl_datum1}<br>{filt_kamp}</th>
	<th>_K-STAMMID_ </th>
	<th colspan=2>_K-ART_ {filt_art}</th>
	<th>_K-BETREFF_<br>
	_K-BESCHREIBUNG_</th>
	<th>_ERGEBNIS_</th>
</tr>
{block-k-start}
<tr{trzeile}>
	<td>{k_datum}</td>
	<td>{k_stammid}</td>
	<td>{k_art}</td>
	<td>{k_erledigt}</td>
	<td>{k_betreff}<br>
	{k_beschreibung}</td>
	<td>{k_ergebnis}</td>
</tr>
{block-k-ende}
</table>
</div>
<!wvl2>
',
		'kalender' => '<!hl1>_PIM-KALENDER_ {kalender_datum}<!hl2>
{kalender}',
		'gebkurz' => '<!hl1>_GEBURTSTAGSLISTE_<!hl2>
<table>
<tr>
	<th>_K-STAMMID_</th>
<!kfz1>
	<th>_VERKAEUFER_</th>
<!kfz2>
	<th>_K-DATUM_</th>
	<th>_K-ALTER_</th>
</tr>
{block-geb2-start}
<tr{trzeile}>
	<td>{k_stammid}</td>
<!kfz1>
	<td>{k_verk}</td>
<!kfz2>
	<td>{k_datum}</td>
	<td class="r">{k_alter}</td>
</tr>
{block-geb2-ende}
</table>
',
		'geblang' => '<!geblang1>
<!hl1>_GEBURTSTAGSLISTE_<!hl2>
<table>
<tr>
	<th width="30%">_K-STAMMID_</th>
<!kfz1>
	<th>_VERKAEUFER_</th>
<!kfz2>
	<th width="30%">_K-DATUM_</th>
	<th>_K-ALTER_</th>
</tr>
{block-geb-start}
<tr{trzeile}>
	<td>{k_stammid}</td>
<!kfz1>
	<td>{k_verk}</td>
<!kfz2>
	<td>{k_datum}</td>
	<td>{k_alter}</td>
</tr>
{block-geb-ende}
</table><!geblang2>',
		'aufgaben' => '<!hl1>_ADMIN-AUFGABEN_{aufgaben_anzahl}<!hl2>
{aufgaben}
',
		'pinnwand' => '<!hl1>_PIM-PINNWAND_<!hl2>
{pinnwand}
',
		'useronline' => '<!hl1>_PIM-USERONLINE_<!hl2>
<table>
{user_online}
</table>
',
		'opp' => '<!om1><!hl1>_OFFENE_VERKAUFSAKTIVITAETEN_<!hl2>
<table>
<tr>
	<th>_BEZEICHNUNG_</th>
	<th>_K-STAMMID_</th>
	<th>_PHASE_</th>
	<th>_PRODUKT_</th>
	<th>_WSEINTRITT_/_BMPRIORITAET_</th>
	<th>_BENUTZER_</th>
</tr>
{block-om-start}
<tr{trzeile}>
	<td>{om_bezeichnung}</td>
	<td>{om_kunde}</td>
	<td>{om_phase}</td>
	<td>{om_produkt}</td>
	<td>{om_ws} / {om_prio}</td>
	<td>{om_benutzer}</td>
</tr>
{block-om-ende}
</table><!om2>
',
		'bm' => '<!bm1><!hl1>_BMHEADLINE_<!hl2>
<table>
<tr>
	<th>_DATUM-EINTRAG_</th>
	<th>_K-STAMMID_</th>
	<th>_BEZEICHNUNG_</th>
	<th>_PRODUKT_</th>
	<th>_STATUS_</th>
	<th>'._BMART_.'</th>
</tr>
{block-bm-start}
<tr{trzeile}>
	<td>{bm_datum}</td>
	<td>{bm_kunde}</td>
	<td>{bm_bezeichnung}</td>
	<td>{bm_produkt}</td>
	<td>{bm_status}</td>
	<td>{bm_art}</td>
</tr>
{block-bm-ende}
</table><!bm2>
',
		'pm' => '<!pm1><!hl1>_PMHEADLINE_<!hl2>
<table>
<tr>
	<th>_BEZEICHNUNG_</th>
	<th>_K-STAMMID_</th>
	<th>_STATUS_</th>
	<th>_PRODUKT_</th>
	<th>_BEGINN_</th>
	<th>_ENDE_</th>
</tr>
{block-pm-start}
<tr{trzeile}>
	<td>{pm_bezeichnung}</td>
	<td>{pm_kunde}</td>
	<td>{pm_status}</td>
	<td>{pm_produkt}</td>
	<td>{pm_beginn}</td>
	<td>{pm_ende}</td>
</tr>
{block-pm-ende}
</table><!pm2>
',
		'notizen' => '<!hl1>_NOTIZ_ {notiz_datum}<!hl2>
{notizen}
',
		'tkpwps' => '<!hl1>_WERKSTATT_<!hl2>
{tkp_termine}
',
		'filter' => '<!hl1>_FILTER_<!hl2>
{pim_filter}
',
		'verkaufsvorgabe' => '{pim_verkaufsvorgabe}
',
		'news' => '{pim_news}
',
		'letztenkunden' => '{pim_letztenkunden}
',
'tkpwps2' => '<!hl1>_WERKSTATT_ (_BENUTZER_KEIN_LOGIN_)<!hl2>
{tkp_termine2}
'
	);
    if ($cfg_modern) {
        $pim_bloecke=array(
		'wvl' => '<!wvl1><div id="pim_wvl" class="table-margin-bottom" style="height: auto; overflow: auto;">
{filterdatum}
{TableFilterListe}
<div id="TableFilterListe">
<table class="table-ignore2 moderntable"><!sbl>
<tr>
	<th class="th">_K-DATUM_ {sort-datum} _WVL_ {sort-wvl_datum1}<br></th>
	<th class="th">_K-STAMMID_ </th>
	<th class="th" colspan="2">_K-ART_</th>
	<th class="th">_K-BETREFF_ / _K-BESCHREIBUNG_</th>
	<th class="th">_ERGEBNIS_</th>
</tr>
{block-k-start}
<tr{trzeile} {oddeven}>
	<td class="td">{k_datum}</td>
	<td class="td">{k_stammid}</td>
	<td class="td">{k_art}</td>
    <td class="td">{k_erledigt}</td>
	<td class="td">{k_betreff}<br>{k_beschreibung}</td>
	<td class="td">{k_ergebnis}</td>
</tr>
{block-k-ende}
</table>
</div>
</div>
<!wvl2>
',
		'kalender' => '<!hl1>_PIM-KALENDER_ <div id="kalender_datum_div" style="display:inline">{kalender_datum}</div><!hl2>
<div id="kalender_div">{kalender}</div>',
		'gebkurz' => '<!hl1>_GEBURTSTAGSLISTE_<!hl2>
<table class="table-ignore2 moderntable table-margin-bottom">
<tr>
	<th  class="th">_K-STAMMID_</th>
<!kfz1>
	<th  class="th">_VERKAEUFER_</th>
<!kfz2>
	<th  class="th">_K-DATUM_</th>
	<th  class="th">_K-ALTER_</th>
</tr>
{block-geb2-start}
<tr{trzeile} {oddeven}>
	<td class="td">{k_stammid}</td>
<!kfz1>
	<td class="td">{k_verk}</td>
<!kfz2>
	<td class="td">{k_datum}</td>
	<td class="td r">{k_alter}</td>
</tr>
{block-geb2-ende}
</table>
',
		'geblang' => '<!geblang1>
<!hl1>_GEBURTSTAGSLISTE_<!hl2>
<table class="table-ignore2 moderntable table-margin-bottom">
<tr>
	<th width="30%" class="th">_K-STAMMID_</th>
<!kfz1>
	<th  class="th">_VERKAEUFER_</th>
<!kfz2>
	<th width="30%"  class="th">_K-DATUM_</th>
	<th  class="th">_K-ALTER_</th>
</tr>
{block-geb-start}
<tr{trzeile} {oddeven}>
	<td class="td">{k_stammid}</td>
<!kfz1>
	<td class="td">{k_verk}</td>
<!kfz2>
	<td class="td">{k_datum}</td>
	<td class="td">{k_alter}</td>
</tr>
{block-geb-ende}
</table><!geblang2>',
		'aufgaben' => '<!hl1>_ADMIN-AUFGABEN_{aufgaben_anzahl}<!hl2>
{aufgaben}
',
		'pinnwand' => '<!hl1>_PIM-PINNWAND_<!hl2>
{pinnwand}
',
		'useronline' => '<!hl1>_PIM-USERONLINE_<!hl2>
<table class="table-ignore2 moderntable table-margin-bottom">
{user_online}
</table>
',
		'opp' => '<!om1><!hl1>_OFFENE_VERKAUFSAKTIVITAETEN_<!hl2>
<div class="scrolling table-margin-bottom">
<table class="table-ignore2 moderntable table-nohover">
<tr>
	<th class="th">_BEZEICHNUNG_</th>
	<th class="th">_K-STAMMID_</th>
	<th class="th">_PHASE_</th>
	<th class="th">_PRODUKT_</th>
	<th class="th">_WSEINTRITT_/_BMPRIORITAET_</th>
	<th class="th">_BENUTZER_</th>
</tr>
{block-om-start}
<tr{trzeile}>
	<td class="td">{om_bezeichnung}</td>
	<td class="td">{om_kunde}</td>
	<td class="td">{om_phase}</td>
	<td class="td">{om_produkt}</td>
	<td class="td">{om_ws} / {om_prio}</td>
	<td class="td">{om_benutzer}</td>
</tr>
{block-om-ende}
</table>
</div><!om2>
',
		'bm' => '<!bm1><!hl1>_BMHEADLINE_<!hl2>
<div class="scrolling table-margin-bottom">
<table class="table-ignore2 moderntable table-nohover">
<tr>
	<th class="th">_DATUM-EINTRAG_</th>
	<th class="th">_K-STAMMID_</th>
	<th class="th">_BEZEICHNUNG_</th>
	<th class="th">_PRODUKT_</th>
	<th class="th">_STATUS_</th>
	<th class="th">'._BMART_.'</th>
</tr>
{block-bm-start}
<tr {oddeven} {trzeile}>
	<td class="td nowrap">{bm_datum}</td>
	<td class="td">{bm_kunde}</td>
	<td class="td">{bm_bezeichnung}</td>
	<td class="td">{bm_produkt}</td>
	<td class="td">{bm_status}</td>
	<td class="td">{bm_art}</td>
</tr>
{block-bm-ende}
</table></div><!bm2>
',
		'pm' => '<!pm1><!hl1>_PMHEADLINE_<!hl2>
<div class="scrolling table-margin-bottom">
<table class="table-ignore2 moderntable table-nohover">
<tr>
	<th class="th">_BEZEICHNUNG_</th>
	<th class="th">_K-STAMMID_</th>
	<th class="th">_STATUS_</th>
	<th class="th">_PRODUKT_</th>
	<th class="th">_BEGINN_</th>
	<th class="th">_ENDE_</th>
</tr>
{block-pm-start}
<tr{trzeile} {oddeven}>
	<td class="td">{pm_bezeichnung}</td>
	<td class="td">{pm_kunde}</td>
	<td class="td">{pm_status}</td>
	<td class="td">{pm_produkt}</td>
	<td class="td">{pm_beginn}</td>
	<td class="td">{pm_ende}</td>
</tr>
{block-pm-ende}
</table></div><!pm2>
',
		'notizen' => '<!hl1>_NOTIZ_ {notiz_datum}<!hl2>
{notizen}
',
		'tkpwps' => '<!hl1>_WERKSTATT_<!hl2>
{tkp_termine}
',
		'filter' => '<!hl1>_FILTER_<!hl2>
{pim_filter}
', // Pim bl�cke Flag
		'lead_pim' => '
		<script>
			jq1112(document).ready(function () {
				RequestHelper2("POST", "leadprozess.php", "just_show_table=1", function (response) {
					jq1112("#leadList").html(response);
				});
			});
		</script>	
		
		<div id="leadList"></div>
',
		'verkaufsvorgabe' => '{pim_verkaufsvorgabe}
',
		'news' => '{pim_news}
',
		'letztenkunden' => '{pim_letztenkunden}
',
'tkpwps2' => '<!hl1>_WERKSTATT_ (_BENUTZER_KEIN_LOGIN_)<!hl2>
{tkp_termine2}
'
	); //Here is the beef Flag
        if ($_SESSION['crm_version'] > 64) {
            $pim_bloecke['bm'] = '<!bm1><div id="pim_bm" class="table-margin-bottom" style="height: auto;">
{BMFilter}
<div id="BMFilter" style="overflow-x:scroll">
<table class="table-ignore2 moderntable table-nohover">
<tr>
	<th class="th">_DATUM-EINTRAG_ {sort-2datum}</th>
	<th class="th">_LETZTE_AENDERUNG_ {sort-2letzte_aenderung}</th>
	<th class="th">_K-STAMMID_</th>
	<th class="th">_BEZEICHNUNG_</th>
	<th class="th">_PRODUKT_</th>
	<th class="th">_STATUS_</th>
	<th class="th">_BMART_ / _TYP_</th>
</tr>
{block-bm-start}
<tr {oddeven} {trzeile}>
	<td class="td nowrap">{bm_datum}</td>
	<td class="td nowrap">{bm_letzte_aenderung}</td>
	<td class="td">{bm_kunde}</td>
	<td class="td">{bm_bezeichnung}</td>
	<td class="td">{bm_produkt}</td>
	<td class="td">{bm_status}</td>
	<td class="td">{bm_art}</td>
</tr>
{block-bm-ende}
</table>
</div>
</div>
<!bm2>';
        }
    }
	if ($cfg_neustyle) {
			$pim_bloecke=array(
		'wvl' => '<!shd1><!wvl1><div id="pim_wvl" style="height: auto; overflow: auto;">
<!hl1>_KORRP_ {filterdatum}<!hl2>
{wvl_reiter}
<table><!sbl>
<tr>
	<th>_K-DATUM_ {sort-datum}
	_WVL_ {sort-wvl_datum1}<br>{filt_kamp}</th>
	<th>_K-STAMMID_ </th>
	<th colspan=2>_K-ART_ {filt_art}</th>
	<th>_K-BETREFF_<br>
	_K-BESCHREIBUNG_</th>
	<th>_ERGEBNIS_</th>
</tr>
{block-k-start}
<tr{trzeile}>
	<td>{k_datum}</td>
	<td>{k_stammid}</td>
	<td>{k_art}</td>
	<td>{k_erledigt}</td>
	<td>{k_betreff}<br>
	{k_beschreibung}</td>
	<td>{k_ergebnis}</td>
</tr>
{block-k-ende}
</table>
</div>
<!wvl2><!shd2>
',
		'kalender' => '<!shd1><!hl1>_PIM-KALENDER_ {kalender_datum}<!hl2>
{kalender}<!shd2>',
		'gebkurz' => '<!shd1><!hl1>_GEBURTSTAGSLISTE_<!hl2>
<table><!sbl>
<tr>
	<th>_K-STAMMID_</th>
<!kfz1>
	<th>_VERKAEUFER_</th>
<!kfz2>
	<th>_K-DATUM_</th>
	<th>_K-ALTER_</th>
</tr>
{block-geb2-start}
<tr{trzeile}>
	<td>{k_stammid}</td>
<!kfz1>
	<td>{k_verk}</td>
<!kfz2>
	<td>{k_datum}</td>
	<td class="r">{k_alter}</td>
</tr>
{block-geb2-ende}
</table><!shd2>
',
		'geblang' => '<!geblang1>
<!shd1><!hl1>_GEBURTSTAGSLISTE_<!hl2>
<table><!sbl>
<tr>
	<th width="30%">_K-STAMMID_</th>
<!kfz1>
	<th>_VERKAEUFER_</th>
<!kfz2>
	<th width="30%">_K-DATUM_</th>
	<th>_K-ALTER_</th>
</tr>
{block-geb-start}
<tr{trzeile}>
	<td>{k_stammid}</td>
<!kfz1>
	<td>{k_verk}</td>
<!kfz2>
	<td>{k_datum}</td>
	<td>{k_alter}</td>
</tr>
{block-geb-ende}
</table><!shd2><!geblang2>',
		'aufgaben' => '<!shd1><!hl1>_ADMIN-AUFGABEN_{aufgaben_anzahl}<!hl2>
{aufgaben}<!shd2>
',
		'pinnwand' => '<!shd1><!hl1>_PIM-PINNWAND_<!hl2>
{pinnwand}<!shd2>
',
		'useronline' => '<!shd1><!hl1>_PIM-USERONLINE_<!hl2>
<table><!sbl>
{user_online}
</table><!shd2>
',
		'opp' => '<!om1><!shd1><!hl1>_OFFENE_VERKAUFSAKTIVITAETEN_<!hl2>
<table><!sbl>
<tr>
	<th>_BEZEICHNUNG_</th>
	<th>_K-STAMMID_</th>
	<th>_PHASE_</th>
	<th>_PRODUKT_</th>
	<th>_WSEINTRITT_/_BMPRIORITAET_</th>
	<th>_BENUTZER_</th>
</tr>
{block-om-start}
<tr{trzeile}>
	<td>{om_bezeichnung}</td>
	<td>{om_kunde}</td>
	<td>{om_phase}</td>
	<td>{om_produkt}</td>
	<td>{om_ws} / {om_prio}</td>
	<td>{om_benutzer}</td>
</tr>
{block-om-ende}
</table><!shd2><!om2>
',
		'bm' => '<!bm1><!shd1><!hl1>_BMHEADLINE_<!hl2>
<table><!sbl>
<tr>
	<th>_DATUM-EINTRAG_</th>
	<th>_K-STAMMID_</th>
	<th>_BEZEICHNUNG_</th>
	<th>_PRODUKT_</th>
	<th>_STATUS_</th>
	<th>'._BMART_.'</th>
</tr>
{block-bm-start}
<tr{trzeile}>
	<td>{bm_datum}</td>
	<td>{bm_kunde}</td>
	<td>{bm_bezeichnung}</td>
	<td>{bm_produkt}</td>
	<td>{bm_status}</td>
	<td>{bm_art}</td>
</tr>
{block-bm-ende}
</table><!shd2><!bm2>
',
		'pm' => '<!pm1><!shd1><!hl1>_PMHEADLINE_<!hl2>
<table><!sbl>
<tr>
	<th>_BEZEICHNUNG_</th>
	<th>_K-STAMMID_</th>
	<th>_STATUS_</th>
	<th>_PRODUKT_</th>
	<th>_BEGINN_</th>
	<th>_ENDE_</th>
</tr>
{block-pm-start}
<tr{trzeile}>
	<td>{pm_bezeichnung}</td>
	<td>{pm_kunde}</td>
	<td>{pm_status}</td>
	<td>{pm_produkt}</td>
	<td>{pm_beginn}</td>
	<td>{pm_ende}</td>
</tr>
{block-pm-ende}
</table><!shd2><!pm2>
',
		'notizen' => '<!shd1><!hl1>_NOTIZ_ {notiz_datum}<!hl2>
{notizen}<!shd2>
',
		'tkpwps' => '<!shd1><!hl1>_WERKSTATT_<!hl2>
{tkp_termine}<!shd2>
',
		'filter' => '<!shd1><!hl1>_FILTER_<!hl2>
{pim_filter}<!shd2>
',
		'verkaufsvorgabe' => '<!shd1>{pim_verkaufsvorgabe}<!shd2>
',
		'news' => '<!shd1>{pim_news}<!shd2>
',
		'letztenkunden' => '<!shd1>{pim_letztenkunden}<!shd2>
'
	);
    if ($carlo_tw && $cfg_vw) {
        // shd tags are already used in the table generator used for pim reminders
        // which is why they are not here.
        $pim_bloecke['pim_reminders']  = '{pim_reminders}';
	}
	}
	
	if ($cfg_pim_externeangebote) {
		$pim_bloecke['externe_ang']  = '{pim_externe_ang}';
	}
	
	if ($zeitdebug) {
		echo 'WPS 1: '.zeitnahme().'<br>';
	}
	if (!isset($_SESSION['pimhatwps'])) {
		$res4=$db->select(
			$sql_tab['einstellungen'],
			$sql_tabs['einstellungen']['wert'],
			$sql_tabs['einstellungen']['modul'].'='.$db->str('hatwpstkp')
		);
		if ($row4=$db->zeile($res4)) {
			if ($row4[0]=='1') {
				$_SESSION['pimhatwps']=1;
			} else {
				$_SESSION['pimhatwps']=0;
			}
		} else {
			$res=$db->select(
				$sql_tab['korrespondenz'],
				'count(*)',
				$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('WPS Termin').' or '.$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('TKP Termin').' or '.$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('WS Termin').' or '.$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('Workshop')
			);
			$row=$db->zeile($res);
			if (intval($row[0])==0) {
				$db->insert(
					$sql_tab['einstellungen'],
					array(
						$sql_tabs['einstellungen']['modul'] => $db->str('hatwpstkp'),
						$sql_tabs['einstellungen']['wert'] => $db->str('0')
					)
				);
				$_SESSION['pimhatwps']=0;
			} else {
				$db->insert(
					$sql_tab['einstellungen'],
					array(
						$sql_tabs['einstellungen']['modul'] => $db->str('hatwpstkp'),
						$sql_tabs['einstellungen']['wert'] => $db->str('1')
					)
				);
				$_SESSION['pimhatwps']=1;
			}
		}
	}
	if ($zeitdebug) {
		echo 'WPS 2: '.zeitnahme().'<br>';
	}
	if ($_SESSION['pimhatwps']==0) {
		unset($pim_blockinfo['tkpwps']);
	}
	if ($cfg_pim_ohne_geburtstag_lang) {
		unset($pim_blockinfo['geblang']);
	}
	if ($cfg_om_inpim and p4n_mb_string('strstr',$_SESSION['rechte_reiter'], 'nav=OM')) {
		
	} else {
		unset($pim_blockinfo['opp']);
	}
	if (!p4n_mb_string('strstr',$_SESSION['rechte_reiter'], 'nav=PM')) {
		unset($pim_blockinfo['pm']);
	}
	if (!p4n_mb_string('strstr',$_SESSION['rechte_reiter'], 'nav=BM')) {
		unset($pim_blockinfo['bm']);
	}
    if ($_SESSION['design_70'] && is_file('inc/lib_sn.php') && $cfg_avag_de) {
		$pim_bloecke['avagpim_vkchancen']  = '';
        $pim_bloecke['avagpim_offang']  = '';
        $pim_bloecke['avagpim_leasingauslauf']  = '';
	}
    
    $hbAssignment = array(
        'kalender'   => '_PIM-KALENDER_',
        'gebkurz'    => '_GEBURTSTAGSLISTE_',
        'geblang'    => '_GEBURTSTAGSLISTE_',
        'aufgaben'   => '_ADMIN-AUFGABEN_',
        'pinnwand'   => '_PIM-PINNWAND_',
        'useronline' => '_PIM-USERONLINE_',
        'opp'        => '_OFFENE_VERKAUFSAKTIVITAETEN_',
        'bm'         => '_BMHEADLINE_',
        'pm'         => '_PMHEADLINE_',
        'notizen'    => '_NOTIZ_',
        'tkpwps'     => '_WERKSTATT_',
        'filter'     => '_FILTER_',
		'lead_pim' 	 => '_LEAD_',
		'lead_vkl_pim' => '_LEAD_ VKL'
    );

	if ($_SESSION['crm_version'] > 64) {
	    unset($hbAssignment['bm']);
    }
    
    if ($_SESSION['design_70']) {
	    unset($hbAssignment['gebkurz']);
    }
    
    if ($_SESSION['design_70'] && is_file('inc/lib_sn.php') && $cfg_avag_de) {
	    $hbAssignment['avagpim_vkchancen']='Verkaufschancen';
        $hbAssignment['avagpim_offang']='offene Angebote2';
        $hbAssignment['avagpim_leasingauslauf']='Leasingausl�ufer';
    }
	//Bloecke assignment Flag
	debug_logging('$pim_bloecke: '.print_r($pim_bloecke,true));
	@reset($pim_bloecke);
	while (list($key, $val)=@each($pim_bloecke)) {
	    $title = $hbAssignment[$key];
        $val = p4n_mb_string('str_replace', $title, $title.'{handbuch}', $val);
		$pim_bloecke[$key]=template($val, true);
			if ($cfg_avag_teilehandel2021 or $cfg_pim_multiroute) {
				$pim_bloecke[$key]=str_replace($lang['_K-STAMMID_'].' </th>', ($cfg_multiroute?'Multiroute ':'').$lang['_K-STAMMID_'].' PLZ {sort-plz}</th>', $pim_bloecke[$key]);
				if (preg_match_all("/\{sort\-([^\}]+)/is",$pim_bloecke[$key],$feld_sort,PREG_SET_ORDER)) {
				while (list($keyx,$valx)=@each($feld_sort)) {
					$sv='';
					$merke=$valx[1];
					if (p4n_mb_string('substr', $valx[1], 0, 1)=='2' and !$t_nicht_sort_para2) {
						$sv='2';
						$valx[1]=p4n_mb_string('substr', $valx[1], 1);
					}
					if (isset($_GET['keinlimit'])) {
						$getsort_add='keinlimit=1&';
					}
					$pim_bloecke[$key]=p4n_mb_string('str_replace', '{sort-'.$merke.'}', link2('', $phs.'?'.$getsort_add.'sort'.$sv.'='.$valx[1].'&order=asc', 'pfeil_oben'.(($_GET['sort'.$sv]==$valx[1] and $_GET['order']=='asc')?'_a':'').'.gif').link2('', $phs.'?'.$getsort_add.'sort'.$sv.'='.$valx[1].'&order=desc', 'pfeil_unten'.(($_GET['sort'.$sv]==$valx[1] and $_GET['order']=='desc')?'_a':'').'.gif'), $pim_bloecke[$key]);
				}
				}
			}
	}
	@reset($pim_bloecke);
	$pb_inh=$pim_bloecke;
    	
    if ($_SESSION['leadprozess']=='pim_vkl' && $userid_pim == -1 && !empty($_SESSION['pim_alle_ben_vkl'])) {
        $bens_pim = $_SESSION['pim_alle_ben_vkl'];
    } 
    $benutzer_to_see=array();
    if ($userid_pim == -1) {
        if (!empty($bens_pim)) {
            foreach ($bens_pim as $user_id_ => $user_name) {
                $benutzer_to_see[$user_id_] = $user_id_;
            }
        }
    } else {
        $benutzer_to_see = array($userid_pim => $userid_pim);
    }
    foreach ($benutzer_to_see as $user_id_) {
        $weitl=bweiterl($user_id_);
        if ($weitl!='') {
            foreach (explode(',', $weitl) as $ben_weit) {
                $benutzer_to_see[$ben_weit] = $ben_weit;
            }
        }
    }

    if ($zeitdebug) {
        echo 'nach Weiterleitung: '.zeitnahme().'<br>';
    }
//	$where_weitl='='.$db->dbzahl($user);
//	$where_weitl_tkp='='.$db->dbzahl($userid_pim);
//	if ($weitl!='') {
    $where_weitl=' in ('.$db->dbzahlin($benutzer_to_see).')';
    $where_weitl_tkp=' in ('.$db->dbzahlin($benutzer_to_see).')';
//	}
    if ($cfg_pim_tkp_vk_nur_std_lao) {
		$ist_verkauf=false;
		$res=$db->select(
			$sql_tab['benutzer_gruppe'],
			$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
			$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('Verkauf')
		);
		if ($row=$db->zeile($res)) {
			$res=$db->select(
				$sql_tab['benutzer_gruppe_zuordnung'],
				$sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'],
				$sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row[0]).' and '.
					$sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'].'='.$db->dbzahl($userid_pim)
			);
			if ($row=$db->zeile($res)) {
				$ist_verkauf=true;
			}
		}
		if ($ist_verkauf) {
			$alle_tkpvkb=$userid_pim.',';
			$standard_lao=-99;
			$res4=$db->select(
					$sql_tab['benutzer'],
					array(
						$sql_tabs['benutzer']['benutzer_id'],
						$sql_tabs['benutzer']['vorname'],
						$sql_tabs['benutzer']['name'],
						$sql_tabs['benutzer']['standard_lagerort']
					),
					$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($userid_pim)
			);
			if ($row4=$db->zeile($res4)) {
				if (intval($row4[3])>0) {
					$standard_lao=intval($row4[3]);
					$res=$db->select(
							$sql_tab['benutzer'],
							array(
								$sql_tabs['benutzer']['benutzer_id'],
								$sql_tabs['benutzer']['vorname'],
								$sql_tabs['benutzer']['name'],
								$sql_tabs['benutzer']['standard_lagerort']
							),
							$sql_tabs['benutzer']['standard_lagerort'].'='.$db->dbzahl($standard_lao)
					);
					while ($row=$db->zeile($res)) {
						$alle_tkpvkb.=$row[0].',';
					}
				}
			}
			$alle_tkpvkb=substr($alle_tkpvkb, 0, -1);
			$where_weitl_tkp=' in ('.$db->dbzahlin($alle_tkpvkb).')';
		}
	}
    if ($cfg_pim_tkp_vkleiter_nur_std_lao or $cfg_pim_tkp_vkleiter_stdlao_ausw_lao) {
		$vkleiter=false;
		$res=$db->select(
			$sql_tab['benutzer_gruppe'],
			$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
			$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('Verkaufsleiter')
		);
		if ($row=$db->zeile($res)) {
			$res=$db->select(
				$sql_tab['benutzer_gruppe_zuordnung'],
				$sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'],
				$sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row[0]).' and '.
					$sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'].'='.$db->dbzahl($userid_pim)
			);
			if ($row=$db->zeile($res)) {
				$vkleiter=true;
			}
		}
		if ($vkleiter and $cfg_pim_tkp_vkleiter_stdlao_ausw_lao) {
			$alle_tkpvkb=$userid_pim.',';
			if ($_SESSION['benutzer_mandant_auswertung']!='-1' and $_SESSION['benutzer_mandant_auswertung']!='-2' and $_SESSION['benutzer_mandant_auswertung']!='') {
				$res4=$db->select(
					$sql_tab['benutzer'],
					array(
						$sql_tabs['benutzer']['benutzer_id'],
						$sql_tabs['benutzer']['vorname'],
						$sql_tabs['benutzer']['name'],
						$sql_tabs['benutzer']['standard_lagerort']
					),
					$sql_tabs['benutzer']['standard_lagerort'].' in ('.$_SESSION['benutzer_mandant_auswertung'].')'
				);
				while ($row4=$db->zeile($res4)) {
					$alle_tkpvkb.=$row4[0].',';
				}
			}
			$alle_tkpvkb=substr($alle_tkpvkb, 0, -1);
			$where_weitl_tkp=' in ('.$db->dbzahlin($alle_tkpvkb).')';
		} elseif ($vkleiter) {
			$alle_tkpvkb=$userid_pim.',';
			$standard_lao=-99;
			$res4=$db->select(
					$sql_tab['benutzer'],
					array(
						$sql_tabs['benutzer']['benutzer_id'],
						$sql_tabs['benutzer']['vorname'],
						$sql_tabs['benutzer']['name'],
						$sql_tabs['benutzer']['standard_lagerort']
					),
					$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($userid_pim)
			);
			if ($row4=$db->zeile($res4)) {
				if (intval($row4[3])>0) {
					$standard_lao=intval($row4[3]);
					$res=$db->select(
							$sql_tab['benutzer'],
							array(
								$sql_tabs['benutzer']['benutzer_id'],
								$sql_tabs['benutzer']['vorname'],
								$sql_tabs['benutzer']['name'],
								$sql_tabs['benutzer']['standard_lagerort']
							),
							$sql_tabs['benutzer']['standard_lagerort'].'='.$db->dbzahl($standard_lao)
					);
					while ($row=$db->zeile($res)) {
						$alle_tkpvkb.=$row[0].',';
					}
				}
			}
			$alle_tkpvkb=substr($alle_tkpvkb, 0, -1);
			$where_weitl_tkp=' in ('.$db->dbzahlin($alle_tkpvkb).')';
		}
	}
	if ($zeitdebug) {
		echo 'nach VKL: '.zeitnahme().'<br>';
	}
	
	$nurgeb=false;
	if ($getfeld['gebliste']=='1') {
		$nurgeb=true;
	}
	
	$ist_pimadmin=false;
	if ($_SESSION['user_gruppe']<2) {
				$res7=$db->select(
					$sql_tab['benutzer_gruppe'],
					array(
						$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
						$sql_tabs['benutzer_gruppe']['bezeichnung']
					),
					$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('PIM-Administrator')
				);
				if ($row7=$db->zeile($res7)) {
					if ($_SESSION['rechte_bgruppen']=='-1' or preg_match('/,'.$row7[0].',/', ','.$_SESSION['rechte_bgruppen'].',')) {
						$ist_pimadmin=true;
					}
				}
	} else {
		$ist_pimadmin=true;
	}
	if ($ist_pimadmin and isset($getfeld['abm'])) {
		$auth=new auth();
		$auth->logout($getfeld['abm']);
		/*$db->delete(
			$sql_tab['useronline'],
			$sql_tabs['useronline']['benutzer_id'].'='.$db->dbzahl($getfeld['abm'])
		);*/
	}
    if ($ist_pimadmin && isset($getfeld['abm_alle']) && $getfeld['abm_alle']==$_SESSION['user_id']) {
        $db->delete(
			$sql_tab['useronline'],
			$sql_tabs['useronline']['benutzer_id'].'!='.$db->dbzahl($getfeld['abm_alle'])
		);
    }
    $stundenlimit=2;
    if (isset($cfg_lizenzcheck_stundeninaktiv)) {
        if ($cfg_lizenzcheck_stundeninaktiv>0) {//Somit auch 0.5 moeglich
            $stundenlimit=$cfg_lizenzcheck_stundeninaktiv;
        }
    }
    if ($ist_pimadmin && isset($getfeld['abm_inaktiv']) && $getfeld['abm_inaktiv']==$_SESSION['user_id']) {
        $db->delete(
			$sql_tab['useronline'],
			$sql_tabs['useronline']['benutzer_id'].'!='.$db->dbzahl($getfeld['abm_inaktiv']).' and '.
            $sql_tabs['useronline']['datum'].'<'.$db->dbtimestamp(time()-(60*2))
		);
    }
	
	if ($_SESSION['cfg_kunde']=='carlo_kurlaender') {
		$cfg_pim_ergebnishaken=true;
	}
	
	$awhere='';
	$pnr='';
	
	if (!isset($cfg_ordner_kdokumente_pfad) or $cfg_ordner_kdokumente_pfad=='')
		$cfg_ordner_kdokumente_pfad=$cfg_ordner_kdokumente;
	
	if (isset($_SESSION['kdokpfad']) and $_SESSION['kdokpfad']!='') {
		$cfg_ordner_kdokumente_pfad=$_SESSION['kdokpfad'];
	}
	
/*	
	if (!isset($_SESSION['stammdaten_id'])) {
		$res=$db->select(
			$sql_tab['stammdaten'],
			$sql_tabs['stammdaten']['id']
		);
		if ($row=$db->zeile($res)) {
			$_SESSION['stammdaten_id']=$row[0];
		}
	}
*/	
	
	if ($feld['submit']==_PIM_ERLEDIGT_) {
		while (list($key, $val)=@each($feld['cb_erl'])) {
			$res=$db->update(
				$sql_tab['korrespondenz'],
				array(
					$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
					$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
					$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($userid_pim)
				),
				$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($key)
			);
		}
	}
	
	if (isset($feld2['aufgabe_erledigt'])) {
		$res=$db->select(
			$sql_tab['aufgaben'],
			$sql_tabs['aufgaben']['korrespondenz_id'],
			$sql_tabs['aufgaben']['aufgaben_id'].'='.$db->dbzahl($feld2['aufgabe_erledigt'])
		);
		if ($row=$db->zeile($res)) {
			if (intval($row[0])>0) {
				$db->update(
					$sql_tab['korrespondenz'],
					array(
						$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
						$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
						$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($_SESSION['user_id'])
					),
					$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($row[0])
				);
			}
		}
		$res=$db->update(
			$sql_tab['aufgaben'],
			array(
				$sql_tabs['aufgaben']['erledigt'] => $db->dblogic(true)
			),
			$sql_tabs['aufgaben']['aufgaben_id'].'='.$db->dbzahl($feld2['aufgabe_erledigt']).' and '.
				$sql_tabs['aufgaben']['benutzer_id'].$where_weitl
		);
	}
	
	if ($feld2['loesch']) {
		$res=$db->delete(
			$sql_tab['korrespondenz'],
			$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($feld2['loesch'])
		);
		if ($res>0) {
			$refresh=true;
			$mess->add(_KGELOESCHT_);
		}
	}
	
	if ($feld2['erledigt']) {
		$res=$db->update(
			$sql_tab['korrespondenz'],
			array(
				$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
				$sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
				$sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($userid_pim)
			),
			$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($feld2['erledigt'])
		);
	}
	if ($feld2['unerledigt']) {
		$res=$db->update(
			$sql_tab['korrespondenz'],
			array(
				$sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(false)
			),
			$sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($feld2['unerledigt'])
		);
	}
	
	
	if ($feld2['pnr']) {
		if ($feld2['pnr']=='-1') {
			$awhere='';
			$pnr='';
		} else {
			$pnr=$feld2['pnr'];
			$awhere=' and '.$sql_tabs['korrespondenz']['produktzuordnung_id'].'='.$db->dbzahl($pnr);
		}
	}
	
	if ($feld2['sort']) {
		if ($feld2['sort']=='plz') {
			$sortorder=$sql_tabs['stammdaten_adresse'][$feld2['sort']].' '.$feld2['order'];
		} elseif ($feld2['sort']=='datum' or $feld2['sort']=='wvl_datum1') {
			$sortorder=$sql_tabs['korrespondenz'][$feld2['sort']].' '.$feld2['order'];
/*			if ($feld2['sort']=='wvl_datum1') {
				$awhere.=' and '.$sql_tabs['korrespondenz']['wvl_datum1'].' is not null and '.$sql_tabs['korrespondenz']['wvl_datum1'].'>='.$db->dbdate('01.01.1970');
			}
*/		} else {
			$sortorder=$sql_tabs['korrespondenz']['wvl_datum1'].' desc, '.$sql_tabs['korrespondenz'][$feld2['sort']].' '.$feld2['order'];
		}
	} else {
		$sortorder=$sql_tabs['korrespondenz']['wvl_datum1'].' desc, '.$sql_tabs['korrespondenz']['datum'].' desc'; //sortiert nach datum
    }
	if ($cfg_pim_wvl_datum_ende) {
        if (!isset($feld['wfilterdatum_ende']) and !isset($feld2['keinlimit'])) {
			$feld['wfilterdatum_ende']=adodb_date('d.m.Y');
		}
	}
    if ($_SESSION['cfg_kunde']=='carlo_opel_dinnebier' || $cfg_pim_datum_ende) {
        if (!isset($feld['filterdatum_ende']) and !isset($feld2['keinlimit'])) {
			$feld['filterdatum_ende']=adodb_date('d.m.Y');
		}
	}
	
	
	$merke_awhere='';
	if (($cfg_pim_korr_bis_heute or $_SESSION['cfg_kunde']=='carlo_aag' or $_SESSION['cfg_kunde']=='carlo_kurlaender' or $_SESSION['cfg_kunde']=='carlo_opel_huebner' or $_SESSION['cfg_kunde']=='carlo_opel_linck') and $feld['filterdatum_start']=='' and $feld['filterdatum_ende']=='' and $feld['wfilterdatum_start']=='' and $feld['wfilterdatum_ende']=='') {	// and !isset($feld2['keinlimit'])
		// nur von heute:
/*		$awhere.=' and (('.$sql_tabs['korrespondenz']['datum'].'>='.$db->dbzeitdatum(adodb_date('d.m.Y'), '00:00:00');
		$awhere.=' and '.$sql_tabs['korrespondenz']['datum'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').') or (';
		$awhere.=''.$sql_tabs['korrespondenz']['wvl_datum1'].'>='.$db->dbzeitdatum(adodb_date('d.m.Y'), '00:00:00');
		$awhere.=' and '.$sql_tabs['korrespondenz']['wvl_datum1'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').'))';
*/
		// bis heute:
		if (isset($cfg_pim_korr_datumtagezurueck) and intval($cfg_pim_korr_datumtagezurueck)>0) {
			$abdat=time()-($cfg_pim_korr_datumtagezurueck*24*60*60);
			$awhere.=' and '.$sql_tabs['korrespondenz']['datum'].' between '.$db->dbtimestamp($abdat).' AND '.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59');
			$awhere.=' and ('.$sql_tabs['korrespondenz']['wvl_datum1'].' between '.$db->dbtimestamp($abdat).' AND '.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').' or '.$sql_tabs['korrespondenz']['wvl_datum1'].' is null)';
			$merke_awhere.=' and '.$sql_tabs['korrespondenz']['datum'].' between '.$db->dbtimestamp($abdat).' AND '.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59');
			$merke_awhere.=' and ('.$sql_tabs['korrespondenz']['wvl_datum1'].' between '.$db->dbtimestamp($abdat).' AND '.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').' or '.$sql_tabs['korrespondenz']['wvl_datum1'].' is null)';
			
		} else {
			$awhere.=' and '.$sql_tabs['korrespondenz']['datum'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59');
			$awhere.=' and ('.$sql_tabs['korrespondenz']['wvl_datum1'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').' or '.$sql_tabs['korrespondenz']['wvl_datum1'].' is null)';
			$merke_awhere.=' and '.$sql_tabs['korrespondenz']['datum'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59');
			$merke_awhere.=' and ('.$sql_tabs['korrespondenz']['wvl_datum1'].'<='.$db->dbzeitdatum(adodb_date('d.m.Y'), '23:59:59').' or '.$sql_tabs['korrespondenz']['wvl_datum1'].' is null)';
		}
	} else {
        if ($feld['filterdatum_start']!='' and p4n_mb_string('strlen',$feld['filterdatum_start'])==10 && !isset($_POST['leadprozess'])) {
            $awhere.=' and '.$sql_tabs['korrespondenz']['datum'].'>='.$db->dbzeitdatum($feld['filterdatum_start'], '00:00:00');
            //$awhere .= ' and ' . $sql_tabs['korrespondenz']['datum'] . ' is not null';
        }
        if ($feld['filterdatum_ende']!='' and p4n_mb_string('strlen',$feld['filterdatum_ende'])==10) {
            $awhere.=' and '.$sql_tabs['korrespondenz']['datum'].'<='.$db->dbzeitdatum($feld['filterdatum_ende'], '23:59:59');
            //$awhere .= ' and ' . $sql_tabs['korrespondenz']['datum'] . ' is not null';
        }
        if ($feld['wfilterdatum_start']!='' and p4n_mb_string('strlen',$feld['wfilterdatum_start'])==10 && !isset($_POST['leadprozess'])) {
            $awhere.=' and '.$sql_tabs['korrespondenz']['wvl_datum1'].'>='.$db->dbzeitdatum($feld['wfilterdatum_start'], '00:00:00');
            //$awhere .= ' and ' . $sql_tabs['korrespondenz']['wvl_datum1'] . ' is not null';
        }
        if ($feld['wfilterdatum_ende']!='' and p4n_mb_string('strlen',$feld['wfilterdatum_ende'])==10) {
            $awhere.=' and '.$sql_tabs['korrespondenz']['wvl_datum1'].'<='.$db->dbzeitdatum($feld['wfilterdatum_ende'], '23:59:59');
            if ($feld['filterdatum_ende']=='') {
                $awhere.=' and '.$sql_tabs['korrespondenz']['datum'].'<='.$db->dbzeitdatum($feld['wfilterdatum_ende'], '23:59:59');
            }
//$awhere .= ' and ' . $sql_tabs['korrespondenz']['wvl_datum1'] . ' is not null';
        }
	}
	if ((isset($feld['filter_kart']) and intval($feld['filter_kart'])>=0)&& (($_SESSION['design_70'] && isset($_GET['pagination_korr_1'])) || !$_SESSION['design_70'])) {
		$awhere.=' and '.$sql_tabs['korrespondenz']['art'].'='.$db->dbzahl($feld['filter_kart']);
	}
	if ((isset($feld['filter_kamp']) and intval($feld['filter_kamp'])>=0)&& (($_SESSION['design_70'] && isset($_GET['pagination_korr_1'])) || !$_SESSION['design_70'])) {
		$awhere.=' and '.$sql_tabs['korrespondenz']['kampagne_id'].'='.$db->dbzahl($feld['filter_kamp']);
	}
	if ((isset($feld['filter_korrkat']) and $feld['filter_korrkat']!='' and $feld['filter_korrkat']!='-1') && (($_SESSION['design_70'] && isset($_GET['pagination_korr_1'])) || !$_SESSION['design_70'])) {
		$awhere.=' and '.$sql_tabs['korrespondenz']['kategorie'].'='.$db->str($feld['filter_korrkat']);
	}
	
	if ($_SESSION['cfg_kunde']=='carlo_kurlaender') {
		$awhere.=' and '.$sql_tabs['korrespondenz']['art'].'!='.$db->dbzahl(9);
	}
	
	
	if ($nurgeb) {
		$pdatei="template/geburtstagsliste.html";
	} elseif (is_file('inc/'.$_SESSION['cfg_kunde'].'/pim.html')) {
		$pdatei='inc/'.$_SESSION['cfg_kunde'].'/pim.html';
	} else {
		$pdatei="template/pim.html";
	}
	
	$alle_drin=array();
	$pim_mitvorlage=false;
	$pim_filter_ids='';
	$res2=$db->select(
		$sql_tab['benutzer'],
		array(
			$sql_tabs['benutzer']['pim_anordnung'],
			$sql_tabs['benutzer']['pim_anordnung_filter']
		),
		$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($userid_pim)
	);
	if ($row2=$db->zeile($res2)) {
		$pim_allebloecke=$row2[0];
		$pim_filter_ids=$row2[1];
		if ($row2[0]!='' and !$nurgeb) {
			$pim_xlp=explode('/', $row2[0]);
			$pim_vor_l=explode(',', $pim_xlp[0]);
			$pim_vor_r=explode(',', $pim_xlp[1]);
            $pim_neu=$pim_xlp[2];
			while (list($key2, $val2)=@each($pim_vor_l)) {
				$alle_drin[$val2]=1;
			}
			while (list($key2, $val2)=@each($pim_vor_r)) {
				$alle_drin[$val2]=1;
			}
            if ($_SESSION['design_70'] && $pim_neu!='') {
                $alle_drin=array();
                $pim_neu= unserialize($pim_neu);
                foreach ($pim_neu as $key => $value) {
                    foreach ($value as $key2 => $value2) {
                        $alle_drin[$value2]=1;
                    }
                }
            }
			@reset($pim_vor_r);
			@reset($pim_vor_l);
			$pdatei="template/pim2.html";
			$pim_mitvorlage=true;
		}
	}
    
    if ($cfg_avag_de) {
        $pim_neu=unserialize('a:4:{i:0;a:3:{i:0;s:17:"avagpim_vkchancen";i:1;s:14:"avagpim_offang";i:2;s:22:"avagpim_leasingauslauf";}i:1;a:2:{i:0;s:2:"bm";i:1;s:8:"kalender";}i:2;a:3:{i:0;s:7:"notizen";i:1;s:8:"pinnwand";i:2;s:15:"verkaufsvorgabe";}i:3;a:3:{i:0;s:6:"tkpwps";i:1;s:13:"letztenkunden";i:2;s:7:"geblang";}}');
       // $pim_allebloecke='wvl,gebkurz,,,,,,,,/kalender,,,,,,,,,/a:6:{i:0;a:3:{i:0;s:10:"useronline";i:1;s:8:"lead_pim";i:2;s:3:"wvl";}i:1;a:2:{i:0;s:22:"avagpim_leasingauslauf";i:1;s:17:"avagpim_vkchancen";}i:2;a:1:{i:0;s:8:"kalender";}i:3;a:3:{i:0;s:15:"verkaufsvorgabe";i:1;s:2:"bm";i:2;s:6:"filter";}i:4;a:1:{i:0;s:4:"news";}i:5;a:1:{i:0;s:7:"notizen";}}';
        $alle_drin=array();
        foreach ($pim_neu as $key => $value) {
            foreach ($value as $key2 => $value2) {
                $alle_drin[$value2]=1;
            }
        }
        $pim_mitvorlage=true;
        $alle_drin['opp']=1;
    }

    $hbExist = false;
	foreach ($alle_drin as $key => $ok) {
	    if (!$key) {
	        continue;
        }
        if (isset($hbAssignment[$key])) {
            if ($hbExist) {
                $replace = '';
            } else {
                $replace = $handbuch;
                $hbExist = true;
            }
            $pim_bloecke[$key] = p4n_mb_string('str_replace', '{handbuch}', $replace, $pim_bloecke[$key]);
            $pb_inh[$key] = $pim_bloecke[$key];
        } else {
            if (!$hbExist) {
                $hbExist = true;
                $hbBlock = $key;
            }
        }
    }

//$pim_mitvorlage=true;
	
		$keine_leerzeile=1;
		if ($inhalt=template($pdatei)) {
			
           // $debug->debug('testpim.txt','$inhalt=template($pdatei)');
            
			if (1==1) {
				$i=0;
				$form=new htmlform();
				$inhalt=$form->start('kform_pim', 'pim.php', 'POST', true).$inhalt;
//				$inhalt=p4n_mb_string('str_replace', '{datensatz}', datensatz($row[7]), $inhalt);
				$abbruch=false;
				
                if (!$cfg_modern) {
				$temp_js=javas('function lade_wvl(para1) {
                                    if (typeof p4ntoken == "undefined") {p4ntoken="";}
                                    var xmlhttp;
                                    try { xmlhttp = new XMLHttpRequest(); } catch (error) {
                                            try { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); } catch (error) { return false;	}
                                    }

                                    para1+="&filterdatum_start="+document.forms["kform_pim"].elements["filterdatum_start"].value;
                                    para1+="&filterdatum_ende="+document.forms["kform_pim"].elements["filterdatum_ende"].value;
                                    para1+="&wfilterdatum_startKorr="+document.forms["kform_pim"].elements["wfilterdatum_startKorr"].value;
                                    para1+="&wfilterdatum_endeKorr="+document.forms["kform_pim"].elements["wfilterdatum_endeKorr"].value;
                                    para1+="&p4ntoken="+p4ntoken;
                                    
                                    xmlhttp.open("POST", "pim.php", false);
                                    xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                                    xmlhttp.setRequestHeader("X-Requested-With", "XMLHttpRequest");
                        
                                    xmlhttp.onreadystatechange=function() { 
                                        if (xmlhttp.readyState==4 && xmlhttp.status==200) {
                                            if (typeof getNewToken == "function") {
                                                p4ntoken = getNewToken(xmlhttp.getResponseHeader("p4ntoken"));
                                            }
                                            response=xmlhttp.responseText;
                                            document.getElementById("pim_wvl").innerHTML=response;
                                        } 
                                    };

                                    xmlhttp.send(para1);
                            }');
                } else {
                   $temp_js=javas('function lade_wvl(para1) {
                                P4nBoxHelper.startloading();
                                para1+="&filterdatum_start="+document.forms["kform_pim"].elements["filterdatum_start"].value;
                                para1+="&filterdatum_ende="+document.forms["kform_pim"].elements["filterdatum_ende"].value;
                                para1+="&wfilterdatum_startKorr="+document.forms["kform_pim"].elements["wfilterdatum_startKorr"].value;
                                para1+="&wfilterdatum_endeKorr="+document.forms["kform_pim"].elements["wfilterdatum_endeKorr"].value;
                                console.log(para1);
                                RequestHelper2("POST","pim.php",para1,function(response) {
                                document.getElementById("pim_wvl").innerHTML=response;
                                    P4nBoxHelper.stoploading();
                                });
                            }');
                }
                $inhalt.=$temp_js;
                $js70.=$temp_js;
				if ($pim_mitvorlage) {
					$m_inhalt=$inhalt;
					$inhalt=$pim_bloecke['wvl'];
				}
                
                //$debug->debug('testpim.txt','pim_wvlblock('.$def_korrart.')');
				pim_wvlblock($def_korrart);
				if ($pim_mitvorlage) {
					$pb_inh['wvl']=$inhalt;
                    //$debug->debug('testpim.txt','_KORRP_ widget_wvl');
                    $design_widget['wvl']=new Template_ElementList($card70,'widget_wvl','wvl_widget');
                    $design_widget_auswahl['wvl']=_KORRP_;
					$inhalt=$m_inhalt;
				}
				
				if ($pim_mitvorlage) {
					if (preg_match_all("/{block-om-start\}(.*){block-om-ende}/Uis", $pim_bloecke['opp'], $omblock, PREG_SET_ORDER)) {
						$omblock=$omblock[0][1];
					}
					if (preg_match_all("/{block-bm-start\}(.*){block-bm-ende}/Uis", $pim_bloecke['bm'], $bmblock, PREG_SET_ORDER)) {
						$bmblock=$bmblock[0][1];
					}
					if (preg_match_all("/{block-pm-start\}(.*){block-pm-ende}/Uis", $pim_bloecke['pm'], $pmblock, PREG_SET_ORDER)) {
						$pmblock=$pmblock[0][1];
					}
				} else {
					if (preg_match_all("/{block-om-start\}(.*){block-om-ende}/Uis", $inhalt, $omblock, PREG_SET_ORDER)) {
						$omblock=$omblock[0][1];
					}
					if (preg_match_all("/{block-bm-start\}(.*){block-bm-ende}/Uis", $inhalt, $bmblock, PREG_SET_ORDER)) {
						$bmblock=$bmblock[0][1];
					}
					if (preg_match_all("/{block-pm-start\}(.*){block-pm-ende}/Uis", $inhalt, $pmblock, PREG_SET_ORDER)) {
						$pmblock=$pmblock[0][1];
					}
				}
				
				// Werkstatt:
				if ((count($alle_drin)==0 or isset($alle_drin['tkpwps'])) and (preg_match('{tkp_termine}', $inhalt) or isset($pim_bloecke['tkpwps'])) && !isset($_GET['pagination_bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
					
					$tkp_anz_zu=2;
					if (isset($cfg_tkpwps_tage_zukunft_pim)) {
						if ($cfg_tkpwps_tage_zukunft_pim>0) {
							$tkp_anz_zu=$cfg_tkpwps_tage_zukunft_pim;
						}
					}
					if ($cfg_pim_tkp_vkleiter_nur_std_lao or $cfg_pim_tkp_vkleiter_stdlao_ausw_lao or $cfg_pim_tkp_stammdatenbetreuer or $cfg_pim_tkp_vk_nur_std_lao) {
						$tkp_wh=$sql_tabs['korrespondenz']['stammdaten_id'].' in (select '.$sql_tabs['stammdaten']['id'].' from '.$sql_tab['stammdaten'].' where '.$sql_tabs['stammdaten']['betreuer'].$where_weitl_tkp.') and ';
					} else {
						$tkp_wh=$sql_tabs['korrespondenz']['betreuer_id'].$where_weitl_tkp.' and ';
					}
					if ($cfg_pim_tkp_alle or ($cfg_pim_tkpgeb_adminalle and $_SESSION['user_gruppe']==2)) {
						$tkp_wh='';
					}
                    if ($zeitdebug) {
                        echo 'vor WPS Select: '.zeitnahme().'<br>';
                    }
                    
                    $pagination=new Template_Pagination('pagination_widget_werkstatt');
                    
					$res2=$db->select(
						$sql_tab['korrespondenz'],
						array(
							$sql_tabs['korrespondenz']['stammdaten_id'],
							$sql_tabs['korrespondenz']['datum'],
							$sql_tabs['korrespondenz']['betreff'],
							$sql_tabs['korrespondenz']['beschreibung']
						),
						$tkp_wh.'('.$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('TKP Termin').' or '.
							$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('WS Termin').' or '.
							$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('Workshop').' or '.
							$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('WPS Termin').') and '.
							$sql_tabs['korrespondenz']['datum'].'>='.$db->dbtimestamp(time()-5*60*60).' and '.
							$sql_tabs['korrespondenz']['datum'].'<='.$db->dbtimestamp(time()+$tkp_anz_zu*24*60*60),
                            $sql_tabs['korrespondenz']['datum'],
                            '',
                            '',
                            ($_SESSION['design_70'] && 1==2?$pagination->limit():0),
                            ($_SESSION['design_70'] && 1==2?$pagination->von():0)   
					);
                    if ($zeitdebug) {
                        echo 'nach WPS Select: '.zeitnahme().'<br>';
                    }
                    $x=0;
                    $table_data=array();
                    $werkstatt_anzahl=$db->anzahl($res2);
					while ($row2=$db->zeile($res2)) {
                        $cols_view=array();
						if (!kunde_mand_recht($row2[0])) {
							continue;
						}
						$t_dat=adodb_date('H:i', $db->unixdate_ts($row2[1]));
						if (adodb_date('d', $db->unixdate_ts($row2[1])) != adodb_date('d', time())) {
							$t_dat=adodb_date('d.m., H:i', $db->unixdate_ts($row2[1]));
						}
						$tkp_termine.='<tr class="'.($x%2?'odd':'even').'"><td class="td">'.$t_dat.'</td><td class="td">'.linkToTab(kundenbezeichnung($row2[0]), 'stammdaten_main.php?nav=Uebersicht&id='.$row2[0], '', '', '', 1).'</td><td class="td">'.oltext($row2[2].'<br><br>'.$row2[3], $row2[2], '', $db->unixdatetime($row2[1])).'</td></tr>';
                        $cols_view[0]=$t_dat;
                        $cols_view[1]=linkToTab70(kundenbezeichnung($row2[0]), 'stammdaten_main.php?nav=Uebersicht&id='.$row2[0], '', '', '', 1);
                        $cols_view[2]=new Template_Tooltip($row2[2].'<br><br>'.$row2[3], $row2[2], '', $db->unixdatetime($row2[1]));
                        $x++;
                        
                        ksort($cols_view);
                        if (!$table_data_i) {
                            $table_data_i = 1;
                        }
                        $table_data[$table_data_i++] = $cols_view;
                    }
					if ($tkp_termine!='') {
						$tkp_termine='<table class="table-ignore2 moderntable table-margin-bottom"><!sbl>'.$tkp_termine.'</table>';
					}
                    if ($cfg_modern && $tkp_termine=='') {
                        $tkp_termine='<table class="table-ignore2 moderntable table-margin-bottom table-nohover"><tr class="odd"><td class="even">-</td></tr></table>';
                    }
                    if ($_SESSION['design_70']) {
                       // $pagination->create($werkstatt_anzahl);
                        //$pagination->setRequest('GET', 'pagination_tkpwps', 'pim.php', array('pagination_tkpwps=1'));
                            
                        $temp=array(_DATUM_,_KUNDE_,_BESCHREIBUNG_);
                        $table=Template_Default::Table($temp,$table_data,$options=array('minHeight'=>248,'maxHeight'=>248),$filter=array(),$search=array(),$button=null,null,$card=true, $card_title=_WERKSTATT_.$extraTitle);
                        //$card=Template_Default::Card(_WERKSTATT_.$extraTitle,new Template_ElementList(array(),'','hozizontal'),array($table,$pagination));
                        if (isset($_GET['pagination_tkpwps'])){
                            Modern_Helper_Request::requestStart();
                            echo $table->getHtml();
                            echo javas('pim_autoheight_();');
                            exit;
                        }   
                        $design_widget['tkpwps']=new Template_ElementList($table,'pagination_tkpwps','tkpwps_widget');
                        $design_widget_auswahl['tkpwps']=_WERKSTATT_;
                        $table_data=array();
                    }
					
					$inhalt=p4n_mb_string('str_replace', '{tkp_termine}', $tkp_termine, $inhalt);
					$pb_inh['tkpwps']=p4n_mb_string('str_replace', '{tkp_termine}', $tkp_termine, $pb_inh['tkpwps']);
				}
                
                if ((count($alle_drin)==0 or isset($alle_drin['avagpim_vkchancen'])) and (isset($pim_bloecke['avagpim_vkchancen'])) && !isset($_GET['tkpwps']) && !isset($_GET['pagination_bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
                    if (!isset($_GET['pagination_avagpim_vkchancen'])) {
                        include_once('inc/wsdispo.php');
                        $r=avagpim_vkchancen($_SESSION['user_id']);

                        $res_avagpim_vkchancen_korr=$db->select(
                            array($sql_tab['korrespondenz'],$sql_tab['kampagne_lead']),
                            array($sql_tabs['korrespondenz']['korrespondenz_id'],$sql_tabs['korrespondenz']['lead_id']),
                            $db->dbzahlin(explode(',',$r[0]), $sql_tabs['korrespondenz']['lead_id']),
                            $sortorder,
                            '',
                            array($sql_tabs['korrespondenz']['lead_id']=>$sql_tabs['kampagne_lead']['kampagne_lead_id'])
                        );
                        $alle_leads_speicher=array();
                        $x1=0;
                        while ($row_avagpim_vkchancen_korr=$db->zeile($res_avagpim_vkchancen_korr)) {
                            if ($row_avagpim_vkchancen_korr[1]>0) {
                                if (isset($alle_leads_speicher[$row_avagpim_vkchancen_korr[1]])) {
                                    continue;
                                }
                                $x1++;
                                $alle_leads_speicher[$row_avagpim_vkchancen_korr[1]]=1;
                            }
                        }
                        
                        
                        $res_avagpim_vkchancen_korr=$db->select(
                            array($sql_tab['korrespondenz'],$sql_tab['kampagne_lead']),
                            array($sql_tabs['korrespondenz']['korrespondenz_id'],$sql_tabs['korrespondenz']['lead_id']),
                            $db->dbzahlin(explode(',',$r[1]), $sql_tabs['korrespondenz']['lead_id']),
                            $sortorder,
                            '',
                            array($sql_tabs['korrespondenz']['lead_id']=>$sql_tabs['kampagne_lead']['kampagne_lead_id'])
                        );
                        $alle_leads_speicher=array();
                        $x2=0;
                        while ($row_avagpim_vkchancen_korr=$db->zeile($res_avagpim_vkchancen_korr)) {
                            if ($row_avagpim_vkchancen_korr[1]>0) {
                                if (isset($alle_leads_speicher[$row_avagpim_vkchancen_korr[1]])) {
                                    continue;
                                }
                                $x2++;
                                $alle_leads_speicher[$row_avagpim_vkchancen_korr[1]]=1;
                            }
                        }
                        
                        $res_avagpim_vkchancen_korr=$db->select(
                            array($sql_tab['korrespondenz'],$sql_tab['kampagne_lead']),
                            array($sql_tabs['korrespondenz']['korrespondenz_id'],$sql_tabs['korrespondenz']['lead_id']),
                            $db->dbzahlin(explode(',',$r[2]), $sql_tabs['korrespondenz']['lead_id']),
                            $sortorder,
                            '',
                            array($sql_tabs['korrespondenz']['lead_id']=>$sql_tabs['kampagne_lead']['kampagne_lead_id'])
                        );
                        $alle_leads_speicher=array();
                        $x3=0;
                        while ($row_avagpim_vkchancen_korr=$db->zeile($res_avagpim_vkchancen_korr)) {
                            if ($row_avagpim_vkchancen_korr[1]>0) {
                                if (isset($alle_leads_speicher[$row_avagpim_vkchancen_korr[1]])) {
                                    continue;
                                }
                                $x3++;
                                $alle_leads_speicher[$row_avagpim_vkchancen_korr[1]]=1;
                            }
                        }
                        $alle_leads_speicher=array();
                    
                        
        
                        $pim_kennzahl_avagpim_vkchancen_main=Template_Text::init($x1)->setRequest('POST',$pim_modal_inhalt,'pim.php',array('pagination_stammdaten_lead1=1'.
                            (isset($_POST['stammdaten_lead_php'])?'&stammdaten_lead_php='.$_POST['stammdaten_lead_php']:'').
                            '&pim_lead_php=1'.
                            '&wvlart=1'.
                            '&leadprozess=1'.
                            '&navto='.$_POST['navto'].
                            '&id='.$_POST['id'].'&filter_phase='.$_POST['filter_phase'].'&avagpim_vkchancen=1'),$pim_modal)->addCustomClass('cursor_pointer');
                        $pim_kennzahl_avagpim_vkchancen['alle Verkaufschancen']=Template_Text::init($x2)->setRequest('POST',$pim_modal_inhalt,'pim.php',array('pagination_stammdaten_lead1=1'.
                            (isset($_POST['stammdaten_lead_php'])?'&stammdaten_lead_php='.$_POST['stammdaten_lead_php']:'').
                            '&pim_lead_php=1'.
                            '&wvlart=1'.
                            '&leadprozess=1'.
                            '&navto='.$_POST['navto'].
                            '&id='.$_POST['id'].'&filter_phase='.$_POST['filter_phase'].'&avagpim_vkchancen=1&avagpim_vkchancen2=1'),$pim_modal)->addCustomClass('cursor_pointer');
                        $pim_kennzahl_avagpim_vkchancen['vereinbarte Termine']=Template_Text::init($x3)->setRequest('POST',$pim_modal_inhalt,'pim.php',array('pagination_stammdaten_lead1=1'.
                            (isset($_POST['stammdaten_lead_php'])?'&stammdaten_lead_php='.$_POST['stammdaten_lead_php']:'').
                            '&pim_lead_php=1'.
                            '&wvlart=1'.
                            '&leadprozess=1'.
                            '&navto='.$_POST['navto'].
                            '&id='.$_POST['id'].'&filter_phase='.$_POST['filter_phase'].'&avagpim_vkchancen=1&avagpim_vkchancen3=1'),$pim_modal)->addCustomClass('cursor_pointer');
                        
                        
                        $pim_kennzahl_avagpim_vkchancen = empty($pim_kennzahl_avagpim_vkchancen) ? array() : $pim_kennzahl_avagpim_vkchancen;
                        $pim_kennzahl_avagpim_vkchancen=array_merge(array('alle Verkaufschancen bis Heute f�llig'=>$pim_kennzahl_avagpim_vkchancen_main),$pim_kennzahl_avagpim_vkchancen);
                        $card70=Template_Module::PimKennzahlenCard('Verkaufschancen',Template_IconButton::init('','','','open_in_new','','',$sizeClass = 'sm',  'transparent-black', 'round')
                                ->setRequest('POST',$pim_modal_inhalt,'pim.php',array('pagination_stammdaten_lead1=1'.
                            (isset($_POST['stammdaten_lead_php'])?'&stammdaten_lead_php='.$_POST['stammdaten_lead_php']:'').
                            '&pim_lead_php=1'.
                            '&wvlart=1'.
                            '&leadprozess=1'.
                            '&navto='.$_POST['navto'].
                            '&id='.$_POST['id'].'&filter_phase='.$_POST['filter_phase'].'&avagpim_vkchancen=1'),$pim_modal),null,
                            $pim_kennzahl_avagpim_vkchancen,false
                        );
                        $design_widget['avagpim_vkchancen']=array(new Template_ElementList($card70,'pagination_avagpim_vkchancen','avagpim_vkchancen_widget'));
                        $design_widget_auswahl['avagpim_vkchancen']='Verkaufschancen';
                    } else {

                    }
                    $table_data=array();
                }
                $pb_inh['avagpim_vkchancen']=$pb_inh['avagpim_vkchancen'];
                
                
                if ((count($alle_drin)==0 or isset($alle_drin['avagpim_offang'])) and (isset($pim_bloecke['avagpim_offang'])) && !isset($_GET['tkpwps']) && !isset($_GET['pagination_bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
                    if (!isset($_GET['pagination_avagpim_offang'])) {
                        include_once('inc/wsdispo.php');
                        $r=avagpim_offang($_SESSION['user_id']);
                        
                        
                        $pim_kennzahl_avagpim_offang_main=Template_Text::init(($r[0]!=''?count(explode(',',$r[0])):0))
                                ->setRequest('GET',$pim_modal_inhalt,'pim.php','pagination_opp=1&avagpim_offang=1',array($pim_modal))->addCustomClass('cursor_pointer');
                        
                        $pim_kennzahl_avagpim_offang['�lter 5 Tage']=Template_Text::init(($r[1]!=''?count(explode(',',$r[1])):0))
                                ->setRequest('GET',$pim_modal_inhalt,'pim.php','pagination_opp=1&avagpim_offang2=1&avagpim_offang=1',array($pim_modal))->addCustomClass('cursor_pointer');

                        
                        $pim_kennzahl_avagpim_offang = empty($pim_kennzahl_avagpim_offang) ? array() : $pim_kennzahl_avagpim_offang;
                        $pim_kennzahl_avagpim_offang=array_merge(array('offene Angebote'=>$pim_kennzahl_avagpim_offang_main),$pim_kennzahl_avagpim_offang);
                        $card70=Template_Module::PimKennzahlenCard('offene Angebote',Template_IconButton::init('','','','open_in_new','','',$sizeClass = 'sm',  'transparent-black', 'round')
                                ->setRequest('GET',$pim_modal_inhalt,'pim.php','pagination_opp=1&avagpim_offang=1',array($pim_modal)),null,
                            $pim_kennzahl_avagpim_offang,false
                        );
                        $design_widget['avagpim_offang']=array(new Template_ElementList($card70,'pagination_avagpim_offang','avagpim_offang_widget'));
                        $design_widget_auswahl['avagpim_offang']='Verkaufschancen';
                    } else {

                    }
                    $table_data=array();
                }
                $pb_inh['avagpim_offang']=$pb_inh['avagpim_offang'];
                
                
                if ((count($alle_drin)==0 or isset($alle_drin['avagpim_leasingauslauf'])) and (isset($pim_bloecke['avagpim_leasingauslauf'])) && !isset($_GET['tkpwps']) && !isset($_GET['pagination_bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
                    if (!isset($_GET['pagination_avagpim_leasingauslauf'])) {
                        include_once('inc/wsdispo.php');
                        $r=avagpim_leasingauslauf($_SESSION['user_id']);

                        $pim_kennzahl_avagpim_leasingauslauf_main=Template_Text::init(($r[0]!=''?count(explode(',',$r[0])):0))
                                ->setRequest('GET',$pim_modal_inhalt,'pim.php','pagination_avagpim_leasingauslauf=1&avagpim_leasingauslauf=1',array($pim_modal))->addCustomClass('cursor_pointer');
                        
                        $pim_kennzahl_avagpim_leasingauslauf['Gesamtbestand']=Template_Text::init(($r[1]!=''?count(explode(',',$r[1])):0))
                                ->setRequest('GET',$pim_modal_inhalt,'pim.php','pagination_avagpim_leasingauslauf=1&avagpim_leasingauslauf=1&avagpim_leasingauslauf2=1',array($pim_modal))->addCustomClass('cursor_pointer');
                         
                        $pim_kennzahl_avagpim_leasingauslauf = empty($pim_kennzahl_avagpim_leasingauslauf) ? array() : $pim_kennzahl_avagpim_leasingauslauf;
                        $pim_kennzahl_avagpim_leasingauslauf=array_merge(array('f�llige Leasing/Fin-ausl�ufer ohne WVL/Termin/Angebot'=>$pim_kennzahl_avagpim_leasingauslauf_main),$pim_kennzahl_avagpim_leasingauslauf);
                        $card70=Template_Module::PimKennzahlenCard('Leasingausl�ufer',Template_IconButton::init('','','','open_in_new','','',$sizeClass = 'sm',  'transparent-black', 'round')
                                ->setRequest('GET',$pim_modal_inhalt,'pim.php','pagination_avagpim_leasingauslauf=1&avagpim_leasingauslauf=1',array($pim_modal))->addCustomClass('cursor_pointer'),null,
                            $pim_kennzahl_avagpim_leasingauslauf,false
                        );
                        $design_widget['avagpim_leasingauslauf']=array(new Template_ElementList($card70,'pagination_avagpim_leasingauslauf','avagpim_leasingauslauf_widget'));
                        $design_widget_auswahl['avagpim_leasingauslauf']='Verkaufschancen';
                    } else {

                    }
                    $table_data=array();
                }
                $pb_inh['avagpim_leasingauslauf']=$pb_inh['avagpim_leasingauslauf'];
                
				// Werkstatt2:
				if ((count($alle_drin)==0 or isset($alle_drin['tkpwps2'])) and (preg_match('{tkp_termine2}', $inhalt) or isset($pim_bloecke['tkpwps2'])) && !isset($_GET['pagination_bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
					
					$tkp_anz_zu=2;
					if (isset($cfg_tkpwps_tage_zukunft_pim)) {
						if ($cfg_tkpwps_tage_zukunft_pim>0) {
							$tkp_anz_zu=$cfg_tkpwps_tage_zukunft_pim;
						}
					}
					
					$alle_w='';
					$aweiterl=array();
					$res8=$db->select(
						$sql_tab['benutzer_weiterleitung'],
						array(
							$sql_tabs['benutzer_weiterleitung']['benutzer_id'],
							$sql_tabs['benutzer_weiterleitung']['benutzer_id_zu'],
							$sql_tabs['benutzer_weiterleitung']['datum_von'],
							$sql_tabs['benutzer_weiterleitung']['datum_bis']
						)
					);
					while ($row8=$db->zeile($res8)) {
						$drin=true;
						if ($row8[2]!='' and $row8[2]!='1970-01-01' and $row8[2]!='0000-00-00') {
							if (adodb_mktime(0,0,0,adodb_date('m', $db->unixdate_ts($row8[2])), adodb_date('d', $db->unixdate_ts($row8[2])), adodb_date('Y', $db->unixdate_ts($row8[2])))>time()) {
								$drin=false;
							}
						}
						if ($row8[3]!='' and $row8[3]!='1970-01-01' and $row8[3]!='0000-00-00') {
							if (adodb_mktime(23,59,59,adodb_date('m', $db->unixdate_ts($row8[3])), adodb_date('d', $db->unixdate_ts($row8[3])), adodb_date('Y', $db->unixdate_ts($row8[3])))<time()) {
								$drin=false;
							}
						}
						if ($drin) {
							$aweiterl[$row8[0]]=$row8[1];
							$alle_w.=$row8[0].',';
						}
					}
					if ($alle_w!='') {
						$alle_w=substr($alle_w, 0, -1);
					}
					$ids_kalben='';
					$res8=$db->select(
						$sql_tab['benutzer'],
						array(
							$sql_tabs['benutzer']['benutzer_id']
						),
						$sql_tabs['benutzer']['gruppe'].'<0'
					);
					while ($row8=$db->zeile($res8)) {
						if (!isset($aweiterl[$row8[0]])) {
							$ids_kalben.=$row8[0].',';
						}
					}
					if ($ids_kalben!='') {
						$ids_kalben=substr($ids_kalben, 0, -1);
						$tkp_wh=$sql_tabs['korrespondenz']['stammdaten_id'].' in (select '.$sql_tabs['stammdaten']['id'].' from '.$sql_tab['stammdaten'].' where '.$sql_tabs['stammdaten']['betreuer'].' in ('.$ids_kalben.')) and ';
					} else {
						$tkp_wh='1=2 and ';
					}
					
                    if ($zeitdebug) {
                        echo 'vor WPS Select: '.zeitnahme().'<br>';
                    }
                    $pagination=new Template_Pagination('pagination_widget_werkstatt2');
					$res2=$db->select(
						$sql_tab['korrespondenz'],
						array(
							$sql_tabs['korrespondenz']['stammdaten_id'],
							$sql_tabs['korrespondenz']['datum'],
							$sql_tabs['korrespondenz']['betreff'],
							$sql_tabs['korrespondenz']['beschreibung']
						),
						$tkp_wh.'('.$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('TKP Termin').' or '.
							$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('WS Termin').' or '.
							$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('Workshop').' or '.
							$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('WPS Termin').') and '.
							$sql_tabs['korrespondenz']['datum'].'>='.$db->dbtimestamp(time()-5*60*60).' and '.
							$sql_tabs['korrespondenz']['datum'].'<='.$db->dbtimestamp(time()+$tkp_anz_zu*24*60*60).
							($cfg_pimblock_wps_kalenderbenutzer_stdlao?' and '.$sql_tabs['korrespondenz']['stammdaten_id'].
			                	' in (SELECT '.$sql_tabs['stammdaten']['id'].' FROM '.$sql_tab['stammdaten'].' WHERE '.$sql_tabs['stammdaten']['vpb'].'='.$db->dbzahl($_SESSION['user_standard_lagerort']).')':'').
			                ($cfg_pimblock_wps_kalenderbenutzer_auswlao&&$_SESSION['benutzer_mandant_auswertung']!='-1'?' and '.$sql_tabs['korrespondenz']['stammdaten_id'].
            				    ' in (SELECT '.$sql_tabs['stammdaten']['id'].' FROM '.$sql_tab['stammdaten'].' WHERE '.$sql_tabs['stammdaten']['vpb'].' IN ('.$_SESSION['benutzer_mandant_auswertung'].'))':''),
						$sql_tabs['korrespondenz']['datum']
					);
                    if ($zeitdebug) {
                        echo 'nach WPS Select: '.zeitnahme().'<br>';
                    }
                    $x=0;
					$tkp_termine2='';
                    $table_data=array();
                    $werkstatt_anzahl=$db->anzahl($res2);
					while ($row2=$db->zeile($res2)) {
                        $cols_view=array();
						if (!kunde_mand_recht($row2[0])) {
							continue;
						}
						$t_dat=adodb_date('H:i', $db->unixdate_ts($row2[1]));
						if (adodb_date('d', $db->unixdate_ts($row2[1])) != adodb_date('d', time())) {
							$t_dat=adodb_date('d.m., H:i', $db->unixdate_ts($row2[1]));
						}
						$tkp_termine2.='<tr class="'.($x%2?'odd':'even').'"><td class="td">'.$t_dat.'</td><td class="td">'.linkToTab(kundenbezeichnung($row2[0]), 'stammdaten_main.php?nav=Uebersicht&id='.$row2[0], '', '', '', 1).'</td><td class="td">'.oltext($row2[2].'<br><br>'.$row2[3], $row2[2], '', $db->unixdatetime($row2[1])).'</td></tr>';
                        $cols_view[0]=$t_dat;
                        $cols_view[1]=linkToTab70(kundenbezeichnung($row2[0]), 'stammdaten_main.php?nav=Uebersicht&id='.$row2[0], '', '', '', 1);
                        $cols_view[2]=new Template_Tooltip($row2[2].'<br><br>'.$row2[3], $row2[2], '', $db->unixdatetime($row2[1]));
                        $x++;
                        
                        ksort($cols_view);
                        if (!$table_data_i) {
                            $table_data_i = 1;
                        }
                        $table_data[$table_data_i++] = $cols_view;
                    }
					if ($tkp_termine2!='') {
						$tkp_termine2='<table class="table-ignore2 moderntable table-margin-bottom"><!sbl>'.$tkp_termine2.'</table>';
					}
                    if ($cfg_modern && $tkp_termine2=='') {
                        $tkp_termine2='<table class="table-ignore2 moderntable table-margin-bottom table-nohover"><tr class="odd"><td class="even">-</td></tr></table>';
                    }
                    if ($_SESSION['design_70']) {
                        //$pagination->create($werkstatt_anzahl);
                        //$pagination->setRequest('GET', 'pagination_tkpwps2', 'pim.php', array('pagination_tkpwps2=1'));
                            
                        $temp=array(_DATUM_,_KUNDE_,_BESCHREIBUNG_);
                        $table=Template_Default::Table($temp,$table_data,$options=array('minHeight'=>248,'maxHeight'=>248),$filter=array(),$search=array(),$button=null,null,$card=false, $card_title=_WERKSTATT_.$extraTitle);
                        //$card=Template_Default::Card(_WERKSTATT_.$extraTitle,new Template_ElementList(array(),'','hozizontal'),array($table,$pagination));
                        if (isset($_GET['pagination_tkpwps2'])){
                            Modern_Helper_Request::requestStart();
                            echo $table->getHtml();
                            echo javas('pim_autoheight_();');
                            exit;
                        }   
                        $design_widget['tkpwps2']=new Template_ElementList($table,'pagination_tkpwps2','tkpwps2_widget');
                        $design_widget_auswahl['tkpwps2']=_WERKSTATT_.'2';
                        $table_data=array();
                    }
					
					$inhalt=p4n_mb_string('str_replace', '{tkp_termine2}', $tkp_termine2, $inhalt);
					$pb_inh['tkpwps2']=p4n_mb_string('str_replace', '{tkp_termine2}', $tkp_termine2, $pb_inh['tkpwps2']);
				}
				
				// Notizen:
			//	if (preg_match('/{notiz_datum}/', $inhalt)) {
					$auch_sa=true;
					$js_notiz=javas('dat2=1000*'.time().';
	function vor() {
		dwert=document.forms["kform_pim"].elements["pim_notizen_datumi"].value;
		dtag=dwert.substring(0, 2);
		dmonat=dwert.substring(3, 2);
		djahr=dwert.substring(6, 4);
		
		jetzt = new Date(dat2);
		jetzt.setDate(dtag);
		jetzt.setMonth(dmonat);
		jetzt.setYear(djahr);
		jetzt.setHours(12);
		
		if (jetzt.getDay()=='.($auch_sa?'6':'5').') {
			dat2+=(24+'.($auch_sa?'0':'24').')*60*60*1000;
		}
		dat2+=25*60*60*1000;
		jetzt=new Date(dat2);
		millis=jetzt.getTime();// /1000;
		mt=millis.toString();
		tag=jetzt.getDate().toString();
		if (tag.length==1) {
			tag="0"+tag;
		}
		monat=jetzt.getMonth();
		monat++;
		monat2=monat.toString();
		if (monat2.length==1) {
			monat2="0"+monat2;
		}
		mt=tag+"."+monat2+"."+jetzt.getFullYear();
		document.forms["kform_pim"].elements["pim_notizen_datumi"].value=mt;
		lade_inh(mt);
//		return mt;
	}
	function zurueck() {
//		jetzt = new Date(dat2);
		dwert=document.forms["kform_pim"].elements["pim_notizen_datumi"].value;
		dtag=dwert.substring(0, 2);
		dmonat=dwert.substring(3, 2);
		djahr=dwert.substring(6, 4);
		
		jetzt = new Date(dat2);
		jetzt.setDate(dtag);
		jetzt.setMonth(dmonat);
		jetzt.setYear(djahr);
		jetzt.setHours(12);
		
		if (jetzt.getDay()==1) {
			dat2-=(24+'.($auch_sa?'0':'24').')*60*60*1000;
		}
		dat2-=23*60*60*1000;
		jetzt=new Date(dat2);
		millis=jetzt.getTime();// /1000;
		mt=millis.toString();
		tag=jetzt.getDate().toString();
		if (tag.length==1) {
			tag="0"+tag;
		}
		monat=jetzt.getMonth();
		monat++;
		monat2=monat.toString();
		if (monat2.length==1) {
			monat2="0"+monat2;
		}
		mt=tag+"."+monat2+"."+jetzt.getFullYear();
		document.forms["kform_pim"].elements["pim_notizen_datumi"].value=mt;
		lade_inh(mt);
//		return mt;
	}
	
	function lade_inh(datu) {
                if (typeof p4ntoken == "undefined") {p4ntoken="";}
                var xmlhttp;
                try { xmlhttp = new XMLHttpRequest(); } catch (error) {
                        try { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); } catch (error) { return false;	}
                }

                xmlhttp.open("POST", "pim.php", false);
                
                xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xmlhttp.setRequestHeader("X-Requested-With", "XMLHttpRequest");
                
                xmlhttp.onreadystatechange=function() { 
                        if (xmlhttp.readyState==4 && xmlhttp.status==200) {
                            if (typeof getNewToken == "function") {
                                p4ntoken = getNewToken(xmlhttp.getResponseHeader("p4ntoken"));
                            }
                            response=xmlhttp.responseText;
                            document.forms["kform_pim"].elements["pim_notizen"].value=response;
                            if (typeof template_textarea_autosize === "function") {
                                template_textarea_autosize($(document.forms["kform_pim"].elements["pim_notizen"]));
                            }
                        } 
                };
                xmlhttp.send("ajax=1&notiz_datum="+datu+"&p4ntoken="+p4ntoken);
	}
	
	function notizen_sp() {
                if (typeof p4ntoken == "undefined") {p4ntoken="";}
                var xmlhttp;
                try { xmlhttp = new XMLHttpRequest(); } catch (error) {
                        try { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); } catch (error) { return false;	}
                }

                xmlhttp.open("POST", "pim.php", false);
                
                xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xmlhttp.setRequestHeader("X-Requested-With", "XMLHttpRequest");
                
                xmlhttp.onreadystatechange=function() { 
                        if (xmlhttp.readyState==4 && xmlhttp.status==200) {
                            if (typeof getNewToken == "function") {
                                p4ntoken = getNewToken(xmlhttp.getResponseHeader("p4ntoken"));
                            }
                            response=xmlhttp.responseText;
                        } 
                };

                xmlhttp.send("ajax=1&notiz_save="+escapeP4n_60(document.forms["kform_pim"].elements["pim_notizen"].value, true)+"&notiz_d="+document.forms["kform_pim"].elements["pim_notizen_datumi"].value+"&p4ntoken="+p4ntoken);
	}
	
	');
	
	if ($pim_mitvorlage) {
		$m_inhalt=$inhalt;
		$inhalt=$pim_bloecke['notizen'];
	}
	if (count($alle_drin)==0 or isset($alle_drin['notizen']) && !isset($_GET['pagination_bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
				$inhalt=p4n_mb_string('str_replace', '{notiz_datum}', (($cfg_modern)?'<div class="small" style="display:inline-block;">':'').link2('&lt;&lt;', 'javascript: zurueck();',(($cfg_modern)?'pfeil_l.gif':'')).'<!div ID="pim_notizen_datum">'.$form->datuminput('pim_notizen_datumi', adodb_date('d.m.Y'), 'ID="pim_notizen_datumi" onBlur="lade_inh(this.value);"').$form->submit2('pim_notizen_sp2', _OK_, 'onClick="lade_inh(this.form.pim_notizen_datumi.value);"').'<!/div>'.link2('&gt;&gt;', 'javascript: vor();',(($cfg_modern)?'pfeil_r.gif':'')).(($cfg_modern)?'</div>':''), $inhalt);
				$res2=$db->select(
					$sql_tab['notizen'],
					array(
						$sql_tabs['notizen']['inhalt']
					),
					$sql_tabs['notizen']['benutzer_id'].'='.$db->dbzahl($userid_pim).' and '.
						$sql_tabs['notizen']['datum'].'='.$db->dbdate(adodb_date('d.m.Y'))
				);
				$row2=$db->zeile($res2);
				$inhalt=p4n_mb_string('str_replace', '{notizen}', $js_notiz.(($cfg_modern)?'<table class="table-ignore2 moderntable table-margin-bottom table-nohover"><tr class="odd"><td class="td">':'').'<div id="pim_notizen_div">'.$form->textareainput('pim_notizen', $row2[0], 50, 6, 'ID="pim_notizen" style="width:auto;"').'<br>'.$form->submit2('pim_notizen_sp', _SUBMIT_STAMMDATEN_, 'onClick="notizen_sp();"').'</div>'.(($cfg_modern)?'</td></tr></table>':''), $inhalt);
				//}
	}
				if ($pim_mitvorlage) {
					$pb_inh['notizen']=$inhalt;
					$inhalt=$m_inhalt;
                    
                    if ($_SESSION['design_70']) {
                        $js70.=$js_notiz;
                        $cols[0][0]=new Template_ElementList(array(Template_DatumInput::init(_DATUM_,'pim_notizen_datumi', adodb_date('d.m.Y'), 'ID="pim_notizen_datumi" onChange="lade_inh(this.value);"'),Template_IconButton::init('','','onclick="zurueck();"','keyboard_arrow_left',$href='',$abfrage='', $sizeClass = 'sm',$colorClass='grey',$formClass='quadratic')->addCustomClass('mt-24'),Template_IconButton::init('','','onclick="vor();"','keyboard_arrow_right',$href='',$abfrage='', $sizeClass = 'sm',$colorClass='grey',$formClass='quadratic')->addCustomClass('mt-24')),'','horizontal w-auto');
                        $cols[1][0]=new Template_Textarea(_NOTIZ_,'pim_notizen', $row2[0],'', '', 'ID="pim_notizen"');
                        $cols[2][0]=new Template_Button('pim_notizen_sp', _SUBMIT_STAMMDATEN_, 'onClick="notizen_sp();"',$image = '',$href='',$abfrage='',$sizeClass = 'xs');
                        $table=new Template_GridTable($cols);
                        $card=Template_Default::Card(_NOTIZ_,new Template_ElementList(array(),'','hozizontal'),$table,array('border','padding','maxHeight'=>300,'minHeight'=>300));
                        $design_widget['notizen']=new Template_ElementList($card,'','notizen_widget');
                        $design_widget_auswahl['notizen']=_NOTIZ_;
                    }
				}
	if ($zeitdebug) {
		echo 'nach Notizen: '.zeitnahme().'<br>';
	}
	if ($pim_mitvorlage) {
		$m_inhalt=$inhalt;
		$inhalt=$pim_bloecke['filter'];
	}

	if (count($alle_drin)==0 or isset($alle_drin['filter']) && !isset($_GET['pagination_bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
			$pim_f_text='';
			$pim_lade_text='';
                        $merke_fi_jstext='';
                        $cols_filter=array();
			if ($pim_filter_ids!='') {
				$res2=$db->select(
					$sql_tab['filter'],
					array(
						$sql_tabs['filter']['name'],
						$sql_tabs['filter']['sql'],
						$sql_tabs['filter']['filter_id']
					),
					$db->dbzahlin($pim_filter_ids,$sql_tabs['filter']['filter_id'])
				);
                $zaehler=0;
				while ($row2=$db->zeile($res2)) {
					$pim_f_text.='<div id="fi_'.$row2[2].'" class="pimfilter">'._INHALT_.' '.$row2[0].'</div>';
                    $temp_js=javas('lade_in_div("fi_'.$row2[2].'", "'.$phs.'", "pim_filter_id='.$row2[2].(isset($_SESSION['wvlart'])?'&wvlart='.$_SESSION['wvlart']:'').'");');#
                    $pim_lade_text.=$temp_js;
                   // $js70.=$temp_js;
                                        $merke_fi_jstext.='lade_in_div("fi_'.$row2[2].'", "'.$phs.'", "pim_filter_id='.$row2[2].'");';
    					//$pim_f_text.='<table class="hori2"><tr><th colspan='.$fi_spalten.'>'.$row2[0].' ('.$anz1.')'.'</th></tr>'.$tf_kopf.'</table>';
                    $cols_filter[]=Template_ElementList::init(_INHALT_.' '.$row2[0],'fi_'.$row2[2])->setRequest($art='POST',$obj='fi_'.$row2[2],$url='pim.php',$werte='pim_filter_id='.$row2[2].(isset($_SESSION['wvlart'])?'&wvlart='.$_SESSION['wvlart']:''),' widget_filter['.$zaehler.']=true; ',$time=-1,$onload=true);
                    $widget_filter_js.='widget_filter['.$zaehler.']=false;';
                    $zaehler++;
                    $pim_requests++;
                    
                }
                                $pim_f_text.=javas('function load_all_fi() {reset_pim_filter("'.$phs.'", function() {'.$merke_fi_jstext.'}); }');
                                $pim_f_text.=$form->submit2('',_AKTUALISIEREN_,'onclick="load_all_fi();"').(($cfg_modern)?'<br><br>':'');
                               $pim_f_text.='<div style="display:none;" id="pim_filter2"></div>';
                               $filter_submit=Template_Button::init('',_AKTUALISIEREN_,$other = '', $image = '',$href='',$abfrage='',$sizeClass = 'xs','grey');
                                
			}
			echo javas('b=0;
	
	function lade_in_div(divfeld, ziel, gettext, callback) {
            if (typeof cfg_modern != "undefined" && cfg_modern==true) {
                P4nBoxHelper.startloading();
                RequestHelper.post(ziel,gettext,function(response) {
                    document.getElementById(divfeld).innerHTML=response;
                    P4nBoxHelper.stoploading();
                    if(callback != undefined && typeof callback == "function") callback();
                });
                return;
            }
            if (typeof p4ntoken == "undefined") {p4ntoken="";}
            var xmlhttp;
            try { xmlhttp = new XMLHttpRequest(); } catch (error) {
                    try { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); } catch (error) {return false;}
            }

            xmlhttp.open("POST", ziel, false);
            
            xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xmlhttp.setRequestHeader("X-Requested-With", "XMLHttpRequest");
            
            xmlhttp.onreadystatechange=function() { 
                    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
                        if (typeof getNewToken == "function") {
                            p4ntoken = getNewToken(xmlhttp.getResponseHeader("p4ntoken"));
                        }
                        response=xmlhttp.responseText;
                        document.getElementById(divfeld).innerHTML=response;
                        if(callback != undefined && typeof callback == "function") callback();
                    } 
            };
            xmlhttp.send(gettext+"&p4ntoken="+p4ntoken);	
	}
        function reset_pim_filter(ziel, callback) {
            lade_in_div("pim_filter2", ziel, "pim_filter_clear=1", function() {
                if(callback != undefined && typeof callback == "function") callback();
            });
        }
         ');
	}
			$inhalt=p4n_mb_string('str_replace', '{pim_filter}', $pim_f_text, $inhalt);
			if ($pim_mitvorlage) {
				$pb_inh['filter']=$inhalt;
				$inhalt=$m_inhalt;
                
                if ($_SESSION['design_70']) {
                    //$card=Template_Default::Card(_FILTER_,$filter_submit,$cols_filter);
                    $design_widget['filter']=array(javas('var widget_filter=new Array();'.$widget_filter_js),new Template_ElementList($cols_filter,'pagination_filter'));
                    $design_widget_auswahl['filter']=_FILTER_;
                }
			}

			/*debug_logging('lead_form_inhalt before: '.$lead_form_inhalt);
			debug_logging('inhalt before: '.$inhalt);
			$inhalt=p4n_mb_string('str_replace', '{lead_form}', $lead_form_inhalt, $inhalt);
			debug_logging('inhalt after: '.$inhalt);
			*/
			/*'..'<table style="margin-bottom:10px;"><tr><td>'
			._LEAD_.' '._IMPORTDATUM_.': '.$leads_form->datuminput('pim_lead_datum_start', $_SESSION['pim_lead_datum_start']).'-'.$leads_form->datuminput('pim_lead_datum_ende', $_SESSION['pim_lead_datum_ende'])
			.$leads_form->submit('ou_submit', _OK_).'</td></tr></table>'.$leads_form->ende().'*/
	//leaduebersicht Flag
	/*if ($cfg_leads_at_pim) {
		$pim_leads_inhalt=p4n_mb_string('str_replace','{pim_ausw}',$form->start('kform', 'leadprozess_vkl.php', 'POST', true).'<table style="margin-bottom:10px;"><tr><td>'.$pim_ausw.$status_auswahl.$form_ok_button.'</td></tr></table>'.$form->ende(),$pim_leads_inhalt);
		if ($leaduebersicht = template("template/leadprozess/leaduebersicht_vkl.html")) {
	
			$leaduebersicht=p4n_mb_string('str_replace','{filter}','',$leaduebersicht);
	
	
			$leaduebersicht=p4n_mb_string('str_replace','{link_open}','',$leaduebersicht);
			$leaduebersicht=p4n_mb_string('str_replace','{link_edit}','',$leaduebersicht);
			$leaduebersicht=p4n_mb_string('str_replace','{link_closed}','',$leaduebersicht);
	
			$pim_leads_inhalt=p4n_mb_string('str_replace','{leaduebersicht}',$leaduebersicht,$pim_leads_inhalt);
		}

		$m_inhalt=$inhalt;
		$inhalt=$pim_bloecke['open_leads'];
		debug_logging('before str_replace. $pim_leads_inhalt: '.$pim_leads_inhalt);
		debug_logging('before str_replace. $inhalt: '.$inhalt);
		$inhalt=p4n_mb_string('str_replace', '{pim_open_leads}', $pim_leads_inhalt, $inhalt);
		debug_logging('after str_replace. $inhalt: '.$inhalt);
		$pb_inh['open_leads']=$inhalt;
		$inhalt=$m_inhalt;
	}*/
	if ($zeitdebug) {
		echo 'nach Filter: '.zeitnahme().'<br>';
	}
	if (count($alle_drin)==0 or isset($alle_drin['verkaufsvorgabe'])  && !isset($_GET['pagination_bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
	
	if (preg_match('/verkaufsvorgabe/', $pim_allebloecke) || $_SESSION['design_70']) {
		if ($pim_mitvorlage) {
			$m_inhalt=$inhalt;
			$inhalt=$pim_bloecke['verkaufsvorgabe'];
		}
		$verkaufsziele_pim_ansicht=1;
		if (is_file('verkaufsziele.php')) {
			include_once('verkaufsziele.php');
		}
        if (!empty($hbBlock) && $hbBlock === 'verkaufsvorgabe') {
            $verkaufsziele_pim_block = p4n_mb_string('str_replace', _VERKAUFSZIELE_.' - ',  _VERKAUFSZIELE_.$handbuch.' - ', $verkaufsziele_pim_block);
        }
        $inhalt=p4n_mb_string('str_replace', '{pim_verkaufsvorgabe}', $verkaufsziele_pim_block, $inhalt);
        if ($pim_mitvorlage) {
            $pb_inh['verkaufsvorgabe']=$inhalt;
            $inhalt=$m_inhalt;
            
            if ($_SESSION['design_70']) {
                $card=Template_Default::Card(_VERKAUFSZIELE_.$handbuch,new Template_ElementList(array(),'','hozizontal'),$verkaufsziele_pim_block,array('border','padding','maxHeight'=>300,'minHeight'=>300),false);
                $design_widget['verkaufsvorgabe']=new Template_ElementList($card,'pagination_verkaufsvorgabe','verkaufsvorgabe_widget');
                $design_widget_auswahl['verkaufsvorgabe']=_VERKAUFSZIELE_;
            }
        }
	}
	}
	if ($zeitdebug) {
		echo 'nach Verkaufsvorgabe: '.zeitnahme().'<br>';
	}
	if (preg_match('/pim_reminders/', $pim_allebloecke)) {
		if ($pim_mitvorlage) {
			$m_inhalt=$inhalt;
			$inhalt=$pim_bloecke['pim_reminders'];
		}
		if (is_file('pim_lead_notifications.php')) {
			require_once('pim_lead_notifications.php');
		}
        $inhalt=p4n_mb_string('str_replace', '{pim_reminders}', $reminders_pim_block, $inhalt);
        if ($pim_mitvorlage) {
            $pb_inh['pim_reminders']=$inhalt;
            $inhalt=$m_inhalt;
        }
	}
	if ($zeitdebug) {
		echo 'nach Reminder: '.zeitnahme().'<br>';
	}
	if (preg_match('/externe_ang/', $pim_allebloecke)) {
		if ($pim_mitvorlage) {
			$m_inhalt=$inhalt;
			$inhalt=$pim_bloecke['externe_ang'];
		}
		$extanginh='';
		$anzahl_e=0;
		$res4=$db->select(
			'crm_bebion_angebote',
			'count(*)',
			'datum_uebernahme is null and benutzer_id='.$db->dbzahl($userid_pim)
		);
		if ($row4=$db->zeile($res4)) {
			$anzahl_e=$row4[0];
		}
		$extanginh=$anzahl_e.' Angebote';
		if (intval($anzahl_e)>0) {
			$extanginh=link2($extanginh, 'externe_angebote.php?uid='.base64_encode($userid_pim));
		}
        $inhalt=p4n_mb_string('str_replace', '{pim_externe_ang}', css_kopf('Externe Angebote').$extanginh, $inhalt);
        if ($pim_mitvorlage) {
            $pb_inh['externe_ang']=$inhalt;
            $inhalt=$m_inhalt;
        }
	}
	if ($zeitdebug) {
		echo 'nach ext.Ang.: '.zeitnahme().'<br>';
	}
    //NEWS
	if (count($alle_drin)==0 or isset($alle_drin['news'])  && !isset($_GET['pagination_bm'])  && !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
	
	if (preg_match('/news/', $pim_allebloecke) || $_SESSION['design_70']) {
		if ($pim_mitvorlage) {
			$m_inhalt=$inhalt;
			$inhalt=$pim_bloecke['news'];
		}
        $extraTitle = '';
        if (!empty($hbBlock) && $hbBlock === 'news') {
            $extraTitle = $handbuch;
        }
		$pimnews1=css_kopf(_NEUIGKEITEN_.$extraTitle);
		
		$hole_news=true;
		$newstext='';
        $newstext70='';
		
		$updneu='';
		if (is_file('upd/updinfo.txt')) {
			$fv=file_get_contents('upd/updinfo.txt');
			if (is_file('upd/'.$fv.'.zip')) {
				$auth_output=new auth();
				$aktvers=$auth_output->getVersion(true, 'x.x.x');
				$aktvers2=intval(str_replace('.', '', $aktvers));
				$xpl=explode('_', $fv);
				$filed=$xpl[0];
				$xpl2=explode('.', $filed);
				$remotevers2=intval(str_replace('.', '', $filed));
				$hauptversion=substr($remotevers2, 0, 3);
				if ($remotevers2>$aktvers2) {
					$updneu='<table class=hori><!sbl><tr><td colspan=3>'.p4n_mb_string('str_replace', '{updver}', $filed, _NEUIGKEITEN_NEUESUPDATE_).'</td></tr>';
				}
			}
		}
		
		$res4=$db->select(
				$sql_tab['einstellungen'],
				$sql_tabs['einstellungen']['wert'],
				$sql_tabs['einstellungen']['modul'].'='.$db->str('p4nbox_news')
		);
		$xpl=array();
		if ($row4=$db->zeile($res4)) {
				$xpl=explode(';;;', $row4[0]);
				if (intval($xpl[0])>adodb_mktime(0,0,0,date('m'),date('d'),date('Y'))) {
					$hole_news=false;
					$newstext=p4n_mb_string('html_entity_decode',$xpl[1]);
                    $newstext70=$xpl[1];
				}
		}
		if ($hole_news) {
			$darten=array(
				0 => $lang['_DOK-SERIENBRIEF_'],
				1 => _FILTER_,
				2 => $lang['_DOK-SERIENBRIEF_'].' '._UND_.' '._FILTER_,
				3 => _FORMULAR_,
				4 => _LEITFADEN_,
				5 => _DIAGRAMMBAUKASTEN_,
				6 => _PRODUKTMODUL_,
				7 => _KNDOC_,
				8 => _LINKTO_,
				9 => _KARTEI_EMAILING_
			);
			$mit_dbk=true;
			if (!is_file('inc/lib_diagrammbaukasten.php')) {
				$mit_dbk=false;
				unset($darten[5]);
			}
			$darten2=$darten;
			include_once('webservice/nusoap.php');
			$masterkey='6t22mp=55+xt4';
			$ws_url='http://www.sales4net.de/profcrm/webservice/extranet.php';
			if (isset($cfg_autoupdate_proxy) and $cfg_autoupdate_proxy!='') {
				$xpl=explode(':', $cfg_autoupdate_proxy);
				if (count($xpl)==2) {
					$proxyhost=$xpl[0];
					$proxyport=$xpl[1];
				} else {
					$proxyhost=$cfg_autoupdate_proxy;
					$proxyport='80';
				}
				$client = new nusoap_client($ws_url, false, $proxyhost, $proxyport, $cfg_autoupdate_proxy_user, $cfg_autoupdate_proxy_password);
				$client->setUseCURL(true);
			} else {
				$client = new nusoap_client($ws_url, false);
			}
			$result = $client->call("liste", array($_SESSION['cfg_kunde'], $userid_pim, '6t22mp=55+xt4', $suchw, $suchk, $sucha), '');
			$x1=unserialize($result);
            $mindatum=time()-7*24*60*60;
			$alle_p4n=array();
            $newsstring='';
			while (list($key, $val)=@each($x1)) {
                foreach ($val as $x1key => $x1value) {
                    if (is_string($x1value)) {
                        if (p4n_mb_string('substr', $x1value, 0, p4n_mb_string('strlen', 'base64p4n'))=='base64p4n') {
                            $val[$x1key]=base64_decode(p4n_mb_string('substr', $x1value, p4n_mb_string('strlen', 'base64p4n')));
                        }
                    }
                }
                if (!$mit_dbk and $val[5]=='5') {
					continue;
				}
				$dat1=$db->unixdate_ts($val[1]);
				if ($dat1>=$mindatum/* || 1==1*/) {
					$alle_p4n[$dat1]='<tr><td>'.$val[2].'</td><td>'.$darten[$val[5]].'</td><td>'.adodb_date('d.m.Y', $dat1).'</td></tr>';
                    $alle_p4n70[$dat1]=$val[2].'{P4N}'.$darten[$val[5]].'{P4N}'.adodb_date('d.m.Y', $dat1).'{P4N2}';
				}
			}
			if (count($alle_p4n)>0) {
				@krsort($alle_p4n);
                @krsort($alle_p4n70);
				$newstext.='<table class=hori><!sbl><tr><th colspan=3>'.link2('P4N@Box', 'extranet_download.php').'</th></tr>';
				@reset($alle_p4n);
                @reset($alle_p4n70);
				$xi1=0;
				while ($xi1<10 and list($pkey, $pval)=@each($alle_p4n)) {
					$newstext.=$pval;
                    $newstext70.=$alle_p4n70[$pkey];
					$xi1++;
				}
				$newstext.='</table>';
                
                if ($_SESSION['design_70']) {
                    $wert_1=time().';;;'.$newstext70;
                } else {
                    $wert_1=time().';;;'.$newstext;
                }

				$res4=$db->select(
					$sql_tab['einstellungen'],
					$sql_tabs['einstellungen']['wert'],
					$sql_tabs['einstellungen']['modul'].'='.$db->str('p4nbox_news')
				);
				if ($row4=$db->zeile($res4)) {
					$db->update(
						$sql_tab['einstellungen'],
						array(
							$sql_tabs['einstellungen']['wert'] => $db->str($wert_1)
						),
						$sql_tabs['einstellungen']['modul'].'='.$db->str('p4nbox_news')
					);
				} else {
					$db->insert(
						$sql_tab['einstellungen'],
						array(
							$sql_tabs['einstellungen']['modul'] => $db->str('p4nbox_news'),
							$sql_tabs['einstellungen']['wert'] => $db->str($wert_1)
						)
					);
				}
			}
		}
		if ($updneu!='') {
			$newstext=$updneu.$newstext;
		}
		
		$pimnews1.=$newstext;
		if (1==2) {
		$pimnews1.='<span>iPhone Ticker</span>
<div class="newsbar" id="newsbar1" style="overflow: hidden;"></div>
<span>iFun Ticker</span>
<div class="newsbar" id="newsbar2" style="overflow: hidden;"></div>
<script type="text/javascript" src="js/rssTicker.js"></script>
<script type="text/javascript">
$(document).ready( function() {
    rssTicker(\'#newsbar1\', \'http://www.iphone-ticker.de/feed/\', 2500, \'<div>'.link2('{publishedDate} - {title} - {author}','{link}').'<br />{contentSnippet}</div>\');
    rssTicker(\'#newsbar2\', \'http://www.ifun.de/feed/\', 5000, \'<div>'.link2('{publishedDate} - {title} - {author}','{link}').'<br />{contentSnippet}</div>\');
});
</script>';
		}
		$inhalt=p4n_mb_string('str_replace', '{pim_news}', $pimnews1, $inhalt);
		if ($pim_mitvorlage) {
			$pb_inh['news']=$inhalt;
			$inhalt=$m_inhalt;
            
            if ($_SESSION['design_70']) {
                $ex=explode('{P4N2}',$newstext70);
                $table_data=array();
                $anzahl_news=0;
                
                $pagination=new Template_Pagination('widget_pagination_news',5);
                
                foreach ($ex as $ex2) {
                    $anzahl_news++;
                    if (!$pagination->cancelWhile() || empty($ex2)) {
                        continue;
                    }
                    
                    $cols_view=array();
                    $ex3=explode('{P4N}',$ex2);
                    $cols_view[0]=Template_Text::init($ex3[0],-1,array('wrap'));
                    $cols_view[1]=$ex3[1];
                    $cols_view[2]=$ex3[2];
                    
                 
                    ksort($cols_view);
                    if (!$table_data_i) {
                        $table_data_i = 1;
                    }
                    $table_data[$table_data_i++] = $cols_view;
                }
                
                $temp = array(
                    _BEZEICHNUNG_,
                    _ART_,
                    _DATUM_
                );
                
                //$pagination->create($anzahl_news);
                //$pagination->setRequest('GET', 'pagination_news', 'pim.php', array('pagination_news=1'));
                
                $table = Template_Default::Table($temp,$table_data,array('size'=>'sm','minHeight'=>248,'maxHeight'=>248),$filter=array(),$search=array(),$button=Template_Button::init('','P4N@Box','','','extranet_download.php','','xs','grey','quadratic'),null,$card=true, $card_title=_NEUIGKEITEN_);
               // $card = Template_Default::Card(_NEUIGKEITEN_,new Template_ElementList(array(Template_Button::init('','P4N@Box','','','extranet_download.php','','xs','grey','quadratic')),'','hozizontal'),array($table,$pagination));
                
                if (isset($_GET['pagination_news'])){
                    Modern_Helper_Request::requestStart();
                    echo $table->getHtml();
                    echo javas('pim_autoheight_();');
                    exit;
                }    
                
                $design_widget['news']=new Template_ElementList($table,'pagination_news','news_widget');
                $design_widget_auswahl['news']=_NEUIGKEITEN_;
                $table_data=array();
            }
		}
	}
	}
	if ($zeitdebug) {
		echo 'nach News: '.zeitnahme().'<br>';
	}
	
	if (count($alle_drin)==0 or isset($alle_drin['letztenkunden']) && !isset($_GET['pagination_bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
        if (preg_match('/letztenkunden/', $pim_allebloecke) || $_SESSION['design_70']) {
            if ($pim_mitvorlage) {
                $m_inhalt=$inhalt;
                $inhalt=$pim_bloecke['letztenkunden'];
            }
            $extraTitle = '';
            if (!empty($hbBlock) && $hbBlock === 'letztenkunden') {
                $extraTitle = $handbuch;
            }
            
            if (!$_SESSION['design_70']) {
                $letzten_kunden=css_kopf(_TERMIN_T_RHYT5_.' '._KUNDEN_.$extraTitle);
                $letzten_kunden.=tab_letztekunden(10, $userid_pim);
            } else {
                $letzten_kunden70=tab_letztekunden(5, $userid_pim);
            }
   

            $inhalt=p4n_mb_string('str_replace', '{pim_letztenkunden}', $letzten_kunden, $inhalt);
            if ($pim_mitvorlage) {
                $pb_inh['letztenkunden']=$inhalt;
                $inhalt=$m_inhalt;
                if ($_SESSION['design_70']) {
                    $card = Template_Default::Card(_TERMIN_T_RHYT5_.' '._KUNDEN_.$extraTitle,new Template_ElementList(array(),'','hozizontal'),$letzten_kunden70,array('border'));
                    $design_widget['letztenkunden']=new Template_ElementList($card,'','letztenkunden_widget');
                    $design_widget_auswahl['letztenkunden']=_TERMIN_T_RHYT5_.' '._KUNDEN_;
                }
            }
        }
	}
	if ($zeitdebug) {
		echo 'nach letzten Kunden: '.zeitnahme().'<br>';
	}
	
				// Geburtstagsliste:
				if ($cfg_kfz) {
					$inhalt=p4n_mb_string('str_replace', array('<!kfz1>', '<!kfz2>'), '', $inhalt);
					if ($pim_mitvorlage) {
						$pim_bloecke['gebkurz']=p4n_mb_string('str_replace', array('<!kfz1>', '<!kfz2>'), '', $pim_bloecke['gebkurz']);
						$pim_bloecke['geblang']=p4n_mb_string('str_replace', array('<!kfz1>', '<!kfz2>'), '', $pim_bloecke['geblang']);
					}
				} else {
					$inhalt=preg_replace('/'.preg_quote('<!kfz1>').'.*'.preg_quote('<!kfz2>').'/Us', '', $inhalt);
					if ($pim_mitvorlage) {
						$pim_bloecke['gebkurz']=preg_replace('/'.preg_quote('<!kfz1>').'.*'.preg_quote('<!kfz2>').'/Us', '', $pim_bloecke['gebkurz']);
						$pim_bloecke['geblang']=preg_replace('/'.preg_quote('<!kfz1>').'.*'.preg_quote('<!kfz2>').'/Us', '', $pim_bloecke['geblang']);
					}
				}
				
				if ($pim_mitvorlage) {
					$m_inhalt=$inhalt;
					$inhalt=$pim_bloecke['opp'];
				}
				// Opportunities
				if (count($alle_drin)==0 or isset($alle_drin['opp']) && !isset($_GET['pagination_bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess'])) {
				if ($cfg_om_inpim and p4n_mb_string('strstr',$_SESSION['rechte_reiter'], 'nav=OM')) {
					$inhalt=p4n_mb_string('str_replace', array('<!om1>', '<!om2>'), '', $inhalt);
					
					$ges_om='';
					$ges_om2='';
					$om_where=$sql_tabs['opportunity']['phase'].'!='.$db->str(_OM_PHASE7_).' and '.
							$sql_tabs['opportunity']['phase'].'!='.$db->str(_OM_PHASE8_).' and '.
							$sql_tabs['opportunity']['phase'].'!='.$db->str(_OM_ANDERESANGEBOT_).' and '.
							$sql_tabs['opportunity']['phase'].'!='.$db->str(_OM_ANDERERKUNDE_).' and '.
							$sql_tabs['opportunity']['phase'].'!='.$db->str(_STORNO_TESTEINTRAG_).' and '.
							$sql_tabs['opportunity']['phase'].'!='.$db->str('Storno');
                    if (!empty($cfg_opp_lost_values)) {
                        $om_where.=' and '.$db->dbstrin(@implode(',', $cfg_opp_lost_values), $sql_tabs['opportunity']['phase'], 'NOT IN');
                    }
					$om_where.=' and '.$sql_tabs['opportunity']['benutzer_id'].$where_weitl;
					
					// neu, nur Phase Angebot:
					if (p4n_mb_string('substr', $_SESSION['cfg_kunde'], 0, 15)=='carlo_opel_avag') {
						$om_where=$sql_tabs['opportunity']['benutzer_id'].$where_weitl.' and '.$sql_tabs['opportunity']['phase'].'='.$db->str(_OM_PHASE3_);
					}
					
					if ($cfg_akvkorr_nurstdlao) {
						$alle_ausschl=ausschluss_stdlao_akv();
						if ($alle_ausschl!='') {
							$om_where.=' and '.$sql_tabs['opportunity']['benutzer_id'].' not in ('.$alle_ausschl.')';
						}
					}
                    
                    
                    if (isset($_GET['avagpim_offang'])) {
                        include_once('inc/wsdispo.php');
                        $r=avagpim_offang($_SESSION['user_id']);
                        if (isset($_GET['avagpim_offang2'])) {
                            $r=$r[1];
                        } else {
                            $r=$r[0];
                        }
                        $om_where=$db->dbzahlin(explode(',',$r),$sql_tabs['opportunity']['opportunity_id']);
					}
					
					$max_op=(isset($cfg_om_pim_max)?$cfg_om_pim_max:5);
					
					$res=$db->select(
						$sql_tab['opportunity'],
						array(
					$sql_tabs['opportunity']['opportunity_id'],
					$sql_tabs['opportunity']['stammdaten_id'],
					$sql_tabs['opportunity']['bezeichnung'],
					$sql_tabs['opportunity']['phase'],
					$sql_tabs['opportunity']['ansprechpartner_id'],
					$sql_tabs['opportunity']['produkt_id'],
					$sql_tabs['opportunity']['art'],
					$sql_tabs['opportunity']['quelle'],
					$sql_tabs['opportunity']['betrag'],
					$sql_tabs['opportunity']['betrag_ist'],
					$sql_tabs['opportunity']['schlusstermin'],
					$sql_tabs['opportunity']['ws_eintritt'],
					$sql_tabs['opportunity']['bemerkung'],
					$sql_tabs['opportunity']['datum_eintrag'],
					$sql_tabs['opportunity']['benutzer_id'],
					$sql_tabs['opportunity']['benutzer_eintrag'],
					$sql_tabs['opportunity']['prioritaet']
						),
						$om_where,
						$sql_tabs['opportunity']['datum_eintrag'].' desc'
					);
					$om_i=0;
					$om_i2=0;
					$anz_om=$db->anzahl($res);
                    $x=0;
                    $table_data=array();
                    $table_data_i=1;
                    
     
                    $pagination=new Template_Pagination('widget_pagination_opp',5);
                    
					while (($om_i2<1000 || $_SESSION['design_70']) and $row=$db->zeile($res)) {//$om_i<$max_op and 
                        
 
						$om_i2++;
						
                        $cols_view=array();
						// Produkt
						if (is_numeric($row[5]) and !isset($p_cache[$row[5]])) {
                            if ($row[5]>0) {
                                if ($cfg_kfz) {
                                    $res2=$db->select($sql_tab['produktzuordnung'],
                                        array(
                                            $sql_tabs['produktzuordnung']['produktzuordnung_id'],
                                            $sql_tabs['produktzuordnung']['kennzeichen'],
                                            $sql_tabs['produktzuordnung']['typ_modell'],
                                            $sql_tabs['produktzuordnung']['datum_ez'],
                                            $sql_tabs['produktzuordnung']['fahrgestell'],
                                            $sql_tabs['produktzuordnung']['stammdaten_id']
                                        ),
                                        $sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($row[5])
                                    );
                                    if ($row2=$db->zeile($res2)) {
                                        
                                        $kfz_string = '<table class="table-nostyle">
                                                <tr>
                                                    <td><b>'._KENNZEICHEN_.':</b>&nbsp;</td><td style="text-align: end;">'.$row2[1].'</td>
                                                </tr>
                                                <tr>
                                                    <td><b>'._FAHRZEUG_.':</b>&nbsp;</td><td style="text-align: end;">'.produktbezeichnung($row2[2], $row2[4], $row2[0]).'</td>
                                                </tr>	
                                                <tr>
                                                    <td><b>'._ERSTZUDATUM_.':</b>&nbsp;</td><td style="text-align: end;">'.$db->unixdate($row2[3]).'</td>
                                                </tr>
                                                <tr>
                                                    <td><b>'._FAHRGESTELLNUMMER_.':</b>&nbsp;</td><td style="text-align: end;">'.$row2[4].'</td>
                                                </tr>
                                            </table>
                                        ';
                                        if ($row2[5] !== $_SESSION['stammdaten_id']) {
                                            $kfz_string .= '<br>'._KFZ_KENNZEICHEN_AKTUELL_;
                                        }
                                        $kfz_string=new Template_Html($kfz_string);
                                        
                                        if ($_SESSION['cfg_kunde']=='carlo_koltes') {
                                            $p_cache[$row[5]]=link2('<font size=1>'.$row2[1].' / '.produktbezeichnung($row2[2], $row2[4], $row2[0]).'<br>('._KFZ_EZ_.': '.$db->unixdate($row2[3]).')</font>', 'fahrzeug_pflege.php?produktzuordnung_id='.$row2[0]);
                                            $p_cache_link70[$row[5]]=new Template_Tooltip($kfz_string,new Template_Link('', 'fahrzeug_pflege?produktzuordnung_id='.$row2[0], 'mdi-car', '', 'target="_tab"'));
                                        } else {
                                            $p_cache[$row[5]]=link2('<font size=1>'.$row2[1].' / '.produktbezeichnung($row2[2], $row2[4], $row2[0]).'<br>('._KFZ_EZ_.': '.$db->unixdate($row2[3]).')</font>', 'stammdaten_main.php?nav=Fahrzeuge&id='.$row2[5].'&pnr='.$row2[0]);
                                            $p_cache_link70[$row[5]]=new Template_Tooltip($kfz_string,new Template_Link('', 'stammdaten_main.php?nav=Fahrzeuge'.(intval($row2[5])>0?'&id='.$row2[5]:'&id='.$st_id).'&pnr='.$row2[0].'&exclude_stammdaten_tabs=1', 'mdi-car', '', 'target="_tab"'));
                                        }
                                    } else {
                                        $p_cache[$row[5]]='-';//$row[14];
                                        $p_cache_link70[$row[5]]='-';
                                    }
                                } else {
                                    $res2=$db->select($sql_tab['produkt'],
                                        array(
                                            $sql_tabs['produkt']['produkt_id'],
                                            $sql_tabs['produkt']['bezeichnung']
                                        ),
                                        $sql_tabs['produkt']['produkt_id'].'='.$db->dbzahl($row[5])
                                    );
                                    if ($row2=$db->zeile($res2)) {
                                        $p_cache[$row[5]]=$row2[1];
                                        $p_cache_link70[$row[5]]=$row2[1];
                                    } else
                                        $p_cache[$row[5]]='-';//$row[14];
                                        $p_cache_link70[$row[5]]='-';
                                }
                            } else {
                                $p_cache[$row[5]]='-';
                                $p_cache_link70[$row[5]]='-';
                            }
						} 
						
						// Kunde:
						$st_id=$row[1];
						if (!isset($kubez[$row[1]])) {
							$kubez[$row[1]]=kundenbezeichnung($row[1]);
							
						}
						$st_zeige1=$kubez[$row[1]];
						if ($st_zeige1==$st_id) {
                            $anz_om--;
							continue;
						}
                        $pim_kennzahl_opp[$row[3]]++;
                        if (!$pagination->cancelWhile()) {
                            continue;
                        }
						
						if ($st_zeige1=='0') {
							$anzeige_stid='-';
                            $anzeige_stid70='-';
                        } else {
							$anzeige_stid=linkToTab($st_zeige1, 'stammdaten_main.php?nav=OM&id='.$st_id, '', '', '', 1);
                            $anzeige_stid70=linkToTab70($st_zeige1, 'stammdaten_main.php?nav=OM&id='.$st_id, '', '', '', 1);
                        }
						// Benutzer:
						if (!isset($benutzer_feld[$row[14]])) {
							$benutzer_feld[$row[14]]=$alle_bens[$row[14]];
						}
						
						$tblock=$omblock;
						
						$zusda1=0;
						if (p4n_mb_string('substr',$_SESSION['cfg_kunde'], 0, 5)=='carlo') {
							$zusda1=14*24*60*60;
						}
						
						if ($row[10]!='' and $row[10]!='1970-01-01' and ($db->unixdate_ts($row[10])+$zusda1)<time()) {
							$tblock=p4n_mb_string('str_replace', '<tr ', '<tr class="'.($x%2?'even':'odd').'" style="background-color:#F08080;" ', $tblock);
                        } else {
                            $tblock=p4n_mb_string('str_replace', '<tr ', '<tr class="'.($x%2?'even':'odd').'" ', $tblock);
                        }
                        $x++;
						
						$dolinks='';
                        $dolinks70=array();
						$res3=$db->select(
							$sql_tab['korrespondenz'],
							array(
								$sql_tabs['korrespondenz']['datum'],
								$sql_tabs['korrespondenz']['doclink'],
								$sql_tabs['korrespondenz']['betreff'],
								$sql_tabs['korrespondenz']['kategorie']
							),
							$sql_tabs['korrespondenz']['opportunity_id'].'='.$db->dbzahl($row[0]).' and '.
								$sql_tabs['korrespondenz']['stammdaten_id'].'='.$db->dbzahl($row[1])
						);
						$di=1;
						while ($row3=$db->zeile($res3)) {
							$dolinks.=oltext($db->unixdatetime($row3[0]).': '.$row3[2].'<br><br>'.$row3[1], $di, 'dokumente_korrespondenz/'.$row3[1], _DATEI_.' '.$row3[3], 300, 'target="_blank"').' ';
							$dolinks70[]=new Template_Tooltip($db->unixdatetime($row3[0]).': '.$row3[2].'<br><br>'.$row3[1],new Template_Link('','dokumente_korrespondenz/'.$row3[1],'mdi-file-document-outline', 'target="_blank"'));
                            $di++;
						}
						if ($dolinks!='') {
							$dolinks='<br>'.p4n_mb_string('substr',$dolinks, 0, -1);
                            $dolinks70=new Template_ElementList($dolinks70,'','horizontal');
						}
						
                        
                        
						$tblock=p4n_mb_string('str_replace', '{om_bezeichnung}', $row[0].': '.$row[2].$dolinks, $tblock);
                        $cols_view[0]=$row[0].': '.$row[2];
						$tblock=p4n_mb_string('str_replace', '{om_kunde}', $anzeige_stid, $tblock);
                        $cols_view[1]=$anzeige_stid70;
						$tblock=p4n_mb_string('str_replace', '{om_phase}', $row[3], $tblock);
                        $cols_view[2]=$row[3];
						$tblock=p4n_mb_string('str_replace', '{om_produkt}', $p_cache[$row[5]], $tblock);
						$cols_view[3]=$p_cache_link70[$row[5]];
                        $tblock=p4n_mb_string('str_replace', '{om_ws}', intval($row[11]).' %'.(($row[10]!='' and $row[10]!='1970-01-01')?' - '._ENDE_.': '.$db->unixdate($row[10]):''), $tblock);
						$cols_view[4][0]=intval($row[11]).' %'.(($row[10]!='' and $row[10]!='1970-01-01')?' - '._ENDE_.': '.$db->unixdate($row[10]):'');
                        $tblock=p4n_mb_string('str_replace', '{om_benutzer}', $benutzer_feld[$row[14]], $tblock);
                        $cols_view[5]=$benutzer_feld[$row[14]];
                        
						$tblock=p4n_mb_string('str_replace', '{om_prio}', $stammdaten_korrespondenz_prio[intval($row[16])], $tblock);
                        $cols_view[4][1]=$stammdaten_korrespondenz_prio[intval($row[16])];
                        $cols_view[4]=new Template_ElementList($cols_view[4],'','vertical');
                        
                        
						if ($om_i<$max_op) {
							$ges_om.=$tblock;
							$om_i++;
						} else {
							$ges_om2.=$tblock;
						}
                        ksort($cols_view);
                        if (!$table_data_i) {
                            $table_data_i = 1;
                        }
                        $table_data[$table_data_i++] = $cols_view;
					}
					if ($om_i<$anz_om) {
						$ges_om.='<tr><th class="th" colspan=6>'.$om_i.'/'.$anz_om.' '._OFFENE_VERKAUFSAKTIVITAETEN_.($ges_om2!=''?' - '.link2(_WEITERE_, 'javascript: document.getElementById(\'pim_om_weitere\').style.display=\'\'; void(0);'):'').'</th></tr>';
					}
					if ($ges_om2!='') {
						$ges_om.='</table><div id="pim_om_weitere" style="display: none;"><table class="table-ignore2 moderntable table-nohover">'.$ges_om2.'</table></div><table class="table-ignore2 table-nostyle" >';
					}
					$inhalt=preg_replace('/\{block-om-start\}.*\{block-om-ende\}/Uis', $ges_om, $inhalt);
                    
       
                    if ($_SESSION['design_70']) {
                        if (!isset($_GET['pagination_opp'])) {
                        	$pim_kennzahl_opp = empty($pim_kennzahl_opp) ? array() : $pim_kennzahl_opp;
                            $pim_kennzahl_opp=array_merge(array('offen'=>$anz_om),$pim_kennzahl_opp);
                            $card70=Template_Module::PimKennzahlenCard(_OFFENE_ANGEBOTE_,Template_IconButton::init('','','','open_in_new','','',$sizeClass = 'sm',  'transparent-black', 'round')
                                    ->setRequest('GET',$pim_modal_inhalt,'pim.php','pagination_opp=1',array($pim_modal)),null,
                                $pim_kennzahl_opp,(($user['pim_opp_view_auswahl']=='graph')?true:false)
                            );
                            $design_widget['opp']=array(new Template_ElementList($card70,'pagination_opp','opp_widget'));
                            $design_widget_auswahl['opp']=_OFFENE_ANGEBOTE_;
                        } else {

                            $temp = array(
                                _BEZEICHNUNG_,
                                $lang['_K-STAMMID_'],
                                _PHASE_,
                                _PRODUKT_,
                                _WSEINTRITT_.'/'._BMPRIORITAET_,
                                _BENUTZER_
                            );

                            $priority = array(
                                _BEZEICHNUNG_,
                            );

                            $pagination->create($anz_om);
                            $pagination->setRequest('GET', 'pim_modal_inhalt', 'pim.php', array('pagination_opp=1'.(isset($_GET['avagpim_offang'])?'&avagpim_offang=1':'').(isset($_GET['avagpim_offang2'])?'&avagpim_offang2=1':'')));
                            $table=Template_Default::Table($temp,$table_data,array('sort'=>$sort,'priority'=>$priority),null,null,$button=null,$pagination,$card=true, '');
                            if (isset($_GET['pagination_opp'])){
                                Modern_Helper_Request::requestStart();
                                echo Template_Default::ModalHeader(_OFFENE_ANGEBOTE_)->getHtml();
                                echo $table->getHtml();
                                echo Template_Default::cancelModalButton()->getHtml();
                                exit;
                            }
                        }
                        $table_data=array();
                    }
                    
                    
				} else {
					$inhalt=preg_replace('/<!om1>.*<!om2>/Uis', '', $inhalt);
				}
				}
                
          
                
                
                // avagpim_leasingauslauf
				if (isset($_GET['avagpim_leasingauslauf']) && (count($alle_drin)==0 or isset($alle_drin['avagpim_leasingauslauf'])) && !isset($_GET['pagination_bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess'])) {
                    include_once('inc/wsdispo.php');
                    $r=avagpim_leasingauslauf($_SESSION['user_id']);
                    if (isset($_GET['avagpim_leasingauslauf2'])) {
                        $r=$r[1];
                    } else {
                        $r=$r[0];
                    }
                    $leasing_where=$db->dbzahlin(explode(',',$r),$sql_tabs['produktzuordnung']['produktzuordnung_id']);
                    
					$res=$db->select(
						$sql_tab['produktzuordnung'],
						array(
					$sql_tabs['produktzuordnung']['produktzuordnung_id'],
					$sql_tabs['produktzuordnung']['stammdaten_id'],
					$sql_tabs['produktzuordnung']['datum_leasing'],
                    $sql_tabs['produktzuordnung']['benutzer_id'],
						),
						$leasing_where
					);
					$om_i=0;
					$anz_leasing=$db->anzahl($res);

                    $table_data=array();
                    $table_data_i=1;
                    
     
                    $pagination=new Template_Pagination('widget_pagination_avagpim_leasingauslauf',5);
                    
					while (($_SESSION['design_70']) and $row=$db->zeile($res)) {//$om_i<$max_op and 

                        $cols_view=array();
						// Produkt
						if (is_numeric($row[0]) and !isset($p_cache[$row[0]])) {
                            if ($row[0]>0) {
                                if ($cfg_kfz) {
                                    $res2=$db->select($sql_tab['produktzuordnung'],
                                        array(
                                            $sql_tabs['produktzuordnung']['produktzuordnung_id'],
                                            $sql_tabs['produktzuordnung']['kennzeichen'],
                                            $sql_tabs['produktzuordnung']['typ_modell'],
                                            $sql_tabs['produktzuordnung']['datum_ez'],
                                            $sql_tabs['produktzuordnung']['fahrgestell'],
                                            $sql_tabs['produktzuordnung']['stammdaten_id']
                                        ),
                                        $sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($row[0])
                                    );
                                    if ($row2=$db->zeile($res2)) {
                                        
                                        $kfz_string = '<table class="table-nostyle">
                                                <tr>
                                                    <td><b>'._KENNZEICHEN_.':</b>&nbsp;</td><td style="text-align: end;">'.$row2[1].'</td>
                                                </tr>
                                                <tr>
                                                    <td><b>'._FAHRZEUG_.':</b>&nbsp;</td><td style="text-align: end;">'.produktbezeichnung($row2[2], $row2[4], $row2[0]).'</td>
                                                </tr>	
                                                <tr>
                                                    <td><b>'._ERSTZUDATUM_.':</b>&nbsp;</td><td style="text-align: end;">'.$db->unixdate($row2[3]).'</td>
                                                </tr>
                                                <tr>
                                                    <td><b>'._FAHRGESTELLNUMMER_.':</b>&nbsp;</td><td style="text-align: end;">'.$row2[4].'</td>
                                                </tr>
                                            </table>
                                        ';
                                        if ($row2[5] !== $_SESSION['stammdaten_id']) {
                                            $kfz_string .= '<br>'._KFZ_KENNZEICHEN_AKTUELL_;
                                        }
                                        $kfz_string=new Template_Html($kfz_string);
                                        
                                        if ($_SESSION['cfg_kunde']=='carlo_koltes') {
                                            $p_cache[$row[0]]=link2('<font size=1>'.$row2[1].' / '.produktbezeichnung($row2[2], $row2[4], $row2[0]).'<br>('._KFZ_EZ_.': '.$db->unixdate($row2[3]).')</font>', 'fahrzeug_pflege.php?produktzuordnung_id='.$row2[0]);
                                            $p_cache_link70[$row[0]]=new Template_Tooltip($kfz_string,new Template_Link('', 'fahrzeug_pflege?produktzuordnung_id='.$row2[0], 'mdi-car', '', 'target="_tab"'));
                                        } else {
                                            $p_cache[$row[0]]=link2('<font size=1>'.$row2[1].' / '.produktbezeichnung($row2[2], $row2[4], $row2[0]).'<br>('._KFZ_EZ_.': '.$db->unixdate($row2[3]).')</font>', 'stammdaten_main.php?nav=Fahrzeuge&id='.$row2[5].'&pnr='.$row2[0]);
                                            $p_cache_link70[$row[0]]=new Template_Tooltip($kfz_string,new Template_Link('', 'stammdaten_main.php?nav=Fahrzeuge'.(intval($row2[5])>0?'&id='.$row2[5]:'&id='.$st_id).'&pnr='.$row2[0].'&exclude_stammdaten_tabs=1', 'mdi-car', '', 'target="_tab"'));
                                        }
                                    } else {
                                        $p_cache[$row[0]]='-';//$row[14];
                                        $p_cache_link70[$row[0]]='-';
                                    }
                                } else {
                                    $res2=$db->select($sql_tab['produkt'],
                                        array(
                                            $sql_tabs['produkt']['produkt_id'],
                                            $sql_tabs['produkt']['bezeichnung']
                                        ),
                                        $sql_tabs['produkt']['produkt_id'].'='.$db->dbzahl($row[0])
                                    );
                                    if ($row2=$db->zeile($res2)) {
                                        $p_cache[$row[0]]=$row2[1];
                                        $p_cache_link70[$row[0]]=$row2[1];
                                    } else
                                        $p_cache[$row[0]]='-';//$row[14];
                                        $p_cache_link70[$row[0]]='-';
                                }
                            } else {
                                $p_cache[$row[0]]='-';
                                $p_cache_link70[$row[0]]='-';
                            }
						} 
						
						// Kunde:
						$st_id=$row[1];
						if (!isset($kubez[$row[1]])) {
							$kubez[$row[1]]=kundenbezeichnung($row[1]);
							
						}
						$st_zeige1=$kubez[$row[1]];
						if ($st_zeige1==$st_id) {
                            $anz_leasing--;
							continue;
						}

                        if (!$pagination->cancelWhile()) {
                            continue;
                        }
						
						if ($st_zeige1=='0') {
							$anzeige_stid='-';
                            $anzeige_stid70='-';
                        } else {
							$anzeige_stid=linkToTab($st_zeige1, 'stammdaten_main.php?nav=Uebersicht&id='.$st_id, '', '', '', 1);
                            $anzeige_stid70=linkToTab70($st_zeige1, 'stammdaten_main.php?nav=Uebersicht&id='.$st_id, '', '', '', 1);
                        }
						// Benutzer:
						if (!isset($benutzer_feld[$row[14]])) {
							$benutzer_feld[$row[14]]=$alle_bens[$row[14]];
						}

                        $cols_view[0]=$anzeige_stid70;
						$cols_view[1]=$p_cache_link70[$row[0]];
                        $cols_view[2]=$benutzer_feld[$row[3]];

                        ksort($cols_view);
                        if (!$table_data_i) {
                            $table_data_i = 1;
                        }
                        $table_data[$table_data_i++] = $cols_view;
					}

                    if ($_SESSION['design_70']) {
                        $temp = array(
                            $lang['_K-STAMMID_'],
                            _PRODUKT_,
                            _BENUTZER_
                        );

                        $priority = array(
                            $lang['_K-STAMMID_'],
                        );

                        $pagination->create($anz_leasing);
                        $pagination->setRequest('GET', 'pim_modal_inhalt', 'pim.php', array('pagination_avagpim_leasingauslauf=1'.(isset($_GET['avagpim_leasingauslauf'])?'&avagpim_leasingauslauf=1':'').(isset($_GET['avagpim_leasingauslauf2'])?'&avagpim_leasingauslauf2=1':'')));
                        $table=Template_Default::Table($temp,$table_data,array('sort'=>$sort,'priority'=>$priority),null,null,$button=null,$pagination,$card=true, '');
                        if (isset($_GET['pagination_avagpim_leasingauslauf'])){
                            Modern_Helper_Request::requestStart();
                            echo Template_Default::ModalHeader('Leasingausl�ufer')->getHtml();
                            echo $table->getHtml();
                            echo Template_Default::cancelModalButton()->getHtml();
                            exit;
                        }
                        
                        $table_data=array();
                    }
				}
                
                
				if ($pim_mitvorlage) {
					$pb_inh['opp']=$inhalt;
					$inhalt=$m_inhalt;
				}
	if ($zeitdebug) {
		echo 'nach Opp: '.zeitnahme().'<br>';
	}
				
				if ($pim_mitvorlage) {
					$m_inhalt=$inhalt;
					$inhalt=$pim_bloecke['pm'];
				}
                
                
                
                
                
                
                
                
				// Projekt
				if (count($alle_drin)==0 or isset($alle_drin['pm']) && !isset($_GET['pagination_bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben'])) {
				if (p4n_mb_string('strstr',$_SESSION['rechte_reiter'], 'nav=PM')) {
					
					$statusfeld[1]=_PM_PHASE1_;
					$statusfeld[2]=_PM_PHASE2_;
					$statusfeld[3]=_PM_PHASE3_;
					$statusfeld[4]=_PM_PHASE4_;
					$statusfeld[5]=_PM_PHASE5_;
					$statusfeld[6]=_PM_PHASE6_;
					
					$res=$db->select(
						$sql_tab['projekt_benutzer'],
						array(
							$sql_tabs['projekt_benutzer']['projekt_id'],
							$sql_tabs['projekt_benutzer']['funktion']
						),
						$sql_tabs['projekt_benutzer']['benutzer_id'].$where_weitl
					);
					$projs='';
					while ($row=$db->zeile($res)) {
						$proj_feld[$row[0]]=$row[1];
						$projs.=$row[0].',';
					}
					$proj_where='';
					if ($projs!='') {
						$projs=p4n_mb_string('substr',$projs, 0, -1);
						$proj_where=$db->dbzahlin($projs,$sql_tabs['projekt']['projekt_id']).' and ';
					}
                    if ($_SESSION['cfg_kunde']=='portal') {
                        $proj_where.=$sql_tabs['projekt']['status'].'!='.$db->dbzahl(4).' and ';
                        $proj_where.=$sql_tabs['projekt']['status'].'!='.$db->dbzahl(6).' and ';
                        $proj_where.=$sql_tabs['projekt']['status'].'!='.$db->dbzahl(7).' and ';
                        $proj_where.='('.$sql_tabs['projekt']['zielzeit'].' is null or '.$sql_tabs['projekt']['zielzeit'].'>='.$db->dbtimestamp(time()).' or '.$sql_tabs['projekt']['fortschritt'].'<100)';
                    } else {
    					$proj_where.=$sql_tabs['projekt']['status'].'!='.$db->dbzahl(6).' and ';
    					$proj_where.='('.$sql_tabs['projekt']['ende'].' is null or '.$sql_tabs['projekt']['ende'].'>='.$db->dbtimestamp(time()).' or '.$sql_tabs['projekt']['fortschritt'].'<100)';
                    }
					
					
					$ges_pm='';
					
					$res=$db->select(
						$sql_tab['projekt'],
						array(
							$sql_tabs['projekt']['projekt_id'],
							$sql_tabs['projekt']['stammdaten_id'],
							$sql_tabs['projekt']['bezeichnung'],
							$sql_tabs['projekt']['status'],
							$sql_tabs['projekt']['fortschritt'],
							$sql_tabs['projekt']['produkt_id'],
							$sql_tabs['projekt']['beginn'],
							($_SESSION['cfg_kunde']=='portal'?$sql_tabs['projekt']['zielzeit']:$sql_tabs['projekt']['ende']),
							$sql_tabs['projekt']['prioritaet']
						),
						$proj_where,
						$sql_tabs['projekt']['beginn'].' desc',
						'',
						false,
						(isset($cfg_om_pim_max)?$cfg_om_pim_max:5)
					);
//				echo $db->last_sql;
					$pm_i=0;
					if ($db->anzahl($res)==0) {
						$inhalt=preg_replace('/<!pm1>.*<!pm2>/Uis', '', $inhalt);
					}
                    $x=0;
                    $table_data=array();
					while ($row=$db->zeile($res)) {
						$cols_view=array();
						// Produkt
						if (is_numeric($row[5]) and !isset($p_cache[$row[5]])) {
                            if ($row[5]>0) {
                                if ($cfg_kfz) {
                                    $res2=$db->select($sql_tab['produktzuordnung'],
                                        array(
                                            $sql_tabs['produktzuordnung']['produktzuordnung_id'],
                                            $sql_tabs['produktzuordnung']['kennzeichen'],
                                            $sql_tabs['produktzuordnung']['typ_modell'],
                                            $sql_tabs['produktzuordnung']['datum_ez'],
                                            $sql_tabs['produktzuordnung']['fahrgestell']
                                        ),
                                        $sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($row[5])
                                    );
                                    if ($row2=$db->zeile($res2)) {
                                        $p_cache[$row[5]]=link2('<font size=1>'.$row2[1].' / '.produktbezeichnung($row2[2], $row2[4], $row2[0]).'<br>('._KFZ_EZ_.': '.$db->unixdate($row2[3]).')</font>', $phs.'?pnr='.$row2[0]);
                                        $p_cache70[$row[5]]=new Template_Link($row2[1].' / '.produktbezeichnung($row2[2], $row2[4], $row2[0]).'<br>('._KFZ_EZ_.': '.$db->unixdate($row2[3]).')', $phs.'?pnr='.$row2[0]);
                                    } else {
                                        $p_cache[$row[5]]='-';//$row[14];
                                        $p_cache70[$row[5]]='-';//$row[14];
                                    }
                                } else {
                                    $res2=$db->select($sql_tab['produkt'],
                                        array(
                                            $sql_tabs['produkt']['produkt_id'],
                                            $sql_tabs['produkt']['bezeichnung']
                                        ),
                                        $sql_tabs['produkt']['produkt_id'].'='.$db->dbzahl($row[5])
                                    );
                                    if ($row2=$db->zeile($res2)) {
                                        $p_cache[$row[5]]=$row2[1];
                                        $p_cache70[$row[5]]=$row2[1];
                                    } else {
                                        $p_cache[$row[5]]='-';//$row[14];
                                        $p_cache70[$row[5]]='-';//$row[14];
                                    }
                                }
                            } else {
                                $p_cache[$row[5]]='-';
                                $p_cache70[$row[5]]='-';
                            }
						}
						
						// Kunde:
						$st_id=$row[1];
						if (!isset($kubez[$row[1]])) {
							$kubez[$row[1]]=kundenbezeichnung($row[1]);
						}
						$st_zeige1=$kubez[$row[1]];
						if ($st_zeige1==$st_id) {
							continue;
						}
						
						if ($st_zeige1=='0')
							$anzeige_stid='-';
						else {
							$anzeige_stid=link2($st_zeige1, 'stammdaten_main.php?nav=PM&id='.$st_id);
                            $anzeige_stid70=new Template_Link($st_zeige1, 'stammdaten_main.php?nav=PM&id='.$st_id);
                        }
						
						$tblock=$pmblock;
						$tblock=p4n_mb_string('str_replace', '{pm_bezeichnung}', oltext($proj_feld[$row[0]], $row[2], '', _FUNKTION_), $tblock);
                        $cols_view[0]=new Template_Tooltip($proj_feld[$row[0]], $row[2], '', _FUNKTION_);
						$tblock=p4n_mb_string('str_replace', '{pm_kunde}', $anzeige_stid, $tblock);
                        $cols_view[1]=$anzeige_stid70;
						$tblock=p4n_mb_string('str_replace', '{pm_status}', $statusfeld[$row[3]].' / '.$row[4].'%'.' / '.$stammdaten_korrespondenz_prio[intval($row[8])], $tblock);
                        $cols_view[2]=$statusfeld[$row[3]].' / '.$row[4].'%'.' / '.$stammdaten_korrespondenz_prio[intval($row[8])];
						$tblock=p4n_mb_string('str_replace', '{pm_produkt}', $p_cache[$row[5]], $tblock);
                        $cols_view[3]=$p_cache70[$row[5]];
						$tblock=p4n_mb_string('str_replace', '{pm_beginn}', $db->unixdate($row[6]), $tblock);
                        $cols_view[4]=$db->unixdate($row[6]);
						$tblock=p4n_mb_string('str_replace', '{pm_ende}', $db->unixdate($row[7]), $tblock);
                        $cols_view[5]=$db->unixdate($row[7]);
                        $tblock=p4n_mb_string('str_replace', '{oddeven}', 'class="'.($x%2?'even':'odd').'"', $tblock);
                        $x++;
						$ges_pm.=$tblock;
                        
                        ksort($cols_view);
                        if (!$table_data_i) {
                            $table_data_i = 1;
                        }
                        $table_data[$table_data_i++] = $cols_view;
    
					}
					$inhalt=preg_replace('/\{block-pm-start\}.*\{block-pm-ende\}/Uis', $ges_pm, $inhalt);
					$inhalt=p4n_mb_string('str_replace', array('<!pm1>', '<!pm2>'), '', $inhalt);
				} else {
					$inhalt=preg_replace('/<!pm1>.*<!pm2>/Uis', '', $inhalt);
				}
				}
				if ($pim_mitvorlage) {
					$pb_inh['pm']=$inhalt;
					$inhalt=$m_inhalt;
                    if ($_SESSION['design_70']) {
   
                    $temp = array(
                        _BEZEICHNUNG_,
                        $lang['_K-STAMMID_'],
                        _STATUS_,
                        _PRODUKT_,
                        _BEGINN_,
                        _ENDE_
                    );
                    $table = Template_Default::Table($temp,$table_data,array('size'=>'sm','maxHeight'=>248,'minHeight'=>248),$filter=array(),$search=array(),$button=null,$pagination=null,$card=true, $card_title=_PMHEADLINE_,array('paginationInCard'=>true,'cardOptions'=>array('border'),'addScrollBar'=>true));
                    //$card = Template_Default::Card(_PMHEADLINE_,new Template_ElementList(array(),'','hozizontal'),$table);
                    $design_widget['pm']=new Template_ElementList($table,'','pm_widget');
                    $design_widget_auswahl['pm']=_PMHEADLINE_;
                    $table_data=array();
                    }
				}
                
	if ($zeitdebug) {
		echo 'nach Projekt: '.zeitnahme().'<br>';
	}
				
				if ($pim_mitvorlage) {
					$m_inhalt=$inhalt;
					$inhalt=$pim_bloecke['bm'];
				}
				// Beschwerden
				if (count($alle_drin)==0 or isset($alle_drin['bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
				if (p4n_mb_string('strpos',$_SESSION['rechte_reiter'], 'nav=BM')!==false) {

                    $statusfeld[1]=_BM_STATUS1_;
                    $statusfeld[2]=_BM_STATUS2_;
                    $statusfeld[3]=_BM_STATUS3_;
                    $statusfeld[4]=_BM_STATUS4_;
                    if (isset($cfg_beschwerde_statusfeld2)) {
                        if (is_array($cfg_beschwerde_statusfeld2)) {
                            if (count($cfg_beschwerde_statusfeld2)>1) {
                                $statusfeld=$cfg_beschwerde_statusfeld2;
                            }
                        }
                    }
                    $arten[_BM_ART1_]=_BM_ART1_;
                    $arten[_BM_ART2_]=_BM_ART2_;
                    $arten[_BM_ART3_]=_BM_ART3_;

                    $ticketTypes = array('Anfrage' => _ANFRAGEN_, 'Beschwerde' => _BESCHWERDEN_);

                    $whereTickets = '';
                    if ($cfg_modern && $_SESSION['crm_version'] > 64) {
                        if (!empty($postfeld['bm_filter'])) {
                            $BMFilter = $postfeld['bm_filter'];
                            if (!$_SESSION['design_70'])
                            $_SESSION['pim_bm_filter'] = $BMFilter;
                        } elseif (!empty($getfeld['bm_filter'])) {
                            $BMFilter = $getfeld['bm_filter'];
                            if (!$_SESSION['design_70'])
                            $_SESSION['pim_bm_filter'] = $BMFilter;
                        } else if (isset($_SESSION['pim_bm_filter'])) {
                            if (!$_SESSION['design_70']) {
                                $BMFilter = $_SESSION['pim_bm_filter'];
                            }
                        } else {
                            $BMFilter = array();
                        }

                        if (!empty($getfeld['sort2'])) {
                            $key = $getfeld['sort2'];
                            if (isset($sql_tabs['troubleticket'][$key])) {
                                $orderBy = $sql_tabs['troubleticket'][$key].' '.$getfeld['order'];
                            }
                            /*$_SESSION['pim_bm_sort'] = $orderBy;
                        } else if (isset($_SESSION['pim_bm_sort'])) {
                            $orderBy = $_SESSION['pim_bm_sort'];*/
                        } else {
                            $orderBy = NULL;
                        }
						if (isset($BMFilter['betreff']) and $BMFilter['betreff']!='') {
							$whereTickets .= ' AND '. $sql_tabs['troubleticket']['betreff'].' like '.$db->str('%'.$BMFilter['betreff'].'%');
						}
						if (isset($BMFilter['kunde']) and $BMFilter['kunde']!='') {
							$whereTickets .= ' AND '. $sql_tabs['troubleticket']['stammdaten_id'].' in (select '.$sql_tabs['stammdaten']['id'].' from '.$sql_tab['stammdaten'].' where '.$sql_tabs['stammdaten']['firma1'].' like '.$db->str('%'.$BMFilter['kunde'].'%').' or '.$sql_tabs['stammdaten']['name'].' like '.$db->str('%'.$BMFilter['kunde'].'%').')';
						}
						
                        foreach ($BMFilter as $key => $val) {
							if ($key=='betreff' or $key=='kunde') {
								continue;
							}
                            if (isset($sql_tabs['troubleticket'][$key])) {
                                $type = $sql_meta['troubleticket'][$key][0];
                                if (is_array($val)) {
                                    $start = @$val['start'];
                                    if ($start) {
                                        $whereTickets .= ' AND '.$sql_tabs['troubleticket'][$key] .'>='. $db->prepareValue($type, strtotime($start.' 00:00:00'));
                                    }
                                    $ende = @$val['ende'];
                                    if ($ende) {
                                        $whereTickets .= ' AND '.$sql_tabs['troubleticket'][$key].'<='. $db->prepareValue($type, strtotime($ende.' 23:59:59'));
                                    }

                                } else if ($val != "-1") {
                                    if ($key === 'art2' && $val === 'Beschwerde') {
                                        $whereTickets .= ' AND '. $sql_tabs['troubleticket'][$key].'!='.$db->prepareValue($type, 'Anfrage');
                                    } else {
                                        $whereTickets .= ' AND '. $sql_tabs['troubleticket'][$key].'='.$db->prepareValue($type, $val);
                                    }
                                }
                            }
                        }
                    }

					$inhalt=p4n_mb_string('str_replace', array('<!bm1>', '<!bm2>'), '', $inhalt);
					
					$ges_om='';
                    
                    $bm_data=array(
					$sql_tabs['troubleticket']['troubleticket_id'],
					$sql_tabs['troubleticket']['stammdaten_id'],
					$sql_tabs['troubleticket']['produkt_id'],
					$sql_tabs['troubleticket']['benutzer_id'],
					$sql_tabs['troubleticket']['ersteller_id'],
					$sql_tabs['troubleticket']['korrespondenz_id'],//5
					$sql_tabs['troubleticket']['kalender_id'],
					$sql_tabs['troubleticket']['parent_id'],
					$sql_tabs['troubleticket']['datum'],
					$sql_tabs['troubleticket']['betreff'],
					$sql_tabs['troubleticket']['beschreibung'],//10
					$sql_tabs['troubleticket']['antwort'],
					$sql_tabs['troubleticket']['status'],
					$sql_tabs['troubleticket']['datum_status0'],
					$sql_tabs['troubleticket']['datum_status1'],
					$sql_tabs['troubleticket']['datum_status2'],//15
					$sql_tabs['troubleticket']['datum_status3'],
					$sql_tabs['troubleticket']['datum_status4'],
					$sql_tabs['troubleticket']['prioritaet'],
					$sql_tabs['troubleticket']['art'],
					$sql_tabs['troubleticket']['kategorie'],//20
					$sql_tabs['troubleticket']['modul'],
					$sql_tabs['troubleticket']['produkt'],
					$sql_tabs['troubleticket']['download1'],
					$sql_tabs['troubleticket']['download2'],
				    $sql_tabs['troubleticket']['fremdschluessel_id'],//25
					$sql_tabs['troubleticket']['benutzer_id2'],
                    $sql_tabs['troubleticket']['letzte_aenderung'],
                    $sql_tabs['troubleticket']['art2']
                    );
                    $bm_where='('.$sql_tabs['troubleticket']['benutzer_id'].$where_weitl.($cfg_bm_bearbeiter2?' or '.$sql_tabs['troubleticket']['benutzer_id2'].$where_weitl:'').') and '.
					$sql_tabs['troubleticket']['status'].'!=4'.$whereTickets;
                    $bm_sort=empty($orderBy) ? $sql_tabs['troubleticket']['datum'].' desc' : $orderBy;
                    
                    $pagination=new Template_Pagination('widget_pagination_bm',5);
                    
					//$start = microtime(true); 
                    $res = $db->select(
                        $sql_tab['troubleticket'],
                        $bm_data,
                        $bm_where,
                        $bm_sort,
                        '',
                        false,
                        (isset($cfg_bm_pim_max) ? $cfg_bm_pim_max : 5)
                    );
                    $anzahl_bm = $db->anzahl($res);
                    
                    $res = $db->select(
                        $sql_tab['troubleticket'],
                        $bm_data,
                        $bm_where,
                        $bm_sort,
                        '',
                        false,
                        ($_SESSION['design_70'] ? (isset($_GET['pagination_bm']) ? $pagination->limit() : 0) : (isset($cfg_bm_pim_max) ? $cfg_bm_pim_max : 5)),
                        ($_SESSION['design_70'] ? (isset($_GET['pagination_bm']) ? $pagination->von() : 0) : 0)
                    );
                   
					$bm_i = $x = 0; /*$beschwerden = $anfragen = */
                    $gebs=array();
                    $table_data=array();
					while ($row=$db->zeile($res)) {
                        
                        $cols_view=array();
                        
						// Produkt
						if (is_numeric($row[2]) and !isset($p_cache[$row[2]])) {
                            if ($row[2]>0) {
                                if ($cfg_kfz) {
                                    $res2=$db->select($sql_tab['produktzuordnung'],
                                        array(
                                            $sql_tabs['produktzuordnung']['produktzuordnung_id'],
                                            $sql_tabs['produktzuordnung']['kennzeichen'],
                                            $sql_tabs['produktzuordnung']['typ_modell'],
                                            $sql_tabs['produktzuordnung']['datum_ez'],
                                            $sql_tabs['produktzuordnung']['fahrgestell']
                                        ),
                                        $sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($row[2])
                                    );
                                    if ($row2=$db->zeile($res2)) {
                                        if ($_SESSION['cfg_kunde']=='carlo_koltes') {
                                            $p_cache[$row[2]]=link2('<font size=1>'.$row2[1].' / '.produktbezeichnung($row2[2], $row2[4], $row2[0]).'<br>('._KFZ_EZ_.': '.$db->unixdate($row2[3]).')</font>', 'fahrzeug_pflege.php?produktzuordnung_id='.$row2[0]);
                                            $p_cache70[$row[2]]=new Template_Link('<font size=1>'.$row2[1].' / '.produktbezeichnung($row2[2], $row2[4], $row2[0]).'<br>('._KFZ_EZ_.': '.$db->unixdate($row2[3]).')</font>', 'fahrzeug_pflege.php?produktzuordnung_id='.$row2[0]);
                                        } else {
                                            $p_cache[$row[2]]=link2('<font size=1>'.$row2[1].' / '.produktbezeichnung($row2[2], $row2[4], $row2[0]).'<br>('._KFZ_EZ_.': '.$db->unixdate($row2[3]).')</font>', $phs.'?pnr='.$row2[0]);
                                            $p_cache70[$row[2]]=new Template_Link('<font size=1>'.$row2[1].' / '.produktbezeichnung($row2[2], $row2[4], $row2[0]).'<br>('._KFZ_EZ_.': '.$db->unixdate($row2[3]).')</font>', $phs.'?pnr='.$row2[0]);
                                        }
                                    } else
                                        $p_cache[$row[2]]='-';//$row[14];
                                        $p_cache70[$row[2]]='-';
                                } else {
                                    $res2=$db->select($sql_tab['produkt'],
                                        array(
                                            $sql_tabs['produkt']['produkt_id'],
                                            $sql_tabs['produkt']['bezeichnung']
                                        ),
                                        $sql_tabs['produkt']['produkt_id'].'='.$db->dbzahl($row[2])
                                    );
                                    if ($row2=$db->zeile($res2)) {
                                        $p_cache[$row[2]]=$row2[1];
                                        $p_cache70[$row[2]]=$row2[1];
                                    } else {
                                        $p_cache[$row[2]]='-';//$row[14];
                                        $p_cache70[$row[2]]='-';//$row[14];
                                    }
                                }
                            } else {
                                $p_cache[$row[2]]='-';
                                $p_cache70[$row[2]]='-';
                            }
						}
						
						// Kunde:
						$st_id=$row[1];
						if (!isset($kubez[$row[1]])) {
							$kubez[$row[1]]=kundenbezeichnung($row[1]);
						}
						$st_zeige1=$kubez[$row[1]];
						
						if ($st_zeige1=='0')
							$anzeige_stid='-';
						else {
							$anzeige_stid=linkToTab($st_zeige1, 'stammdaten_main.php?nav=BM&id='.$st_id, '', '', '', 1);
                            $anzeige_stid70=linkToTab70($st_zeige1, 'stammdaten_main.php?nav=BM&id='.$st_id, '', '', '', 1);
                        }
						
						// Benutzer:
/*						if (!isset($benutzer_feld[$row[14]])) {
							$benutzer_feld[$row[14]]=dbout($sql_tab['benutzer'], array($sql_tabs['benutzer']['vorname'], $sql_tabs['benutzer']['name']), $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row[14]));
						}
*/						
						$tblock=$bmblock;
						
						$aendernlink=$db->unixdatetime($row[8]);
						if ($st_zeige1!='0' and ($userid_pim==$row[3] or $userid_pim==$row[26] or $_SESSION['user_gruppe']==2)) {
							$aendernlink=linkToTab($aendernlink, 'stammdaten_main.php?nav=BM&id='.$st_id.'&aendern='.$row[0], '', '', '', 1);
							$aendernlink70 = new Template_Link($db->unixdatetime($row[8]));
							$aendernlink70->setModalWeiterleitung(
								'GET',
								'stammdaten_main.php',
								'nav=BM&id='.$st_id,
								'nav=BM&action=modal&modal_action=tab_activities&troubleticket_id='.$row[0].'&aendern='.$row[0],
								'ticket_modal',
								false,
								'_tab',
								'',
								true
							);
						}
						$beschwerdenummer = (($cfg_catch_retail || $cfg_catch_whole) && intval($row[25]) > 0) ? $row[0].' ('.$row[25].')' : $row[0];
						/*if (isset($ticketTypes[$row[28]])) {
						    $bm_typ = $ticketTypes[$row[28]];
                        } else {
                            $bm_typ = $ticketTypes['Beschwerde'];
                        }*/
                        if ($row[28] === 'Anfrage') {
                            $bm_typ = _ANFRAGE_;
                        } else {
                            $bm_typ = _BESCHWERDE_;
                        }
                        $bm_art = $row[19];
                        $bm_art .= ($bm_art ? '<br>' : '').$bm_typ;

						$tblock=p4n_mb_string('str_replace', '{bm_datum}', $aendernlink, $tblock);
                        $tblock=p4n_mb_string('str_replace', '{bm_letzte_aenderung}', $db->unixdatetime($row[27]), $tblock);
						$tblock=p4n_mb_string('str_replace', '{bm_bezeichnung}', $beschwerdenummer.' '.oltext($row[10], abkuerzung($row[9], 25), '', _BESCHREIBUNG_), $tblock);
						$tblock=p4n_mb_string('str_replace', '{bm_kunde}', $anzeige_stid, $tblock);
						$tblock=p4n_mb_string('str_replace', '{bm_status}', $statusfeld[$row[12]], $tblock);
                        $pim_kennzahl_bm[$statusfeld[$row[12]]]++;
                        $pim_kennzahl_bm2[$statusfeld[$row[12]]]=$row[12];
						$tblock=p4n_mb_string('str_replace', '{bm_produkt}', $p_cache[$row[2]], $tblock);
						$tblock=p4n_mb_string('str_replace', '{bm_art}', $bm_art, $tblock);
                        $tblock=p4n_mb_string('str_replace', '{oddeven}', 'class="'.($x%2?'even':'odd').'"', $tblock);
                        
                        $cols_view[0] = new Template_ElementList(
                            array(
                                $aendernlink70,
                                $db->unixdatetime($row['letzte_aenderung'])
                            ), '', 'vertical'
                        );
                        $cols_view[1] = new Template_ElementList(
                            array(
                                $anzeige_stid70,
                                new Template_ElementList(
                                    array(
                                        $beschwerdenummer,
                                        new Template_Tooltip(
                                            $row['beschreibung'],
                                            array(
                                                new Template_Icon('help'),
                                                abkuerzung($row['betreff'], 25)
                                            ),
                                            '',
                                            $row['betreff']
                                        )
                                    )
                                )
                            ), '', 'vertical'
                        );
                        $cols_view[2] = new Template_ElementList(
                            array(
                                $p_cache70[$row['produkt_id']] ?: '-',
                                $statusfeld[$row['status']] ?: '-'
                            ), '', 'vertical'
                        );
                        $cols_view[3] = new Template_ElementList(
                            array(
                                $row['art'] ?: '-',
                                $bm_typ ?: '-'
                            ), '', 'vertical'
                        );
                        
                        $x++;
						$ges_om.=$tblock;
                        
                        ksort($cols_view);
                        if (!$table_data_i) {
                            $table_data_i = 1;
                        }
                        $table_data[$table_data_i++] = $cols_view;
					}
                    
                    //echo "Process took ". number_format(microtime(true) - $start, 2). " seconds.";
                    
                    if ($cfg_modern && $_SESSION['crm_version'] > 64) {

                        /*$wvor1 = '<td class="menu_karte">';
                        $wnach1 = '</td>';
                        $filt_zus = $wvor1.'<!SMke1>'.link2(_ALLE_.' ('.$x.')', 'pim.php?'.http_build_query(array('bm_filter' => $BMFilter)), '', '', 'style="font-size:12px;" class="karten'.$l_aktiv[0].'"').'<!SMke2>'.$wnach1;
                        if ($beschwerden) {
                            $tempFilter = $BMFilter;
                            $tempFilter['art2'] = _BESCHWERDE_;
                            $filt_zus .= $wvor1.'<!SMke1>'.link2(_BESCHWERDEN_.' ('.$beschwerden.')', 'pim.php?'.http_build_query(array('bm_filter' => $tempFilter)), '', '', 'style="font-size:12px;" class="karten'.$l_aktiv[1].'"').'<!SMke2>'.$wnach1;
                        }
                        if ($anfragen) {
                            $tempFilter = $BMFilter;
                            $tempFilter['art2'] = _BM_ART3_;
                            $filt_zus .= $wvor1.'<!SMke1>'.link2(_ANFRAGEN_.' ('.$anfragen.')', 'pim.php?'.http_build_query(array('bm_filter' => $tempFilter)), '', '', 'style="font-size:12px;" class="karten'.$l_aktiv[3].'"').'<!SMke2>'.$wnach1;
                        }*/

                        $temp = new Modern_Template_SubMenu();
                        $temp->class = 'kartei';
                        $temp->kartei_floatleft = true;
                        $temp->wrapper_small = true;
                        $temp->wrapper_wauto = true;
                        $temp->wrapper_nowrap = true;

                        $temp->target1 = "#pimbmkopf";
                        $temp->targetgesamt = "#pimbmkopfgesamt";
                        $temp->abstand = 100;
                        //$temp->setKarteiString($filt_zus);
                        $temp->setHtml();

                        $extraTitle = '';
                        if (!empty($hbBlock) && $hbBlock === 'bm') {
                            $extraTitle = $handbuch;
                        }

                        $filter = new Modern_Template_Filter;
                        $filter->filter_display = false;
                        $filter->setTitle2('
                                <table class="table-ignore2 moderntable table-header small table-replace-icons">
                                <tr class="heading" id="pimbmkopfgesamt">
                                <th class="th" style="border-right:0px;">
                                <div style="float:left" id="pimbmkopf">'._BMHEADLINE_.$extraTitle.'</div>'.$filter->getFilterLink().'
                                </th>
                                <td style="padding:0px;width:10px;border-top:1px solid -P4Nc1-heading_border-P4Nc2-;border-right:1px solid -P4Nc1-heading_border-P4Nc2-">
                                <div style="border-left:1px solid -P4Nc1-body-P4Nc2-;">
                                ' . $temp->getHtml() . '
                                    </div>
                                </td>
                                </tr>
                                </table>');
                        unset($statusfeld[4]);
                        $filter->setFilterValue(_STATUS_, $form->selectinput('bm_filter[status]', $statusfeld, @$BMFilter['status'], _ALLE_));
                        $filter->setFilterValue(_TYP_, $form->selectinput('bm_filter[art2]', $ticketTypes, @$BMFilter['art2'], _ALLE_));
                        $filter->setFilterValue(_BETREFF_, $form->textinput('bm_filter[betreff]', @$BMFilter['betreff']));
                        $filter->setFilterValue(_KUNDE_, $form->textinput('bm_filter[kunde]', @$BMFilter['kunde']));
                        $filterdatum1 = '<!NULL>'.' '.'<!NULL>'.
                            '<!SMfe1><!SMfl1>'.$lang['_DATUM-EINTRAG_'].' '.'<!SMfl2>'.
                            $form->datuminput('bm_filter[datum][start]', @$BMFilter['datum']['start']).''.
                            ''.' - '.''.
                            ''.$form->datuminput('bm_filter[datum][ende]', @$BMFilter['datum']['ende']).'<!SMfe2>';
                        $filter->setFilterString($filterdatum1);
                        $filterdatum2 = '<!NULL>'.' '.'<!NULL>'.
                            '<!SMfe1><!SMfl1>'._LETZTE_AENDERUNG_.' '.'<!SMfl2>'.
                            $form->datuminput('bm_filter[letzte_aenderung][start]', @$BMFilter['letzte_aenderung']['start']).''.
                            ''.' - '.''.
                            ''.$form->datuminput('bm_filter[letzte_aenderung][ende]', @$BMFilter['letzte_aenderung']['ende']).'<!SMfe2>';
                        $filter->setFilterString($filterdatum2);

                        $filter->setSubmit();
                        $filter->setHtml();
                        $inhalt = p4n_mb_string('str_replace', '{BMFilter}', $filter->getHtml(), $inhalt);
                        
                        if ($_SESSION['design_70']) {
                            if (!isset($_GET['pagination_bm'])) {
                                if (is_array($pim_kennzahl_bm)) {
                                    $merke = $pim_kennzahl_bm;
                                    $pim_kennzahl_bm = array();
                                    foreach ($merke as $key => $value) {
                                        $pim_kennzahl_bm[$key] = Template_Text::init($value)
                                            ->setRequest(
                                                'GET',
                                                $pim_modal_inhalt,
                                                'pim.php',
                                                array('pagination_bm=1&bm_filter[status]='.$pim_kennzahl_bm2[$key]),
                                                $pim_modal
                                            )
                                            ->addCustomClass('cursor_pointer');
                                    }
                                    
                                    $anzahl_bm = Template_Text::init($anzahl_bm)
                                        ->setRequest(
                                            'GET',
                                            $pim_modal_inhalt,
                                            'pim.php',
                                            array('pagination_bm=1&bm_filter[status]=-1'),
                                            $pim_modal
                                        )
                                        ->addCustomClass('cursor_pointer');
                                    
                                    $pim_kennzahl_bm = array_merge(array('alle Beschwerden' => $anzahl_bm), $pim_kennzahl_bm);
                                } else {
                                    $pim_kennzahl_bm=array('alle Beschwerden'=>$anzahl_bm);
                                }
                                
                                $card70 = Template_Module::PimKennzahlenCard(
                                    _BMHEADLINE_,
                                    Template_IconButton::init('', '', '', 'open_in_new', '', '', 'sm', 'transparent-black', 'round')
                                        ->setRequest(
                                            'GET',
                                            $pim_modal_inhalt,
                                            'pim.php',
                                            'pagination_bm=1',
                                            $pim_modal
                                        ),
                                    null,
                                    $pim_kennzahl_bm,
                                    (($user['pim_bm_view_auswahl'] == 'graph') ? true : false)
                                );
                                $design_widget['bm'] = array(new Template_ElementList($card70, 'pagination_bm', 'bm_widget'));
                                $design_widget_auswahl['bm'] = _BMHEADLINE_;
                            } else {
                            
                                $temp = array(
                                    $lang['_DATUM-EINTRAG_'].'/'._LETZTE_AENDERUNG_,
                                    $lang['_K-STAMMID_'].'/'._BEZEICHNUNG_,
                                    _PRODUKT_.'/'._STATUS_,
                                    _BMART_.'/'._TYP_
                                );
                                
                                $statusfeld[1]=_BM_STATUS1_;
                                $statusfeld[2]=_BM_STATUS2_;
                                $statusfeld[3]=_BM_STATUS3_;
                                $statusfeld[4]=_BM_STATUS4_;

                                if (isset($cfg_beschwerde_statusfeld2) && is_array($cfg_beschwerde_statusfeld2) && count($cfg_beschwerde_statusfeld2) > 1) {
                                    $statusfeld=$cfg_beschwerde_statusfeld2;
                                }
                                if (!empty($cfg_bm_ticketpool)) {
                                    $statusfeld[100] = _TO_QUALIFY_;
                                }
                                
                                $statusfeld5 = array(-1 => _ALLE_);
                                $statusfeld5_offen = array();
                                if (is_array($statusfeld)) {
                                    foreach ($statusfeld as $key => $value) {
                                        if ($key != 4) {
                                            $statusfeld5_offen[] = $key;
                                        } else {
                                            $statusfeld5[4] = $value;
                                        }
                                    }
                                }
                                if (!empty($statusfeld5_offen)) {
                                    $statusfeld5[@implode(',', $statusfeld5_offen)] = _NICHT_.' '.$statusfeld5[4];
                                }

                                @ksort($statusfeld5);
  
                                
                                $filterFields = [
                                    new Template_SelectInput(_STATUS_, 'bm_filter[status]', $statusfeld, @$BMFilter['status'], _ALLE_),
                                    new Template_SelectInput(_TYP_, 'bm_filter[art2]', $ticketTypes, @$BMFilter['art2'], _ALLE_),
                                    new Template_TextInput(_BETREFF_, 'bm_filter[betreff]', @$BMFilter['betreff']),
                                    new Template_TextInput(_KUNDE_, 'bm_filter[kunde]', @$BMFilter['kunde']),
                                    new Template_ElementList(
                                        [
                                            Template_DatumInput::init(
                                                $lang['_DATUM-EINTRAG_'].' '._VON_.' / '._BIS_,
                                                'bm_filter[datum][start]',
                                                @$BMFilter['datum']['start']
                                            )
                                                ->setFilterOperator('>='),
                                            Template_DatumInput::init(
                                                '&nbsp;',
                                                'bm_filter[datum][ende]',
                                                @$BMFilter['datum']['ende']
                                            )
                                                ->setFilterOperator('<='),
                                        ],
                                        '', 'horizontal'
                                    ),
                                    new Template_ElementList(
                                        [
                                            Template_DatumInput::init(
                                                _LETZTE_AENDERUNG_.' '._VON_.' / '._BIS_,
                                                'bm_filter[letzte_aenderung][start]',
                                                @$BMFilter['letzte_aenderung']['start']
                                            )
                                                ->setFilterOperator('>='),
                                            Template_DatumInput::init(
                                                '&nbsp;',
                                                'bm_filter[letzte_aenderung][ende]',
                                                @$BMFilter['letzte_aenderung']['ende']
                                            )
                                                ->setFilterOperator('<='),
                                        ],
                                        '', 'horizontal'
                                    )
                                ];
                                
                                $filter = new Template_Filter();
                                $filter->initPageFilter($filterFields, 'pim.php?open_modal=1&pagination_bm=1', 'POST');

                                $search = [
                                    $lang['_K-STAMMID_'].'/'._BEZEICHNUNG_
                                ];
                            
                                $sort = [
                                    $lang['_DATUM-EINTRAG_'],
                                    name2jsname(_LETZTE_AENDERUNG_)
                                ];
                            
                                $priority = array(
                                    _BEZEICHNUNG_,
                                );

                                $pagination->create($anzahl_bm);
                                $pagination->setRequest(
                                    'GET',
                                    'pim_modal_inhalt',
                                    'pim.php',
                                    'open_modal=1'.
                                    '&pagination_bm=1'.
                                    '&bm_filter[status]='.(@$BMFilter['status'] ?: '-1').
                                    '&bm_filter[art2]='.(@$BMFilter['art2'] ?: '-1').
                                    '&bm_filter[betreff]='.@$BMFilter['betreff'].
                                    '&bm_filter[kunde]='.@$BMFilter['kunde'].
                                    '&bm_filter[datum][start]='.@$BMFilter['datum']['start'].
                                    '&bm_filter[datum][ende]='.@$BMFilter['datum']['ende'].
                                    '&bm_filter[letzte_aenderung][start]='.@$BMFilter['letzte_aenderung']['start'].
                                    '&bm_filter[letzte_aenderung][ende]='.@$BMFilter['letzte_aenderung']['ende']
                                );
                                
                                $activeFilterCount = 0;
                                foreach ($BMFilter as $filterValue) {
                                    if (empty($filterValue) || $filterValue === '-1') {
                                        continue;
                                    }
                                    if (is_array($filterValue)) {
                                        foreach ($filterValue as $filterValue2) {
                                            if (empty($filterValue2) || $filterValue2 === '-1') {
                                                continue;
                                            }
                                            $activeFilterCount++;
                                        }
                                    } else {
                                        $activeFilterCount++;
                                    }
                                }
                                
                                $table = Template_Default::Table(
                                    $temp,
                                    $table_data,
                                    array(
                                        'sort' => $sort,
                                        'priority' => $priority,
                                        'collapse' => true
                                    ),
                                    $filter,
                                    $search,
                                    null,
                                    $pagination,
                                    true,
                                    '',
                                    array(
                                        'filterActiveCount' => $activeFilterCount
                                    )
                                );
                                
                                Modern_Helper_Request::requestStart();
                                echo Template_Default::ModalHeader([_BMHEADLINE_])->getHtml();
                                echo $table->addCustomClass('mb-0')->getHtml();
                                echo Template_Default::cancelModalButton()->getHtml();
                                exit;
                            }
                            $table_data=array();
                        }
                    }
					if ($ges_om=='') {
						$ges_om='<td colspan=6>'._KEINE_EINTRAEGE_.'</td>';
					}
					$inhalt=preg_replace('/\{block-bm-start\}.*\{block-bm-ende\}/Uis', $ges_om, $inhalt);
				} else {
					$inhalt=preg_replace('/<!bm1>.*<!bm2>/Uis', '', $inhalt);
				}
				}
				if ($pim_mitvorlage) {
					$pb_inh['bm']=$inhalt;
                    $design_widget_auswahl['bm']=_BMHEADLINE_;
					$inhalt=$m_inhalt;
				}
				// ENde BM
	if ($zeitdebug) {
		echo 'nach BM: '.zeitnahme().'<br>';
	}
				
				if ($pim_mitvorlage) {
					if (preg_match_all("/\{block-geb-start\}(.*)\{block-geb-ende\}/Uis", $pim_bloecke['geblang'], $kblock, PREG_SET_ORDER)) {
						$kblock=$kblock[0][1];
					}
					if (preg_match_all("/\{block-geb2-start\}(.*)\{block-geb2-ende\}/Uis", $pim_bloecke['gebkurz'], $kblock2, PREG_SET_ORDER)) {
						$kblock2=$kblock2[0][1];
					}
				} else {
					if (preg_match_all("/\{block-geb-start\}(.*)\{block-geb-ende\}/Uis", $inhalt, $kblock, PREG_SET_ORDER)) {
						$kblock=$kblock[0][1];
					}
					if (preg_match_all("/\{block-geb2-start\}(.*)\{block-geb2-ende\}/Uis", $inhalt, $kblock2, PREG_SET_ORDER)) {
						$kblock2=$kblock2[0][1];
					}
				}
				
				// nur die Geburtstage, die man sehen darf:                
				if (count($alle_drin)==0 or isset($alle_drin['gebkurz']) or isset($alle_drin['geblang']) or $nurgeb  && !isset($_GET['pagination_news']) && !isset($_GET['pagination_bm']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
				$gr_zusatz=sql_gruppe($sql_tabs['stammdaten']['id']);
				if ($gr_zusatz=='-2') {
					$gr_zusatz='1=1';
				}
				if (!$cfg_pim_eigene_geb and ($gr_zusatz=='1=1' or $gr_zusatz=='')) {
					$sql_from=array($sql_tab['stammdaten']);
					$sql_from2=array($sql_tab['stammdaten_ansprechpartner']);
					$fj=false;
					$gr_zusatz='';
				} else {
					$sql_from=array($sql_tab['stammdaten'], $sql_tab['stammdaten_gruppe_zuordnung']);
					$fj=array($sql_tabs['stammdaten']['id'] => $sql_tabs['stammdaten_gruppe_zuordnung']['stammdaten_id']);
					$gr_zusatz.=' and ';
					
					$sql_from2=array($sql_tab['stammdaten'], $sql_tab['stammdaten_ansprechpartner'], $sql_tab['stammdaten_gruppe_zuordnung']);
					$fj2=array($sql_tabs['stammdaten']['id'] => $sql_tabs['stammdaten_gruppe_zuordnung']['stammdaten_id'], $sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'] => $sql_tabs['stammdaten_gruppe_zuordnung']['stammdaten_id']);
				}
				// nur eigene Geburtstage:
				$pimgeballe=false;
				if ($cfg_pim_eigene_geb) {
					$res7=$db->select(
						$sql_tab['benutzer_gruppe'],
						array(
							$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
							$sql_tabs['benutzer_gruppe']['bezeichnung']
						),
						$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('PIM-Geburtstage')
					);
					if ($row7=$db->zeile($res7)) {
						if ($_SESSION['rechte_bgruppen']=='-1' or preg_match('/,'.$row7[0].',/', ','.$_SESSION['rechte_bgruppen'].',')) {
							$pimgeballe=true;
						}
					}
				}
				if ($cfg_pim_geb_vkleiter_stdlao_ausw_lao and $where_weitl_tkp!='') {
					$gr_zusatz.=$sql_tabs['stammdaten']['betreuer'].$where_weitl_tkp.' and ';
				} elseif ($pimgeballe or ($cfg_pim_tkpgeb_adminalle and $_SESSION['user_gruppe']==2)) {
					
				} elseif ($cfg_pim_eigene_geb) {
					$gr_zusatz.=$sql_tabs['stammdaten']['betreuer'].$where_weitl.' and ';
				}
				
				$gesblock='';
				$gesblock2='';
				
				$dat_m1=intval(date('m')-1);
				if ($dat_m1==0) {
					$dat_m1=12;
				}
				$dat_m2=intval(date('m')+1);
				if ($dat_m2==13) {
					$dat_m2=1;
				}
				
				$res=$db->select(
					$sql_from,
					array(
						'distinct '.$sql_tabs['stammdaten']['id'],
						$sql_tabs['stammdaten']['anzeigename'],
						$sql_tabs['stammdaten']['geburtstag'],
                        $sql_tabs['stammdaten']['betreuer']
					),
					$sql_tabs['stammdaten']['geburtstag'].' is not null and '.
					$sql_tabs['stammdaten']['geburtstag'].'!='.$db->str('0000-00-00').' and '.
					$gr_zusatz.'MONTH('.$sql_tabs['stammdaten']['geburtstag'].') in ('.intval(date('m')).','.$dat_m1.','.$dat_m2.')',
//					$gr_zusatz.''.$db->dbzahlin(intval(date('m')).','.$dat_m1.','.$dat_m2,'MONTH('.$sql_tabs['stammdaten']['geburtstag'].')'),
					'',
					'',
					$fj
					/*
					.' and '.
					$sql_tabs['stammdaten']['betreuer'].'='.$db->dbzahl($userid_pim)
					,
					$sql_tabs['stammdaten']['geburtstag']
					*/
				);
//echo $db->last_sql.'<br>';
				$gebs=array();
				$geb_tage=5;
                while ($row=$db->zeile($res)) {
					if ($_SESSION['cfg_kunde']=='ba' and $row[2]=='1911-11-11') {
						continue;
					}
                    $anzeigename = trim($row[1]);
                    if ($carlo_tw) {
                        $anzeigename = kundenbezeichnung($row[0]);
                    }
					$dat=$db->unixdate($row[2]);
					$m_dat=$dat;
					$dat=adodb_mktime(0,0,0,p4n_mb_string('substr',$dat,3,2), p4n_mb_string('substr',$dat,0,2), date('Y'));
					$dat_2=0;
					if (date('m')==12) {
						$dat_2=adodb_mktime(0,0,0,p4n_mb_string('substr',$m_dat,3,2), p4n_mb_string('substr',$m_dat,0,2), intval(date('Y'))+1);
					}
					$dat_3=0;
					if (date('m')==1) {
						$dat_3=adodb_mktime(0,0,0,p4n_mb_string('substr',$m_dat,3,2), p4n_mb_string('substr',$m_dat,0,2), intval(date('Y'))-1);
					}
					if ( $dat<=(time()+$geb_tage*24*60*60) and $dat>=(time()-$geb_tage*24*60*60) ) {
						$gebs[$dat][]=array($row[0], $anzeigename, $row[2], $row[3]);
					} elseif ( $dat_2<=(time()+$geb_tage*24*60*60) and $dat_2>=(time()-$geb_tage*24*60*60) ) {
						$gebs[$dat_2][]=array($row[0], $anzeigename, $row[2], $row[3]);
					} elseif ( $dat_3<=(time()+$geb_tage*24*60*60) and $dat_3>=(time()-$geb_tage*24*60*60) ) {
						$gebs[$dat_3][]=array($row[0], $anzeigename, $row[2], $row[3]);
					}
				}
				
				// Ansprechpartner:
				$res=$db->select(
					$sql_from2,
					array(
						'distinct '.$sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'],
						$sql_tabs['stammdaten_ansprechpartner']['geburtstag'],
						$sql_tabs['stammdaten_ansprechpartner']['vorname'],
						$sql_tabs['stammdaten_ansprechpartner']['bezeichnung']
					),
					$gr_zusatz.''.$db->dbzahlin(date('m').','.$dat_m1.','.$dat_m2,'MONTH('.$sql_tabs['stammdaten_ansprechpartner']['geburtstag'].')'),
					'',
					'',
					$fj2
					/*
					.' and '.
					$sql_tabs['stammdaten']['betreuer'].'='.$db->dbzahl($userid_pim)
					,
					$sql_tabs['stammdaten']['geburtstag']
					*/
				);
//				echo $db->last_sql;
				$geb_tage=5;
				while ($row=$db->zeile($res)) {
					if ($_SESSION['cfg_kunde']=='ba' and $row[1]=='1911-11-11') {
						continue;
					}
					$dat=$db->unixdate($row[1]);
					$m_dat=$dat;
					$dat=adodb_mktime(0,0,0,p4n_mb_string('substr',$dat,3,2), p4n_mb_string('substr',$dat,0,2), date('Y'));
					$dat_2=0;
					if (date('m')==12) {
						$dat_2=adodb_mktime(0,0,0,p4n_mb_string('substr',$m_dat,3,2), p4n_mb_string('substr',$m_dat,0,2), intval(date('Y'))+1);
					}
					$dat_3=0;
					if (date('m')==1) {
						$dat_3=adodb_mktime(0,0,0,p4n_mb_string('substr',$m_dat,3,2), p4n_mb_string('substr',$m_dat,0,2), intval(date('Y'))-1);
					}
                    
                    $ansprechpartner_anzeigename = $row[2].' '.$row[3];
                    if ($carlo_tw) {
                        $ansprechpartner_anzeigename = $row[3].' '.$row[2];
                    }
					if ( $dat<=(time()+$geb_tage*24*60*60) and $dat>=(time()-$geb_tage*24*60*60) ) {
						$res3=$db->select(
							$sql_tab['stammdaten'],
							$sql_tabs['stammdaten']['firma1'],
							$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($row[0])
						);
						$row3=$db->zeile($res3);
						$ap_anzs=$row3[0];
						//$ap_anzs=kundenbezeichnung($row[0]);
						$gebs[$dat][]=array($row[0], trim($ansprechpartner_anzeigename).' ('.$ap_anzs.')', $row[1], 0);
					} elseif ( $dat_2<=(time()+$geb_tage*24*60*60) and $dat_2>=(time()-$geb_tage*24*60*60) ) {
						$res3=$db->select(
							$sql_tab['stammdaten'],
							$sql_tabs['stammdaten']['firma1'],
							$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($row[0])
						);
						$row3=$db->zeile($res3);
						$ap_anzs=$row3[0];
						//$ap_anzs=kundenbezeichnung($row[0]);
						$gebs[$dat_2][]=array($row[0], trim($ansprechpartner_anzeigename).' ('.$ap_anzs.')', $row[1], 0);
					} elseif ( $dat_3<=(time()+$geb_tage*24*60*60) and $dat_3>=(time()-$geb_tage*24*60*60) ) {
						$res3=$db->select(
							$sql_tab['stammdaten'],
							$sql_tabs['stammdaten']['firma1'],
							$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($row[0])
						);
						$row3=$db->zeile($res3);
						$ap_anzs=$row3[0];
						//$ap_anzs=kundenbezeichnung($row[0]);
						$gebs[$dat_3][]=array($row[0], trim($ansprechpartner_anzeigename).' ('.$ap_anzs.')', $row[1], 0);
					}
				}
				
                if (!$cfg_keine_mitarbeiter_geb_pim) {
                    // Mitarbeiter:
                    $res=$db->select(
                        $sql_tab['benutzer'],
                        array(
                            $sql_tabs['benutzer']['geburtstag'],
                            $sql_tabs['benutzer']['vorname'],
                            $sql_tabs['benutzer']['name'],
                            $sql_tabs['benutzer']['benutzer_id']
                        ),
                        $db->dbzahlin(date('m').','.(date('m')-1).','.(date('m')+1),'MONTH('.$sql_tabs['benutzer']['geburtstag'].')')
                    );
                    $geb_tage=5;
                    while ($row=$db->zeile($res)) {
                        $dat=$db->unixdate($row[0]);
                        if ($dat=='') {
                            continue;
                        }
                        $dat=adodb_mktime(0,0,0,p4n_mb_string('substr',$dat,3,2), p4n_mb_string('substr',$dat,0,2), date('Y'));
                        if ( $dat<=(time()+$geb_tage*24*60*60) and $dat>=(time()-$geb_tage*24*60*60) ) {
                            //$ap_anzs=kundenbezeichnung($row[0]);
                            $gebs[$dat][]=array('-', trim($row[1].' '.$row[2]).' ('._MITARBEITER_.')', $row[0], $row[3]);
                        }
                    }
                }
				
                
                //Geburtstagsliste - design70 Tag
                if (count($gebs)>0) {
					if ($cfg_pim_geblang_sort) {
						@ksort($gebs);
					} else {
						@krsort($gebs);
					}
					@reset($gebs);
					$heute=adodb_mktime(0,0,0,date('m'), date('d'), date('Y'));
					$heute_gebtag='';
                    $x=0;
                    $table_data=array();
                    $table_dataheute=array();
                    $table_dataheute2=array();
                    $geb_lang_data=0;
                    $pagination=new Template_Pagination('widget_pagination_geblang');
					while (list($key, $val)=@each($gebs)) {
						while (list($key2, $val2)=@each($val)) {
                            $geb_lang_data++;
                            
                            $cols_view = array();
							$gebdatum=$db->unixdate($val2[2]);
							
							if (isset($_SESSION['design_70'])) {
								if (strlen($val2[1]) > 30) {
									$userName = substr($val2[1], 0, 30).'...';
								} else {
									$userName = $val2[1];
								}
								$link_kunde = (new Template_Tooltip(
									$val2[1],
									linkToTab($userName, 'stammdaten_main.php?nav=Uebersicht&id='.$val2[0], '', '', '', 1)
								))->getHtml();
							} else {
								$link_kunde = linkToTab($val2[1], 'stammdaten_main.php?nav=Uebersicht&id='.$val2[0], '', '', '', 1);
							}
							
							if ($val2[0] == '-') {
								$link_kunde = $val2[1];
							}
							
							$alter=adodb_date('Y')-adodb_date('Y', $db->unixdate_ts($val2[2]));
							if ($cfg_kfz) {
								$verk=kfz_verk($val2[0], $val2[3]);
								if ($verk=='')
									$verk='&nbsp;';
							}
                          
							if ($key==$heute) {
                                
								$block2=$kblock2;
								$block2=p4n_mb_string('str_replace', '{k_datum}', $gebdatum, $block2);
                                $cols_view[2]=$gebdatum;
								$block2=p4n_mb_string('str_replace', '{k_stammid}', $link_kunde, $block2);
                                $cols_view[0]=$link_kunde;
								$block2=p4n_mb_string('str_replace', '{k_alter}', $alter, $block2);
                                $cols_view[3]=$alter;
								if ($cfg_kfz) {
									$block2=p4n_mb_string('str_replace', '{k_verk}', $verk, $block2);
                                    $cols_view[1]=$verk;
								}
                                $block2=p4n_mb_string('str_replace', '{oddeven}', 'class="'.($x%2==0?'odd':'even').'"', $block2);
								$gesblock2.=$block2;
								
                                ksort($cols_view);
                                if (!$table_data_i3) {
                                    $table_data_i3 = 1;
                                }
                                $table_dataheute[$table_data_i3++] = $cols_view;
 
								$gebdatum='<b><font color=red>'.$gebdatum.'</font></b>';
								$alter='<b><font color=red>'.$alter.'</font></b>';
							}
                            
                            
                            $cols_view = array();
							$block=$kblock;
							$block=p4n_mb_string('str_replace', '{k_datum}', $gebdatum, $block);
                            $cols_view[2]=$gebdatum;
							$block=p4n_mb_string('str_replace', '{k_stammid}', $link_kunde, $block);
                            $cols_view[0]=$link_kunde;
							$block=p4n_mb_string('str_replace', '{k_alter}', $alter, $block);
                            $cols_view[3]=$alter;
                            $block=p4n_mb_string('str_replace', '{oddeven}', 'class="'.($x%2==0?'odd':'even').'"', $block);
                            $x++;
							if ($cfg_kfz) {
								$block=p4n_mb_string('str_replace', '{k_verk}', $verk, $block);
                                $cols_view[1]=$verk;
							}
							$gesblock.=$block;
                            ksort($cols_view);
                            if (!$table_data_i) {
                                $table_data_i = 1;
                            }
                            if (!$table_data_i2) {
                                $table_data_i2 = 1;
                            }
							if ($key==$heute) {
								$heute_gebtag.=$block;
                                $table_dataheute2[$table_data_i2++] = $cols_view;
                                $table_dataheute2b[$key][$table_data_i2++] = $cols_view;
							} else {
                                $table_data[$table_data_i++] = $cols_view;
                                $table_datab[$key][$table_data_i++] = $cols_view;
                            }
						}
					}
					if ($heute_gebtag!='') {
						$zblock=$kblock;
						$zblock=p4n_mb_string('str_replace', '{k_datum}', '<hr>', $zblock);
						$zblock=p4n_mb_string('str_replace', '{k_stammid}', '<hr>', $zblock);
						$zblock=p4n_mb_string('str_replace', '{k_alter}', '<hr>', $zblock);
						$zblock=p4n_mb_string('str_replace', '{k_verk}', '<hr>', $zblock);
					}
				} else {
					$gesblock='<tr class="odd"><td class="td">'._KEINE_GEBURTSTAGE_.'</td><td class="td" colspan="'.($cfg_kfz?'3':'2').'">&nbsp;</td></tr>';
				}
				if ($heute_gebtag=='') {
					$gesblock2='<tr class="odd"><td class="td">'._KEINE_GEBURTSTAGE_.'</td><td class="td" colspan="'.($cfg_kfz?'3':'2').'">&nbsp;</td></tr>';
				}
				}
				$inhalt=p4n_mb_string('str_replace', '{anzahl_geb}', ($cfg_kfz?'4':'3'), $inhalt);
                if (!$nurgeb and $cfg_pim_ohne_geburtstag_lang) {
					$inhalt=preg_replace('/<!geblang1>(.*)<!geblang2>/Uis', '', $inhalt);
				} else {
                    $temp=array();
					if (is_array($table_dataheute2)) {
                    	//$temp=array_merge($table_dataheute2,$table_data);
					} else {
                    	//$temp=$table_data;
					}
                    $tempb=array();
                    if (is_array($table_dataheute2b) and is_array($table_datab)) {
                    	$tempb=$table_dataheute2b+$table_datab;
					} else {
                    	$tempb=$table_datab;
					}
                    if (is_array($tempb)) {
	                    krsort($tempb);
    	                foreach($tempb as $arr) {
        	                foreach($arr as $arr2) {
            	                $temp[]=$arr2;
                	        }
						}
                    }
                    
                    $table_data=array();
					if (isset($temp)) {
						foreach ($temp as $key => $value) {
							if ($pagination!=null && !$pagination->cancelWhile() && 1==2) {
							continue;
							}
							$table_data[($key+1)]=$value;
						}
					}
					$inhalt=preg_replace('/\{block-geb-start\}(.*)\{block-geb-ende\}/Uis', $heute_gebtag.$zblock.$gesblock, $inhalt);
				}
				$pb_inh['gebkurz']=preg_replace('/\{block-geb2-start\}(.*)\{block-geb2-ende\}/Uis', $gesblock2, $pim_bloecke['gebkurz']);

                
                if ($_SESSION['design_70']) {
                    $temp = array(
                        $lang['_K-STAMMID_'],
                        ($cfg_kfz?_VERKAEUFER_:''),
                        $lang['_K-DATUM_'],
                        $lang['_K-ALTER_']
                    );

                    $table = Template_Default::Table($temp,$table_dataheute,array('size'=>'sm','maxHeight'=>248,'minHeight'=>248),array(),array(),null,null,$card=true, _GEBURTSTAGE_,array('paginationInCard'=>true,'cardOptions'=>array('border'),'addScrollBar'=>true));
                    //$card=Template_Default::Card(_GEBURTSTAGSLISTE_,new Template_ElementList(array(),'','hozizontal'),$table);
                    $design_widget['gebkurz']=new Template_ElementList($table,'','gebkurz_widget');
                    $design_widget_auswahl['gebkurz']=_GEBURTSTAGE_;
                    $table_dataheute=array();
                }
                
                
				if ($cfg_pim_ohne_geburtstag_lang) {
                    $pb_inh['geblang']='';
				} else {
                    $pb_inh['geblang']=preg_replace('/\{block-geb-start\}(.*)\{block-geb-ende\}/Uis', $heute_gebtag.$zblock.$gesblock, $pim_bloecke['geblang']);
                    
                    if ($_SESSION['design_70']) {
                        $temp = array(
                            $lang['_K-STAMMID_'],
                            ($cfg_kfz?_VERKAEUFER_:''),
                            $lang['_K-DATUM_'],
                            $lang['_K-ALTER_'],
                        );

                        if ($pagination!=null) {
                        //$pagination->create($geb_lang_data);
                        //$pagination->setRequest('GET', 'pagination_geblang', 'pim.php', array('pagination_geblang=1'));
                        }       
        
                  
                        $table = Template_Default::Table(
							$temp,
							$table_data,
							array(
								'size' => 'sm',
								'maxHeight' => 248,
								'minHeight' => 248,
								'sort' => false/*,'sortDefaultOrder'=>array($lang['_K-DATUM_']=>'asc')/*,'dataType'=>array($lang['_K-DATUM_']=>'date')*/
							),
							array(),
							array(),
							null,
							null,
							true,
							_GEBURTSTAGE_.' ('._AUSFUEHRLICH_.')',
							array(
								'paginationInCard' => true,
								'cardOptions' => array('border'),
								'addScrollBar' => true
							)
						);
                        //$card=Template_Default::Card(_GEBURTSTAGSLISTE_,new Template_ElementList(array(),'','hozizontal'),array($table,$pagination));
                        if (isset($_GET['pagination_geblang'])){
                            Modern_Helper_Request::requestStart();
                            echo $table->getHtml();
                            echo javas('pim_autoheight_();');
                            exit;
                        }  
                        $design_widget['geblang']=new Template_ElementList($table,'pagination_geblang','geblang_widget');
                        $design_widget_auswahl['geblang']=_GEBURTSTAGE_.'+';
                        $table_data=array();
                    }
                    
                    
				}
                
                $inhalt=preg_replace('/\{block-geb2-start\}(.*)\{block-geb2-ende\}/Uis', $gesblock2, $inhalt);
			}
	if ($zeitdebug) {
		echo 'nach Geb: '.zeitnahme().'<br>';
	}
			
			// Kalender:
			if (count($alle_drin)==0 or isset($alle_drin['kalender']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
			
            //$cfg_pim_kalender_zusatzkal_links=true;    
                
            $month=date('m');
			$year=date('Y');
            if ($cfg_modern && $cfg_jqkal) {
                require_once('inc/lib_feiertag.php');
                include_once('inc/lib_kalender_neu.php');
                include_once('inc/class_kalender_requests.php');
                $requests =new KalenderRequests(array(), array('uid'=>$userid_pim));
                $testdichte=json_encode($requests->getTermindichte(array('encode'=>'json')));
                $kal_text.=javas(' 
                    jq1112(document).ready(function ($) {
                        DatepickerHelper.create("#pimkalender",{termindichte:true, uid:'.$userid_pim.', stid:0, zusatz:0, json:'.$testdichte.'});
                    });'
                );
                $kalender='<div style="position:relative;"><div id="pimkalender"></div></div>';
            } else {
                $phs=$kln1;//'kalender.php';
                $kal=new event_calendar();
                if ($cfg_pimkal_ohne_auslieferung) {
                    $kal->ohne_auslieferung=true;
                }
                $kal->set_date(1, $month, $year);
                $kalender=''.$kal->gen_month_table($userid_pim, 0) ;
            }   
			$kal_text.=javas('
			var am='.intval(date('m')).';
			var aj='.intval(date('Y')).';
			function lade_kal1(vz) {
				if (vz==0) {
					if (am==1) {
						am=12;
						aj--;
					} else {
						am--;
					}
				}
				if (vz==1) {
					if (am==12) {
						am=1;
						aj++;
					} else {
						am++;
					}
				}
				document.getElementById("aktm").innerHTML=am;
				document.getElementById("aktj").innerHTML=aj;

                '.($cfg_jqkal?'
                if (typeof cfg_modern != typeof undefined && cfg_modern==true) {
                    if (vz==0) {
                        jq1112("#pimkalender").find(".ui-datepicker-prev").click();
                    }
                    if (vz==1) {
                        jq1112("#pimkalender").find(".ui-datepicker-next").click();
                    }
                    return false;
                }
                ':'').'
                
                if (typeof p4ntoken == "undefined") {p4ntoken="";}
                                var xmlhttp;
                                try { xmlhttp = new XMLHttpRequest(); } catch (error) {
                                        try { xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); } catch (error) { return false;	}
                                }

                                xmlhttp.open("POST", "pim.php", false);
                                
                                xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                                xmlhttp.setRequestHeader("X-Requested-With", "XMLHttpRequest"); 
                                
                                xmlhttp.onreadystatechange=function() { 
                                        if (xmlhttp.readyState==4 && xmlhttp.status==200) {
                                            if (typeof getNewToken == "function") {
                                                p4ntoken = getNewToken(xmlhttp.getResponseHeader("p4ntoken"));
                                            }
                                            response=xmlhttp.responseText;
                                            document.getElementById("monkal").innerHTML=response;
                                        } 
                                };

                                xmlhttp.send("genkal=1&m="+am+"&j="+aj+"&p4ntoken="+p4ntoken);
		
			}');
			$kal_text.='<table id="pim_kalender_table" class="table-ignore2 moderntable table-nohover table-margin-bottom"><!sbl>'
                    . '<tr class="odd">'
                    . '<td class="td" id="monkal">'.($cfg_modern?'<table class="table-kalendar"><tr><td>':'').$kalender.($cfg_modern?'</td></tr></table>':'').'</td>'
                    . '<td class="'.(($cfg_modern)?'td ':'t ').'zusatzinfo">'.(($cfg_modern)?'<table class="table-nostyle table-fixed">':'');
			$kal_text.=(($cfg_modern)?'<tr><td colspan="2">':'<font size=1>').link2(_TERMIN_NEUEINTRAG_, $kln1.'?uid='.$userid_pim.'&zusatz=0&stid=0&neu=1').(($cfg_modern)?'</td>':'</font><br><br>');
            $action_list=array();
            $action_list[]=new Template_Link(_TERMIN_NEUEINTRAG_, $kln1.'?uid='.$userid_pim.'&zusatz=0&stid=0&neu=1');
            $kal_text.=(($cfg_modern)?'<tr><td>':'').link2(_KALENDER_ANDERE_, 'kalender.php?andere=1').':'.(($cfg_modern)?'<br>':'<br>');
            $action_list[]=new Template_Link(_KALENDER_ANDERE_, 'kalender.php?andere=1');
            $res=$db->select(
				$sql_tab['kalender_benutzer'],
				array(
					$sql_tabs['kalender_benutzer']['benutzer_id'],
					$sql_tabs['kalender_benutzer']['schreibrecht']
				),
				$sql_tabs['kalender_benutzer']['ziel_benutzer_id']
					.$where_weitl
			);
          	if ($db->anzahl($res)==0) {
				$kal_text.=(($cfg_modern)?'':'')._KALENDER_ANDERE_KEINE_.(($cfg_modern)?'<br>':'<br>');
            }
            $anderekalender=array('-1'=>'-');
            $anderekalenderlinks=array();
            $anderekalender_temp = array();
            $temp_action_list=array();
			while ($row=$db->zeile($res)) {
				if (isset($kalschon[$row[0]])) {
					continue;
				}
				$kalschon[$row[0]]=1;
				$res2=$db->select(
					$sql_tab['benutzer'],
					array(
						$sql_tabs['benutzer']['benutzer_id'],
						$sql_tabs['benutzer']['login'],
						$sql_tabs['benutzer']['vorname'],
						$sql_tabs['benutzer']['name']
					),
					$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row[0]),
					$sql_tabs['benutzer']['name']
				);
				if ($row2=$db->zeile($res2)) {
                    $name_benutzer = $row2[3].', '.$row2[2];
                    $anderekalender_temp[$row[0]]=$name_benutzer;
                    $anderekalenderlinks[$name_benutzer]='&nbsp;-&nbsp;'.link2($name_benutzer, $kln1.'?uid='.$row[0]);
                    $temp_action_list[]=new Template_Link($name_benutzer, $kln1.'?uid='.$row[0]);
				}
			}
            if ($cfg_modern) {
                if (count($anderekalender_temp)<6 && !$_SESSION['design_70']) {
                    ksort($anderekalenderlinks);
                    $kal_text.=implode('<br>', $anderekalenderlinks);
                } else {
                    asort($anderekalender_temp);
                    $anderekalender = $anderekalender + $anderekalender_temp;
                    $kal_text.=''.$form->selectinput('',$anderekalender,-1,false,'onchange="javascript: location.href=\''.$kln1.'?uid=\'+this.value"').'</td></tr>';
                    $actionMenuButton = Template_IconTextButton::init('','andere Kalender','', 'keyboard_arrow_down__right','','','xs','grey','quadratic');
                    $actionMenuContent = new Template_LinkList($temp_action_list);
                    Template_InlineOverlay::prepare($actionMenuButton, $actionMenuContent, 'pim_kalender_aktionen_anderekalender');
                    //$kal_text70[]=new Template_ElementList(array($actionMenuButton,$actionMenuContent),'','');
                }
            } else {
                ksort($anderekalenderlinks);
                $kal_text.=implode('<br>', $anderekalenderlinks);
            }
			if ($cfg_pim_kalender_zusatzkal_links) {
				$zuskals=array();
				 $res=$db->select(
					$sql_tab['kalender_zusatz'],
					array(
						$sql_tabs['kalender_zusatz']['kalender_zusatz_id'],
						$sql_tabs['kalender_zusatz']['bezeichnung']
					)
				);
				while ($row=$db->zeile($res)) {
					$zuskals[$row[1]]='&nbsp;-&nbsp;'.link2($row[1], 'kalender.php?extern='.$row[0]);
				}
				if (count($zuskals)>0) {
					@ksort($zuskals);
					$kal_text.='<br>'._ZUSATZKALENDER_.':';
					foreach ($zuskals as $zkkey => $zkval) {
						$kal_text.='<br>'.$zkval;
					}
				}
			}
            /*
			// wartende Termine von mir:
			$kal_text.=link2(_PIM_KALENDER_OFFEN_, 'kalender.php?offen=1').':<br>';
			$res=$db->select(
				$sql_tab['kalender'],
				$sql_tabs['kalender']['kalender_id'],
				$sql_tabs['kalender']['user_id'].$where_weitl.' and '.
					$sql_tabs['kalender']['bestaetigung'].'='.$db->dblogic(true).' and '.
					$sql_tabs['kalender']['bestaetigung_gelesen'].'='.$db->dblogic(false),
					$sql_tabs['kalender']['erstellt_am']
			);
			$x=$db->anzahl($res);
			if ($x==0)
				$kal_text.='&nbsp;-&nbsp;'._KEINE_.' '._PIM_KALENDER_OFFEN1_.'<br>';
			else
				$kal_text.='&nbsp;-&nbsp;'.$x.' '._PIM_KALENDER_OFFEN1_.'<br>';
            
			// wartend f�r einen selbst:
			$res=$db->select(
				$sql_tab['kalender'],
				$sql_tabs['kalender']['kalender_id'],
				$sql_tabs['kalender']['betreuer'].$where_weitl.' and '.
					$sql_tabs['kalender']['bestaetigung'].'='.$db->dblogic(true).' and '.
					$sql_tabs['kalender']['bestaetigung_gelesen'].'='.$db->dblogic(false),
					$sql_tabs['kalender']['erstellt_am']
			);
			$x=$db->anzahl($res);
			if ($x==0)
				$kal_text.='&nbsp;-&nbsp;'._KEINE_.' '._PIM_KALENDER_OFFEN2_.'<br>';
			else
				$kal_text.='&nbsp;-&nbsp;'.$x.' '._PIM_KALENDER_OFFEN2_.'<br>';
			*/
			// Einladungen:
			$kal_text.=(($cfg_modern)?'<tr><td>':'')._PIM_KALENDER_EINLADUNG_.':'.(($cfg_modern)?'</td>':'<br>');
			$res=$db->select(
                    array(
				$sql_tab['kalender_einladung'],
                        $sql_tab['kalender']
                    ),
				$sql_tabs['kalender_einladung']['kalender_id'],
				$sql_tabs['kalender_einladung']['kalender_id'].'='.$sql_tabs['kalender']['kalender_id'].' and '.
				$sql_tabs['kalender_einladung']['benutzer_id'].$where_weitl.' and '.
				$sql_tabs['kalender_einladung']['bestaetigung'].'='.$db->dblogic(false).' and '.$sql_tabs['kalender']['beginn'].'>='.$db->dbdate(adodb_date('d.m.Y'), 0),
					$sql_tabs['kalender_einladung']['datum'].' desc'
			);
			$x=$db->anzahl($res);
			if ($x==0) {
				$kal_text.=(($cfg_modern)?'<td>':'').'&nbsp;-&nbsp;'._KEINE_.' '._PIM_KALENDER_EINLADUNG_.(($cfg_modern)?'</td></tr>':'<br>');
            } else {
                $kal_text.=(($cfg_modern)?'<td>':'').'&nbsp;-&nbsp;'.linkToTab($x.' '._PIM_KALENDER_EINLADUNG_, 'kalender.php?offen=1', '', '', '', 5).(($cfg_modern)?'</td></tr>':'<br>');
                $kal_text70[]=new Template_Tooltip($x.' '._PIM_KALENDER_EINLADUNG_, Template_IconTextButton::init('',' '.$x,'','insert_invitation','','', 'xs', 'grey', 'quadratic')
                        ->setRequest('GET',$pim_modal_inhalt,'kalender.php','offen=1',$pim_modal));
			}
            $kal_text.=(($cfg_modern)?'</td></tr></table>':'').'</td></tr></table>';
			}
			$inhalt=preg_replace('/\{kalender_datum\}/Uis', $month.' / '.$year, $inhalt);
			$inhalt=preg_replace2('/\{kalender\}/Uis', $kal_text, $inhalt);
			
			$pb_inh['kalender']=preg_replace('/\{kalender_datum\}/Uis', link2(_STAMMDATEN_NAV_ZURUECK_, 'javascript: lade_kal1(0); void(0);', 'pfeil_l.gif').'&nbsp;<div id="aktm" style="display:inline;">'.$month.'</div> / <div id="aktj" style="display:inline;">'.$year.'</div>&nbsp;'.link2(_STAMMDATEN_NAV_VOR_, 'javascript: lade_kal1(1); void(0);', 'pfeil_r.gif'), $pb_inh['kalender']);
			$pb_inh['kalender']=preg_replace2('/\{kalender\}/Uis', $kal_text, $pb_inh['kalender']);
            
            // region Get the last 5 unfinished appointments of the user.
            $table = $sql_tab['kalender'].' JOIN '.$sql_tab['korrespondenz'].
                ' ON '.$sql_tabs['kalender']['kalender_id'].'='.$sql_tabs['korrespondenz']['kalender_id'];
            
            $where = $sql_tabs['kalender']['betreuer'].'='.$db->dbzahl($_SESSION['user_id']);
            $where .= ' AND ';
            $where .= '(';
            $where .= $sql_tabs['korrespondenz']['ergebnis_datum'].' IS NULL';
            $where .= ' OR ';
            $where .= $sql_tabs['korrespondenz']['erledigt'].'='.$db->dbzahl(0);
            $where .= ')';
            if ($_SESSION['design_70'])
            $where .= ' AND '.$sql_tabs['kalender']['ende'].'>='.$db->dbtimestamp(time());
            $termine = array();
            $res_kaltermine = $db->select(
                $table,
                array(
                    $sql_tabs['kalender']['kalender_id'],
                    $sql_tabs['kalender']['betreuer'],
                    $sql_tabs['kalender']['betreff'],
                    $sql_tabs['kalender']['beschreibung'],
                    $sql_tabs['kalender']['beginn'],
                    $sql_tabs['kalender']['ende']
                ),
                $where,
                $sql_tabs['kalender']['beginn'].' ASC',
                '',
                false,
                (($_SESSION['design_70'])?0:5)
            );
            unset($where, $table);
            
            while ($row_kaltermine = $db->zeile($res_kaltermine)) {
                $termine[] = new Template_ElementList(
                    array(
                        new Template_Icon('event', 'grey', 'md'),
                        new Template_ElementList(
                            array(
                                new Template_ElementList(
                                    array(
                                        Template_Text::init(
                                            abkuerzung($row_kaltermine[2], 30),
                                            -1,
                                            array('bold')
                                        )->addCustomClass('mb-0')
                                    ), '', 'horitontal nowrap mb-0'
                                ),
                                Template_Text::init(
                                    $db->unixdatetime($row_kaltermine[4])
                                )->addCustomClass('text-light-grey')
                            ), '', 'vertical no-scroll'),
                        new Template_Link(
                            new Template_Icon('edit', 'grey'),
                            'kalender_neu.php?uid='.$_SESSION['user_id'].'&termin='.$row_kaltermine[0]
                        )
                    ), '', 'horizontal nowrap pr-16 align-items-start'
                );
            }
            // endregion
            
            $actionMenuButton = Template_IconTextButton::init('','Aktionen','', 'keyboard_arrow_down__right','','','xs','blue','quadratic');
            $actionMenuContent = new Template_LinkList($action_list);
            Template_InlineOverlay::prepare($actionMenuButton, $actionMenuContent, 'pim_kalender_aktionen');
            //$right=new Template_ElementList(array($actionMenuButton,$actionMenuContent),'','');
            
            $nextmonth=date('Y,m,d', strtotime('next month'));
            
            $temp=array();
            $temp[0][0]=Template_GridTableCol::init(12,4,4,new Template_DatePicker('pim_kalender',true, true,true,true,true))->addCustomClass('border-right')->setAttribute('data-on-document-ready', 'pim_kalender_sync')->setAttribute('data-on-document-ready', 'pim_kalender_sync_refresh');
            $temp[0][1]=Template_GridTableCol::init(12,4,4,new Template_DatePicker('pim_kalender2',true, true,true,true,true,$nextmonth))->addCustomClass('border-right')->setAttribute('data-on-document-ready', 'pim_kalender_sync')->setAttribute('data-on-document-ready', 'pim_kalender_sync_refresh');  
             $kalender=Template_Default::Card('',null,
                    new Template_ElementList($termine,'','vertical w-auto')
                    ,array('maxHeight'=>265,'minHeight'=>265));
            $temp[0][2]=Template_GridTableCol::init(12,4,4,$kalender);
            
           
            
            
            
            $kalender=Template_Default::Card('Kalender',new Template_ElementList(array($kal_text70,$right),'','horizontal'),
                    new Template_GridTable($temp)
                 ,array('padding','border','maxHeight'=>300,'minHeight'=>300));
            $pim_requests++;
            /*require_once('inc/lib_feiertag.php');
            include_once('inc/lib_kalender_neu.php');
            include_once('inc/class_kalender_requests.php');
            $requests =new KalenderRequests(array(), array('uid'=>$userid_pim));
            $testdichte=json_encode($requests->getTermindichte(array('encode'=>'json')));
            echo $testdichte;
            $kal_text.=javas(' 
                jq1112(document).ready(function ($) {
                    DatepickerHelper.create("#pim_kalender",{termindichte:true, uid:'.$userid_pim.', stid:0, zusatz:0, json:'.$testdichte.'});
                });'
            );*/
            
            $design_widget['kalender']=new Template_ElementList(array($kalender),'','kalender_widget');
            $design_widget_auswahl['kalender']=_KALENDER_;
            
            
	if ($zeitdebug) {
		echo 'nach Kalender: '.zeitnahme().'<br>';
	}
			
    
    
    
    
			// Aufgaben:
			if (count($alle_drin)==0 or isset($alle_drin['aufgaben']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
                $aufg_text='<table class="table-ignore2 moderntable table-margin-bottom"><!sbl>';
                
                $pagination=new Template_Pagination('pagination_widget_aufgaben',5);
                
                
                $res=$db->select(
                    $sql_tab['aufgaben'],
                    array(
                        $sql_tabs['aufgaben']['erledigt'],
                    ),
                    $sql_tabs['aufgaben']['betreuer'].$where_weitl.' and '.
                        $sql_tabs['aufgaben']['erledigt'].'='.$db->dblogic(false),
                    $sql_tabs['aufgaben']['erledigt'].' asc, '.$sql_tabs['aufgaben']['faellig'].' asc, '.$sql_tabs['aufgaben']['datum'].' desc'   
                );
           
                $x2=$db->anzahl($res);
                
                
                $res=$db->select(
                    $sql_tab['aufgaben'],
                    array(
                        $sql_tabs['aufgaben']['erledigt'],
                        $sql_tabs['aufgaben']['betreff'],
                        $sql_tabs['aufgaben']['inhalt'],
                        $sql_tabs['aufgaben']['aufgaben_id'],
                        $sql_tabs['aufgaben']['stammdaten_id'],
                        $sql_tabs['aufgaben']['faellig'],			// 5
                        $sql_tabs['aufgaben']['fortschritt']
                    ),
                    $sql_tabs['aufgaben']['betreuer'].$where_weitl.' and '.
                        $sql_tabs['aufgaben']['erledigt'].'='.$db->dblogic(false),
                    $sql_tabs['aufgaben']['erledigt'].' asc, '.$sql_tabs['aufgaben']['faellig'].' asc, '.$sql_tabs['aufgaben']['datum'].' desc',
                    '',
                    '',
                    ($_SESSION['design_70'] && !isset($_POST['leadprozess']) && 1==2?$pagination->limit():0),
                    ($_SESSION['design_70'] && !isset($_POST['leadprozess']) && 1==2?$pagination->von():0)    
                );
                $x=$db->anzahl($res);

                
                if ($x==0) {
                    $aufg_text.='<tr><td>'._KEINE_.' '.$lang['_ADMIN-AUFGABEN_'].'</td></tr>';
                    $inhalt=p4n_mb_string('str_replace', '{aufgaben_anzahl}', '', $inhalt);
                    $pb_inh['aufgaben']=p4n_mb_string('str_replace', '{aufgaben_anzahl}', '', $pb_inh['aufgaben']);
                } else {
                    $res2=$db->select(
                        $sql_tab['aufgaben'],
                        $sql_tabs['aufgaben']['aufgaben_id'],
                        $sql_tabs['aufgaben']['betreuer'].$where_weitl.' and '.
                            $sql_tabs['aufgaben']['erledigt'].'=0'
                    );
                    $aufg_nerl=$db->anzahl($res2);
                    $res2=$db->select(
                        $sql_tab['aufgaben'],
                        $sql_tabs['aufgaben']['aufgaben_id'],
                        $sql_tabs['aufgaben']['betreuer'].$where_weitl
                    );
                    $inhalt=p4n_mb_string('str_replace', '{aufgaben_anzahl}', ' - '.$aufg_nerl.' '._VON_.' '.$db->anzahl($res2).' '._OFFEN_, $inhalt);
                    $pb_inh['aufgaben']=p4n_mb_string('str_replace', '{aufgaben_anzahl}', '', $pb_inh['aufgaben']);
                    $aufg_anz=0;
                    $max_aufg=3;
                    if ($_SESSION['cfg_kunde']=='carlo_kurlaender') {
                        $max_aufg=10;
                    } else {
                        $max_aufg=50;
                    }
                    $table_data=array();
                    while ($aufg_anz<$max_aufg and $row=$db->zeile($res)) {
                        $cols_view=array();
                        $aufg_anz++;
                        $zus_aufg='';
                        if (intval($row[4])>0) {
                            $zus_aufg.=' - '.linkToTab(kundenbezeichnung($row[4]), 'stammdaten_main.php?nav=Uebersicht&id='.$row[4], '', '', 1);
                        }
                        $faellig=$db->unixdate($row[5]);
                        if ($faellig!='') {
                            $faellig=_FAELLIG_.' '.$faellig;
                        }
                        $proz_a='';
                        if (intval($row[6])>0) {
                            $proz_a.=intval($row[6]).'%';
                        }
                        $aufg_text.='<tr '.tr_zeile().' class="odd"><td class="td" width="30">'.link2('', 'pim.php?aufgabe_erledigt='.$row[3], grafikhaken($row[0], true)).'</td><td class="td">'.($row[2]!=''?oltext($row[2], $row[1], 'aufgaben.php'):$row[1]).$zus_aufg.'</td><td class="td">'.$faellig.'</td><td class="td">'.$proz_a.'</td></tr>';

                        $cols_view[4]=new Template_Link('', 'pim.php?pagination_aufgaben=1&aufgabe_erledigt='.$row[3], grafikhaken($row[0], true),'','target="pagination_aufgaben"');
                        $cols_view[0]=($row[2]!=''?New Template_Tooltip($row[2], $row[1], ''):$row[1]);
                        $cols_view[1]=(intval($row[4])>0?linkToTab70(kundenbezeichnung($row[4]), 'stammdaten_main.php?nav=Uebersicht&id='.$row[4], '', '','', 1):'');
                        $cols_view[2]=$faellig;
                        $cols_view[3]=$proz_a;

                        ksort($cols_view);
                        if (!$table_data_i) {
                            $table_data_i = 1;
                        }
                        $table_data[$table_data_i++] = $cols_view;
                    }
                }
                $aufg_text.='<tr class="odd"><td class="td" colspan='.(($cfg_modern)?'4':'2').'>'.link2(_AUFGABEN_EINTRAGEN_, 'aufgaben.php').'</td></tr>';
                $aufg_text.='</table>';

                if ($_SESSION['design_70']) {
                    if (!isset($_GET['pagination_aufgaben']) && 1==2){
                        $card70=Template_Module::PimKennzahlenCard($lang['_ADMIN-AUFGABEN_'], Template_IconButton::init('','','','open_in_new','','',$sizeClass = 'sm',  'transparent-black', 'round')
                                ->setRequest('GET',$pim_modal_inhalt,'pim.php','pagination_aufgaben=1',array($pim_modal),-1,false,'',''),null,
                            array(
                                'alle Aufgaben'=>$x
                            )
                        );
                        $design_widget['aufgaben']=new Template_ElementList($card70,'pagination_aufgaben','aufgaben_widget');
                        $design_widget_auswahl['aufgaben']=$lang['_ADMIN-AUFGABEN_'];
                    } else {
                    
                        $temp = array(
                            _BEZEICHNUNG_,
                            _KUNDE_,
                            _FAELLIG_,
                            _PROZENT_,
                            _AKTION_,
                        );
                        $priority = array(
                            _BEZEICHNUNG_,
                            _AKTION_,
                        );
                        //$pagination->create($x2);
                        //$pagination->setRequest('GET', 'pagination_aufgaben', 'pim.php', array('pagination_aufgaben=1'));

                        $launch=new Template_IconButton('','','','launch','aufgaben.php','','sm');
                        
                        //($header=array(),$table_data=array(),$optionsTable=array(),$filter=array(),$search=array(),$button=null,$pagination=null,$card=false, $card_title='', $OPTIONS=null)
                        $table=Template_Default::Table($temp,$table_data,array('size'=>'sm','priority'=>$priority,'maxHeight'=>248,'minHeight'=>248),$filter=array(),$search=array(),$launch,null,true, $lang['_ADMIN-AUFGABEN_'],array('paginationInCard'=>true,'cardOptions'=>array('border'),'addScrollBar'=>true));
                       // $card=Template_Default::Card($lang['_ADMIN-AUFGABEN_'],new Template_ElementList(array($launch),'','hozizontal'),array($table,$pagination));

                        if (isset($_GET['pagination_aufgaben']) && 1==2){
                            Modern_Helper_Request::requestStart();
                            echo Template_Default::ModalHeader($lang['_ADMIN-AUFGABEN_'])->getHtml();
                            echo $table->getHtml();
                            echo Template_Default::ModalFooter('')->getHtml();
                           // echo javas('pim_autoheight_();');
                            exit;
                        } 
                        
                        if (isset($_GET['pagination_aufgaben']) && 1==2){
                            Modern_Helper_Request::requestStart();
                            echo $table->getHtml();
                            echo javas('pim_autoheight_();');
                            exit;
                        } 
                       
                        if (isset($feld2['aufgabe_erledigt'])) {
                            Modern_Helper_Request::requestStart();
                            echo $table->getHtml();
                            exit;
                        }
                        
                        $design_widget['aufgaben']=new Template_ElementList($table,'pagination_aufgaben','aufgaben_widget');
                        $design_widget_auswahl['aufgaben']=$lang['_ADMIN-AUFGABEN_'];

                    }
                    $table_data=array();
                }
            
			}
//			$aufg_text.='<br>';
			$pb_inh['aufgaben']=preg_replace('/\{aufgaben\}/Uis', $aufg_text, $pb_inh['aufgaben']);
			$inhalt=preg_replace('/\{aufgaben\}/Uis', $aufg_text, $inhalt);
			
	if ($zeitdebug) {
		echo 'nach Aufgaben: '.zeitnahme().'<br>';
	}
			
			// Pinnwand:
			if (count($alle_drin)==0 or isset($alle_drin['pinnwand'])&& !isset($_GET['pagination_bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang'])&& !isset($_GET['pagination_useronline']) && !isset($_GET['pagination_korr_1']) && !isset($_GET['pagination_aufgaben']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps']) && !isset($_GET['pagination_tkpwps2']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
			$gruppen=$_SESSION['rechte_bgruppen'];
			
            $pagination=new Template_Pagination('widget_pagination_pinnwand',5);
            
            $res=$db->select(
				array(
					$sql_tab['pinnwand'],
					$sql_tab['pinnwand_gruppe_zuordnung']
				),
				array(
					'distinct '.$sql_tabs['pinnwand']['datum'],
					$sql_tabs['pinnwand']['betreff']
				),
				'('.$db->dbzahlin($gruppen,$sql_tabs['pinnwand_gruppe_zuordnung']['gruppe_id']).' or '.
				$sql_tabs['pinnwand']['user_id'].$where_weitl.
				') and ('.$sql_tabs['pinnwand']['gueltig_von'].'<='.$db->dbdate(time()).
				' or '.$sql_tabs['pinnwand']['gueltig_von'].'='.$db->str('0000-00-00').
				' or '.$sql_tabs['pinnwand']['gueltig_von'].' is null'.
				') and ('.$sql_tabs['pinnwand']['gueltig_bis'].'>='.$db->dbdate(time()).
				' or '.$sql_tabs['pinnwand']['gueltig_bis'].'='.$db->str('0000-00-00').
				' or '.$sql_tabs['pinnwand']['gueltig_bis'].' is null)',
				$sql_tabs['pinnwand']['datum'].' desc',
				'',
				array(
					$sql_tabs['pinnwand_gruppe_zuordnung']['pinnwand_id']
						=> $sql_tabs['pinnwand']['pinnwand_id']
				)
			);
            $x2=$db->anzahl($res);
            
            $res=$db->select(
				array(
					$sql_tab['pinnwand'],
					$sql_tab['pinnwand_gruppe_zuordnung']
				),
				array(
					'distinct '.$sql_tabs['pinnwand']['datum'],
					$sql_tabs['pinnwand']['betreff'],
					$sql_tabs['pinnwand']['beschreibung'],
					$sql_tabs['pinnwand']['pinnwand_id']
				),
				'('.$db->dbzahlin($gruppen,$sql_tabs['pinnwand_gruppe_zuordnung']['gruppe_id']).' or '.
				$sql_tabs['pinnwand']['user_id'].$where_weitl.
				') and ('.$sql_tabs['pinnwand']['gueltig_von'].'<='.$db->dbdate(time()).
				' or '.$sql_tabs['pinnwand']['gueltig_von'].'='.$db->str('0000-00-00').
				' or '.$sql_tabs['pinnwand']['gueltig_von'].' is null'.
				') and ('.$sql_tabs['pinnwand']['gueltig_bis'].'>='.$db->dbdate(time()).
				' or '.$sql_tabs['pinnwand']['gueltig_bis'].'='.$db->str('0000-00-00').
				' or '.$sql_tabs['pinnwand']['gueltig_bis'].' is null)',
				$sql_tabs['pinnwand']['datum'].' desc',
				'',
				array(
					$sql_tabs['pinnwand_gruppe_zuordnung']['pinnwand_id']
						=> $sql_tabs['pinnwand']['pinnwand_id']
				),
                ($_SESSION['design_70'] && 1==2?$pagination->limit():0),
                ($_SESSION['design_70'] && 1==2?$pagination->von():0)   
			);
			$pw_text='';
            $table_data=array();
			while ($row=$db->zeile($res)) {
                $cols_view=array();
				$pwlink=oltext($row[2], $row[1], 'pinnwand.php?pwid='.$row[3], _PW_BESCHREIBUNG_);
                $pwlink70=new Template_Tooltip($row[2], array(new Template_Icon('mdi-information-outline'),$row[1]), 'pinnwand.php?pwid='.$row[3], _PW_BESCHREIBUNG_);
				if (strtolower(substr($row[2], 0, 5))=='http:' or strtolower(substr($row[2], 0, 6))=='https:'  or substr($row[2], 0, 2)=='\\\\') {
					$row[2]=str_replace('\\', '\\\\', nl2br($row[2]));
					$pwlink=link2($row[1], $row[2], '', '', 'target="_blank"');
                    $pwlink70=new Template_Link($row[1], $row[2], '', '', 'target="_blank"');
				}
				$pw_text.='<tr><td>'.$db->unixdate($row[0]).'</td><td>'.$pwlink.'</td></tr>';
                $cols_view[0]=$db->unixdate($row[0]);
                $cols_view[1]=$pwlink70;
                
                ksort($cols_view);
                if (!$table_data_i) {
                    $table_data_i = 1;
                }
                $table_data[$table_data_i++] = $cols_view;
			}
			if ($pw_text=='')
				$pw_text='<table class="moderntable table-nohover table-margin-bottom"><!sbl><tr><td>'.link2(_PW_KEINE_EINTRAEGE_, 'pinnwand.php').'</td></tr></table>';
			else
				$pw_text='<table class="moderntable table-nohover table-margin-bottom"><!sbl><tr><th>'._PW_DATUM_.'</th><th>'._PW_BETREFF_.'</th></tr>'.$pw_text.'</table>';
			}
			$pb_inh['pinnwand']=preg_replace('/\{pinnwand\}/Uis', $pw_text, $pb_inh['pinnwand']);
			$inhalt=preg_replace('/\{pinnwand\}/Uis', $pw_text, $inhalt);
            
            if ($_SESSION['design_70']) {
                $temp = array(
                    _PW_DATUM_,
                    _PW_BETREFF_
                );
                
                if ($pagination) {
                   // $pagination->create($x2);
                   // $pagination->setRequest('GET', 'pagination_pinnwand', 'pim.php', array('pagination_pinnwand=1'));
                }
				
				$launch = new Template_IconButton('', '', '', 'launch', '', '', 'sm');
				$launch->onClick('linkToTab(\'pinnwand.php\');');
				$table = Template_Default::Table(
					$temp,
					$table_data,
					array('size' => 'sm', 'maxHeight' => 248, 'minHeight' => 248),
					array(),
					array(),
					$launch,
					null,
					true,
					$lang['_PIM-PINNWAND_'],
					array(
						'paginationInCard' => true,
						'cardOptions' => array('border'),
						'addScrollBar' => true
					)
				);
               // $card=Template_Default::Card($lang['_PIM-PINNWAND_'],new Template_ElementList(array(),'','hozizontal'),$table);
                
                if (isset($_GET['pagination_pinnwand'])){
                    Modern_Helper_Request::requestStart();
                    echo $table->getHtml();
                    exit;
                } 
                
                
                $design_widget['pinnwand']=new Template_ElementList($table,'pagination_pinnwand','pinnwand_widget');
                $design_widget_auswahl['pinnwand']=$lang['_PIM-PINNWAND_'];
                $table_data=array();
            }
			
               
			// User online:
			if (count($alle_drin)==0 or isset($alle_drin['useronline'])&& !isset($_GET['pagination_bm']) && !isset($_GET['pagination_news'])&& !isset($_GET['pagination_geblang']) && !isset($_GET['pagination_korr_1']) && !isset($_POST['pagination_filter_']) && !isset($_GET['pagination_tkpwps']) && !isset($_GET['pagination_tkpwps2']) && !isset($_GET['pagination_pinnwand']) && !isset($_POST['leadprozess']) && !isset($_POST['pagination_opp'])) {
			if ($cfg_kein_useronline) {
				$inhalt=preg_replace('/\{user_online\}/Uis', '', $inhalt);
				$pb_inh['useronline']=preg_replace('/\{user_online\}/Uis', '', $pb_inh['useronline']);
			}
			
	if ($zeitdebug) {
		echo 'nach Pinnwand: '.zeitnahme().'<br>';
	}
			if ($_SESSION['user_gruppe']==2) {
				$liz_max=check_lizenz(true);
			}
			$bfeld2=array();
			$alle_uson=array();
			
			$standard_lao=-99;
			if ($cfg_pim_online_nur_std_lao) {
				$res4=$db->select(
					$sql_tab['benutzer'],
					array(
						$sql_tabs['benutzer']['benutzer_id'],
						$sql_tabs['benutzer']['vorname'],
						$sql_tabs['benutzer']['name'],
						$sql_tabs['benutzer']['standard_lagerort']
					),
					$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id'])
				);
				if ($row4=$db->zeile($res4)) {
					$standard_lao=intval($row4[3]);
				}
			}
			
            $tabelle_useronline = array($sql_tab['useronline']);
            $where_useronline='';
            $lizenzzaehlung=true;
            if ($cfg_pim_online_recht_rolle) {
                $rechte_ = array();
                if (is_a($menuRights, 'Rights_MenuPoint')) {
                    $rechte_ = $menuRights->getConfigurationFromUser($_SESSION['user_id']);
                }
                if (!empty($rechte_) && (isset($rechte_['only_self_user']) || isset($rechte_['only_standard_lagerort_user']) || isset($rechte_['only_mandant_auswertung_user']))) {
                    $lizenzzaehlung=false;
                    if (isset($rechte_['only_self_user'])) {
                        $where_useronline=$sql_tabs['useronline']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id']);
                    } elseif (isset($rechte_['only_standard_lagerort_user'])) {
                        $tabelle_useronline[]=$sql_tab['benutzer'];
                        $where_useronline=
                            $sql_tabs['useronline']['benutzer_id'].'='.$sql_tabs['benutzer']['benutzer_id'].' and '.
                            $sql_tabs['benutzer']['standard_lagerort'].'='.$db->dbzahl($_SESSION['user_standard_lagerort']);
                    } elseif (isset($rechte_['only_mandant_auswertung_user'])) {
                        $tabelle_useronline[]=$sql_tab['benutzer_mandant_auswertung'];
                        $where_useronline=
                            $sql_tabs['useronline']['benutzer_id'].'='.$sql_tabs['benutzer_mandant_auswertung']['benutzer_id'].
                            (($_SESSION['benutzer_mandant_auswertung'] != '-1') ? ' and '.$db->dbzahlin($_SESSION['benutzer_mandant_auswertung'], $sql_tabs['benutzer_mandant_auswertung']['mandant_id']) : '');
                    }
                }
            }
            $interface_ref = new Interface_RefRepository('pim_users_online');
            $row_other_users_pim=$interface_ref->getAllForTable('benutzer', $_SESSION['user_id']);
            if (!empty($row_other_users_pim)) {
                $pim_benutzer_online_def=array();
                if ($row_other_users_pim[0]['extern_id']!='') {
                    $pim_benutzer_online_def=explode(',', $row_other_users_pim[0]['extern_id']);
                }
                if (!empty($pim_benutzer_online_def)) {
                    $alle_benutzer_online=array($_SESSION['user_id'] => $_SESSION['user_id']);
                    $result_benutzer_gruppe_zuordnung = $db->select(
                        $sql_tab['benutzer_gruppe_zuordnung'],
                        $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'],
                        $db->dbzahlin($pim_benutzer_online_def, $sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'])
                    );
                    while ($row_benutzer_gruppe_zuordnung = $db->zeile($result_benutzer_gruppe_zuordnung)) {
                        $alle_benutzer_online[$row_benutzer_gruppe_zuordnung[0]]=$row_benutzer_gruppe_zuordnung[0];
                    }
                    if ($where_useronline!='') {
                        $where_useronline.=' and ';
                    }
                    $where_useronline.=$db->dbzahlin($alle_benutzer_online, $sql_tabs['useronline']['benutzer_id']);
                }
            }
            $res2=$db->select(
                $tabelle_useronline,
                array(
                    'distinct '.$sql_tabs['useronline']['benutzer_id'],
                    $sql_tabs['useronline']['datum'],
                    $sql_tabs['useronline']['session']
                ),
                $where_useronline
            );
            $pim_aktivitaet_sichtbar = $cfg_nav_historie && $_SESSION['crm_version']>61 && ($_SESSION['user_id']==1 || $_SESSION['cfg_kunde']=='portal' || $_SESSION['cfg_kunde'] == 'carlo_opel_prof4net');
            $benutzerfeld=array();
            $benutzerfeld_info=array();
            $anzahl_uo = $db->anzahl($res2);
            if ($pim_aktivitaet_sichtbar) {
                $session_pfad = ini_get('session.save_path');
                $session_pfad_letztes_zeichen = substr($session_pfad, -1);
                if ($session_pfad_letztes_zeichen != '\\' && $session_pfad_letztes_zeichen != '/') {
                    $session_pfad.='/';
                }
                $result_menu_aktivit = $db->select(
                    $sql_tab['menu'],
                    array(
                        $sql_tabs['menu']['name'],
                        $sql_tabs['menu']['link']
                    )
                );
                $aequivalent=array(
                    'callcenter.php' => 'leitfaden.php',
                    'leitfaden.php' => 'callcenter.php'
                );
                $newnames=array(
                    'tabs.php'=>_NEUER_TAB_,
                    'tabs.php?blank=1'=>_NEUER_TAB_,
                    '//about:blank'=>_NEUER_TAB_,
                    'stammdaten_main.php'=>_AKTIVER_KUNDE_,
                    'kalender_neu.php' => _KALENDER_,
                    'kalender.php' => _KALENDER_,
                    'stammdaten_liste.php' => _DATENSATZ_.'-'._STAMMDATEN_NAV_LISTE_
                );
                $menuearray2 = array();
                $menuearray2_70 = array();
                while ($row_menu_aktivit = $db->zeile($result_menu_aktivit)) {
                    $temp_link = strtolower($row_menu_aktivit[1]);
                    $temp_link = preg_replace('/(.*\.php)(.*)/', '$1', $temp_link);
                    $menuearray2[$temp_link] = link2($row_menu_aktivit[0], $row_menu_aktivit[1]);
                    $menuearray2_70[$temp_link]=new Template_Link($row_menu_aktivit[0], $row_menu_aktivit[1]);
                }
                foreach ($menuearray2 as $link => $str_link) {
                    if (isset($aequivalent[$link])) {
                        $menuearray2[$aequivalent[$link]] = $str_link;
                        $menuearray2_70[$aequivalent[$link]]=$menuearray2_70[$link];
                    }
                }
                foreach ($newnames as $link => $names) {
                    $menuearray2[$link] = $names;
                    $menuearray2_70[$link] = $names;
                }
            }
            
       
            while ($row2=$db->zeile($res2)) {
                $cols_view=array();
                $benutzerfeld_info[$row2[0]] = '';
                $benutzerfeld_info70[$row2[0]] = '';
                if ($row2[0]==$userid_pim) {
                    continue;
                }
                if (!isset($alle_uson[$row2[0]])) {
                    if ($db->unixdate_ts($row2[1])>(time()-($stundenlimit*60*60)) or $db->unixdate_ts($row2[1])>(time()-(2*60))) {
                        $res3=$db->select(
                            $sql_tab['benutzer'],
                            array(
                                $sql_tabs['benutzer']['vorname'],
                                $sql_tabs['benutzer']['name'],
                                $sql_tabs['benutzer']['login'],
                                $sql_tabs['benutzer']['standard_lagerort']
                            ),
                            $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row2[0])
                        );
                        $row3=$db->zeile($res3);
                        if (!$cfg_pim_online_recht_rolle) {
                            if ($_SESSION['user_gruppe']<2 and $cfg_pim_online_nur_std_lao) {
                                if (intval($row3[3])==$standard_lao) {

                                } else {
                                    continue;
                                }
                            }
                        }
                        $alle_uson[$row2[0]]=$row3[1].', '.$row3[0];
                    }
                }
                if ($pim_aktivitaet_sichtbar) {
                    $session_id = $row2[2];
                    if (file_exists($session_pfad.'sess_'.$session_id)) {
                        $session_inhalt = SessionP4N::unserialize(file_get_contents($session_pfad.'sess_'.$session_id));
                        if (isset($session_inhalt['crm_verlauf']) && !empty($session_inhalt['crm_verlauf'])) {
                            $first_value_verlauf = array_values($session_inhalt['crm_verlauf']);
                            $temp_link = basename($first_value_verlauf[0]);
                            $temp_link = preg_replace('/(.*\.php)(.*)/', '$1', $temp_link);
                            $benutzerfeld_info[$row2[0]]='';
                            $benutzerfeld_info70[$row2[0]]='';
                            $link='';
                            $link70='';
                            if ($menuearray2[$temp_link] != '') {
                                $link = $menuearray2[$temp_link];
                                $link70 = $menuearray2_70[$temp_link];
                                if ($temp_link=='stammdaten_main.php') {
                                    if ($session_inhalt['stammdaten_id']>0) {
                                        $stammdaten_name = dbout($sql_tab['stammdaten'], $sql_tabs['stammdaten']['anzeigename'], $sql_tabs['stammdaten']['id'].'='.$db->dbzahl($session_inhalt['stammdaten_id']));
                                        $link=linkToTab($stammdaten_name, 'stammdaten_main.php?id='.$session_inhalt['stammdaten_id'].($session_inhalt['karte']!='' ? '&nav='.$session_inhalt['karte'] : ''), '', '', '', 1);
                                        $link70=linkToTab70($stammdaten_name, 'stammdaten_main.php?'.($session_inhalt['karte']!='' ? '&nav='.$session_inhalt['karte'] : '').'&id='.$session_inhalt['stammdaten_id'], '', '', '', 1);
                                    }
                                }
                            }
                            $benutzerfeld_info[$row2[0]]=$link;
                            $benutzerfeld_info70[$row2[0]]=$link70;
                        }
                    }
                }
                if ($db->unixdate_ts($row2[1])>(time()-($stundenlimit*60*60))) {
                    $benutzerfeld[$row2[0]]=$alle_uson[$row2[0]];
                }
                if ($db->unixdate_ts($row2[1])>(time()-(2*60))) {
                    $bfeld2[$row2[0]]=$alle_uson[$row2[0]];
                }
            }
            if ($carlo_tw) {
                $bfeld2=array(); //damit wird abmelden immer angezeigt
            }
 			@asort($benutzerfeld);
			
			$ist_pimadmin=false;
			if ($_SESSION['user_gruppe']<2) {
				$res7=$db->select(
					$sql_tab['benutzer_gruppe'],
					array(
						$sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
						$sql_tabs['benutzer_gruppe']['bezeichnung']
					),
					$sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('PIM-Administrator')
				);
				if ($row7=$db->zeile($res7)) {
					if ($_SESSION['rechte_bgruppen']=='-1' or preg_match('/,'.$row7[0].',/', ','.$_SESSION['rechte_bgruppen'].',')) {
						$ist_pimadmin=true;
					}
				}
			} else {
				$ist_pimadmin=true;
			}
            $rauss=false;
            if ($lizenzzaehlung and $ist_pimadmin and count($bfeld2)<=count($benutzerfeld)) {
                $rauss=true;
			}
            $uo_text_neu = '<tr><th class="th">'._BENUTZER_.'</th>'.($pim_aktivitaet_sichtbar ? '<th class="th">'._AKTIVITAET_.'</th>' : '').'<th class="th">'._AKTION_.'</th></tr>';
            $uo_text='<!font color=blue>'.$_SESSION['mitarbeiter_name'].'</font><br>';
            $uo_text_neu .= '<tr class="odd"><td class="td"><!font color=blue>'.$_SESSION['mitarbeiter_name2'].'</font></td>'.($pim_aktivitaet_sichtbar ? '<td class="td"></td>' : '').'<td class="td">-</td></tr>';
            @reset($benutzerfeld);
            

            $pagination=new Template_Pagination('widget_pagination_useronline');
            $pagination_zaehler=0;

            if ($_SESSION['design_70']) {
                $benutzerfeld[$_SESSION['user_id']]=$_SESSION['mitarbeiter_name2'];
            }
            $x=0;
            $table_data=array();
            while (list($key, $val)=@each($benutzerfeld)) {
                $pagination_zaehler++;
                
                if (!$pagination->cancelWhile() && 1==2) {
                    continue;
                }
                        
                $cols_view=array();
				if ($cfg_messenger) {
                    
                    $widget_sofortnachrichten=false;
                    if ($_SESSION['widget_leiste'] && $_SESSION['widget_sn'] && !$_SESSION['design_70']) {
                        $widget_sofortnachrichten=true;
                        $res2=$db->select(
                            $sql_tab['benutzer'],
                            array(
                                $sql_tabs['benutzer']['vorname'],//0
                                $sql_tabs['benutzer']['name']//1
                            ),
                            $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($key)
                        );
                        if ($row2=$db->zeile($res2)) {
                            $sn_von=trim($row2[0].' '.$row2[1]);
                        }
                    }
                    
                    if ($widget_sofortnachrichten) {
                        $onclick='P4nBoxHelper.menu=true;P4nBoxHelper.init({id:\'infopanel_sn_window\',href:\'menu4.php?sn_von=\'+escapeP4n_60(\''.$sn_von.'\')+\'&sn_von_id='.$key.'&infopanel=sn_reply&amp;options_menu=0&amp;options_padding=0\',target:\'body\',width:\'600px\',height:\'400px\',autosize:true,type:\'get\'});';
                    } else {
                        $onclick='neu('.$key.');';
                        if ($_SESSION['design_70']) {
                            $onclick='top.sofortnachricht'.$_SESSION['user_id'].'.neu(\'selecttouser='.$key.'&neu=1&uid='.$_SESSION['user_id'].'\');';
                        }
                    }
					$uo_text.=link2($val, 'javascript:','','','onclick="'.$onclick.'"').(($userid_pim==1 or ($rauss and !isset($bfeld2[$key])))?' '.link2(' - '._PDA_LOGOUT_, 'pim.php?abm='.$key):'').'<br>';
                    $uo_text_neu.='<tr class="'.($x%2?'odd':'even').'"><td class="td">'.link2($val, 'javascript:','','','onclick="'.$onclick.'"').'</td>'.(($pim_aktivitaet_sichtbar ? '<td class="td">'.$benutzerfeld_info[$key].'</td>' : '')).'<td class="td">'.(($userid_pim==1 or ($rauss and !isset($bfeld2[$key])))?' '.link2(_PDA_LOGOUT_, 'pim.php?abm='.$key):'-').'</td></tr>';
                    $cols_view[0]=($key!=$_SESSION['user_id']?new Template_Link($val, 'javascript:','','','onclick="'.$onclick.'"'):$val);
                    if ($pim_aktivitaet_sichtbar)
                    $cols_view[1]=$benutzerfeld_info70[$key];
                    $cols_view[2]=(($key!=$_SESSION['user_id'] && ($userid_pim==1 or ($rauss and !isset($bfeld2[$key]))))?new Template_Link(_PDA_LOGOUT_, 'pim.php?abm='.$key):'-');
				} else {
					$uo_text.=$val.'<br>';
                    $uo_text_neu.='<tr class="'.($x%2?'odd':'even').'"><td class="td">'.$val.'</td>'.(($pim_aktivitaet_sichtbar ? '<td class="td">'.$benutzerfeld_info[$key].'</td>' : '')).'<td class="td">-</td></tr>';
                    $cols_view[0]=$val;
                    if ($pim_aktivitaet_sichtbar)
                    $cols_view[1]=$benutzerfeld_info70[$key];
                    $cols_view[2]='-';
                }
                
                $x++;
                
                ksort($cols_view);
                if (!$table_data_i) {
                    $table_data_i = 1;
                }
                $table_data[$table_data_i++] = $cols_view;
			}
            

                        
            
                if ($uo_text=='') {
                    $uo_text='<tr><td><font size="1">'._PIM_KEINUSERONLINE_.'</font></td><td>&nbsp;</td></tr>';
                } else {
                    $pi_text=(($cfg_modern)?'':'<tr><td>').javas('var fenster=null;
                    function neu(benutzer) {
                        fenster=open(\'sofortnachricht.php?selecttouser=\'+benutzer+\'&uid='.$userid_pim.'&neu=1\', \'snr\', \'height=300,width=250, toolbar=no,statusbar=no,scrollbars=no,location=no,resizable=no\');
                    }');
                    $uo_text=p4n_mb_string('substr',$uo_text, 0, -2);
                    $uo_text='<tr><td>'.$uo_text.'</td><td class="td">&nbsp;</td></tr>';
                }
                if ($userid_pim==1 || $rauss) {
                    $uo_text_neu.='<tr class="'.($x%2?'odd':'even').'"><td class="td">'._LS_IHRE_LIZENZEN_.': '.(count($benutzerfeld)+1).'/'.$liz_max.'</td>'.($pim_aktivitaet_sichtbar ? '<td class="td">'._VERSION_.' '.$_SESSION['crm_version_complete'].'</td>' : '').'<td class="td">'.link2(_PDA_LOGOUT_.' ('._INAKTIV_.')', 'pim.php?abm_inaktiv='.$_SESSION['user_id']).' - '.link2(_PDA_LOGOUT_.' ('._ALLE_.')', 'pim.php?abm_alle='.$_SESSION['user_id']).'</td></tr>';
                    $cols_view=array();
                    $cols_view[0]=_LS_IHRE_LIZENZEN_.': '.(count($benutzerfeld)+1).'/'.$liz_max;
                    if ($pim_aktivitaet_sichtbar) {
						$cols_view[1] = _VERSION_.' '.$_SESSION['crm_version_complete'];
					}
                    $cols_view[2]=new Template_ElementList(array(new Template_Link(_PDA_LOGOUT_.' ('._INAKTIV_.')', 'pim.php?abm_inaktiv='.$_SESSION['user_id']),new Template_Link(_PDA_LOGOUT_.' ('._ALLE_.')', 'pim.php?abm_alle='.$_SESSION['user_id'])),'','','/');
                    
                    ksort($cols_view);
                    if (!$table_data_i) {
                        $table_data_i = 1;
                    }
                    $table_data[$table_data_i++] = $cols_view;
                }
            }

            if ($_SESSION['crm_version']>56 || $carlo_tw) {
                $uo_text = $uo_text_neu;
            }
            if ($_SESSION['design_70']) {
                $temp = array(
                    _BENUTZER_,
                    ($pim_aktivitaet_sichtbar?_AKTIVITAET_:''),
                    _AKTION_,
                );
                if ($pagination!=null) {
                    //$pagination->create($pagination_zaehler);
                    //$pagination->setRequest('GET', 'pagination_useronline', 'pim.php', array('pagination_useronline=1'));
                }

                $table = Template_Default::Table($temp,$table_data,array('size'=>'sm','maxHeight'=>248,'minHeight'=>248),$filter=array(),$search=array(),$button=null,null,$card=true, $card_title=$lang['_PIM-USERONLINE_'],array('paginationInCard'=>true,'cardOptions'=>array('border'),'addScrollBar'=>true));
                //$card=Template_Default::Card($lang['_PIM-USERONLINE_'],new Template_ElementList(array(),'','hozizontal'),array($table,$pagination));
                 if (isset($_GET['pagination_useronline'])){
                    Modern_Helper_Request::requestStart();
                    echo $table->getHtml();
                    //echo javas('pim_autoheight_();');
                    exit;
                }   
                $design_widget['useronline']=new Template_ElementList($table,'pagination_useronline');
                $design_widget_auswahl['useronline']=$lang['_PIM-USERONLINE_'];
                $table_data=array();
                
                
                //"POST", "leadprozess.php", "just_show_table=1#
            }
			$pb_inh['useronline']=preg_replace('/\{user_online\}/Uis', ($cfg_modern?'':'<font size=1>').$uo_text.($cfg_modern?'':'</font>'), $pb_inh['useronline']);
			$inhalt=preg_replace('/\{user_online\}/Uis', '<font size=1>'.$uo_text.'</font>', $inhalt);
            if ($zeitdebug) {
                echo 'nach Useronline: '.zeitnahme().'<br>';
            }
			if ($pim_mitvorlage) {
				$cols_l=array();
                $cl=0;
                $colr_r=array();
                $cr=0;
				$alles='<table class="table-nostyle table-fixed">';
				$l_text='';
				$r_text='';
				$l_i=0;
                $ca=0;
				while (list($key, $val)=@each($pim_vor_l)) {
//echo $key.'--'.$val.' --- '.$pim_vor_r[$key].'<br>';
					if ($val!='' and $pim_vor_r[$key]=='') {
						if ($l_text!='' or $r_text!='') {
							if ($l_text!='') {
								$alles.='<tr><td class="t" style="'.(($cfg_modern)?'':'margin: 0 0 0 0; padding: 0 0 0 0;').'">'.$l_text.'</td>';
							} else {
								$alles.='<tr><td></td>';
							}
							if ($r_text!='') {
								$alles.='<td class="t" style="'.(($cfg_modern)?'':'margin: 0 0 0 0; padding: 0 0 0 0;').'">'.$r_text.'</td></tr>';
							} else {
								$alles.='<td></td></tr>';
							}
						}
						$l_text='';
						$r_text='';
                        $cols_alles[$ca][0]=$design_widget[$val];
                        $cols_alles[$ca][1]=' ';
                        $ca++;
						$alles.='<tr><td colspan=2 class="t" style="'.(($cfg_modern)?'':'margin: 0 0 0 0; padding: 0 0 0 0;').'">'.$pb_inh[$val].'</td></tr>';
						continue;
					}
					if (isset($pim_bloecke[$val])) {
						$l_text.=$pb_inh[$val];
                        if (isset($design_widget[$val])) {
                            $cols_l[$cl++][0]=$design_widget[$val];
                        }
					}
					if (isset($pim_vor_r[$key])) {
						if (isset($pim_bloecke[$pim_vor_r[$key]])) {
							$r_text.=$pb_inh[$pim_vor_r[$key]];
                            $cols_r[$cr++][0]=$design_widget[$pim_vor_r[$key]];
						}
					}
                    
             
                    
					$l_i++;
				}
				if ($l_text!='' or $r_text!='') {
							if ($l_text!='') {
								$alles.='<tr><td class="t" style="'.(($cfg_modern)?'':'margin: 0 0 0 0; padding: 0 0 0 0;').'">'.$l_text.'</td>';
							} else {
								$alles.='<tr><td></td>';
							}
							if ($r_text!='') {
								$alles.='<td class="t" style="'.(($cfg_modern)?'padding-right:0px !important;':'margin: 0 0 0 0; padding: 0 0 0 0;').'">'.$r_text.'</td></tr>';
							} else {
								$alles.='<td></td></tr>';
							}
				}
				$alles.='</table>';
				$inhalt=p4n_mb_string('str_replace', '{alles}', $alles, $inhalt);
			}
			
			$pim_ausw='';
			$pim_ausw2='';
			if ($cfg_pim_neuprivat) {
                $pim_ausw2.=$form->submit2('neufirma', _NEU_.': '._PRIVATKUNDE_, 'onClick="window.open(\'neuanlage.php?privat=1\', \'main\');"').' | ';
            }
			if ($cfg_pim_neufirma) {
				 $pim_ausw2.=$form->submit2('neuprivat', _NEU_.': '._FIRMA_, 'onClick="window.open(\'neuanlage.php?firma=1\', \'main\');"').' | ';
			}
			if ($cfg_pim_epa) {
                include_once ('inc/utilities.php');
                if (hasRight($_SESSION['user_id'], 'vk_potenzial_analyse.php')) {
                    $pim_ausw2.=$form->submit2('neuepa', _EIGENPOTENTIALANALYSE_, 'onClick="window.open(\'vk_potenzial_analyse.php\', \'main\');"').' | ';
                }
            }
			if ($cfg_pim_leasingkunden) {
				$pim_ausw2.=$form->submit2('neuleasingkunden', _LEASING_.' '._KUNDEN_, 'onClick="window.open(\'stammdaten_liste.php?vfilter=26\', \'main\');"').' | ';
			}
			$pim_ausw2=substr($pim_ausw2, 0, -3);
			if ($zeitdebug) {
				echo 'vor otherusers: '.zeitnahme().'<br>';
			}
			if ($cfg_pim_otherusers) {
                if (count($bens_pim)>0) {
                    if (array_key_exists($_SESSION['user_id'], $bens_pim)) {
                        $temp_bens_pim=array($_SESSION['user_id'] => $merke_bens_pim);
                        foreach ($bens_pim as $key => $value) {
                            $temp_bens_pim[$key]=$value;
                        }
                        $bens_pim=$temp_bens_pim;
                    }
                    if ($cfg_modern) {
                        $pim_ausw='<table style="margin-bottom:10px;"><tr><td>PIM | '.$pim_ausw2.' | '._ANDERER_BENUTZER_.': '.$form->selectinput('ou_pim', $bens_pim, $userid_pim).$form->submit('ou_submit', _OK_).'</td></tr></table>';
                    } else {
                        $pim_ausw=' | '._ANDERER_BENUTZER_.': '.$form->selectinput('ou_pim', $bens_pim, $userid_pim).$form->submit('ou_submit', _OK_);
                    }
				} elseif ($pim_ausw2!='') {
                    $pim_ausw='<table style="margin-bottom:10px;"><tr><td>PIM | '.$pim_ausw2.'</td></tr></table>';
                }
			} elseif ($pim_ausw2!='') {
				 $pim_ausw='<table style="margin-bottom:10px;"><tr><td>PIM | '.$pim_ausw2.'</td></tr></table>';
			}
			if ($zeitdebug) {
				echo 'nach otherusers: '.zeitnahme().'<br>';
			}
			
			$inhalt=p4n_mb_string('str_replace', '{pim_auswahl}',  $pim_ausw, $inhalt);
			
            if ($_SESSION['design_70']) {
                
                if ($isLeadPimInPim) {

                    
                    echo javas('var lead_pim=false; ');
                   // $design_widget['lead_pim']=Template_ElementList::init('','leadList')->setRequest('POST', 'leadList', 'leadprozess.php', 'just_show_table=1&pim_lead_php=1', '', -1, true);
                    $design_widget['lead_pim']=Template_ElementList::init('','pim_wvl')->setRequest('POST', 'pim_wvl', 'pim.php', 'just_show_table=1&wvlart=1&leadprozess=1&pim_lead_php=1', 'lead_pim=true;', -1, true);
                    $pim_requests++;
                    $pim_requests++;
                    $design_widget_auswahl['lead_pim']=_LEADS_;
                }
                
                $breadcrumps_list = array(new Template_Link('PIM', $phs));
                
                if ($_SESSION['cfg_kunde'] === 'portal') {
                    $cleanupPasswordString = p4n_mb_string('substr', md5(date('m')), 1, 4);
                    $referenz = str_replace('=', '', base64_encode(substr(time(), 0, 2).substr(time(), 4, 2)));
                    $referenz_array = str_split(substr(base_convert(bin2hex(base64_decode($referenz)), 16, 2), 1));
                    shuffle($referenz_array);
                    $cleanupPassword = str_replace('=', '', base64_encode(hex2bin(base_convert('1'.implode('', $referenz_array), 2, 16))));
                    $cleanupPasswordString .= ' - '.$cleanupPassword;
                    
                    $breadcrumps_list[] = new Template_Text($cleanupPasswordString);
                }
                
                $actionMenuButton = Template_IconButton::init('','','','settings','','','sm','transparent-blue')->openModal('widget_modal_pim_widgets')->setAttribute('id','open_widget_modal_pim_widgets');
                if ($cfg_avag_de) {
                    $actionMenuButton=null;
                }
                $contentHeader = new Template_ContentHeader(new Template_Breadcrumps($breadcrumps_list),new Template_Elementlist(array($actionMenuButton),'','horizontal'),false,true);
                echo $contentHeader->getHtml();
                
                
                $res=$db->select(
                    $sql_tab['benutzer'],
                    array(
                        $sql_tabs['benutzer']['pim_anordnung']
                    ),
                    $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($userid_pim)
                );
                $pim_leer=true;
                $pim_neu=array();
                if ($row2=$db->zeile($res)) {
                    if ($row2[0]!='') {
                        $pim_xlp=explode('/', $row2[0]);
                        $pim_neu=$pim_xlp[2];
                        if ($pim_neu!='') {
                            $pim_neu=unserialize($pim_neu);
                        } else {
                            $pim_l=explode(',',$pim_xlp[0]);
                            $pim_r=explode(',',$pim_xlp[1]);
                            $bau_neu=array();
                            foreach ($pim_l as $key => $value) {
                                if ($value!='') {
                                    $bau_neu[$key][0]=$value;
                                }
                                if ($pim_r[$key] !='') {
                                    $bau_neu[$key][1]=$pim_r[$key];
                                }
                            }
                            $pim_neu=$bau_neu;
                        }
                    }    
                }    
                
                if ($cfg_avag_de) {
                    $pim_neu=unserialize('a:4:{i:0;a:3:{i:0;s:17:"avagpim_vkchancen";i:1;s:14:"avagpim_offang";i:2;s:22:"avagpim_leasingauslauf";}i:1;a:2:{i:0;s:2:"bm";i:1;s:8:"kalender";}i:2;a:3:{i:0;s:7:"notizen";i:1;s:8:"pinnwand";i:2;s:15:"verkaufsvorgabe";}i:3;a:3:{i:0;s:6:"tkpwps";i:1;s:13:"letztenkunden";i:2;s:7:"geblang";}}');
                }

                if (count($pim_neu)>0) {
                    $pim=new Template_GridTable();
                    foreach ($pim_neu as $key => $value) {
                        $pim_leer=false;
                        $row=Template_GridTableRow::init();
                        foreach ($value as $key2 => $value2) {
                            if ($design_widget[$value2]) {
                                $col=new Template_GridTableCol();
                                $col->addElement($design_widget[$value2]);
                                $row->addElement($col);
                            } else {
                                //if ($value2!='geblang') {
                                $col=new Template_GridTableCol();
                                $col->addElement($value2);
                                $row->addElement($col);
                                //}
                            }
                        }
                        $pim->addElement($row);
                    }
                    $pim->addCustomClass('pim_gridtable');
                   // $pim->addCustomClass('novisibility');
                    $form70 = new Template_Form('kform_pim', $phs, 'POST', true, '', $cfg_leserecht);
                    $form70->addCustomClass('pr-0 pl-0');
                    $pim=new Template_Elementlist($pim,'','pr-32 pl-32');
                        
                    $pim->fullContentHeight();
                    $pim->addScrollBar();
                        
                    $form70->addElement($pim);
                    echo $form70->getHtml();
                    echo $js70;
                }
                
                
                if ($pim_leer) {
                    $empty_pim=new Template_ElementList(array(
                        new Template_ElementList(array(
                            new Template_Title('Aktuell sind keine Inhalte f�r die Anzeige in der PIM gew�hlt.',2),
                        )),
                        new Template_ElementList(array(
                            new Template_Text('Bitte oben, rechts �ber das'),
                            Template_Link::init(new Template_Icon('settings'))->openModal('widget_modal_pim_widgets')->setAttribute('id','open_widget_modal_pim_widgets2'),
                            new Template_Text('Icon die PIM-Einstellungen anpassen.')
                        ),'','')
                    ),'widget_empty','justify-content-around');

                    echo $empty_pim->getHtml();
                }
                
   
                
                $pim_blockinfo_widget=array(
                    'wvl' => ($_SESSION['design_70']?_KORRESPONDENZEN_:$lang['_K-WVL1_']),
                    'kalender' => $lang['_PIM-KALENDER_'],
                    'gebkurz' => _SP_GEBURTSTAGSLISTE_,
                    'geblang' => _SP_GEBURTSTAGSLISTE_.' ('._LANG_.')',
                    'aufgaben' => $lang['_ADMIN-AUFGABEN_'],
                    'pinnwand' => $lang['_PIM-PINNWAND_'],
                    'useronline' => $lang['_PIM-USERONLINE_'],
                    'opp' => ($_SESSION['design_70']?_OFFENE_ANGEBOTE_:_OPPORTUNITIES_),
                    'bm' => _BMHEADLINE_,
                    'pm' => _PMHEADLINE_,
                    'notizen' => _KTYP15_,
                    'tkpwps' => _WERKSTATT_.' '._NAECHSTEN_TERMINE2_,
                    'filter' => _FILTER_,
                    'news' => _NEUIGKEITEN_
                );
                if ($_SESSION['design_70']) {
                    //unset($pim_blockinfo_widget['geblang']);
                    $pim_blockinfo_widget['gebkurz']=_GEBURTSTAGE_;
                    $pim_blockinfo_widget['geblang']=_GEBURTSTAGE_.' ('._AUSFUEHRLICH_.')';
                }
                 if ($_SESSION['design_70'] && is_file('inc/lib_sn.php') && $cfg_avag_de) {
                    $pim_blockinfo_widget['avagpim_vkchancen']='Verkaufschancen';
                    $pim_blockinfo_widget['avagpim_offang']='offene Angebote';
                    $pim_blockinfo_widget['avagpim_leasingauslauf']='Leasingausl�ufer';
                }
                
                if (is_file('inc/lib_sn.php')) {// and extension_loaded("ChartDirector PHP API")) {
                    $pim_blockinfo_widget['verkaufsvorgabe']=_VERKAUFSZIELE_;
                }
                if ($carlo_tw && $cfg_vw) {
                    $pim_blockinfo_widget['pim_reminders']=_ERINNERUNG_;
                }
                if ($_SESSION['crm_version']>60) {
                    $pim_blockinfo_widget['letztenkunden']=_TERMIN_T_RHYT5_.' '._KUNDEN_;
                }
                $res=$db->select(
                    $sql_tab['korrespondenz'],
                    'count(*)',
                    $sql_tabs['korrespondenz']['kategorie'].'='.$db->str('WPS Termin').' or '.$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('TKP Termin').' or '.$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('WS Termin').' or '.$sql_tabs['korrespondenz']['kategorie'].'='.$db->str('Workshop')
                );
                $row=$db->zeile($res);
                if (intval($row[0])==0) {
                    unset($pim_blockinfo_widget['tkpwps']);
                }
                if ($cfg_pim_ohne_geburtstag_lang) {
                    unset($pim_blockinfo_widget['geblang']);
                }
                if ($cfg_om_inpim and p4n_mb_string('strstr',$_SESSION['rechte_reiter'], 'nav=OM')) {

                } else {
                    unset($pim_blockinfo_widget['opp']);
                }
                if (!p4n_mb_string('strstr',$_SESSION['rechte_reiter'], 'nav=PM')) {
                    unset($pim_blockinfo_widget['pm']);
                }
                if (!p4n_mb_string('strstr',$_SESSION['rechte_reiter'], 'nav=BM')) {
                    unset($pim_blockinfo_widget['bm']);
                }
                if ($_SESSION['crm_version']>99) {
                    asort($pim_blockinfo_widget, SORT_NATURAL | SORT_FLAG_CASE);
                }
                
                if ($isLeadPimInPim) {
                $pim_blockinfo_widget['lead_pim']=($_SESSION['design_70']?_LEADS_:_LEADUEBERSICHT_);
                }
                
                $temp=array();

                $res=$db->select(
                $sql_tab['benutzer'],
                array(
                    $sql_tabs['benutzer']['pim_anordnung']
                ),
                $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($userid_pim)
                );
                if ($row2=$db->zeile($res)) {
                    if ($row2[0]!='') {
                        $pim_xlp=explode('/', $row2[0]);
                        $pim_neu=$pim_xlp[2];
                        if ($pim_neu!='') {
                            $pim_neu=unserialize($pim_neu);
                        }else {
                            $pim_l=explode(',',$pim_xlp[0]);
                            $pim_r=explode(',',$pim_xlp[1]);
                            $bau_neu=array();
                            foreach ($pim_l as $key => $value) {
                                if ($value!='') {
                                    $bau_neu[$key][0]=$value;
                                }
                                if ($pim_r[$key] !='') {
                                    $bau_neu[$key][1]=$pim_r[$key];
                                }
                            }
                            $pim_neu=$bau_neu;
                        }
                    }
                }
                
                if ($cfg_avag_de) {
                    $pim_neu=unserialize('a:4:{i:0;a:3:{i:0;s:17:"avagpim_vkchancen";i:1;s:14:"avagpim_offang";i:2;s:22:"avagpim_leasingauslauf";}i:1;a:2:{i:0;s:2:"bm";i:1;s:8:"kalender";}i:2;a:3:{i:0;s:7:"notizen";i:1;s:8:"pinnwand";i:2;s:15:"verkaufsvorgabe";}i:3;a:3:{i:0;s:6:"tkpwps";i:1;s:13:"letztenkunden";i:2;s:7:"geblang";}}');
                }
                
                if ($_SESSION['design_70'] && is_file('inc/lib_sn.php') && $cfg_avag_de) {
                    $design_widget_auswahl['avagpim_vkchancen']='Verkaufschancen';
                    $design_widget_auswahl['avagpim_offang']='offene Angebote2';
                    $design_widget_auswahl['avagpim_leasingauslauf']='Leasingausl�ufer';
                }
                $design_widget_auswahl['opp']=_OFFENE_ANGEBOTE_;
                
              
                if ($_SESSION['design_70']) {
                    $pb_inh_temp=array();
                    foreach ($pb_inh as $key => $value) {
                        $pb_inh_temp[$design_widget_auswahl[$key]]=$key;
                    }
                    ksort($pb_inh_temp);
                }
               

                $alle_fi = array();
                $res2 = $db->select(
                    $sql_tab['filter'],
                    array(
                        $sql_tabs['filter']['filter_id'],
                        $sql_tabs['filter']['name'],
                        $sql_tabs['filter']['sql'],
                        $sql_tabs['filter']['beschreibung'],
                        $sql_tabs['filter']['user_id'],
                        $sql_tabs['filter']['datum'],
                        $sql_tabs['filter']['kategorie'],
                        $sql_tabs['filter']['ausschluss']
                    ),
                    $where,
                    $sql_tabs['filter']['kategorie'].','.$sql_tabs['filter']['name']
                );
                while ($row2 = $db->zeile($res2)) {
                    $kategor = $row2['kategorie'] != '' ? $row2['kategorie'] : _KEINE_KATEGORIE_;
                    if (!isset($alle_fi[$kategor])) {
                        $alle_fi[$kategor] = 'OPTGROUP';
                    }
                    $alle_fi[$row2[0]] = $row2[1];
                }
                

                $grid_filter[0][0]=array(new Template_SelectInput('Filter', 'user_setting[pim_anordnung_filter]', $alle_fi, explode(',', $user['pim_anordnung_filter']), _KEINE_AUSWAHL_, 'onchange="pim_widget_filter(this)"', true, 15),Template_HiddenInput::init('pim_widget_filter',$user['pim_anordnung_filter'])->setAttribute('id','pim_widget_filter'));
                $grid_filter=new Template_GridTable($grid_filter);
                $grid_korrespondenz[0][0]=array(new Template_SelectInput(_KORRESPONDENZ_.' Anzeigeart', 'user_setting[pim_korrespondenz_view_auswahl]', array('kennzahl'=>'Kennzahl','graph'=>'Graph'), $user['pim_korrespondenz_view_auswahl'], _KEINE_AUSWAHL_, 'onchange="pim_widget_korrespondenz(this)"', false, 15),Template_HiddenInput::init('pim_widget_korrespondenz',$user['pim_korrespondenz_view_auswahl'])->setAttribute('id','pim_widget_korrespondenz'));
                $grid_korrespondenz=new Template_GridTable($grid_korrespondenz);
                $grid_bm[0][0]=array(new Template_SelectInput(_BMHEADLINE_.' Anzeigeart', 'user_setting[pim_bm_view_auswahl]', array('kennzahl'=>'Kennzahl','graph'=>'Graph'), $user['pim_bm_view_auswahl'], _KEINE_AUSWAHL_, 'onchange="pim_widget_bm(this)"', false, 15),Template_HiddenInput::init('pim_widget_bm',$user['pim_bm_view_auswahl'])->setAttribute('id','pim_widget_bm'));
                $grid_bm=new Template_GridTable($grid_bm);
                $grid_lead[0][0]=array(new Template_SelectInput(_LEADS_.' Anzeigeart', 'user_setting[pim_lead_view_auswahl]', array('kennzahl'=>'Kennzahl','graph'=>'Graph'), $user['pim_lead_view_auswahl'], _KEINE_AUSWAHL_, 'onchange="pim_widget_lead(this)"', false, 15),Template_HiddenInput::init('pim_widget_lead',$user['pim_lead_view_auswahl'])->setAttribute('id','pim_widget_lead'));
                $grid_lead=new Template_GridTable($grid_lead);
                $grid_opp[0][0]=array(new Template_SelectInput(_OFFENE_ANGEBOTE_.' Anzeigeart', 'user_setting[pim_opp_view_auswahl]', array('kennzahl'=>'Kennzahl','graph'=>'Graph'), $user['pim_opp_view_auswahl'], _KEINE_AUSWAHL_, 'onchange="pim_widget_opp(this)"', false, 15),Template_HiddenInput::init('pim_widget_opp',$user['pim_opp_view_auswahl'])->setAttribute('id','pim_widget_opp'));
                $grid_opp=new Template_GridTable($grid_opp);


                $zusatz=Template_Default::Card('Einstellungen','',array(
                    Template_ElementList::init($grid_filter,'pim_widgets_filterauswahl','nodisplay'),
                    Template_ElementList::init($grid_korrespondenz,'pim_widgets_korrespondenzauswahl','nodisplay'),
                    Template_ElementList::init($grid_bm,'pim_widgets_bmauswahl','nodisplay'),
                    Template_ElementList::init($grid_lead,'pim_widgets_leadauswahl','nodisplay'),
                    Template_ElementList::init($grid_opp,'pim_widgets_oppauswahl','nodisplay')
                ));
                //$pim_neu
                list($settings_btn, $container) = Template_Module::WidgetSettings(
                    '_pim_widgets',
                    'Pim Widgets',
                    $pim_blockinfo_widget,
                    $pim_neu,
                    'pim.php',
                    'main',
                    '',
                    $zusatz
                );
                if (isset($container) && is_object($container)) {
                    echo $container->getHtml();
                } 
               
               

                echo Template_Script::init('pim')->getHtml();
                echo Template_Stylesheet::init('pim')->getHtml();
                

                echo javas('
                    $(document).ready(function () {
                        pim_widget_zusatz();
                        
                        function check_loading() {
                            var check=true;
                            if (1==2 &&  typeof lead_pim != typeof undefined) {
                                if (lead_pim==false) {
                                    check=false;
                                }
                            }
                            if (1==2 && typeof widget_filter != typeof undefined) {
                                for (var i=0;i<widget_filter.length;i++) {
                                    if (widget_filter[i]==false) {
                                        check=false;
                                    }
                                } 
                            }

                            var check=true;
                            if (check==false) {
                                setTimeout(function() { check_loading(); template_progressbar.start(true); template_progressbar.setprogress(75); },500);
                            } else {
                               /* setTimeout(function() {*/ $("#pim_php").css("visibility","visible"); /*}, 500);*/
                            }
                        }
                     
                        //check_loading();
                    });
                ');
               // echo Template_Js::sortable(array($cols));
               // echo $cols->getHtml();
                echo $pim_modal->getHtml();
				echo $pim_modal_level2->getHtml();
                
                if (!empty($cfg_tinymce) && isset($_SESSION['design_70'])) {
                    init_tinymce();
                }
            } else {
                echo $inhalt.$pi_text;
                echo $pim_lade_text;
            }
			if ($zeitdebug) {
				echo zeitnahme();
			}
			fuss();
			if ($zeitdebug) {
				echo '<br>nach Fuss: '.zeitnahme();
			}
			
			if ($zeitdebuglog) {
				if ($fp=fopen('log/pimlog.txt', 'a')) {
					fwrite($fp, adodb_date('d.m.Y H:i:s').';'.$_SESSION['user_id'].';'.zeitnahme().';'."\r\n");
					fclose($fp);
				}
			}
		}
		
	function kfz_verk($stid, $betreuer=0) {
		global $db, $sql_tab, $sql_tabs, $verk_feld, $alle_bens;
		$verk='';
        if ($betreuer>0 && isset($verk_feld[$betreuer])) { 
            $verk=$verk_feld[$betreuer];
        } elseif ($betreuer>0 && isset($alle_bens[$betreuer])) {
            if (!isset($verk_feld[$betreuer])) {
                $verk_feld[$betreuer]=$alle_bens[$betreuer];
            }
            $verk=$verk_feld[$betreuer];
        } else {
            if (is_numeric($stid)) {
                $res=$db->select(
                    $sql_tab['stammdaten'],
                    $sql_tabs['stammdaten']['betreuer'],
                    $sql_tabs['stammdaten']['id'].'='.$db->dbzahl($stid)
                );
                if ($row=$db->zeile($res)) {
                    if (!isset($verk_feld[$row[0]])) {
                        $verk_feld[$row[0]]=$alle_bens[$row[0]];
                    }
                    $verk=$verk_feld[$row[0]];
                }
            }
        }
        return $verk;
	}
    function getUserPimIds($userid_pim,$benutzer_to_see) {
        global $sql_tab,$sql_tabs,$db;
       if ($userid_pim[0] == '_') {
            $benutzerrolle = p4n_mb_string('substr', $userid_pim, 1);
            $result = $db->select(
                    array(
                        $sql_tab['benutzer'],
                    ),
                    array(
                        $sql_tabs['benutzer']['benutzer_id']
                    ),
                    $sql_tabs['benutzer']['benutzer_rolle_id'].'='.$db->dbzahl($benutzerrolle).' and '.
                    $sql_tabs['benutzer']['gruppe'].'>='.$db->dbzahl(0)
            );

            while ($row = $db->zeile($result)) {
                $benutzer_to_see[$row[0]] = $row[0];
            }
        }elseif (p4n_mb_string('strpos', $userid_pim, 'g_') === 0) {
            $gid = p4n_mb_string('substr', $userid_pim, 2);
            $res = $db->select(
                array(
                    $sql_tab['benutzer_gruppe_zuordnung'],
                    $sql_tab['benutzer']
                ),
                array(
                    $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id']
                ),
                $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'].'='.$sql_tabs['benutzer']['benutzer_id'].' and '.
                $sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'] . '=' . $db->dbzahl($gid)
            );
            while ($row = $db->zeile($res)) {
                $benutzer_to_see[$row[0]] = $row[0];
            }
        }
        return $benutzer_to_see;
    }

	function get_leads_filter_form() {
		global $lang, $phs, $cfg_leadprozess_schlank;

		$leads_form = new htmlform();
		$lead_form_inhalt = $leads_form->start('kform', $phs, 'POST', true);
		$lead_form_inhalt .='<table style="width: 200px;"><tr>';

		$alle_status_leads_temp = Plugin_System_LeadTracker::getLeadCategoryList();
        $alle_status_leads = array();
        foreach ($alle_status_leads_temp as $key => $value) {
            if (!isset($alle_status_leads[_PHASE_])) {
                $alle_status_leads[_PHASE_] = 'OPTGROUP';
            }
            $alle_status_leads[$key] = $value;
        }
        $alle_status_leads[_GRUPPIERUNG_] = 'OPTGROUP';
        $alle_status_leads['9,6,5'] = _IN_ARBEIT_;
        $lead_form_inhalt .= '<td>'._PHASE_.': '.$leads_form->selectinput('leadstatus', $alle_status_leads, $_SESSION['leadstatus'], _KEINE_AUSWAHL_).'<td>';

		$alle_kamps = get_kamps($cfg_leadprozess_schlank);
		$lead_form_inhalt .= '<td>'._KAMPAGNE_.': '.$leads_form->selectinput('pim_kamp1', $alle_kamps, $_SESSION['pim_kamp1'], _KEINE_AUSWAHL_).'</td>';
		$lead_form_inhalt .= '<td style="width: 150px;">'.$lang['_LEAD_'].' '.$lang['_IMPORTDATUM_'].':</td>';
		$lead_form_inhalt .= '<td>';
		if (isset($_SESSION['pim_lead_datum_start'])) {
			$lead_form_inhalt .= $leads_form->datuminput('pim_lead_datum_start', $_SESSION['pim_lead_datum_start']);
		} else {
			$lead_form_inhalt .= $leads_form->datuminput('pim_lead_datum_start');
		}
		$lead_form_inhalt .= '</td>';
		$lead_form_inhalt .= '<td>';
		if (isset($_SESSION['pim_lead_datum_ende'])) {
			$lead_form_inhalt .= $leads_form->datuminput('pim_lead_datum_ende', $_SESSION['pim_lead_datum_ende']);
		} else {
			$lead_form_inhalt .= $leads_form->datuminput('pim_lead_datum_ende');
		}
		$lead_form_inhalt .= '</td>';
		$lead_form_inhalt .= '<td>';
		$lead_form_inhalt .= $leads_form->submit('ou_submit', _OK_);
		$lead_form_inhalt .= '</td></tr></table>';
		$lead_form_inhalt .= $leads_form->ende();
		debug_logging('$lead_form_inhalt: '.$lead_form_inhalt);
		return $lead_form_inhalt;
	}

	function get_benutzer_id_from_lead($lead_id) {
		global $db, $sql_tab, $sql_tabs;
		
		debug_logging('in get_benutzer_id_from_lead');
		$benutzer_id = dbout($sql_tab['kampagne_lead'], array($sql_tabs['kampagne_lead']['benutzer_id']), $sql_tabs['kampagne_lead']['kampagne_lead_id'].'='.$db->dbzahl($lead_id));
		debug_logging('in get_benutzer_id_from_lead after query');
		return $benutzer_id;
	}

	function lead_pim_in_pim() {
		global $db, $sql_tab, $sql_tabs;

		$res = $db->select( 
			$sql_tab['benutzer'],
			$sql_tabs['benutzer']['benutzer_id'],
			$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id']).' and '.
			$sql_tabs['benutzer']['pim_anordnung'].' LIKE "%lead_pim%"'
		);
		//debug_logging('last_sql @ pim function: '.$db->last_sql());
		if ($row = $db->zeile($res)) { 
			return true;
		}
        if ($_SESSION['design_70']) {
            return true;
        }
		return false;
	}

    unset($_SESSION['leadprozess']);
    unset($_SESSION['pim_alle_ben_vkl']);
?>
