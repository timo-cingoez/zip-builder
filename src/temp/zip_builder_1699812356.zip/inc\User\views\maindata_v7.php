<?php

/** Alexander - added phpstorm notes:
 *  will know the variables
 * global
 * @var array $sql_tabs
 * @var array $sql_tab
 * @var array $db
 * @var array $lang
 * @var array $cfg_benutzer_sprache
 * @var boolean $cfg_password_policy
 * @var array $cfg_passwortsicherheit
 * @var boolean $cfg_pim_otherusers
 * @var boolean $cfg_user_unterschrift_ratio
 * @var boolean $cfg_opos_stidaufruf
 * @var boolean $cfg_catch_retail
 * @var boolean $cfg_stammdaten_lead
 * @var boolean $cfg_leadmanagement_2020
 * @var boolean $cfg_catch_whole
 * @var string $cfg_basedir
 * @var array $cfg_benutzer_startseite
 * from parent
 * @var int $uid
 * @var int $user
 * @var string $phs
 * @var string $link
 * @var string $tabsList
 * @var string $title_main_comtact_data
 * @var array $getfeld
 * @var array $postfeld
 *
 */

if (isset($_POST['password_policy_reset'])) {
    $zusatzget = '';
    if ($getfeld['from'] != '') {
        $zusatzget = '?uid='.$uid.'&from='.$getfeld['from'];
    }
    wechsel('benutzer_passwort.php?user_id='.$uid.'&hidden_reset_password='.urlencode(verschluesseleWert($_SESSION['user_id'])).'&quelle='.urlencode(verschluesseleWert('benutzer.php'.$zusatzget)));
}

if (isset($postfeld['submit'])) {
    foreach (array('login', 'name', 'vorname', 'passwort') as $key) {
        if (isset($postfeld['user_setting'][$key])) {
            unset($postfeld['user_setting'][$key]);
        }
    }
}
$besonderes_recht = array();
if ($user->besonderes_recht != '') {
    $besonderes_recht = unserialize($user->besonderes_recht);
}

if (isset($postfeld['submit'])) {

    $data = $postfeld['user_setting'];

    $x = preg_replace('/_.*/', '', $_SESSION['hash']);
    
    if (!empty($cfg_kat_portal) || $_SESSION['cfg_kunde'] === 'portal') {
        if (isset($postfeld['p4n_verantwortlich'])) {
            $besonderes_recht['p4n_verantwortlich']=$postfeld['p4n_verantwortlich'];
            $data['besonderes_recht']=serialize($besonderes_recht);
        }
        if (isset($postfeld['p4n_auskennen'])) {
            $besonderes_recht['p4n_auskennen']=$postfeld['p4n_auskennen'];
            $data['besonderes_recht']=serialize($besonderes_recht);
        }
        if (isset($postfeld['p4n_team'])) {
            $besonderes_recht['p4n_team']=$postfeld['p4n_team'];
            $data['besonderes_recht']=serialize($besonderes_recht);
        }
        if (isset($postfeld['p4n_aufgaben'])) {
            $besonderes_recht['p4n_aufgaben']=$postfeld['p4n_aufgaben'];
            $data['besonderes_recht']=serialize($besonderes_recht);
        }
        if (isset($postfeld['p4n_nebenaufgaben'])) {
            $besonderes_recht['p4n_nebenaufgaben']=$postfeld['p4n_nebenaufgaben'];
            $data['besonderes_recht']=serialize($besonderes_recht);
        }
        if (isset($postfeld['p4n_bereich'])) {
            $besonderes_recht['p4n_bereich']=$postfeld['p4n_bereich'];
            $data['besonderes_recht']=serialize($besonderes_recht);
        }
        if (isset($postfeld['p4n_wochenstunden'])) {
            $besonderes_recht['p4n_wochenstunden']=$postfeld['p4n_wochenstunden'];
            $data['besonderes_recht']=serialize($besonderes_recht);
        }
    }
    
    $data['startseite'] = remove_wwwlink_prefix($data['startseite']);
    $m_sprache = $_SESSION['sprache'];
    if ($_SESSION['user_id'] == $uid) {
        $_SESSION['version_reload'] = true;
    }
    $data['signatur_vorlage'] = json_encode($postfeld['signatur_vorlage']);

    $pw_fehler = '';
    $pw = $user['passwort'];
    if ($postfeld['alt'] !== '' && $postfeld['neu1'] !== '' && $postfeld['neu2'] !== '') {
        if ($pw != hash('sha512', $postfeld['alt']) && $pw != md5($postfeld['alt'])) {
            $pw_fehler = _PW_FEHLER1_;
        } else {
            $ok_pass = true;
            if ($postfeld['neu1'] !== $postfeld['neu2']) {
                $pw_fehler .= _PW_FEHLER2_;
                $ok_pass = false;
            } elseif (is_array($cfg_passwortsicherheit) && count($cfg_passwortsicherheit) > 0) {
                $ok_pass = false;
                $neuregex = $meldung = '';
                foreach ($cfg_passwortsicherheit as $warnhinweis => $pregex) {
                    $neuregex .= $pregex;
                    $meldung .= ' '.$warnhinweis;
                }
                if (intval(@preg_match("/^\S*".$neuregex."\S*$/", $postfeld['neu1'])) > 0) {
                    $ok_pass = true;
                } else {
                    $pw_fehler .= _PW_FEHLER3_.' '.trim($meldung);
                }
            }
            if ($ok_pass) {
                // ok:
                $data['passwort'] = hash('sha512', $postfeld['neu1']);
                $pw_fehler .= _PW_OK_;
            }
        }
    } else {
        if ($postfeld['alt'] === '' && ($postfeld['neu1'] !== '' || $postfeld['neu2'] !== '')) {
            $pw_fehler .= _PW_FEHLER1_;
        } elseif ($postfeld['neu1'] !== '' || $postfeld['neu2'] !== '') {
            $pw_fehler .= _PW_FEHLER2_;
        } elseif ($postfeld['alt'] !== '') {
            $pw_fehler .= _PW_FEHLER1_;
        }
    }
    
    if (!isset($data['neuesdesign']) && $data['neuesdesign_alt']!='null') {
        $data['neuesdesign']=0;
    }

    foreach ($data as $key => $value) {
        if (is_array($value)) {
            $value = implode(',', $value);
        } else {
            if ($value === '-1') {
                $value = '';
            }
        }
        $user[$key] = $value;
    }
    $user->save();
    
    if (!isset($data['neuesdesign']) && $data['neuesdesign_alt']=='null') {
        $db->update($sql_tab['benutzer'], array(
            $sql_tabs['benutzer']['neuesdesign'] => 'NULL'
        ),
        $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id']));
    }

    if (class_exists('Logger_File')) {
        $logger = new Logger_File('inc/'.$_SESSION['cfg_kunde'].'/crm_protocol.txt', true);
        $logger->info(p4n_mb_string('utf8_encode', _BENUTZER_.' ('.$uid.') '._EINSTELLUNGEN_.' ('._ALLGEMEIN_.') '._WURDE_GEAENDERT_.' ('.$_SESSION['mitarbeiter_name'].' ('.$_SESSION['user_id'].') - benutzer.php)'));
    }
    if ($cfg_pim_otherusers && $_SESSION['crm_version'] > 67) {
        $interface_refRepository = new Interface_RefRepository('pim_users_online');
        $row_interface = $interface_refRepository->getAllForTable('benutzer', $uid);
        $interface_ref_id = null;
        if (!empty($row_interface)) {
            $interface_ref_id = $row_interface[0]['interface_ref_id'];
        }
        $extern_id_val = array();
        if (isset($postfeld['pim_benutzer_online'])) {
            $extern_id_val = $postfeld['pim_benutzer_online'];
        }
        $interface_ref = new Interface_Ref($interface_ref_id);
        $interface_ref['interface'] = 'pim_users_online';
        $interface_ref['table_name'] = 'benutzer';
        $interface_ref['table_id'] = $uid;
        $interface_ref['extern_id'] = implode(',', $extern_id_val);
        $interface_ref->save();
    }

    unset($_SESSION['modern']['cache_menu']);
    unset($_SESSION['modern']['cache_fav']);
    $refresh = false;
    if ($data['sprache'] != $_SESSION['sprache']) {
        // reload divs 'menu' and 'main content' after change language
        $refresh = true;
    }
}
// Image2
$deleteUserImage2 = isset($_POST['submit']) && empty($_POST['user_image2']) && empty($_POST['_user_image2']);
$userImage2 = $cfg_basedir.'dokumente/user_images/'.$uid.'_2.jpg';
if (
    (
        !empty($getfeld['delete_user_image2']) ||
        $deleteUserImage2
    ) && is_file($userImage2)
) {
    unlink($userImage2);
}

$userImageError2 = '';
if (!empty($_FILES['user_image2']) && $_FILES['user_image2']['error'] == 0) {
    $fileData = $_FILES['user_image2'];
    $fileName = $fileData['name'];
    $xpl = explode('.', $fileName);
    $extension = strtolower($xpl[count($xpl) - 1]);
    if (in_array($extension, array('jpg', 'jpeg', 'gif', 'png'))) {
        if (!is_dir(dirname($userImage2))) {
            mkdir(dirname($userImage2), 0777, true);
        }
        if ($cfg_user_unterschrift_ratio) {
            if (intval($fileData['size']) > (1024 * 1024 * 1)) {
                $userImageError = '<span style="color:red">'._FEHLER_.': '.$lang['_DOK-GROESSE_'].' &gt; 1 MB</span><br>';
                $fileData['error'] = 1;
            } else {
                move_uploaded_file($fileData['tmp_name'], $userImage2);
                if (isset($_POST['user_image_breite2']) && $_POST['user_image_breite2'] != '' && isset($_POST['user_image_hoehe2']) && $_POST['user_image_hoehe2'] != '') {
                    resize_bild($userImage2, $userImage2, $extension, intval($_POST['user_image_breite2']), intval($_POST['user_image_hoehe2']), (isset($_POST['user_image_prob2']) ? true : false));
                }
            }
        } else {
            move_uploaded_file($fileData['tmp_name'], $userImage2);
            if ($_SESSION['cfg_kunde'] == 'carlo_opel_dbrent') {
                resize_bild($userImage2, $userImage2, $extension, 250, 250, true);
            } else {
                resize_bild($userImage2, $userImage2, $extension, 200, 100, true);
            }
        }
    } else {
        $userImageError2 = '<span style="color:red">'._UNERLAUBTEDATEI_.' ('.$extension.')</span><br>';
    }
}
// Image
$deleteUserImage = isset($_POST['submit']) && empty($_POST['user_image']) && empty($_POST['_user_image']);
$userImage = $cfg_basedir.'dokumente/user_images/'.$uid.'.jpg';
if (
    (
        isset($_GET['delete_user_image']) ||
        $deleteUserImage
    ) && is_file($userImage)
) {
    unlink($userImage);
}
$userImageError = '';
if (!empty($_FILES['user_image']) && $_FILES['user_image']['error'] == 0) {
    $fileData = $_FILES['user_image'];
    $fileName = $fileData['name'];
    $xpl = explode('.', $fileName);
    $extension = strtolower($xpl[count($xpl) - 1]);
    if (in_array($extension, array(
        'jpg',
        'jpeg',
        'gif',
        'png'
    ))) {
        if (!is_dir(dirname($userImage))) {
            mkdir(dirname($userImage), 0777, true);
        }
        if ($cfg_signaturbild_ratio) {
            if (intval($fileData['size']) > (1024 * 1024 * 1)) {
                $userImageError = '<span style="color:red">'._FEHLER_.': '.$lang['_DOK-GROESSE_'].' &gt; 1 MB</span><br>';
                $fileData['error'] = 1;
            } else {
                move_uploaded_file($fileData['tmp_name'], $userImage);
                if (isset($_POST['user_image_breite']) && $_POST['user_image_breite'] != '' && isset($_POST['user_image_hoehe']) && $_POST['user_image_hoehe'] != '') {
                    resize_bild($userImage, $userImage, $extension, intval($_POST['user_image_breite']), intval($_POST['user_image_hoehe']), (isset($_POST['user_image_prob']) ? true : false));
                }
            }
        } else {
            move_uploaded_file($fileData['tmp_name'], $userImage);
            if ($_SESSION['cfg_kunde'] == 'carlo_opel_dbrent') {
                resize_bild($userImage, $userImage, $extension, 250, 250, true);
            } else {
                resize_bild($userImage, $userImage, $extension, 128, 128);
            }
        }
    } else {
        $userImageError = '<span style="color:red">'._UNERLAUBTEDATEI_.' ('.$extension.')</span><br>';
    }
}
if (is_file($userImage)) {
    list($userImage_width, $userImage_height) = getimagesize($userImage);
}
if (is_file($userImage2)) {
    list($userImage2_width, $userImage2_height) = getimagesize($userImage2);
}
// Startseite:
if ($cfg_opos_stidaufruf && !isset($cfg_benutzer_startseite['op_sap.php'])) {
    $cfg_benutzer_startseite['op_sap.php'] = 'OP-Liste';
}
if (($cfg_catch_retail || $cfg_catch_whole) && !isset($cfg_benutzer_startseite['leadanlage.php'])) {
    $cfg_benutzer_startseite['leadanlage.php'] = _LEADANLAGE_;
}
if (preg_match('/vw/i', $_SESSION['cfg_kunde']) || preg_match('/audi/i', $_SESSION['cfg_kunde'])) {
    $cfg_benutzer_startseite['serviceannahme.php'] = _SERVICECENTER_;
}
if ($cfg_stammdaten_lead || $cfg_leadmanagement_2020) {
    if ($_SESSION['crm_version'] > 60 && is_file('inc/utilities.php')) {
        include_once('inc/utilities.php');
        if (hasRight($_SESSION['user_id'], 'leadprozess.php')) {
            $cfg_benutzer_startseite['leadprozess.php'] = 'Leadprozess';
        }
        if (hasRight($_SESSION['user_id'], 'leadprozess_vkl.php')) {
            $cfg_benutzer_startseite['leadprozess_vkl.php'] = 'Lead PIM VKL';
        }
    }
}
// Signatur
$signaturePatterns = array();
$res = $db->select($sql_tab['email_vorlagen'], array(
    $sql_tabs['email_vorlagen']['email_vorlagen_id'],
    $sql_tabs['email_vorlagen']['bezeichnung']
), $sql_tabs['email_vorlagen']['kategorie'].'='.$db->str('_ADMINBENUTZER-SIGNATUR_'), $sql_tabs['email_vorlagen']['bezeichnung']);
while ($row = $db->zeile($res)) {
    $signaturePatterns[$row[0]] = $row[1];
}

$signatur_vorlage = json_decode($user['signatur_vorlage'], true);
if (!is_array($signatur_vorlage)) {
    $signatur_vorlage = array();
}

$pim_benutzer_online = $pim_benutzer_online_def = array();
if ($cfg_pim_otherusers && $_SESSION['crm_version'] > 67) {
    $result_benutzer_gruppen = $db->select($sql_tab['benutzer_gruppe'], array(
        $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
        $sql_tabs['benutzer_gruppe']['bezeichnung'],
    ), '', $sql_tabs['benutzer_gruppe']['rang'].' asc');
    while ($row_benutzer_gruppen = $db->zeile($result_benutzer_gruppen)) {
        $pim_benutzer_online[$row_benutzer_gruppen[0]] = $row_benutzer_gruppen[1];
    }

    $interface_ref = new Interface_RefRepository('pim_users_online');
    $row = $interface_ref->getAllForTable('benutzer', $uid);
    if (!empty($row) && $row[0]['extern_id'] != '') {
        $pim_benutzer_online_def = explode(',', $row[0]['extern_id']);
    }
}

$hat_ldap = false;
$res = $db->select($sql_tab['benutzer'], $sql_tabs['benutzer']['login_ldap'], $sql_tabs['benutzer']['benutzer_id']."=".$db->dbzahl($uid));
if ($row = $db->zeile($res)) {
    if ($row[0] != '') {
        $hat_ldap = true;
    }
}
$countries = array();
$res = $db->select($sql_tab['kategorie'], $sql_tabs['kategorie']['bezeichnung'], $sql_tabs['kategorie']['modul'].'='.$db->dbzahl(12), $sql_tabs['kategorie']['bezeichnung'].' asc');
while ($row = $db->zeile($res)) {
    $country = $row[0];
    if (!empty($country)) {
        $countries[$country] = abkuerzung($country);
    }
}
$i = 0;
?>
    <script type="text/javascript">
        <?php if ($refresh): ?>
        jq1112(document).ready(function ($) {
            P4nBoxHelper.closeall();
            closeAllModal();
            RequestHelper.get("<?=$link?>", function (response) {
                setTimeout(function () {
                    // console.log(response);
                    var a = $("div.frameclass.wasmain.ismain");
                    a.html(response);
                    a.ready(function () {
                        // console.log("1 READY");
                        document_ready();
                        window_load();
                    });
                }, 40);
            }, false, true, true);

            RequestHelper.get("_menu_70_ajax.php", function (response) {
                setTimeout(function () {
                    //console.log(response);
                    var b = $("div#main-menu-content");
                    //console.log(b);
                    b.html(response);
                    b.ready(function () {
                        //console.log("2 READY");
                        document_ready();
                        window_load();
                    });
                }, 40);
            }, false, true, true);
        });
        <?php endif; ?>

        function prepareSignPreview(signKey) {
            let patternId = document.getElementById("signatur_vorlage_" + signKey).value;
            if (parseInt(patternId) < 1) {
                templateAlert('<?=_FEHLER_POPUP_.'<br>'._VORLAGEN_?>');
                return false;
            }
            const url = "benutzer.php?tabs_loaded=1&view=signatur&user_id=<?=$uid ?>&vorlage_id=" + patternId + "&sig_id=" + signKey;
            jq1112('div#benutzer_php button[name="sig_button' + signKey + '"]').attr('data-request-url',url);
            console.log(url);
            return true;
        }
        <?php if ($cfg_signaturbild_ratio): ?>
        function check_zahl(t) {
            var zahl = t;
            for (var i = 0; i < zahl.value.length; i++) {
                var z = zahl.value.substring(i, i + 1);
                if (z < "0" || "9" < z) {
                    var zahl2 = zahl.value.substring(0, zahl.value.length - 1);
                    zahl.value = zahl2;
                    zahl.focus();
                    return false;
                }
            }
        }
        <?php endif; ?>
    </script>
<?php
$form = new Template_Form('settings', $link.'&tabs_loaded=1', 'POST', true, '');
$form->setTarget('maindata');

//alex: try implement new design
//https://xd.adobe.com/view/928a8df8-dda7-4d0c-911d-bcdbdb325598-c7d9/screen/8fefcd9c-38b3-4e13-a0c4-c19fbecf956c/
// page 53: Pers�nlichen Einstellungen
$group_title = new Template_Title(_PERSONENDATEN_, 5);
$form->addElement($group_title);

// section _PERSONENDATEN_
$cols = $content = $cell = array();
$td_i = $i = 0;
$title = Template_Title::init($title_main_comtact_data, 5)->setAttribute('class', 'title_blue padding-bottom');
$cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_TextInput(_MOBILFON_, 'user_setting[mobilfon]', $user['mobilfon']));
$cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_TextInput(_TELEFON2_, 'user_setting[telefon]', $user['telefon']));
$cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_TextInput(_FAX_, 'user_setting[fax]', $user['fax']));
$cell[0][$td_i] = makeCardWithGridTable($title, $cols);
if (!empty($cfg_benutzer_adresse)) {
    $i = 0;
    $cols = array();
    $title = Template_Title::init(_ANDERE_DATEN_.' '._KUNDEN_.' '._KOMMUNIKATION_, 5)->setAttribute('class', 'title_blue padding-bottom');
    $cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_TextInput(_ADRESSE_, 'user_setting[adresse]', $user['adresse']));
    $cols[$i][0] = Template_GridTableCol::init(4, 4, 4, new Template_TextInput(_PLZ_, 'user_setting[plz]', $user['plz'], 5));
    $cols[$i++][1] = Template_GridTableCol::init(8, 8, 8, new Template_TextInput(_ORT_, 'user_setting[ort]', $user['ort'], 10));
    $cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_SelectInput(_LAND_, 'user_setting[land]', $countries, $user['land'], _KEINE_AUSWAHL_));
    $cols[$i][0] = Template_GridTableCol::init(12, 12, 12, new Template_TextArea((!empty($cfg_wegbeschreibung_kvbestaetigungsmail) ? 'zus�tzl. Email-Empf�nger f�r KV-Best�tigung' : _WEGBESCHREIBUNG_), 'user_setting[wegbeschreibung]', $user['wegbeschreibung'], 30, 3));
    $td_i++;
    $cell[0][$td_i] = makeCardWithGridTable($title, $cols);
}

$i = 0;
$cols = array();
$title = Template_Title::init(_BILD_, 5)->setAttribute('class', 'title_blue padding-bottom');

$imageInput = new Template_FileInput('', 'user_image', '', '', '', false, 1);
$cols[$i++][0] = Template_GridTableCol::init(
    12, 12, 12,
    $imageInput->initFileList(
        '',
        'bild',
        [$userImage],
        [],
        '',
        'xs',
        true
    )
);

if ($cfg_signaturbild_ratio) {
    $cols[$i][0] = Template_GridTableCol::init(
        8, 8, 8,
        new Template_ElementList(
            array(
                new Template_NumberInput(_BREITE_.' in px', 'user_image_breite', '', 3, 'onKeyUp="check_zahl(this)"'),
                (new Template_Text('x'))->setAttribute('class', 'mt-16'),
                new Template_NumberInput(_HOEHE_.' in px', 'user_image_hoehe', '', 3, 'onKeyUp="check_zahl(this)"')
            ), '', 'horizontal'
        )
    );
    $cols[$i++][1] = Template_GridTableCol::init(
        4, 4, 4,
        new Template_CheckInput(_CSS_PROPORTIONEN_, 'user_image_prob', true)
    );
}
$cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_Html('<div style="height:5px;display:block;"></div>'.$userImageError));

$td_i++;
$cell[0][$td_i] = makeCardWithGridTable($title, $cols);
//end
if ($cfg_user_unterschrift) {
    $i = 0;
    $cols = array();
    $title = Template_Title::init(_BILD_.' '._DATENSCHUTZ1K_5_, 5)->setAttribute('class', 'title_blue padding-bottom');

    $imageInput = new Template_FileInput('', 'user_image2', '', '', '', false, 1);
    $cols[$i++][0] = Template_GridTableCol::init(
        12, 12, 12,
        $imageInput->initFileList(
            '',
            'bild',
            [$userImage2],
            [],
            '',
            'xs',
            true
        )
    );
    
    if ($cfg_user_unterschrift_ratio) {
        $cols[$i][0] = Template_GridTableCol::init(
            8, 8, 8,
            new Template_ElementList(
                array(
                    new Template_NumberInput(_BREITE_.' in px', 'user_image_breite2', '', 3, 'onKeyUp="check_zahl(this)"'),
                    (new Template_Text('x'))->setAttribute('class', 'mt-16'),
                    new Template_NumberInput(_HOEHE_.' in px', 'user_image_hoehe2', '', 3, 'onKeyUp="check_zahl(this)"')
                ), '', 'horizontal'
            )
        );
        $cols[$i++][1] = Template_GridTableCol::init(
            4, 4, 4,
            new Template_CheckInput(_CSS_PROPORTIONEN_, 'user_image_prob2', true)
        );
    }

    $cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_Html('<div style="height:5px;display:block;"></div>'.$userImageError2));
    if (is_file($userImage2)) {
        $cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_Html('<div style="position: relative;" title="'.$userImage2_width.' x '.$userImage2_height.' px">
                <img style="max-width:300px" src="'.$userImage2.'?'.time().'" /><div style="top:1px;left:1px;cursor:pointer;position:absolute;">'.
                Template_Link::init(' ', $link.'?uid='.$uid.'&view=maindata&delete_user_image2=1&tabs_loaded=1', '', _ABFRAGE_LOESCHEN_)->setAttribute('style','background-image: url('.$cfg_basedir.'bilder/loesch.gif);height:15px;width:15px')->getHtml().
                '</div></div>'));
    }
    $td_i++;
    $cell[0][$td_i] = makeCardWithGridTable($title, $cols);
}

$gridTable = new Template_GridTable($cell);
$card = new Template_Card('', $gridTable, array(
    'shadow' => true,
    'padding' => true
));
$form->addElement($card);

// section email signature
$cols = $content = $cell = array();
$i = 0;

$group_title = new Template_Title(_BEMAIL_, 5);
$form->addElement($group_title);

foreach (array('1', '2', '3') as $i => $k) {
    $title = Template_Title::init(_EMAIL_.' '.$k, 5)->setAttribute('class', 'title_blue padding-bottom');
    $cols = array();
    $cols[0][$i] = Template_GridTableCol::init(12, 12, 12, new Template_TextInput(_EMAIL_ADRESS_, 'user_setting[email'.($k > 1 ? $k : '').']', $user['email'.($k > 1 ? $k : '')]));
    $cols[1][$i] = Template_GridTableCol::init(12, 12, 12, Template_TextArea::init($lang['_ADMINBENUTZER-SIGNATUR_'], 'user_setting[signatur'.($k > 1 ? $k : '').']', $user['signatur'.($k > 1 ? $k : '')], 20, 4));
    if (!empty($signaturePatterns)) {
        $cols[2][$i] = Template_GridTableCol::init(12, 12, 12, new Template_SelectInput(_VORLAGE_, 'signatur_vorlage['.$k.']', $signaturePatterns, @$signatur_vorlage[$k], _OHNEVORLAGE_, 'id="signatur_vorlage_'.$k.'"'));
        $responseContainer = new Template_Html();
        $responseContainer->setAttribute('id', 'SignPreview-'.$k.'_inhalt');
        $modal = Template_Modal::init('SignPreview-'.$k, null, $responseContainer);
        $modal->setRight();
        $requestTrigger = new Template_Button('sig_button'.$k, _VORSCHAU_, 'onclick="if (prepareSignPreview('.$k.') === false) { return false; }"', '', '', '', 'xs', 'grey');
        $requestTrigger->setRequest('GET', $responseContainer, $cfg_basedir.'benutzer.php?tabs_loaded=1&view=signatur&user_id='.$uid.'&sig_id='.$k, '', $modal);
        $cols[3][$i] = Template_GridTableCol::init(12, 12, 12, array($requestTrigger, $modal));
    }
    $cell[0][$i] = makeCardWithGridTable($title, $cols);
}

$gridTable = new Template_GridTable($cell);
$card = new Template_Card('', $gridTable, array(
    'shadow' => true,
    'padding' => true
));
$form->addElement($card);

// section _GLOBALE_EINSTELLUNGEN_
$group_title = new Template_Title(p4n_mb_string('ucfirst', _GLOBALE_EINSTELLUNGEN_), 5);
$form->addElement($group_title);
$i = 0;
$cols = $cell = array();
$cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_SelectInput(_BSTYLE_, 'user_setting[stil]', Modern_Helper_Stile::getFarbschemaSelectArr(), $user['stil']));
$cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_SelectInput(_BSTARTSEITE_, 'user_setting[startseite]', $cfg_benutzer_startseite, $_SESSION['startseite']));
$cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_SelectInput(_BSPRACHE_, 'user_setting[sprache]', $cfg_benutzer_sprache, $_SESSION['sprache']));
if ($cfg_pim_otherusers && $_SESSION['crm_version'] > 67) {
    $cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_SelectInput($lang['_PIM-USERONLINE_'], 'pim_benutzer_online', $pim_benutzer_online, $pim_benutzer_online_def, false, '', true, (count($pim_benutzer_online) > 4 ? 5 : count($pim_benutzer_online))));
}
if ($cfg_design70_btn && (int)$_SESSION['user_id'] === 1) {
    $cols[$i++][0] = Template_GridTableCol::init(
        12, 12, 12,
        array(
            new Template_CheckInput('Neues Design', 'user_setting[neuesdesign]', $user['neuesdesign']),
            new Template_HiddenInput('user_setting[neuesdesign_alt]',(is_null($user['neuesdesign'])?'null':''))
        )
    );
}
$cell[0][0] = makeCardWithGridTable('', $cols, array(
    'shadow' => true,
    'padding' => true
));
//empty cell
$cell[0][1] = $cell[0][2] = new Template_Text('');

$gridTable = new Template_GridTable($cell);
$form->addElement($gridTable);


// section password
if ($_SESSION['user_id'] == $uid && !boolval($user->login_ldap)) {
    $i = 0;
    $cols = $cell = array();
    $group_title = new Template_Title(_PASSWORD_POLICY_RESET_PASS_, 5);
    $form->addElement($group_title);

    if ($cfg_password_policy) {
        $cols[$i++][0] = Template_Submit::init('password_policy_reset', _PASSWORD_POLICY_RESET_PASS_, '', '', '', '', '', 'xs', 'grey');
        if (!empty($_GET['infotext'])) {
            $cols[$i++][0] = new Template_Text(entschluesseleWert($_GET['infotext']));
        }
    } else {
        $cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_PasswordInput(_BPASSWORT_ALT_, 'alt'));
        $cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_PasswordInput(_BPASSWORT_NEU1_, 'neu1', '', 20));
        $cols[$i++][0] = Template_GridTableCol::init(12, 12, 12, new Template_PasswordInput(_BPASSWORT_NEU2_, 'neu2', '', 20));
        if (!empty($pw_fehler)) {
            $cols[$i++][0] = new Template_Html('<font color="'.(!empty($ok_pass) ? 'green' : 'red').'">'.$pw_fehler.'</font>');
        }
    }

    $cell[0][0] = makeCardWithGridTable('', $cols, array(
        'shadow' => true,
        'padding' => true
    ));
    //empty cell
    $cell[0][1] = $cell[0][2] = new Template_Text('');

    $gridTable = new Template_GridTable($cell);
    $form->addElement($gridTable);
}

// region Product responsibility.
if (!empty($cfg_kat_portal) || $_SESSION['cfg_kunde'] === 'portal') {
    $alle_pgs = $alle_p4n_pg = array();
    $result_produkt_gruppe = $db->select(
        $sql_tab['produkt_gruppe'],
        array(
            $sql_tabs['produkt_gruppe']['gruppe_id'],
            $sql_tabs['produkt_gruppe']['parent_id'],
            $sql_tabs['produkt_gruppe']['bezeichnung'],
            $sql_tabs['produkt_gruppe']['rang']
        ),
        $sql_tabs['produkt_gruppe']['aktiv'].'=1',
        $sql_tabs['produkt_gruppe']['parent_id'].','.$sql_tabs['produkt_gruppe']['rang']
    );
    while ($row_produkt_gruppe = $db->zeile($result_produkt_gruppe)) {
        $alle_pgs[$row_produkt_gruppe['gruppe_id']] = $row_produkt_gruppe['bezeichnung'];
        $bez = $row_produkt_gruppe['bezeichnung'];
        if ((int)$row_produkt_gruppe['parent_id'] > 0) {
            $bez = $alle_pgs[$row_produkt_gruppe['parent_id']].' - '.$bez;
        }
        $alle_p4n_pg[$row_produkt_gruppe['gruppe_id']] = $bez;
    }
    $alle_p4n_pg = is_array($alle_p4n_pg) ? $alle_p4n_pg : array();
    asort($alle_p4n_pg);
    
    $p4nkats = array();
    $result_kategorie = $db->select(
        $sql_tab['kategorie'],
        array(
            $sql_tabs['kategorie']['modul'],
            $sql_tabs['kategorie']['bezeichnung']
        ),
        $sql_tabs['kategorie']['modul'].' in (200,201,202,203)'
    );
    while ($row_kategorie = $db->zeile($result_kategorie)) {
        $p4nkats[(int)$row_kategorie['modul']][$row_kategorie['bezeichnung']] = $row_kategorie['bezeichnung'];
    }
    $p4nkats[200] = is_array($p4nkats[200]) ? $p4nkats[200] : array();
    $p4nkats[201] = is_array($p4nkats[201]) ? $p4nkats[201] : array();
    $p4nkats[202] = is_array($p4nkats[202]) ? $p4nkats[202] : array();
    $p4nkats[203] = is_array($p4nkats[203]) ? $p4nkats[203] : array();
    asort($p4nkats);
    asort($p4nkats[200]);
    asort($p4nkats[201]);
    asort($p4nkats[202]);
    asort($p4nkats[203]);
    
    $sel1 = array();
    if (isset($besonderes_recht['p4n_verantwortlich'])) {
        $sel1 = $besonderes_recht['p4n_verantwortlich'];
    }
    $sel2 = array();
    if (isset($besonderes_recht['p4n_auskennen'])) {
        $sel2 = $besonderes_recht['p4n_auskennen'];
    }
    $sel3 = array();
    if (isset($besonderes_recht['p4n_team'])) {
        $sel3 = $besonderes_recht['p4n_team'];
    }
    $sel4 = array();
    if (isset($besonderes_recht['p4n_aufgaben'])) {
        $sel4 = $besonderes_recht['p4n_aufgaben'];
    }
    $sel5 = array();
    if (isset($besonderes_recht['p4n_nebenaufgaben'])) {
        $sel5 = $besonderes_recht['p4n_nebenaufgaben'];
    }
    $sel6 = array();
    if (isset($besonderes_recht['p4n_bereich'])) {
        $sel6 = $besonderes_recht['p4n_bereich'];
    }
    $wochenstunden = '';
    if (isset($besonderes_recht['p4n_wochenstunden'])) {
        $wochenstunden = $besonderes_recht['p4n_wochenstunden'];
    }
    
    $grid = array(
        array(
            new Template_SelectInput(
                'Produkt',
                'p4n_verantwortlich',
                $alle_p4n_pg,
                $sel1,
                false,
                '',
                true,
                10
            )
        ),
        array(
            new Template_SelectInput(
                'Bei diesen Produkten kenne ich mich aus',
                'p4n_auskennen',
                $alle_p4n_pg,
                $sel2,
                false,
                '',
                true,
                10
            )
        ),
        array(
            new Template_SelectInput(
                'Teammitglied',
                'p4n_team',
                $p4nkats[200],
                $sel3,
                false,
                '',
                true,
                10
            )
        ),
        array(
            new Template_SelectInput(
                'Aufgabenfelder',
                'p4n_aufgaben',
                $p4nkats[201],
                $sel4,
                false,
                '',
                true,
                10
            )
        ),
        array(
            new Template_SelectInput(
                'Nebenaufgaben',
                'p4n_nebenaufgaben',
                $p4nkats[202],
                $sel5,
                false,
                '',
                true,
                10
            )
        ),
        array(
            new Template_SelectInput(
                'Bereich',
                'p4n_bereich',
                $p4nkats[203],
                $sel6,
                false,
                '',
                true,
                10
            )
        ),
        array(
            new Template_NumberInput(
                'Anzahl Wochenstunden',
                'p4n_wochenstunden',
                $wochenstunden,
                5
            )
        )
    );
    $gridTable = new Template_GridTable($grid);
    $card = Template_Default::Card('Prof4Net - Produktverantwortung', null, $gridTable);
    $form->addElement($card);
}
// endregion

$form->addElement(Template_HiddenInput::init('tabs_loaded', '1'));
$form->addElement(Template_Submit::init('submit', _SUBMIT_STAMMDATEN_));

echo javas('jq1112("#crm_body").scrollTop(0);');
echo $form->getHtml();
