<?php

class SeatLeads extends BaseLeadImport {
    const SETTINGS_MODULE = 'seat_leads';

    public function __construct() {
        $params = self::getParams();
        if (empty($params['masterCampaign']) || intval($params['masterCampaign']) < 1) {
            throw new Exception(_EINSTELLUNGEN_.' '._UNVOLLSTAENDIG_.' ('._MASTERKAMPAGNE_.')');
        }
        $this->masterCampaign = intval($params['masterCampaign']);
        if (empty($params['locations']) || intval($params['locations']) < 1) {
            throw new Exception(_EINSTELLUNGEN_.' '._UNVOLLSTAENDIG_.' ('._LAGERORTE_.')');
        }
        $this->dealerList = $params['locations'];
        $this->api = new SeatLeads_Api('', $params);
        $this->errorLogger = new Logger_File('log/seat_leads.txt');
    }

    public function importLeads() {
        global $cfg_lead_absatzgruppe;
        $logger = new Logger_ImportExport(self::SETTINGS_MODULE, 'Import leads');
        $lastImport = $logger->getLastRecord();
        $logs = $newLeads = array();
        foreach ($this->dealerList as $locationId => $dealerId) {
            if ($_SESSION['cfg_kunde'] === 'carlo_opel_prof4net') {
                $leads = $this->api->generateTestLeads($dealerId, 'Test Drive', 1);
            } else {
                $leads = $this->api->getLeads();
            }
            foreach ($leads as $data) {
                $lead = new SeatLeads_Lead();
                if ($lead->parse($data)) {
                    $lead['lagerort_id'] = $locationId;
                    $lead['retailer'] = $dealerId;
                    $lead['kampagne_id'] = $this->initCampaign($lead['campaignname']);
                    if (!empty($this->le_qualifizieren[$lead['campaignname']])) {
                        $lead['status'] = 100;
                    }
                    $lead->save();
                    $leadId = $lead['kampagne_lead_id'];
                    // Notifications
                    $leadParams = array(
                        'params' => array(
                            'kampagne_lead_id' => $leadId,
                            'lagerort_id'      => $locationId,
                            'channel'          => $lead['channel'],
                            'type'             => $lead['type'],
                            'kfzmarke'         => $lead['kfzmarke'],
                            'source'           => $lead['source'],
                            'kampagne_id'      => $lead['kampagne_id'],
                            'absatzgruppe'     => '-1'
                        )
                    );
                    $newLeads[$locationId][$lead['leadid']] = $leadParams;
                    $customer = $lead->getCustomer();
                    if (!empty($customer['email'])) {
                        if ($lead['stammdaten_id'] != '') {
                            $leadParams['customer'] = array('stammdaten_id' => $lead['stammdaten_id']);
                        } else {
                            $leadParams['customer'] = $customer;
                        }
                        $leadParams['lead'] = $lead;
                        Lead_CustomerNotification::instance(SeatLeads_Lead::SOURCE)->run(array($customer['email'] => $leadParams));
                    } else {
                        Lead_CustomerNotification::instance(SeatLeads_Lead::SOURCE)->log(_NO_MAILS_FOUND_.' (LEAD ID: '.$leadId.')');
                    }
                    $logs[_LEADS_.' '._HINZUGEFUEGT_]++;
                } else {
                    $logs[_LEADS_.' '._IGNORIERT_]++;
                }
            }
        }
        if (!empty($newLeads)) {
            Lead_Notification::instance(SeatLeads_Lead::SOURCE)->run($newLeads);
        }
        if (empty($logs)) {
            return NULL;
        } else {
            $text = $this->prepareLog($logs);
            $logger->info($text);
            if ($lastImport) {
                $text .= ' ('._SEIT_.' '.$lastImport.')';
            }
            return $text;
        }
    }
}