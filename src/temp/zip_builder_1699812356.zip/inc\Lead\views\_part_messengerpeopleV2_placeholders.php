<?php
/**
 * for phpstorm:
 * @noinspection PhpUndefinedConstantInspection
 * @var array $sql_tabs
 * @var array $sql_tab
 * @var PDB $db
 */
global $cfg_basedir;
PearAutoLoader::instance()->addSourceRoot('inc/services');
$template = $data = $count = $count_body = $count_button = false;
$error = [];
if ($_GET['template']) {
    $template = $_GET['template'];
}
if(empty($template)) {
    echo 'Please select template for configuration';
    exit();
}
$link = 'einstellungen_kfz.php?view=_part_messengerpeopleV2_placeholders&template='.$template;
//AzureApp::dd($_POST);
$obj = MessengerPeopleV2::instance();
$select_options = $obj->getTemplateSelectboxOptions();

$select_options_url_placeholder = [
    'switch' => array(
        'string' => 'is String',
        'stammdaten_id' => 'is DB "Stammdaten" ID',
    ),
    'string' => [
        'manual-fill' => 'Fill manually as Text when init each mailing'
    ],
    'stammdaten_id'  => [
        'stammdaten_id' => '\'Stammdaten\' ID',
    ]
];
$full_cfg = MessengerPeopleV2::getParams();
// get full config for templates section
$config = MessengerPeopleV2::getTemplatesCfg('templates', $full_cfg);
$mass_templates_cfg = MessengerPeopleV2::getTemplatesCfg('mass_templates', $full_cfg);
$data = $obj->getDataTemplate($template);
$template_content = [];
$template_approved = false;
if ($data === false) {
    //todo: need translate
    echo '<b>'._NICHT_GEFUNDEN_.'</b> Please setup template "'.$template.'" at page <a href="https://app.messengerpeople.dev/settings/templates/create" target="_blank">https://app.messengerpeople.dev/settings/templates/create</a>';
    exit;
} elseif (!empty($data['translations']) && empty($data['translations'][$obj->moduleLanguage])) {
    //todo: need translate
    echo '<b>'._NICHT_GEFUNDEN_.' translations for selected language '.strtoupper($obj->moduleLanguage).'</b> Please setup template "'.$template.'" for selected language at page <a href="https://app.messengerpeople.dev/settings/templates/create" target="_blank">https://app.messengerpeople.dev/settings/templates/create</a>';
    exit;
} elseif (!empty($data['translations'][$obj->moduleLanguage]['status']) && $data['translations'][$obj->moduleLanguage]['status'] !=='APPROVED') {
    echo _BSPRACHE_ .' '.strtoupper($obj->moduleLanguage).' <b style="color: maroon">'.MessengerPeopleV2_Template::$templateStatus[$data['translations'][$obj->moduleLanguage]['status']].'</b>';
    exit;
}
$template_content = $data['translations'][$obj->moduleLanguage];
if ($template_content ==='APPROVED') {
    $template_approved = true;
}

//this template cfg
$cfg = MessengerPeopleV2::getTemplatesCfg('templates', $full_cfg, $template);

//media
$image_view = $image = $document = $video = $location = '';
$need_save = $image_form_required = false;

if ($template_content['header_type'] === 'MEDIA') {
    if ($template_content["header_media_type"] === 'LOCATION') {
        echo 'todo: required LOCATION';
        if (!empty($cfg['header']['switch'][1]) &&
            $cfg['header']['switch'][1] === 'media-location' &&
            !empty($cfg['header']['field'][1])
        ) {
            $location = $cfg['header']['field'][1];
            //here need add location to quire
        } else {
            //block of code for required location
        }
    } elseif ($template_content["header_media_type"] === 'DOCUMENT') {
        echo 'todo: required DOCUMENT';
        if (!empty($cfg['header']['switch'][1]) &&
            $cfg['header']['switch'][1] === 'media-document' &&
            !empty($cfg['header']['field'][1])
        ) {
            $document = $cfg['header']['field'][1];
            //here need add document to quire
        } else {
            //block of code for required document
        }
    } elseif ($template_content["header_media_type"] === 'VIDEO') {
        echo 'todo: required VIDEO';
        if (!empty($cfg['header']['switch'][1]) &&
            $cfg['header']['switch'][1] === 'media-video' &&
            !empty($cfg['header']['field'][1])
        ) {
            $video = $cfg['header']['field'][1];
            //here need add video to quire
        } else {
            //block of code for required video
        }

    //---------- image ---------------
    } elseif ($template_content["header_media_type"] === 'IMAGE') {
        $image_form_required = true;
        //is post
        if (isset($_POST['media_image'])) {
            //if is post - then required
            if (empty($_POST['media_image'])) {
                $error[] = _FALSCHE_DATEN_.': Image URl';
            } else {
                $tmp_url = $_POST['media_image'];
                if (false === ($binary = file_get_contents($tmp_url))) {
                    $error[] = 'Ich kann die Bilddatei nicht von dieser URL abrufen: '.$tmp_url;
                } else {
                    $mimetype = null;
                    //AzureApp::dd($http_response_header);
                    foreach ($http_response_header as $v) {
                        preg_match('/^content\-type:\s*(image\/[^;\s\n\r]+)/i', $v, $m);
                        if (!empty($m[1])) {
                            $tmp = $m[1];
                            if ($m[1] === 'image/png' || $m[1] === 'image/jpeg') {
                                $mimetype = $m[1];
                            }
                        }
                    }
                    if (empty($mimetype)) {
                        $error[] = "Es sind nur '.jpg' und '.png' Bilder erlaubt. ".(!empty($tmp) ? '['.$tmp.']' : '');
                    } else {
                        $need_save = true;
                        $cfg['header']['switch'][1] = 'media-image';
                        $image = $cfg['header']['field'][1] = $tmp_url;
                    }
                }
                //AzureApp::dd($image, 'gold', 'image from _post');
            }
        }
        // not post OR incorrect image url - try load from cfg if is before configured
        if (empty($image) && !empty($cfg['header']['switch'][1]) &&
            $cfg['header']['switch'][1] === 'media-image' &&
            !empty($cfg['header']['field'][1])
        ) {
            // image from cfg
            if (false === ($binary = file_get_contents($cfg['header']['field'][1]))) {
                $error[] = 'Ich kann die Bilddatei nicht von dieser URL abrufen: '.$cfg['header']['field'][1];
            } else {
                $mimetype = null;
                //AzureApp::dd($http_response_header);
                foreach ($http_response_header as $v) {
                    preg_match('/^content\-type:\s*(image\/[^;\s\n\r]+)/i', $v, $m);
                    if (!empty($m[1])) {
                        $tmp = $m[1];
                        if ($m[1] === 'image/png' || $m[1] === 'image/jpeg') {
                            $mimetype = $m[1];
                        }
                    }
                }
                if (empty($mimetype)) {
                    $error[] = "Es sind nur '.jpg' und '.png' Bilder erlaubt. ".(!empty($tmp) ? '['.$tmp.']' : '');
                } else {
                    $image = $cfg['header']['field'][1];
                }
            }
        }
    }
}

$type = '24h';
if (in_array($template, $mass_templates_cfg)) {
    $type = 'mass';
    foreach (['time', 'date', 'name', 'datetime'] as $name) {
        foreach ($select_options[$name] as $k => $v) {
            $select_options[$name] = ['manual-fill' => 'Set manually when init each mailing'] + $select_options[$name];
        }
    }
    $select_options['string'] = ['manual-fill' => 'Fill manually as Text when init each mailing'];
}

if (!empty($_POST['template_name'])) {
    $count = (!empty($_POST['count_replaces_header']) && $_POST['count_replaces_header'] > 0 ) ? $_POST['count_replaces_header'] : 0;
    $count_body = (!empty($_POST['count_replaces_body']) && $_POST['count_replaces_body'] > 0 ) ? $_POST['count_replaces_body'] : 0;
    $count_button = (!empty($_POST['count_replaces_button']) && $_POST['count_replaces_button'] > 0 ) ? $_POST['count_replaces_button'] : 0;
}
//AzureApp::dd([$type,$mass_templates_cfg,$select_options], 'blue');
if ($count > 0 || $count_body > 0 || $count_button > 0 || $need_save) {
    // maybe in next version allow select active template, so:
    if ($template !== $_POST['template_name']) {
        //Not valid template name
        $error[] = 'Ung�ltiger Vorlagenname';
    } else {
        while ($count > 0) {
            if (!empty($_POST['placeholder-header-switch'][$count])) {
                switch ($_POST['placeholder-header-switch'][$count]) {
                    case 'time':
                        $cfg['header']['switch'][(int) $count] = 'time';
                        break;
                    case 'date':
                        $cfg['header']['switch'][(int) $count] = 'date';
                        break;
                    case 'datetime':
                        $cfg['header']['switch'][(int) $count] = 'datetime';
                        break;
                    case 'string':
                        $cfg['header']['switch'][(int) $count] = 'string';
                        break;
                    default:
                        $cfg['header']['switch'][(int) $count] = 'name';
                }
            }
            if (!empty($_POST['placeholder-header-prefix'][$count]) && $_POST['placeholder-header-prefix'][$count] !== '-1') {
                // not used prefix if uses time
                if (!in_array($cfg['header']['switch'][(int) $count], ['time', 'datetime', 'date', 'string'])) {
                    $cfg['header']['prefix'][(int) $count] = $_POST['placeholder-header-prefix'][$count];
                }
            }
            if (!empty($_POST['placeholder-header'][$count]) && $_POST['placeholder-header'][$count] !== '-1') {
                $cfg['header']['field'][(int) $count] = $_POST['placeholder-header'][$count];
            } else {
                $error[] = 'Keine Daten festgelegt f�r "header" {{'.$count.'}}';
            }
            $count--;
        }

        while ($count_body > 0) {
            if (!empty($_POST['placeholder-body-switch'][$count_body])) {
                switch ($_POST['placeholder-body-switch'][$count_body]) {
                    case 'time':
                        $cfg['body']['switch'][(int) $count_body] = 'time';
                        break;
                    case 'date':
                        $cfg['body']['switch'][(int) $count_body] = 'date';
                        break;
                    case 'datetime':
                        $cfg['body']['switch'][(int) $count_body] = 'datetime';
                        break;
                    case 'string':
                        $cfg['body']['switch'][(int) $count_body] = 'string';
                        break;
                    default:
                        $cfg['body']['switch'][(int) $count_body] = 'name';
                }
            }

            if (!empty($_POST['placeholder-body-prefix'][$count_body]) && $_POST['placeholder-body-prefix'][$count_body] !== '-1') {
                $cfg['body']['prefix'][(int)$count_body] = $_POST['placeholder-body-prefix'][$count_body];
            }
            if (!empty($_POST['placeholder-body'][$count_body]) && $_POST['placeholder-body'][$count_body] !== '-1') {
                $cfg['body']['field'][(int)$count_body] = $_POST['placeholder-body'][$count_body];
            } else {
                $error[] = 'Keine Daten festgelegt f�r "body" {{'.$count_body.'}}<br>';
            }
            $count_body--;
        }

        while ($count_button > 0) {
            if (!empty($_POST['placeholder-button-switch'][$count_button])) {
                switch ($_POST['placeholder-button-switch'][$count_button]) {
                    case 'stammdaten_id':
                        $cfg['button']['switch'][(int) $count_button] = 'stammdaten_id';
                        break;
                    case 'string':
                    default:
                        $cfg['button']['switch'][(int) $count_button] = 'string';
                }

                if (!empty($_POST['placeholder-button'][$count_button]) && $_POST['placeholder-button'][$count_button] !== '-1') {
                    $cfg['button']['field'][(int)$count_button] = $_POST['placeholder-button'][$count_button];
                } else {
                    $error[] = 'Keine Daten festgelegt f�r "buttons" {{'.$count_button.'}}<br>';
                }
            }

            $count_button--;
        }
    }
    if (empty($error)) {
        $config[$template] = $cfg;
        if (false === ($ret = MessengerPeopleV2::updateTemplates($config))) {
            //Can not save data
            $error[] = 'Daten k�nnen nicht gespeichert werden';
        }
    }
}
//re-read
$cfg = MessengerPeopleV2::getTemplatesCfg('templates','', $template);
//AzureApp::dd($cfg,'red', 'cfg re-read');
$i = 1;
?>
<style>
    .warning {
        border: 1px solid red !important;
    }
    .message-header-image {width:100%}
    .jss231 {
        color: #00a5f4;
        height: 34px;
        margin: 2px 0 0 2px;
        display: flex;
        padding: 0 16px;
        font-size: 14px;
        background: #fff;
        box-shadow: 0 1px 0.5px rgba(0, 0, 0, .15);
        align-items: center;
        line-height: 20px;
        white-space: pre-wrap;
        border-radius: 7.5px;
        justify-content: center;
    }
    *, ::before, ::after {
        box-sizing: inherit;
    }
    .jss224 {
        font-weight: bold;
        font-size: 8px;
    }
    .jss218::before {
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        content: '';
        opacity: 0.06;
        background-color: maroon;
    }
    .jss218 {
        padding: 16px;
        min-height: 100%;
        border-radius: 4px;
        background-color: #e5ddd5;
    }
    .jss1::before {
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        content: '';
        opacity: 0.06;
    }
    .jss1 {
        padding: 16px;
        min-height: 100%;
        border-radius: 4px;
    }
    jss4::after {
        top: 0;
        left: -12px;
        width: 12px;
        height: 19px;
        content: "";
        position: absolute;
        background-size: contain;
        background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAmCAYAAADeB1slAAABHUlEQVR4Ae3UAUTFUBTG8YooKzALC4KZAEOAJoCIAQIGhMBkiKAhwIIAswCIARAGMEiyBsSA4g6vaQ0as1nn8B6AJj4e9vEHOD/Y7srJ+cWoXNeV0jS9GobhiSqoT2r2R1+jjtNWi6K4G/6xUYCiKFt1XX/AANpmWZYvMIALw/ASCqiqKgshnmEAZ1nWYdu23zCA833fgQK0jSRJHmAAp+v6XlVVbzCAs237uO/7HwjAf/b8072GAItkWd7OsuwRBnCGYew3TfMOAzjHcU7pVgcDaGtRFN3CgMVTkud5AgM40zQPuq6bwQDO87wzKEBbj+P4HgZwmqbtCiFeYcD8aT+i+y0M4IIguIECkiTtQAH+AaEAtwzABEzABEzAL/1aF55kcmH1AAAAAElFTkSuQmCC);
        background-repeat: no-repeat;
        background-position: 50% 50%;
    }
    .jss4 {
        position: relative;
        word-wrap: break-word;
        box-shadow: 0 1px 0.5px rgba(0, 0, 0, .15);
        min-height: 50px;
        border-radius: 7.5px;
        border-top-left-radius: 7.5px;
        background-color: #fff;
    }
    .jss5 {
        color: #262626;
        font-size: 13.6px;
        line-height: 19px;
        word-wrap: break-word;
    }
    .jss4 {
        word-wrap: break-word;
    }
    .info-div {
        padding: 4px 8px;
        width:99%;
        margin-top: 4px;
    }
    .error {background-color: #fba1a1;}
    .success {background-color: #d1f4d1;}
</style>
<?php if (!empty($error)) : ?>
<br clear="both"><div class="info-div error">
    <span class="error"><?= _FEHLER_.': '.implode('<br>', $error) ?></span>
</div>
<?php endif; ?>
<?php if (!empty($success)) : ?>
    <br clear="both"><div class="info-div success">
        <span class="success"><?= implode('<br>', $success) ?></span>
    </div>
<?php endif; ?>
<table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
    <tr class="heading">
        <th class="small th" colspan="3">
            <?= _EINSTELLUNGEN_ ?> WhatsApp <?= _LEITFADEN_VORLAGE_.' '._STATUS_?>
            <?= link2(_AKTUALISIEREN_, $link.'&send=1') ?>
        </th>
    </tr>
    <tr class="<?= $i++ % 2 ? 'odd' : 'even' ?> first-child">
        <th class="th"><?= _LEITFADEN_VORLAGE_?> <?= $template ?></th>
        <td class="td" nowrap>
            <?php
            $places = $text = array();
            //AzureApp::dd($template_content, 'brown', '$template_content');

            if(!empty($template_content)) :?>
            <div class="jss1" style="width:500px;">
                <div title="<?= _VORSCHAU_ ?>" class="jss218">
                    <div><p class="jss224"><?= _VORSCHAU_ ?> / <?= _BSPRACHE_.' '.strtoupper($obj->moduleLanguage)?> / <b style="color: green"><?= MessengerPeopleV2_Template::$templateStatus[$template_content['status']]?></b></p>
                        <div class="jss4">
                            <div class="jss222"><?php
                                if ($image_form_required) {
                                    echo '<div class="jss5" style="margin-top: 5px;padding: 5px 10px;">
                                            <img src="'.(!empty($image) ? $image : $cfg_basedir.'img/no-image.png').'" class="message-header-image">
                                          </div>';
                                } elseif (!empty($template_content['header_text'])) {
                                    echo '<div class="jss5" style="margin-top: 25px;padding: 5px 10px;"><b>'.
                                        $template_content['header_text'].
                                        '</b></div>';
                                    $text['header'] = $template_content['header_text'];
                                    preg_match_all('/{{(\d+)}}/i', $text['header'], $m, PREG_PATTERN_ORDER);
                                    for ($i = 0; $i < count_p4n($m[1]); $i++) {
                                        if (!empty($m[1][$i])) {
                                            $places['header'][] = $m[1][$i];
                                        }
                                    }

                                }
                                if (!empty($template_content['body_text'])) {
                                    echo '<div class="jss5" style="padding: 5px 10px;">'.
                                        wordwrap($template_content['body_text'], 64, "<br />\n").
                                        '</div>';
                                    $text['body'] = $template_content['body_text'];
                                    preg_match_all('/{{(\d+)}}/i', $text['body'], $m, PREG_PATTERN_ORDER);
                                    for ($i = 0; $i < count_p4n($m[1]); $i++) {
                                        if (!empty($m[1][$i])) {
                                            $places['body'][] = $m[1][$i];
                                        }
                                    }
                                }
                                if (!empty($template_content['footer_text'])) {
                                    echo '<div class="jss5" style="margin-top: 25px;padding: 5px 10px;"><b>'.
                                        $template_content['footer_text'].
                                        '</div>';
                                }
                                ?>
                            </div>
                        </div>
                        <div><?php
                            if (!empty($template_content['buttons']) && is_array($template_content['buttons'])) {
                                foreach ($template_content['buttons'] as $id => $button) {
                                    if ($button['type'] === 'QUICK_REPLY') {
                                        echo '<div class="jss231"><div class="jss232"><span style="cursor: pointer !important;">'.$button['text'].'</div></div>';
                                    } elseif ($button['type'] === 'PHONE_NUMBER') {
                                        echo '<div class="jss231"><div class="jss232">'.$button['text'].
                                            ' '.oltext($button['phone_number'], '<img class="vmitte" src="bilder/overlib.gif">').
                                            '</div></div>';
                                    } elseif ($button['type'] === 'URL') {
                                        echo '<div class="jss231"><div class="jss232" style="text-align: center">'.
                                            link2($button['text'], $button['url'], '', '', 'target=_blank').
                                            ' '.oltext($button['url'], '<img class="vmitte" src="bilder/overlib.gif">').
                                            '</div></div>';
                                        preg_match_all('/{{(\d+)}}/i', $button['url'], $m, PREG_PATTERN_ORDER);
                                        for ($i = 0; $i < count_p4n($m[1]); $i++) {
                                            if (!empty($m[1][$i])) {
                                                $places['button'][$id] = $m[1][$i];
                                            }
                                        }
                                    }
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </td>
    <td class="td" nowrap>
        <?php
        if (count_p4n($places['header']) > 0 || count_p4n($places['body']) > 0 || count_p4n($button['url'])) {
            $form = new htmlform();
            $js = array();
            echo $form->start('template', $link, 'POST', false, 'id="template" onSubmit="P4nBoxHelper.startloading(true)"');
            //Replace template placeholders to
            echo 'Ersetzen Sie Vorlagenplatzhalter durch:  <br>';
            echo $form->hidden('template_name', $template);
            if ($image_form_required) {
                echo '<b>header image</b><br>{{image URL <small>(jpg/png)</small>}} -&gt; '.
                    $form->textinput(
                        'media_image',
                        (!empty($cfg['header']['field'][1]) ? $cfg['header']['field'][1] : ''),
                        30,
                        'data-position="header" data-num="1" class="mp-media-image"'
                    ).'<span style="color: red;font-size: 10px">*</span><br>';
            }
            foreach ($places as $position=>$items) {
                if(count_p4n($places[$position]) > 0) {
                    echo $form->hidden('count_replaces_'.$position, count_p4n($places[$position]), 'id="count-replaces-'.$position.'"');
                    echo '<b>'.$position.' text</b><br>';
                    foreach ($items as $key) {
                        $current = [];
                        $switch = $cfg[$position]['switch'][$key];
                        //AzureApp::dd($cfg[$position],'red');
                        if ($position === 'button') {
                            //AzureApp::dd($cfg[$position]['switch'][$key],'green');
                            if (!empty($switch) && isset($select_options_url_placeholder[$switch])) {
                                $current = $select_options_url_placeholder[$switch];
                            }
                            echo '{{'.$key.'}} -&gt; '.
                                $form->selectinput(
                                    'placeholder-'.$position.'-switch['.$key.']',
                                    $select_options_url_placeholder['switch'], !empty($cfg[$position]['switch'][$key]) ? $cfg[$position]['switch'][$key] : '', _BITTE_WAEHLEN_,
                                    ' id="switch-'.$position.'-'.$key.'" data-position="'.$position.'"  data-id="'.$key.'" class="button_on_change_trigger" '
                                );

                        } else {
                            if (!empty($switch) && isset($select_options[$switch])) {
                                $current = $select_options[$switch];
                            }
                            echo '{{'.$key.'}} -&gt; '.
                                $form->selectinput(
                                    'placeholder-'.$position.'-switch['.$key.']',
                                    $select_options['switch'], !empty($switch) ? $switch : '', _BITTE_WAEHLEN_,
                                    ' id="switch-'.$position.'-'.$key.'" data-position="'.$position.'"  data-id="'.$key.'" class="on_change_trigger" '
                                ).
                                '&nbsp;'.$form->selectinput(
                                    'placeholder-'.$position.'-prefix['.$key.']',
                                    $select_options['prefix'], !empty($cfg[$position]['prefix'][$key]) ? $cfg[$position]['prefix'][$key] : '', '',
                                    ' id="placeholder-'.$position.'-prefix'.$key.'" '.(($switch === 'name' && !empty($cfg[$position]['prefix'][$key])) ? '' : ' style="display:none" ')
                                );
                        }
                        echo '&nbsp;'.
                            $form->selectinput(
                                'placeholder-'.$position.'['.$key.']',
                                $current,
                                (isset($cfg[$position]['field'][$key]) ? $cfg[$position]['field'][$key] : ''),
                                _BITTE_WAEHLEN_,
                                ' required="required" id="placeholder-'.$position.'-'.$key.'"'
                            ).
                            '<span style="color: red;font-size: 10px">*</span><br>';
                        if (!empty($cfg[$position]['field'][$key])) {
                            $js[] = 'jq1112("#placeholder-'.$position.'-'.$key.'").val("'.$cfg[$position]['field'][$key].'").change();';
                        }
                    }
                }
            }
            echo '<br>'.$form->submit2('submit_placeholders', _SUBMIT_AP_, ' onClick="check_required()"; style="padding: 5px 15px"');
            $form->ende();
        }
//        echo '<pre style="color: #0A246A">';
//        print_r(json_encode($obj->getTemplatePayload('375296018682', $template, $obj->moduleLanguage)));
//        echo '</pre>';
//        echo '<pre style="color: #2a5006">';
//        //var_dump($obj->postTemplate());
//        echo '</pre>';
        ?>
    </td></tr>
</table>
<script type="application/javascript">
    let fieldOptions = {"time": {}, "date": {}, "name": {}, "datetime": {}, "string": {}, "stammdaten_id": {}}
    let buttonFieldOptions = {"stammdaten_id": {}, "string": {}}
    <?php
    foreach (array_keys($select_options['switch']) as $name) {
        foreach ($select_options[$name] as $k => $v) {
            echo 'fieldOptions.'.$name.'["'.$k.'"] = "'.$v.'";'."\n";
        }
    }
    foreach (['stammdaten_id', 'string'] as $name) {
        foreach ($select_options_url_placeholder[$name] as $k => $v) {
            echo 'buttonFieldOptions.'.$name.'["'.$k.'"] = "'.$v.'";'."\n";
        }
    }
    ?>

    let trigger = jq1112(".on_change_trigger");
    let for_button_trigger = jq1112(".button_on_change_trigger");

    jq1112(function () {

        <?php echo implode("\n", $js); ?>

        trigger.on('change', function () {
            let dataid = jq1112(this).data('id');
            let position = jq1112(this).data('position');
            console.log(position + dataid);

            let field_type = jq1112(this).val();

            jq1112("#placeholder-" + position + "-" + dataid).find('option').remove();
            if (typeof field_type !== typeof undefined && field_type !== '' && field_type !== '-1') {
                console.log(Object.entries(fieldOptions[field_type]));
                for (const [val, text] of Object.entries(fieldOptions[field_type])) {
                    jq1112("#placeholder-" + position + "-" + dataid).append(new Option(text, val));
                }
            }
            if (field_type === 'time' || field_type === 'date' || field_type === 'datetime' || field_type === 'string' || field_type === 'stammdaten_id') {
                jq1112("#placeholder-" + position + "-prefix" + dataid).hide();
            } else {
                jq1112("#placeholder-" + position + "-prefix" + dataid).show();
            }
        });

        for_button_trigger.on('change', function () {
            let dataid = jq1112(this).data('id');
            let position = jq1112(this).data('position');
            let field_type = jq1112(this).val();
            console.log(position + " " + dataid + " " + field_type);
            console.log(buttonFieldOptions);

            jq1112("#placeholder-" + position + "-" + dataid).find('option').remove();
            if (typeof field_type !== typeof undefined && field_type !== '' && field_type !== '-1') {
                console.log(Object.entries(buttonFieldOptions[field_type]));
                for (const [val, text] of Object.entries(buttonFieldOptions[field_type])) {
                    jq1112("#placeholder-" + position + "-" + dataid).append(new Option(text, val));
                }
            }
        });
    });

    function check_required() {

        // console.log(fieldOptions);
        let h_count = jq1112("#count-replaces-header").val();
        let b_count = jq1112("#count-replaces-body").val();
        let bp_count = jq1112("#count-replaces-button").val();
        console.log('h_count ' + h_count);
        console.log('b_count ' + b_count);
        let i = 1;
        let tmp = '';
        if (h_count > 0) {
            while (h_count > 0) {
                tmp = jq1112("#placeholder-header-" + i).find(":selected").val();
                console.log(" check switch-header-" + i);
                console.log(jq1112("#switch-header-" + i).val());
                console.log(" selected value = ");
                console.log(tmp);
                if (typeof tmp === "undefined" || tmp === '' || tmp === '-1') {
                // if (jq1112("#placeholder-header-" + i)[0].selectedIndex <= 0 && jq1112("#switch-header-" + i).val() !=='time') {
                    jq1112("#placeholder-header-" + i).addClass('warning');
                    console.log('return false');
                    return false;
                } else {
                    jq1112("#placeholder-header-" + i).removeClass('warning');
                }
                i++;
                h_count--;
            }
        }
        i = 1;
        if (b_count > 0) {
            while (b_count > 0) {
                tmp = jq1112("#placeholder-body-" + i).find(":selected").val();
                console.log(" check switch-body-" + i);
                console.log(jq1112("#switch-body-" + i).val());
                console.log(" selected value = ");
                console.log(tmp);
                if (typeof tmp === "undefined" || tmp === '' || tmp === '-1') {
                    jq1112("#placeholder-body-" + i).addClass('warning');
                    console.log('return false');
                    return false;
                } else {
                    jq1112("#placeholder-body-" + i).removeClass('warning');
                }
                i++;
                b_count--;
            }
        }
        i = 1;
        if (bp_count > 0) {
            while (bp_count > 0) {
                tmp = jq1112("#placeholder-button-" + i).find(":selected").val();
                console.log(" check switch-button-" + i);
                console.log(jq1112("#switch-button-" + i).val());
                console.log(" selected value = ");
                console.log(tmp);
                if (typeof tmp === "undefined" || tmp === '' || tmp === '-1') {
                    jq1112("#placeholder-button-" + i).addClass('warning');
                    console.log('return false');
                    return false;
                } else {
                    jq1112("#placeholder-button-" + i).removeClass('warning');
                }
                i++;
                bp_count--;
            }
        }
        console.log('submit');
        jq1112( "#template" ).submit();
    }
</script>