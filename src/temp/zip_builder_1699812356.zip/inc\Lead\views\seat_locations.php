<?php
if (substr($_SERVER["PHP_SELF"], -strlen('einstellungen_kfz.php')) !== 'einstellungen_kfz.php') {
    exit(_KEINRECHT_);
}
$params = SeatLeads::getParams();
if (isset($postfeld['submit_seat_locations'])) {
    $params['locations'] = array();
    foreach ($postfeld['active'] as $locationId => $ok) {
        $params['locations'][$locationId] = $postfeld['data'][$locationId];
    }
    SeatLeads::updateParams($params);
}
$locationList = array();
foreach (Location_Helper::instance()->getList() as $id => $title) {
    if (!strstr($title, 'OPTGROUP')) {
        $locationList[$id] = $title;
    }
}
$seatLocation = empty($params['locations']) ? array() : $params['locations'];
$form = new htmlform();
$i = 1;
?>
<style type="text/css">
    .error { background-color:#F2DEDE;color:#B94A48; }
</style>
<script type="text/javascript">
    function checkForm(requiredClass) {
        jq1112(".required").each(function() {
            jq1112(this).removeClass("error");
        });
        var ok = true;
        jq1112(".line").each(function() {
            var $active = jq1112(this).find(".active");
            if ($active.is(":checked")) {
                jq1112(this).find(".required").each(function() {
                    if (jq1112(this).val() == "") {
                        jq1112(this).addClass("error");
                        ok = false;
                    }
                });
            }
        });
        if (ok) {
            return confirm("<?= _ABFRAGE_SPEICHERN_ ?>");
        }
        return false;
    }
</script>
<?= $form->start('kia_locations_form', '', 'POST', false, '', $_SESSION['user_id'] != 1) ?>
<table class="table-ignore2 moderntable table-margin-bottom table-lasttd-w100">
    <tr class="heading">
        <th class="small th" colspan="3">Seat <?= _HAENDLER_.'-'._ZUORDNUNG_ ?></th>
    </tr>
    <tr class="first-child">
        <th class="th"><?= _AKTIV_ ?></th>
        <th class="th"><?= _LAGERORT_ ?></th>
        <th class="th"><?= _HAENDLER_NR_ ?></th>
    </tr>
    <?php foreach($locationList as $locationId => $locationTitle):?>
        <tr class="line <?= $i++ % 2 ? 'odd' : 'even' ?>">
            <td class="td"><?= $form->checkinput('active['.$locationId.']', isset($seatLocation[$locationId]), 'class="active"') ?></td>
            <td class="td" nowrap><?= $locationTitle ?></td>
            <td class="td"><?= $form->textinput('data['.$locationId.']', @$seatLocation[$locationId], '', 'class="required"') ?></td>
        </tr>
    <?php endforeach; ?>
</table>
<?= $form->submit('submit_seat_locations', _SUBMIT_STAMMDATEN_, 'onClick="return checkForm()"') ?>
<?= $form->ende() ?>