<?php
/**
 * API class
 * MessengerPeopleV2 service implementation
 * https://api.messengerpeople.dev/docs/
 *
 * @author Alexander Yurkovets <alexander.yurkovets@prof4.net>
 * 28.11.2022
 */

class MessengerPeopleV2_Api extends BaseRest {

    protected $urlAuth;
    protected $logging = false;
    public $channels = array();
    public $token;
    public $url;
    public $auth;
    public $expires_in;
    public $account;
    public $error;
    public $errorCode;

    /**
     * MessengerPeopleV2_Api constructor.
     *
     * @param array $cfg
     *
     * @throws Exception
     */
    public function __construct($cfg = array()) {

        if (empty($cfg['url'])) {
            throw new Exception('Please add URL value to the config B');
        }
        if (empty($cfg['urlAuth'])) {
            throw new Exception('Please add UrlAuth value to the config');
        }
        if (empty($cfg['channels'])) {
            throw new Exception('Channels UUIDs error');
        }
        $this->url = $cfg['url'];
        // $this->channels[$messenger]['recipient num'] = array('recipient'=>'', 'uuid'=>'', 'language'=>'', 'location'=>'')
        $this->channels = $cfg['channels'];//todo - maybe not need - remove?
        $this->urlAuth = $cfg['urlAuth'];
        $this->account = $cfg;
        $params = array(
            'responseHeader' => true,
            'verifyCert' => false,
            'checkStatus' => true,
            'authHeader' => array(
                'Content-Type: application/vnd.messengerpeople.v2+json',
                'Accept: application/vnd.messengerpeople.v2+json',
                'cache-control: no-cache'
            )
        );
        $this->postFormat = 'json';
        parent::__construct($this->url, $params);
        if (!empty($cfg['logging'])) {
            $this->logging = true;
            $this->enableLog();
        }
    }

    /**
     * add bearer authorization to header
     */
    protected function add_bearer_authorization() {
        if (!in_array('Authorization: Bearer '.$this->token, $this->header)) {
            $this->header[] = 'Authorization: Bearer '.$this->token;
        }
    }

    /**
     * save Token In session
     */
    function saveTokenInSession() {
        $s = MessengerPeople::CONFIG_MODULE;
        $_SESSION[$s]['token'] = $this->token;
        $_SESSION[$s]['expires_in'] = $this->expires_in;
    }

    /**
     * get Token from Session if exist and not expired
     */
    function checkTokenInSession() {
        $s = MessengerPeople::CONFIG_MODULE;
        if (isset($_SESSION[$s]) && is_array($_SESSION[$s]) && !empty($_SESSION[$s]['token'])
            && !empty($_SESSION[$s]['expires_in']) && $_SESSION[$s]['expires_in'] > time()
        ) {
            // echo 'get from session';
            $this->token = $_SESSION[$s]['token'];
            $this->expires_in = $_SESSION[$s]['expires_in'];
        } else {
            // echo ' empty on session';
            $this->token = '';
            $this->expires_in = '';
        }
    }


    /**
     * Init Auth
     *
     * @return MessengerPeople_Auth
     */
    public function auth() {
        if (empty($this->auth)) {
            $this->auth = new MessengerPeople_Auth($this->urlAuth, array(
                'account' => $this->account,
                'verifyCert' => false,
                'checkStatus' => true,
                'logging' => $this->logging,
                'authHeader' => array(
                    'Content-Type: application/x-www-form-urlencoded',
                    'Accept: application/vnd.messengerpeople.v2+json',
                    'cache-control: no-cache'
                )
            ));
        }

        return $this->auth;
    }

    /**
     * get token
     *
     * @return bool
     * @throws Exception
     */
    public function getToken() {
        $this->checkTokenInSession();
        //        echo ' current token:'.$this->token."<br>\n";
        if (!isset($this->token) || empty($this->token) || $this->expires_in <= time()) {
            if (false !== ($data = $this->auth()->login()) && !empty($data['access_token'])) {
                $this->expires_in = time() + $data['expires_in'];
                $this->token = $data['access_token'];
                $this->saveTokenInSession();
                //echo ' new token:'.$this->token."<br>\n";
                //echo ' new expires_in:'.date('Y-m-d H:i:s',$this->expires_in)."<br>\n";
                return true;
            } else {
                $this->expires_in = '';
                $this->token = '';
                $this->saveTokenInSession();
                $this->error = 'Authentication error (get token): ('.print_r($data, true).')';
                throw new Exception($this->error);
            }
        }

        return true;
    }

    /**
     * Authorize
     *
     * @throws Exception
     */
    public function authorize() {
        $this->getToken();
        $this->add_bearer_authorization();
    }

    /** Get List Messages
     * @param string $sort
     * @param string $filter
     *
     * @return array|false
     * @throws Exception
     */
    public function mpGetListMessages($sort, $filter) {
        $q = array();
        if (!empty($sort)) {
            $q[] = 'sort='.urlencode($sort);
        }
        if (!empty($filter)) {
            $q[] = 'filter='.$filter;
        }
        $func = 'messages'.(!empty($q) ? '?'.implode('&', $q) : '');
        $this->error = null;
        $this->errorCode = null;
        $response = $this->preGet($func);
        return $response; // data bits
    }

    /** delete template by uuid
     *
     * @param $uuid
     *
     * @return string
     * @throws Exception
     */
    public function deleteTemplate($uuid) {
        $this->error = null;
        $this->errorCode = null;
        $this->authorize();
        $func = 'templates/'.$uuid;
        if ($this->logEnabled) {
            $this->requestFunc = $this->getFuncFromUrl($func).'_delete';
        }
        $response = $this->delete($this->url.'/'.$func);
        return $this->parseResponse($response);
    }

    /** get all templates via api
     * @return array|false
     * @throws Exception
     */
    public function getTemplates() {
        $this->error = null;
        $this->errorCode = null;
        $response = $this->preGet('templates');
        return $response; // data bits
    }

    /** get languages via api
     * @return array|false
     * @throws Exception
     */
    public function getTemplatesLanguages() {
        $this->error = null;
        $this->errorCode = null;
        $response = $this->preGet('templates/languages');
        return $response; // data bits
    }

    /** get Categories via api
     * @return array|false
     * @throws Exception
     */
    public function getTemplateCategories() {
        $this->error = null;
        $this->errorCode = null;
        $response = $this->preGet('templates/categories');
        return $response; // data bits
    }

    /** get Message via api
     * @return array|false
     * @throws Exception
     */
    public function getMessage($uuid) {
        $this->error = null;
        $this->errorCode = null;
        $data = $this->preGetRaw('messages/'.$uuid);
        if (!empty($data)) {
            $data = json_decode($data, true);
            if (is_array($data)) {
                $data = json_decode_utf8($data);
                //error from MessengerPeople?
                if (isset($data['error'])) {
                    $this->error = $data['error'];
                    $this->errorCode = $data['errorCode'];
                    return false;
                }
                //error status from FaceBook? (via MP)
                if (isset($data['statuscode']) && $data['statuscode'] >= 400) {
                    $this->error = $data['statuscode'];
                    $this->errorCode = $data['statuscode'];

                    if (!empty($data['result']['title'])) {
                        $this->error = $data['result']['title'];
                    } elseif (!empty($data['result'])) {
                        $this->parseExtErr($data['result']);
                    }

                    return false;
                }


                return $data;
            }
        }

        return false;
    }

    /** analyze string & try extract error message & code
     * @param string $s
     *
     * @return void
     */
    public function parseExtErr($s) {
    //'{\"status\":400,\"type\":\"ResponseErrorException\",\"error\":\"\\\"{\\\\\\\"meta\\\\\\\":{\\\\\\\"api_status\\\\\\\":\\\\\\\"stable\\\\\\\",\\\\\\\"version\\\\\\\":\\\\\\\"2.49.3\\\\\\\"},\\\\\\\"errors\\\\\\\":[{\\\\\\\"code\\\\\\\":2060,\\\\\\\"title\\\\\\\":\\\\\\\"Template message dropped\\\\\\\",\\\\\\\"details\\\\\\\":\\\\\\\"Message has been dropped. Reason unknown\\\\\\\"}]}\\\"\",\"details\":\"{\\\"meta\\\":{\\\"api_status\\\":\\\"stable\\\",\\\"version\\\":\\\"2.49.3\\\"},\\\"errors\\\":[{\\\"code\\\":2060,\\\"title\\\":\\\"Template message dropped\\\",\\\"details\\\":\\\"Message has been dropped. Reason unknown\\\"}]}\"}';
        $s = preg_replace('#\\\+#i', '', $s);
        $str = preg_replace('/"/i', '', $s);
        preg_match('#errors:\[\{([^}]+)#i', $str, $m);
        $tmp = @json_decode($s, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            if (!empty($s['errors'][0]['title'])) {
                $this->error = $tmp['errors'][0]['title'];
            }
        } elseif (!empty($m[1])) {
            $tmp = explode(',', $m[1]);
            foreach ($tmp as $s) {
                preg_match('#^details:(.+)#i', $s, $m);
                if (!empty($m[1])) {
                    $this->error = $m[1];
                }
                preg_match('#^code:(.+)#i', $s, $m);
                if (!empty($m[1])) {
                    $this->errorCode = $m[1];
                }
            }
        } else {
            //{"code":1006,"title":"Failed to find media file for id 110b15e6-effa-40d7-be01-23e94359bb96"...
            //HTTP ERROR: {"error":"Invalid parameter: \"{\\\"error\\\":{\\\"message\\\":\\\"Invalid parameter\\\",\\\"type\\\":\\\"OAuthException\\\",\\\"code\\\":100,\\\"error_subcode\\\":2388023,\\\"is_transient\\\":false,\\\"error_user_title\\\":\\\"Message template language is being deleted\\\",\\\"error_user_msg\\\":\\\"New German content can't be added while the existing German content is being deleted. Try again in 4 weeks or consider creating a new message template.\\\",\\\"fbtrace_id\\\":\\\"As8WsGmYLpXgNY4mwu_aQ57\\\"}}\"","hint":"As8WsGmYLpXgNY4mwu_aQ57"}
            $this->error = $str;
            $err = [];
            $s = preg_replace('#\\\+#i', '', $s);
            $str = preg_replace('/^HTTP ERROR:[^{]*/i', '', $s);
            preg_match('#error_user_title":"([^\"]+)"#i', $str, $m);
            if (!empty($m[1])) {
                $err[] = $m[1];
            }
            preg_match('#error_user_msg":"([^\"]+)"#i', $str, $m);
            if (!empty($m[1])) {
                $err[] = $m[1];
            }
            preg_match('#{"code":\s*(\d+),"title":"([^\"]+)"#i', $s, $m);
            if (!empty($m[1])) {
                $this->errorCode = $m[1];
            }
            if (!empty($m[2])) {
                $err[] = $m[2];
            }
            if (!empty($err)) {
                $this->error = implode(' ', $err);
            }
        }
    }

    /** check Available template name via api
     * @param string $name
     *
     * @return bool
     * @throws Exception
     */
    public function checkAvailable($name) {
        $this->error = null;
        $this->errorCode = null;
        $data = $this->preGetRaw('templates/is-name-available?name='.$name);
        if (!empty($data)) {
            $data = json_decode($data, true);
            if (is_array($data)) {
                $data = json_decode_utf8($data);
                if (isset($data['error']) && isset($data['hint'])) {
                    $this->error = $data['error'].' '.$data['hint'];
                    $this->errorCode = '400';
                    return false;
                }
                if (isset($data['error'])) {
                    $this->error = $data['error'];
                    $this->errorCode = $data['errorCode'];
                }
            }
            return false;
        }
        //is ok
        return true;
    }

    /** create template via api
     * @param array $data
     *
     * @return array|false
     * @throws Exception
     */
    public function postTemplate(array $data) {
        $this->error = $this->errorCode = '';
        try {
            $response = $this->prePost($data, 'templates');
            if (!empty($this->error)) {
                return array('success' => false, 'error' => true, 'message' => $this->error);
            }
            if (false === $response) {
                return array('success' => false, 'error' => true, 'message' => 'Unknown error');
            }
            return array(
                'success' => true,
                'data' => $response,
                'uuid' => $response['uuid'],
                'message' => 'Successfully send'
            );

        } catch (Exception $e) {
            $this->parseExtErr($e->getMessage());
            return false;
        }
    }

    /** Send Message
     * @param array $data
     *
     * @return array|false
     * @throws Exception
     */
    public function mpSendMessages(array $data) {
        // $log = 'TEXT: '.$data['payload']['text']."\r\n";
        // $log.= 'ENCODE: '.(MessengerPeople::is_utf8_p4n($data['payload']['text'])?'UTF8':'NOT UTF')."\r\n";
        // Logger_File::instance()->setFilePath('log/MessengerPeople_ENCODE.txt');
        // Logger_File::instance()->info($log);
        $response = $this->prePost($data, 'messages');
        return $response;
    }

    /**
     * combine raw & parse
     *
     * @param $func
     *
     * @return array|false
     * @throws Exception
     */
    protected function preGet($func) {
        $response = $this->preGetRaw($func);

        return $this->parseResponse($response);
    }

    /**
     * Get raw data bits
     *
     * @param $func
     *
     * @return string
     * @throws Exception
     */
    protected function preGetRaw($func) {
        $this->authorize();
        if ($this->logEnabled) {
            $this->requestFunc = $this->getFuncFromUrl($func).'_get';
        }

        return $this->get($this->url.'/'.$func);
    }

    /**
     * prepare post api method and get result
     *
     * @param $data
     * @param string $func
     *
     * @return array|false
     * @throws Exception
     */
    protected function prePost($data, $func) {
        $this->authorize();
        if ($this->logEnabled) {
            $this->requestFunc = $this->getFuncFromUrl($func).'_post';
            $this->requestData = json_encode($data);
        }
        $response = $this->post($data, $this->url.'/'.$func);

        return $this->parseResponse($response);
    }

    /**
     * parse Response
     *
     * @param string $response
     *
     * @return array|false
     * @throws Exception
     */
    protected function parseResponse($response) {
        // emoji chars in utf "*#0123456789" to html
        //$response = preg_replace('/\\\ufe0f\\\u20e3/i', '&#xfe0f;&#x20e3;', $response);
        //mark for me:  before json_decode.
        $response = MessengerPeopleV2_Survey::utf8EmojiCharsToHtmlEntities($response);
        $data = json_decode($response, true);
        if (is_array($data)) {
            $data = json_decode_utf8($data);
            if (isset($data['errorCode']) && isset($data['message'])) {
                $this->error = $data['message'];
                $this->errorCode = $data['errorCode'];
                return false;
            }
            if (isset($data['error']) && isset($data['hint'])) {
                $this->error = $data['error'].' '.$data['hint'];
                $this->errorCode = '400'; //Bad Request
                return false;
            }
            // Response:
            // {"error":"Something went wrong"}
            if (isset($data['error'])) {
                $this->error = $data['error'];
                $this->errorCode = '400'; //Bad Request
                return false;
            }

            return $data;
        }
        throw new Exception('Error parseResponse:. '.$response);
    }

    /**
     * @param string $aID
     *
     * @return string
     * @throws Exception
     */
    public function downloadAttachmet($aID) {
        $this->responseHeader = true;
        $func = 'media/'.$aID.'/download';
        $this->error = null;
        $this->errorCode = null;
        $response = $this->preGetRaw($func);
        return $response;
    }

    /** Send File
     * @param $binary
     * @param string $type
     *
     * @return array|false
     * @throws Exception
     */
    public function sendFile($binary, $type) {
        if (empty($binary)) {
            throw new Exception('Empty binary data');
        }
        if (empty($type)) {
            throw new Exception('Empty mime type');
        }
        $old = $this->header;
        // Logger_File::instance()->setFilePath('log/whatsapp.txt');
        // Logger_File::instance()->info(print_r($old,true));
        $this->header = array_diff($this->header, array('Content-Type: application/vnd.messengerpeople.v2+json'));
        $this->header[] = 'Content-Type: '.$type;
        $this->postFormat = '';
        $this->error = null;
        $this->errorCode = null;
        $response = $this->prePost($binary, 'media');
        // restore
        // Logger_File::instance()->info(print_r($this->header,true));
        $this->header = $old;
        // Logger_File::instance()->info(print_r($this->header,true));
        $this->postFormat = 'json';
        return $response;
    }

    /** post media
     * @param $binary
     *
     * @return array|false
     * @throws Exception
     */
    public function sendMediaFile($binary) {
        if (empty($binary)) {
            throw new Exception('Empty binary data');
        }
        $old = $this->header;
        // Logger_File::instance()->setFilePath('log/whatsapp.txt');
        // Logger_File::instance()->info(print_r($old,true));
        $this->header = array_diff($this->header, array('Content-Type: application/vnd.messengerpeople.v2+json'));
        $this->postFormat = '';
        $this->error = null;
        $this->errorCode = null;
        $response = $this->prePost($binary, 'media/fb-filehandle');
        // restore
        $this->header = $old;
        $this->postFormat = 'json';
        return $response;
    }

}