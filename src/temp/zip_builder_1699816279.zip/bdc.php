<?php
@session_start();

if (isset($_GET['design70-bdc-bm-mail']) && !isset($_POST['submit_req'])) {
    $noauth = true;
    $_SESSION['design_70'] = true;
    if (!isset($_GET['singlesite'])) {
        $singlesite = true;
        $_SESSION['temp_startseite'] = $_SESSION['startseite'];
        $_SESSION['startseite'] = $_SERVER['REQUEST_URI'].'&singlesite=1';
        $_SESSION['user_id'] = 1;
        include('start.php');
        unset($_SESSION['user_id']);
        exit;
    }
}

if (isset($_POST['action']) && $_POST['action']==='configure_required_fields') {
    include_once('inc/session.php');
    if (isset($_POST['fields']) && is_array($_POST['fields'])) {
        $alle_pflichtfelder=array();
        foreach ($_POST['fields'] as $fieldName => $fieldValue) {
            if ($fieldValue==1) {
                $alle_pflichtfelder[]=$fieldName;
            }
        }
        $result_einstellungen = $db->select(
            $sql_tab['einstellungen'],
            $sql_tabs['einstellungen']['einstellungen_id'],
            $sql_tabs['einstellungen']['modul'].'='.$db->str('bdc_pflichtfelder')
        );

        if ($row_einstellungen = $db->zeile($result_einstellungen)) {
            $db->update(
                $sql_tab['einstellungen'],
                array(
                    $sql_tabs['einstellungen']['wert'] => $db->str(base64_encode(serialize($alle_pflichtfelder)))
                ),
                $sql_tabs['einstellungen']['einstellungen_id'].'='.$db->dbzahl($row_einstellungen[0])
            );
        } else {
            $db->insert(
                $sql_tab['einstellungen'],
                array(
                    $sql_tabs['einstellungen']['wert'] => $db->str(base64_encode(serialize($alle_pflichtfelder))),
                    $sql_tabs['einstellungen']['modul'] => $db->str('bdc_pflichtfelder')
                )
            );
        }
    }
    exit;
}



$user_id = intval($_SESSION['user_id']);
$usergruppe = $_SESSION['user_gruppe'];
if (isset($_GET['req'])) {
    $daten1=base64_decode($_GET['req']);
    $xpl1=explode('_', $daten1);
    $bdcid=$xpl1[0];
    ob_start();
    include('inc/typen.inc.php');
    include('inc/db.inc.php');
    
    if ($user_id>0) {
        $res = $db->select(
            $sql_tab['benutzer'], 
            array(
                $sql_tabs['benutzer']['stil'],
                $sql_tabs['benutzer']['sprache'],
                $sql_tabs['benutzer']['gruppe']
            ),
            $sql_tabs['benutzer']['benutzer_id'].' = '.$db->dbzahl($user_id)
        );
        if ($row = $db->zeile($res)) {
            $usergruppe = $row[2];
            $_SESSION['stil'] = $row[0];
            if ($_SESSION['db_utf8'] and is_file("inc/" . str_replace('.php', '_utf8.php', $row[1]))) {
                include_once("inc/" . str_replace('.php', '_utf8.php', $row[1]));
            } else {
                include_once("inc/" . $row[1]);
            }
        } else {
            include_once("inc/lang_de.php");
        }
    } else {
        include_once("inc/lang_de.php");
    }
    
    include('inc/typen.inc.php');
    if (is_file('kundeninc.php')) {
        include('kundeninc.php');
    }
    
    if (isset($_GET['bdcuid']) && intval(base64_decode($_GET['bdcuid']))>0) {
        $user_id=base64_decode($_GET['bdcuid']);
    } elseif ($xpl1[1] > 0) {
        $user_id=$xpl1[1];
    }

    $is_lead=false;
    if ($xpl1[3] > 0) {
        if (!$cfg_bdc_lead_bearbeitung) {
            echo 'Leadbearbeitung ist nicht aktiv.';
            exit;
        }
        $is_lead=true;
        $bdcid=$xpl1[3];
        $alle_bmadr=explode(';',base64_decode($_GET['mail_adressen']));
    }
    include('inc/output.php');
    debug_logging('POST Vars.: '.print_r($_POST,true));
    $postfeld=$_POST;
    $getfeld=$_GET;
    $files=$_FILES;

    Modern_Helper_Request::requestStart();
    Modern_Helper_Encoding::getHeader();
    $bdc_einstellungen=getBdcEinstellungen();
    if (!$is_lead) {
        $ist_bm_verant=false;
        if (defined('_BM_VERANTWORTLICHER_')) {
            $groupname = $db->str(_BM_VERANTWORTLICHER_);
        }
        else {
            $groupname = $db->str('BM-Verantwortlicher');
        }
        $res=$db->select(
            $sql_tab['benutzer_gruppe'],
            $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
            $sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$groupname
        );
        if ($row=$db->zeile($res)) {
            $res=$db->select(
                $sql_tab['benutzer_gruppe_zuordnung'],
                $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'],
                $sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row[0]).' and '.
                    $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'].'='.$db->dbzahl($user_id)
            );
            if ($db->anzahl($res)>0) {
                $ist_bm_verant=true;
            }
        }

        $bm_editor=false;
        if (isset($_GET['bdcfr'])) {
            if (base64_decode($_GET['bdcfr'])=='true') {
                $bm_editor=true;
            }
        }

        if (!$bm_editor) {
            $arr_bearb=array('BM-Bearbeiter', 'Complaint Editor');
            if (isset($lang['_BM_BEARBEITER_'])) {
                $arr_bearb[]=_BM_BEARBEITER_;
            }
            $res=$db->select(
                $sql_tab['benutzer_gruppe'],
                $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
                $db->dbstrin($arr_bearb, $sql_tabs['benutzer_gruppe']['bezeichnung'])
            );

            while ($row=$db->zeile($res)) {
                $res=$db->select(
                    $sql_tab['benutzer_gruppe_zuordnung'],
                    $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'],
                    $sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row[0]).' and '.
                        $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'].'='.$db->dbzahl($user_id)
                );
                if ($db->anzahl($res)>0) {
                    $bm_editor=true;
                }
            }
        }
        $darf_schliessen=false; // Jeder darf generell nicht schlie�en
        $darf_schliessen_anfrage=false;
        $schliessgruppe_bm_existiert=false;
        $schliessgruppe_anfrage_existiert=false;
        if (isset($cfg_bm_schliessbeschwerde) && $user_id > 0) {
            $res=$db->select(
                $sql_tab['benutzer_gruppe'],
                $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
                $sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str($cfg_bm_schliessbeschwerde)
            );
            if ($row=$db->zeile($res)) {
                $schliessgruppe_bm_existiert=true;
                $res=$db->select(
                    $sql_tab['benutzer_gruppe_zuordnung'],
                    $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'],
                    $sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row[0]).' and '.
                        $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'].'='.$db->dbzahl($user_id)
                );
                if ($db->anzahl($res)>0) {
                    $darf_schliessen=true;
                }
            }

        }

        if (isset($cfg_bm_schliessanfrage) && $user_id > 0) {
            $res=$db->select(
                $sql_tab['benutzer_gruppe'],
                $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
                $sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str($cfg_bm_schliessanfrage)
            );
            if ($row=$db->zeile($res)) {
                $schliessgruppe_anfrage_existiert=true;
                $res=$db->select(
                    $sql_tab['benutzer_gruppe_zuordnung'],
                    $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'],
                    $sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row[0]).' and '.
                        $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'].'='.$db->dbzahl($user_id)
                );
                if ($db->anzahl($res)>0) {
                    $darf_schliessen_anfrage=true;
                }
            }
        }
    }
    $lead_tracking_prozess=false;
    if (!$is_lead) {
        $statusfeld[1]=_BM_STATUS1_;
        $statusfeld[2]=_BM_STATUS2_;
        $statusfeld[3]=_BM_STATUS3_;
        $statusfeld[4]=_BM_STATUS4_;
        
        if (isset($cfg_beschwerde_statusfeld2)) {
            if (is_array($cfg_beschwerde_statusfeld2)) {
                if (count($cfg_beschwerde_statusfeld2)>1) {
                    $statusfeld=$cfg_beschwerde_statusfeld2;
                }
            }
        }
    
    } else {
        $statusfeld=array(2 => _NICHTERREICHT_, 4 => _BM_STATUS3_, 5 => _BM_STATUS4_);
        //$statusfeld=array(0 => _NEU_, 1 => _BM_STATUS3_, 2 => _BM_STATUS2_, 3 => _OFFEN_, 4 => _KONTAKTIERT_, 5 => _BM_STATUS4_, 99 => _NICHT_ABGESCHLOSSEN_);
        if (isset($postfeld['status_phasen'])) {
            $postfeld['status']=4;
            $statusfeld[4]=$postfeld['status_phasen'];
            $lead_tracking_prozess=true;
        }
        
    }
    
    kopf();
    if (!isset($_SESSION['design_70'])) {
        echo css_kopf('BDC '._ANTWORT_);
    }

    if (isset($postfeld['submit_req'])) {
        debug_logging('Post in bdc.php @submit_req: '.print_r($_POST,true));
        $res=$db->select(
            $sql_tab['benutzer'],
            $sql_tabs['benutzer']['gruppe'],
            $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($user_id)
        );
        if ($row=$db->zeile($res)) {
            $bgrp=$row[0];
        }

        if (!$is_lead) {
            $res=$db->select(
            $sql_tab['troubleticket'],
            array(
                $sql_tabs['troubleticket']['betreff'],//0
                $sql_tabs['troubleticket']['beschreibung'],//1
                $sql_tabs['troubleticket']['stammdaten_id'],//2
                $sql_tabs['troubleticket']['status'],//3
                $sql_tabs['troubleticket']['ansprechpartner_id'],//4
                $sql_tabs['troubleticket']['benutzer_id'],		// 5
                $sql_tabs['troubleticket']['anweisung'],//6
                $sql_tabs['troubleticket']['protokoll'],//7
                $sql_tabs['troubleticket']['beschwerdezeit'],//8
                $sql_tabs['troubleticket']['beschwerdezeit_ende'],//9
                $sql_tabs['troubleticket']['datum'],//10   
                $sql_tabs['troubleticket']['datum_status1'],//11
                $sql_tabs['troubleticket']['datum_status2'],//12
                $sql_tabs['troubleticket']['datum_status3'],//13
                $sql_tabs['troubleticket']['datum_status4'],//14
                $sql_tabs['troubleticket']['verursacher_id'],//15
                $sql_tabs['troubleticket']['art2'],//16
                $sql_tabs['troubleticket']['ersteller_id'],//17
                $sql_tabs['troubleticket']['history']//18
            ),
            $sql_tabs['troubleticket']['troubleticket_id'].'='.$db->dbzahl($bdcid)
            );
            if ($row=$db->zeile($res)) {
                
                if ($row[3]!=$postfeld['status']) {
                    if ($row[18]!='') {
                          $alt_history = unserialize($row[18]);
                    } else {
                        $alt_history = array();
                    }

                    $alt_history[]=array(
                        'time' => adodb_date('d.m.Y H:i'),
                        'user' => $_SESSION['user_id'],
                        'status' => $postfeld['status']
                    );
                    $sqlt[$sql_tabs['troubleticket']['history']] = $db->str(serialize($alt_history));
                }
                
                if ($postfeld['status']!=4) {
                    $sqlt[$sql_tabs['troubleticket']['beschwerdezeit_minuten']]=$db->dbzahl(0);
                }
                if (($postfeld['status']=='4' || $postfeld['status']==4) and $row[3]!='4' && $row[3]!=4) {
                    $b_start=$db->unixdate_ts($row[8]);
                    $b_ende=time();
                    $mins=intval(($b_ende-$b_start)/60);
                    $sqlt[$sql_tabs['troubleticket']['datum_status4']]=$db->dbtimestamp($b_ende);
                    $sqlt[$sql_tabs['troubleticket']['beschwerdezeit_ende']]=$db->dbtimestamp($b_ende);
                    $sqlt[$sql_tabs['troubleticket']['beschwerdezeit_minuten']]=$db->dbzahl($mins);
                }
                
                $sqlt[$sql_tabs['troubleticket']['status']]=$db->str($postfeld['status']);
                if (isset($sql_tabs['troubleticket']['mitarbeiter_status'.$postfeld['status']])) {
                    $sqlt[$sql_tabs['troubleticket']['mitarbeiter_status'.$postfeld['status']]]=$db->dbzahl($user_id);

                    $status_zus='';
                    //if ($_SESSION['crm_version']>61) {
                        if (!empty($row[11]) && ($postfeld['status']=='1' || $postfeld['status']==1)) {
                            $status_zus=$row[11];
                        } else if (!empty($row[10]) && ($postfeld['status']=='1' || $postfeld['status']==1)) {
                            $status_zus=$row[10];
                        }
                        if (!empty($row[12]) && ($postfeld['status']=='2' || $postfeld['status']==2)) {
                            $status_zus=$row[12];
                        }
                        if (!empty($row[13]) && ($postfeld['status']=='3' || $postfeld['status']==3)) {
                            $status_zus=$row[13];
                        }
                        if (!empty($row[14]) && ($postfeld['status']=='4' || $postfeld['status']==4)) {
                            $status_zus=$row[14];
                        }
                    //}
                    if ($status_zus=='') {
                        $status_zus=time();
                    }
                    $sqlt[$sql_tabs['troubleticket']['datum_status'.$postfeld['status']]]=$db->dbtimestamp($status_zus);
                }

                if ($postfeld['absender']!='') {
                    echo javas('StorageHelper.set("bdc_req_absender","'.$postfeld['absender'].'");');
                }

                
                
                
                $alle_bmadr2=array();
               
                    
                $proto_mail='';
                $res_b=$db->select(
                    $sql_tab['benutzer'],
                    array(
                        $sql_tabs['benutzer']['email'],
                        $sql_tabs['benutzer']['benutzer_id']
                    ),
                    $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row[5]).' OR '.$sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($row[17])
                );
                while ($row_b=$db->zeile($res_b)) {

                    if ($row_b[0]!='' && !in_array($row_b[0],$alle_bmadr2)) {
                        if (isset($postfeld['email_verantwortlicher']) && $row_b[1]==$row[5]) {
                            $alle_bmadr2[]=$row_b[0];
                            $proto_mail.=$row_b[0].', ';
                        }
                        if (isset($postfeld['email_ersteller']) && $row_b[1]==$row[17]) {
                            $alle_bmadr2[]=$row_b[0];
                            $proto_mail.=$row_b[0].', ';
                        }
                    }
                }

                $sqlt[$sql_tabs['troubleticket']['antwort']]=$db->str($postfeld['antwort']);
                $sqlt[$sql_tabs['troubleticket']['protokoll']]=$db->str(adodb_date('d.m.Y, H:i:s').' '.(isset($postfeld['absender']) && $postfeld['absender']!=''?$postfeld['absender']:$_SESSION['mitarbeiter_name2']).":\n\n".$postfeld['antwort'].(($proto_mail!='')?"\n"._EMAIL_.': '.p4n_mb_string('substr',$proto_mail, 0, -2):'')."\n\n".$row[7]);
                $sqlt[$sql_tabs['troubleticket']['letzte_aenderung']]=$db->dbtimestamp(time());
                $db->update(
                    $sql_tab['troubleticket'],
                    $sqlt,
                    $sql_tabs['troubleticket']['troubleticket_id'].'='.$db->dbzahl($bdcid)
                );
                
                if ($_SESSION['crm_version']>65 && (isset($postfeld['email_ersteller']) || isset($postfeld['email_verantwortlicher']))) {
                    if (count($alle_bmadr2)>0) {
                        include_once("inc/lib_htmledit.php");
                        include_once('inc/class_bdc_email.php');

                        $htmleditor = new HTMLEditor();

                        if ($row[16]=='Anfrage') {
                            if (intval($bdc_einstellungen['vorlage1'])>0) {
                                $mail = $htmleditor->prepare_mail($bdc_einstellungen['vorlage1']);
                            } else {
                                $mail=$htmleditor->prepare_utf8_html_mail('template/bdc/anfrage'.($cfg_bdc_nl?'_nl':(p4n_mb_string('substr',$_SESSION['cfg_kunde'], 0, p4n_mb_string('strlen','carlo_opel_avag'))=='carlo_opel_avag' ? '_avag':'')).'.html');
                            }
                        } else {
                            if (intval($bdc_einstellungen['vorlage2'])>0) {
                                $mail = $htmleditor->prepare_mail($bdc_einstellungen['vorlage2']);
                            } elseif (isset($_SESSION['design_70'])) {
                                $mail = $htmleditor->prepare_utf8_html_mail('template/bdc/beschwerde_70.html', false);
                            } else {
                                $mail=$htmleditor->prepare_utf8_html_mail('template/bdc/beschwerde'.($cfg_bdc_nl?'_nl':(p4n_mb_string('substr',$_SESSION['cfg_kunde'], 0, p4n_mb_string('strlen','carlo_opel_avag'))=='carlo_opel_avag' ? '_avag':'')).'.html');
                            }
                        }


                        $mail->Subject = (($row[16]=='Anfrage')?_BM_ART3_:_BESCHWERDE_) . ' (' . adodb_date('d.m.Y, H:i') . ') - ' . kundenbezeichnung($row[2]) . ' (' . $row[2] . ')';
                        if ($bdc_email_betreff) {
                            $mail->Subject = 'BDC '.(($row[16]=='Anfrage')?_BM_ART3_:_BESCHWERDE_) . ' ('.$bdcid.') - ' . $row[0];
                        }
                        $bdc_mail = new bdcMail();
                        $mail = $bdc_mail->beschwerde(
                            $bdcid,
                            $mail,
                            false,
                            $alle_bmadr2,
                            [
                                'text' => $postfeld['antwort'],
                                'betreff' => $mail->Subject
                            ],
                            $_SESSION['design_70']
                        );
                        $mailtext = $mail->Body;


                        $mail->IsHTML(true);
                        @reset($alle_bmadr2);
                        while (list($keyba, $valba) = @each($alle_bmadr2)) {
                            $mail->AddAddress($valba);
                        }

                        preg_match_all('/(src|background)=\"(?P<image>.*?(jpg|jpeg|png|gif))\"/i', $mailtext, $matches);
                        foreach (array_unique($matches['image']) as $i => $src) {
                            $parts = explode('/', p4n_mb_string('str_replace', '\\', '/', $src));

                            // Nur lokale Bilder einbetten
                            if (!preg_match('/^[A-z][A-z]*:\/\//', $src)) {
                                $cid = 'img'.$i;
                                $cid .=md5($src);
                                # Ersetze Bilder-URL mit Content-ID
                                $mailtext = p4n_mb_string('str_replace', $src, 'cid:'.$cid, $mailtext);
                                $mail->AddEmbeddedImage($src, $cid);
                            }
                        }
                        $mailtext= preg_replace('/\<\![A-Za-z0-9_]*\>/Uis','',$mailtext);
                        $mail->Body = $mailtext;
                        // init default settings from
                        $mail->From = $bdc_einstellungen['absender'] != '' ? $bdc_einstellungen['absender'] : $_SESSION['user_email'];
                        $mail->FromName = $bdc_einstellungen['absendername'] != '' ? $bdc_einstellungen['absendername'] : $_SESSION['mitarbeiter_name'];
                        //Alexander 5.06.2022
                        //implode Microsoft Azure API
                        // use azure 'personal email 1 address' for send mail
                        if (!empty($cfg_microsoft_v2) && !empty($cfg_microsoft_v2_email_send)) {
                            $azure_email = AzureApp::getUserEmail($_SESSION['user_id'], $_SESSION['user_role'], 2); // 'personal email 1' is priority
                            if (!empty($azure_email['error'])) {
                                echo javas('alert("'.p4n_mb_string('htmlspecialchars', $azure_email['error']).'");');
                            }
                            if (!empty($azure_email['data']['mail'])) {
                                $mail->From = $azure_email['data']['mail'];
                                $mail->FromName = $azure_email['data']['name'];
                            }
                        }
                        if ($cfg_smtp_alternative) {
                            $smtpAlternative = array();
                            if (is_file('inc/utilities.php')) {
                                include_once 'inc/utilities.php';
                                $smtpAlternative = getSMTPdetails('stammdaten_uebersicht');
                            }
                        }
                        ob_start();

                        $gesendet2=$gesendet3=true;
                        if (method_exists($bdc_mail,'splitMailTo')) {
                            $mail=$bdc_mail->splitMailTo($mail);
                            $mail_temp=clone $mail;
                            $gesendet1=$bdc_mail->sendVerursacherMail($mail_temp);
                            $mail_temp=clone $mail;
                            $gesendet2=$bdc_mail->sendAndereBenutzer($mail_temp);
                            $mail_temp=clone $mail;
                            $gesendet3=$bdc_mail->sendFreieAdressen($mail_temp);
                        } else {
                            $gesendet1=$mail->Send($smtpAlternative);
                        }

                        if (!$gesendet1 || !$gesendet2 || !$gesendet3) {
                            $hinweistext .= '<font color=red>' . _EMAILING_EMAILS_FEHLER_ . '</font><br>';
                            $ticketMailMessage = new Template_Message(_EMAILING_EMAILS_FEHLER_, 'ERROR');
                        } else {
                            $hinweistext .= _EMAILING_EMAILS_ABGESCHICKT_ . '<br>';
                            $ticketMailMessage = new Template_Message(_EMAILING_EMAILS_ABGESCHICKT_, 'INFO');
                        }
                        $x=addslashes(ob_get_clean());
                        $hinweistext.=$x;
                        
                        
                       
                        

                        
                    }
                
                }
            
                
                        }
        } else {
            $ansprechpartner_id=0;
            $res_lead=$db->select(
                $sql_tab['kampagne_lead'],
                array(
                    $sql_tabs['kampagne_lead']['kampagne_lead_id'],//0
                    $sql_tabs['kampagne_lead']['korrespondenz_id'],//1
                    $sql_tabs['kampagne_lead']['status'],//2
                    $sql_tabs['kampagne_lead']['stammdaten_id'],//3
                    $sql_tabs['kampagne_lead']['additionaldata']//4
                ),
                $sql_tabs['kampagne_lead']['kampagne_lead_id'].'='.$db->dbzahl($bdcid)
            );
            if ($row_lead=$db->zeile($res_lead)) {
            
                
                $res=$db->select(
                    $sql_tab['korrespondenz'],
                    array(
                        $sql_tabs['korrespondenz']['korrespondenz_id'],//0
                        $sql_tabs['korrespondenz']['stammdaten_id'],//1
                        $sql_tabs['korrespondenz']['ersteller_id'],//2
                        $sql_tabs['korrespondenz']['betreuer_id'],//3
                        $sql_tabs['korrespondenz']['betreff'],//4
                        $sql_tabs['korrespondenz']['produktzuordnung_id'],//5
                        $sql_tabs['korrespondenz']['kampagne_id'],//6
                        $sql_tabs['korrespondenz']['lead_id'],//7
                        $sql_tabs['korrespondenz']['kategorie2'],//8
                        $sql_tabs['korrespondenz']['beschreibung'],//9
                        $sql_tabs['korrespondenz']['ansprechpartner_id'],//10
                    ),
                    $sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($row_lead[1])
                );
                if ($row=$db->zeile($res)) {
                    $ansprechpartner_id=$row[10];
                    $beschreibung=adodb_date('d.m.Y, H:i:s').' '.(isset($postfeld['absender']) && $postfeld['absender']!=''?$postfeld['absender']:$_SESSION['mitarbeiter_name2']).":\n".$statusfeld[$postfeld['status']]." - ".$postfeld['antwort']."\n\n".$row[9];

                    $db->update(
                        $sql_tab['korrespondenz'], array($sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true)), $sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($row_lead[1])
                    );
                    $korr_kategorie = _LEADS_;
                    if ($cfg_leadmanagement_2020) {
                        $temp_kat = $statusfeld[$postfeld['status']];
                        $status_temp = Plugin_System_LeadTracker::getStatusForCampaignCategory($temp_kat, $row[6]);
                        if ($status_temp > 0 && isset($sql_tabs['kampagne_lead_status']['status'.$status_temp])) {
                            $korr_kategorie = $temp_kat;
                        }
                    }
                    
                    $sqlt = array(
                        $sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
                        //$sql_tabs['korrespondenz']['datum2'] => $db->dbtimestamp(0),
                        $sql_tabs['korrespondenz']['wvl_datum1'] => $db->dbtimestamp(time()),
                        //$sql_tabs['korrespondenz']['wvl_datum2'] => $db->dbtimestamp(0),
                        $sql_tabs['korrespondenz']['stammdaten_id'] => $row[1],
                        $sql_tabs['korrespondenz']['ersteller_id'] =>$row[2],
                        $sql_tabs['korrespondenz']['betreuer_id'] =>$row[3],
                        $sql_tabs['korrespondenz']['eingang'] => $db->dblogic(false),
                        $sql_tabs['korrespondenz']['art'] => $db->dbzahl(14),
                        $sql_tabs['korrespondenz']['kategorie'] => $db->str($korr_kategorie),
                        $sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(($postfeld['status']==5?true:false)),
                        $sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl($row_lead[1]),
                        $sql_tabs['korrespondenz']['doclink'] => $db->str(''),
                        $sql_tabs['korrespondenz']['betreff'] => $db->str($row[4]),
                        $sql_tabs['korrespondenz']['beschreibung'] => $db->str($beschreibung),
                        $sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl($row[5]),
                        $sql_tabs['korrespondenz']['veranstaltung_id'] => $db->dbzahl(0),
                        $sql_tabs['korrespondenz']['veranstaltung_status'] => $db->dbzahl(0),
                        $sql_tabs['korrespondenz']['papierkorb'] => 0,
                        $sql_tabs['korrespondenz']['kalender_id'] => $db->dbzahl(0),
                        $sql_tabs['korrespondenz']['negativ'] => $db->dblogic(false),
                        $sql_tabs['korrespondenz']['auftrag_id'] => $db->dbzahl(0),
                        $sql_tabs['korrespondenz']['projekt_id'] => $db->dbzahl(0),
                        $sql_tabs['korrespondenz']['opportunity_id'] => $db->dbzahl(0),
                        $sql_tabs['korrespondenz']['troubleticket_id'] => $db->dbzahl(0),
                        $sql_tabs['korrespondenz']['aus_workflow'] => $db->dblogic(false),
                        $sql_tabs['korrespondenz']['kampagne_id'] => $row[6], //$kamp_id !!
                        $sql_tabs['korrespondenz']['lead_id'] => $db->str($bdcid),
                        $sql_tabs['korrespondenz']['kstatus'] => $db->dbzahl(0),
                        $sql_tabs['korrespondenz']['quelle'] => $db->str('BDC'),
                        $sql_tabs['korrespondenz']['kanal'] => $db->str(''),
                        $sql_tabs['korrespondenz']['kategorie2'] => $db->str($row[8]),
                        $sql_tabs['korrespondenz']['followup_anzahl'] => $db->dbzahl(0),
                        $sql_tabs['korrespondenz']['status1_time'] => $db->dbtimestamp(time()),
                        $sql_tabs['korrespondenz']['zusatz2'] => $db->str('')
                    );
                    $db->insert(
                        $sql_tab['korrespondenz'], $sqlt
                    );
                    $korrid=$db->insertid();

                    $sql_update_kampagne_lead = array(
                        $sql_tabs['kampagne_lead']['korrespondenz_id'] => $db->dbzahl($korrid)
                    );
                    if (!$lead_tracking_prozess) {
                        $sql_update_kampagne_lead[$sql_tabs['kampagne_lead']['status']] = $db->str($postfeld['status']);
                        $sql_update_kampagne_lead[$sql_tabs['kampagne_lead']['status'.$postfeld['status'].'_time']] = $db->dbtimestamp(time());
                    }
                    
                    $res2=$db->update(
                        $sql_tab['kampagne_lead'],
                        $sql_update_kampagne_lead,
                        $sql_tabs['kampagne_lead']['kampagne_lead_id'].'='.$db->dbzahl($bdcid)
                    );
                    if ($lead_tracking_prozess) {
                        $result_kampagne_lead = $db->select(
                            $sql_tab['kampagne_lead'],
                            $sql_tabs['kampagne_lead']['status'],
                            $sql_tabs['kampagne_lead']['kampagne_lead_id'].'='.$db->dbzahl($bdcid)
                        );
                        if ($row_kampagne_lead = $db->zeile($result_kampagne_lead)) {
                            $postfeld['status'] = $row_kampagne_lead['status'];
                        }
                    }
                }
                
                if (count($alle_bmadr) > 0 && intval($postfeld['status'])<5) {
                    include_once("inc/lib_htmledit.php");
                    include_once('inc/class_bdc_email.php');

                    $htmleditor = new HTMLEditor();
                    //$mail = $htmleditor->prepare_mail(138);

                    if (intval($bdc_einstellungen['vorlage3'])>0) {
                        $mail = $htmleditor->prepare_mail($bdc_einstellungen['vorlage3']);
                    } else {
                        $mail=$htmleditor->prepare_utf8_html_mail('template/bdc/lead'.($cfg_bdc_nl?'_nl':(p4n_mb_string('substr',$_SESSION['cfg_kunde'], 0, p4n_mb_string('strlen','carlo_opel_avag'))=='carlo_opel_avag' ? '_avag':($cfg_bdc_lead_bearbeitung?'_edit':''))).'.html');
                        /*if (!$cfg_bdc_lead_bearbeitung) {
                            $mail->Body= preg_replace('/\<\!cfg_bdc_lead_bearbeitung1\>.*\<\!cfg_bdc_lead_bearbeitung2\>/Uis','',$mail->Body);
                        }
                        $mail->Body= p4n_mb_string('str_replace',array('<!cfg_bdc_lead_bearbeitung1>','<!cfg_bdc_lead_bearbeitung2>'),'',$mail->Body); */
                    }
                    $mail->Subject = _LEAD_ . ' (' . adodb_date('d.m.Y, H:i') . ') - ' . kundenbezeichnung($row_lead[3]) . ' (' . $row_lead[3] . ')';
                    //Griga Flag       
                    $bdc_mail=new bdcMail();
                    if ($bdc_email_betreff) {
                        $betreff_a=$bdc_mail->extractAdditionalDataString($row_lead[4]);
                        $mail->Subject = 'BDC '._LEAD_ . ' ('.$bdcid.') - ' . $betreff_a['betreff'];
                    }
                    $mail=$bdc_mail->lead($bdcid,$mail,$ansprechpartner_id,$alle_bmadr);
                    $mailtext=$mail->Body; //Griga Flag


                    $mail->IsHTML(true);
                    @reset($alle_bmadr);
                    while (list($keyba, $valba) = @each($alle_bmadr)) {
                        $mail->AddAddress($valba);
                    }

                    preg_match_all('/(src|background)=\"(?P<image>.*?(jpg|jpeg|png|gif))\"/i', $mailtext, $matches);
                    foreach (array_unique($matches['image']) as $i => $src) {
                        $parts = explode('/', p4n_mb_string('str_replace', '\\', '/', $src));

                        // Nur lokale Bilder einbetten
                        if (!preg_match('/^[A-z][A-z]*:\/\//', $src)) {
                            $cid = 'img'.$i;
                            $cid .=md5($src);
                            # Ersetze Bilder-URL mit Content-ID
                            $mailtext = p4n_mb_string('str_replace', $src, 'cid:'.$cid, $mailtext);
                            $mail->AddEmbeddedImage($src, $cid);
                        }
                    }
                    $mailtext= preg_replace('/\<\![A-Za-z0-9_]*\>/Uis','',$mailtext);
                    $mail->Body = $mailtext;
                    // init default settings from
                    $mail->From = $bdc_einstellungen['absender'] != '' ? $bdc_einstellungen['absender'] : $_SESSION['user_email'];
                    $mail->FromName = $bdc_einstellungen['absendername'] != '' ? $bdc_einstellungen['absendername'] : $_SESSION['mitarbeiter_name'];
                    //Alexander 5.06.2022
                    //implode Microsoft Azure API
                    // use azure 'personal email 1 address' for send mail
                    if (!empty($cfg_microsoft_v2) && !empty($cfg_microsoft_v2_email_send)) {
                        $azure_email = AzureApp::getUserEmail($_SESSION['user_id'], $_SESSION['user_role'], 2); // 'personal email 1' is priority
                        if (!empty($azure_email['error'])) {
                            echo javas('alert("'.p4n_mb_string('htmlspecialchars', $azure_email['error']).'");');
                        }
                        if (!empty($azure_email['data']['mail'])) {
                            $mail->From = $azure_email['data']['mail'];
                            $mail->FromName = $azure_email['data']['name'];
                        }
                    }

                    if ($cfg_smtp_alternative) {
                        $smtpAlternative = array();
                        if (is_file('inc/utilities.php')) {
                            include_once 'inc/utilities.php';
                            $smtpAlternative = getSMTPdetails('stammdaten_uebersicht');
                        }
                    }
                    ob_start();

                    $gesendet2=$gesendet3=true;
                    if (method_exists($bdc_mail,'splitMailTo')) {
                        $mail=$bdc_mail->splitMailTo($mail);
                        $mail_temp=clone $mail;
                        $gesendet1=$bdc_mail->sendVerursacherMail($mail_temp);
                        $mail_temp=clone $mail;
                        $gesendet2=$bdc_mail->sendAndereBenutzer($mail_temp);
                        $mail_temp=clone $mail;
                        $gesendet3=$bdc_mail->sendFreieAdressen($mail_temp);
                    } else {
                        $gesendet1=$mail->Send($smtpAlternative);
                    }

                    if (!$gesendet1 || !$gesendet2 || !$gesendet3) {
                        $hinweistext .= '<font color=red>' . _EMAILING_EMAILS_FEHLER_ . '</font><br>';
                    } else {
                        $hinweistext .= _EMAILING_EMAILS_ABGESCHICKT_ . '<br>';
                    }
                    $x=addslashes(ob_get_clean());
                    $hinweistext.=$x;
                    $mail_lead=true;
                   // echo javas('jq1112(document).ready(function ($) {bdc_alert("'.$hinweistext.'");});');
                } else {
                    if ($lead_tracking_prozess && $postfeld['status']=='5') {
                        $db->update(
                            $sql_tab['korrespondenz'],
                            array(
                                $sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true)
                            ),
                            $sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($korrid)
                        );
                    }
                }
            }
        }

        if (isset($_SESSION['design_70'])) {
            Modern_Helper_Request::requestStart();
            echo Template_Message::init(_VIELEN_DANK_, 'SUCCESS')->getHtml();
            if ($ticketMailMessage) {
                echo $ticketMailMessage->getHtml();
            }
        } else {
            echo _VIELEN_DANK_;
        }
        fuss();
        die;
        
    }
    
    
    $form=new htmlform();
    echo $form->start('bdc_req?req='.$getfeld['req'], $phs, 'POST');
    echo '
    <style type="text/css">
    textarea {
        max-width:500px; 
        width:100%;
    }
    </style>
    <style type="text/css" media="only screen and (max-width: 480px)">
        @media only screen and (max-width: 480px) {
            .inputauto .styled-select, .inputauto .styled-select select {
                max-width:500px; 
                width:100%;
            }
            textarea {
                height: 300px;
            }
        }
    </style>';
    
    echo '<div id="bdc_alert"></div>';

    echo javas('
    function focus_red(ele) {
        ele.addClass("border-red");
        ele.bind("focus",function() {
            ele.removeClass("border-red");
            ele.unbind("focus");
        });
    }
    function bdc_alert(html, closeall, ohnecc) {
        if (typeof closeall==typeof undefined) {
            closeall=false;
        }

        if (closeall==true) {
            P4nBoxHelper.close();
        }
        P4nBoxHelper.init({
            href:"#bdc_alert",
            target:"body",
            id:"bdc_alert_window",
            width:"260px",
            height:"80px",
            type:"obj",
            beforeShow: function() {
                jq1112("#bdc_alert").html(html);
            },
            beforeClose: function() {
                jq1112("#bdc_alert").html("");
                if (typeof ohnecc != typeof undefined && ohnecc==true) {
                    try {parent.P4nBoxHelper.closeall();} catch(e) {}
                }
            },
            callback:function() {
                jq1112("#bdc_alert_window input").focus();
                setTimeout(function() {jq1112("#bdc_alert_window input").focus();},1);
            },
            buttons:"'.addslashes($form->submit2('',  '&nbsp;'.strtoupper(_OK_).'&nbsp;','onclick="P4nBoxHelper.close(\'bdc_alert_window\');"')).'",
            noscroll:true,
            noclosebtn:true
        });
    }

    function check_req() {
        var name=$("#absender").val();
        var message="<b>'._FEHLER_POPUP_.':</b><br>";
        if (name=="" && "'.intval($bdc_einstellungen['name']).'"=="1") {
            message+="'._ABSENDER_.'<br>";
            focus_red($("#absender"));
        }

        if (message!="<b>'._FEHLER_POPUP_.':</b><br>") {
            bdc_alert(message ,true);
        } else {
            if (typeof P4nBoxHelper.startloading != typeof undefined) { 
                P4nBoxHelper.startloading(); 
            }
            return true;
        }
        return false;
    };
    ');
    
    $js_antw_pfl='';
    if ($cfg_bdc_antwort_pflicht) {
		$js_antw_pfl=' if (this.form.antwort.value==\'\') { alert(\''._FELDEREINGEBEN_.': '._ANTWORT_.'\'); return false; } ';
	}
    
    if (!$is_lead) {
        $res=$db->select(
            $sql_tab['troubleticket'],
            array(
                $sql_tabs['troubleticket']['status'],//0
                $sql_tabs['troubleticket']['protokoll'],//1
                $sql_tabs['troubleticket']['art2'],
                $sql_tabs['troubleticket']['benutzer_id'],
                $sql_tabs['troubleticket']['benutzer_id2']
            ),
            $sql_tabs['troubleticket']['troubleticket_id'].'='.$db->dbzahl($bdcid)
        );
        if ($row=$db->zeile($res)) {
            $def_benutzer_veranwortlicher=$row[3];
            $schliess_status_entfernen_bm=!$darf_schliessen;
            $schliess_status_entfernen_anfrage=!$darf_schliessen_anfrage;
            if (!$schliessgruppe_bm_existiert) {
                if (($def_benutzer_veranwortlicher==$user_id && !$bm_editor) || $ist_bm_verant || $_SESSION['user_gruppe']==2) {
                    $schliess_status_entfernen_bm=false;
                }
            }
            if (!$schliessgruppe_anfrage_existiert) {
                if (($def_benutzer_veranwortlicher==$user_id && !$bm_editor) || $ist_bm_verant || $_SESSION['user_gruppe']==2) {
                    $schliess_status_entfernen_anfrage=false;
                }
            }
			if ($cfg_bdc_schliessen_alle) {
				// schliess-Status nicht rausnehmen
			} else {
                if ($row[2]=='') {
                    if ($schliess_status_entfernen_bm) {
                        unset($statusfeld[4]);
                    }
                } else {
                    if ($schliess_status_entfernen_anfrage) {
                        unset($statusfeld[4]);
                    }
                }
			}

			// region BDC E-Mail Aktion "Schnell antworten"
            if (isset($_SESSION['design_70'])) {
                $result_troubleticket = $db->select(
                    $sql_tab['troubleticket'],
                    [
                        $sql_tabs['troubleticket']['lagerort_id'],
                        $sql_tabs['troubleticket']['mandant_id'],
                        $sql_tabs['troubleticket']['produkt_id'],
                        $sql_tabs['troubleticket']['stammdaten_id'],
                        $sql_tabs['troubleticket']['benutzer_id'],
                        $sql_tabs['troubleticket']['benutzer_id2'],
                        $sql_tabs['troubleticket']['ansprechpartner_id'],
                        $sql_tabs['troubleticket']['kategorie'],
                        $sql_tabs['troubleticket']['kategorie2'],
                        $sql_tabs['troubleticket']['kategorie5'],
                        $sql_tabs['troubleticket']['status'],
                        $sql_tabs['troubleticket']['datum'],
                        $sql_tabs['troubleticket']['beschreibung'],
                        $sql_tabs['troubleticket']['beschwerdezeit_ziel'],
                        $sql_tabs['troubleticket']['betreff'],
                        $sql_tabs['troubleticket']['prioritaet'],
                        $sql_tabs['troubleticket']['art2'],
                        $sql_tabs['troubleticket']['protokoll'],
                        $sql_tabs['troubleticket']['kfzmarke']
                    ],
                    $sql_tabs['troubleticket']['troubleticket_id'].'='.$db->dbzahl($bdcid)
                );
                if ($row_troubleticket = $db->zeile($result_troubleticket)) {
                    $troubleticket = $row_troubleticket;
                }

                $troubleticket_stammdaten = [];
                $result_stammdaten = $db->select(
                    $sql_tab['stammdaten'],
                    [
                        $sql_tabs['stammdaten']['EMail_1'],
                        $sql_tabs['stammdaten']['Telefon_1'],
                        $sql_tabs['stammdaten']['Mobilfon_1'],
                        $sql_tabs['stammdaten']['name'],
                        $sql_tabs['stammdaten']['vorname'],
                        $sql_tabs['stammdaten']['anrede'],
                        $sql_tabs['stammdaten']['titel'],
                        $sql_tabs['stammdaten']['mandant']
                    ],
                    $sql_tabs['stammdaten']['id'].'='.$db->dbzahl($troubleticket['stammdaten_id'])
                );
                if ($row_stammdaten = $db->zeile($result_stammdaten)) {
                    $troubleticket_stammdaten['email'] = $row_stammdaten['EMail_1'] !== '' ? $row_stammdaten['EMail_1'] : '-';
                    $troubleticket_stammdaten['telefon'] = $row_stammdaten['Telefon_1'] !== '' ? $row_stammdaten['Telefon_1'] : '-';
                    $troubleticket_stammdaten['mobil'] = $row_stammdaten['Mobilfon_1'] !== '' ? $row_stammdaten['Mobilfon_1'] : '-';
                    $troubleticket_stammdaten['name'] = $row_stammdaten['name'] !== '' ? $row_stammdaten['name'] : '-';
                    $troubleticket_stammdaten['vorname'] = $row_stammdaten['vorname'] !== '' ? $row_stammdaten['vorname'] : '-';
                    $troubleticket_stammdaten['anrede'] = $row_stammdaten['anrede'] !== '' ? $row_stammdaten['anrede'] : '-';
                    $troubleticket_stammdaten['titel'] = $row_stammdaten['titel'] !== '' ? $row_stammdaten['titel'] : '-';
                    $troubleticket_stammdaten['mandant'] = $row_stammdaten['mandant'] !== '' ? $row_stammdaten['mandant'] : '-';
                }

                $troubleticket_ansprechpartner = [];
                $result_ansprechpartner = $db->select(
                    $sql_tab['stammdaten_ansprechpartner'],
                    [
                        $sql_tabs['stammdaten_ansprechpartner']['vorname'],
                        $sql_tabs['stammdaten_ansprechpartner']['bezeichnung'],
                    ],
                    $sql_tabs['stammdaten_ansprechpartner']['ansprechpartner_id'].'='.$db->dbzahl($troubleticket['ansprechpartner_id'])
                );
                if ($row_ansprechpartner = $db->zeile($result_ansprechpartner)) {
                    $troubleticket_ansprechpartner['vorname'] = $row_ansprechpartner['vorname'];
                    $troubleticket_ansprechpartner['name'] = $row_ansprechpartner['bezeichnung'];
                } else {
                    $result_ansprechpartner = $db->select(
                        $sql_tab['stammdaten_ansprechpartner'],
                        [
                            $sql_tabs['stammdaten_ansprechpartner']['vorname'],
                            $sql_tabs['stammdaten_ansprechpartner']['bezeichnung'],
                        ],
                        $sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'].'='.$db->dbzahl($troubleticket['stammdaten_id']).' AND '.
                        $sql_tabs['stammdaten_ansprechpartner']['ansprechpartner_id'].'='.$db->dbzahl($troubleticket['ansprechpartner_id'])
                    );
                    if ($row_ansprechpartner = $db->zeile($result_ansprechpartner)) {
                        $troubleticket_ansprechpartner['vorname'] = $row_ansprechpartner['vorname'];
                        $troubleticket_ansprechpartner['name'] = $row_ansprechpartner['bezeichnung'];
                    } else {
                        $troubleticket_ansprechpartner['vorname'] = '-';
                        $troubleticket_ansprechpartner['name'] = '-';
                    }
                }

                // region Header
                if (empty($troubleticket['art2'])) {
                    $type = '-';
                } else {
                    $type = $troubleticket['art2'] === 'Anfrage' ? _BM_ART3_ : _BESCHWERDE_;
                }

                if (empty($troubleticket['kategorie'])) {
                    $category = '-';
                } else {
                    $category = strpos($troubleticket['kategorie'], 'Kategorie') !== false ? substr(strstr($troubleticket['kategorie'], ' '), 1) : $troubleticket['kategorie'];
                }

                $clients = rmandanten(false, true);
                if ((int)$troubleticket['lagerort_id'] < 0) {
                    $company = '-';
                } elseif (isset($clients[$troubleticket['lagerort_id']])) {
                    $company = $clients[$troubleticket['lagerort_id']];
                } elseif (isset($clients[$troubleticket['mandant_id']])) {
                    $company = $clients[$troubleticket['mandant_id']];
                }

                if (empty($troubleticket['kategorie5']) || $troubleticket['kategorie5'] === 'keine Zuordnung') {
                    $section = '-';
                } else {
                    $section = $troubleticket['kategorie5'];
                }

                $make = empty($troubleticket['kfzmarke']) ? '-' : $troubleticket['kfzmarke'];

                $billString = ' - | - | - ';
                $result_auftrag = $db->select(
                    $sql_tab['auftrag'],
                    [
                        $sql_tabs['auftrag']['rechnung_id'],
                        $sql_tabs['auftrag']['datum'],
                        $sql_tabs['auftrag']['nummer']
                    ],
                    $sql_tabs['auftrag']['auftrag_id'].'='.$db->dbzahl($troubleticket['auftrag_id'])
                );
                if ($row_auftrag = $db->zeile($result_auftrag)) {
                    $billString = $row_auftrag['datum'] !== '' ? $row_auftrag['datum'] : '-';
                    $billString .= ' | ';
                    $billString .= $row_auftrag['nummer'] !== '' ? $row_auftrag['nummer'] : '-';
                    $billString .= ' | ';
                    $billString .= $row_auftrag['rechnung_id'] !== '' ? $row_auftrag['rechnung_id'] : '-';
                }

                $product = [];
                if (((int)$troubleticket['produkt_id'] > 0) && $cfg_kfz) {
                    $product = produktauswahl($troubleticket['produkt_id'], [], false, $troubleticket['stammdaten_id']);
                }
                $vehicleString = str_replace('/', '|', isset($product[$troubleticket['produkt_id']]) ? $product[$troubleticket['produkt_id']] : _KPRODUKTNEU_);

                if ($troubleticket['status'] === 4) {
                    $timeDifference = '-';
                } else {
                    include('inc/lib_sn.php');
                    $dateStart = new DateTime(
                        str_replace('.', '-', adodb_date('d.m.Y', $db->unixdate_ts($troubleticket['datum']))).
                        ' '.
                        adodb_date('H', $db->unixdate_ts($troubleticket['datum'])).
                        ':'.
                        adodb_date('i', $db->unixdate_ts($troubleticket['datum']))
                    );

                    $time = time();
                    $dateEnd = new DateTime(
                        str_replace('.', '-', adodb_date('d.m.Y', $time)).
                        ' '.
                        adodb_date('H', $db->unixdate_ts($time)).
                        ':'.
                        adodb_date('i', $db->unixdate_ts($time))
                    );

                    $interval = $dateStart->diff($dateEnd);
                    $timeDifference = $interval->m !== 0 ? $interval->m.'M '.$interval->d.'T '.$interval->h.'S '.$interval->i.'M' : $interval->d.'T '.$interval->h.'s '.$interval->i.'m';
                }

                $cols_x[0][0] = Template_Text::init($troubleticket['beschreibung'])->addCustomClass('mt-32 mb-16');
                $cols_x[1][0] = Template_Title::init($troubleticket_stammdaten['anrede'].' '.$troubleticket_stammdaten['titel'].' '.$troubleticket_stammdaten['vorname'].' '.$troubleticket_stammdaten['name'].' ('.$troubleticket_ansprechpartner['name'].', '.$troubleticket_ansprechpartner['vorname'].')', 4);

                $cols_k = [];
                $cols_k[0][0] = new Template_ElementList(
                    [
                        new Template_Label([new Template_Icon('phone'), _FESTNETZ_], $troubleticket_stammdaten['telefon']),
                        new Template_Label([new Template_Icon('smartphone'), _MOBILTELEFON_], $troubleticket_stammdaten['mobil']),
                        new Template_Label([new Template_Icon('mdi-email-outline'), _EMAIL_], $troubleticket_stammdaten['email'])
                    ],
                    '',
                    'details-list-advanced2'
                );
                $cols_k2 = [];
                $cols_k2[0][0] = new Template_ElementList(
                    [
                        new Template_Label(_ERSTELLDATUM_, date('d.m.Y H:i:s', strtotime($troubleticket['datum']))),
                        new Template_Label(_ZIELDATUM_, date('d.m.Y H:i:s', strtotime($troubleticket['beschwerdezeit_ziel']))),
                        new Template_Label(_AKTUELLE_DAUER_, $timeDifference)
                    ],
                    '',
                    'details-list-advanced2'
                );

                $users = rbenutzer(1, false, '', 40);
                if (function_exists('getUsersWithOnlineOfflineStatus')) {
                    $users = getUsersWithOnlineOfflineStatus($users);
                }

                $userId = $troubleticket['benutzer_id'];
                if ($bdcid === '-1') {
                    $userId = $_SESSION['user_id'];
                }

                $cols_k3 = [];
                $cols_k3[0][0] = new Template_ElementList(
                    [
                        new Template_Label(_FAHRZEUG_, $vehicleString),
                        new Template_Label(_RECHNUNG_, $billString),
                        new Template_Label(_BEARBEITER_.'/'._VERANTWORTLICHER_, $users[$userId])
                    ],
                    '',
                    'details-list-advanced2'
                );

                $cols = [];
                $cols[0][0] = new Template_GridTableCol(12, 'auto', 'auto', new Template_GridTable($cols_k));
                $cols[0][1] = new Template_GridTableCol('0', '05', '05', '&nbsp;');
                $cols[0][2] = new Template_GridTableCol(12, 'auto', 'auto', new Template_GridTable($cols_k2));
                $cols[0][3] = new Template_GridTableCol('0', '05', '05', '&nbsp;');
                $cols[0][4] = new Template_GridTableCol(12, 'auto', 'auto', new Template_GridTable($cols_k3));
                $cols_x[1][0] = Template_GridTable::init($cols)->addCustomClass('mb-24');
                $inner = new Template_GridTable($cols_x);

                $ticketNumber = (($cfg_catch_retail || $cfg_catch_whole) && (int)$troubleticket['fremdschluessel_id'] > 0) ? $troubleticket_stammdaten['mandant'].'-'.$bdcid.' ('.$troubleticket_stammdaten['mandant'].'-'.$troubleticket['fremdschluessel_id'].')' : $troubleticket_stammdaten['mandant'].'-'.$bdcid;

                $breadcrumps = [Template_Title::init($troubleticket['betreff'].' ('.$ticketNumber.')', 3)->addCustomClass('color-blue')];

                $back = new Template_IconButton('', '', 'class="close_trigger"', 'arrow_back');
                $close = new Template_IconButton('', '', 'class="close_trigger"', 'close');
                $triggerBtn = new Template_IconButton('', '', '', 'expand_more', '', '', 'sm', 'blue');

                $status[1] = new Template_Text(_BM_STATUS1_);
                $status[2] = new Template_Text(_BM_STATUS2_);
                $status[3] = new Template_Text(_BM_STATUS3_);
                $status[4] = new Template_Text(_BM_STATUS4_);
                $statusTimeline = new Template_Timeline($status, null, $troubleticket['status'], true, true);

                if (!empty($troubleticket['prioritaet'])) {
                    if ((int)$troubleticket['prioritaet'] === 0) {
                        $priorityIcon = new Template_Icon('south');
                    }
                    if ((int)$troubleticket['prioritaet'] === 1) {
                        $priorityIcon = new Template_Icon('east');
                    }
                    if ((int)$troubleticket['prioritaet'] === 2) {
                        $priorityIcon = Template_Icon::init('arrow_upward')->setAttribute('style', 'color: red');
                    }
                }

                $subtextTitle = Template_Title::init($type.' | '.$catgory.' | '.$company.' | '.$section.' | '.$make, 5)->setAttribute('style', 'white-space: nowrap');

                $subtext = new Template_ElementList([$subtextTitle], '', 'horizontal ml-0 mb-8');

                $chips = '';
                $chipsCounter = 0;
                foreach (explode(';', $troubleticket['kategorie2']) as $category2) {
                    if ($category2 !== '' && $category2 !== '-') {
                        if (empty($chips)) {
                            $chips = new Template_ElementList([], '', 'horizontal wrap mt-8 ml-0 mb-8');
                        }
                        $chips->addElement(new Template_Chip($category2, '#e4e4e4', '#292929'));
                        $subtext->addElement(new Template_Chip($category2, '#e4e4e4', '#292929'));
                        $chipsCounter++;
                    }
                }

                $subtextGrid = new Template_GridTable([[$subtextTitle], [$chips]]);

                $collapsileTriggerBtn = Template_Default::collapsilesButton();

                if (is_object($subtext)) {
                    $subtext = [$subtext, $collapsileTriggerBtn];
                }
                $subtext = new Template_ElementList($subtext, '', 'horizontal subtext');

                $headerCollapsile = new Template_Collapsiles(new Template_ElementList([$breadcrumps, $chipsCounter > 2 ? $subtextGrid : $subtext, $inner]), false);
                $headerCollapsile->setTrigger($collapsileTriggerBtn);
                $headerCollapsile->setBody($inner);
                $headerCollapsile->addCustomClass('bdc-mail-action-header-collapsile');
                // endregion

                // region E-Mail form
                $userId = $troubleticket['benutzer_id'];
                $userId2 = $troubleticket['benutzer_id2'];
                // If crm_troubleticket.art2 is empty the ticket is a "Anfrage" => can always be edited.
                $canEdit = $troubleticket['art2'] !== '';
                if ($usergruppe === 2 || $ist_bm_verant) {
                    $canEdit = true;
                }
                if ($cfg_bm_bearbeiter2 && $user_id === $userId2) {
                    $canEdit = true;
                }
                if ($bm_editor || $user_id === $userId) {
                    $canEdit = true;
                }

                $textArea = new Template_TextArea(_ANTWORT_, 'antwort', '', 0, 5);
                if ($troubletickt['status'] === 4) {
                    $textArea->setAttribute('disabled', 'disabled');
                }
                $textArea->setAttribute('style', 'min-width: 100% !important');

                $emailFormContent = new Template_ElementList(null, '', 'vertical');
                $emailFormContent->addElement(new Template_Title(_SCHNELLANTWORT_, 3));
                $emailFormContent->addElement(new Template_SelectInput(_STATUS_, 'status', $statusfeld, $troubletickt['status'], false));
                $emailFormContent->addElement($textArea);
                
                $removeBdcRecipientBtn = new Template_IconButton(
                    '',
                    _FELD_LEEREN_,
                    '',
                    'mdi-trash-can-outline',
                    '',
                    false
                );
                $removeBdcRecipientBtn->onClick('StorageHelper.remove(\'bdc_req_absender\'); location.reload();');
                $removeBdcRecipientBtn->addCustomClass('mt-22');
                $emailFormContent->addElement(
                    new Template_ElementList(
                        [
                            new Template_TextInput(_NAME_, 'absender', $_SESSION['mitarbeiter_name2'], '', ($troubletickt['status'] === 4 ? 'disabled="disabled"' : '').' id="absender"'),
                            $removeBdcRecipientBtn
                        ],
                        '',
                        'horizontal'
                    )
                );
                $emailFormContent->addElement(Template_Title::init(_ANTWORT_.' '._PER_.' '._EMAIL_.' '._SENDEN_, 3)->addCustomClass('color-blue'));
                $emailFormContent->addElement(
                    new Template_ElementList(
                        [
                            new Template_CheckInput(_TICKET_.' '._ERSTELLER_, 'email_ersteller', false),
                            new Template_CheckInput(_TICKET_.' '._VERANTWORTLICHER_, 'email_verantwortlicher', false)
                        ],
                        '',
                        'horizontal'
                    )
                );
                $emailFormContent->addElement(Template_Default::ModalFooter(new Template_Submit('submit_req', _KSUBMIT_, 'id="submit_req" onClick="'.$js_antw_pfl.'return check_req();"'.($troubletickt['status'] === 4 ? ' disabled="disabled"' : ''))));

                $action = 'bdc.php?req='.$_GET['req'].'&bdcfr='.$_GET['bdcfr'].'&bdcuid='.$_GET['bdcuid'].'&requestnote=1';
                $emailForm = new Template_Form('d70-bdc-email-form', $action, 'POST', false, '', $canEdit);
                $emailForm->addElement($emailFormContent);
                // endregion

                $protocol = Template_Default::CollapsilesCard(false, _KONTAKTHISTORIE_, null, new Template_GridTable([[new Template_Text($troubleticket['protokoll'])]]), ['border', 'padding', 'shadow'], true, null, 'bdc-mail-action-protocol');
                $protocol->addCustomClass('bdc-mail-action-protocol');

                $content = new Template_Card(null, new Template_ElementList([$headerCollapsile, $statusTimeline, $emailForm, $protocol], '', 'vertical'));
                $content->setAttribute('style', 'margin: auto; width: 50%; height: 95vh; display: grid; place-items: center; overflow-y: auto;');

                echo javas('
                    if (StorageHelper.get("bdc_req_absender") != null && StorageHelper.get("bdc_req_absender") != "") {
                        document.getElementById("absender").value = StorageHelper.get("bdc_req_absender");
                    }
                ');
                echo $content->getHtml();
                unset($_GET['design70-bdc-bm-mail']);
                exit;
            } else {
                if ($_SESSION['crm_version']>62) {
                    $def_b = $row[3];
                    $def_b2 = $row[4];
                    $darf_bearbeiten = ($row[2]!='');//!= leer -> Anfrage -> true darf immer bearbeitet werden
                    if ($usergruppe==2 or $ist_bm_verant) {
                        $darf_bearbeiten = true;
                    }
                    if ($cfg_bm_bearbeiter2 and $user_id==$def_b2) {
                        $darf_bearbeiten = true;
                    }
                    if ($bm_editor or $user_id==$def_b) {
                        $darf_bearbeiten = true;
                    }
                    $old_form_ro = $form->ro;
                    $form->ro = !$darf_bearbeiten;
                    echo '<table class="inputauto">';
                    echo '<tr><th>'._STATUS_.'</th><td>'.$form->selectinput('status', $statusfeld, $row[0],false).'</td></tr>';
                    echo '<tr><th>'._ANTWORT_.'</th><td>'.$form->textareainput('antwort', '', 100, 5,($row[0]==4?'disabled="disabled"':'')).(($row[1]!='')?'<br>'.oltext($row[1],_PROTOKOLL_.' '._BM_ART4_):'').'</td></tr>';
                    echo '<tr><th>'._NAME_.'</th><td>'.$form->textinput('absender', $_SESSION['mitarbeiter_name2'], '',($row[0]==4?'disabled="disabled"':'').' id="absender"').' ('. link2(_FELD_LEEREN_, 'javascript:void(0);', '', false,'style="color:#666;" onclick="StorageHelper.remove(\'bdc_req_absender\'); location.reload();"').')'.'</td></tr>';
                    if ($_SESSION['crm_version']>65) {
                        echo '<tr><th>'._EMAIL_.'</th><td>'.$form->checkinput('email_ersteller', false).' '._ERSTELLER_.' '.$form->checkinput('email_verantwortlicher', false).' '._VERANTWORTLICHER_.' </td>';
                    }
                    echo '</table>';
                    echo '<br>'.$form->submit('submit_req', _KSUBMIT_, 'id="submit_req" onClick="'.$js_antw_pfl.'return check_req();"'.($row[0]==4?' disabled="disabled"':''));
                    echo javas('if (StorageHelper.get("bdc_req_absender")!=null && StorageHelper.get("bdc_req_absender")!="") {document.getElementById("absender").value=StorageHelper.get("bdc_req_absender");}');
                    $form->ro = $old_form_ro;
                } else {
                    echo '<table class="inputauto"><tr><th>'._AKTION_.'/'._ANTWORT_.'</th></tr><tr><td>'.$form->selectinput('status', $statusfeld, $row[0],false).'<br>'.$form->textareainput('antwort', '', 100, 5,($row[0]==4?'disabled="disabled"':''));
                    echo '<br>'.$form->submit('submit_req', _KSUBMIT_, 'onClick="'.$js_antw_pfl.'if (typeof P4nBoxHelper.startloading != typeof undefined) { P4nBoxHelper.startloading(); }"'.($row[0]==4?' disabled="disabled"':'')).'</td></tr></table>';
                }
                echo $form->ende();
            }
            // endregion
        }
    } else {
        $res=$db->select(
            $sql_tab['kampagne_lead'],
            array(
                $sql_tabs['kampagne_lead']['kampagne_lead_id'],//0
                $sql_tabs['kampagne_lead']['korrespondenz_id'],//1
                $sql_tabs['kampagne_lead']['status']
            ),
            $sql_tabs['kampagne_lead']['kampagne_lead_id'].'='.$db->dbzahl($bdcid)
        );
        if ($row=$db->zeile($res)) {
            if ($row[2]>2) {
                unset($statusfeld[2]);
            }
            if ($row[2]>4) {
                unset($statusfeld[4]);
            } 
            
            if ($_SESSION['crm_version']>62) {
                
                
                $res2=$db->select(
                    $sql_tab['korrespondenz'],
                    array(
                        $sql_tabs['korrespondenz']['beschreibung'],//0
                        $sql_tabs['korrespondenz']['kampagne_id'],
                        $sql_tabs['korrespondenz']['kategorie']
                    ),
                    $sql_tabs['korrespondenz']['korrespondenz_id'].'='.$db->dbzahl($row[1])
                );
                $select_input_name_status='status';
                if ($row2=$db->zeile($res2)) {
                    $beschreibung=$row2[0];
                    if ($cfg_leadmanagement_2020) {
                        $kampagne_id = $row2[1];
                        $status_kategorien=array();
                        if ($kampagne_id>0) {
							$rangkat=array();
							$result_kampagne_status_zuordnung = $db->select(
                                $sql_tab['kampagne_kategorie'],
                                array(
                                    $sql_tabs['kampagne_kategorie']['rang'],
                                    $sql_tabs['kampagne_kategorie']['bezeichnung']
                                ),
                                $sql_tabs['kampagne_kategorie']['kampagne_id'].'='.$db->dbzahl($kampagne_id)
                            );
                            while ($row_kampagne_status_zuordnung = $db->zeile($result_kampagne_status_zuordnung)) {
                                $rangkat[$row_kampagne_status_zuordnung[1]]=$row_kampagne_status_zuordnung[0];
                            }
                            $result_kampagne_status_zuordnung = $db->select(
                                $sql_tab['kampagne_status_zuordnung'],
                                array(
                                    $sql_tabs['kampagne_status_zuordnung']['kategorie'],
                                    $sql_tabs['kampagne_status_zuordnung']['status']
                                ),
                                $sql_tabs['kampagne_status_zuordnung']['kampagne_id'].'='.$db->dbzahl($kampagne_id)
                            );
                            while ($row_kampagne_status_zuordnung = $db->zeile($result_kampagne_status_zuordnung)) {
                                $status_kategorien[$row_kampagne_status_zuordnung[0]]=$row_kampagne_status_zuordnung[0];
                            }
							@asort($rangkat);
							$neuestat=array();
							foreach ($rangkat as $katbez => $rang) {
								if (isset($status_kategorien[$katbez])) {
									$neuestat[$katbez]=$katbez;
								}
							}
							if (count($neuestat)>0) {
								$status_kategorien=$neuestat;
							}
                        }
                        if (!empty($status_kategorien)) {
                            $select_input_name_status='status_phasen';
                            $statusfeld=$status_kategorien;
                        }
                    }
                }
                
                
                echo '<table class="inputauto">';
                echo '<tr><th>'._STATUS_.'</th><td>'.$form->selectinput($select_input_name_status, $statusfeld, $row[2],false,($row[2]==5?'disabled="disabled"':'')).'</td></tr>';
                echo '<tr><th>'._ANTWORT_.'</th><td>'.$form->textareainput('antwort', '', 100, 5,($row[2]==5?'disabled="disabled"':'')).(($beschreibung!='')?'<br>'.oltext($beschreibung,_PROTOKOLL_.' '._BM_ART4_):'').'</td></tr>';
                echo '<tr><th>'._NAME_.'</th><td>'.$form->textinput('absender', $_SESSION['mitarbeiter_name2'], '',($row[2]==5?'disabled="disabled"':'').' id="absender"').' ('. link2(_FELD_LEEREN_, 'javascript:void(0);', '', false,'style="color:#666;" onclick="StorageHelper.remove(\'bdc_req_absender\'); location.reload();"').')'.'</td></tr>';
                echo '</table>';
                echo '<br>'.$form->submit('submit_req', _KSUBMIT_, 'id="submit_req" onClick="'.$js_antw_pfl.'return check_req();"'.($row[2]==5?' disabled="disabled"':''));
                echo javas('if (StorageHelper.get("bdc_req_absender")!=null && StorageHelper.get("bdc_req_absender")!="") {document.getElementById("absender").value=StorageHelper.get("bdc_req_absender");}');
                $form->ro = $old_form_ro;
            } else {
                echo '<table class="inputauto"><tr><th>'._AKTION_.'/'._ANTWORT_.'</th></tr><tr><td>'.$form->selectinput('status', $statusfeld, $row[2],false).'<br>'.$form->textareainput('antwort', '', 100, 5,($row[2]==5?'disabled="disabled"':''));
                echo '<br>'.$form->submit('submit_req', _KSUBMIT_, 'onClick="'.$js_antw_pfl.'if (typeof P4nBoxHelper.startloading != typeof undefined) { P4nBoxHelper.startloading(); }"'.($row[2]==4?' disabled="disabled"':'')).'</td></tr></table>';
            }
            echo $form->ende();
        }
    }

    fuss();
    die();
} 

include("inc/session.php");
require_once('inc/lib_sn.php');

$modal_utility_content = new Template_ElementList('', 'modal_bdc_utility_inhalt');
$modal_utility = new Template_Modal('modal_bdc_utility', null, $modal_utility_content);
$modal_utility->setRight();

$modal_utility_level_2_content = new Template_ElementList('', 'modal_bdc_utility_level_2_inhalt');
$modal_utility_level_2 = new Template_Modal('modal_bdc_utility_level_2', null, $modal_utility_level_2_content);
$modal_utility_level_2->setRight();

$rememberedCarId = null;
$leadDefaultUser = null;
$redirectToLeadAfterLeadCreation = false;
if (isset($_SESSION['design_70'])) {
    $userRoleData = new User_Role($_SESSION['user_role']);
    if ($userRoleData->load(['besonderes_recht']) && !empty($userRoleData['besonderes_recht'])) {
        $userRoleSpecialRights = unserialize($userRoleData['besonderes_recht']);
        if (!empty($userRoleSpecialRights)) {
            if (
                $userRoleSpecialRights['bdc_lead_is_default_user'] &&
                $db->dblogic($userRoleSpecialRights['bdc_lead_is_default_user'])
            ) {
                $leadDefaultUser = $_SESSION['user_id'];
            }
            if (
                $userRoleSpecialRights['bdc_lead_creation_redirect_to_lead'] &&
                $db->dblogic($userRoleSpecialRights['bdc_lead_creation_redirect_to_lead'])
            ) {
                $redirectToLeadAfterLeadCreation = true;
            }
        }
    }
    
    if ($cfg_avag_de && !empty($_SESSION['AVAG_KFZSUCHE_REMEMBER_CAR_VIN'])) {
        $car = (new Car_Data())
            ->getByConditions(['fahrgestell' => $_SESSION['AVAG_KFZSUCHE_REMEMBER_CAR_VIN']]);
        if ($car[0]['produktzuordnung_id']) {
            $rememberedCarId = $car[0]['produktzuordnung_id'];
        }
    }
}


if (
    isset($_GET['product_id'], $_GET['action']) &&
    $_GET['product_id'] &&
    $_GET['action'] === 'get_product_responsibility_info'
) {
    $productData = new Product_Data($_GET['product_id']);
    $productData->load(array('gruppe_id'));
    $productGroupId = $productData['gruppe_id'];
    if (empty($productGroupId)) {
        Modern_Helper_Request::requestStart();
        Modern_Helper_Request::sendResponseJson(
            array(
                "status" => "error",
                "message" => "No product group id found"
            )
        );
    }
    
    $userData = new User_Data();
    $users = $userData->getByConditions(
        null,
        '',
        '',
        'AND',
        array(
            'vorname',
            'name',
            'besonderes_recht'
        )
    );
    $responsibleUserNames = $knowledgeableUserNames = array();
    foreach ($users as $user) {
        $specialRights = $user['besonderes_recht'] = $user['besonderes_recht'] ? unserialize($user['besonderes_recht']) : array();
        if (count($specialRights) === 0) {
            continue;
        }
        if (empty($specialRights['p4n_verantwortlich']) && empty($specialRights['p4n_auskennen'])) {
            continue;
        }
        
        if (in_array($productGroupId, $specialRights['p4n_verantwortlich'])) {
            $responsibleUserNames[] = json_encode_utf8("{$user['vorname']}, {$user['name']}");
        }
        
        if (in_array($productGroupId, $specialRights['p4n_auskennen'])) {
            $knowledgeableUserNames[] = json_encode_utf8("{$user['vorname']}, {$user['name']}");
        }
    }

    if (empty($responsibleUserNames) && empty($knowledgeableUserNames)) {
        Modern_Helper_Request::requestStart();
        Modern_Helper_Request::sendResponseJson(
            array(
                "status" => "error",
                "message" => "No responsible or knowledgeable users found"
            )
        );
    }
    
    $data = array(
        'status' => 'success',
        'responsible_user_names' => $responsibleUserNames,
        'kowledgeable_user_names' => $knowledgeableUserNames
    );

    Modern_Helper_Request::requestStart();
    Modern_Helper_Request::sendResponseJson($data);
}

if (
    isset($_GET['product_id'], $_GET['action']) &&
    $_GET['product_id'] &&
    $_GET['action'] === 'get_product_teams_link'
) {
    $productData = new Product_Data($_GET['product_id']);
    $productData->load(array('mengeneinheit'));
    $productTeamsLink = $productData['mengeneinheit'];
    if (empty($productTeamsLink)) {
        Modern_Helper_Request::requestStart();
        Modern_Helper_Request::sendResponseJson(
            array(
                "status" => "error",
                "message" => "No product teams link found"
            )
        );
    }
    
    $data = array(
        'status' => 'success',
        'teams_link' => $productTeamsLink
    );
    
    Modern_Helper_Request::requestStart();
    Modern_Helper_Request::sendResponseJson($data);
}

if (
    isset($_GET['product_id'], $_GET['action']) &&
    $_GET['product_id'] &&
    $_GET['action'] === 'get_product_form_link_availability'
) {
    $productData = new Product_Data($_GET['product_id']);
    $productData->load(array('artikelnr'));
    $productFormIds = $productData['artikelnr'];
    if (empty($productFormIds)) {
        Modern_Helper_Request::requestStart();
        Modern_Helper_Request::sendResponseJson(
            array(
                "status" => "error",
                "message" => "No product forms found"
            )
        );
    }
    
    $data = array(
        'status' => 'success',
        'params' => 'product_id='.$_GET['product_id'].'&action=product_forms'
    );
    
    Modern_Helper_Request::requestStart();
    Modern_Helper_Request::sendResponseJson($data);
}

if (
    isset($_GET['product_id'], $_GET['action']) &&
    $_GET['product_id'] &&
    $_GET['action'] === 'product_forms'
) {
    Modern_Helper_Request::requestStart();
   
    $productData = new Product_Data($_GET['product_id']);
    $productData->load(array('artikelnr', 'bezeichnung'));
    $productFormIds = $productData['artikelnr'];
    if (empty($productFormIds)) {
        Modern_Helper_Request::requestStart();
        Modern_Helper_Request::sendResponseJson(
            array(
                "status" => "error",
                "message" => "No product forms found"
            )
        );
    }
    
    $productFormIds = explode(';', $productFormIds);
    $forms = (new Form_Data())
        ->getByConditions(
            ['formular_id' => $productFormIds],
            '',
            '',
            'AND',
            ['bezeichnung', 'formular_id']
        );
    
    $formLinks = [];
    foreach ($forms as $form) {
        $formLink = new Template_Tooltip(
            $form['bezeichnung'],
            (new Template_Button(
                '',
                abkuerzung($form['bezeichnung'], 30),
                '',
                '',
                '',
                '',
                'xs',
                'darkgrey-outline',
                'quadratic'
            ))->addCustomClass('w-100')
        );
        $formLink->setRequest(
            'GET',
            $modal_utility_level_2_content,
            'stammdaten_main.php',
            'nav=FM&neuf='.$form['formular_id'].'&no_redirect=1&form_target=hidden_elementlist',
            $modal_utility_level_2
        );
        $formLinks[] = $formLink;
    }
    
    $content = Template_Default::Card(
        _FORMULARE_,
        null,
        new Template_GridTable($formLinks, true, 3)
    );
    
    echo Template_Default::ModalHeader(['Service-Leitfaden', $productData['bezeichnung']])->getHtml();
    echo $content->getHtml();
    
    exit;
}

if (isset($_GET['bdc_dummy'])) {

    $nur_includen=true;
    include('serviceannahme.php');

    $feld['kname']='';
    $feld['bdc']=1;

    $_GET['stid']=sc_eintrag_neu($feld);
}

$bdc_einstellungen=getBdcEinstellungen();

$recht_kfz_schnellsuche=false;
include_once ('inc/utilities.php');
if (hasRight($_SESSION['user_id'], 'kfz_schnellsuche.php')) {
    $recht_kfz_schnellsuche=true;
}

if ($_SESSION['crm_version']>64 || $cfg_avag_de || $cfg_avag_at) {
    if (!isset($cfg_bdc_kanal)) {
        $cfg_bdc_kanal = true;
    }
}

if (isset($_POST['tenios'])) {//number is expected in get
    $_GET['tenios']=$_POST['tenios'];
}

if (isset($_POST['cti_fremd_id'])) {
    $_GET['cti_fremd_id']=$_POST['cti_fremd_id'];
}

if (isset($_GET['cti_fremd_id'])) {
    $ctiRes = $db->select(
        $sql_tab['cti_schnittstelle_daten'],
        array(
            $sql_tabs['cti_schnittstelle_daten']['cti_schnittstelle_daten_id'],
            $sql_tabs['cti_schnittstelle_daten']['daten']
        ),
        $sql_tabs['cti_schnittstelle_daten']['cti_fremd_id'].'='.$db->str($_GET['cti_fremd_id'])
    );
    $ctiData=array();
    if ($ctiRow = $db->zeile($ctiRes)) {
        $ctiData=json_decode($ctiRow['1'], true);
    }
    if (isset($ctiData['origin_number'])) {
        $_GET['tenios']=$ctiData['origin_number'];
    }
    if (isset($ctiData['duration'])) {
        $_POST['ctiCallDuration']=$ctiData['duration'];
    }
    if (isset($ctiData['notice']['nr'])) {
         $_GET['telefon_privat']=$ctiData['notice']['nr'];
    }
}

if ($_GET['tenios_external_number']) {
    $_GET['tenios']=$cfg_tenios_external_number;
}

$teniosLeadpool=false;
$teniosBetreuer=-1;

if ($_GET['tenios']!='') {
    $_GET['goto']='lead';
    $res = $db->select(
        $sql_tab['einstellungen'],
        $sql_tabs['einstellungen']['wert'],
        $sql_tabs['einstellungen']['modul'].'='.$db->str('Tenios')
    );
    $teniosData=array();
    if ($row = $db->zeile($res)) {
        $arr = unserialize($row[0]);
        if (is_array($arr)) {
            if (!empty($arr['numbers'][$_GET['tenios']])) {
                $teniosData=$arr['numbers'][$_GET['tenios']];
                
                if ($teniosData['bdc_supervisor']=='currentUser') {
                    $teniosBetreuer=$_SESSION['user_id'];
                } elseif ($teniosData['bdc_supervisor']=='leadpool') {
                    $teniosLeadpool=true;
                }
                
                /*if (isset($teniosData['bdc_goto']) && $teniosData['bdc_goto']!='' ) {
                    $_GET['goto']=$teniosData['bdc_goto'];
                }*/
            }
        }
    }
}

//allg. Einstellung Bdc Lead Settings
if (isset($_POST['startSetting'])) {
    $_GET['startSetting']=$_POST['startSetting'];
}
$bdcDataSetter=new bdcDataSetter();
$bdcSettings=$bdcDataSetter->getData();
if ($_GET['startSetting']) {
    $postfeld['form_kunde_standort']=$_SESSION['user_standard_lagerort'];
    $_GET['goto']='lead';
    if (!empty($bdcSettings['numbers'][$_GET['startSetting']])) {
        $teniosData=$bdcSettings['numbers'][$_GET['startSetting']];
		foreach ($teniosData as $tkey => $tval) {
			if ($tval=='') {
				unset($teniosData[$tkey]);
			}
		}
        if ($teniosData['bdc_supervisor']=='currentUser') {
            $teniosBetreuer=$_SESSION['user_id'];
        } elseif ($teniosData['bdc_supervisor']=='leadpool') {
            $teniosLeadpool=true;
        }
    }
}
if (isset($_GET['goto'])) {
    $_SESSION['bdc_goto']=$_GET['goto'];
}
if ($_SESSION['bdc_goto']!='') {
    $_GET['goto']=$_SESSION['bdc_goto'];
}

if (isset($_GET['form_kunde_ansprechpartner_id'])) {
    $_POST['form_kunde_ansprechpartner_id']=$_GET['form_kunde_ansprechpartner_id'];
}
if ($_POST['form_kunde_ansprechpartner_id']) {
    $_SESSION['bdcSelectedAp']=$_POST['form_kunde_ansprechpartner_id'];
} elseif ($_SESSION['bdcSelectedAp']>0) {
    $_POST['form_kunde_ansprechpartner_id']=$_SESSION['bdcSelectedAp'];
    $_GET['form_kunde_ansprechpartner_id']=$_SESSION['bdcSelectedAp'];
}
$result_einstellungen = $db->select(
    $sql_tab['einstellungen'],
    $sql_tabs['einstellungen']['wert'],
    $sql_tabs['einstellungen']['modul'].'='.$db->str('bdc_pflichtfelder')
);

if (!isset($cfg_bdc_pflichtfelder)) {
    $cfg_bdc_pflichtfelder=array();
}
$pflicht_lead_array = array();
if ($row_einstellungen = $db->zeile($result_einstellungen)) {
    $cfg_bdc_pflichtfelder=unserialize(base64_decode($row_einstellungen[0]));
} else {
    $pflicht_anfragen_array = array();
    if ($cfg_leadmanagement_2020) {
        $pflicht_lead_array = array('form_lead_kampagne' => array('-1', '', '-99'));
    } else {
        $pflicht_lead_array = array();
    }

    if (!in_array('form_anfrage_benutzer', $cfg_bdc_pflichtfelder)) {
        $cfg_bdc_pflichtfelder[] = 'form_anfrage_benutzer';
    }
    if (!in_array('form_beschwerde_benutzer', $cfg_bdc_pflichtfelder)) {
        $cfg_bdc_pflichtfelder[] = 'form_beschwerde_benutzer';
    }

    if (($_SESSION['crm_version']>61 or $cfg_bdc_grund)) {
        if (!in_array('form_lead_grund', $cfg_bdc_pflichtfelder)) {
            $cfg_bdc_pflichtfelder[] = 'form_lead_grund';
        }
        if (!in_array('form_anfrage_grund', $cfg_bdc_pflichtfelder)) {
            $cfg_bdc_pflichtfelder[] = 'form_anfrage_grund';
        }
        if (!in_array('form_beschwerde_grund', $cfg_bdc_pflichtfelder)) {
            $cfg_bdc_pflichtfelder[] = 'form_beschwerde_grund';
        }
        if (!in_array('form_sonstiges_grund', $cfg_bdc_pflichtfelder)) {
            $cfg_bdc_pflichtfelder[] = 'form_sonstiges_grund';
        }
    }
    if ($cfg_avag_at || $cfg_avag_de) {
        if (!in_array('form_sonstiges_standort', $cfg_bdc_pflichtfelder)) {
            $cfg_bdc_pflichtfelder[] = 'form_sonstiges_standort';
        }
    }
    if (!$nora and !empty($cfg_bm_kategorien2)) {
        if (!in_array('form_beschwerde_kategorie2', $cfg_bdc_pflichtfelder)) {
            $cfg_bdc_pflichtfelder[] = 'form_beschwerde_kategorie2';
        }
    }
    $db->insert(
        $sql_tab['einstellungen'],
        array(
            $sql_tabs['einstellungen']['wert'] => $db->str(base64_encode(serialize($cfg_bdc_pflichtfelder))),
            $sql_tabs['einstellungen']['modul'] => $db->str('bdc_pflichtfelder')
        )
    );
}
if (!empty($cfg_bm_ticketpool)) {
    if (($key = array_search('form_anfrage_benutzer', $cfg_bdc_pflichtfelder)) !== false) {
        unset($cfg_bdc_pflichtfelder[$key]);
    }
    if (($key = array_search('form_beschwerde_benutzer', $cfg_bdc_pflichtfelder)) !== false) {
        unset($cfg_bdc_pflichtfelder[$key]);
    }
}
if ($_SESSION['cfg_kunde']=='carlo_opel_dechent') {
    $cfg_bdc_pflichtfelder[]='form_anfrage_email2';
    $cfg_bdc_pflichtfelder[]='form_beschwerde_email2';  
}
$pflicht_bm_array = array();
$pflicht_sonstiges_array = array();
if (!empty($cfg_bdc_pflichtfelder)) {
    foreach ($cfg_bdc_pflichtfelder as $pflichtfelder) {
        $type_explode = explode('_', $pflichtfelder);
        if ($type_explode[1]=='lead') {
            $pflicht_lead_array[$pflichtfelder] = array('-1', '', '-99');
        } elseif ($type_explode[1]=='anfrage') {
            $pflicht_anfragen_array[$pflichtfelder] = array('-1', '', '-99');
        } elseif ($type_explode[1]=='beschwerde') {
            $pflicht_bm_array[$pflichtfelder] = array('-1', '', '-99');
        } elseif ($type_explode[1]=='sonstiges') {
            $pflicht_sonstiges_array[$pflichtfelder] = array('-1', '', '-99');
        }
    }
}
if (isset($_POST['reloadfahrzeugselect'])) {
    if (!$form) {
        $form=new htmlform();
    }
    Modern_Helper_Request::requestStart();
    
    
    $res=$db->select(
        $sql_tab['produktzuordnung'],
            array($sql_tabs['produktzuordnung']['produktzuordnung_id'],//0
        $sql_tabs['produktzuordnung']['kennzeichen'],//1
        $sql_tabs['produktzuordnung']['typ_modell'],//2
        $sql_tabs['produktzuordnung']['datum_ez'],//3
        $sql_tabs['produktzuordnung']['datum_tuev'],//4
        $sql_tabs['produktzuordnung']['datum_asu'],//5
        $sql_tabs['produktzuordnung']['fahrgestell']),//6
            $sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($_POST['reloadfahrzeugselect'])
    );
    if ($row=$db->zeile($res)) {
        $fahrzeuglink[$row[0]]=$row[2];
        echo'<option value="'.$row[0].'">'._KFZ_SUCHE_.': '.$row[2].'</option>';
    }
   
  
   // echo $form->selectinput($_POST['formele'], $fahrzeuglink, $_POST['reloadfahrzeugselect'], false,' class="bdcpool" data-bdcpool-name="fahrzeug"');
    Modern_Helper_Request::requestFlush();
    exit;
}
$statusfeld[1]=_BM_STATUS1_;
$statusfeld[2]=_BM_STATUS2_;
$statusfeld[3]=_BM_STATUS3_;
$statusfeld[4]=_BM_STATUS4_;
if (isset($cfg_beschwerde_statusfeld2)) {
    if (is_array($cfg_beschwerde_statusfeld2)) {
        if (count($cfg_beschwerde_statusfeld2)>1) {
            $statusfeld=$cfg_beschwerde_statusfeld2;
        }
    }
}

if (isset($_POST['eva']) && $_POST['eva']!='') {
    $_GET['eva']=$_POST['eva'];
}

if (isset($_POST['ohnecc']) && $_POST['ohnecc']!='') {
    $_GET['ohnecc']=$_POST['ohnecc'];
}


$postfeld=$_POST;
$getfeld=$_GET;
$files=$_FILES;

if (isset($getfeld['aus_startportal'])) {
	foreach($getfeld as $skey => $sval) {
		$postfeld[$skey]=$sval;
	}
}

function strReplaceInputs($html, $arr, $arr_pflicht=array()) {
    foreach ($arr as $key => $value) {
        if (isset($_GET['configure_required_fields']) && $_GET['configure_required_fields']==1) {
            $html=p4n_mb_string('str_replace','{'.$key.'}', $value.(isset($arr_pflicht[$key]) ? '<span class="required"></span>' : ''), $html);
        }
        else {
            $html=p4n_mb_string('str_replace','{'.$key.'}', $value.(isset($arr_pflicht[$key]) ? '*' : ''), $html);
        }
    }
    return $html;
}

$rechte_=array();
if (file_exists('inc/Rights/MenuPoint.php') && isset($sql_tabs['benutzer_rolle']['besonderes_recht'])) {
    $menuRights = new Rights_MenuPoint('bdc.php');
    $rechte_=$menuRights->getConfigurationFromUser($user_id);
}
if ($cfg_bdc_pool===true) {
    if (!array_key_exists('bdc_pool', $rechte_)) {
        $cfg_bdc_pool=false;
    }
}

if (isset($postfeld['form_einstellungen_submit'])) {
    
    if ($_SESSION['crm_version']>62) {
        $alle_bdc_gruende=array();
        if (is_array($postfeld['bgrp'])) {
            foreach($postfeld['bgrp'] as $key => $value) {
                $alle_bdc_gruende[$key]=array('bgrp'=>$postfeld['bgrp'][$key],'bgrp_grund'=>$postfeld['bgrp_grund'][$key]);
            }
        }
    }
    
    $bdc_einstellungen_post=array(
        'absender'=>$postfeld['form_einstellungen_absender'],
        'absendername'=>$postfeld['form_einstellungen_absendername'],
        'vorlage1'=>$postfeld['form_einstellungen_vorlage1'],
        'vorlage2'=>$postfeld['form_einstellungen_vorlage2'],
        'vorlage3'=>$postfeld['form_einstellungen_vorlage3'],
        'grund'=>$alle_bdc_gruende,
        'name'=>$postfeld['form_einstellungen_name'],
        'moredetails'=>$postfeld['form_einstellungen_moredetails'],
    );
    $bdc_kanal_einstellung = false;
    if (isset($postfeld['form_einstellungen_lead_kanal'])) {
        $bdc_kanal_einstellung = true;
    }
    if (isset($postfeld['form_einstellungen_lead_kanal_def'])) {
		if ($postfeld['form_einstellungen_lead_kanal_def']=='-1') {
			$postfeld['form_einstellungen_lead_kanal_def']='';
		}
        $bdc_einstellungen_post['lead_kanal_def']=$postfeld['form_einstellungen_lead_kanal_def'];
    }
    $bdc_quelle_einstellung = false;
    if (isset($postfeld['form_einstellungen_lead_quelle'])) {
        $bdc_quelle_einstellung = true;
    }
    $bdc_marke_einstellung = false;
    if (isset($postfeld['form_einstellungen_lead_marke'])) {
        $bdc_marke_einstellung = true;
    }
    $bdc_art_einstellung = false;
    if (isset($postfeld['form_einstellungen_lead_art'])) {
        $bdc_art_einstellung = true;
    }
    $bdc_fahrzeug_einstellung = false;
    if (isset($postfeld['form_einstellungen_lead_fahrzeug'])) {
        $bdc_fahrzeug_einstellung = true;
    }
    $bdc_einstellungen_post['lead_kanal'] = $bdc_kanal_einstellung;
    $bdc_einstellungen_post['lead_quelle'] = $bdc_quelle_einstellung;
    $bdc_einstellungen_post['lead_marke'] = $bdc_marke_einstellung;
    $bdc_einstellungen_post['lead_art'] = $bdc_art_einstellung;
    $bdc_einstellungen_post['lead_fahrzeug'] = $bdc_fahrzeug_einstellung;
    
    $bdc_absatzgruppe_einstellung = false;
    if (isset($postfeld['form_einstellungen_lead_absatzgruppe'])) {
        $bdc_absatzgruppe_einstellung = true;
    }
    if ($cfg_lead_absatzgruppe || $_SESSION['crm_version_float']>=61300) {
        $bdc_einstellungen_post['lead_absatzgruppe'] = $bdc_absatzgruppe_einstellung;
    }
    
    $bdc_neuanlage_anrede_pfl = false;
    if (isset($postfeld['form_einstellungen_pflicht_anrede'])) {
        $bdc_neuanlage_anrede_pfl = true;
    }
    $bdc_neuanlage_vorname_pfl = false;
    if (isset($postfeld['form_einstellungen_pflicht_vorname'])) {
        $bdc_neuanlage_vorname_pfl = true;
    }
    $bdc_neuanlage_name_pfl = false;
    if (isset($postfeld['form_einstellungen_pflicht_name'])) {
        $bdc_neuanlage_name_pfl = true;
    }
    $bdc_neuanlage_firma_pfl = false;
    if (isset($postfeld['form_einstellungen_pflicht_firma'])) {
        $bdc_neuanlage_firma_pfl = true;
    }
    $bdc_neuanlage_telemail_pfl = false;
    if (isset($postfeld['form_einstellungen_pflicht_telemail'])) {
        $bdc_neuanlage_telemail_pfl = true;
    }
    $bdc_einstellungen_post['neuanlage_pflicht']['anrede'] = $bdc_neuanlage_anrede_pfl;
    $bdc_einstellungen_post['neuanlage_pflicht']['vorname'] = $bdc_neuanlage_vorname_pfl;
    $bdc_einstellungen_post['neuanlage_pflicht']['name'] = $bdc_neuanlage_name_pfl;
    $bdc_einstellungen_post['neuanlage_pflicht']['firma'] = $bdc_neuanlage_firma_pfl;
    $bdc_einstellungen_post['neuanlage_pflicht']['telemail'] = $bdc_neuanlage_telemail_pfl;
    
    $res=$db->select(
        $sql_tab['einstellungen'],
        $sql_tabs['einstellungen']['wert'],
        $sql_tabs['einstellungen']['modul'].'='.$db->str('bdc_einstellungen')
    );
    if ($row=$db->zeile($res)) {
        $bdc_einstellungen_post_ursprung= unserialize($row[0]);
        if ($_SESSION['design_70']) {
            $bdc_einstellungen_post_ursprung['absender']=$bdc_einstellungen_post['absender'];
            $bdc_einstellungen_post_ursprung['absendername']=$bdc_einstellungen_post['absendername'];
            $bdc_einstellungen_post_ursprung['vorlage1']=$bdc_einstellungen_post['vorlage1'];
            $bdc_einstellungen_post_ursprung['vorlage2']=$bdc_einstellungen_post['vorlage2'];
            $bdc_einstellungen_post_ursprung['vorlage3']=$bdc_einstellungen_post['vorlage3'];
            $bdc_einstellungen_post=$bdc_einstellungen_post_ursprung;
        }
        $db->update(
        $sql_tab['einstellungen'], array(
            $sql_tabs['einstellungen']['wert'] => $db->str(serialize($bdc_einstellungen_post))
        ),$sql_tabs['einstellungen']['modul'].'='.$db->str('bdc_einstellungen')
        );
    } else {
        if ($_SESSION['design_70']) {
            $bdc_einstellungen_post=array(
                'absender'=>$postfeld['form_einstellungen_absender'],
                'absendername'=>$postfeld['form_einstellungen_absendername'],
                'vorlage1'=>$postfeld['form_einstellungen_vorlage1'],
                'vorlage2'=>$postfeld['form_einstellungen_vorlage2'],
                'vorlage3'=>$postfeld['form_einstellungen_vorlage3'],
            );
        }
        $db->insert(
            $sql_tab['einstellungen'], array(
                $sql_tabs['einstellungen']['modul'] => $db->str('bdc_einstellungen'),
                $sql_tabs['einstellungen']['wert'] => $db->str(serialize($bdc_einstellungen_post))
            )
        );
    }
    $bdc_einstellungen=getBdcEinstellungen();
}

function av_telnr_ch_sub_Bdc () {
    global $alle_av_telf;
	$anz=0;
	if (is_array($alle_av_telf)) {
		foreach ($alle_av_telf as $keyf => $valf) {
            $jst.='var telAvagTest=$("#form_kunde_suche_table input[name=\''.$keyf.'\']"); ';
            //$jst.='console.log(telAvagTest.val());';
			$jst.='if (typeof telAvagTest==\'object\') { if (telAvagTest.val()!=\'\' && !telAvagTest.val().match(/^\+\d+\s{0,1}\d+\s{0,1}\d+$/)) { 
               message="'.$valf.'<br>";
               focus_red(telAvagTest); }} ';
			$anz++;
		}
	}
	return $jst;
}      
$alle_av_telf=array();
$telzus='';
if ($cfg_avag_telnr_check) {
    $telzus.='<img src="img/link_ask.gif" class="overlib" '.av_telnr_ch_ol().'>';
    $alle_av_telf['form_kunde_telefon_privat']=$lang['_ADMINBENUTZER-TELEFON_'];
    $alle_av_telf['form_kunde_telefon_ges']=$lang['_ADMINBENUTZER-TELEFON_'];
    $alle_av_telf['form_kunde_mobil_privat']=_MOBILFON_;
    $alle_av_telf['form_kunde_mobil_ges']=_MOBILFON_;
}
$zus_submit2='';
if ($cfg_avag_telnr_check) {
    $zus_submit2.=av_telnr_ch_sub_Bdc();
}
echo javas('
    function check_name_pflicht() {
        var message="";
        var anrede_obj = $("#form_kunde_suche_table select[name=\'form_kunde_anrede\']");
        var name_obj=$("#form_kunde_suche_table input[name=\'form_kunde_name\']");
        var vorname_obj=$("#form_kunde_suche_table input[name=\'form_kunde_vorname\']");
        var firma_obj=$("#form_kunde_suche_table input[name=\'form_kunde_firma\']");
		
		var tel1_obj=$("#form_kunde_suche_table input[name=\'form_kunde_telefon_privat\']");
		var tel2_obj=$("#form_kunde_suche_table input[name=\'form_kunde_telefon_ges\']");
		var tel3_obj=$("#form_kunde_suche_table input[name=\'form_kunde_mobil_privat\']");
		var tel4_obj=$("#form_kunde_suche_table input[name=\'form_kunde_mobil_ges\']");
		var tel5_obj=$("#form_kunde_suche_table input[name=\'form_kunde_t_alternativ\']");
		
		var email1_obj=$("#form_kunde_suche_table input[name=\'form_kunde_email_privat\']");
		var email2_obj=$("#form_kunde_suche_table input[name=\'form_kunde_email_ges\']");
		'.$zus_submit2.'
        if (anrede_obj.val()=="'._FIRMA_.'") {
            if (firma_obj.val()=="" && "'.$bdc_einstellungen['neuanlage_pflicht']['firma'].'"=="1") {
                message+="'._FIRMA_.'<br>";
                focus_red(firma_obj);
            }
			if (tel1_obj.val()=="" && tel2_obj.val()=="" && tel3_obj.val()=="" && tel4_obj.val()=="" && tel5_obj.val()=="" && email1_obj.val()=="" && email2_obj.val()=="" && "'.$bdc_einstellungen['neuanlage_pflicht']['telemail'].'"=="1") {
                message+="'._TELEFON2_.' '._ODER_.' '._EMAIL_.'<br>";
                focus_red(tel2_obj);
                focus_red(email2_obj);
            }
        } else {
            if (anrede_obj.val()=="" && "'.$bdc_einstellungen['neuanlage_pflicht']['anrede'].'"=="1") {
                message+="'._ANREDE_.'<br>";
                focus_red(anrede_obj);
            }
            if (vorname_obj.val()=="" && "'.$bdc_einstellungen['neuanlage_pflicht']['vorname'].'"=="1") {
                message+="'._VORNAME_.'<br>";
                focus_red(vorname_obj);
            }
            if (name_obj.val()=="" && "'.$bdc_einstellungen['neuanlage_pflicht']['name'].'"=="1") {
                message+="'._NAME_.'<br>";
                focus_red(name_obj);
            }
			
			if (tel1_obj.val()=="" && tel2_obj.val()=="" && tel3_obj.val()=="" && tel4_obj.val()=="" && tel5_obj.val()=="" && email1_obj.val()=="" && email2_obj.val()=="" && "'.$bdc_einstellungen['neuanlage_pflicht']['telemail'].'"=="1") {
                message+="'._TELEFON2_.' '._ODER_.' '._EMAIL_.'<br>";
                focus_red(tel1_obj);
                focus_red(email1_obj);
            }
			
        }

        return message;
    }
');
$grund_selected=-1;
if ($cfg_bdc_nl || $_SESSION['crm_version']>61 or $cfg_bdc_grund) {
    $alle_bdc_gruende=array();
    $res=$db->select(
        $sql_tab['kategorie'],
        array(
            $sql_tabs['kategorie']['kategorie_id'],
            $sql_tabs['kategorie']['bezeichnung'],
            $sql_tabs['kategorie']['rang']
        ),
        $sql_tabs['kategorie']['modul'].'='.$db->dbzahl(39),
        $sql_tabs['kategorie']['rang'].' asc, '.$sql_tabs['kategorie']['bezeichnung'].' asc'
    );
    while ($row=$db->zeile($res)) {
        if (($row[2]===0 || $row[2]==='0')) {
            $grund_selected=$row[1];
        }
        $alle_bdc_gruende[$row[1]]=$row[1];
    }
}
$bdc_kanaele = array();
$keine_bdckanal_vorauswahl=false;
if ($cfg_bdc_kanal_keinevorauswahl) {
	$bdc_kanaele[-1] = _KEINE_AUSWAHL_;
} else {
	if (is_array($cfg_bdc_pflichtfelder) and in_array('form_lead_bdc_kanal', $cfg_bdc_pflichtfelder)) {
		$keine_bdckanal_vorauswahl=true;
	}
	if (is_array($cfg_bdc_pflichtfelder) and in_array('form_anfrage_bdc_kanal', $cfg_bdc_pflichtfelder)) {
		$keine_bdckanal_vorauswahl=true;
	}
	if (is_array($cfg_bdc_pflichtfelder) and in_array('form_beschwerde_bdc_kanal', $cfg_bdc_pflichtfelder)) {
		$keine_bdckanal_vorauswahl=true;
	}
	if (is_array($cfg_bdc_pflichtfelder) and in_array('form_sonstiges_bdc_kanal', $cfg_bdc_pflichtfelder)) {
		$keine_bdckanal_vorauswahl=true;
	}
}
if ($_SESSION['design_70']) {
    $keine_bdckanal_vorauswahl=true;
}

$bdc_kanal_selected = -1;
if ($cfg_bdc_kanal) {
    $result_kategorie = $db->select(
        $sql_tab['kategorie'],
        $sql_tabs['kategorie']['bezeichnung'],
        $sql_tabs['kategorie']['modul'].'='.$db->dbzahl(61),
        $sql_tabs['kategorie']['rang'].' ASC,'.$sql_tabs['kategorie']['bezeichnung'].' ASC'
    );
    while ($row_kategorie = $db->zeile($result_kategorie)) {
        $bdc_kanaele[$row_kategorie[0]] = $row_kategorie[0];
        if (!$keine_bdckanal_vorauswahl and !$cfg_bdc_kanal_keinevorauswahl and $bdc_kanal_selected == -1) {
            $bdc_kanal_selected = $row_kategorie[0];
        }
    }
}

if ($_SESSION['crm_version']>62 || $_SESSION['cfg_kunde']=='carlo_opel_asag') {
    $benutzergrp=array();
    $res_grp=$db->select($sql_tab['benutzer_gruppe'],
        array(
            $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
            $sql_tabs['benutzer_gruppe']['bezeichnung'],
            $sql_tabs['benutzer_gruppe']['rang'],
            $sql_tabs['benutzer_gruppe']['email']
        ),
        '',
        $sql_tabs['benutzer_gruppe']['rang']
    );
    while ($row_grp = $db->zeile($res_grp)) {
        $benutzergrp[$row_grp[0]]=$row_grp[1];
    }   
    $benutzer_grps_bdc=array();
    if (is_array($bdc_einstellungen['grund'])) {
        foreach ($bdc_einstellungen['grund'] as $key => $val) {
           $benutzer_grps_bdc[$val['bgrp']]=$val['bgrp_grund'];
        }
    }

    $drin=false;
    $benutzer_grps=explode(',',$_SESSION['rechte_bgruppen']);
    if (is_array($benutzer_grps)) {
        foreach ($benutzergrp as $key => $val) {
            if ($drin) {
               continue; 
            }
            if (in_array($key,$benutzer_grps) && array_key_exists($key,$benutzer_grps_bdc)) {
                $grund_selected=$benutzer_grps_bdc[$key];
                $grund_selected2=$benutzer_grps_bdc[$key];
                $drin=true;
                continue;
            }
        }
    }
}

$cti_bdcvorlagen = array();
if ($cfg_cti_bdcvorauswahl) {
    $result_einstellungen = $db->select(
        $sql_tab['einstellungen'],
        $sql_tabs['einstellungen']['wert'],
        $sql_tabs['einstellungen']['modul'].'='.$db->str('cti_bdcvorlagen')
    );
    if ($row_einstellungen = $db->zeile($result_einstellungen)) {
        if ($row_einstellungen[0]!='') {
            $cti_bdcvorlagen_unser = unserialize($row_einstellungen[0]);
            if (is_array($cti_bdcvorlagen_unser)) {
                foreach ($cti_bdcvorlagen_unser as $arr) {
                    $cti_bdcvorlagen[$arr['sip_cti_ruf']]=$arr;
                }
            }
        }
    }
}
$selected_kamp=-99;
if (isset($_GET['sip_cti_ruf_line']) && $_GET['sip_cti_ruf_line']!='') {
    //$_GET['sip_cti_ruf_line'] = '+'.trim($_GET['sip_cti_ruf_line'], '+');
    $temp_sip_cti=array();
    if ($cti_bdcvorlagen[$_GET['sip_cti_ruf_line']]) {
        $temp_sip_cti=$cti_bdcvorlagen[$_GET['sip_cti_ruf_line']];
    } elseif($cti_bdcvorlagen['alle']) {
        $temp_sip_cti=$cti_bdcvorlagen['alle'];
    }
    if ($temp_sip_cti['sip_cti_grund']!=-1 && $temp_sip_cti['sip_cti_grund']!='') {
        $grund_selected=$temp_sip_cti['sip_cti_grund'];
    }
    if (intval($temp_sip_cti['sip_cti_kamp'])>0) {
        $selected_kamp=$temp_sip_cti['sip_cti_kamp'];
    }
    if (intval($temp_sip_cti['sip_cti_lag'])>0) {
        $postfeld['form_kunde_standort']=$temp_sip_cti['sip_cti_lag'];
    } 
}

if ($cfg_stammdaten_lead && empty($grund_selected2) && (!isset($_GET['sip_cti_ruf_line']) || $_GET['sip_cti_ruf_line']=='')) {
    $grund_selected_lead='Lead';
}

if (isset($_GET['bdc_einstellungen']) && (array_key_exists('bdc_einstellungen', $rechte_))) {
    $temp = new Modern_Template_SubMenu();
    $temp->setLinkBack($phs);
    
    if ($inhalt=template('template/bdc_einstellungen.html')) {
        
        if ($_SESSION['crm_version']>62 || (p4n_mb_string('substr', $_SESSION['cfg_kunde'], 0, p4n_mb_string('strlen', 'carlo_opel_avag'))=='carlo_opel_avag')) {} else {
            $inhalt= preg_replace('/\<\!version_avag_1\>.*\<\!version_avag_2\>/Uis','',$inhalt);
        }
        $inhalt= p4n_mb_string('str_replace',array('<!version_avag_1>','<!version_avag_2>'),'',$inhalt);
        
        if ($_SESSION['crm_version']>68 || $cfg_bdc_pflichtfelder_setting) {
            
        } else {
            $inhalt= preg_replace('/\<\!version69_1\>.*\<\!version69_2\>/Uis','',$inhalt);
        }
        $inhalt= p4n_mb_string('str_replace',array('<!version69_1>','<!version69_2>'),'',$inhalt);
        
        $kvorlagen_feld = array(-1=>_KEINE_AUSWAHL_);
        $where_temp = '';
        $sortorder = $sql_tabs['email_vorlagen']['bezeichnung'];
        if ($_SESSION['crm_version'] > 56) {
            $where_temp = $sql_tabs['email_vorlagen']['inaktiv'].'!='.$db->dblogic(true).' OR '.
                          $sql_tabs['email_vorlagen']['inaktiv'].' IS NULL';
            $sortorder = 'CASE WHEN '.$sql_tabs['email_vorlagen']['rang'].'=0 THEN 1 ELSE 0 END , '.$sql_tabs['email_vorlagen']['rang'].','.$sortorder;
        }
        $sql_tabsemail = array(
                $sql_tabs['email_vorlagen']['email_vorlagen_id'],
                $sql_tabs['email_vorlagen']['bezeichnung'],
                $sql_tabs['email_vorlagen']['htmltext']
        );
        if (isset($sql_tabs['email_vorlagen']['kategorie'])) {
            $sql_tabsemail[] = $sql_tabs['email_vorlagen']['kategorie'];
            $sortorder = $sql_tabs['email_vorlagen']['kategorie'].','.$sortorder;
            $where_temp = ($where_temp ? '('.$where_temp.') AND ' : '').$sql_tabs['email_vorlagen']['kategorie'].'!='.$db->str('_ADMINBENUTZER-SIGNATUR_');
        }
        // --> vers. 5.7 - 19.04.2016
        $res2=$db->select(
            $sql_tab['email_vorlagen'],
            $sql_tabsemail,
            $where_temp,
            $sortorder
        );
        while ($row2 = $db->zeile($res2)) {
            $neuereditor_verbergen = false;
            $treffer = array();
            preg_match_all("/{editor}(.*){editor}/", $row2[2], $treffer);
            if (!$cfg_newsletterbaukasten_p4n and !$cfg_newsletterbaukasten_2_p4n and count($treffer[0]) > 0) {
                $neuereditor_verbergen = true;
            }
            if (!$neuereditor_verbergen) {
                // vers. 5.7 - 19.04.2016 -->
                if ($_SESSION['crm_version'] > 56) {
                    $kategor = $row2[3] != '' ? $row2[3] : _KEINE_KATEGORIE_;
                    if (!isset($kvorlagen_feld[$kategor])) {
                        $kvorlagen_feld[$kategor] = 'OPTGROUP';
                    }
                    $kvorlagen_feld[$row2[0]] = $row2[1];
                }
                // --> vers. 5.7 - 19.04.2016
            } else {
                $kvorlagen_feld[$row2[0]] = $row2[1] . ' ' . link2(_VORSCHAU_, 'admin_email_vorlagen.php?vs=' . $row2[0], '', '', 'target="_blank"') . '<br>';
            }
        }
        $alle_vorlagen=$kvorlagen_feld;
        
        
        
        $p='form_einstellungen_';
        $form_einstellungen=new htmlform();

        $grund_html='';
        if ($_SESSION['crm_version']>62 || $_SESSION['cfg_kunde']=='carlo_opel_asag') {
            $cols_grund=array();
            if (is_array($bdc_einstellungen['grund'])) {
                $i=0;
                foreach ($bdc_einstellungen['grund'] as $key => $val) {
                    $grund_html.='
                        <tr class="bdc_einstellungen_grund">
                        <td>'.$form_einstellungen->selectinput('bgrp['.$key.']', $benutzergrp, $val['bgrp'], _KEINE_AUSWAHL_).'</td>
                        <td>'.$form_einstellungen->selectinput('bgrp_grund['.$key.']', $alle_bdc_gruende, $val['bgrp_grund'], _KEINE_AUSWAHL_).'</td>
                        <td><span style="margin-top:3px; cursor:pointer;" border="0" class="icon icon-bin">&nbsp;</span></td>
                        </tr>'; //todo f�r neu
                    $cols_grund[$i][0]=new Template_SelectInput(_BENUTZERGRUPPE_,'bgrp['.$key.']', $benutzergrp, $val['bgrp'], _KEINE_AUSWAHL_);
                    $cols_grund[$i][1]=new Template_SelectInput(_GRUND_,'bgrp_grund['.$key.']', $alle_bdc_gruende, $val['bgrp_grund'], _KEINE_AUSWAHL_);
                    $i++;
                }
            }
            $cols_grund=new Template_GridTable($cols_grund);

            $grund_tpl=' <tr class="bdc_einstellungen_grund">
            <td>'.$form_einstellungen->selectinput('bgrp[{key}]', $benutzergrp, -1, _KEINE_AUSWAHL_).'</td>
            <td>'.$form_einstellungen->selectinput('bgrp_grund[{key}]', $alle_bdc_gruende, -1, _KEINE_AUSWAHL_).'</td>
            <td><span style="margin-top:3px; cursor:pointer;" border="0" class="icon icon-bin">&nbsp;</span></td>
            </tr>';
            $grund_tpl=addslashes(p4n_mb_string('str_replace',array("\r\n","\r","\n",'\r\n','\r','\n'),' ',$grund_tpl));
        }
        
        $bdc_lead_setter='';
        if ($_SESSION['crm_version']>67 || $_SESSION['cfg_kunde']=='crm_vw_ostmann') {
            $bdcDataSetter = new bdcDataSetter();
            $bdcDataSetter->setUpdateSubmitName('form_einstellungen_submit'.(!$_SESSION['design_70']?'':'2'));
            $bdcDataSetter->setUrlExtraData('bdc_einstellungen=1');
            if (!$_SESSION['design_70']) {
                $bdc_lead_setter= '<br>'.$bdcDataSetter->output($_REQUEST);
            }
        }
        
        if ($cfg_stammdaten_lead) {} else {
            $inhalt= preg_replace('/\<\!stammdaten_lead1\>.*\<\!stammdaten_lead2\>/Uis','',$inhalt);
        }
        $inhalt= p4n_mb_string('str_replace',array('<!stammdaten_lead1>','<!stammdaten_lead2>'),'',$inhalt);
		
        if ($cfg_lead_absatzgruppe || $_SESSION['crm_version_float']>=61300) {} else {
            $inhalt= preg_replace('/\<\!einstellungen_lead_absatzgruppe1\>.*\<\!einstellungen_lead_absatzgruppe2\>/Uis','',$inhalt);
        }
        $inhalt= p4n_mb_string('str_replace',array('<!einstellungen_lead_absatzgruppe1>','<!einstellungen_lead_absatzgruppe2>'),'',$inhalt);
        
		$kanal_def_auswahl='';
		if (1) {
			$kanal=array();
			$res5 = $db->select(
        		$sql_tab['kategorie'],
		        array(
        		    $sql_tabs['kategorie']['kategorie_id'],
		            $sql_tabs['kategorie']['bezeichnung'],
        		    $sql_tabs['kategorie']['rang'],
		            $sql_tabs['kategorie']['modul']
		        ),
		        $db->dbzahlin(array(47), $sql_tabs['kategorie']['modul']).' and '.$sql_tabs['kategorie']['zusatz1'].'='.$db->str(''),
        		$sql_tabs['kategorie']['rang'].' asc,'.$sql_tabs['kategorie']['bezeichnung']
    		);
			while ($row5 = $db->zeile($res5)) {
				$kanal[$row5[1]]=$row5[1];
			}
			$res5=$db->select(
		        $sql_tab['kampagne_lead'],
		        'distinct '.$sql_tabs['kampagne_lead']['channel']
		    );
		    while ($row5=$db->zeile($res5)) {
		        $kanal[$row5[0]]=$row5[0];
		    }
		    $kanal = cleanUpSelectArray($kanal, _IMPORT_KEINE_ZUORDNUNG_);
			if (count($kanal)>0) {
				$kanal_def_auswahl=' '._STANDARD_.': '.$form_einstellungen->selectinput('form_einstellungen_lead_kanal_def', $kanal, $bdc_einstellungen['lead_kanal_def'], _KEINE_AUSWAHL_);
			}
		}
		
        $form_einstellungen_tpl=array(
            'form_einstellungen_start' => $form_einstellungen->start('form_einstellungen', $phs.'?bdc_einstellungen=1', 'POST',false,'id="'.'form_einstellungen_start'.'"'),
            'form_einstellungen_absender'=>$form_einstellungen->textinput('form_einstellungen_absender', $bdc_einstellungen['absender']),
            'form_einstellungen_absendername'=>$form_einstellungen->textinput('form_einstellungen_absendername', $bdc_einstellungen['absendername']),
            'form_einstellungen_vorlage1'=>$form_einstellungen->selectinput('form_einstellungen_vorlage1', $alle_vorlagen, $bdc_einstellungen['vorlage1']),
            'form_einstellungen_vorlage2'=>$form_einstellungen->selectinput('form_einstellungen_vorlage2', $alle_vorlagen, $bdc_einstellungen['vorlage2']),
            'form_einstellungen_vorlage3'=>$form_einstellungen->selectinput('form_einstellungen_vorlage3', $alle_vorlagen, $bdc_einstellungen['vorlage3']),
            'form_einstellungen_name'=>$form_einstellungen->checkinput('form_einstellungen_name', $bdc_einstellungen['name']),
            'form_einstellungen_moredetails'=>$form_einstellungen->checkinput('form_einstellungen_moredetails', $bdc_einstellungen['moredetails']),
            'form_einstellungen_submit' => $bdc_lead_setter.$form_einstellungen->submit('form_einstellungen_submit',_SPEICHERN_),
            'form_einstellungen_lead_quelle' => $form_einstellungen->checkinput('form_einstellungen_lead_quelle', $bdc_einstellungen['lead_quelle']), //lead_quelle_label}</th><td class="td">{form_einstellungen_lead_quelle
            'form_einstellungen_lead_kanal' => $form_einstellungen->checkinput('form_einstellungen_lead_kanal', $bdc_einstellungen['lead_kanal']).$kanal_def_auswahl, //lead_quelle_label}</th><td class="td">{form_einstellungen_lead_quelle
            'form_einstellungen_lead_art' => $form_einstellungen->checkinput('form_einstellungen_lead_art', $bdc_einstellungen['lead_art']), //lead_quelle_label}</th><td class="td">{form_einstellungen_lead_quelle
            'form_einstellungen_lead_marke' => $form_einstellungen->checkinput('form_einstellungen_lead_marke', $bdc_einstellungen['lead_marke']), //lead_quelle_label}</th><td class="td">{form_einstellungen_lead_quelle
            'form_einstellungen_lead_fahrzeug' => $form_einstellungen->checkinput('form_einstellungen_lead_fahrzeug', $bdc_einstellungen['lead_fahrzeug']), //lead_quelle_label}</th><td class="td">{form_einstellungen_lead_quelle
            'form_einstellungen_lead_absatzgruppe' => $form_einstellungen->checkinput('form_einstellungen_lead_absatzgruppe', $bdc_einstellungen['lead_absatzgruppe']),
            'lead_quelle_label' => 'Lead '._QUELLE_,
            'lead_kanal_label' => 'Lead '._KANAL_,
            'lead_art_label' => 'Lead '.($cfg_nutzensparte ? _SPARTE_ : _ART_),
            'lead_marke_label' => 'Lead '._MARKE_,
            'lead_absatzgruppe_label'=>'Lead '._ABSATZGRUPPE_,
            'lead_fahrzeug_label' => 'Lead '._FAHRZEUG_,
            'grund_html'=> $grund_html,
            'grund_tpl'=>$grund_tpl,
            
            'form_einstellungen_pflicht_anrede'=>$form_einstellungen->checkinput('form_einstellungen_pflicht_anrede', $bdc_einstellungen['neuanlage_pflicht']['anrede']),
            'form_einstellungen_pflicht_vorname'=>$form_einstellungen->checkinput('form_einstellungen_pflicht_vorname', $bdc_einstellungen['neuanlage_pflicht']['vorname']),
            'form_einstellungen_pflicht_name'=>$form_einstellungen->checkinput('form_einstellungen_pflicht_name', $bdc_einstellungen['neuanlage_pflicht']['name']),
            'form_einstellungen_pflicht_firma'=>$form_einstellungen->checkinput('form_einstellungen_pflicht_firma', $bdc_einstellungen['neuanlage_pflicht']['firma']),
            'form_einstellungen_pflicht_telemail'=>$form_einstellungen->checkinput('form_einstellungen_pflicht_telemail', $bdc_einstellungen['neuanlage_pflicht']['telemail']),
            
            'form_einstellungen_pflicht_aendern_link' => linkToTab(_PFLICHTFELDER_ANPASSEN_, 'bdc.php?configure_required_fields=1'),
            'form_einstellungen_ende' => $form_einstellungen->ende(),
            'zurueck' => $temp->getHtml()
        );
        $inhalt=strReplaceInputs($inhalt,$form_einstellungen_tpl); 
    }
    if ($_SESSION['design_70']) {
        Modern_Helper_Request::requestStart();
        
        
        $breadcrumps_list=array('Verwaltung BDC');
        echo Template_Default::ModalHeader($breadcrumps_list)->getHtml();
        

        if (isset($_GET['bdc_tab_settings0'])) {
            Modern_Helper_Request::requestStart();
            $form70_mail=new Template_Form('form_einstellungen', $phs.'?bdc_einstellungen=1&bdc_tab_settings0=1', 'POST',false);
            $form70_mail->setTarget('bdc_tab_settings0');
            $cols_email=array();
            $cols_email[0][0]=new Template_TextInput(_ABSENDER_,'form_einstellungen_absender', $bdc_einstellungen['absender']);
            $cols_email[0][1]=new Template_TextInput(_ABSENDER_.' '._NAME_,'form_einstellungen_absendername', $bdc_einstellungen['absendername']);
            $cols_email[1][0]=new Template_SelectInput(_VORLAGE_.' '._BM_ART3_,'form_einstellungen_vorlage1', $alle_vorlagen, $bdc_einstellungen['vorlage1']);
            $cols_email[2][0]=new Template_SelectInput(_VORLAGE_.' '._BESCHWERDE_,'form_einstellungen_vorlage2', $alle_vorlagen, $bdc_einstellungen['vorlage2']);
            $cols_email[3][0]=new Template_SelectInput(_VORLAGE_.' '._LEAD_,'form_einstellungen_vorlage3', $alle_vorlagen, $bdc_einstellungen['vorlage3']);
            $cols_email=new Template_GridTable($cols_email); 
            $card_email=Template_Default::Card(_EMAIL_,null,$cols_email);
            $form70_mail->addElement($card_email);
            $form70_mail->addElement(Template_Default::ModalFooter(Template_Submit::init('form_einstellungen_submit',_SPEICHERN_,$other='', $image='',$requiredTarget='',$requestTarget='')));
            $form70_mail->checkFormChange();
            echo $form70_mail->getHtml();
            exit;
        }

        if (isset($_GET['bdc_tab_settings1'])) {
            Modern_Helper_Request::requestStart();
            $form70=new Template_Form('form_einstellungen', $phs.'?bdc_einstellungen=1&bdc_tab_settings1=1', 'POST',false);
            $form70->setTarget('bdc_tab_settings1');
            
            $bdc_lead_setter70=$bdcDataSetter->output($_REQUEST,false,(isset($_GET['bdc_settings_modal'])?$_GET['bdc_settings_modal']:-1));
            
            $action_list=array(
                Template_Link::init('Neue Leadvorlage')->openModal('bdc_settings_modal_new_lead'),
                Template_Link::init('Neue Anfragevorlage')->openModal('bdc_settings_modal_new_anfrage'),
                Template_Link::init('Neue Beschwerdevorlage')->openModal('bdc_settings_modal_new_beschwerde')
            );
            $actionMenuButton = Template_IconTextButton::init('',_AKTIONEN_,'', 'keyboard_arrow_down__right','','','','blue')->addCustomClass('mb-12');
            $actionMenuContent = new Template_LinkList($action_list);
            Template_InlineOverlay::prepare($actionMenuButton, $actionMenuContent, 'bdc_sesstings_aktionen');
            $right=new Template_ElementList(array($actionMenuButton,$actionMenuContent),'','');
            
            $card=Template_Default::Card(' ',$right,$bdc_lead_setter70,array('border','shadow'));
            
            
            $form70->addElement($card);
            echo $form70->getHtml();
            exit;
        }


        $a['bdc_tab_settings1'] = new Template_Link('Schnellauswahl', 'bdc.php?bdc_tab_settings1=1&bdc_einstellungen=1');
        $a['bdc_tab_settings0'] = Template_Link::init(_EMAIL_, 'bdc.php?bdc_tab_settings0=1&bdc_einstellungen=1');
        $a['bdc_tab_settings2'] = Template_Link::init(_LEAD_, 'bdc.php?bdc_tab_settings2=1');
        if (p4n_mb_string('strpos', $_SESSION['rechte_reiter'], 'nav=BM') !== false) {
            $a['bdc_tab_settings3'] = Template_Link::init(_ANFRAGEN_, 'bdc.php?bdc_tab_settings3=1');
            $a['bdc_tab_settings4'] = Template_Link::init(_BESCHWERDEN_, 'bdc.php?bdc_tab_settings4=1');
        }
        $a['bdc_tab_settings5'] = Template_Link::init(_SONSTIGES_, 'bdc.php?bdc_tab_settings5=1');

        $tabs = new Template_Tabs($a,array(),$options=array('border'));
        $tabs->active($a['bdc_tab_settings'.$_GET['bdc_tab_settings']]);
        echo $tabs->getHtml();
       // echo $bdc_settings_modal->getHtml();
        
       

        exit;
    }
    
    echo $inhalt;
    
    fuss();
    die();
}






if (p4n_mb_string('strpos', $_SESSION['rechte_reiter'], 'nav=BM')!==false) {} else {
    $cfg_bdc_notbman=true;
}


if (isset($_POST['action']) && $_POST['action']=='reloadap') {
    Modern_Helper_Request::requestStart();
    
    $std=$_POST['form_kunde_stdid'];
    $ap_std=$_POST['form_kunde_ansprechpartner_id'];
    $_SESSION['bdcSelectedAp']=$ap_std;
    $res_ap = $db->select(
        $sql_tab['stammdaten_ansprechpartner'], array(
            $sql_tabs['stammdaten_ansprechpartner']['ansprechpartner_id'], //0
            $sql_tabs['stammdaten_ansprechpartner']['vorname'], //1
            $sql_tabs['stammdaten_ansprechpartner']['bezeichnung'], //2
            $sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'], //3
            $sql_tabs['stammdaten_ansprechpartner']['adresse'], //4
            $sql_tabs['stammdaten_ansprechpartner']['plz'], //5
            $sql_tabs['stammdaten_ansprechpartner']['ort'], //6
            $sql_tabs['stammdaten_ansprechpartner']['email'], //7
            $sql_tabs['stammdaten_ansprechpartner']['telefon'], //8
            $sql_tabs['stammdaten_ansprechpartner']['mobil'], //9
            $sql_tabs['stammdaten_ansprechpartner']['anrede'], //10
            $sql_tabs['stammdaten_ansprechpartner']['titel'], //11
            $sql_tabs['stammdaten_ansprechpartner']['zusatz4'], //12
            $sql_tabs['stammdaten_ansprechpartner']['zusatz5'], //13

        ), $sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'] . ' = ' . $db->dbzahl($std)
    );
  
    $html='';
    $html.='<option value="-1">'._KEINE_AUSWAHL_.'</option>';
    $html.='<option value="-1000">'._ADMINBENUTZER_SUBMITNEU_.'</option>';
    $arr=array('vorname'=>'','bezeichnung'=>'','email'=>'','telefon'=>'','anrede'=>'','titel'=>'','mobil'=>'');
    while ($row=$db->zeile($res_ap)) {
        if ($row[0]==$ap_std) {
            $arr=$row;
        }
        $html.='<option value="'.$row[0].'">'.trim($row[1].', '.$row[2]).'</option>';
    }
    echo base64_encode(serialize(array($arr,$html)));
    exit;
}

if (isset($_GET['startSetting']) && isset($_GET['stid']) && isset($_SESSION['bdcSelectedAp'])) {
    echo javas ('window.onload = function(){
        bdc_reload_ap();
    }');
    $getfeld['ignoreBdcSuche']=1;
}

if (isset($_POST['action']) && $_POST['action']=='getKorrespodenz') {
    Modern_Helper_Request::requestStart();
}




if (isset($_GET['bdcPoolSearch'])) {

    $res = $db->select(
        $sql_tab['bdc_pool'], 
        array(
            $sql_tabs['bdc_pool']['bdc_pool_id'],//0
            $sql_tabs['bdc_pool']['pool_obj'],//1
            $sql_tabs['bdc_pool']['ersteller_id'],//2
            $sql_tabs['bdc_pool']['datum_eintrag'],//3
            $sql_tabs['bdc_pool']['betreuer_id'],//4
            $sql_tabs['bdc_pool']['datum_wvl'],//5
            $sql_tabs['bdc_pool']['status'],//6
            $sql_tabs['bdc_pool']['letzte_aenderung']//7
        ),
        $sql_tabs['bdc_pool']['bdc_pool_id'].'='.$db->dbzahl($_GET['bdcPoolSearch'])
    );
    if ($row = $db->zeile($res)) {
        $bdc_pool_obj= unserialize(base64_decode($row[1]));
        $postfeld['form_kunde_stdid']=$bdc_pool_obj['stammdaten_id'];
        $getfeld['stid']=$bdc_pool_obj['stammdaten_id'];
    }
}

if (isset($postfeld['bdcPoolSearch'])) {
    $_GET['bdcPoolSearch']=$postfeld['bdcPoolSearch'];
    if (isset($postfeld['neue_suche'])) {
        unset($postfeld);
    }
}

if(isset($_GET['extraLinkData'])) {
    $postfeld['form_kunde_suche_erg']=$_GET['extraLinkData'];
} 

$extraLinkData='';
if (isset($postfeld['form_kunde_suche_erg'])) {
    $postfeld2=unserialize(base64_decode($postfeld['form_kunde_suche_erg']));
    $extraLinkData=$postfeld['form_kunde_suche_erg'];
}
if (intval($postfeld2['bdcPoolSearch'])>0) {
    $_GET['bdcPoolSearch']=$postfeld2['bdcPoolSearch'];
}

$allek=array();
if (intval($postfeld2['form_kunde_stdid'])>0 || (isset($getfeld['stid']) && intval($getfeld['stid'])>0)) {
    $res=$db->select(
        $sql_tab['korrespondenz'],
        array(
            $sql_tabs['korrespondenz']['korrespondenz_id'],
            $sql_tabs['korrespondenz']['betreff'],
            $sql_tabs['korrespondenz']['kategorie'],
            $sql_tabs['korrespondenz']['datum'],
            $sql_tabs['korrespondenz']['lead_id'],
            $sql_tabs['korrespondenz']['kampagne_id']
        ),
        $sql_tabs['korrespondenz']['stammdaten_id'].'='.$db->dbzahl((intval($postfeld2['form_kunde_stdid'])>0)?$postfeld2['form_kunde_stdid']:$getfeld['stid']),$sql_tabs['korrespondenz']['korrespondenz_id'].' DESC','',false,3
    );
    while ($row=$db->zeile($res)) {
        $allek[$row[0]]=$db->unixdatetime($row[3]).': '.abkuerzung($row[1], 20).' / '.abkuerzung($row[2], 10).(intval($row[4])>0?' ('._LEAD_.')':'');
    } 
}

if (!$form) {
    $form=new htmlform();
}

$allek=$form->selectinput('kbezug', $allek, -1, _KEINE_AUSWAHL_);
    
if (isset($_POST['action']) && $_POST['action']=='getKorrespodenz') {
    echo $allek;
    Modern_Helper_Request::requestFlush();
}



function bdc_bereinige_standort($lagid, $stdid) {
    global $db, $sql_tab, $sql_tabs, $cfg_kunde_mandlao;
    
    if (intval($lagid)>0) {} else {
        if ($stdid>0) {
             $res=$db->select(
                $sql_tab['stammdaten'],
                array(
                    $sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'vpb' :  'mandant'],
                    $sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'mandant' : 'vpb']
                ),
                $sql_tabs['stammdaten']['id'].'='.$db->dbzahl($stdid)
            );
            if ($row=$db->zeile($res)) {
                if (intval($row[1])>0) {
                    $lagid=$row[1];
                } else {
                    $lagid=$row[0];
                }
            }
        }
    }
    
    $mandant=1;
    $lagerort=0;
    $res=$db->select(
        $sql_tab['mandant'],
        array(
            $sql_tabs['mandant']['mandant_id'],
            $sql_tabs['mandant']['bezeichnung'],
            $sql_tabs['mandant']['parent_id']
        ),
        $sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($lagid)
    );
    if ($row=$db->zeile($res)) {
        if (intval($row[2])>0) {
            $mandant = $db->dbzahl($row[2]);
            $lagerort = $db->dbzahl($lagid);
        } else {
            $mandant = $db->dbzahl($lagid);
            $lagerort = 0;
        }
    }
    return array($mandant,$lagerort);
}

if ($cfg_bdc_nl) {
    $kfz=array();
    $res = $db->select(
        $sql_tab['kfzzuordnung'],
        array($sql_tabs['kfzzuordnung']['id'], $sql_tabs['kfzzuordnung']['kategorie'], $sql_tabs['kfzzuordnung']['typmodell']),
        $sql_tabs['kfzzuordnung']['typmodell'].'!='.$db->str('').' AND '.$sql_tabs['kfzzuordnung']['kategorie'].'!='.$db->str(''),
        $sql_tabs['kfzzuordnung']['markencode'].' ASC,'.
        $sql_tabs['kfzzuordnung']['obergruppe'].' ASC,'.
        $sql_tabs['kfzzuordnung']['typmodell'].' ASC'
    );
    while ($row=$db->zeile($res)) {
        $kfz[$row[1]][]=$row[2];
    }

    $fahrzeugkategorie=array();
    $js_kat='';
    $js_kat2='';
    $res=$db->select(
        $sql_tab['kategorie'],
        array(
            $sql_tabs['kategorie']['kategorie_id'],
            $sql_tabs['kategorie']['bezeichnung'],
            $sql_tabs['kategorie']['zusatz1'],
        ),
        $sql_tabs['kategorie']['modul'].'='.$db->dbzahl(38)
    );
    while ($row=$db->zeile($res)) {
        $fahrzeugkategorie[$row[1]]=$row[1];

        $js_kat.='{kat:"'.$row[1].'",typmodell:[';
        $temp='"'._KEINE_AUSWAHL_.'",';
        if (is_array($kfz[$row[1]]) && count($kfz[$row[1]])>0) {
            foreach ($kfz[$row[1]] as $typmodell) { 
                $temp.='"'.$typmodell.'",';
            } 
        }
        if ($temp!='') {
            $js_kat.=substr($temp,0,-1);
        }
        $js_kat.=']},';
        
        
        $js_kat2.='{kat:"'.$row[1].'",neugebraucht:[';
        $temp='"'._KEINE_AUSWAHL_.'",';
        $neuugebraucht=explode(';',$row[2]);
        if (is_array($neuugebraucht) && count($neuugebraucht)>0) {
            foreach ($neuugebraucht as $temp2) { 
                $temp.='"'.$temp2.'",';
            } 
        }
        if ($temp!='') {
            $js_kat2.=substr($temp,0,-1);
        }
        $js_kat2.=']},';
    }

    if ($js_kat!='') {
        $js_kat='['.substr($js_kat,0,-1).']';
    }
    $js_kat=p4n_mb_string('str_replace','"','\'',$js_kat);

    if ($js_kat2!='') {
        $js_kat2='['.substr($js_kat2,0,-1).']';
    }
    $js_kat2=p4n_mb_string('str_replace','"','\'',$js_kat2);

    

    
    
    $status_bez_lead = array(
        //0 => _NEU_,
      //  1 => _BM_STATUS3_,
        2 => _BM_STATUS2_,
        3 => _OFFEN_,
        4 => _KONTAKTIERT_,
        5 => _BM_STATUS4_,
      //  99 => _NICHT_ABGESCHLOSSEN_
    );
}

$kategorien2_anfrage = $kategorien2_bechwerde = array();
if (!$cfg_bdc_kategorie2_multiselect) {
    $kategorien2_anfrage[_KEINE_] = _KEINE_;
    $kategorien2_bechwerde[_KEINE_] = _KEINE_;
}
$alle_textbausteine = $alle_textbausteine_bm = $alle_textbausteine_lead = array();
$res = $db->select(
    $sql_tab['kategorie'],
    array(
        $sql_tabs['kategorie']['kategorie_id'],
        $sql_tabs['kategorie']['bezeichnung'],
        $sql_tabs['kategorie']['modul'],
        $sql_tabs['kategorie']['zusatz3']
    ),
    //$sql_tabs['kategorie']['modul'].'='.$db->dbzahl(35).' OR '.$sql_tabs['kategorie']['modul'].'='.$db->dbzahl(65).' OR '.$sql_tabs['kategorie']['modul'].'='.$db->dbzahl(66),
    $db->dbzahlin(array(35, 53, 65, 66), $sql_tabs['kategorie']['modul']),
    $sql_tabs['kategorie']['rang'].' asc,'.$sql_tabs['kategorie']['bezeichnung']
);
while ($row = $db->zeile($res)) {
    $title = $row[1];
    if (empty($title)) {
        continue;
    }
    switch ($row[2]) {
        case 35:
            $alle_textbausteine[$title] = $title;
            break;
        case 53:
            $katTyp = $row[3];
            if ($katTyp === 'anfrage') {
                $kategorien2_anfrage[$title] = $title;
            } else if ($katTyp === 'beschwerde') {
                $kategorien2_bechwerde[$title] = $title;
            } else {
                $kategorien2_anfrage[$title] = $title;
                $kategorien2_bechwerde[$title] = $title;
            }
            break;
        case 65:
            $alle_textbausteine_bm[$title] = $title;
            break;
        case 66:
            $alle_textbausteine_lead[$title] = $title;
            break;
    }
}
ksort($alle_textbausteine, SORT_NATURAL | SORT_FLAG_CASE);
ksort($alle_textbausteine_bm, SORT_NATURAL | SORT_FLAG_CASE);
ksort($alle_textbausteine_lead, SORT_NATURAL | SORT_FLAG_CASE);


$rben_where=$sql_tabs['benutzer']['gruppe'].'>=0';
if ($_SESSION['cfg_kunde']=='carlo_vw_nuetzel') {
    $rben_where.=' OR '.$sql_tabs['benutzer']['gruppe'].'=-10';
}

$benutzer_feld=rbenutzer(3, true, $rben_where, 40);
$benutzer_feld_lead=$benutzer_feld;
$benutzer_feld_bm=$benutzer_feld;
if (isset($cfg_bm_neubeschwerde)) {
    $alle_bens_bs='';
    $res=$db->select(
        $sql_tab['benutzer_gruppe'],
        $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
        $sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str($cfg_bm_neubeschwerde)
    );
    if ($row=$db->zeile($res)) {
        $res=$db->select(
            $sql_tab['benutzer_gruppe_zuordnung'],
            $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'],
            $sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].'='.$db->dbzahl($row[0])
        );
        while ($row=$db->zeile($res)) {
            $alle_bens_bs.=$row[0].',';
        }
    }
    if ($alle_bens_bs!='') {

        $alle_bens_bs=p4n_mb_string('substr',$alle_bens_bs, 0, -1);
        $rben_where2=$rben_where.' and '.$db->dbzahlin($alle_bens_bs,$sql_tabs['benutzer']['benutzer_id']);
        $benutzer_feld_bm=rbenutzer(3, true, $rben_where2, 40);

    }
}

    $alle_eva_ben = $alle_eva_ben1 = $alle_eva_ben2 = $alle_eva_ben3 = array();
    $merke_evaselbst = '';
    $res = $db->select(
        $sql_tab['benutzer'],
        array(
            $sql_tabs['benutzer']['benutzer_id'],
            $sql_tabs['benutzer']['vorname'],
            $sql_tabs['benutzer']['name'],
            $sql_tabs['benutzer']['syncml_user4'],
            $sql_tabs['benutzer']['gruppe']
        ),
        $sql_tabs['benutzer']['syncml_user4'].'!='.$db->str('')
    );
    while ($row = $db->zeile($res)) {
        $xpl = explode('_', $row[3]);
        if (intval($xpl[1]) > 0) {
            if (intval($row[4]) >= 0) {
                $alle_eva_ben[$row[3]] = $row[2].', '.$row[1].' ('.$xpl[1].(($xpl[0]=='2' and $_SESSION['cfg_kunde']=='carlo_vw_mahag')?'/NFZ':'').')';
                $alle_eva_ben1[$row[0]] = $row[2].', '.$row[1].' ('.$xpl[1].(($xpl[0]=='2' and $_SESSION['cfg_kunde']=='carlo_vw_mahag')?'/NFZ':'').')';
            }
            $alle_eva_ben2[$row[0]] = $row[3];
            $alle_eva_ben3[$row[3]] = $row[0];
            if ($_SESSION['user_id'] == $row[0]) {
                $merke_evaselbst = $row[3];
            }
        }
    }
    @asort($alle_eva_ben);

$bens2_online_lead_eva=array();
if ($_SESSION['crm_version']>63 && function_exists('getUsersWithOnlineOfflineStatus')) {
    if ($benutzer_feld_bm!=$benutzer_feld_lead) {
        $bens2_online = getUsersWithOnlineOfflineStatus($benutzer_feld_bm, $bdc = true);
        $bens2_online_lead = getUsersWithOnlineOfflineStatus($benutzer_feld_lead, $bdc = true);
    } else {
        $bens2_online = getUsersWithOnlineOfflineStatus($benutzer_feld_bm, $bdc = true);
        $bens2_online_lead = $bens2_online;
    }
    $bens2_online_lead_eva = getUsersWithOnlineOfflineStatus($alle_eva_ben1, $bdc = true);
} else {
    
    $alle_uson=array();
    $res=$db->select(
        array(
            $sql_tab['useronline'],
            $sql_tab['benutzer']
        ),
        array(
            $sql_tabs['useronline']['datum'],
            $sql_tabs['useronline']['benutzer_id'],
            $sql_tabs['benutzer']['name'],
            $sql_tabs['benutzer']['vorname']
        ),
        $sql_tabs['useronline']['benutzer_id'].'='.$sql_tabs['benutzer']['benutzer_id']
    );
    while ($row=$db->zeile($res)) {
        if ($db->unixdate_ts($row[0])>(time()-(2*60))) {
            $alle_uson[$row[1]]=$row[2].', '.$row[3];
        }
    }
    @asort($alle_uson);

    if ($_SESSION['crm_version']>63) {
        $benutzer_online=array();
        $benutzer_offline=array();
        $benutzer_urlaub=array();

        $benutzer_online_lead=array();
        $benutzer_offline_lead=array();
        $benutzer_urlaub_lead=array();

        $benutzer_to_check = array();

        if (!empty($benutzer_feld_bm)) {
            foreach ($benutzer_feld_bm as $ben_id => $benutzer_name) {
                if (!isset($benutzer_to_check[$ben_id])) {
                    $benutzer_to_check[$ben_id] = $ben_id;
                }
            }
        }
        if (!empty($benutzer_feld_lead)) {
            foreach ($benutzer_feld_lead as $ben_id => $benutzer_name) {
                if (!isset($benutzer_to_check[$ben_id])) {
                    $benutzer_to_check[$ben_id] = $ben_id;
                }
            }
        }

        if (!empty($benutzer_to_check)) {
            if (is_file('inc/lib_feiertag.php')) {
                include_once('inc/lib_feiertag.php');
                $alle_ben_termine = getArbeitsTageVonBenutzer_multi(time(), time(), $benutzer_to_check);
            }
        }

        if (!empty($alle_ben_termine)) {
            $alle_urlaub = array();
            if (!empty($_SESSION['kal_kategorie'])) {
                foreach ($_SESSION['kal_kategorie'] as $kal_kat => $is_urlaub) {
                    if ($is_urlaub == 1) {
                        $alle_urlaub[] = $kal_kat;
                    }
                }
            } else {
                if ($_SESSION['crm_version_float'] >= 61200) {
                    $alle_urlaub = array(ucfirst(_ABWESEND_));
                } else {
                    $alle_urlaub = array(_URLAUB_);
                }
            }

            foreach ($alle_ben_termine as $ben_id => $val) {
                foreach ($alle_urlaub as $urlaub_name) {

                    if (isset($benutzer_feld_bm[$ben_id]) && isset($val[0]['termin_kategorie']) && !empty($val[0]['termin_kategorie']) && isset($val[0]['termin_kategorie'][$urlaub_name])) {
                        $ben_name = $benutzer_feld_bm[$ben_id];

                        if ($_SESSION['crm_version_float'] >= 61200) {
                            if (!isset($benutzer_urlaub[ucfirst(_ABWESEND_)])) {
                                $benutzer_urlaub[ucfirst(_ABWESEND_)]='OPTGROUP';
                            }

                            $urlaub_termin = current($val[0]['termin_kategorie_konkret'][$urlaub_name]);
                            $urlaub_ende = date('d.m.Y H:i', $urlaub_termin['ende']);

                            $benutzer_urlaub[$ben_id] = $ben_name.' ('._BIS_.' '.$urlaub_ende.')';
                        } else {
                            if (!isset($benutzer_urlaub[_URLAUB_])) {
                                $benutzer_urlaub[_URLAUB_]='OPTGROUP';
                            }
                            $benutzer_urlaub[$ben_id]=$ben_name;
                        }
                    }
                    if (isset($benutzer_feld_lead[$ben_id]) && isset($val[0]['termin_kategorie']) && !empty($val[0]['termin_kategorie']) && isset($val[0]['termin_kategorie'][$urlaub_name])) {
                        $ben_name = $benutzer_feld_lead[$ben_id];

                        if ($_SESSION['crm_version_float'] >= 61200) {
                            if (!isset($benutzer_urlaub_lead[ucfirst(_ABWESEND_)])) {
                                $benutzer_urlaub_lead[ucfirst(_ABWESEND_)]='OPTGROUP';
                            }

                            $urlaub_termin = current($val[0]['termin_kategorie_konkret'][$urlaub_name]);
                            $urlaub_ende = date('d.m.Y H:i', $urlaub_termin['ende']);

                            $benutzer_urlaub_lead[$ben_id] = $ben_name.' ('._BIS_.' '.$urlaub_ende.')';
                        } else {
                            if (!isset($benutzer_urlaub_lead[_URLAUB_])) {
                                $benutzer_urlaub_lead[_URLAUB_]='OPTGROUP';
                            }
                            $benutzer_urlaub_lead[$ben_id]=$ben_name;
                        }
                    }
                }
            }
        }
        if (!empty($alle_uson)) {
            foreach ($alle_uson as $ben_id => $val) {
                if (isset($benutzer_feld_bm[$ben_id]) && !isset($benutzer_urlaub[$ben_id])) {
                    if (!isset($benutzer_online[_ONLINE_])) {
                        $benutzer_online[_ONLINE_]='OPTGROUP';
                    }
                    $benutzer_online[$ben_id]=$benutzer_feld_bm[$ben_id];
                }
                if (isset($benutzer_feld_lead[$ben_id]) && !isset($benutzer_urlaub_lead[$ben_id])) {
                    if (!isset($benutzer_online_lead[_ONLINE_])) {
                        $benutzer_online_lead[_ONLINE_]='OPTGROUP';
                    }
                    $benutzer_online_lead[$ben_id]=$benutzer_feld_lead[$ben_id];
                }
            }
        }

        if (!empty($benutzer_feld_bm)) {
            foreach ($benutzer_feld_bm as $ben_id => $benutzer_name) {
                if (!isset($benutzer_online[$ben_id]) && !isset($benutzer_urlaub[$ben_id])) {
                    if (!empty($benutzer_online)) {
                        if (!isset($benutzer_offline[_NICHT_ONLINE_])) {
                            $benutzer_offline[_NICHT_ONLINE_]='OPTGROUP';
                        }
                    }
                    $benutzer_offline[$ben_id]=$benutzer_name;
                }
            }
        }
        if (!empty($benutzer_feld_lead)) {
            foreach ($benutzer_feld_lead as $ben_id => $benutzer_name) {
                if (!isset($benutzer_online_lead[$ben_id]) && !isset($benutzer_urlaub_lead[$ben_id])) {
                    if (!empty($benutzer_online_lead)) {
                        if (!isset($benutzer_offline_lead[_NICHT_ONLINE_])) {
                            $benutzer_offline_lead[_NICHT_ONLINE_]='OPTGROUP';
                        }
                    }
                    $benutzer_offline_lead[$ben_id]=$benutzer_name;
                }
            }
        }    
        $bens2_online=$benutzer_online+$benutzer_offline+$benutzer_urlaub;
        $bens2_online_lead=$benutzer_online_lead+$benutzer_offline_lead+$benutzer_urlaub_lead;
    } else {
        $bens2_online=array();
        foreach ($benutzer_feld_bm as $key => $value) {
            if (array_key_exists($key, $alle_uson)) {
                $bens2_online[$key]=_ONLINE_ABK_.': '.$value;
            }
        }
        //sort($bens2_online);
        foreach ($benutzer_feld_bm as $key => $value) {
            if (!array_key_exists($key, $alle_uson)) {
                $bens2_online[$key]=$value;
            }
        }

        $bens2_online_lead=array();
        foreach ($benutzer_feld_lead as $key => $value) {
            if (array_key_exists($key, $alle_uson)) {
                $bens2_online_lead[$key]=_ONLINE_ABK_.': '.$value;
            }
        }
        foreach ($benutzer_feld_lead as $key => $value) {
            if (!array_key_exists($key, $alle_uson)) {
                $bens2_online_lead[$key]=$value;
            }
        }
    }
}
//sort($bens2_online);

if (isset($_POST['saveBdcPoolSearch'])) {
    $bdc_pool_id=$_POST['bdc_pool_id'];
    $std_id=$_POST['form_kunde_stdid'];
    $res = $db->select(
        $sql_tab['bdc_pool'], 
        array(
            $sql_tabs['bdc_pool']['bdc_pool_id'],//0
            $sql_tabs['bdc_pool']['pool_obj'],//1
            $sql_tabs['bdc_pool']['ersteller_id'],//2
            $sql_tabs['bdc_pool']['datum_eintrag'],//3
            $sql_tabs['bdc_pool']['betreuer_id'],//4
            $sql_tabs['bdc_pool']['datum_wvl'],//5
            $sql_tabs['bdc_pool']['status'],//6
            $sql_tabs['bdc_pool']['letzte_aenderung']//7
        ),
        $sql_tabs['bdc_pool']['bdc_pool_id'].'='.$db->dbzahl($bdc_pool_id)
    );
    if ($row = $db->zeile($res)) {
        $bdc_pool_obj=unserialize(base64_decode($row[1]));
        if ($std_id && $std_id!="") {
            $bdc_pool_obj['stammdaten_id']=$std_id;
            $getfeld['stid']=$std_id;
            
            
            $res_std = $db->select(
                    $sql_tab['stammdaten'], array(
                $sql_tabs['stammdaten']['id'], //0
                $sql_tabs['stammdaten']['anzeigename'], //1
                $sql_tabs['stammdaten']['Telefon_1'], //2
                $sql_tabs['stammdaten']['Telefon_2'], //3
                $sql_tabs['stammdaten']['Mobilfon_1'], //4
                $sql_tabs['stammdaten']['Mobilfon_2'], // 5
                $sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'vpb' :  'mandant'], //6
                $sql_tabs['stammdaten']['matchcode'], //7
                $sql_tabs['stammdaten']['meinvpb'], //8
                $sql_tabs['stammdaten']['abteilung'], //9
                $sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'mandant' : 'vpb'],   // 10
                $sql_tabs['stammdaten']['vorname'],   // 11
                $sql_tabs['stammdaten']['name'],   // 12
                $sql_tabs['stammdaten']['firma1'],   // 13
                $sql_tabs['stammdaten']['anrede'],   // 14
                $sql_tabs['stammdaten']['titel'],   // 15
                $sql_tabs['stammdaten']['EMail_1'],   // 16
                $sql_tabs['stammdaten']['EMail_2'],   // 17
                $sql_tabs['stammdaten']['firma2'],   // 18
                $sql_tabs['stammdaten']['firma3'],   // 19
                $sql_tabs['stammdaten']['bemerkung'],   // 20    
                    ), $sql_tabs['stammdaten']['id'].' = '.$db->dbzahl($std_id)
            );
            if ($row_std=$db->zeile($res_std)) {
                if ($row_std['firma1']!='') {
                    $bdc_pool_obj['firma']=$row_std['firma1'];
                } else {
                    $bdc_pool_obj['name']=$row_std[12];
                    $bdc_pool_obj['vorname']=$row_std[11];
                    unset($bdc_pool_obj['nachname']);
                }
                $bdc_pool_obj['anrede']=$row_std[14];
            }
            
            
            //unset($bdc_pool_obj['vorname']);
            
            
        } else{
             $bdc_pool_obj['stammdaten_id']=0;
            unset($getfeld['stid']);
            unset($postfeld['form_kunde_stdid']);
        }
        $bdc_pool_obj['bdc_flag']=$_POST['art'];
        $res = $db->update(
        $sql_tab['bdc_pool'], 
        array(
            $sql_tabs['bdc_pool']['pool_obj']=>$db->str(base64_encode(serialize($bdc_pool_obj))),
            $sql_tabs['bdc_pool']['betreuer_id']=>$db->dbzahl($_POST['benutzer'])
        ),
        $sql_tabs['bdc_pool']['bdc_pool_id'].'='.$db->dbzahl($bdc_pool_id)
        );
        
    }
}

if (isset($_POST['selectBdcPoolAll'])) {
    Modern_Helper_Request::requestStart();
    $res = $db->select(
        $sql_tab['bdc_pool'], 
        array(
            $sql_tabs['bdc_pool']['bdc_pool_id'],//0
            $sql_tabs['bdc_pool']['pool_obj'],//1
            $sql_tabs['bdc_pool']['ersteller_id'],//2
            $sql_tabs['bdc_pool']['datum_eintrag'],//3
            $sql_tabs['bdc_pool']['betreuer_id'],//4
            $sql_tabs['bdc_pool']['datum_wvl'],//5
            $sql_tabs['bdc_pool']['status'],//6
            $sql_tabs['bdc_pool']['letzte_aenderung']//7
        ),
        '('.$sql_tabs['bdc_pool']['betreuer_id'].'='.$db->dbzahl(-1).' OR '.$sql_tabs['bdc_pool']['betreuer_id'].'='.$db->dbzahl(0).' OR '.$sql_tabs['bdc_pool']['betreuer_id'].' is NULL OR '.$sql_tabs['bdc_pool']['betreuer_id'].'='.$db->dbzahl($_SESSION['user_id']).') AND '.$sql_tabs['bdc_pool']['status'].'>='.$db->dbzahl(0),
            $sql_tabs['bdc_pool']['bdc_pool_id'].' DESC'  
    );
    $html='';
    while ($row = $db->zeile($res)) {
        $bdc_pool_obj=unserialize(base64_decode($row[1]));
        $beschreibung='';
        
        $beschreibung='<b>Betreff: </b>'.$bdc_pool_obj['betreff'].'<br><b>Beschreibung: </b>'.$bdc_pool_obj['beschreibung'];
        $beschreibung2='';
        foreach ($bdc_pool_obj as $key => $value) {
            if ($key=='bdc_flag' || $key=='betreff' || $key=='beschreibung' || $key=='undefined') {
                continue;
            }
            $beschreibung2.=p4n_mb_string('ucwords',$key).': <i>'.$value.'</i>,';
        }
        if ($beschreibung2!='') {
            $beschreibung.='<br>('.substr($beschreibung2,0,-1).')';
        }
 
        
       // if (intval($bdc_pool_obj['stammdaten_id'])>0) {
         //   $za=$form->selectinput('',array('Anfrage'=>'Anfrage','Beschwerde'=>'Beschwerde','Lead'=>'Lead','Sonstiges'=>'Sonstiges'),$bdc_pool_obj['bdc_flag']);
       // } else {
            //$za=link2('Kunden suchen','javascript:void(0);','','','onClick="P4nBoxHelper.iframe(\'bdcPoolSearch\',\'bdc.php?bdcPoolSearch='.$row[0].'\',false,\'70%\',\'70%\');"');
            $za=link2('bearbeiten','javascript:','','','onclick=" P4nBoxHelper.init({
                    href:\'bdc.php?bdcPoolSearch='.$row[0].'\',
                    target:\'body\',
                    id:\'bdc_search\',
                    autosize:false,
                    width:\'80%\',
                    height:\'70%\',
                    single:true,
                    type:\'iframe\',
                    beforeShow: function() {
                    },
                    beforeClose: function() {
                       
                    },
                });"').'<br>';
       // }
        $html.='
            <tr class="odd">
                <td class="td">'.$row[0].'</td>
                <td class="td">'.($bdc_pool_obj['bdc_flag'] && $bdc_pool_obj['bdc_flag']!=-1 && $bdc_pool_obj['bdc_flag']!=''?$bdc_pool_obj['bdc_flag']:'').'</td>
                <td class="td">'.nl2br($beschreibung).'</td>
                <td class="td">'.$benutzer_feld[$row[2]].'</td>
                <td class="td">'.$row[3].'</td>
                <td class="td">'.$benutzer_feld[$row[4]].'</td>
                <td class="td">'.$row[7].'</td>
               <!-- <td class="td">'.$row[5].'</td>
                <td class="td">'.$row[6].'</td>-->
                <td class="td">'.
                $za.
                ((intval($bdc_pool_obj['stammdaten_id'])>0)?link2('ausw�hlen','bdc.php?stid='.$bdc_pool_obj['stammdaten_id'].'&getBdcPoolData='.$row[0]).'<br>':'').
                link2(_LOESCHEN_, 'javascript:void(0);', '', '','style="color:#ea1f1f" onclick="RequestHelper.post(\'bdc.php\',\'removeFromBdcPool=\'+'.$row[0].',function(response) {P4nBoxHelper.closeall(\'selectBdcPoolAll\'); try { top.main.P4nBoxHelper.requestPost(\'bdc.php\',\'selectBdcPoolAll=1\',function(response) {},\'600px\',\'600px\',true,\'selectBdcPoolAll\'); } catch(e) {} });"')
                .'</td>
            </tr>';
    }
    if ($html!='') {
        $html='
        <tr class="odd">
            <th class="th">ID</th>
            <th class="th">Art</th>
            <th class="th">Beschreibung</th>
            <th class="th">Ersteller</th>
            <th class="th">erstellt am:</th>
            <th class="th">Betreuer</th>
            <th class="th">letzte �nderung</th>
            <!--<th class="th">Datum WVL</th>
            <th class="th">Status</th>-->
            
            <th class="th"></th>
        </tr>'.$html;
        $html='<table class="moderntable table-ignore2">'.$html.'</table>';
        echo $html;
    } else {
        echo 'keine Eintr�ge vorhanden';
    }
    echo javas('top.main.P4nBoxHelper.close("bdc_search");');
    
    Modern_Helper_Request::requestFlush();
}


if (isset($_POST['toBdcPool'])) {
    Modern_Helper_Request::requestStart();
 
    $pool_obj1=[];
    
    
 
    $ex=explode('{p4n,}',$_POST['reset']);
    foreach ($ex as $wert) {
        $ex2=explode('{p4n:}',$wert);
        $str=$ex2[0].': '.$ex2[1]."\n";
        $_POST['beschreibung']=p4n_mb_string('str_replace',$str,'',$_POST['beschreibung']);
    }

    
    
    
    
    $ex=explode('{p4n,}',$_POST['pool_obj']);
    foreach ($ex as $wert) {
        $ex2=explode('{p4n:}',$wert);
        if (is_string($ex2[1])) {
            if ($ex2[1]!='-1' && $ex2[1]!='') {
                if ($ex2[0]=='beschreibung') {
                    $pool_obj1[$ex2[0]]=$_POST['beschreibung'];
                } else {
                    $pool_obj1[$ex2[0]]=$ex2[1];
                }
            }
        }
    }
    /*if (!isset($pool_obj1['art']) && !isset($pool_obj1['Art'])) {
        $pool_obj1['art']='lead';
    }*/
    unset($pool_obj1['undefined']);
    $pool_obj['pool_obj']=$pool_obj1;
    
 
    
    $pool_obj['betreuer_id']=$pool_obj['pool_obj']['betreuer_id'];
    unset($pool_obj['pool_obj']['betreuer_id']);
    
    
 
    if (intval($pool_obj['betreuer_id'])<=0) {
        $pool_obj['betreuer_id']=$_SESSION['user_id'];
    }
    if (intval($pool_obj['status'])<=0) {
        $pool_obj['status']=0;
    }
    
    
    if (!isset($pool_obj['pool_obj']['ersteller_id']) || intval($pool_obj['pool_obj']['ersteller_id'])<=0) {
        $pool_obj['ersteller_id']=$_SESSION['user_id'];
    } else {
        $pool_obj['ersteller_id']=$db->dbzahl($pool_obj['pool_obj']['ersteller_id']);
    }
    unset($pool_obj['pool_obj']['ersteller_id']);
    
    
    if (!isset($pool_obj['pool_obj']['datum_eintrag']) || $pool_obj['pool_obj']['datum_eintrag']=='') {
        $pool_obj['datum_eintrag']=$db->dbtimestamp(time());
    } else {
        $pool_obj['datum_eintrag']=$db->dbtimestamp($pool_obj['pool_obj']['datum_eintrag']);
    }
    unset($pool_obj['pool_obj']['datum_eintrag']);
    
    
    
    $pool_obj['letzte_aenderung']=$db->dbtimestamp(time());
    
  
 
    
    
    $pool_obj['pool_obj']=$db->str(base64_encode(serialize($pool_obj['pool_obj'])));
    
    
    $sqlt=array();
    foreach ($pool_obj as $key => $value) {
        $sqlt[$sql_tabs['bdc_pool'][$key]]=$value;
    }
    
    if (isset($_POST['bdc_pool_id']) && intval($_POST['bdc_pool_id'])>0) {
        $res = $db->update(
            $sql_tab['bdc_pool'], 
            $sqlt,
            $sql_tabs['bdc_pool']['bdc_pool_id'].'='.$db->dbzahl($_POST['bdc_pool_id'])
        );
    } else {
        $res = $db->insert(
            $sql_tab['bdc_pool'], 
            $sqlt
        );
    }

    
    Modern_Helper_Request::requestFlush();
}


if (isset($_POST['removeFromBdcPool'])) {
    Modern_Helper_Request::requestStart();
    /*$res = $db->delete(
        $sql_tab['bdc_pool'], 
        $sql_tabs['bdc_pool']['bdc_pool_id'].'='.$db->dbzahl($_POST['removeFromBdcPool'])
    );*/
    
    $res = $db->update(
        $sql_tab['bdc_pool'], 
        array($sql_tabs['bdc_pool']['status']=>$db->dbzahl(-1)),
        $sql_tabs['bdc_pool']['bdc_pool_id'].'='.$db->dbzahl($_POST['removeFromBdcPool'])
    );
    
    exit;
}



$from_bdc_pool=false;
if (isset($_GET['getBdcPoolData'])) {
    $from_bdc_pool=true;
    $res = $db->select(
        $sql_tab['bdc_pool'], 
        array(
            $sql_tabs['bdc_pool']['bdc_pool_id'],//0
            $sql_tabs['bdc_pool']['pool_obj'],//1
            $sql_tabs['bdc_pool']['ersteller_id'],//2
            $sql_tabs['bdc_pool']['datum_eintrag'],//3
            $sql_tabs['bdc_pool']['betreuer_id'],//4
            $sql_tabs['bdc_pool']['datum_wvl'],//5
            $sql_tabs['bdc_pool']['status'],//6
            $sql_tabs['bdc_pool']['letzte_aenderung']//7
        ),
        $sql_tabs['bdc_pool']['bdc_pool_id'].'='.$db->dbzahl($_GET['getBdcPoolData'])
    );
    if ($row = $db->zeile($res)) {
        $bdc_pool_obj=unserialize(base64_decode($row[1]));
      //  echo '<pre>';
       // print_r($bdc_pool_obj);
       // echo '</pre>';
        $returnstr='';
        $kfz='';

        preg_match('/KKennzeichen\:[\s]*([a-zA-Z\-]*[\s]*[0-9\-]*)/i', $bdc_pool_obj['beschreibung'],$matches);
        if ($matches && $matches[1]!='') {
            $kennzeichen_suche=$matches[1];
           // $kennzeichen_suche='WI-NE 70';
            $res2 = $db->select(
                $sql_tab['produktzuordnung'], 
                array(
                    $sql_tabs['produktzuordnung']['produktzuordnung_id'],//0
                    $sql_tabs['produktzuordnung']['typ_modell'],//1
                ),
                $sql_tabs['produktzuordnung']['kennzeichen'].' LIKE '.$db->dbstr('%'.$kennzeichen_suche.'%')
            );
            while ($row2=$db->zeile($res2)) {
                $kfz.='<option value="'.$row2[0].'">'._KFZ_SUCHE_.': '.$row2[1].'</option>';
            }
        }
        
        foreach ($bdc_pool_obj as $key => $val) {
            $returnstr.=$key.'{p4n:}'.$val.'{p4n,}';
        }
        
        $returnstr.='datum_eintrag'.'{p4n:}'.$row[3].'{p4n,}';
        $returnstr.='betreuer_id'.'{p4n:}'.$row[4].'{p4n,}';
        $returnstr=substr($returnstr,0,-6);
        
        $returnstr=nl2br($returnstr);
        $returnstr=p4n_mb_string('str_replace',array("\r\n","\r","\n",'\r\n','\r','\n'),'',$returnstr);
  
        Modern_Template_StructureJs::pushFooterOnReady('jq1112(document).ready(function ($) { autoloadBdcPoolByData('.$row[0].',\''.$returnstr.'\',\''.$kfz.'\'); });');
    }
 
}


if (!array_key_exists($benutzer_selected, $bens2_online)) {
    $benutzer_selected=-1;
}
 

$get_mandanten_where='';
if (p4n_mb_string('substr', $_SESSION['cfg_kunde'], 0, p4n_mb_string('strlen', 'carlo_opel_avag'))=='carlo_opel_avag') {
    $get_mandanten_where=$sql_tabs['mandant']['firma'].'!='.$db->str('');
}

$lagerortauswahl = 0;
if ($cfg_bdc_lagerorte>0) {
    $lagerortauswahl=intval($cfg_bdc_lagerorte);
}

$get_mandanten = get_mandanten(true, $lagerortauswahl, $get_mandanten_where);
$get_mandanten2 = get_mandanten(false, $lagerortauswahl, $get_mandanten_where);

if (!function_exists('kampagnen_select_js')) {
    $kkats2=array();
    $res2=$db->select(
        $sql_tab['kategorie'],
        array(
            $sql_tabs['kategorie']['bezeichnung'],
            $sql_tabs['kategorie']['zusatz1']
        ),
        $sql_tabs['kategorie']['modul'].'=2'
    );
    while ($row2=$db->zeile($res2)) {
        $row2[0]=p4n_mb_string('str_replace',"'", '', $row2[0]);
        $kkats2[$row2[0]]=$row2[0];
    }
    $res2=$db->select(
        $sql_tab['korrespondenz'],
        'distinct '.$sql_tabs['korrespondenz']['kategorie']
    );
    while ($row2=$db->zeile($res2)) {
        $row2[0]=p4n_mb_string('str_replace',"'", '', $row2[0]);
        $kkats2[$row2[0]]=$row2[0];
    }
    unset($kkats2['']);

    $js_kamp=' this.form.elements[\'form_lead_kategorie\'].value=\'-1\'; ';
    $res2=$db->select(
        $sql_tab['kampagne_kategorie'],
        array(
            $sql_tabs['kampagne_kategorie']['kampagne_id'],
            $sql_tabs['kampagne_kategorie']['bezeichnung']
        ),
        $sql_tabs['kampagne_kategorie']['als_standard'].'='.$db->dblogic(true)
    );
    while ($row2=$db->zeile($res2)) {
        $row2[0]=p4n_mb_string('str_replace',"'", '', $row2[0]);
        if ($row2[1]!='') {
            $kkats2[$row2[1]]=$row2[1];
            $js_kamp.=' if (this.options[this.selectedIndex].value==\''.$row2[0].'\') { this.form.elements[\'form_lead_kategorie\'].value=\''.$row2[1].'\'; alert(\''._KATEGORIE_.' ' ._AENDERUNG_.': '.$row2[1].'\'); } ';
        }
    }
    @ksort($kkats2);
    $js_kamp2=$js_kamp;
}

if ($cfg_bdc_nl) {
    $lalbevorzugtekontaktzeit1 = array('', _WOCHENTAG_, _WOCHENENDE_, _SONNTAG_, _MONTAG_, _DIENSTAG_, _MITTWOCH_, _DONNERSTAG_, _FREITAG_, _SAMSTAG_);
    $lalbevorzugtekontaktzeit2 = array('', _DAVOR_ . ' 09:00', '09:00-12:00', '12:00-14:00', '14:00-18:00', '18:00-21:00', '21:00-24:00');
    $alle_abteilungen = array('0' => 'Sales', '1' => 'Service','2'=>'Used');
    $priority_bez = array();
    $priority_bez['-1'] = '';
    $priority_bez['2'] = _KPRIO2_;
    $priority_bez['1'] = _KPRIO1_;
    $priority_bez['0'] = _KPRIO3_;
    $priority_auswahl = 1;
}



$def_land1 = 'Deutschland';
if (isset($cfg_neuanlage_standardland)) {
    if ($cfg_neuanlage_standardland != '') {
        $def_land1 = $cfg_neuanlage_standardland;
    }
}
if ($cfg_ws_avag_kroatien) {
    $def_land1='Hrvatska';
}


$suchekunde_millisek=300;
if (isset($cfg_kfzsuche_kundensuche_delay)) {
    if (intval($cfg_kfzsuche_kundensuche_delay)>0) {
        $suchekunde_millisek=$cfg_kfzsuche_kundensuche_delay*1000;
    }
}

$alle_dealer = $get_mandanten[1];
$form_kunde_standort=array();
$form_kunde_standort_lead=array();
foreach ($alle_dealer as $id => $displayName) {
    if ($id == -1) {
        continue;
    }
    //$form_kunde_standort[$id]=$displayName;
    $form_kunde_standort_lead[$id]=$displayName;
    if (p4n_mb_string('substr',$displayName,0,3)== '-- ') {
        $form_kunde_standort[$id]=$displayName;
    } else {
        $form_kunde_standort[$displayName]='OPTGROUP';
    }
}


$bmtage1=2;
$zielz=time();
if (isset($cfg_bm_zielzeit)) {
    $zielz=time()+$cfg_bm_zielzeit*60*60;
    $bmtage1=$cfg_bm_zielzeit/24;
} else {
    $zielz=time()+48*60*60;
}
$alle_ben_feiertage=array();
$alle_ben_termine=array();
$alle_ben_termine[$user_id] = feiertage_jebenutzeralle($user_id);
if ($_SESSION['crm_version']>64) {
    if (count($alle_ben_feiertage[$user_id])>0) {
        while (adodb_date('w', $zielz)==0 or adodb_date('w', $zielz)==6 or isset($alle_ben_feiertage[$user_id][adodb_date('d.m.Y', $zielz)])) {
            $zielz+=24*60*60;
        }
    } else {
        while (adodb_date('w', $zielz)==0 or adodb_date('w', $zielz)==6) {
            $zielz+=24*60*60;
        }
    }
} else {
    if (count($alle_ben_feiertage[$user_id])>0) {
        $kp_tag=time();
        $iz1=1;
        while ($iz1<=$bmtage1) {
            while (adodb_date('w', $kp_tag)==0 or adodb_date('w', $kp_tag)==6 or isset($alle_ben_feiertage[$user_id][adodb_date('d.m.Y', $kp_tag)])) {
                $kp_tag+=24*60*60;
            }
            $iz1++;
            $kp_tag+=24*60*60;
        }
        while (adodb_date('w', $kp_tag)==0 or adodb_date('w', $kp_tag)==6 or isset($alle_ben_feiertage[$user_id][adodb_date('d.m.Y', $kp_tag)])) {
            $kp_tag+=24*60*60;
        }
        $zielz=$kp_tag;
    } else {
        $kp_tag=time();
        $iz1=1;
        while ($iz1<=$bmtage1) {
            while (adodb_date('w', $kp_tag)==0 or adodb_date('w', $kp_tag)==6) {
                $kp_tag+=24*60*60;
            }
            $iz1++;
            $kp_tag+=24*60*60;
        }
        while (adodb_date('w', $kp_tag)==0 or adodb_date('w', $kp_tag)==6) {
            $kp_tag+=24*60*60;
        }
        $zielz=$kp_tag;
    }
}
if (isset($postfeld['nora']) or isset($getfeld['nora'])) {
        $nora=true;
}

if ($cfg_bm_keinearten) {
        $arten=array();
} else {
        $arten[_BM_ART1_]=_BM_ART1_;
        $arten[_BM_ART2_]=_BM_ART2_;
        $arten[_BM_ART3_]=_BM_ART3_;
        $arten[_BM_ART4_]=_BM_ART4_;
}
$res=$db->select(
    $sql_tab['kategorie'],
    $sql_tabs['kategorie']['bezeichnung'],
    $sql_tabs['kategorie']['modul'].'='.($nora?'20':'14'),
    $sql_tabs['kategorie']['rang'].' asc, '.$sql_tabs['kategorie']['kategorie_id'].' asc'
);
while ($row=$db->zeile($res)) {
    $arten[$row[0]]=$row[0];
}

$kategorien=array();
$res=$db->select(
    $sql_tab['kategorie'],
    array(
    $sql_tabs['kategorie']['bezeichnung'],
        $sql_tabs['kategorie']['modul'],
        $sql_tabs['kategorie']['zusatz2']
    ),
    $sql_tabs['kategorie']['modul'].'='.($nora?'21':'16'),
    $sql_tabs['kategorie']['rang'].' asc, '.$sql_tabs['kategorie']['kategorie_id'].' asc'
);
while ($row=$db->zeile($res)) {
    if ($row[1]==16) {
        if ($row[2]=='1') {
            continue;
        }
    }
    $kategorien[$row[0]]=$row[0];
}
/*$bm_kategorien2=array();
if (!$cfg_bdc_kategorie2_multiselect) {
    $bm_kategorien2[_KEINE_] = _KEINE_;
}
if (!empty($cfg_bm_kategorien2)) {
    foreach ($cfg_bm_kategorien2 as $kat2) {
        $bm_kategorien2[$kat2] = $kat2;
    }
}*/
// Rollenrechte
$user_role_rights = array();
if (!empty($_SESSION['user_role_rights'])) {
    $user_role_rights = $_SESSION['user_role_rights'];
}
$bm_kategorien5 = array();
if (!$nora and !empty($cfg_bm_kategorien5)) {
    if (count_p4n($cfg_bm_kategorien5)>0) {
        foreach ($cfg_bm_kategorien5 as $kat5) {
            if (!empty($user_role_rights['ticket_kategorie5']) && !in_array($kat5, $user_role_rights['ticket_kategorie5'])) {
                continue;
            }
            $bm_kategorien5[$kat5]=$kat5;
        }
    }
}
$bm_kfzmarken = array();
if (!empty($cfg_bm_kfzmarken)) {
    foreach ($cfg_bm_kfzmarken as $make) {
        if (!empty($user_role_rights['ticket_kfzmarke']) && !in_array($make, $user_role_rights['ticket_kfzmarke'])) {
            continue;
        }
        $bm_kfzmarken[$make] = $make;
    }
}
if (($_SESSION['crm_version']>61 or $cfg_bdc_grund) and !$cfg_bdc_nl) {
    function saveInBdcDB($stdid,$mandant_id,$lagerort_id,$grund,$apid=0,$art='',$kid=0,$tid=0, $bdc_kanal='') {
        global $db,$sql_tab,$sql_tabs, $user_id, $cfg_bdc_kanal;

        if (isset($_GET['ohnecc'])) {
            return;
        }

        if ($stdid<=0) {
            $p='form_kunde_';
            $nur_includen=true;
            include('serviceannahme.php');

            $feld['kname']='';
            $feld['bdc']=1;

            $postfeld['form_kunde_stdid']=sc_eintrag_neu($feld);
            $postfeld['form_kunde_sct']=1;
            $postfeld['form_kunde_standort']=1;
            $_SESSION['stammdaten_id']=$postfeld['form_kunde_stdid'];
            $stdid=$postfeld['form_kunde_stdid'];
            
            $apid=0;
        }
        
        $bdc_tabs = array(
            $sql_tabs['bdc']['erstellt_am'] => $db->dbtimestamp(time()),
            $sql_tabs['bdc']['benutzer_id'] => $db->dbzahl($user_id),
            $sql_tabs['bdc']['mandant_id'] => $db->dbzahl($mandant_id),          
            $sql_tabs['bdc']['lagerort_id'] => $db->dbzahl($lagerort_id),   
            $sql_tabs['bdc']['stammdaten_id'] => $db->dbzahl($stdid),
            $sql_tabs['bdc']['ansprechpartner_id'] => $db->dbzahl($apid),
            $sql_tabs['bdc']['art'] => $db->str($art),
            $sql_tabs['bdc']['kampagne_lead_id'] => $db->dbzahl($kid),
            $sql_tabs['bdc']['troubleticket_id'] => $db->dbzahl($tid),
            $sql_tabs['bdc']['grund'] => $db->str($grund)
        );
        if ($cfg_bdc_kanal) {
            if (isset($sql_tabs['bdc']['bdc_kanal']) && $bdc_kanal!=-1) {
                $bdc_tabs[$sql_tabs['bdc']['bdc_kanal']] = $db->str($bdc_kanal);
            }
        }
        $db->insert(
            $sql_tab['bdc'], 
            $bdc_tabs
        ); 
    }
}

if (isset($postfeld['form_kunde_submit'])) {
   // Modern_Helper_Request::requestStart();
    $lagid = 0;
    
    $p='form_kunde_';
    /*if (isset($postfeld['form_kunde_standort']) && $postfeld['form_kunde_standort']>0) {
        $mandid = $get_mandanten2[2][$postfeld['form_kunde_standort']];
        $lagid = $postfeld['form_kunde_standort'];
    }*/
    
    if (isset($postfeld['form_kunde_standort']) and intval($postfeld['form_kunde_standort']) > 0) {
        list($mandid,$lagid)=bdc_bereinige_standort($postfeld['form_kunde_standort'], 0);
    }
    
    $anzname = eingabe2anzeigename($postfeld['form_kunde_vorname'], $postfeld['form_kunde_name'], $postfeld['form_kunde_titel'], $postfeld['form_kunde_firma'], $postfeld['form_kunde_anrede']);
    
    $vorname=$postfeld['form_kunde_vorname'];
    if ($cfg_bdc_nl) {

        $rufname='';
        if ($postfeld['form_kunde_rufname']!='') {
            $rufname=$postfeld['form_kunde_rufname'];
        }
        $mittelname='';
        if ($postfeld['form_kunde_mittelname']!='') {
            $mittelname=$postfeld['form_kunde_mittelname'];
        }
        
        
        if ($cfg_kfzsuche_holland and $mittelname!='') {
            if (p4n_mb_string('substr',$vorname, -p4n_mb_string('strlen',$mittelname))==$mittelname) {
                $vorname=trim(p4n_mb_string('substr',$vorname, 0, -p4n_mb_string('strlen',$mittelname)));
            }
            
            $vorname.=' '.$mittelname;
            $vorname=trim($vorname);
        }
        
        
        $anzname = eingabe2anzeigename($vorname, $postfeld['form_kunde_name'], $postfeld['form_kunde_titel'], $postfeld['form_kunde_firma'], $postfeld['form_kunde_anrede'],$rufname,$mittelname);
    }
    
    
    $briefan = _BRIEFANREDE_FIRMA_;
    if (p4n_mb_string('substr', p4n_mb_string('strtolower', $postfeld['form_kunde_anrede']), 0, p4n_mb_string('strlen', _HERR_)) == p4n_mb_string('strtolower', _HERR_)) {
        $briefan = _BRIEFANREDE_HERR_;
    } elseif (p4n_mb_string('substr', p4n_mb_string('strtolower', $postfeld['form_kunde_anrede']), 0, p4n_mb_string('strlen', _FRAU_)) == p4n_mb_string('strtolower', _FRAU_)) {
        $briefan = _BRIEFANREDE_FRAU_;
    }
    if ($postfeld['form_kunde_anrede']=='' && !($postfeld['form_kunde_firma']!='')) {
		$briefan='';
	}
    
    $sqlt = array(
        $sql_tabs['stammdaten']['betreuer'] => $db->dbzahl($user_id),
        $sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'vpb' :  'mandant'] => $db->dbzahl($mandid),
        $sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'mandant' : 'vpb'] => $db->dbzahl($lagid),
        $sql_tabs['stammdaten']['anzeigename'] => $db->str($anzname),
        $sql_tabs['stammdaten']['vorname'] => $db->str($vorname),
        $sql_tabs['stammdaten']['name'] => $db->str($postfeld['form_kunde_name']),
        $sql_tabs['stammdaten']['firma1'] => $db->str($postfeld['form_kunde_firma']),
        $sql_tabs['stammdaten']['anrede'] => $db->str($postfeld['form_kunde_anrede']),
        $sql_tabs['stammdaten']['briefanrede'] => $db->str($briefan),
        $sql_tabs['stammdaten']['titel'] => $db->str($postfeld['form_kunde_titel']),
        $sql_tabs['stammdaten']['Telefon_1'] => $db->str($postfeld['form_kunde_telefon_privat']),
        $sql_tabs['stammdaten']['Telefon_2'] => $db->str($postfeld['form_kunde_telefon_ges']),
        $sql_tabs['stammdaten']['Mobilfon_1'] => $db->str($postfeld['form_kunde_mobil_privat']),
        $sql_tabs['stammdaten']['Mobilfon_2'] => $db->str($postfeld['form_kunde_mobil_ges']),
        $sql_tabs['stammdaten']['EMail_1'] => $db->str($postfeld['form_kunde_email_privat']),
        $sql_tabs['stammdaten']['EMail_2'] => $db->str($postfeld['form_kunde_email_ges']),
        $sql_tabs['stammdaten']['source'] => $db->str('bdc'),
        $sql_tabs['stammdaten']['bemerkung'] => $db->str($postfeld['form_kunde_st_bemerkung'])
    );
	if ($_SESSION['cfg_kunde']=='crm_bmw_widmann') {
		$res3=$db->select(
							$sql_tab['crmcodes'],
							array(
								$sql_tabs['crmcodes']['crmcodes_id'],
								$sql_tabs['crmcodes']['code1'],
								$sql_tabs['crmcodes']['text1']
							),
							$sql_tabs['crmcodes']['art'].'='.$db->str('CARLO_ANREDEN').' and '.$sql_tabs['crmcodes']['text1'].' like '.$db->str($postfeld['form_kunde_anrede'])
		);
		if ($row3=$db->zeile($res3)) {
			$sqlt[$sql_tabs['stammdaten']['anredecode']]=$db->str($row3[1]);
		}
		if (preg_match('/firma/i', $postfeld['form_kunde_anrede'])) {
			$sqlt[$sql_tabs['stammdaten']['anredecode']]=$db->str('FA');
		}
	}
    
    if ($cfg_bdc_nl && $postfeld['form_kunde_firma']=='') {
        if ($postfeld['form_kunde_rufname']!='') {
            $sqlt[$sql_tabs['stammdaten']['firma2']]=$db->str($postfeld['form_kunde_rufname']);
        }
        if ($postfeld['form_kunde_mittelname']!='') {
            $sqlt[$sql_tabs['stammdaten']['firma3']]=$db->str($postfeld['form_kunde_mittelname']);
        }
    }
    
    if ($_SESSION['cfg_kunde']=='carlo_opel_eisner' or $_SESSION['cfg_kunde']=='carlo_opel_eisner_kaernten') {
		$sqlt[$sql_tabs['stammdaten']['zusatz3']]=$db->str('AKTIV');
		$postfeld['form_kunde_zusatz3']='AKTIV';
	}

    if (intval($postfeld['form_kunde_stdid'])>0) {
        $neuid=$postfeld['form_kunde_stdid'];
    } else {
        $neuid = schreibe_stid_bdc();
    }
    $db->update(
            $sql_tab['stammdaten'], $sqlt, $sql_tabs['stammdaten']['id'] . '=' . $db->dbzahl($neuid)
    );
    suchfeld_update($neuid);
	$ist_neuanlage=false;
    if (intval($postfeld['form_kunde_stdid'])>0) {
        
    } else {
        if (is_file('inc/nachneuanlage.php')) {
            include_once('inc/nachneuanlage.php');
            nachneuanlage($neuid);
        }
		$ist_neuanlage=true;
    }
	
    
    
    
    if (intval($postfeld['form_kunde_stdid'])>0) {
        $sql_update_adresse = array(
            $sql_tabs['stammdaten_adresse']['stammdaten_id'] => $db->dbzahl($neuid),
            $sql_tabs['stammdaten_adresse']['adresse'] => $db->str($postfeld['adresse']),
            $sql_tabs['stammdaten_adresse']['plz'] => $db->str($postfeld['plz']),
            $sql_tabs['stammdaten_adresse']['ort'] => $db->str($postfeld['ort']),
            $sql_tabs['stammdaten_adresse']['land'] => $db->str($postfeld['land']),
            $sql_tabs['stammdaten_adresse']['art'] => $db->dbzahl(0),
            $sql_tabs['stammdaten_adresse']['post'] => $db->dblogic(true),
            $sql_tabs['stammdaten_adresse']['beginn'] => $db->dbtimestamp(time()),
            $sql_tabs['stammdaten_adresse']['ende'] => $db->dbdate(''),
            $sql_tabs['stammdaten_adresse']['mandant_id'] => $db->dbzahl($mandid),
            $sql_tabs['stammdaten_adresse']['kategorie'] => $db->str('')
        );
        if (isset($sql_tabs['stammdaten_adresse']['mandanten_entfernung']) && file_exists('_plz_distanz_nachberechnung.php')) {
            $sql_update_adresse[$sql_tabs['stammdaten_adresse']['mandanten_entfernung']] = 'null';
        }
        
        $db->update(
            $sql_tab['stammdaten_adresse'], 
            $sql_update_adresse,
            $sql_tabs['stammdaten_adresse']['stammdaten_id'].'='.$db->dbzahl($postfeld['form_kunde_stdid'])
       );    
    } else {
        $postfeld['form_kunde_stdid']=$neuid;
        $db->insert(
                $sql_tab['stammdaten_adresse'], array(
            $sql_tabs['stammdaten_adresse']['stammdaten_id'] => $db->dbzahl($neuid),
            $sql_tabs['stammdaten_adresse']['adresse'] => $db->str($postfeld['adresse']),
            $sql_tabs['stammdaten_adresse']['plz'] => $db->str($postfeld['plz']),
            $sql_tabs['stammdaten_adresse']['ort'] => $db->str($postfeld['ort']),
            $sql_tabs['stammdaten_adresse']['land'] => $db->str($postfeld['land']),
            $sql_tabs['stammdaten_adresse']['art'] => $db->dbzahl(0),
            $sql_tabs['stammdaten_adresse']['post'] => $db->dblogic(true),
            $sql_tabs['stammdaten_adresse']['beginn'] => $db->dbtimestamp(time()),
            $sql_tabs['stammdaten_adresse']['ende'] => $db->dbdate(''),
            $sql_tabs['stammdaten_adresse']['mandant_id'] => $db->dbzahl($mandid),
            $sql_tabs['stammdaten_adresse']['kategorie'] => $db->str('')
            )
        ); 
    }
	
	if (($cfg_f1allg_rueck && !$cfg_bdc_neuanlage_dms_rueck) || ($cfg_f1allg_rueck && $cfg_bdc_neuanlage_dms_rueck && $postfeld['form_kunde_vaudixVersand']==1)) {
		include_once('inc/f1allg.php');
		if (!$ist_neuanlage) {
			f1allg_writecustomer($neuid, false);
		} else {
			f1allg_writecustomer($neuid, true);
			if ($_SESSION['stammdaten_id']!=$neuid) {
				$neuid=$_SESSION['stammdaten_id'];
				$postfeld['form_kunde_stdid']=$neuid;
			}
		}
	}
    if (($cfg_md_rueck && !$cfg_bdc_neuanlage_dms_rueck) || ($cfg_md_rueck && $cfg_bdc_neuanlage_dms_rueck && $postfeld['form_kunde_vaudixVersand']==1)) {
		include_once('inc/lib_md.php');
		if (!$ist_neuanlage) {
			md_writecustomer($neuid, false);
		} else {
			md_writecustomer($neuid, true);
			if ($_SESSION['stammdaten_id']!=$neuid) {
				$neuid=$_SESSION['stammdaten_id'];
				$postfeld['form_kunde_stdid']=$neuid;
			}
		}
	}
    if (($cfg_vx_rueck && !$cfg_bdc_neuanlage_dms_rueck) || ($cfg_vx_rueck && $cfg_bdc_neuanlage_dms_rueck && $postfeld['form_kunde_vaudixVersand']==1)) {
		include_once('inc/lib_vaudisx.php');
		if (!$ist_neuanlage) {
			vx_writecustomer($neuid, false);
		} else {
			vx_writecustomer($neuid, true);
			if ($_SESSION['stammdaten_id']!=$neuid) {
				$neuid=$_SESSION['stammdaten_id'];
				$postfeld['form_kunde_stdid']=$neuid;
			}
		}
	}
    if (($cfg_attribut_rueck && !$cfg_bdc_neuanlage_dms_rueck) || ($cfg_attribut_rueck && $cfg_bdc_neuanlage_dms_rueck && $postfeld['form_kunde_vaudixVersand']==1)) {
		include_once('inc/lib_attr.php');
		if (!$ist_neuanlage) {
			attr_writecustomer($neuid, false);
		} else {
			attr_writecustomer($neuid, true);
			if ($_SESSION['stammdaten_id']!=$neuid) {
				$neuid=$_SESSION['stammdaten_id'];
				$postfeld['form_kunde_stdid']=$neuid;
			}
		}
	}
    if (($cfg_loco_rueck && !$cfg_bdc_neuanlage_dms_rueck) || ($cfg_loco_rueck && $cfg_bdc_neuanlage_dms_rueck && $postfeld['form_kunde_vaudixVersand']==1)) {
		include_once('inc/lib_loco.php');
		if (!$ist_neuanlage) {
			loco_writecustomer($neuid, false);
		} else {
			loco_writecustomer($neuid, true);
			if ($_SESSION['stammdaten_id']!=$neuid) {
				$neuid=$_SESSION['stammdaten_id'];
				$postfeld['form_kunde_stdid']=$neuid;
			}
		}
	}
    if (($cfg_ecaros_rueck && !$cfg_bdc_neuanlage_dms_rueck) || ($cfg_ecaros_rueck && $cfg_bdc_neuanlage_dms_rueck && $postfeld['form_kunde_vaudixVersand']==1)) {
		include_once('inc/lib_ecaros.php');
		if (!$ist_neuanlage) {
			ecaros_writecustomer($neuid, false);
		} else {
			ecaros_writecustomer($neuid, true);
			if ($_SESSION['stammdaten_id']!=$neuid) {
				$neuid=$_SESSION['stammdaten_id'];
				$postfeld['form_kunde_stdid']=$neuid;
			}
		}
	}
    if (($cfg_betzemeier_rueck && !$cfg_bdc_neuanlage_dms_rueck) || ($cfg_betzemeier_rueck && $cfg_bdc_neuanlage_dms_rueck && (int)$postfeld['form_kunde_vaudixVersand'] === 1)) {
        if ($ist_neuanlage) {
            Betzemeier::writeCustomer($neuid, true);
            if ($_SESSION['stammdaten_id'] !== $neuid) {
                $neuid = $_SESSION['stammdaten_id'];
                $postfeld['form_kunde_stdid'] = $neuid;
            }
        } else {
            Betzemeier::writeCustomer($neuid, false);
        }
    }
    if (isset($postfeld['dse_druck']) && $neuid>0) {
        dse_druck_datei($neuid);
    }
}


/*SCT*/
if (isset($postfeld['form_kunde_submit2'])) {
    $p='form_kunde_';
    $nur_includen=true;
    include('serviceannahme.php');
    
    $feld['kname']='';
    $feld['bdc']=1;
    
    $postfeld['form_kunde_stdid']=sc_eintrag_neu($feld);
    $postfeld['form_kunde_sct']=1;
    $postfeld['form_kunde_standort']=1;
    $_SESSION['stammdaten_id']=$postfeld['form_kunde_stdid'];
}

$updateCustomer=0;
if (isset($postfeld['form_anfrage_zusatz_kundendaten']) && $postfeld['form_anfrage_zusatz_kundendaten']!="") {
    if (class_exists('xss')) {
        $postfeld['form_anfrage_zusatz_kundendaten'] = xss::decodeString($postfeld['form_anfrage_zusatz_kundendaten']);
    }
    $exp1=explode('#####',$postfeld['form_anfrage_zusatz_kundendaten']);
    foreach ($exp1 as $exp1_val) {
        $exp2=explode("=",$exp1_val);
        $postfeld[$exp2[0]]=$exp2[1];
        $updateCustomer=1;
    }
}
if (isset($postfeld['form_beschwerde_zusatz_kundendaten']) && $postfeld['form_beschwerde_zusatz_kundendaten']!="") {
    if (class_exists('xss')) {
        $postfeld['form_beschwerde_zusatz_kundendaten'] = xss::decodeString($postfeld['form_beschwerde_zusatz_kundendaten']);
    }
    $exp1=explode('#####',$postfeld['form_beschwerde_zusatz_kundendaten']);
    foreach ($exp1 as $exp1_val) {
        $exp2=explode("=",$exp1_val);
        $postfeld[$exp2[0]]=$exp2[1];
        $updateCustomer=1;
    }
}

// D70 - Sales Feedback Punkt 98 (ansprechpartner_id is overwritten for no apparent reason?)
if (isset($_SESSION['design_70']) && ($postfeld['form_kunde_ansprechpartner_id'] !== $_POST['form_kunde_ansprechpartner_id'])) {
    $postfeld['form_kunde_ansprechpartner_id'] = $_POST['form_kunde_ansprechpartner_id'];
}

if (isset($postfeld['form_lead_zusatz_kundendaten']) && $postfeld['form_lead_zusatz_kundendaten']!="") {
    if (class_exists('xss')) {
        $postfeld['form_lead_zusatz_kundendaten'] = xss::decodeString($postfeld['form_lead_zusatz_kundendaten']);
    }
    $exp1=explode('#####',$postfeld['form_lead_zusatz_kundendaten']);
    foreach ($exp1 as $exp1_val) {
        $exp2=explode("=",$exp1_val);
        $postfeld[$exp2[0]]=$exp2[1];
        debug_logging('PostFeld: '.print_r($postfeld,true));
        $updateCustomer=1;
    }
}
if (isset($postfeld['form_sonstiges_zusatz_kundendaten']) && $postfeld['form_sonstiges_zusatz_kundendaten']!="") {
    if (class_exists('xss')) {
        $postfeld['form_sonstiges_zusatz_kundendaten'] = xss::decodeString($postfeld['form_sonstiges_zusatz_kundendaten']);
    }
    $exp1=explode('#####',$postfeld['form_sonstiges_zusatz_kundendaten']);
    foreach ($exp1 as $exp1_val) {
        $exp2=explode("=",$exp1_val);
        $postfeld[$exp2[0]]=$exp2[1];
        debug_logging('PostFeld: '.print_r($postfeld,true));
        $updateCustomer=1;
    }
}

if (
    ($postfeld['form_kunde_sct']!=1) && 
    (isset($postfeld['form_kunde_ap_bezeichnung']) && $postfeld['form_kunde_ap_bezeichnung']!="") &&
    (isset($postfeld['form_kunde_stdid']) && intval($postfeld['form_kunde_stdid']) > 0)
)
{
    //if (isset($postfeld['form_kunde_standort']) and intval($postfeld['form_kunde_standort'])>0) {
        list($mandid_ap,$lagid_ap)=bdc_bereinige_standort($postfeld['form_kunde_standort'],$postfeld['form_kunde_stdid']);
    //}
    if ($lagid_ap==0) {
       $lagid = $mandid_ap; 
    }
    
    $p='form_kunde_ap_';
    
    $sqlt= array(
        $sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'] => $db->dbzahl($postfeld['form_kunde_stdid']),
        $sql_tabs['stammdaten_ansprechpartner']['bezeichnung'] => $db->str($postfeld['form_kunde_ap_bezeichnung']),
        $sql_tabs['stammdaten_ansprechpartner']['telefon'] => $db->str($postfeld['form_kunde_ap_telefon']),
        $sql_tabs['stammdaten_ansprechpartner']['mobil'] => $db->str($postfeld['form_kunde_ap_mobil']),
        $sql_tabs['stammdaten_ansprechpartner']['email'] => $db->str($postfeld['form_kunde_ap_email']),
        $sql_tabs['stammdaten_ansprechpartner']['adresse'] => $db->str(''),
        $sql_tabs['stammdaten_ansprechpartner']['plz'] => $db->str(''),
        $sql_tabs['stammdaten_ansprechpartner']['ort'] => $db->str(''),
        $sql_tabs['stammdaten_ansprechpartner']['vorname'] => $db->str($postfeld['form_kunde_ap_vorname']),
        $sql_tabs['stammdaten_ansprechpartner']['mandant_id'] => $db->dbzahl($lagid),
        $sql_tabs['stammdaten_ansprechpartner']['anrede'] => $db->str($postfeld['form_kunde_ap_anrede']),
        $sql_tabs['stammdaten_ansprechpartner']['titel'] => $db->str($postfeld['form_kunde_ap_titel']),
        $sql_tabs['stammdaten_ansprechpartner']['anlagedatum'] => $db->dbdate(adodb_date('d.m.Y'))
    );
    if ($cfg_bdc_nl) {
        if ($postfeld['form_kunde_ap_rufname']!='') {
            $sqlt[$sql_tabs['stammdaten_ansprechpartner']['zusatz4']]=$db->str($postfeld['form_kunde_ap_rufname']);
        }
        if ($postfeld['form_kunde_ap_mittelname']!='') {
            $sqlt[$sql_tabs['stammdaten_ansprechpartner']['zusatz5']]=$db->str($postfeld['form_kunde_ap_mittelname']);
        }
    }
    
    $ap_neu=true;
    if ($postfeld['form_kunde_ansprechpartner_id']>0) {
        $ap_neu=false;
    }
    if ($ap_neu) {
        if (isset($postfeld['form_kunde_ap_change']) && intval($postfeld['form_kunde_ap_change'])!=-1000) {
            $ap_neu=false;
            $postfeld['form_kunde_ansprechpartner_id']=$postfeld['form_kunde_ap_change'];
        }
    }
    
    
    if ($ap_neu) {
        $allesok=$db->insert(
        $sql_tab['stammdaten_ansprechpartner'],
            $sqlt
        );
        $apid_neu=$db->insertid();
    } else {
        if ($postfeld['form_kunde_ansprechpartner_id']>0) {
            unset($sqlt[$sql_tabs['stammdaten_ansprechpartner']['anlagedatum']]);
            $db->update(
            $sql_tab['stammdaten_ansprechpartner'],
                $sqlt,
                $sql_tabs['stammdaten_ansprechpartner']['ansprechpartner_id'].'='.$db->dbzahl($postfeld['form_kunde_ansprechpartner_id'])
            );
            $apid_neu=$postfeld['form_kunde_ansprechpartner_id'];
        }
    }

    $apbez='';
    if ($postfeld['form_kunde_ap_vorname']!='' && $postfeld['form_kunde_ap_bezeichnung']!='') {
        $apbez=$postfeld['form_kunde_ap_bezeichnung'].', '.$postfeld['form_kunde_ap_vorname'];
    }
    if ($postfeld['form_kunde_ap_vorname']!='' && $postfeld['form_kunde_ap_bezeichnung']=='') {
        $apbez=$postfeld['form_kunde_ap_vorname'];
    }
    if ($postfeld['form_kunde_ap_vorname']=='' && $postfeld['form_kunde_ap_bezeichnung']!='') {
        $apbez=$postfeld['form_kunde_ap_bezeichnung'];
    }    
    $postfeld['form_kunde_ansprechpartner']=$apbez;
    $postfeld['form_kunde_ansprechpartner_id']=$apid_neu;
}



if (isset($postfeld['form_kunde_submit']) && isset($postfeld['form_kunde_submit_change'])) {
    echo javas('parent.bdc_reload_ap('.$postfeld['form_kunde_ansprechpartner_id'].'); parent.P4nBoxHelper.stoploading();');
}


if (isset($postfeld['form_sonstiges_submit'])) {
    
    $temp_mandant=1;
    $temp_standort=0;
    if (isset($postfeld['form_sonstiges_standort']) and intval($postfeld['form_sonstiges_standort']) > 0) {
        list($temp_mandant,$temp_standort)=bdc_bereinige_standort($postfeld['form_sonstiges_standort'],0);
    }
    
    saveInBdcDB(
        0,
        $temp_mandant,
        $temp_standort,
        ($postfeld['form_sonstiges_grund']!=-1?$postfeld['form_sonstiges_grund']:''),
        ($postfeld['form_kunde_ansprechpartner_id']!=-1?$postfeld['form_kunde_ansprechpartner_id']:0),
        '',
        0,
        0,
        $postfeld['form_sonstiges_bdc_kanal']
    );
    if ($_SESSION['design_70']) {
        exit;
    }
}
if($updateCustomer && !empty($postfeld['form_kunde_stdid']) && !empty($postfeld['form_kunde_st_bemerkung'])){
    updateCurrentCustomer($postfeld['form_kunde_stdid'],array($sql_tabs['stammdaten']['bemerkung']=>$db->str($postfeld['form_kunde_st_bemerkung'])));
}
if (isset($postfeld['form_beschwerde_submit']) || isset($postfeld['form_anfrage_submit'])) {
    $ticket = array();
    
    $erfolgtext='';
    if (isset($postfeld['form_beschwerde_submit'])) {
        $p='form_beschwerde_';
        $erfolgtext=_BESCHWERDE_.' erfolgreich angelegt';
    } else {
        $p='form_anfrage_';
        $ticket['art2']=$db->str('Anfrage');
        $erfolgtext=_ANFRAGE_.' erfolgreich angelegt';
    }
    
    $actionProtocolEntry = '';
    if (isset($postfeld['ticket_action_type'])) {
        $ticketActionTypeFields = array(
            _ANWEISUNG_ => 'anweisung',
            _ANTWORT_ => 'antwort',
            _MASSNAHME_ => 'zusatz_text1'
        );
        
        switch ($postfeld['ticket_action_type']) {
            case 'instruction':
                $ticketActionType = _ANWEISUNG_;
                $ticketActionTypeField = 'anweisung';
                break;
            case 'action':
                $ticketActionType = _ANTWORT_;
                $ticketActionTypeField = 'antwort';
                break;
            case 'measure':
                $ticketActionType = _MASSNAHME_;
                $ticketActionTypeField = 'zusatz_text1';
                break;
        }
        
        $actionProtocolEntry = Troubleticket_ProtocolEntry::create(
            $ticketActionType,
            $postfeld['ticket_action_description']
        );
        $ticket[$ticketActionTypeField] = $db->str($actionProtocolEntry);
        $ticket['protokoll'] = $db->str($actionProtocolEntry);
    }
    
    if (
        isset($postfeld['ticket_working_time']) &&
        !empty($postfeld['ticket_working_time'])
    ) {
        $ticket['arbeitszeit_minuten'] = $postfeld['ticket_working_time'];
    }
    
    if (!$_SESSION['design_70'])
    $_SESSION['stammdaten_id']=$postfeld['form_kunde_stdid'];
    
    
    //if (isset($postfeld['form_kunde_standort']) and intval($postfeld['form_kunde_standort']) > 0) {
        list($ticket['mandant_id'],$ticket['lagerort_id'])=bdc_bereinige_standort($postfeld['form_kunde_standort'],$postfeld['form_kunde_stdid']);
    //}
    if (isset($postfeld[$p.'standort']) and intval($postfeld[$p.'standort'])>0) {
        list($ticket['mandant_id'],$ticket['lagerort_id'])=bdc_bereinige_standort($postfeld[$p.'standort'],0);
    } else {
        if (isset($postfeld['form_kunde_sct']) && ($postfeld['form_kunde_sct']==1 || $postfeld['form_kunde_sct']=='1')) {
            /*$ticket['mandant_id']=1;
            $ticket['lagerort_id']=0;
            $dummy='BDC Dummy';
            $res_dummy=$db->select(
                $sql_tab['stammdaten'],
                array($sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'vpb' :  'mandant'],$sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'mandant' : 'vpb']),
                $sql_tabs['stammdaten']['id'].'>1000000 and ('.
                    $sql_tabs['stammdaten']['name'].'='.$db->str($dummy).' or '.
                    $sql_tabs['stammdaten']['firma1'].'='.$db->str($dummy).')'
            );
            if ($row_dummy=$db->zeile($res_dummy)) {
                $ticket['mandant_id']=$row_dummy[0];
                $ticket['lagerort_id']=$row_dummy[1];
            }*/
        }
    }

    $ticket['parent_id'] = $db->dbzahl(0);
    $ticket['stammdaten_id'] = $db->dbzahl($postfeld['form_kunde_stdid']);
    if ($postfeld['form_kunde_ansprechpartner_id']!=-1) {
        $ticket['ansprechpartner_id'] = $db->dbzahl($postfeld['form_kunde_ansprechpartner_id']);
    }
    
    $ticket['status'] = $db->dbzahl(1);
    if (!empty($postfeld[$p.'pool'])) {
        $ticket['status'] = $db->dbzahl(100);
    } else if (isset($postfeld[$p.'status']) && intval($postfeld[$p.'status']) > 0) {
        $ticket['status'] = $db->dbzahl($postfeld[$p.'status']);
        $ticket['datum_status'.$postfeld[$p.'status']] = $db->dbtimestamp(time());
        $tt_history=array();
        $tt_history[]=array(
                        'time' => adodb_date('d.m.Y H:i'),
                        'user' => $_SESSION['user_id'],
                        'status' => $postfeld[$p.'status']
                    );
        $ticket['history'] = $db->str(serialize($tt_history));
    }
    

    $ticket['korrespondenz_id'] = $db->dbzahl((intval($postfeld['kbezug'])>0?$postfeld['kbezug']:0));
    $ticket['kalender_id'] = $db->dbzahl(0);
    if (isset($postfeld[$p.'benutzer']) && intval($postfeld[$p.'benutzer'])>0) {
        $ticket['benutzer_id'] = $db->dbzahl($postfeld[$p.'benutzer']);
    }
    if (isset($postfeld[$p.'benutzer_hidden']) && intval($postfeld[$p.'benutzer_hidden'])>0 && $postfeld[$p.'benutzer_hidden']!='') {
        $ticket['benutzer_id'] = $db->dbzahl($postfeld[$p.'benutzer_hidden']);
    }
    if (isset($postfeld[$p.'betreuerzwei']) && intval($postfeld[$p.'betreuerzwei'])>0) {
        $ticket['benutzer_id2'] = $db->dbzahl($postfeld[$p.'betreuerzwei']);
    }
    $ticket['verursacher_id'] = $db->dbzahl($postfeld[$p.'benutzer']);
    $ticket['kampagne_id'] = $db->dbzahl(0);
    $ticket['datum'] = $db->dbtimestamp(time());
    $ticket['beschwerdezeit'] = $db->dbtimestamp(time());
    if ($ticket['status']==4) {
        $ticket['beschwerdezeit_ende']=$db->dbtimestamp(time());
    }
    $ticket['ersteller_id'] = $db->dbzahl($user_id);
    if (isset($postfeld[$p.'fahrzeug']) && $postfeld[$p.'fahrzeug']!=-1) {
        $ticket['produkt_id'] = $db->dblogicfull($postfeld[$p.'fahrzeug']);
    }
    if (isset($postfeld[$p.'rechnung']) && $postfeld[$p.'rechnung']!=-1) {
        $ticket['auftrag_id'] = $db->dblogicfull($postfeld[$p.'rechnung']);
    }
    $ticket['betreff'] = $db->str($postfeld[$p.'betreff']);
    
    if (($_SESSION['crm_version']>61 or $cfg_bdc_grund) and !$cfg_bdc_nl) {
        $ticket['grund']=$db->str(($postfeld[$p.'grund']!=-1?$postfeld[$p.'grund']:''));
    }

    $zusbetext='';
    if (isset($postfeld['form_kunde_sct']) && ($postfeld['form_kunde_sct']==1 || $postfeld['form_kunde_sct']=='1')) {
        
        $sct_bez='';
        if ($postfeld['form_kunde_firma']=='') {
            if (isset($postfeld['form_kunde_name']) && $postfeld['form_kunde_name']!='') {
                $sct_bez.=$postfeld['form_kunde_name'].', ';
            }
            if (isset($postfeld['form_kunde_vorname']) && $postfeld['form_kunde_vorname']!='') {
                $sct_bez.=$postfeld['form_kunde_vorname'].', ';
            }
        } else {
            $sct_bez.=$postfeld['form_kunde_firma'].', ';
        }
        $sct_bez=substr($sct_bez,0,-2);

        
        $zusbetext="\n\n".'{name} {kunde}{tel_kunde}{tel_kunde2}{tel_mobil}{tel_mobil2}{mail_kunde}{mail_kunde2}{adresse}{ort}';
        $zusbetext=p4n_mb_string('str_replace','{name}',($postfeld['form_kunde_firma']!=''?_FIRMA_:_KUNDE_)."\n",$zusbetext);
        $zusbetext=p4n_mb_string('str_replace','{kunde}',$sct_bez."\n",$zusbetext);

        $tel_kunde='';
        if ($postfeld['form_kunde_telefon_privat']!='') {
            $tel_kunde.=$postfeld['form_kunde_telefon_privat'].' ('._KONTAKT_PRIVAT_ABK_.')'."\n";
        }
        $zusbetext=p4n_mb_string('str_replace','{tel_kunde}',$tel_kunde,$zusbetext);

        $tel_kunde='';
        if ($postfeld['form_kunde_telefon_ges']!='') {
            $tel_kunde.=$postfeld['form_kunde_telefon_ges'].' ('._KONTAKT_GESCHAEFTLICH_ABK_.')'."\n";
        }
        $zusbetext=p4n_mb_string('str_replace','{tel_kunde2}',$tel_kunde,$zusbetext);


        $tel_mobil='';
        if ($postfeld['form_kunde_mobil_privat']!='') {
            $tel_mobil.=$postfeld['form_kunde_mobil_privat'].' ('._KONTAKT_PRIVAT_ABK_.')'."\n";
        }
        $zusbetext=p4n_mb_string('str_replace','{tel_mobil}',$tel_mobil,$zusbetext);


        $tel_mobil='';
        if ($postfeld['form_kunde_mobil_ges']!='') {
            $tel_mobil.=$postfeld['form_kunde_mobil_ges'].' ('._KONTAKT_GESCHAEFTLICH_ABK_.')'."\n";
        }
        $zusbetext=p4n_mb_string('str_replace','{tel_mobil2}',$tel_mobil,$zusbetext);


        $mail_kunde='';
        if ($postfeld['form_kunde_email_privat']!='') {
            $mail_kunde.=$postfeld['form_kunde_email_privat'].' ('._KONTAKT_PRIVAT_ABK_.')'."\n";
        }
        $zusbetext=p4n_mb_string('str_replace','{mail_kunde}',$mail_kunde,$zusbetext);

        $mail_kunde='';
        if ($postfeld['form_kunde_email_ges']!='') {
            $mail_kunde.=$postfeld['form_kunde_email_ges'].' ('._KONTAKT_GESCHAEFTLICH_ABK_.')'."\n";
        }
        $zusbetext=p4n_mb_string('str_replace','{mail_kunde2}',$mail_kunde,$zusbetext);
        
        
        $ort='';
        if ($postfeld['plz']!='') {
            $ort.=$postfeld['plz'].' ';
        }
        if ($postfeld['ort']!='') {
            $ort.=$postfeld['ort'].' ';
        }
        if ($ort!='') {
            $ort=substr($ort,0,-1)."\n";
        }
        $zusbetext=p4n_mb_string('str_replace','{ort}',$ort,$zusbetext);

        
        $adresse='';
        if ($postfeld['adresse']!='') {
            $adresse.=$postfeld['adresse']."\n";
        }
        $zusbetext=p4n_mb_string('str_replace','{adresse}',$adresse,$zusbetext);
        
        if ($_SESSION['crm_version']<=68) {
            $zusbetext2="\n"._FAHRZEUG_."\n".'{modell}{erstzulassung}{kmstand}{kennzeichen}';
        
            $modell='';
            if ($postfeld['form_kunde_modell']!='') {
                $modell.=$postfeld['form_kunde_modell']."\n";
            }
            $zusbetext2=p4n_mb_string('str_replace','{modell}',$modell,$zusbetext2);
        
             $erstzulassung='';
            if ($postfeld['form_kunde_erstzulassung']!='') {
                $erstzulassung.=$postfeld['form_kunde_erstzulassung']."\n";
            }
            $zusbetext2=p4n_mb_string('str_replace','{erstzulassung}',$erstzulassung,$zusbetext2);
        
            $kmstand='';
            if ($postfeld['form_kunde_kmstand']!='') {
                $kmstand.=$postfeld['form_kunde_kmstand']."\n";
            }
            $zusbetext2=p4n_mb_string('str_replace','{kmstand}',$kmstand,$zusbetext2);
        
            $kennzeichen='';
            if ($postfeld['form_kunde_kennzeichen']!='') {
                $kennzeichen.=$postfeld['form_kunde_kennzeichen']."\n";
            }
            $zusbetext2=p4n_mb_string('str_replace','{kennzeichen}',$kennzeichen,$zusbetext2);
            if ($modell!='' || $erstzulassung!='' || $kmstand!='' || $kennzeichen!='') {} else {
                $zusbetext2='';
            }
        }   
        
       

        $apname='';
        if ($postfeld['form_kunde_ap_anrede']!='') {
            $apname.=$postfeld['form_kunde_ap_anrede'];
        }
        if ($postfeld['form_kunde_ap_titel']!='') {
            $apname.=($apname!=''?' ':'').$postfeld['form_kunde_ap_titel'];
        }
        
        if ($postfeld['form_kunde_ap_bezeichnung']!='' && $postfeld['form_kunde_ap_vorname']!='') {
            $apname.=($apname!=''?' ':'').$postfeld['form_kunde_ap_bezeichnung'].', '.$postfeld['form_kunde_ap_vorname'];
        } elseif ($postfeld['form_kunde_ap_bezeichnung']!='' && $postfeld['form_kunde_ap_vorname']=='') {
            $apname.=($apname!=''?' ':'').$postfeld['form_kunde_ap_bezeichnung'];
        } elseif ($postfeld['form_kunde_ap_bezeichnung']=='' && $postfeld['form_kunde_ap_vorname']!='') {
            $apname.=($apname!=''?' ':'').$postfeld['form_kunde_ap_vorname'];
        }
        if ($apname!='' || $postfeld['form_kunde_ap_telefon']!='' || $postfeld['form_kunde_ap_mobil']!='' || $postfeld['form_kunde_ap_email']!='') {
            $zusbetext.="\n"._ANSPRECHPARTNER_."\n".'{ap_name}{ap_telefon}{ap_mobil}{ap_email}';
            if ($apname!='') {
                $zusbetext=p4n_mb_string('str_replace','{ap_name}',$apname."\n",$zusbetext);
            } else {
                $zusbetext=p4n_mb_string('str_replace','{ap_name}','',$zusbetext);
            }
            if ($postfeld['form_kunde_ap_telefon']!='') {
                $zusbetext=p4n_mb_string('str_replace','{ap_telefon}',$postfeld['form_kunde_ap_telefon']."\n",$zusbetext);
            } else {
                $zusbetext=p4n_mb_string('str_replace','{ap_telefon}','',$zusbetext);
            }
            if ($postfeld['form_kunde_ap_mobil']!='') {
                $zusbetext=p4n_mb_string('str_replace','{ap_mobil}',$postfeld['form_kunde_ap_mobil']."\n",$zusbetext);
            } else {
                $zusbetext=p4n_mb_string('str_replace','{ap_mobil}','',$zusbetext);
            }
            if ($postfeld['form_kunde_ap_email']!='') {
                $zusbetext=p4n_mb_string('str_replace','{ap_email}',$postfeld['form_kunde_ap_email']."\n",$zusbetext);
            } else {
                $zusbetext=p4n_mb_string('str_replace','{ap_email}','',$zusbetext);
            }
        }
    }
    
    $zusbetext2='';
    if (
        ($_SESSION['crm_version']>68) &&  (
        (isset($postfeld[$p.'fahrzeug']) && intval($postfeld[$p.'fahrzeug'])<=0) || 
        (isset($postfeld['form_kunde_sct']) && ($postfeld['form_kunde_sct']==1 || $postfeld['form_kunde_sct']=='1'))
    )) {
        $zusbetext2="\n"._FAHRZEUG_.": ".'{modell}{erstzulassung}{kmstand}{kennzeichen}{fahrgestell}';

        $modell='';
        if ($postfeld['form_kunde_modell']!='') {
            $modell.=$postfeld['form_kunde_modell']." / ";
        }
        $zusbetext2=p4n_mb_string('str_replace','{modell}',$modell,$zusbetext2);

        $erstzulassung='';
        if ($postfeld['form_kunde_erstzulassung']!='') {
            $erstzulassung.=$postfeld['form_kunde_erstzulassung']." / ";
        }
        $zusbetext2=p4n_mb_string('str_replace','{erstzulassung}',$erstzulassung,$zusbetext2);

        
        $fahrgestell='';
        if ($postfeld['form_kunde_fahrgestell']!='') {
            $fahrgestell.=$postfeld['form_kunde_fahrgestell']." / ";
        }
        $zusbetext2=p4n_mb_string('str_replace','{fahrgestell}',$fahrgestell,$zusbetext2);

        $kmstand='';
        if ($postfeld['form_kunde_kmstand']!='') {
            $kmstand.=$postfeld['form_kunde_kmstand']." / ";
        }
        $zusbetext2=p4n_mb_string('str_replace','{kmstand}',$kmstand,$zusbetext2);

        $kennzeichen='';
        if ($postfeld['form_kunde_kennzeichen']!='') {
            $kennzeichen.=$postfeld['form_kunde_kennzeichen']." / ";
        }
        $zusbetext2=p4n_mb_string('str_replace','{kennzeichen}',$kennzeichen,$zusbetext2);
        if ($modell!='' || $erstzulassung!='' || $kmstand!='' || $kennzeichen!='') {
            $zusbetext2= substr($zusbetext2, 0,-3);
        } else {
            $zusbetext2='';
        } 
    }
    
    $zusbetext3='';
    if (
        ($_SESSION['crm_version']>68) &&  (
        (isset($postfeld['form_kunde_t_alternativ']) && $postfeld['form_kunde_t_alternativ']!=''))
    ) {
        $zusbetext3.="\n"._ALTERNATIVE_.' '._KNTEL_.": ".$postfeld['form_kunde_t_alternativ'];
    }
        
    
    
    
    $ticket['beschreibung'] = $db->str($postfeld[$p.'beschreibung'].$zusbetext.$zusbetext2.$zusbetext3);
    if (isset($postfeld[$p.'art']) && $postfeld[$p.'art']!='' && $postfeld[$p.'art']!=-1 && $postfeld[$p.'art']!='-1') {
        $ticket['art'] = $db->str($postfeld[$p.'art']);
    }
    if (isset($postfeld[$p.'kategorie1']) && $postfeld[$p.'kategorie1']!='' && $postfeld[$p.'kategorie1']!=-1 && $postfeld[$p.'kategorie1']!='-1') {
        $ticket['kategorie'] = $db->str($postfeld[$p.'kategorie1']);
    }
    $ticket['prioritaet'] = $db->dbzahl(1);
    if (isset($sql_tabs['troubleticket']['source'])) {
        $ticket['source'] = $db->str('BDC');
    }
    
    if (isset($postfeld[$p.'zielzeit_datum'])) {
        $ticket['beschwerdezeit_ziel'] = $db->dbzeitdatum($postfeld[$p.'zielzeit_datum'], $postfeld[$p.'zielzeit_zeit'] . ':' . $postfeld[$p.'zielzeit_zeit2']); 
    } else {
        if (trim($ticket['art2'], "'")!='Anfrage') {
            $ticket['beschwerdezeit_ziel'] = $db->dbtimestamp($zielz); 
        }
    }
    $zielz_an=0;
    if (trim($ticket['art2'], "'")=='Anfrage' && $cfg_bm_an_zielzeit) {
        $res=$db->select(
            $sql_tab['einstellungen'],
            $sql_tabs['einstellungen']['wert'],
            $sql_tabs['einstellungen']['modul'].'='.$db->str('system_anfragen')
        );
        if ($row=$db->zeile($res)) {
            $systemTemp = unserialize($row[0]);
            $bm_zielzeit_an=$systemTemp['zielzeit'];
        }
        
        $zielz_an=time()+(60*60*(int)$bm_zielzeit_an);
        $bmtage1=$zielz_an/24;
        $zielz_an=checkZielZeit($zielz_an, $bmtage1, $user_id);
    }
    if (trim($ticket['art2'], "'")=='Anfrage' && $cfg_bm_an_zielzeit && $zielz_an!=0) {
        $ticket['beschwerdezeit_ziel'] = $db->dbtimestamp($zielz_an); 
    }
    if (isset($postfeld[$p.'kategorie2'])) {
        $to_save = $postfeld[$p.'kategorie2'];
        if (is_array($postfeld[$p.'kategorie2'])) {
            $to_save = implode(';', $postfeld[$p.'kategorie2']);
        } else {
            if ($postfeld[$p.'kategorie2']==_KEINE_ || $postfeld[$p.'kategorie2']==-1 || $postfeld[$p.'kategorie2']=='-1') {
                $to_save = false;
            }
        }
        if ($to_save!==false) {
            $ticket['kategorie2'] = $db->str($to_save);
        }
    }
    if (isset($postfeld[$p.'kategorie5']) && $postfeld[$p.'kategorie5']!=_KEINE_ && $postfeld[$p.'kategorie5']!=-1 && $postfeld[$p.'kategorie5']!='-1') {
        $ticket['kategorie5'] = $db->str($postfeld[$p.'kategorie5']);
    }
    if (isset($postfeld[$p.'kfzmarke']) && $postfeld[$p.'kfzmarke'] != _KEINE_ && $postfeld[$p.'kfzmarke'] != -1) {
        $ticket['kfzmarke'] = $db->str($postfeld[$p.'kfzmarke']);
    }
    
    $bm_linkdateien='';
    $anz_bmdatei=0;
    $alle_bm_anhaenge = array();
    for ($bm_i = 1; $bm_i <= 3; $bm_i++) {
        $files=checkBdcPosteingangFileCheckbox($files,$postfeld,$p.'datei' . $bm_i);
        if ($files[$p.'datei' . $bm_i]['error'] == 0 and $files[$p.'datei' . $bm_i]['size'] > 0) {
            $ziel_datei = 'bm_' . time() . '_' . name2filename($files[$p.'datei' . $bm_i]['name']);
            // Nachsehen ob die Dateiendung auch erlaubt ist
            $dateiendung = p4n_mb_string('strtolower', p4n_mb_string('substr', $ziel_datei, -3));
            $dateiendung2 = p4n_mb_string('strtolower', p4n_mb_string('substr', $ziel_datei, -4));
            if (is_array($erlaubte_dateiendungen)) {
                if (!in_array($dateiendung2, $erlaubte_dateiendungen)) {
                    $nicht_erlaubte_dateiendungen = array($dateiendung);
                }
            }
            if (array_search($dateiendung, $nicht_erlaubte_dateiendungen) !== false) {
                echo '<div class="error_header">' . _UNERLAUBTEDATEI_ . '</div>';
                echo '<div class="error_text">' . _UNERLAUBTEDATEI_ . ': ' . $dateiendung . '. ' . _UNERLAUBTEDATEI2_ . '</div>';
            } else {
                $ziel_datei = dok_korr_filename($ziel_datei, 'beschwerden');
                if ($files[$p.'datei' . $bm_i]['force_copy']==1) {
                    copy($files[$p.'datei' . $bm_i]['tmp_name'], 'dokumente_korrespondenz/' . $ziel_datei);
                } else {
                    move_uploaded_file($files[$p.'datei' . $bm_i]['tmp_name'], 'dokumente_korrespondenz/' . $ziel_datei);
                }
                
                $chm = 0740;
                if ($cfg_unix_dateien != '') {
                    $chm = octdec($cfg_unix_dateien);
                }
                @chmod('dokumente_korrespondenz/' . $ziel_datei, $chm);
                $alle_bm_anhaenge[name2filename($files[$p.'datei'.$bm_i]['name'])]='dokumente_korrespondenz/'.$ziel_datei;
                $ticket['download' . $bm_i] = $db->str($ziel_datei);
                $anz_bmdatei++;
                if (isset($sc_crm_hostpfad)) {
                    if ($sc_crm_hostpfad!='') {
                        $bm_linkdateien.="\n".'<a href="'.$sc_crm_hostpfad.'dokumente_korrespondenz/'.$ziel_datei.'">'.$files[$p.'datei'.$bm_i]['name'].'</a>';
                    }
                }
            }
        }
    }
    $ticket['letzte_aenderung'] = $db->dbtimestamp(time());
    
    $sqlt=array();
    foreach ($ticket as $key => $value) {
        $sqlt[$sql_tabs['troubleticket'][$key]]=$value;
    }

    $db->insert(
            $sql_tab['troubleticket'],
            $sqlt
    );
    $tt_id=$db->insertid();
    
    if ($postfeld['is_bdc_mailbox_request']==1 && class_exists('Mailbox_EmailAdmin')) {
        Mailbox_EmailAdmin::updateState($_SESSION['bdc_email_path'],'3','bdc',
            array(
                'troubleticket_id'=>$tt_id,
                'user_id'=>$_SESSION['user_id'],
                'time'=>time(),
                'st_id'=>$postfeld['form_kunde_stdid'],
                'type'=>(isset($postfeld['form_beschwerde_submit'])?'Beschwerde':'Anfrage')
            )
        );

        $emailAdmin = new Mailbox_EmailAdmin('Mailbox_Processor_Posteingang');
        $mailboxEmail = $emailAdmin::getEmail($_SESSION['bdc_email_path']);
        $mailboxEmail->createCorrespondenceForMail([
            'type' => 'TROUBLE_TICKET',
            'troubleticket_id' => $tt_id,
            'troubleticket_type' => isset($postfeld['form_beschwerde_submit'])?'COMPLAINT':'REQUEST',
            'stammdaten_id' => $postfeld['form_kunde_stdid'],
            'create_mode' => 'NEW',
        ]);
    }
    
    
    if (($_SESSION['crm_version']>61 or $cfg_bdc_grund) and !$cfg_bdc_nl) {
        saveInBdcDB(
            $ticket['stammdaten_id'],
            $ticket['mandant_id'],
            $ticket['lagerort_id'],
            ($postfeld[$p.'grund']!=-1?$postfeld[$p.'grund']:''),
            ($postfeld['form_kunde_ansprechpartner_id']!=-1?$postfeld['form_kunde_ansprechpartner_id']:0),
            (isset($postfeld['form_beschwerde_submit'])?'Beschwerde':'Anfrage'),
             0,
            $tt_id,
            $postfeld['form_beschwerde_bdc_kanal']
        );
    }

    $bmid='1-'.$tt_id;

    if (($postfeld[$p.'email'] != '' || $postfeld[$p.'benutzer']>0) && (intval($ticket['status'])!=4)) {
        $alle_bmadr = array();
        $proto_mail='';
        if ($postfeld[$p.'email']!='' && !in_array($postfeld[$p.'email'],$alle_bmadr)) {
            $exple=explode(';',$postfeld[$p.'email']);
            foreach ($exple as $exple_val) {
                if ($exple_val!='') {
                    $alle_bmadr[] = $exple_val;
                    $proto_mail.=$exple_val.', ';
                }
            }
        }
        if (isset($postfeld[$p.'email2']) && intval($postfeld[$p.'email2'])>0) {
            $res=$db->select(
                $sql_tab['benutzer'],
                array(
                    $sql_tabs['benutzer']['email'],
                    $sql_tabs['benutzer']['passwort'],
                    $sql_tabs['benutzer']['benutzer_id']
                ),
                 $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($postfeld[$p.'email2'])
            );
            while ($row=$db->zeile($res)) {
                if ($row[0]!='' && !in_array($row[0],$alle_bmadr)) {
                    $alle_bmadr[]=$row[0];
                    $proto_mail.=$row[0].', ';
                }
            }
        }
        if (isset($postfeld[$p.'email1']) && intval($postfeld[$p.'email1'])>0) {
            $res=$db->select(
                $sql_tab['benutzer'],
                array(
                    $sql_tabs['benutzer']['email'],
                    $sql_tabs['benutzer']['passwort'],
                    $sql_tabs['benutzer']['benutzer_id']
                ),
                 $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($postfeld[$p.'email1'])
            );
            while ($row=$db->zeile($res)) {
                if ($row[0]!='' && !in_array($row[0],$alle_bmadr)) {
                    $alle_bmadr[]=$row[0];
                    $proto_mail.=$row[0].', ';
                }
            }
        }
        if (isset($postfeld[$p.'benutzer']) && intval($postfeld[$p.'benutzer'])>0) {
            $res=$db->select(
                $sql_tab['benutzer'],
                array(
                    $sql_tabs['benutzer']['email'],
                    $sql_tabs['benutzer']['passwort'],
                    $sql_tabs['benutzer']['benutzer_id']
                ),
                 $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($postfeld[$p.'benutzer'])
            );
            while ($row=$db->zeile($res)) {
                if ($row[0]!='' && !in_array($row[0],$alle_bmadr)) {
                    $alle_bmadr[]=$row[0];
                    $proto_mail.=$row[0].', ';
                }
            }
        }
        
        if ($proto_mail != '') {
            $protocolEntry = Troubleticket_ProtocolEntry::create(
                _EMAIL_,
                p4n_mb_string('substr', $proto_mail, 0, -2)
            );
            $troubleTicket = new Troubleticket_Data($tt_id);
            $troubleTicket['protokoll'] = $protocolEntry;
            $troubleTicket['letzte_aenderung'] = $db->dbtimestamp(time());
            $troubleTicket->save();
        }
        
        if (count($alle_bmadr) > 0) {
            include_once("inc/lib_htmledit.php");
            include_once('inc/class_bdc_email.php');
            
            $htmleditor = new HTMLEditor();

            if (isset($postfeld['form_beschwerde_submit'])) {
                if (intval($bdc_einstellungen['vorlage2'])>0) {
                    $mail = $htmleditor->prepare_mail($bdc_einstellungen['vorlage2']);
                } elseif (isset($_SESSION['design_70'])) {
                    $mail = $htmleditor->prepare_utf8_html_mail('template/bdc/beschwerde_70.html');
                } else {
                    $mail=$htmleditor->prepare_utf8_html_mail('template/bdc/beschwerde'.($cfg_bdc_nl?'_nl':(p4n_mb_string('substr',$_SESSION['cfg_kunde'], 0, p4n_mb_string('strlen','carlo_opel_avag'))=='carlo_opel_avag' ? '_avag':'')).'.html');
                }
            } else {
                if (intval($bdc_einstellungen['vorlage1'])>0) {
                    $mail = $htmleditor->prepare_mail($bdc_einstellungen['vorlage1']);
                } else {
                    $mail=$htmleditor->prepare_utf8_html_mail('template/bdc/anfrage'.($cfg_bdc_nl?'_nl':(p4n_mb_string('substr',$_SESSION['cfg_kunde'], 0, p4n_mb_string('strlen','carlo_opel_avag'))=='carlo_opel_avag' ? '_avag':'')).'.html');
                }
            }
            
            $mail->Subject=_NEUEINTRAG_ . ': ' . (isset($postfeld['form_anfrage_submit'])?_BM_ART3_:_BESCHWERDE_).' '.$bmid.' - '.kundenbezeichnung($postfeld['form_kunde_stdid']).' ('.$postfeld['form_kunde_stdid'].')';
            if ($bdc_email_betreff) {
                $mail->Subject = 'BDC '.(isset($postfeld['form_anfrage_submit'])?_BM_ART3_:_BESCHWERDE_) . ' ('.$bmid.') - ' . (isset($postfeld['form_anfrage_submit'])?$postfeld['form_anfrage_betreff']:$postfeld['form_beschwerde_betreff']);      
            }
            
            
            $bdc_mail=new bdcMail();
            $mail = $bdc_mail->beschwerde(
                $tt_id,
                $mail,
                false,
                _NEUEINTRAG_.': ',
                [],
                $_SESSION['design_70']
            );
            $mailtext=$mail->Body;
            
            if (count($alle_bm_anhaenge)>0) {
                @reset($alle_bm_anhaenge);
                while (list($bmakey, $bmaval) = @each($alle_bm_anhaenge)) {
                    $mail->AddAttachment($bmaval, $bmakey);
                }
            }

            @reset($alle_bmadr);
            while (list($keyba, $valba) = @each($alle_bmadr)) {
                $mail->AddAddress($valba);
            }

            $mailtext= preg_replace('/\<\![A-Za-z0-9_]*\>/Uis','',$mailtext);
            $mail->Body = $mailtext;
            // init default settings from
            $mail->From = $bdc_einstellungen['absender'] != '' ? $bdc_einstellungen['absender'] : $_SESSION['user_email'];
            $mail->FromName = $bdc_einstellungen['absendername'] != '' ? $bdc_einstellungen['absendername'] : $_SESSION['mitarbeiter_name'];
            //Alexander 5.06.2022
            //implode Microsoft Azure API
            // use azure 'personal email 1 address' for send mail
            if (!empty($cfg_microsoft_v2) && !empty($cfg_microsoft_v2_email_send)) {
                $azure_email = AzureApp::getUserEmail($_SESSION['user_id'], $_SESSION['user_role'], 2); // 'personal email 1' is priority
                if (!empty($azure_email['error'])) {
                    echo javas('alert("'.p4n_mb_string('htmlspecialchars', $azure_email['error']).'");');
                }
                if (!empty($azure_email['data']['mail'])) {
                    $mail->From = $azure_email['data']['mail'];
                    $mail->FromName = $azure_email['data']['name'];
                }
            }
            //$mail->Subject = _NEUEINTRAG_ . ': ' . (isset($postfeld['form_anfrage_submit'])?_BM_ART3_:_BESCHWERDE_) . ' (' . adodb_date('d.m.Y, H:i') . ') - ' . kundenbezeichnung($postfeld['form_kunde_stdid']) . ' (' . $postfeld['form_kunde_stdid'] . ')';
                      
            if ($cfg_smtp_alternative) {
                $smtpAlternative = array();
                if (is_file('inc/utilities.php')) {
                    include_once 'inc/utilities.php';
                    $smtpAlternative = getSMTPdetails('stammdaten_uebersicht');
                }
            }
            ob_start();
            
            $gesendet2=$gesendet3=true;
            if (method_exists($bdc_mail,'splitMailTo')) {
                $mail=$bdc_mail->splitMailTo($mail);
                if ($_SESSION['cfg_kunde']=='portal') {
                    $mail_temp=clone $mail;
                    $mail->ClearAllRecipients();
                    if (is_array($mail_temp->verursacher_mail)) {
                        $mail->AddAddress($mail_temp->verursacher_mail[1]);
                    }
                    
                    if (is_array($mail_temp->andere_benutzer)) {
                        foreach($mail_temp->andere_benutzer as $andere) {
                            $mail->AddCC($andere);
                        }
                    }
    
                    if (is_array($mail_temp->freie_adressen)) {
                        foreach($mail_temp->freie_adressen as $freie) {
                            $mail->AddCC($freie);
                        }
                    }
                    $gesendet1 = $mail->Send($smtpAlternative);
                } else {
                    $mail_temp=clone $mail;
                    $gesendet1=$bdc_mail->sendVerursacherMail($mail_temp);
                    $mail_temp=clone $mail;
                    $gesendet2=$bdc_mail->sendAndereBenutzer($mail_temp);
                    $mail_temp=clone $mail;
                    $gesendet3=$bdc_mail->sendFreieAdressen($mail_temp);
                }
            } else {
                $gesendet1=$mail->Send($smtpAlternative);
            }

            $hinweistext70='';
            if (!$gesendet1 || !$gesendet2 || !$gesendet3) {
                $hinweistext .= '<font color=red>' . _EMAILING_EMAILS_FEHLER_ . '</font><br>';
                $hinweistext70=_EMAILING_EMAILS_FEHLER_.'<br>';
            } else {
                $erfolgtext.='<br>'._EMAILING_EMAILS_ABGESCHICKT_;
                $hinweistext .= _EMAILING_EMAILS_ABGESCHICKT_ . '<br>';
            }
            $x=addslashes(ob_get_clean());
            $hinweistext.=$x;
            $hinweistext70.=$x;
            if (!$_SESSION['design_70']) {
            echo javas('jq1112(document).ready(function ($) {bdc_alert("'.$hinweistext.'",false,'.(isset($_GET['ohnecc'])?'true':'false').');});');
            }
        }
    } else {
        if (isset($_GET['ohnecc']) && !$_SESSION['design_70']) {
            echo javas('try {parent.P4nBoxHelper.closeall();} catch(e) {}');
        }
    }
    if ($_SESSION['design_70']) {
        if ($hinweistext70!='') {
            Template_Alert::alert($hinweistext70);
        } else {
            Template_Alert::success($erfolgtext);
        }
        if ($_SESSION['bdc_ziel']=='stammdaten') {
            wechsel('stammdaten_main.php?nav=Uebersicht&exclude_stammdaten_tabs=1');
        } else {
            wechsel('startseite.php');
        }
        exit;
    }
    unset($_SESSION['bdcSelectedAp']);
    unset($postfeld);
}


if (isset($postfeld['form_lead_submit'])) {
    // D70 - AVAG - If no car was selected, use the last remembered car as default.
    // And remove the last remembered car from the session + filter.
    if (
        $cfg_avag_de &&
        (empty($postfeld['form_lead_fahrzeug']) || $postfeld['form_lead_fahrzeug'] == '-1') &&
        !empty($postfeld['remembered_car_id'])
    ) {
        $postfeld['form_lead_fahrzeug'] = $postfeld['remembered_car_id'];
        unset($_SESSION['AVAG_KFZSUCHE_REMEMBER_CAR_VIN']);
        if (isset($_SESSION['filter']['kfzsuche']['fahrgestell'])) {
            unset($_SESSION['filter']['kfzsuche']['fahrgestell']);
        }
    }
    
    $p='form_lead_';
    
    if (isset($postfeld[$p.'benutzer_eva']) and isset($postfeld[$p.'eva'])) {
        $postfeld[$p.'benutzer']=$postfeld[$p.'benutzer_eva'];
    }
    
    $erfolgtext=_LEAD_.' erfolgreich angelegt';
    if (!$_SESSION['design_70'])
    $_SESSION['stammdaten_id']=$postfeld['form_kunde_stdid'];
    
    require_once('inc/services/LDS/CrmLeads.php');
    /** @var CrmLeads $leadMan */
        $leadMan = new CrmLeads();

        
        $mail_vorname='';
        $mail_name='';
        $mail_beschreibung='';
        $mail_tel1='';
        $mail_tel2='';
        $mail_mtel1='';
        $mail_mtel2='';
        $persdata = $customerEmails = array();
        $res = $db->select(
                $sql_tab['stammdaten'], array(
            $sql_tabs['stammdaten']['anrede'],//0
            $sql_tabs['stammdaten']['vorname'],//1
            $sql_tabs['stammdaten']['name'],//2
            $sql_tabs['stammdaten']['geburtstag'],//3
            $sql_tabs['stammdaten']['Telefon_1'],//4
            $sql_tabs['stammdaten']['Mobilfon_1'],//5
            $sql_tabs['stammdaten']['Telefon_2'],//6
            $sql_tabs['stammdaten']['Mobilfon_2'],//7
            $sql_tabs['stammdaten']['Fax_1'],//8
            $sql_tabs['stammdaten']['EMail_1'],//9
            $sql_tabs['stammdaten']['bemerkung'],//10
            $sql_tabs['stammdaten']['EMail_2'],//11
            $sql_tabs['stammdaten']['EMail_3'],//12
                ), $sql_tabs['stammdaten']['id'] . '=' . $db->dbzahl($postfeld['form_kunde_stdid'])
        );
        while ($row = $db->zeile($res)) {
            $mail_vorname=$row[1];
            $mail_name=$row[2];
            
            $mail_tel1=$row[4];
            $mail_tel2=$row[6];
            $mail_mtel1=$row[5];
            $mail_mtel2=$row[7];
            $postfeld['form_kunde_st_bemerkung'].=$row[10];
            $persdata = array(
                'leer' => null,
                'Salutation' => $row[0],
                'Occupation' => null,
                'AcademicTitle' => null,
                'Initials' => null,
                'FirstName' => $row[1],
                'LinkName' => null,
                'LastName' => $row[2],
                'SecondLastName' => null,
                'Gender' => null,
                'DateOfBirth' => $row[3],
                'LanguageCode' => null,
                'LDSCustomerID' => null
            );

            $contactdata = array(
                'leer' => null,
                'PhoneHome' => $row[4],
                'PhoneMobile' => $row[5],
                'PhoneWork' => $row[6],
                'PhoneWorkMobile' => $row[7],
                'Fax' => $row[8],
                'Email' => $row[9],
                'PreferedContactDate1' => null,
                'PreferedContactDate2' => null,
                'PreferedContactTime1' => null,
                'PreferedContactTime2' => null,
                'ContactNumber' => null,
                'OptOut' => null,
                'ContactPreferencePhone' => null,
                'ContactPreferenceEmail' => null,
                'ContactPreferenceMail' => null,
                'ContactPreferenceMobileMessaging' => null,
                'DataPrivacyData' => null
            );
            if (isset($_GET['cti_fremd_id']) && isset($ctiData['notice']['nr']) && $ctiData['notice']['nr']!='') {
                $contactdata['PhoneHome']=$ctiData['notice']['nr'];
            }
            if ($row[9]) {
                $customerEmails[] = $row[9];
            }
            if ($row[11]) {
                $customerEmails[] = $row[11];
            }
            if ($row[12]) {
                $customerEmails[] = $row[12];
            }
        }
        $lead['persdata'] = @implode('#####', $persdata);
        $lead['contactdata'] = @implode('#####', $contactdata);
    
        $mail_plz='';
        $mail_ort='';
        $mail_adresse='';
        $mail_adresse2='';
        $mail_adresse3='';
        $mail_adresse4='';
        $mail_adresse5='';
        $addressdata = array();
        $res = $db->select(
                $sql_tab['stammdaten_adresse'], array(
            $sql_tabs['stammdaten_adresse']['ort'],//0
            $sql_tabs['stammdaten_adresse']['adresse'],//1
            $sql_tabs['stammdaten_adresse']['plz'],//2
                      $sql_tabs['stammdaten_adresse']['zusatz1'], //3
            $sql_tabs['stammdaten_adresse']['zusatz2'], //4
            $sql_tabs['stammdaten_adresse']['sync_id'], //5
            $sql_tabs['stammdaten_adresse']['kategorie']//6
                ), $sql_tabs['stammdaten_adresse']['stammdaten_id'] . '=' . $db->dbzahl($postfeld['form_kunde_stdid'])
        );
        while ($row = $db->zeile($res)) {
            $mail_plz=$row[2];
            $mail_ort=$row[0];
            $mail_adresse=$row[1];
            $mail_adresse2=$row[3];
            $mail_adresse3=$row[4];
            $mail_adresse4=$row[5];
            $mail_adresse5=$row[6];
            
            $addressdata = array(
                'leer' => null,
                'HouseNumber' => null,
                'HouseNumberSuffix' => null,
                'Apartment' => null,
                'StreetName' => null,
                'AddressLine1' => $row[1],
                'AddressLine2' => null,
                'Town' => $row[0],
                'PostalCode' => $row[2],
                'County' => null,
                'AddressType' => null,
                'CountryCode' => null,
            );
        }
        $lead['addressdata'] = @implode('#####', $addressdata);
        
        
        $companydata = array(
            'leer'                         => null,
            'CompanyName'                  => $postfeld['form_kunde_firma'],
            'CompanyDepartment'            => null,//_ABTEILUNG_,
            'CompanyPosition'              => null,//_POSITION_,
            'CompanySize'                  => null,
            'CompanySizeCategory'          => null,//_GROESSENKATEGORIE_,
            'CompanyPrivateCars'           => null,//_ANZAHL_PRIVATFAHRZEUGE_,
            'CompanyCommercialCars'        => null,//_ANZAHL_FIRMENFAHRZEUGE_,
            'CompanyTotalCars'             => null,//_GESAMTANZAHL_FAHRZEUGE_
        );
        $lead['companydata'] = @implode('#####', $companydata);
        
        
        
         $cardata = array();
        
        if (isset($postfeld['form_kunde_stdid']) && $postfeld['form_kunde_stdid']>0) {
            //$produkt=$sql_tabs['produktzuordnung']['stammdaten_id'] . '=' . $db->dbzahl($postfeld['form_kunde_stdid']);
        }

        if (isset($postfeld[$p.'fahrzeug']) && intval($postfeld[$p.'fahrzeug'])>0) {
            $produkt=$sql_tabs['produktzuordnung']['produktzuordnung_id'] . '=' . $db->dbzahl($postfeld[$p.'fahrzeug']);
    
            $res = $db->select(
                    $sql_tab['produktzuordnung'], array(
                        $sql_tabs['produktzuordnung']['produkt_id'], //0
                        $sql_tabs['produktzuordnung']['typ'], //1
                        $sql_tabs['produktzuordnung']['kennzeichen'], //2
                        $sql_tabs['produktzuordnung']['typ_modell'], //3
                        $sql_tabs['produktzuordnung']['datum_ez'], //4
                        $sql_tabs['produktzuordnung']['markencode'], //5
                        $sql_tabs['produktzuordnung']['bauart'], //6
                        $sql_tabs['produktzuordnung']['kraftstoff'], //7
                        $sql_tabs['produktzuordnung']['getriebebezeichnung'], //8
                        $sql_tabs['produktzuordnung']['km_stand'], //9
                        $sql_tabs['produktzuordnung']['farbbezeichnung'], //10
                        $sql_tabs['produktzuordnung']['produktzuordnung_id'], //11
                        $sql_tabs['produktzuordnung']['fahrgestell'] //12
                    ), 
                    $produkt
            );
            $produktzuordnung_id = 0;
            if ($row = $db->zeile($res)) {
                $produktzuordnung_id = $row[11];
                $cardata = array(
                    'LeadID' => $row[0],
                    'RegistrationDate' => $row[4], //_ERSTZULASSUNG_,
                    'RegistrationNumber' => $row[2], //_KENNZEICHEN_,
                    'VIN' => $row[12],
                    'BodyStyle' => $row[6], //_BAUART_,
                    'AnnualMileage' => null, //_JAEHRLICHE_KM_LEISTUNG_,
                    'NewUsed' => $row[1], //_ART_,
                    'RegistrationDateOwner' => null, //_ZULASSUNGSDATUM_KUNDE_,
                    'OwnerType' => null, //_KUNDENTYP_,
                    '' => null,
                    'OwnerTypeUpdated' => null, //_KUNDENTYP_AKTUALISIERT_,
                    'CurrentlyFinanced' => null, //_DERZEIT_FINANZIERT_,
                    'Brand' => $row[5], //_MARKE_,
                    'Model' => $row[3], //_MODELL_,
                    'BrandModelCodeUpdated' => null, //_MARKE_MODELL_AKTUALISIERT_,
                    'Trim' => null, //_INNENAUSSTATTUNG_,
                    'EngineSize' => null, //_HUBRAUM_,
                    'FuelType' => $row[7], //_MOTORART_,
                    'TransmissionType' => $row[8], //_GETRIEBE_,
                    'CurrentMileage' => $row[9], //_KMSTAND_,
                    'Colour' => $row[10], //_FARBE_,
                    'TyreSize' => null, //_REIFENGROESSE_,
                    'LastServiceDate' => null, //_LETZTE_INSPEKTION_,
                    'LastServiceMileage' => null, //_KM_STAND_LETZTE_INSPEKTION_,
                    'LastMOTDate' => null, //_LETZTE_HAUPTUNTERSUCHUNG_,
                    'WarrantyReferenceNumber' => null, //_GARANTIENUMMER_,
                    'WarrantyStartDate' => null, //_GARANTIEBEGINN_,
                    'WarrantyExpiryDate' => null, //_GARANTIEENDE_,
                    'WarrantyExpiryMileage' => null, //_GARANTIEENDE_BEI_KM_STAND_,
                    'ERD' => null, //_VORAUSSICHTLICHES_ERSATZDATUM_,
                    'CarBuildDate' => null //_BAUJAHR_
                );
                if (!empty($row[12])) {
                    $lead['fahrgestell']=$row[12];
                }
            }
            $lead['cardata'] = @implode('#####', $cardata);
        }
        
       
        $AllocationDate=date('Y-m-d H:i:s');
        $statusdata = array(
            'leer' => null,
            'StatusCode' => 'NEW',
            'StatusName' => 'New Lead',
            'StatusDescription' => null, //_BESCHREIBUNG_,
            'AllocationDate' => $AllocationDate,
            'OpenDate' => null, //_OEFFNUNGSDATUM_,
            'TargetOpenDate' => null, //_ZIELOEFFNUNGSDATUM_,
            'ContactDate' => null, //_KONTAKTDATUM_,
            'TargetContactDate' => null, //_ZIELKONTAKTDATUM_,
            'CloseDate' => null, //_SCHLIESSDATUM_,
            'TargetCloseDate' => null, //_ZIELSCHLIESSDATUM_,
            'ReminderCloseDate' => null, //_ERINNERUNG_SCHLIESSDATUM_,
            'ReallocationDate' => null, //_NEUERSTELLUNGSDATUM_,
            'AssignedToDealer' => null, //_ZU_HAENDLER_ZUGEWIESEN_,
            'ImportDate' => null, //_IMPORT_DATUM_
        );
        $lead['statusdata'] = @implode('#####', $statusdata);
        
        if (isset($_GET['cti_fremd_id'])) {
            $lead['leadid']=$_GET['cti_fremd_id'];
        }
        
        $res = $db->select(
            $sql_tab['kampagne'], array(
                $sql_tabs['kampagne']['kampagne_id'],
                $sql_tabs['kampagne']['bezeichnung'],
                $sql_tabs['kampagne']['le_qualifizieren']
            ), 
            $sql_tabs['kampagne']['kampagne_id'] . '=' . $db->dbzahl($postfeld[$p.'kampagne'])
        );
        $le_qualifizieren=false;
        while ($row = $db->zeile($res)) {
            $campaigndata = array(
                'ID' => $row[0],
                'Code' => null,
                'Description' => $row[1],
                'Active' => null,
                'StartDate' => null,
                'EndDate' => null,
                'InclInSummaryEmails' => 'true',
                'IncludeInReports' => 'true',
                'IncludeInNotifEmail' => 'true',
                'Redistribution' => 'true'
            );
            $le_qualifizieren = $row[2];
            $lead['campaigndata'] = @implode('#####', $campaigndata);
            $kampagne_bezeichnung = $row[1];
        }
        
        $additionaldata = array();
        $additionaldata[_BETREFF_] = $postfeld[$p.'betreff'];
        if ($cfg_bdc_nl) {
            $lead['kfzkategorie']=($postfeld[$p.'kfzkategorie']!=-1)?$postfeld[$p.'kfzkategorie']:'';
            $lead['kfzmodell']=($postfeld[$p.'kfzmodell']!=-1)?$postfeld[$p.'kfzmodell']:'';
            $lead['kfznwgw']=($postfeld[$p.'kfznwgw']!=-1)?$postfeld[$p.'kfznwgw']:'';
            $additionaldata[_BESCHREIBUNG_] = $postfeld[$p.'beschreibung'];
        }
        $additionaldata[_QUELLE_] = 'BDC';
        $lead['source'] = 'BDC';
        $lead['lead_origin'] = 'BDC';

        if (isset($postfeld[$p.'alle_source']) && $postfeld[$p.'alle_source']!='' && $postfeld[$p.'alle_source']!=-1) {
            $lead['source'] = $postfeld[$p.'alle_source'];
            $additionaldata[_QUELLE_] = $postfeld[$p.'alle_source'];
        }
        
        
        $alle_bmadr = array();
        if (isset($postfeld[$p.'emailan']) && !in_array($postfeld[$p.'emailan'],$alle_bmadr)) {
            $exple=explode(';',$postfeld[$p.'emailan']);
            foreach ($exple as $exple_val) {
                if ($exple_val!='') {
                    $alle_bmadr[] = $exple_val;
                }
            }
        }
        if (isset($postfeld[$p.'email2']) && intval($postfeld[$p.'email2'])>0) {
            $res=$db->select(
                $sql_tab['benutzer'],
                array(
                    $sql_tabs['benutzer']['email'],
                    $sql_tabs['benutzer']['passwort'],
                    $sql_tabs['benutzer']['benutzer_id']
                ),
                 $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($postfeld[$p.'email2'])
            );
            while ($row=$db->zeile($res)) {
                if ($row[0]!='' && !in_array($row[0],$alle_bmadr)) {
                    $alle_bmadr[]=$row[0];
                }
            }
        }
        if (isset($postfeld[$p.'email1']) && intval($postfeld[$p.'email1'])>0) {
            $res=$db->select(
                $sql_tab['benutzer'],
                array(
                    $sql_tabs['benutzer']['email'],
                    $sql_tabs['benutzer']['passwort'],
                    $sql_tabs['benutzer']['benutzer_id']
                ),
                 $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($postfeld[$p.'email1'])
            );
            while ($row=$db->zeile($res)) {
                if ($row[0]!='' && !in_array($row[0],$alle_bmadr)) {
                    $alle_bmadr[]=$row[0];
                }
            }
        }
        $res=$db->select(
            $sql_tab['benutzer'],
            array(
                $sql_tabs['benutzer']['email'],
                $sql_tabs['benutzer']['passwort'],
                $sql_tabs['benutzer']['benutzer_id']
            ),
             $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($postfeld[$p.'benutzer'])
        );
        while ($row=$db->zeile($res)) {
            if ($row[0]!='' && !in_array($row[0],$alle_bmadr)) {
                $alle_bmadr[]=$row[0];
            }
        }

        if (count($alle_bmadr) > 0) {
            $email_string='';
            foreach ($alle_bmadr as $eval) {
                if ($eval!='') {
                    $email_string.=$eval.', ';
                }
            }
            if ($email_string!='') {
                $email_string=substr($email_string,0,-2);
            }
            $additionaldata[_EMAIL_] = $email_string;
        }
        
      
        
        $additionaldata[_DATUM_] = $db->unixdate($AllocationDate);
        
        if ($cfg_bdc_nl) {
            $additionaldata[_HAENDLER_ABTEILUNG_] = $alle_abteilungen[$postfeld[$p.'abteilung']];
            $additionaldata[_ANRUF_QUELLE_] = $postfeld[$p.'anrufquelle'];
        }
        
        if ($cfg_bdc_nl || ($_SESSION['crm_version']>61 or $cfg_bdc_grund)) {
            $additionaldata[_GRUND_] = $postfeld[$p.'grund'];
        }
        
        if ($cfg_bdc_nl) {
            $additionaldata[_TERMIN_PRIO_] = $priority_bez[$postfeld[$p.'prioritaet']];
            $additionaldata[_WVLDATUM_] = $postfeld[$p.'wvldatum'];
        }
        
        if ($cfg_bdc_nl || ($_SESSION['crm_version']>61 or $cfg_bdc_grund)) {
            $lead['grund']=($postfeld[$p.'grund']!=-1)?$postfeld[$p.'grund']:'';
        }
        
        $additionaldata[_KAMPAGNE_] = $kampagne_bezeichnung;
        
        if ($cfg_bdc_nl) {
            if (isset($postfeld[$p.'bevorzugterkontakt1'])) {
                if (is_array($postfeld[$p.'bevorzugterkontakt1'])) {
                    $postfeld[$p.'bevorzugterkontakt1'] = @implode(",", $postfeld[$p.'bevorzugterkontakt1']);
                }
            }
            if (isset($postfeld[$p.'bevorzugterkontakt2'])) {
                if (is_array($postfeld[$p.'bevorzugterkontakt2'])) {
                    $postfeld[$p.'bevorzugterkontakt2'] = @implode(",", $postfeld[$p.'bevorzugterkontakt2']);
                }
            }
    
            $additionaldata['1.' . _BEVORZUGTER_KONTAKT_VON_] = $postfeld[$p.'bevorzugterkontakt1'];
            $additionaldata['2.' . _BEVORZUGTER_KONTAKT_VON_] = $postfeld[$p.'bevorzugterkontakt2'];
            $additionaldata['1.' . _BEVORZUGTE_KONTAKT_ZEIT_] = $lalbevorzugtekontaktzeit1[$postfeld[$p.'bevorzugtekontaktzeit1']];
            $additionaldata['2.' . _BEVORZUGTE_KONTAKT_ZEIT_] = $lalbevorzugtekontaktzeit2[$postfeld[$p.'bevorzugtekontaktzeit2']];
            $additionaldata['1.' . _WUNSCHDATUM_TD_] = $postfeld[$p.'wunschdatum1'];
            $additionaldata[_BEMERKUNG_] = $postfeld[$p.'bemerkung'];
        }
        
        $zusbetext2='';
        if (
        $_SESSION['crm_version']>68 && (
        (isset($postfeld[$p.'fahrzeug']) && intval($postfeld[$p.'fahrzeug'])<=0) || 
        (isset($postfeld['form_kunde_sct']) && ($postfeld['form_kunde_sct']==1 || $postfeld['form_kunde_sct']=='1'))
        )) {
            $zusbetext2="\n"._FAHRZEUG_.": ".'{modell}{erstzulassung}{kmstand}{kennzeichen}{fahrgestell}';

            $modell='';
            if ($postfeld['form_kunde_modell']!='') {
                $modell.=$postfeld['form_kunde_modell']." / ";
            }
            $zusbetext2=p4n_mb_string('str_replace','{modell}',$modell,$zusbetext2);

            $erstzulassung='';
            if ($postfeld['form_kunde_erstzulassung']!='') {
                $erstzulassung.=$postfeld['form_kunde_erstzulassung']." / ";
            }
            $zusbetext2=p4n_mb_string('str_replace','{erstzulassung}',$erstzulassung,$zusbetext2);

            $fahrgestell='';
            if ($postfeld['form_kunde_fahrgestell']!='') {
                $fahrgestell.=$postfeld['form_kunde_fahrgestell']." / ";
            }
            $zusbetext2=p4n_mb_string('str_replace','{fahrgestell}',$fahrgestell,$zusbetext2);

            
            $kmstand='';
            if ($postfeld['form_kunde_kmstand']!='') {
                $kmstand.=$postfeld['form_kunde_kmstand']." / ";
            }
            $zusbetext2=p4n_mb_string('str_replace','{kmstand}',$kmstand,$zusbetext2);

            $kennzeichen='';
            if ($postfeld['form_kunde_kennzeichen']!='') {
                $kennzeichen.=$postfeld['form_kunde_kennzeichen']." / ";
            }
            $zusbetext2=p4n_mb_string('str_replace','{kennzeichen}',$kennzeichen,$zusbetext2);
            if ($modell!='' || $erstzulassung!='' || $kmstand!='' || $kennzeichen!='') {
                $zusbetext2= substr($zusbetext2, 0,-3);
            } else {
                $zusbetext2='';
            } 
        }
        
        if (!$cfg_bdc_nl) {
            $additionaldata[_BESCHREIBUNG_] = $postfeld[$p.'beschreibung'].$zusbetext2;
        }
        
        
        $xp5=explode('#####', $lead['cardata']);
        if ($xp5[2]!='') {
			if ($xp5[2]=='New') {
				$xp5[2]=$lang['_AUFTRAG-NW_'];
			}
			if ($xp5[2]=='Used') {
				$xp5[2]=$lang['_AUFTRAG-GW_'];
			}
		}
		$kfz='';
		if ($xp5[3]!='') {
			$kfz=trim($xp5[3].' '.$xp5[8].' '.$xp5[2].' '.$xp5[7]).'<br>'.$lang['_PZ-ERSTZULASSUNG_'].': '.$db->dbzeitdatum_ausgabe($xp5[1], 'd.m.Y');
            $additionaldata[_FAHRZEUG_]=$kfz;
		}
        
        if ($postfeld[$p.'sparte']!='' && $postfeld[$p.'sparte']!='-1' && $postfeld[$p.'sparte']!=-1) {
            $additionaldata[_ART_]=$postfeld[$p.'sparte'];
        }
        
        
        if (isset($postfeld[$p.'kanal']) && $postfeld[$p.'kanal']!='-1' && $postfeld[$p.'kanal']!=-1) {
            $lead['channel'] = $postfeld[$p.'kanal'];
            $additionaldata[_KANAL_] = $postfeld[$p.'kanal'];
        }
        if (isset($postfeld[$p.'marke']) && $postfeld[$p.'marke']!='-1' && $postfeld[$p.'marke']!=-1) {
            $lead['kfzmarke'] = $postfeld[$p.'marke'];
            $additionaldata[_MARKE_] = $postfeld[$p.'marke'];
        }
        
        if (isset($postfeld[$p.'absatzgruppe']) && $postfeld[$p.'absatzgruppe']!='-1' && $postfeld[$p.'absatzgruppe']!=-1) {
            $lead['absatzgruppe'] = $postfeld[$p.'absatzgruppe'];
            $additionaldata[_ABSATZGRUPPE_] = $postfeld[$p.'absatzgruppe'];
        }
        
        $additionaldata_string = '';
        $additionaldata_string2='';
//        if (is_array($additionaldata)) { // of course this is a fucking array, damned!!!
        foreach ($additionaldata as $key => $value) {
            if ($value!='' && $value!='-1') {
                $additionaldata_string.=$key . ': ' . $value . '<br>';
                $additionaldata_string2.=$key . ': ' . $value . "\n";
            }
        }
//        }
        if (
            ($_SESSION['crm_version']>68) &&  (
            (isset($postfeld['form_kunde_t_alternativ']) && $postfeld['form_kunde_t_alternativ']!=''))
        ) {
            $additionaldata_string.='<br>'._ALTERNATIVE_.' '._KNTEL_.": ".$postfeld['form_kunde_t_alternativ'];
            $additionaldata_string2.="\n"._ALTERNATIVE_.' '._KNTEL_.": ".$postfeld['form_kunde_t_alternativ'];
        }
        $lead['additionaldata'] = implode('#####', 
            array(
                '',
                $additionaldata_string,
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                $additionaldata[_BETREFF_]
            )
        );
        $lead['additionaldata_array'] = $additionaldata;
        
        //0 - neu
        //2 - zugewiesen
        //3 - offen
        //4 - kontaktiert
        //5 - abgeschlossen
        $lead['status'] = 0;
        if ($le_qualifizieren) {
            $lead['status'] = '100';
        }
        if (isset($sql_tabs['kampagne_lead']['kamp_kategorie'])) {
            if (isset($postfeld[$p.'kategorie']) && $postfeld[$p.'kategorie']!='' && $postfeld[$p.'kategorie']!='-1') {
                $lead['kamp_kategorie']=$postfeld[$p.'kategorie'];
            } else {
                $lead['kamp_kategorie']=_LEADS_;
            }
        }
        
        //if (isset($postfeld['form_kunde_standort']) and intval($postfeld['form_kunde_standort']) > 0) {
            list($mandid,$lagid)=bdc_bereinige_standort($postfeld['form_kunde_standort'],$postfeld['form_kunde_stdid']);
        //}
        if (isset($postfeld[$p.'standort']) and intval($postfeld[$p.'standort'])>0) {
            list($mandid,$lagid)=bdc_bereinige_standort($postfeld[$p.'standort'],0);
        }
        if (isset($postfeld['form_kunde_sct']) && ($postfeld['form_kunde_sct']==1 || $postfeld['form_kunde_sct']=='1')) {
            /*$lagid=0;
            $mandid=1;
            $dummy='BDC Dummy';
            $res_dummy=$db->select(
                $sql_tab['stammdaten'],
                array($sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'vpb' :  'mandant'],$sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'mandant' : 'vpb']),
                $sql_tabs['stammdaten']['id'].'>1000000 and ('.
                    $sql_tabs['stammdaten']['name'].'='.$db->str($dummy).' or '.
                    $sql_tabs['stammdaten']['firma1'].'='.$db->str($dummy).')'
            );
            if ($row_dummy=$db->zeile($res_dummy)) {
                $mandid=$row_dummy[0];
                $lagid=$row_dummy[1];
            }*/
        }
        
        $lead['lagerort_id'] = $lagid;
        if ($lagid==0) {
           $lead['lagerort_id'] = $mandid; 
        }
        $lead['stammdaten_id'] = $db->dbzahl($postfeld['form_kunde_stdid']);
        $lead['kampagne_id'] = $db->dbzahl($postfeld[$p.'kampagne'] > 0 ? $postfeld[$p.'kampagne'] : 0);
        $lead['campaignname'] = $kampagne_bezeichnung;
        $lead['benutzer_id'] = $db->dbzahl($postfeld[$p.'benutzer']);
        $lead['ersteller_id'] = $db->dbzahl($user_id);
        $lead['type'] = ($postfeld[$p.'sparte']!='' && $postfeld[$p.'sparte']!='-1' && $postfeld[$p.'sparte']!=-1)?$postfeld[$p.'sparte']:'';
        $lead['erfassungsdatum']=time();
        $lead['produktzuordnung_id']=$db->dbzahl($produktzuordnung_id);
		if ($cfg_lead_fahrzeugbesitz) {
			$lead['produktzuordnung_id2']=$db->dbzahl($postfeld[$p.'fahrzeug2']);
			if (intval($produktzuordnung_id)<=0 and intval($postfeld[$p.'fahrzeug2'])>0) {
				$lead['produktzuordnung_id']=$db->dbzahl($postfeld[$p.'fahrzeug2']);
			}
		}
		if (isset($sql_tabs['kampagne_lead']['ansprechpartner_id']) and intval($apid_neu)>0) {
			$lead['ansprechpartner_id']=$db->dbzahl($apid_neu);
		}
        if ($_SESSION['crm_version'] > 67) {
            //dateien f�r lead speichern
            $new_files_lead = array();
            for ($lead_i = 1; $lead_i <= 3; $lead_i++) {
                $files=checkBdcPosteingangFileCheckbox($files,$postfeld,$p.'datei' . $lead_i);
                if ($files[$p.'datei' . $lead_i]['error'] == 0 and $files[$p.'datei' . $lead_i]['size'] > 0) {
                    $ziel_datei = 'lead_' . time() . '_' . name2filename($files[$p.'datei' . $lead_i]['name']);
                    // Nachsehen ob die Dateiendung auch erlaubt ist
                    $dateiendung = p4n_mb_string('strtolower', p4n_mb_string('substr', $ziel_datei, -3));
                    $dateiendung2 = p4n_mb_string('strtolower', p4n_mb_string('substr', $ziel_datei, -4));
                    if (is_array($erlaubte_dateiendungen)) {
                        if (!in_array($dateiendung2, $erlaubte_dateiendungen)) {
                            $nicht_erlaubte_dateiendungen = array($dateiendung);
                        }
                    }
                    if (array_search($dateiendung, $nicht_erlaubte_dateiendungen) !== false) {

                    } else {
                        $ziel_datei = dok_korr_filename($ziel_datei, 'bdc_lead');
                        if ($files[$p.'datei' . $lead_i]['force_copy']==1) {
                            copy($files[$p.'datei' . $lead_i]['tmp_name'], 'dokumente_korrespondenz/' . $ziel_datei);
                        } else {
                            move_uploaded_file($files[$p.'datei' . $lead_i]['tmp_name'], 'dokumente_korrespondenz/' . $ziel_datei);
                        }

                        $chm = 0740;
                        if ($cfg_unix_dateien != '') {
                            $chm = octdec($cfg_unix_dateien);
                        }
                        @chmod('dokumente_korrespondenz/' . $ziel_datei, $chm);
                        $new_files_lead[name2filename($files[$p.'datei'.$lead_i]['name'])]='dokumente_korrespondenz/'.$ziel_datei;
                    }
                }
            }
            $lead['datei_anhaenge'] = json_encode(json_encode_utf8($new_files_lead));
            $lead['moidata'] = '#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####'.''.'#####';
        }
        
        $neue_lead_id=$leadMan->saveLead($lead);
        
        if (isset($_GET['cti_fremd_id'])) {
            $ref = new Interface_Ref();
            $ref['interface'] = 'crm_cti_number';
            $ref['table_name'] = 'kampagne_lead';
            $ref['table_id'] = $neue_lead_id;
            $ref['extern_id'] = $_GET['cti_fremd_id'];
            $ref->save();
        }
        
		$evakorrid=0;
        if (isset($postfeld[$p.'eva'])) {
            include_once('inc/xml_io.php');
            $evakorrid=eva_schreiben(array(), $neue_lead_id);
        }
        
        if (($_SESSION['crm_version']>61 or $cfg_bdc_grund) and !$cfg_bdc_nl) {
            saveInBdcDB(
                $lead['stammdaten_id'],
                $mandid,
                $lagid,
                ($postfeld[$p.'grund']!=-1?$postfeld[$p.'grund']:''),
                ($postfeld['form_kunde_ansprechpartner_id']!=-1?$postfeld['form_kunde_ansprechpartner_id']:0),
                'Lead',
                $neue_lead_id,
                0,
                $postfeld['form_lead_bdc_kanal']
            );
        }

        
        if (isset($postfeld['ctiCallDuration']) && trim($postfeld['ctiCallDuration'])!='') {
            if (function_exists('zahl_seconds')) {
                $postfeld['ctiCallDuration']=" \r\n"._TELEFONAT_DAUER_.': '.zahl_seconds($postfeld['ctiCallDuration']);
            } else {
                $postfeld['ctiCallDuration']=" \r\n"._TELEFONAT_DAUER_.': '.$postfeld['ctiCallDuration'];
            }
            $additionaldata_string2.=$postfeld['ctiCallDuration'];
        }
        //wird immer eine neue korres erstellt
        //wenn folge dann parentid>0
        $sqlt = array(
            $sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
            //$sql_tabs['korrespondenz']['datum2'] => $db->dbtimestamp(0),
            $sql_tabs['korrespondenz']['wvl_datum1'] => $db->dbtimestamp(time()),
            //$sql_tabs['korrespondenz']['wvl_datum2'] => $db->dbtimestamp(0),
            $sql_tabs['korrespondenz']['stammdaten_id'] => $lead['stammdaten_id'],
            $sql_tabs['korrespondenz']['ersteller_id'] =>$lead['ersteller_id'],
            $sql_tabs['korrespondenz']['betreuer_id'] =>$lead['benutzer_id'],
            $sql_tabs['korrespondenz']['eingang'] => $db->dblogic(false),
            $sql_tabs['korrespondenz']['art'] => $db->dbzahl(14),
            $sql_tabs['korrespondenz']['kategorie'] => $db->str((isset($postfeld[$p.'kategorie']) && $postfeld[$p.'kategorie']!='' && $postfeld[$p.'kategorie']!='-1') ? $postfeld[$p.'kategorie'] : _LEADS_),
            $sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(false),
            $sql_tabs['korrespondenz']['parent_id'] => $db->dbzahl(0),
            $sql_tabs['korrespondenz']['doclink'] => $db->str(''),
            $sql_tabs['korrespondenz']['betreff'] => $db->str($postfeld[$p.'betreff']),
            $sql_tabs['korrespondenz']['beschreibung'] => $db->str($additionaldata_string2),
            $sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl($produktzuordnung_id),
            $sql_tabs['korrespondenz']['veranstaltung_id'] => $db->dbzahl(0),
            $sql_tabs['korrespondenz']['veranstaltung_status'] => $db->dbzahl(0),
            $sql_tabs['korrespondenz']['papierkorb'] => 0,
            $sql_tabs['korrespondenz']['kalender_id'] => $db->dbzahl(0),
            $sql_tabs['korrespondenz']['negativ'] => $db->dblogic(false),
            $sql_tabs['korrespondenz']['auftrag_id'] => $db->dbzahl(0),
            $sql_tabs['korrespondenz']['projekt_id'] => $db->dbzahl(0),
            $sql_tabs['korrespondenz']['opportunity_id'] => $db->dbzahl(0),
            $sql_tabs['korrespondenz']['troubleticket_id'] => $db->dbzahl(0),
            $sql_tabs['korrespondenz']['aus_workflow'] => $db->dblogic(false),
            $sql_tabs['korrespondenz']['kampagne_id'] => $lead['kampagne_id'], //$kamp_id !!
            $sql_tabs['korrespondenz']['lead_id'] => $db->str($neue_lead_id),
            $sql_tabs['korrespondenz']['kstatus'] => $db->dbzahl(0),
            $sql_tabs['korrespondenz']['quelle'] => $db->str('BDC'),
            $sql_tabs['korrespondenz']['kanal'] => $db->str(''),
            $sql_tabs['korrespondenz']['kategorie2'] => $db->str($postfeld[$p.'kategorie']),
            $sql_tabs['korrespondenz']['followup_anzahl'] => $db->dbzahl(0),
            $sql_tabs['korrespondenz']['status1_time'] => $db->dbtimestamp(time()),
            $sql_tabs['korrespondenz']['zusatz2'] => $db->str('')
        );
		if (intval($apid_neu)>0) {
			$sqlt[$sql_tabs['korrespondenz']['ansprechpartner_id']]=$db->dbzahl($apid_neu);
		}
		if ($cfg_lead_fahrzeugbesitz and isset($postfeld[$p.'fahrzeug2']) and intval($postfeld[$p.'fahrzeug2'])>0 and intval($produktzuordnung_id)<=0) {
			$sqlt[$sql_tabs['korrespondenz']['produktzuordnung_id']]=$db->dbzahl($postfeld[$p.'fahrzeug2']);
		}
        if ($cfg_bdc_nl) {
            $sqlt[$sql_tabs['korrespondenz']['wvl_datum1']] = $db->dbtimestamp($postfeld[$p.'wvldatum']);
        }
        if ($postfeld['is_bdc_mailbox_request']==1 && class_exists('Mailbox_EmailAdmin')) {
            Mailbox_EmailAdmin::updateState($_SESSION['bdc_email_path'],'3','bdc',
                array(
                    'correspondence_id'=>$korrid,
                    'lead_id'=>$neue_lead_id,
                    'user_id'=>$_SESSION['user_id'],
                    'time'=>time(),
                    'st_id'=>$postfeld['form_kunde_stdid'],
                    'type'=>'Lead'
                )
            );

            $emailAdmin = new Mailbox_EmailAdmin('Mailbox_Processor_Posteingang');
            $mailboxEmail = $emailAdmin::getEmail($_SESSION['bdc_email_path']);
            $mailboxEmail->createCorrespondenceForMail([
                'type' => 'LEAD',
                'lead_id' => $neue_lead_id,
                'stammdaten_id' => $postfeld['form_kunde_stdid'],
                'create_mode' => 'NEW',
            ]);
        }
    
        if (isset($postfeld[$p.'leadpool'])) {//  || isset($postfeld[$p.'eva'])
            
        } else {
			
			if (isset($postfeld[$p.'eva'])) {
				$korrid=$evakorrid;
			} else {
	            $db->insert(
    	            $sql_tab['korrespondenz'], $sqlt
        	    );
            	$korrid=$db->insertid();
			}
            if ($_SESSION['crm_version']>67) {
                if (!empty($new_files_lead)) {
                    if (is_array($new_files_lead)) {
                        foreach ($new_files_lead as $label => $link) {
                            $label = p4n_mb_string('utf8_decode', $label);
                            $link = p4n_mb_string('utf8_decode', $link);

                            $db->insert(
                                $sql_tab['korrespondenz_doks'],
                                array(
                                    $sql_tabs['korrespondenz_doks']['korrespondenz_id'] => $db->dbzahl($korrid),
                                    $sql_tabs['korrespondenz_doks']['bezeichnung']      => $db->str($label),
                                    $sql_tabs['korrespondenz_doks']['datei']            => $db->str(str_replace('dokumente_korrespondenz/', '', $link))
                                )
                            );
                        }
                    }
                }
            }

            $lstatus=2;
            if ($cfg_bdc_nl && isset($postfeld[$p.'status'])) {
                $lstatus = $postfeld[$p.'status'];
            }

            $res=$db->update(
                $sql_tab['kampagne_lead'],
                array(
                    $sql_tabs['kampagne_lead']['korrespondenz_id'] => $db->dbzahl($korrid),
                    $sql_tabs['kampagne_lead']['status'] => $db->str($lstatus),
                    $sql_tabs['kampagne_lead']['status2_time'] => $db->dbtimestamp(time()),
                ),
                $sql_tabs['kampagne_lead']['kampagne_lead_id'].' = '.$db->dbzahl($neue_lead_id)
            );
        }
        
        $mail_lead=false;
        if (isset($postfeld[$p.'leadpool'])) {
            include_once('inc/mailabruf.php');
            //$cfg_leadmail_fuer_benutzergruppe='Makrogruppe';
            $mandant_id = $lead['lagerort_id'];
            // Benachrichtigung
            if (!empty($cfg_lead_einstellungen_neu) || $_SESSION['crm_version'] > 67) {
                $leadParams = array(
                    'params' => array(
                        'kampagne_lead_id' => $neue_lead_id,
                        'lagerort_id'      => $lead['lagerort_id'],
                        'channel'          => $lead['channel'],
                        'type'             => $lead['type'],
                        'kfzmarke'         => $lead['kfzmarke'],
                        'source'           => $lead['source'],
                        'kampagne_id'      => $lead['kampagne_id']
                    ),
                    'customer' => array(
                        'stammdaten_id' => $lead['stammdaten_id']
                    ),
                    'lead' => $lead
                );
                if ($cfg_lead_absatzgruppe || $_SESSION['crm_version_float']>=61300) {
                    $leadParams['params']['absatzgruppe'] = $lead['absatzgruppe'];
                }
                Lead_Notification::instance('BDC')->run(array($mandant_id => array('NOID' => $leadParams)));
                // Kunden Benachrichtigung
                $notificationEmail = null;
                foreach ($customerEmails as $customerEmail) {
                    if (validate_email($customerEmail, true)) {
                        $notificationEmail = $customerEmail;
                        break;
                    }
                }
                if ($notificationEmail) {
                    $newLeads = array(
                        $notificationEmail => $leadParams
                    );
                    Lead_CustomerNotification::instance('BDC')->run($newLeads);
                } else {
                    Lead_CustomerNotification::instance('BDC')->log(_NO_MAILS_FOUND_.' (LEAD ID: '.$neue_lead_id.')');
                }

            } else if ($_SESSION['crm_version'] > 64) {
                Lead_Notification::instance('BDC')->run(array($mandant_id => array('NOID' => $neue_lead_id)));
            } else {
                if (function_exists('lead_benachrichtigung_an_gruppe')) {
                    $alle_leads_zu_mandant[$mandant_id][] = array('kamp_lead_id' => $neue_lead_id, 'boerse' => 'BDC');
                    lead_benachrichtigung_an_gruppe($cfg_leadmail_fuer_benutzergruppe, $alle_leads_zu_mandant);
                }
            }
            
            if (intval($cfg_leadengine_benachrichtigung) > 0) {
                $res4=$db->select(
                    $sql_tab['benutzer'],
                    $sql_tabs['benutzer']['email'],
                    $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($cfg_leadengine_benachrichtigung)
                );
                $ergebnis_mail = '';
                if ($row4=$db->zeile($res4)) {
                    if ($row4[0]!='') {
                        $mail_temp = $mail;
                        if (isset($_SESSION['user_email']) && $_SESSION['user_email']!='') {
                            $absender = $_SESSION['user_email'];
                        } else {
                            $absender = $mcs_pop3_email;
                        }
                        $absender_name='CATCH';
                        $result_einstellungen = $db->select(
                            $sql_tab['einstellungen'],
                            $sql_tabs['einstellungen']['wert'],
                            $sql_tabs['einstellungen']['modul'].'='.$db->str('mailbeileadeingang')
                        );
                        if ($row_einstellungen = $db->zeile($result_einstellungen)) {
                            if (is_numeric($row_einstellungen[0])) {
                                if (intval($row_einstellungen[0]) > 0) {
                                    $absender = intval($row_einstellungen[0]);
                                }
                            } else {
                                if ($row_einstellungen[0]!='') {
                                    $email_einstellungen_explode = explode('#####', $row_einstellungen[0]);
                                    $absender=$email_einstellungen_explode[0];
                                    if (trim($email_einstellungen_explode[1])!='') {
                                        $absender_name=$email_einstellungen_explode[1];
                                    }
                                }
                            }
                        }
                        $erfolg = mailSendP4n($row4[0], $absender, $absender_name, array(), array(), '1 '._NEUE_LEADS_.' ('._ALLG_ANFRAGE_.')', '<font face=arial size=2>'.p4n_mb_string('str_replace',"\n", '<br>', '1 '._NEUE_LEADS_.'<br>').'</font>', array(), 0, true);
                        $ergebnis_mail = $erfolg['text'];
                        $mail = $mail_temp;
                    }
                }
                
                
                $sqlt=array(
                    $sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
                    $sql_tabs['korrespondenz']['datum2'] => '0',
                    $sql_tabs['korrespondenz']['wvl_datum1'] => $db->dbtimestamp(time()),
                    $sql_tabs['korrespondenz']['wvl_datum2'] => '0',
                    $sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl(0),
                    $sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($cfg_leadengine_benachrichtigung),
                    $sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($cfg_leadengine_benachrichtigung),
                    $sql_tabs['korrespondenz']['eingang'] => $db->dblogic(false),
                    $sql_tabs['korrespondenz']['art'] => $db->dbzahl(14),
                    $sql_tabs['korrespondenz']['kategorie'] => $db->str(_LEADS_),
                    $sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(false),
                    $sql_tabs['korrespondenz']['parent_id'] => $db->dblogicfull(0),
                    $sql_tabs['korrespondenz']['doclink'] => $db->str(''),
                    $sql_tabs['korrespondenz']['betreff'] => $db->str('1 '._NEUE_LEADS_.' ('._ALLG_ANFRAGE_.')'),
                    $sql_tabs['korrespondenz']['beschreibung'] => $db->str('1 '._NEUE_LEADS_.' ('._ALLG_ANFRAGE_.')'."\n\n".$ergebnis_mail),
                    $sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl($postfeld[$p.'fahrzeug']),
                    $sql_tabs['korrespondenz']['veranstaltung_id'] => $db->dbzahl(0),
                    $sql_tabs['korrespondenz']['veranstaltung_status'] => $db->dbzahl(0),
                    $sql_tabs['korrespondenz']['papierkorb'] => 0,
                    $sql_tabs['korrespondenz']['kalender_id'] => $db->dbzahl(0),
                    $sql_tabs['korrespondenz']['prioritaet'] => $db->dbzahl(0),
                    $sql_tabs['korrespondenz']['negativ'] => $db->dblogic(false),
                    $sql_tabs['korrespondenz']['auftrag_id'] => $db->dbzahl(0),
                    $sql_tabs['korrespondenz']['ansprechpartner_id'] => $db->dbzahl(0),
                    $sql_tabs['korrespondenz']['projekt_id'] => $db->dbzahl(0),
                    $sql_tabs['korrespondenz']['opportunity_id'] => $db->dbzahl(0),
                    $sql_tabs['korrespondenz']['troubleticket_id'] => $db->dbzahl(0),
                    $sql_tabs['korrespondenz']['aus_workflow'] => $db->dblogic(false),
                    $sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl(0),
                    $sql_tabs['korrespondenz']['lead_id'] => $db->dbzahl(0)
                );
                if ($cfg_bdc_nl) {
                    $sqlt[$sql_tabs['korrespondenz']['wvl_datum1']] = $db->dbtimestamp($postfeld[$p.'wvldatum']);
                }
                
                $db->insert(
                        $sql_tab['korrespondenz'], $sqlt
                );
            }
            

            
        } else {
           /* $alle_bmadr = array();
            if (isset($postfeld[$p.'emailan']) && !in_array($postfeld[$p.'emailan'],$alle_bmadr)) {
                $exple=explode(';',$postfeld[$p.'emailan']);
                foreach ($exple as $exple_val) {
                    if ($exple_val!='') {
                        $alle_bmadr[] = $exple_val;
                    }
                }
            }
            if (isset($postfeld[$p.'email2']) && intval($postfeld[$p.'email2'])>0) {
                $res=$db->select(
                    $sql_tab['benutzer'],
                    array(
                        $sql_tabs['benutzer']['email'],
                        $sql_tabs['benutzer']['passwort'],
                        $sql_tabs['benutzer']['benutzer_id']
                    ),
                     $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($postfeld[$p.'email2'])
                );
                while ($row=$db->zeile($res)) {
                    if ($row[0]!='' && !in_array($row[0],$alle_bmadr)) {
                        $alle_bmadr[]=$row[0];
                    }
                }
            }
            if (isset($postfeld[$p.'email1']) && intval($postfeld[$p.'email1'])>0) {
                $res=$db->select(
                    $sql_tab['benutzer'],
                    array(
                        $sql_tabs['benutzer']['email'],
                        $sql_tabs['benutzer']['passwort'],
                        $sql_tabs['benutzer']['benutzer_id']
                    ),
                     $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($postfeld[$p.'email1'])
                );
                while ($row=$db->zeile($res)) {
                    if ($row[0]!='' && !in_array($row[0],$alle_bmadr)) {
                        $alle_bmadr[]=$row[0];
                    }
                }
            }
            $res=$db->select(
                $sql_tab['benutzer'],
                array(
                    $sql_tabs['benutzer']['email'],
                    $sql_tabs['benutzer']['passwort'],
                    $sql_tabs['benutzer']['benutzer_id']
                ),
                 $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($postfeld[$p.'benutzer'])
            );
            while ($row=$db->zeile($res)) {
                if ($row[0]!='' && !in_array($row[0],$alle_bmadr)) {
                    $alle_bmadr[]=$row[0];
                }
            }*/
            if ($postfeld[$p.'benutzer'] === $_SESSION['user_id']) {
                // kein E-Mail-Versand fuer sich selbst
                $redirectToLeadTab = true;
            } else if (count($alle_bmadr) > 0) {
                include_once("inc/lib_htmledit.php");
                include_once('inc/class_bdc_email.php');

                $htmleditor = new HTMLEditor();
                //$mail = $htmleditor->prepare_mail(138);
                
                if (intval($bdc_einstellungen['vorlage3'])>0) {
                    $mail = $htmleditor->prepare_mail($bdc_einstellungen['vorlage3']);
                } else {
                    $mail=$htmleditor->prepare_utf8_html_mail('template/bdc/lead'.($cfg_bdc_nl?'_nl':(p4n_mb_string('substr',$_SESSION['cfg_kunde'], 0, p4n_mb_string('strlen','carlo_opel_avag'))=='carlo_opel_avag' ? '_avag':($cfg_bdc_lead_bearbeitung?'_edit':''))).'.html');
                    //if ($_SESSION['cfg_kunde']!='carlo_vw_audihannover' && $_SESSION['crm_version']<=62) {
                        //$mail->Body= preg_replace('/\<\!hannover1\>.*\<\!hannover2\>/Uis','',$mail->Body);
                    //}
                    //$mail->Body= p4n_mb_string('str_replace',array('<!hannover1>','<!hannover2>'),'',$mail->Body); 
                }
                $mail->Subject = _NEUEINTRAG_ . ': ' . _LEAD_ . ' (' . adodb_date('d.m.Y, H:i') . ') - ' . kundenbezeichnung($postfeld['form_kunde_stdid']) . ' (' . $postfeld['form_kunde_stdid'] . ')';
                if ($bdc_email_betreff) {
                    $mail->Subject = 'BDC ' . _LEAD_ . ' ('.$neue_lead_id.') - ' . $postfeld['form_lead_betreff'];
                }
                //Griga Flag
                $bdc_mail=new bdcMail();
                if ($_SESSION['crm_version']>67) {
                   $bdc_mail->with_attachments=true;
                }
                $mail=$bdc_mail->lead($neue_lead_id,$mail,$postfeld['form_kunde_ansprechpartner_id'],$alle_bmadr,_NEUEINTRAG_ . ': ');
                $mailtext=$mail->Body;
 
                $mail->IsHTML(true);
                @reset($alle_bmadr);
                while (list($keyba, $valba) = @each($alle_bmadr)) {
                    $mail->AddAddress($valba);
                }

                preg_match_all('/(src|background)=\"(?P<image>.*?(jpg|jpeg|png|gif))\"/i', $mailtext, $matches);
                foreach (array_unique($matches['image']) as $i => $src) {
                    $parts = explode('/', p4n_mb_string('str_replace', '\\', '/', $src));

                    // Nur lokale Bilder einbetten
                    if (!preg_match('/^[A-z][A-z]*:\/\//', $src)) {
                        $cid = 'img'.$i;
                        $cid .=md5($src);
                        # Ersetze Bilder-URL mit Content-ID
                        $mailtext = p4n_mb_string('str_replace', $src, 'cid:'.$cid, $mailtext);
                        $mail->AddEmbeddedImage($src, $cid);
                    }
                }
                $mailtext= preg_replace('/\<\![A-Za-z0-9_]*\>/Uis','',$mailtext);
                $mail->Body = $mailtext;
                // init default settings from
                $mail->From = $bdc_einstellungen['absender'] != '' ? $bdc_einstellungen['absender'] : $_SESSION['user_email'];
                $mail->FromName = $bdc_einstellungen['absendername'] != '' ? $bdc_einstellungen['absendername'] : $_SESSION['mitarbeiter_name'];
                //Alexander 5.06.2022
                //implode Microsoft Azure API
                // use azure 'personal email 1 address' for send mail
                if (!empty($cfg_microsoft_v2) && !empty($cfg_microsoft_v2_email_send)) {
                    $azure_email = AzureApp::getUserEmail($_SESSION['user_id'], $_SESSION['user_role'], 2); // 'personal email 1' is priority
                    if (!empty($azure_email['error'])) {
                        echo javas('alert("'.p4n_mb_string('htmlspecialchars', $azure_email['error']).'");');
                    }
                    if (!empty($azure_email['data']['mail'])) {
                        $mail->From = $azure_email['data']['mail'];
                        $mail->FromName = $azure_email['data']['name'];
                    }
                }
                if ($cfg_smtp_alternative) {
                    $smtpAlternative = array();
                    if (is_file('inc/utilities.php')) {
                        include_once 'inc/utilities.php';
                        $smtpAlternative = getSMTPdetails('stammdaten_uebersicht');
                    }
                }
                ob_start();
                
                $gesendet2=$gesendet3=true;
                if (method_exists($bdc_mail,'splitMailTo')) {
                    $mail=$bdc_mail->splitMailTo($mail);
                    if ($cfg_bdc_nl===true) {
                        $mail_temp=clone $mail;
                        $gesendet1=$bdc_mail->sendAll($mail_temp);
                    } else {
                    if ($_POST['form_lead_sparte'] == 'AS' && ($cfg_stammdaten_lead || $cfg_leadzuordnung_as)) {           //Flag at new sending
                            $result = $db->select(
                                $sql_tab['einstellungen'],
                                $sql_tabs['einstellungen']['wert'],
                                $sql_tabs['einstellungen']['modul'].'='.$db->str('mailbeileadzuordnung')
                            );

                            if ($row = $db->zeile($result)) {
                                debug_logging('Row: '.print_r($row,true));
                                $email_an_leadbenutzer_explode = explode(';', $row[0]);
                                if ($email_an_leadbenutzer_explode[2]!='' ) {
                                    //Here it assigns email_vorlagen_id Flag 4
                                    $email_an_leadbenutzer_vorlage = $email_an_leadbenutzer_explode[2];
                                    $email_an_leadbenutzer = intval($email_an_leadbenutzer_explode[3]);
                                    $html_editor = new HTMLEditor();
                                    $temp_mail=$html_editor->prepare_mail($email_an_leadbenutzer_vorlage, dirname($_SERVER['PHP_SELF']));
                                    debug_logging('First Temp_mail: '.print_r($temp_mail,true));
                                    $bdc_mail=new bdcMail();
                                    $bdc_mail->with_attachments=true;
                                    debug_logging('$neue_lead_id: '.$neue_lead_id);
                                    /*if (!function_exists('getAnsprechpartner')) {
                                        include_once('inc/StammdatenBlatt.php');
                                        $ap_array = StammdatenBlatt::getAnsprechpartner();
                                        debug_logging('$ap_array: '.print_r($ap_array,true));
                                        //$ap_id = $ap_array[0]['id'];
                                        debug_logging('$ap_id: '.$ap_id);
                                    }
                                    if( $getfeld['apid'] ) {
                                        $ap_id = $getfeld['apid'];
                                    }
                                    debug_logging('$ap_id: '.$ap_id);
                                    */
                                    //$temp_mail=$bdc_mail->lead($neue_lead_id,$temp_mail, $ap_id, array($useremail));
                                    $ap_id = $postfeld['form_kunde_ansprechpartner_id'];
                                    $temp_mail=$bdc_mail->lead($neue_lead_id, $temp_mail, $ap_id, array($useremail));
                                    debug_logging('Temp_mail: '.print_r($temp_mail,true));
                                    $bdc_mail->sendAll($temp_mail);
                                    $gesendet_as = true;
                                    //mailBeiLeadZuordnung_send($postfeld['form_kunde_stdid'], $_POST['form_lead_benutzer'],'AS');
                                }
                            }
                        } else {
                            $mail_temp=clone $mail;
                            $gesendet1=$bdc_mail->sendVerursacherMail($mail_temp);
                            $mail_temp=clone $mail;
                            $gesendet2=$bdc_mail->sendAndereBenutzer($mail_temp);
                            $mail_temp=clone $mail;
                            $gesendet3=$bdc_mail->sendFreieAdressen($mail_temp);
                            debug_logging('At mails Sendings.  Post: '.print_r($_POST,true));      //Flag
                        }
                    } 
                } else {
                    debug_logging('At mail Send');      //Flag
                    $gesendet1=$mail->Send($smtpAlternative);
                }
                $hinweistext70='';
                if ($cfg_bdc_nl===true) {
                    if (!$gesendet1) {
                        $hinweistext .= '<font color=red>' . _EMAILING_EMAILS_FEHLER_ . '</font><br>';
                    } else {
                        $hinweistext .= _EMAILING_EMAILS_ABGESCHICKT_ . '<br>';
                    }
                } else {
                   if ((!$gesendet1 || !$gesendet2 || !$gesendet3) && !$gesendet_as) {
                        $hinweistext .= '<font color=red>' . _EMAILING_EMAILS_FEHLER_ . '</font><br>';
                        $hinweistext70=_EMAILING_EMAILS_FEHLER_.'<br>';
                    } else {
                        debug_logging('At Msg alert');
                        $hinweistext .= _EMAILING_EMAILS_ABGESCHICKT_ . '<br>';//This is the Msg
                        $erfolgtext.='<br>'._EMAILING_EMAILS_ABGESCHICKT_;
                    } 
                }
                $x=addslashes(ob_get_clean());
                $hinweistext.=$x;
                $hinweistext70.=$x;
                $mail_lead=true;
               // echo javas('jq1112(document).ready(function ($) {bdc_alert("'.$hinweistext.'");});');
            }
        }
        
    
  
     if (($mail_lead || $mail_bm) && !$_SESSION['design_70'])   {
          echo javas('jq1112(document).ready(function ($) {bdc_alert("'.$hinweistext.'",false,'.(isset($_GET['ohnecc'])?'true':'false').');});');

    } else {
        if (isset($_GET['ohnecc']) && !$_SESSION['design_70']) {
            echo javas('try {parent.P4nBoxHelper.closeall();} catch(e) {}');
        }
    }
    
    if ($_SESSION['design_70']) {
        if ($hinweistext70!='') {
            Template_Alert::alert($hinweistext70);
        } else {
            Template_Alert::success($erfolgtext);
        }
        
        if ($redirectToLeadAfterLeadCreation) {
            $_SESSION['lead'][$postfeld['form_kunde_stdid']] = $neue_lead_id;
            echo Template_Trait_Request_Helper::setAutoModalWeiterleitung(
                'GET',
                'stammdaten_main.php',
                'nav=lead&lead='.$neue_lead_id.'&id='.$postfeld['form_kunde_stdid'],
                'lead='.$neue_lead_id.'&modal=1&stammdaten_lead_tab=tab_aktivitaeten',
                'pim_aendern_modal'
            );
            exit;
        }
        
        if ($_SESSION['bdc_ziel']=='stammdaten') {
            wechsel('stammdaten_main.php?nav=Uebersicht&exclude_stammdaten_tabs=1');
        } else {
            wechsel('startseite.php');
        }
        exit;
    }
    unset($_SESSION['bdcSelectedAp']);
    unset($postfeld);
    if (!empty($redirectToLeadTab)) {
        exit(javas('location.href="stammdaten_main.php?nav=lead";'));
    }
}

if (isset($getfeld['suche'])) {
    //$postfeld['form_kunde_suche']=true;
}
if (!isset($postfeld['form_kunde_telefon_privat']) && isset($getfeld['telefon_privat']) && $getfeld['telefon_privat']!='') {
    $postfeld['form_kunde_telefon_privat']=$getfeld['telefon_privat'];
}

if (isset($postfeld['form_kunde_suche_erg'])) {
    $postfeld=unserialize(base64_decode($postfeld['form_kunde_suche_erg']));
}




function bdcSearchReplace($str='') {
    $str=p4n_mb_string('str_replace', "*", "%", $str);
    $str=p4n_mb_string('str_replace', "%%", "%", $str);
    return $str;
}

function telSearch($search='') {
    global $db, $sql_tab, $sql_tabs;
    $stdwhere='';
    $wheret='';
    if ((isset($_GET['null_ign']) && $_GET['null_ign']==1) or (isset($_POST['null_ign']) && $_POST['null_ign']==1)) {
        if (substr($search, 0, 1)=='0') {
            $search=substr($search, 1);
        }
    }
    
    $nochschneller_eintraege = $_SESSION['nochschneller_telefonsuche'];
    if (isset($_POST['form_kunde_stdid']) && $_POST['form_kunde_stdid']!='' && $_POST['form_kunde_stdid']!=0) {
        $alle_stammdaten_ids=array($_POST['form_kunde_stdid']);
        $wheret = $db->dbzahlin($alle_stammdaten_ids, $sql_tabs['stammdaten']['id']).' or ';
    } elseif ($nochschneller_eintraege) {
        $v = telefon_variationen($search);
        $or_search = array();
        foreach ($v as $such_term) {
            $or_search[] = $sql_tabs['stammdaten_telefon_suche']['telefonnr'].' like '.$db->str(str_replace('*', '%', $such_term));
        }
        $result_stammdaten_telefon_suche = $db->select(
            $sql_tab['stammdaten_telefon_suche'],
            $sql_tabs['stammdaten_telefon_suche']['stammdaten_id'],
            implode(' or ', $or_search)
        );
        $alle_stammdaten_ids = array();
        $zaehler=0;
        while ($row_stammdaten_telefon_suche = $db->zeile($result_stammdaten_telefon_suche)) {
            $alle_stammdaten_ids[$row_stammdaten_telefon_suche[0]]=$row_stammdaten_telefon_suche[0];
            if ($zaehler++ > 2000) {
                break;
            }
        }
        $wheret = $db->dbzahlin($alle_stammdaten_ids, $sql_tabs['stammdaten']['id']).' or ';
    } else {
        $tels=preg_replace('/\D/', '', $search);
        if ($tels!='') {
            $wheret.='REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE('.$sql_tabs['stammdaten']['Telefon_1'].',"-",""),"+","")," ",""),")",""),"(",""),".",""),"/","") like '.$db->str('%'.$tels.'%').' or ';
            $wheret.='REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE('.$sql_tabs['stammdaten']['Telefon_2'].',"-",""),"+","")," ",""),")",""),"(",""),".",""),"/","") like '.$db->str('%'.$tels.'%').' or ';
            $wheret.='REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE('.$sql_tabs['stammdaten']['Telefon_3'].',"-",""),"+","")," ",""),")",""),"(",""),".",""),"/","") like '.$db->str('%'.$tels.'%').' or ';
            $wheret.='REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE('.$sql_tabs['stammdaten']['Mobilfon_1'].',"-",""),"+","")," ",""),")",""),"(",""),".",""),"/","") like '.$db->str('%'.$tels.'%').' or ';
            $wheret.='REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE('.$sql_tabs['stammdaten']['Mobilfon_2'].',"-",""),"+","")," ",""),")",""),"(",""),".",""),"/","") like '.$db->str('%'.$tels.'%').' or ';
            $wheret.='REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE('.$sql_tabs['stammdaten']['Mobilfon_3'].',"-",""),"+","")," ",""),")",""),"(",""),".",""),"/","") like '.$db->str('%'.$tels.'%').' or ';
        }
    }
    if ($wheret!='') {
        $wheret=substr($wheret, 0, -4);
        $stdwhere=' ('.$wheret.') and ';
    }
    return $stdwhere; 
}

function log_bdcs_telt($t) {
	if ($fp=fopen('lot.txt', 'a')) {
		fwrite($fp, adodb_date('d.m.Y H:i:s').': '.$t."\r\n");
		fclose($fp);
	}
}

/***SUCHE***/
if (isset($postfeld['form_kunde_suche'])) {
    if (!isset($getfeld['suche'])) {
        Modern_Helper_Request::requestStart();
        Modern_Helper_Encoding::getHeader();
    }
	
	$mitaps=false;
	$mitstidsu=false;
	if (isset($postfeld['form_kunde_suche']) and isset($postfeld['form_kunde_telefon_privat']) and $postfeld['form_kunde_telefon_privat']!='') {
		//$postfeld['form_kunde_ap_telefon']=$postfeld['form_kunde_telefon_privat'];
		//$postfeld['form_kunde_ap_mobil']=$postfeld['form_kunde_telefon_privat'];
		$sqlt=telSearch($postfeld['form_kunde_telefon_privat']);
		if ($sqlt!='') {
			$sqlt=substr($sqlt, 0, -5);
			$res=$db->select(
				$sql_tab['stammdaten'],
				$sql_tabs['stammdaten']['id'],
				$sqlt
			);
			$stids='';
			while ($row=$db->zeile($res)) {
				$stids.=$row['stammdaten_id'].',';
				$mitstidsu=true;
			}
		}
		$tels=str_replace(array(' ', '-', '+', ',', '.', '/', '(', ')'), '', $postfeld['form_kunde_telefon_privat']);
		$tels=preg_replace('/\D/', '', $tels);
		$apidstel='';
        if (isset($postfeld['form_kunde_stdid']) && $postfeld['form_kunde_stdid']!='' && $postfeld['form_kunde_stdid']!=0) {
            $stids = $postfeld['form_kunde_stdid'];
            $mitstidsu=true;
            $apWhere=$db->dbzahlin($postfeld['form_kunde_stdid'], $sql_tabs['stammdaten_ansprechpartner']['stammdaten_id']);
        } else{
            $apWhere='REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE('.$sql_tabs['stammdaten_ansprechpartner']['telefon'].',"-",""),"+","")," ",""),")",""),"(",""),".",""),"/","") like '.$db->str('%'.$tels.'%').' or '.'REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE('.$sql_tabs['stammdaten_ansprechpartner']['mobil'].',"-",""),"+","")," ",""),")",""),"(",""),".",""),"/","") like '.$db->str('%'.$tels.'%');
        }
		$res=$db->select(
			$sql_tab['stammdaten_ansprechpartner'],
			array(
				$sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'],
				$sql_tabs['stammdaten_ansprechpartner']['ansprechpartner_id']
			),
            $apWhere
			);
		while ($row=$db->zeile($res)) {
			$stids.=$row['stammdaten_id'].',';
			$apidstel.=$row['ansprechpartner_id'].',';
		}
		if ($stids!='') {
			$stids=substr($stids, 0, -1);
		}
		if ($apidstel!='') {
			$apidstel=substr($apidstel, 0, -1);
			$mitaps=true;
		}
	}
    
    if ($_SESSION['crm_version']>68 && $postfeld['form_kunde_name']!='' && $postfeld['form_kunde_anrede']=='' && $postfeld['form_kunde_vorname']=='') {
        $postfeld['form_kunde_firma']=$postfeld['form_kunde_name'];
    }
    
    $umlaute = array('�' => 'ae', '�' => 'oe', '�' => 'ue', '�' => 'ss', '�' => 'Ae', '�' => 'Oe', '�' => 'Ue');
    $umlaute2 = array('ae' => '�', 'oe' => '�', 'ue' => '�', 'ss' => '�', 'Ae' => '�', 'Oe' => '�', 'Ue' => '�');

    $apwhere='';
    $apid=0;
    $stdabpid=0;
    $apbez='';
    //$ids='';
    
    
    if ($cfg_ignoriere_gruppenzuordnung) {
        $wh2='';
    } else {
        $wh2=sql_gruppe($sql_tabs['stammdaten']['id']);
    }
    $stdwhere='';
    if ($wh2!='') {
        $stdwhere=$wh2.' and ';
    }
	if ($cfg_olympia_server and intval($_SESSION['user_standard_lagerort'])>0) {
		$res8=$db->select(
			$sql_tab['mandant'],
			$sql_tabs['mandant']['parent_id'],
			$sql_tabs['mandant']['mandant_id'].'='.$db->dbzahl($_SESSION['user_standard_lagerort'])
		);
		if ($row8=$db->zeile($res8)) {
			if (intval($row8[0])==$cfg_olympia_server_mandant) {
				$stdwhere=$sql_tabs['stammdaten']['mandant'].'='.$db->dbzahl($cfg_olympia_server_mandant).' and ';
			} else {
				$stdwhere=$sql_tabs['stammdaten']['mandant'].'!='.$db->dbzahl($cfg_olympia_server_mandant).' and ';
			}
		}
	}
    $fromtabs=$sql_tab['stammdaten'];
    $joins=array();
    if (preg_match('/'.$sql_tab['stammdaten_gruppe_zuordnung'].'/Uis', $stdwhere)) {
        $fromtabs=array(
            $sql_tab['stammdaten'],
            $sql_tab['stammdaten_gruppe_zuordnung']
        );
        $joins=array(
            $sql_tabs['stammdaten']['id'] => $sql_tabs['stammdaten_gruppe_zuordnung']['stammdaten_id']
        );
    }
    
    $apids=0;
    $merke_ap_bez = $merke_aps= array();
    if ($postfeld['form_kunde_ap_anrede']!='') {
        $apwhere.=feldbed_s($sql_tabs['stammdaten_ansprechpartner']['anrede'], $db->str(bdcSearchReplace($postfeld['form_kunde_ap_anrede'].'%'))).' or ';
    }
    if ($postfeld['form_kunde_ap_titel']!='' && $postfeld['form_kunde_ap_titel']!=-1) {
        $apwhere.=feldbed_s($sql_tabs['stammdaten_ansprechpartner']['titel'], $db->str(bdcSearchReplace($postfeld['form_kunde_ap_titel'].'%'))).' or ';
    }
    if ($postfeld['form_kunde_ap_bezeichnung']!='') {
        $apwhere.=feldbed_s($sql_tabs['stammdaten_ansprechpartner']['bezeichnung'], $db->str(bdcSearchReplace($postfeld['form_kunde_ap_bezeichnung'].'%'))).' or ';
    }
    if ($cfg_bdc_nl && $postfeld['form_kunde_ap_mittelname']!='') {
        $apwhere.=feldbed_s($sql_tabs['stammdaten_ansprechpartner']['zusatz4'], $db->str(bdcSearchReplace($postfeld['form_kunde_ap_mittelname'].'%'))).' or ';
    }
    if ($cfg_bdc_nl && $postfeld['form_kunde_ap_rufname']!='') {
        $apwhere.=feldbed_s($sql_tabs['stammdaten_ansprechpartner']['zusatz3'], $db->str(bdcSearchReplace($postfeld['form_kunde_ap_rufname'].'%'))).' or ';
    }
    if ($postfeld['form_kunde_ap_vorname']!='') {
        $apwhere.=feldbed_s($sql_tabs['stammdaten_ansprechpartner']['vorname'], $db->str(bdcSearchReplace($postfeld['form_kunde_ap_vorname'].'%'))).' or ';
    }
    if ($postfeld['form_kunde_ap_telefon']!='') {
        $apwhere.=feldbed_s($sql_tabs['stammdaten_ansprechpartner']['telefon'], $db->str(bdcSearchReplace($postfeld['form_kunde_ap_telefon'].'%'))).' or ';
    }
    if ($postfeld['form_kunde_ap_mobil']!='') {
        $apwhere.=feldbed_s($sql_tabs['stammdaten_ansprechpartner']['mobil'], $db->str(bdcSearchReplace($postfeld['form_kunde_ap_mobil'].'%'))).' or ';
    }
    if ($postfeld['form_kunde_ap_email']!='') {
        $apwhere.=feldbed_s($sql_tabs['stammdaten_ansprechpartner']['email'], $db->str(bdcSearchReplace($postfeld['form_kunde_ap_email'].'%'))).' or ';
    }
	
	if ($mitaps) {
		$apwhere=$db->dbzahlin($apidstel, $sql_tabs['stammdaten_ansprechpartner']['ansprechpartner_id']).' or ';
	}
	
    if ($apwhere!='') {
        $apwhere=substr($apwhere,0,-4);
    
        
        $res = $db->select(
        $sql_tab['stammdaten_ansprechpartner'], 
            array(
                $sql_tabs['stammdaten_ansprechpartner']['ansprechpartner_id'], //0
                $sql_tabs['stammdaten_ansprechpartner']['vorname'], //1
                $sql_tabs['stammdaten_ansprechpartner']['bezeichnung'], //2
                $sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'], //3
                $sql_tabs['stammdaten_ansprechpartner']['adresse'], //4
                $sql_tabs['stammdaten_ansprechpartner']['plz'], //5
                $sql_tabs['stammdaten_ansprechpartner']['ort'], //6
                $sql_tabs['stammdaten_ansprechpartner']['email'], //7
                $sql_tabs['stammdaten_ansprechpartner']['telefon'], //8
                $sql_tabs['stammdaten_ansprechpartner']['mobil'], //9
                $sql_tabs['stammdaten_ansprechpartner']['anrede'], //10
                $sql_tabs['stammdaten_ansprechpartner']['titel'], //11
                $sql_tabs['stammdaten_ansprechpartner']['zusatz4'], //12
                $sql_tabs['stammdaten_ansprechpartner']['zusatz5'] //13
            ), 
            $apwhere
        );
        while ($row=$db->zeile($res)) {
            $apid=$row[0];
            $stdabpid=$row[3];
            if ($row[1]!='' && $row[2]!='') {
                $apbez=$row[2].', '.$row[1];
            }
            if ($row[1]!='' && $row[2]=='') {
                $apbez=$row[1];
            }
            if ($row[1]=='' && $row[2]!='') {
                $apbez=$row[2];
            }
            $titel='';
            if ($row[10]!='') {
                $titel.=$row[10].' ';
            }
            if ($row[11]!='') {
                $titel.=$row[11].' ';
            }
            if ($titel!='') {
                $titel=substr($titel,0,-1).' ';
            }
            
            if ($cfg_bdc_nl) {
                $apbez='';
                if ($row[1]!='') {
                    $apbez.=$row[1].', ';
                }
                if ($row[12]!='') {
                    $apbez.=$row[12].', ';
                }
                if ($row[2]!='') {
                    $apbez.=$row[2].', ';
                }
                if ($row[13]!='') {
                    $apbez.=$row[13].', ';
                }
                if ($apbez!='') {
                    $apbez=substr($apbez,0,-1);
                }
            }
            
            //$ids.=$row[3].',';
            $merke_ap_bez[$row[0]]=array('bez'=>$apbez, 'bezeichnung'=>$row[2], 'vorname'=>$row[1], 'email'=>$row[7], 'telefon'=>$row[8], 'mobil'=>$row[9]);
            $merke_ap_bez[$row[0]]['anrede']=$row[10];
            $merke_ap_bez[$row[0]]['titel']=$row[11];
            if ($cfg_bdc_nl) {
                $merke_ap_bez[$row[0]]['mittelname']=$row[12];
                $merke_ap_bez[$row[0]]['rufname']=$row[13];
            }
            
            $merke_aps[$row[3]][$apid]='<td class="td" style="font-size:11px;"><b>'.$titel.$apbez.'</b><br>'.($row[4]!=''?$row[4].'<br>':'').($row[5]!=''?$row[5].' ':'').$row[6].($row[5]!=''||$row[6]!=''?'<br>':'').($row[7]!=''?$row[7].'<br>':'').($row[8]!=''?$row[8].'<br>':'').($row[9]!=''?$row[9].'<br>':'').'</td>';
            $apids++;
        }
        if ($apids>0) {
            //$ids=substr($ids,0,-1);
            //$stdwhere='('.$db->dbzahlin($ids,$sql_tabs['stammdaten']['id']). ') and ';
            $stdwhere='('.$sql_tabs['stammdaten']['id'].' in (select '.$sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'].' from '.$sql_tab['stammdaten_ansprechpartner'].' where '.$apwhere.')) and ';
        }
    }
	
    if ($_SESSION['crm_version']>68 && $postfeld['form_kunde_name']!='' && $postfeld['form_kunde_anrede']=='' && $postfeld['form_kunde_vorname']=='') {
        $stdwhere.='(' . feldbed_s($sql_tabs['stammdaten']['name'], $db->str(bdcSearchReplace($postfeld['form_kunde_name'] . '%'))) . ' or ';
        $stdwhere.=' ' . feldbed_s($sql_tabs['stammdaten']['firma1'], $db->str(bdcSearchReplace($postfeld['form_kunde_firma'] . '%'))) . ' or ';
        $stdwhere.=feldbed_s($sql_tabs['stammdaten']['matchcode'], $db->str(bdcSearchReplace($postfeld['form_kunde_name'] . '%'))) .') and ';
    } else {
        if ($postfeld['form_kunde_name']!='' && $postfeld['form_kunde_firma']=='') {
            $stdwhere.='(' . feldbed_s($sql_tabs['stammdaten']['name'], $db->str(bdcSearchReplace($postfeld['form_kunde_name'] . '%'))) . ' or ';
            $stdwhere.=feldbed_s($sql_tabs['stammdaten']['matchcode'], $db->str(bdcSearchReplace($postfeld['form_kunde_name'] . '%'))) .') and ';
        }
        if ($postfeld['form_kunde_firma']!='') {
            $stdwhere.=feldbed_s($sql_tabs['stammdaten']['firma1'], $db->str(bdcSearchReplace($postfeld['form_kunde_firma'].'%'))).' and '; 
        }
    }
    
    if ($postfeld['form_kunde_vorname']!=''/* && $postfeld['form_kunde_firma']==''*/) {
        $stdwhere.=feldbed_s($sql_tabs['stammdaten']['vorname'], $db->str(bdcSearchReplace($postfeld['form_kunde_vorname'].'%'))).' and ';
    }
    if ($postfeld['form_kunde_Interessentennummer']!='') {
        $zfKundeids=getKundemitZf('Carlo Interessentennummer', $postfeld['form_kunde_Interessentennummer']);
        $zfKundeids=getKundemitZf('Carlo Debitorennummer', $postfeld['form_kunde_Interessentennummer'], $zfKundeids);
        $stdwhere.='('.$db->dbzahlin($zfKundeids, $sql_tabs['stammdaten']['id']).' or '.$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($postfeld['form_kunde_Interessentennummer']).') and ';
    }
    if ($cfg_bdc_nl && $postfeld['form_kunde_mittelname']!='') {
        $stdwhere.=feldbed_s($sql_tabs['stammdaten']['firma3'], $db->str(bdcSearchReplace($postfeld['form_kunde_mittelname'] . '%'))) . ' and ';
    }
    if ($cfg_bdc_nl && $postfeld['form_kunde_rufname']!='') {
        $stdwhere.=feldbed_s($sql_tabs['stammdaten']['firma2'], $db->str(bdcSearchReplace($postfeld['form_kunde_rufname'] . '%'))) . ' and ';
    }
    
    if ($postfeld['form_kunde_telefon_privat'] != '' && !isset($_GET['cti_fremd_id'])) {
        $stdwhere.=telSearch($postfeld['form_kunde_telefon_privat']);
    }
    if ($postfeld['form_kunde_mobil_privat'] != '') {
        $stdwhere.=telSearch($postfeld['form_kunde_mobil_privat']);
    }
    if ($postfeld['form_kunde_telefon_ges'] != '') {
        $stdwhere.=telSearch($postfeld['form_kunde_telefon_ges']);
    }
    if ($postfeld['form_kunde_mobil_ges'] != '') {
        $stdwhere.=telSearch($postfeld['form_kunde_mobil_ges']);
    }
   // echo htmlentities($stdwhere);
    //Flag for ticket 1-32369
    if ($postfeld['form_kunde_email_privat'] != '') {
        $stdwhere.='('.feldbed_s($sql_tabs['stammdaten']['EMail_1'], $db->str(bdcSearchReplace($postfeld['form_kunde_email_privat'] . '%')));
        $stdwhere.= ' or '.feldbed_s($sql_tabs['stammdaten']['EMail_2'], $db->str(bdcSearchReplace($postfeld['form_kunde_email_privat'] . '%')));
        $stdwhere.=') and ';
    }
    if ($postfeld['form_kunde_email_ges'] != '') {
        $stdwhere.='('.feldbed_s($sql_tabs['stammdaten']['EMail_2'], $db->str(bdcSearchReplace($postfeld['form_kunde_email_ges'] . '%')));
        $stdwhere.= ' or '.feldbed_s($sql_tabs['stammdaten']['EMail_1'], $db->str(bdcSearchReplace($postfeld['form_kunde_email_ges'] . '%')));
        $stdwhere.=') and ';
    }
    if ($postfeld['form_kunde_titel'] != '') {
        $stdwhere.=feldbed_s($sql_tabs['stammdaten']['titel'], $db->str(bdcSearchReplace($postfeld['form_kunde_titel'] . '%'))) . ' and ';
    }
    
    /*if ($postfeld['form_kunde_telefon_eva'] != '') {
        $stdwhere.=feldbed_s($sql_tabs['stammdaten']['Telefon_3'], $db->str($postfeld['form_kunde_telefon_eva'] . '%')) . ' and ';
    }*/
    
    /*if ($postfeld['form_kunde_mobil_eva'] != '') {
        $stdwhere.=feldbed_s($sql_tabs['stammdaten']['Mobilfon_3'], $db->str($postfeld['form_kunde_mobil_eva'] . '%')) . ' and ';
    }*/
    if ($postfeld['form_kunde_standort'] != '-1' && $postfeld['form_kunde_standort'] != -1 && $postfeld['form_kunde_standort']!=''  ) {
        //$stdwhere.=' ('.feldbed_s($sql_tabs['stammdaten']['vpb'], $db->dbzahl($postfeld['form_kunde_standort']),'=') . ' or '.feldbed_s($sql_tabs['stammdaten']['mandant'], $db->dbzahl($postfeld['form_kunde_standort']),'=').') and ';
    }
    /*TT: Erstmal raus. Kunden beschweren sich
    if ($_SESSION['cfg_kunde']=='crm_vw_hahn') {
		// bei Hahn nicht auf Mand. filtern
	} else {
        $alle_mandanten_dealer = array(0 => 0) + $alle_dealer;
	    $stdwhere.=' ('.$db->dbzahlin(array_keys($alle_mandanten_dealer),$sql_tabs['stammdaten']['vpb']).' or '.$db->dbzahlin(array_keys($alle_mandanten_dealer),$sql_tabs['stammdaten']['mandant']).') and ';
	}*/
    
    if ($postfeld['form_kunde_anrede']!='') {
        //$stdwhere.=feldbed_s($sql_tabs['stammdaten']['anrede'], $db->str('%'.$postfeld['form_kunde_anrede'].'%')).' and ';
    }

    $ids = '';
    $where1so = '';
    if ($postfeld['ort'] != '') {
        $where1so.=feldbed_s($sql_tabs['stammdaten_adresse']['ort'], $db->str(bdcSearchReplace($postfeld['ort'] . '%'))) . ' and ';
    }
    if ($postfeld['adresse'] != '') {
        $where1so.=feldbed_s($sql_tabs['stammdaten_adresse']['adresse'], $db->str(bdcSearchReplace($postfeld['adresse'] . '%'))) . ' and ';
    }
    if ($postfeld['plz'] != '') {
        $where1so.=$sql_tabs['stammdaten_adresse']['plz'] . ' like ' . $db->str(bdcSearchReplace($postfeld['plz'] . '%')) . ' and ';
    }
    if ($where1so != '') {
        $where1so = p4n_mb_string('substr', $where1so, 0, -5);
        /*$res = $db->select(
                $sql_tab['stammdaten_adresse'], $sql_tabs['stammdaten_adresse']['stammdaten_id'], $where1so
        );
        while ($row = $db->zeile($res)) {
            $ids.=$row[0] . ',';
        }
        if ($ids != '') {
        $ids = p4n_mb_string('substr', $ids, 0, -1);
        }*/
        //$stdwhere.=  ' ' . $db->dbzahlin($ids,$sql_tabs['stammdaten']['id']) . ' and ';
        $stdwhere.=  ' ('.$sql_tabs['stammdaten']['id'].' in (select '.$sql_tabs['stammdaten_adresse']['stammdaten_id'].' from '.$sql_tab['stammdaten_adresse'].' where '.$where1so.')) and ';
    }
    
    $kfzth='';
    $merke_kennzeichen_stdid = $merke_produkt_daten = array();
    $kfzids = '';
    $kfzapids = '';
    if ($postfeld['form_kunde_kennzeichen']!='' || $postfeld['form_kunde_modell']!='' || $postfeld['form_kunde_kmstand']!='' || $postfeld['form_kunde_erstzulassung']!='' || $postfeld['form_kunde_fahrgestell']!='') {
        $kfz_where_suche = '';
        $wh2 = sql_gruppe($sql_tabs['stammdaten']['id']);
        if ($wh2 != '') {
            $kfz_where_suche = $wh2 . ' and ';
        }
        $fromtabs_suche = array(
            $sql_tab['produktzuordnung'],
            $sql_tab['stammdaten'],
        );
        $joins_suche = array(
                $sql_tabs['produktzuordnung']['stammdaten_id'] => $sql_tabs['stammdaten']['id'],
        );
        if (preg_match('/' . $sql_tab['stammdaten_gruppe_zuordnung'] . '/Uis', $kfz_where_suche)) {
            $fromtabs_suche[] = $sql_tab['stammdaten_gruppe_zuordnung'];
            $joins_suche[$sql_tabs['stammdaten']['id']] = $sql_tabs['stammdaten_gruppe_zuordnung']['stammdaten_id'];
        }
    
        $kfz_where_kennzeichen='';
        if ($postfeld['form_kunde_kennzeichen']!='') {
          //  $kfz_where_kennzeichen.='(' . $sql_tabs['produktzuordnung']['kennzeichen'] . ' like ' . $db->str(bdcSearchReplace($postfeld['form_kunde_kennzeichen'] . '%')) . ') and ';
            
			$zus_kzs='';
			if ($cfg_kfzsuche_holland) {
				$zus_kzs.='REPLACE('.$sql_tabs['produktzuordnung']['kennzeichen'].', '.$db->str('-').', '.$db->str('').') like '.$db->str($postfeld['form_kunde_kennzeichen'].'%').' or ';
				$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($postfeld['form_kunde_kennzeichen'], 0, 2).'%'.substr($postfeld['form_kunde_kennzeichen'], 2, 2).'%'.substr($postfeld['form_kunde_kennzeichen'], 4, 2).'%').' or ';
				$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($postfeld['form_kunde_kennzeichen'], 0, 2).'%'.substr($postfeld['form_kunde_kennzeichen'], 2, 3).'%'.substr($postfeld['form_kunde_kennzeichen'], 5, 1).'%').' or ';
			}
			if ($cfg_suche_kennzeichenmehr) {
			$kfzsw=str_replace(array('-', ' '), '', $postfeld['form_kunde_kennzeichen']);
			if (preg_match('/([\s\w\-]+)(\d+)$/Uis', $kfzsw, $ma)) {
				$kbuchst=$ma[1];
				$kzahlen=$ma[2];
				if ($kbuchst!='' and $kzahlen!='') {
					if (strlen($kbuchst)==1) {
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str($kbuchst.'_'.$kzahlen.'%').' or ';
					} elseif (strlen($kbuchst)==2) {
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'_'.substr($kbuchst, 1, 1).'_'.$kzahlen.'%').' or ';
					} elseif (strlen($kbuchst)==3) {
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'_'.substr($kbuchst, 1, 2).'_'.$kzahlen.'%').' or ';
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 2).'_'.substr($kbuchst, 2, 1).'_'.$kzahlen.'%').' or ';
					} elseif (strlen($kbuchst)==4) {
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'_'.substr($kbuchst, 1, 3).'_'.$kzahlen.'%').' or ';
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 2).'_'.substr($kbuchst, 2, 2).'_'.$kzahlen.'%').' or ';
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 3).'_'.substr($kbuchst, 3, 1).'_'.$kzahlen.'%').' or ';
					} elseif (strlen($kbuchst)==5) {
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 3).'_'.substr($kbuchst, 3, 2).'_'.$kzahlen.'%').' or ';
					}
					if (strlen($kbuchst)==1) {
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str($kbuchst.''.$kzahlen.'%').' or ';
					} elseif (strlen($kbuchst)==2) {
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'_'.substr($kbuchst, 1, 1).''.$kzahlen.'%').' or ';
					} elseif (strlen($kbuchst)==3) {
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'_'.substr($kbuchst, 1, 2).''.$kzahlen.'%').' or ';
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 2).'_'.substr($kbuchst, 2, 1).''.$kzahlen.'%').' or ';
					} elseif (strlen($kbuchst)==4) {
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'_'.substr($kbuchst, 1, 3).''.$kzahlen.'%').' or ';
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 2).'_'.substr($kbuchst, 2, 2).''.$kzahlen.'%').' or ';
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 3).'_'.substr($kbuchst, 3, 1).''.$kzahlen.'%').' or ';
					} elseif (strlen($kbuchst)==5) {
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 3).'_'.substr($kbuchst, 3, 2).''.$kzahlen.'%').' or ';
					}
				}
			} elseif (preg_match('/([\s\w\-]+)$/Uis', $kfzsw, $ma)) {
				$kbuchst=$ma[1];
				if ($kbuchst!='') {
					if (strlen($kbuchst)==4) {
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 1).'_'.substr($kbuchst, 1, 3).'%').' or ';
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 2).'_'.substr($kbuchst, 2, 2).'%').' or ';
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 3).'_'.substr($kbuchst, 3, 1).'%').' or ';
					} elseif (strlen($kbuchst)==5) {
						$zus_kzs.=$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str(substr($kbuchst, 0, 3).'_'.substr($kbuchst, 3, 2).'%').' or ';
					}
				}
			}
			}
			if ($postfeld['form_kunde_kennzeichen']!='') {
				$pkz2=$postfeld['form_kunde_kennzeichen'];
				$pkz2=str_replace(' ', '%', $pkz2);
				$pkz2=str_replace('-', '%', $pkz2);
				$kfz_where_kennzeichen.='('.$zus_kzs.$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str($postfeld['form_kunde_kennzeichen'].'%').($pkz2!=$postfeld['form_kunde_kennzeichen']?' or '.$sql_tabs['produktzuordnung']['kennzeichen'].' like '.$db->str($pkz2.'%'):'').') and ';
			}
        }
        if ($postfeld['form_kunde_fahrgestell']!='') {
            $kfz_where_kennzeichen.=$sql_tabs['produktzuordnung']['fahrgestell'] . ' like ' . $db->str(bdcSearchReplace('%'.$postfeld['form_kunde_fahrgestell'].'%')) . ' and ';
        }
        if ($postfeld['form_kunde_modell']!='') {
            if ($cfg_cross) {
                $kfz_where_kennzeichen.=' ( '.$sql_tabs['produktzuordnung']['typ_modell'] . ' like ' . $db->str(bdcSearchReplace('%'.$postfeld['form_kunde_modell'].'%')) . ' or ';
                $kfz_where_kennzeichen.=$sql_tabs['produktzuordnung']['typ'] . ' like ' . $db->str(bdcSearchReplace('%'.$postfeld['form_kunde_modell'].'%')) . ') and ';
            } else {
                $kfz_where_kennzeichen.=$sql_tabs['produktzuordnung']['typ_modell'] . ' like ' . $db->str(bdcSearchReplace('%'.$postfeld['form_kunde_modell'].'%')) . ' and ';
            }
            
        }
        if ($postfeld['form_kunde_kmstand']!='') {
            $kfz_where_kennzeichen.=$sql_tabs['produktzuordnung']['km_stand'] . ' = ' . $db->dbzahl($postfeld['form_kunde_kmstand']) . ' and ';
        }
        if ($postfeld['form_kunde_erstzulassung']!='') {
            $kfz_where_kennzeichen.=$sql_tabs['produktzuordnung']['datum_ez'] . ' = ' . $db->dbdate($postfeld['form_kunde_erstzulassung']) . ' and ';
        }
        if ($kfz_where_kennzeichen!='') {
            $kfz_where_kennzeichen = p4n_mb_string('substr', $kfz_where_kennzeichen, 0, -5);
        }

        $res = $db->select(
                $fromtabs_suche, array(
            'distinct '.$sql_tabs['produktzuordnung']['produktzuordnung_id'], //0
            $sql_tabs['produktzuordnung']['stammdaten_id'], //1
            $sql_tabs['produktzuordnung']['kennzeichen'], //2
            $sql_tabs['produktzuordnung']['fahrgestell'], //3
            $sql_tabs['produktzuordnung']['typ_modell'], //4
            $sql_tabs['produktzuordnung']['datum_ez'], //5
            $sql_tabs['produktzuordnung']['km_stand'], //6
            $sql_tabs['produktzuordnung']['ansprechpartner_id'],//7
                $sql_tabs['produktzuordnung']['typ']//8
                ), $stdwhere.$kfz_where_suche.$kfz_where_kennzeichen, $sql_tabs['produktzuordnung']['kennzeichen'],
            '',
            $joins_suche
        );

        while ($row = $db->zeile($res)) {
            if ($row[1] != '') {
                $kfzids.=$row[1] . ',';
                $merke_produkt_daten[$row[1]]=array($row[2],$row[4],$db->unixdate($row[5]),$row[6],$row[8],$row[3]);
                $merke_kennzeichen_stdid[$row[1]] = '<td class="td">' . $row[3] . '</td><td class="td">' . $row[2] . '</td><td class="td">' . link2(trim($row[4].($cfg_cross? ' '.$row[8]:'')), 'stammdaten_main.php?nav=Fahrzeuge&pnr=' . $row[0] . '&id=' . $row[1]) . '</td><td class="td">' . $db->unixdate($row[5]) . '</td><td class="td">' . $row[6] . '</td>';
            }
        }
        if ($kfzids != '') {
            $kfzth = '<th class="th">' . _FAHRGESTELL_ . '</th><th class="th">' . $lang['_PZ-KENNZEICHEN_'] . '</th><th class="th">' . _TYP_ . '</th><th class="th">' . $lang['_PZ-ERSTZULASSUNG_'] . '</th><th class="th">' . _KMSTAND_ . '</th>';// echo '<br>3: '.$kfz_where.'<br>';
            $kfzids = p4n_mb_string('substr', $kfzids, 0, -1);
        }
        $stdwhere.= ' ' . $db->dbzahlin($kfzids,$sql_tabs['stammdaten']['id']) . ' and ';
    }
    
    
    if ($stdwhere!='') {
        $stdwhere=p4n_mb_string('substr',$stdwhere,0,-5);
    }
    
    
    
    if ($apids>0 || $postfeld['form_kunde_firma']!='') {
        $apth='<th class="th">'._ANSPRECHPARTNER_.'</th>';
    }


    $ausgabe='
        <table class="hori2 moderntable table-margin-bottom table-ignore2">
        <tr class="even">
        <th class="th">' . _LAGERORT_ . '</th>
        <th class="th">' . _KUNDE_ . '</th>
        <th class="th">' . _ADRESSE_ . '</th>
        <th class="th">' . _TELEFON_ . '</th>
        <th class="th">' . _EMAIL_ . '</th>' . $apth.$kfzth. '
        <th class="th">' . _UEBERNEHMEN_ . '</th></tr>
        </tr>
    ';
    
    if ($mitstidsu and $stids!='') {
		$stdwhere=$db->dbzahlin($stids, $sql_tabs['stammdaten']['id']);
	}
    
    $anz=0;
    $res = $db->select(
            $fromtabs, array(
        'distinct ' . $sql_tabs['stammdaten']['id'], //0
        $sql_tabs['stammdaten']['anzeigename'], //1
        $sql_tabs['stammdaten']['Telefon_1'], //2
        $sql_tabs['stammdaten']['Telefon_2'], //3
        $sql_tabs['stammdaten']['Mobilfon_1'], //4
        $sql_tabs['stammdaten']['Mobilfon_2'], // 5
        $sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'vpb' :  'mandant'], //6
        $sql_tabs['stammdaten']['matchcode'], //7
        $sql_tabs['stammdaten']['meinvpb'], //8
        $sql_tabs['stammdaten']['abteilung'], //9
        $sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'mandant' : 'vpb'],   // 10
        $sql_tabs['stammdaten']['vorname'],   // 11
        $sql_tabs['stammdaten']['name'],   // 12
        $sql_tabs['stammdaten']['firma1'],   // 13
        $sql_tabs['stammdaten']['anrede'],   // 14
        $sql_tabs['stammdaten']['titel'],   // 15
        $sql_tabs['stammdaten']['EMail_1'],   // 16
        $sql_tabs['stammdaten']['EMail_2'],   // 17
        $sql_tabs['stammdaten']['firma2'],   // 18
        $sql_tabs['stammdaten']['firma3'],   // 19
        $sql_tabs['stammdaten']['bemerkung'],   // 20
            ), $stdwhere, $sql_tabs['stammdaten']['id'], '', $joins,500
    );
    while ($row=$db->zeile($res)) {
        $tel = '';
        if ($row[2] != '') {
            $tel.=$row[2] . ',<br>';
        }
        if ($row[3] != '') {
            $tel.=$row[3] . ',<br>';
        }
        if ($row[4] != '') {
            $tel.=$row[4] . ',<br>';
        }
        if ($row[5] != '') {
            $tel.=$row[5] . ',<br>';
        }
        $tel = p4n_mb_string('substr', $tel, 0, -5);
        
        $mail='';
        if ($row[16] != '') {
            $mail.=$row[16] . ',<br>';
        }
        if ($row[17] != '') {
            $mail.=$row[17] . ',<br>';
        }
        $mail = p4n_mb_string('substr', $mail, 0, -5);
        
        $res2 = $db->select(
                $sql_tab['stammdaten_adresse'], array(
            $sql_tabs['stammdaten_adresse']['adresse'], //0
            $sql_tabs['stammdaten_adresse']['plz'], //1
            $sql_tabs['stammdaten_adresse']['ort'], //2
            $sql_tabs['stammdaten_adresse']['zusatz1'], //3
            $sql_tabs['stammdaten_adresse']['zusatz2'], //4
            $sql_tabs['stammdaten_adresse']['sync_id'], //5
            $sql_tabs['stammdaten_adresse']['kategorie']//6
                ), $sql_tabs['stammdaten_adresse']['stammdaten_id'] . '=' . $db->dbzahl($row[0])
        );
        $row2 = $db->zeile($res2);
        
        $p='form_kunde_';
        $temp=array();
        $temp[$p.'st_bemerkung']=$row[20].' '.$postfeld[$p.'st_bemerkung'];
        $temp[$p.'anrede']=$row[14];
        $temp[$p.'titel']=$row[15];
        $temp[$p.'stdid']=$row[0];
        
        if ($cfg_kfzsuche_holland and $row[19]!='') {
            if (p4n_mb_string('substr',$row[11], -p4n_mb_string('strlen',$row[19]))==$row[19]) {
                $row[11]=trim(p4n_mb_string('substr',$row[11], 0, -p4n_mb_string('strlen',$row[19])));
            }
        }
        
        $temp[$p.'vorname']=$row[11];
        $temp[$p.'name']=$row[12];
        
        if ($cfg_bdc_nl) {
            $temp[$p.'mittelname']=$row[19];
            $temp[$p.'rufname']=$row[18];
        }
        
        $temp[$p.'firma']=$row[13];
        $temp['plz']=$row2[1];
        $temp['ort']=$row2[2];
        $temp['adresse']=$row2[0];
        $temp[$p.'standort']=$row[10];
        if ($row[10]==0) {
            $temp[$p.'standort']=$row[6];
        }
        
        $temp[$p.'telefon_privat']=$row[2];
        $temp[$p.'mobil_privat']=$row[4];
        $temp[$p.'telefon_ges']=$row[3];
        $temp[$p.'mobil_ges']=$row[5];
        $temp[$p.'email_ges']=$row[17];
        $temp[$p.'email_privat']=$row[16];
        
        if (!empty($merke_produkt_daten[$row[0]]) && count($merke_produkt_daten[$row[0]]) > 0) {
            $temp[$p.'kennzeichen']=$merke_produkt_daten[$row[0]][0];
            $temp[$p.'modell']=$merke_produkt_daten[$row[0]][1];
            $temp[$p.'erstzulassung']=$merke_produkt_daten[$row[0]][2];
            $temp[$p.'kmstand']=$merke_produkt_daten[$row[0]][3];
            $temp[$p.'typ']=$merke_produkt_daten[$row[0]][4];
            $temp[$p.'fahrgestell']=$merke_produkt_daten[$row[0]][5];
        }
        
        if (isset($postfeld['bdcPoolSearch'])) {
            $temp['bdcPoolSearch']=$postfeld['bdcPoolSearch'];
        }
        
        $temp_string=  base64_encode(serialize($temp));
        
        $zusatzkennzeichen = ($kfzids != '') ? $merke_kennzeichen_stdid[$row[0]] : '';
        if ($zusatzkennzeichen=='' && $kfzids != '') {
            $zusatzkennzeichen='<td class="td"></td><td class="td"></td><td class="td"></td><td class="td"></td>';
        }
        
        
        if ($apids>0 || $postfeld['form_kunde_firma']!='') {
            $aphtml='<td class="td"></td>';
        }
        
        
        $form=new htmlform();
        $tdclass=(($anz%2)==0?'odd':'even');

        if (($mitstidsu and !isset($merke_aps[$row[0]])) or ($apids==0 && !isset($postfeld['nurap']))) {
            
            $name=$row[1];
            if ($cfg_bdc_nl) {
                $name='';
                if ($row[11]!='') {
                    $name=$row[11].', ';
                }
                if ($row[19]!='') {
                    $name.=$row[19].', ';
                }
                if ($row[12]!='') {
                    $name.=$row[12].', ';
                }
                if ($row[18]!='') {
                    $name.=$row[18].', ';
                }
                if ($name!='') {
                    $name=substr($name,0,-2);
                }
            }
            $ausgabe.='<tr ' . tr_zeile() . ' class="'.$tdclass.'"><td class="td">' . $get_mandanten2[4][$temp[$p.'standort']] . '</td><td class="td">' . link2($name, 'stammdaten_main.php?nav=Uebersicht&id=' . $row[0],'','','onMouseOver=""') . '</td><td class="td">' . $row2[0] . '<br>' . $row2[1] . ' ' . $row2[2] . '</td><td  class="td">' . $tel . '</td>'.'<td class="td">'.$mail.'</td>' . $aphtml. $zusatzkennzeichen . '<td  class="td">' . 
                $form->start('','bdc.php'.(isset($postfeld['bdcPoolSearch'])?'?options_menu=0&options_padding=0':''),'POST').
                $form->hidden('form_kunde_suche_erg',$temp_string).
                $form->hidden('eva',$_GET['eva']).
				(isset($_GET['null_ign'])?$form->hidden('null_ign',$_GET['null_ign']):'').
                $form->hidden('ohnecc',$_GET['ohnecc']).(!isset($_GET['cti_fremd_id'])?'':$form->hidden('cti_fremd_id',$_GET['cti_fremd_id'])).(!isset($_GET['startSetting'])?'':$form->hidden('startSetting',$_GET['startSetting'])).
                $form->submit('', _UEBERNEHMEN_).
                $form->ende()
                    . '</td></tr>';
        }
        $anz++;
        
        $ap_suche=0;
        if ($apids==0 && ($postfeld['form_kunde_firma']!='')) {
            $merke_ap_bez = $merke_aps= array();
           // $apids=0;
            $res_ap = $db->select(
            $sql_tab['stammdaten_ansprechpartner'], array(
                $sql_tabs['stammdaten_ansprechpartner']['ansprechpartner_id'], //0
                $sql_tabs['stammdaten_ansprechpartner']['vorname'], //1
                $sql_tabs['stammdaten_ansprechpartner']['bezeichnung'], //2
                $sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'], //3
                $sql_tabs['stammdaten_ansprechpartner']['adresse'], //4
                $sql_tabs['stammdaten_ansprechpartner']['plz'], //5
                $sql_tabs['stammdaten_ansprechpartner']['ort'], //6
                $sql_tabs['stammdaten_ansprechpartner']['email'], //7
                $sql_tabs['stammdaten_ansprechpartner']['telefon'], //8
                $sql_tabs['stammdaten_ansprechpartner']['mobil'], //9
                $sql_tabs['stammdaten_ansprechpartner']['anrede'], //10
                $sql_tabs['stammdaten_ansprechpartner']['titel'], //11
                $sql_tabs['stammdaten_ansprechpartner']['zusatz4'], //12
                $sql_tabs['stammdaten_ansprechpartner']['zusatz5'], //13
                
            ), $sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'] . ' = ' . $db->dbzahl($row[0])
            );
            while ($row_ap=$db->zeile($res_ap)) {
                $apbez='';
                $titel='';
                if ($row_ap[10]!='') {
                    $titel.=$row_ap[10].' ';
                }
                if ($row_ap[11]!='') {
                    $titel.=$row_ap[11].' ';
                }
                if ($titel!='') {
                    $titel=substr($titel,0,-1).' ';
                }
                if ($row_ap[1]!='' && $row_ap[2]!='') {
                    $apbez=$row_ap[2].', '.$row_ap[1];
                }
                if ($row_ap[1]!='' && $row_ap[2]=='') {
                    $apbez=$row_ap[1];
                }
                if ($row_ap[1]=='' && $row_ap[2]!='') {
                    $apbez=$row_ap[2];
                }
                
                if ($cfg_bdc_nl) {
                    $apbez='';
                    if ($row_ap[1]!='') {
                        $apbez.=$row_ap[1].', ';
                    }
                    if ($row_ap[12]!='') {
                        $apbez.=$row_ap[12].', ';
                    }
                    if ($row_ap[2]!='') {
                        $apbez.=$row_ap[2].', ';
                    }
                    if ($row_ap[13]!='') {
                        $apbez.=$row_ap[13].', ';
                    }
                    if ($apbez!='') {
                        $apbez=substr($apbez,0,-2);
                    }
                }
                
                //$ids.=$row_ap[3].',';
                $merke_ap_bez[$row_ap[0]]=array('bez'=>$apbez, 'bezeichnung'=>$row_ap[2], 'vorname'=>$row_ap[1], 'email'=>$row_ap[7], 'telefon'=>$row_ap[8], 'mobil'=>$row_ap[9]);
                $merke_ap_bez[$row_ap[0]]['anrede']=$row_ap[10];
                $merke_ap_bez[$row_ap[0]]['titel']=$row_ap[11];
                if ($cfg_bdc_nl) {
                    $merke_ap_bez[$row_ap[0]]['mittelname']=$row_ap[12];
                    $merke_ap_bez[$row_ap[0]]['rufname']=$row_ap[13];
                }
                $merke_aps[$row_ap[3]][$row_ap[0]]='<td class="td" style="font-size:11px;"><b>'.$titel.$apbez.'</b><br>'.($row_ap[4]!=''?$row_ap[4].'<br>':'').($row_ap[5]!=''?$row_ap[5].' ':'').$row_ap[6].($row_ap[5]!=''||$row_ap[6]!=''?'<br>':'').($row_ap[7]!=''?$row_ap[7].'<br>':'').($row_ap[8]!=''?$row_ap[8].'<br>':'').($row_ap[9]!=''?$row_ap[9].'<br>':'').'</td>';
              //  $apids++;
            }
        }
        if (!empty($merke_aps[$row[0]]) && count($merke_aps[$row[0]])>0) {
            if ($kfzids != '') {
                $zusatzkennzeichen='<td class="td"></td><td class="td"></td><td class="td"></td><td class="td"></td>';
            }
            foreach($merke_aps[$row[0]] as $apid => $aphtml) {
                $ap_suche++;
                $temp[$p.'ap_bezeichnung']=$merke_ap_bez[$apid]['bezeichnung'];
                $temp[$p.'ap_vorname']=$merke_ap_bez[$apid]['vorname'];
                $temp[$p.'ap_telefon']=$merke_ap_bez[$apid]['telefon'];
                $temp[$p.'ap_mobil']=$merke_ap_bez[$apid]['mobil'];
                $temp[$p.'ap_email']=$merke_ap_bez[$apid]['email'];
                $temp[$p.'ap_anrede']=$merke_ap_bez[$apid]['anrede'];
                $temp[$p.'ap_titel']=$merke_ap_bez[$apid]['titel'];
                if ($cfg_bdc_nl) {
                    $temp[$p.'ap_mittelname']=$merke_ap_bez[$apid]['mittelname'];
                    $temp[$p.'ap_rufname']=$merke_ap_bez[$apid]['rufname'];
                }
                
                $temp[$p.'ansprechpartner_id']=$apid;
                $temp_string=  base64_encode(serialize($temp));

                $ausgabe.='<tr ' . tr_zeile() . ' class="'.$tdclass.'"><td class="td">' . $get_mandanten2[4][$temp[$p.'standort']] . '</td><td class="td">' . link2($row[1], 'stammdaten_main.php?nav=Uebersicht&id=' . $row[0],'','','onMouseOver=""') . '</td><td class="td">' . $row2[0] . '<br>' . $row2[1] . ' ' . $row2[2] . '</td><td  class="td">' . $tel . '</td><td  class="td">' . $mail . '</td>' . $aphtml .$zusatzkennzeichen. '<td  class="td">' . 
                $form->start('','bdc.php'.(isset($postfeld['bdcPoolSearch'])?'?options_menu=0&options_padding=0':''),'POST').
                $form->hidden('form_kunde_suche_erg',$temp_string).
                $form->hidden('eva',$_GET['eva']).
				(isset($_GET['null_ign'])?$form->hidden('null_ign',$_GET['null_ign']):'').
                $form->hidden('ohnecc',$_GET['ohnecc']).(!isset($_GET['cti_fremd_id'])?'':$form->hidden('cti_fremd_id',$_GET['cti_fremd_id'])).(!isset($_GET['startSetting'])?'':$form->hidden('startSetting',$_GET['startSetting'])).
                $form->submit('', _UEBERNEHMEN_).
                $form->ende()
                    . '</td></tr>';
            }
        }
        
    }
    $ausgabe.='</table>';
    
    if (isset($postfeld['nurap']) && $ap_suche==0) {
        echo '';
        exit;
    }
    $extraAusgabe='';
    if ($cfg_bdc_neuanlage_dms_rueck && ($cfg_f1allg_rueck || $cfg_vx_rueck || $cfg_attribut_rueck|| $cfg_loco_rueck || $cfg_md_rueck || $cfg_ecaros_rueck || $cfg_betzemeier_rueck)) {
        $extraAusgabe='<br>'.$form->checkinput('vaudixVersand',false, 'id="vaudixVersand"')._DMS_UEBERTRAGUNG_;
    }
    if ($anz>0) {
        echo $ausgabe.$extraAusgabe;
    } else {
        $ausgabe='<table class=" table-irgnore2 table-nostyle" style="width:260px; height:80px;"><tr><td><b>'._LS_ERGEBNISLOS_.'</b></td></tr></table>'.$extraAusgabe;
        echo $ausgabe;
    }
    if (!isset($getfeld['suche'])) {
        Modern_Helper_Request::requestFlush();
        exit;
    }
}


if (isset($getfeld['stid']) && intval($getfeld['stid'])>0) {
    
    $res = $db->select(
            $sql_tab['stammdaten'], array(
        $sql_tabs['stammdaten']['id'], //0
        $sql_tabs['stammdaten']['anzeigename'], //1
        $sql_tabs['stammdaten']['Telefon_1'], //2
        $sql_tabs['stammdaten']['Telefon_2'], //3
        $sql_tabs['stammdaten']['Mobilfon_1'], //4
        $sql_tabs['stammdaten']['Mobilfon_2'], // 5
        $sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'vpb' :  'mandant'], //6
        $sql_tabs['stammdaten']['matchcode'], //7
        $sql_tabs['stammdaten']['meinvpb'], //8
        $sql_tabs['stammdaten']['abteilung'], //9
        $sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'mandant' : 'vpb'],   // 10
        $sql_tabs['stammdaten']['vorname'],   // 11
        $sql_tabs['stammdaten']['name'],   // 12
        $sql_tabs['stammdaten']['firma1'],   // 13
        $sql_tabs['stammdaten']['anrede'],   // 14
        $sql_tabs['stammdaten']['titel'],   // 15
        $sql_tabs['stammdaten']['EMail_1'],   // 16
        $sql_tabs['stammdaten']['EMail_2'],   // 17
        $sql_tabs['stammdaten']['firma2'],   // 18
        $sql_tabs['stammdaten']['firma3'],   // 19
        $sql_tabs['stammdaten']['bemerkung'],   // 20   
        $sql_tabs['stammdaten']['geburtstag'] //21
            ), $sql_tabs['stammdaten']['id'].' = '.$db->dbzahl($getfeld['stid'])
    );
    $postfeld['form_kunde_standort']=-1;
    if ($row=$db->zeile($res)) {
        $res2 = $db->select(
                $sql_tab['stammdaten_adresse'], array(
            $sql_tabs['stammdaten_adresse']['adresse'], //0
            $sql_tabs['stammdaten_adresse']['plz'], //1
            $sql_tabs['stammdaten_adresse']['ort'], //2
            $sql_tabs['stammdaten_adresse']['zusatz1'], //3
            $sql_tabs['stammdaten_adresse']['zusatz2'], //4
            $sql_tabs['stammdaten_adresse']['sync_id'], //5
            $sql_tabs['stammdaten_adresse']['kategorie']//6
                ), $sql_tabs['stammdaten_adresse']['stammdaten_id'] . '=' . $db->dbzahl($row[0])
        );
        $row2 = $db->zeile($res2);
        
        $p='form_kunde_';
        $postfeld[$p.'st_bemerkung']=$row[20];
        $postfeld[$p.'anrede']=$row[14];
        $postfeld[$p.'titel']=$row[15];
        $postfeld[$p.'stdid']=$row[0];
        if ($cfg_kfzsuche_holland and $row[19]!='') {
            if (p4n_mb_string('substr',$row[11], -p4n_mb_string('strlen',$row[19]))==$row[19]) {
                $row[11]=trim(p4n_mb_string('substr',$row[11], 0, -p4n_mb_string('strlen',$row[19])));
            }
        }
        $postfeld[$p.'vorname']=$row[11];
        $postfeld[$p.'name']=$row[12];
        if ($cfg_bdc_nl) {
            $postfeld[$p.'mittelname']=$row[19];
            $postfeld[$p.'rufname']=$row[18];
        }
        $postfeld[$p.'firma']=$row[13];
        $postfeld['plz']=$row2[1];
        $postfeld['ort']=$row2[2];
        $postfeld['adresse']=$row2[0];
        $postfeld[$p.'standort']=$row[10];
        
        if ($row[10]==0) {
            $postfeld[$p.'standort']=$row[6];
        }
        
        $postfeld[$p.'telefon_privat']=$row[2];
        $postfeld[$p.'mobil_privat']=$row[4];
        $postfeld[$p.'telefon_ges']=$row[3];
        $postfeld[$p.'mobil_ges']=$row[5];
        $postfeld[$p.'email_privat']=$row[16];
        $postfeld[$p.'email_ges']=$row[17]; 
        $postfeld[$p.'geburtstag']=$row[21]; 
    }
}

if ($_SESSION['crm_version']<=68) {
    unset($getfeld['apid']);
    unset($getfeld['pnr']);
}

if (isset($getfeld['apid']) && intval($getfeld['apid'])>0) {
    $res = $db->select(
            $sql_tab['stammdaten_ansprechpartner'], array(
        $sql_tabs['stammdaten_ansprechpartner']['ansprechpartner_id'], //0
        $sql_tabs['stammdaten_ansprechpartner']['anrede'], //1
        $sql_tabs['stammdaten_ansprechpartner']['titel'], //2
        $sql_tabs['stammdaten_ansprechpartner']['bezeichnung'], //3
        $sql_tabs['stammdaten_ansprechpartner']['vorname'], //4
        $sql_tabs['stammdaten_ansprechpartner']['telefon'], // 5
        $sql_tabs['stammdaten_ansprechpartner']['mobil'], //6
        $sql_tabs['stammdaten_ansprechpartner']['email'] //7
            ), $sql_tabs['stammdaten_ansprechpartner']['ansprechpartner_id'].' = '.$db->dbzahl($getfeld['apid'])
    );

    if ($row=$db->zeile($res)) {
        $p='form_kunde_ap_';
        $postfeld['form_kunde_ansprechpartner_id']=$row[0];
        $getfeld['form_kunde_ansprechpartner_id']=$row[0];
        $postfeld[$p.'anrede']=$row[1];
        $postfeld[$p.'titel']=$row[2];
        $postfeld[$p.'bezeichnung']=$row[3];
        $postfeld[$p.'vorname']=$row[4];
        $postfeld[$p.'telefon']=$row[5];
        $postfeld[$p.'mobil']=$row[6];
        $postfeld[$p.'email']=$row[7];
    }
}

if (isset($getfeld['pnr']) && intval($getfeld['pnr'])>0) {
    $res=$db->select(
        $sql_tab['produktzuordnung'],
        array(
            $sql_tabs['produktzuordnung']['produktzuordnung_id'],
            $sql_tabs['produktzuordnung']['kennzeichen'],
            $sql_tabs['produktzuordnung']['fahrgestell'],
            $sql_tabs['produktzuordnung']['typ_modell'],
            $sql_tabs['produktzuordnung']['datum_ez'],		
            $sql_tabs['produktzuordnung']['km_stand'],
            $sql_tabs['produktzuordnung']['produkt_id'],
            $sql_tabs['produktzuordnung']['typ'],
            $sql_tabs['produktzuordnung']['letzter_besuch'],
            $sql_tabs['produktzuordnung']['ansprechpartner_id']
        ),
        $sql_tabs['produktzuordnung']['produktzuordnung_id'].'='.$db->dbzahl($getfeld['pnr']),
        $sql_tabs['produktzuordnung']['kennzeichen']
    );
    if ($row=$db->zeile($res)) {
        $p='form_kunde_';
        $postfeld[$p.'modell']=$row[3];
        $postfeld[$p.'erstzulassung']=$db->unixdate($row[4]);
        $postfeld[$p.'kmstand']=$row[5];
        $postfeld[$p.'kennzeichen']=$row[1];
        $postfeld[$p.'fahrgestell']=$row[2];
    }
}
$produkt=array();
$rechnungslink=array();
$ap_feld=array();


if (intval($postfeld['form_kunde_stdid'])===0) {
    unset($postfeld['form_kunde_stdid']);
}


if (isset($postfeld['form_kunde_stdid'])) {
    //Modern_Helper_Encoding::getHeader();
    if (!$_SESSION['design_70'])
    $_SESSION['stammdaten_id']=$postfeld['form_kunde_stdid'];

    $benutzer_selected=$user_id;
    $res = $db->select(
            $sql_tab['stammdaten'], array(
        $sql_tabs['stammdaten']['betreuer']//0
            ), $sql_tabs['stammdaten']['id'] . '=' . $db->dbzahl($postfeld['form_kunde_stdid'])
    );
    if ($row = $db->zeile($res)) {
        $benutzer_selected=$row[0];
    }
    if (!$cfg_bdc_kundenbetreuer) {
        $benutzer_selected=-1;
    }
    
    
    $produkt=$sql_tabs['produktzuordnung']['stammdaten_id'] . '=' . $db->dbzahl($postfeld['form_kunde_stdid']);
    $res = $db->select(
            $sql_tab['produktzuordnung'], array(
        $sql_tabs['produktzuordnung']['produktzuordnung_id'],//0
        $sql_tabs['produktzuordnung']['stammdaten_id'],//1
        $sql_tabs['produktzuordnung']['kennzeichen'],//2
        $sql_tabs['produktzuordnung']['fahrgestell'],//3
        $sql_tabs['produktzuordnung']['typ_modell'],//4
        $sql_tabs['produktzuordnung']['datum_ez'],//5
        $sql_tabs['produktzuordnung']['km_stand'],//6
        $sql_tabs['produktzuordnung']['ansprechpartner_id'],//7
        $sql_tabs['produktzuordnung']['typ']     //8   
            ), $produkt, $sql_tabs['produktzuordnung']['kennzeichen']
    );
    $fahrzeuglink[-1] = '';
    $fahrzeuglink_selected=-1;
    
  
    //$ap_feld_selected=-1;    
    while ($row = $db->zeile($res)) {
        if ($postfeld['form_kunde_kennzeichen']!='' && $postfeld['form_kunde_kennzeichen']==$row[2]) {
            $fahrzeuglink_selected=$row[0];
            //if($row[7]>0) {
                //$ap_feld_selected=$row[7];
            //}
        }
       // $fahrzeuglink[$row[0]] = $row[2];
    }

    $res = $db->select(
            $sql_tab['auftrag'], array(
        $sql_tabs['auftrag']['nummer'],//0
        $sql_tabs['auftrag']['auftrag_id'],//1
        $sql_tabs['auftrag']['datum'],//2
        $sql_tabs['auftrag']['produktzuordnung_id']//3
            ), $sql_tabs['auftrag']['stammdaten_id'] . '=' . $db->dbzahl($postfeld['form_kunde_stdid']),
            $sql_tabs['auftrag']['auftrag_id']
    );
    $rechnungslink[-1] = '';
    $rechnungslink_selected=-1;
    while ($row = $db->zeile($res)) {
        //$date = explode(' ', $row[2]);
        //$date2 = explode('-', $date[0]);
       // $rechnungslink[$row[1]] = $date2[2] . '.' . $date2[1] . '.' . $date2[0] . ' / ' . $row[0];
        if ($fahrzeuglink_selected!=-1 && $row[3]==$fahrzeuglink_selected) {
            $rechnungslink_selected=$row[1];
        }
    }
    
    
    $alle_rech=array();
    $def_rech=-99;
    $res4=$db->select(
        $sql_tab['auftrag'],
        array(
            $sql_tabs['auftrag']['auftrag_id'],
            $sql_tabs['auftrag']['datum'],
            $sql_tabs['auftrag']['rechnung_id'],
            $sql_tabs['auftrag']['nummer'],
            $sql_tabs['auftrag']['betrag'],
            $sql_tabs['auftrag']['bereich'],
            $sql_tabs['auftrag']['mandant_id'],
            $sql_tabs['auftrag']['vp'],
        ),
        $sql_tabs['auftrag']['stammdaten_id'].'='.$db->dbzahl($postfeld['form_kunde_stdid']),
        $sql_tabs['auftrag']['datum'].' desc'
    );
    $anzre=0;
    $js_auf='';
    while ($anzre<100 and $row4=$db->zeile($res4)) {
        $def_ma1=0;
        if (intval($row4[7])>0) {
            $def_ma1=$row4[7];
        } elseif (intval($row4[6])>0) {
            $def_ma1=$row4[6];
        }
        if (intval($def_ma1)>0) {
            $js_auf.=' if (this.options[this.selectedIndex].value==\''.$row4[0].'\') { this.form.form_beschwerde_standort.value=\''.$def_ma1.'\'; } ';
            if ($rechnungslink_selected==$row4[0]) {
                $def_bmmand=$def_ma1;
            }
        }
        $rechnungslink[$row4[0]]=trim($db->unixdate($row4[1]).': '.$row4[2].'/'.$row4[3].'/'.p4n_mb_string('substr',$row4[5], 0, 2).'/'.number_format($row4[4], 2,",","."));
        $anzre++;
    }
    
    $fahrzeuglink=produktauswahl(0, $fahrzeuglink, false, $postfeld['form_kunde_stdid'], 0, false, $sql_tabs['produktzuordnung']['datum_ez'].' desc');
    

    // AP-Feld
    $res=$db->select(
        $sql_tab['stammdaten_ansprechpartner'],
        array(
            $sql_tabs['stammdaten_ansprechpartner']['ansprechpartner_id'],
            $sql_tabs['stammdaten_ansprechpartner']['bezeichnung'],
            $sql_tabs['stammdaten_ansprechpartner']['vorname'],
            $sql_tabs['stammdaten_ansprechpartner']['abteilung'],
            $sql_tabs['stammdaten_ansprechpartner']['email'],
            $sql_tabs['stammdaten_ansprechpartner']['telefon'],
            $sql_tabs['stammdaten_ansprechpartner']['mobil'],
            $sql_tabs['stammdaten_ansprechpartner']['ausblenden']
        ),
        $sql_tabs['stammdaten_ansprechpartner']['stammdaten_id'].'='.$db->dbzahl($postfeld['form_kunde_stdid'])
    );
    $ap_feld[-1] = '';
    $ap_feld2[-1000]=_ADMINBENUTZER_SUBMITNEU_;
    while ($row=$db->zeile($res)) {
        if (isset($_SESSION['design_70'])) {
            if (empty($row['ausblenden']) || $row['ausblenden'] === '0') {
                $ap_feld2[$row[0]]=trim($row[1].', '.$row[2]);
            }
        } else {
            $ap_feld2[$row[0]]=trim($row[1].', '.$row[2]);
        }
        $ap_feld[$row[0]]=trim($row[1].', '.$row[2]);
    }
    //if (isset($postfeld['form_kunde_stdid']) || $postfeld['form_kunde_stdid']!='' && $postfeld['form_kunde_stdid']!=0) {
        //unset($ap_feld2[-1000]);
    //}
    if (isset($_SESSION['design_70'])) {
        asort($ap_feld2);
    }
    $items=karten('',true);
    @reset($items);
    while (list($key, $val)=each($items)) {
        if (p4n_mb_string('strstr', $_SESSION['rechte_reiter'], $val)) {
            $zusinf.=link2($key, 'javascript: lade_message_leadanlage3(\'' . $val.'&bdcpopup=1&id=' . $postfeld['form_kunde_stdid'] . '\',\'' . $key . '\');') . ' | ';
        }
    }
    
    /*
    if (p4n_mb_string('strstr', $_SESSION['rechte_reiter'], "stammdaten_main.php?nav=Uebersicht")) {
        $zusinf.=link2(_KARTEI_UEBERSICHT_, 'javascript: lade_message_leadanlage3(\'' . 'stammdaten_main.php?id=' . $postfeld['form_kunde_stdid'] . '&nav=Uebersicht\',\'' . _KARTEI_STAMMDATEN_ . '\');') . ' | ';
    }
    if (p4n_mb_string('strstr', $_SESSION['rechte_reiter'], "stammdaten_main.php?nav=Uebersicht")) {
        $zusinf.=link2(_KARTEI_STAMMDATEN_, 'javascript: lade_message_leadanlage3(\'' . 'stammdaten_main.php?id=' . $postfeld['form_kunde_stdid'] . '&nav=Stammdaten\',\'' . _KARTEI_STAMMDATEN_ . '\');') . ' | ';
    }
    if (p4n_mb_string('strstr', $_SESSION['rechte_reiter'], "stammdaten_main.php?nav=Uebersicht")) {
        $zusinf.=link2(_KARTEI_FAHRZEUGE_, 'javascript: lade_message_leadanlage3(\'' . 'stammdaten_main.php?id=' . $postfeld['form_kunde_stdid'] . '&nav=Fahrzeuge&tabelle=1\',\'' . _KARTEI_FAHRZEUGE_ . '\');') . ' | ';
    }
    if (p4n_mb_string('strstr', $_SESSION['rechte_reiter'], "stammdaten_main.php?nav=Uebersicht")) {
        $zusinf.=link2(_KARTEI_AUFTRAEGE_, 'javascript: lade_message_leadanlage3(\'' . 'stammdaten_main.php?id=' . $postfeld['form_kunde_stdid'] . '&nav=Auftraege2\',\'' . _KARTEI_AUFTRAEGE_ . '\');') . ' | ';
    }
    if (p4n_mb_string('strstr', $_SESSION['rechte_reiter'], "stammdaten_main.php?nav=Uebersicht")) {
        $zusinf.=link2(_KARTEI_KORRESPONDENZ_, 'javascript: lade_message_leadanlage3(\'' . 'stammdaten_main.php?id=' . $postfeld['form_kunde_stdid'] . '&nav=Korrespondenz\',\'' . _KARTEI_KORRESPONDENZ_ . '\');') . ' | ';
    }
    if (p4n_mb_string('strstr', $_SESSION['rechte_reiter'], "stammdaten_main.php?nav=Uebersicht")) {
        $zusinf.=link2(_BESCHWERDEN_, 'javascript: lade_message_leadanlage3(\'' . 'stammdaten_main.php?id=' . $postfeld['form_kunde_stdid'] . '&nav=BM\',\'' . _BESCHWERDEN_ . '\');') . ' | ';
    }
    */
    if ($zusinf != '') {
        $zusinf = p4n_mb_string('substr', $zusinf, 0, -3);
    }
    
    //kanal -> kampagne_lead  channel
    //quelle -> kampagne_lead  source
    
}

$templ='template/bdc.html';
if ($cfg_bdc_nl) {
    $templ='template/bdc_nl.html';
}
if ($cfg_stammdaten_lead) {
    $templ='template/bdc_vgrd.html';
}
if (isset($cfg_bdc_template) && file_exists($cfg_bdc_template)) {
    $templ=$cfg_bdc_template;
}
if ($inhalt = template($templ)) {
    if (!empty($cfg_workshop_planner)) {
        $customerNumber = empty($_GET['stid']) ? $postfeld2['form_kunde_stdid'] : $_GET['stid'];

        # Get customer center (lagerort_text) and DMS customerId (fremdnummer, can vary).
        $dmsCustomerNumber = $suhl = $gotha = null;
        $result_stammdaten = $db->select(
            $sql_tab['stammdaten'],
            [
                $sql_tabs['stammdaten']['fremdnummer'],
                $sql_tabs['stammdaten']['lagerort_text']
            ],
            $sql_tabs['stammdaten']['id'].'='.$db->dbzahl($customerNumber)
        );
        if ($row_stammdaten = $db->zeile($result_stammdaten)) {
            $dmsCustomerNumber = $row_stammdaten['fremdnummer'];
            if (stripos($row_stammdaten['lagerort_text'], 'suhl') !== false) {
                $suhl = true;
            }
            if (stripos($row_stammdaten['lagerort_text'], 'gotha') !== false) {
                $gotha = true;
            }
        }

        # Break if no configured center was found. (Suhl / Gotha) TODO: AHG?
        if (empty($suhl) && empty($gotha)) {
            $inhalt = p4n_mb_string('str_replace', '{workshop_planner_new_case_btn}', 'The selected customer is not associated with a configured Center. (Suhl / Gotha)', $inhalt);
        } else {
            $customerVin = $postfeld2['form_kunde_fahrgestell'];

            # PHP5 compatibility.
            $trim_dmsCustomerNumber = trim($dmsCustomerNumber);
            if (empty($trim_dmsCustomerNumber)) {
                $dmsCustomerNumber = $customerNumber;
                $debugDmsCustomerNumber = ' <b>Info: No DMS customerNumber found (crm_stammdaten.fremdnummer). Using CATCH customerNumber instead.</b>';
            }

            $workshop_planner_btn_suhl = $workshop_planner_btn_gotha = $debug_workshop_planner_container = '';
            if ($suhl) {
                if (!empty($customerVin)) {
                    $workshop_planner_btn_suhl = '<button class="btn btn-blue" style="width: 50px; height: 30px; text-align: center; margin-right: 5px;" onClick="window.open(\'https://werkstattplanung.net/ahg/suhl/kic/public/da/#/?searchVin='.$customerVin.'\', \'_blank\');">Suhl</button>';
                } elseif (!empty($dmsCustomerNumber)) {
                    $workshop_planner_btn_suhl = '<button class="btn btn-blue" style="width: 50px; height: 30px; text-align: center; margin-right: 5px;" onClick="window.open(\'https://werkstattplanung.net/ahg/suhl/kic/public/da/#/?searchCustomerNumber='.$dmsCustomerNumber.'\', \'_blank\');">Suhl</button>';
                }
            }
            if ($gotha) {
                if (!empty($customerVin)) {
                    $workshop_planner_btn_gotha = '<button class="btn btn-blue" style="width: 50px; height: 30px; text-align: center; margin-right: 5px;" onClick="window.open(\'https://werkstattplanung.net/ahg/gotha/kic/public/da/#/?searchVin='.$customerVin.'\', \'_blank\');">Gotha</button>';
                } elseif (!empty($dmsCustomerNumber)) {
                    $workshop_planner_btn_gotha = '<button class="btn btn-blue" style="width: 50px; height: 30px; text-align: center;" onClick="window.open(\'https://werkstattplanung.net/ahg/gotha/kic/public/da/#/?searchCustomerNumber='.$dmsCustomerNumber.'\', \'_blank\');">Gotha</button>';
                }
            }

            # DEBUG
            if ($_SERVER['SERVER_ADMIN'] === 'timo.cingoez@prof4.net') {
                $debug_workshop_planner_container = '<div style="border: dotted 1px black; margin: 5px; padding: 5px; display: inline-block;">';
                $debug_workshop_planner_container .= '<p style="text-align: center; font-size: 15px;"><b>DEBUG</b></p>';
                $debug_workshop_planner_container .= 'DMS customerNumber: '.$dmsCustomerNumber.$debugDmsCustomerNumber.'<br>';
                $debug_workshop_planner_container .= 'CATCH customerNumber: '.$customerNumber.'<br>';
                $debug_workshop_planner_container .= 'CATCH customerCenter: '.($suhl ? 'Suhl' : '').' '.($gotha ? 'Gotha' : '').'<br>';
                $debug_workshop_planner_container .= 'CATCH customerVin: '.$customerVin.'<br>';
                $debug_workshop_planner_container .= '<b>Using '.($customerVin ? 'VIN' : 'customerNumber').' for Deeplink.</b>'.'</div>';
            }

            $inhalt = p4n_mb_string('str_replace', '{workshop_planner_new_case_btn}', '<div style="display: flex; align-items: center;">'.$workshop_planner_btn_suhl.'<br>'.$workshop_planner_btn_gotha.'<br>'.$debug_workshop_planner_container.'</div>', $inhalt);
        }
    }

    $kanal = $alle_source = $marke = $sparte = array();
	$marke_hat_rang = false;
    $res = $db->select(
        $sql_tab['kategorie'],
        array(
            $sql_tabs['kategorie']['kategorie_id'],
            $sql_tabs['kategorie']['bezeichnung'],
            $sql_tabs['kategorie']['rang'],
            $sql_tabs['kategorie']['modul']
        ),
        $db->dbzahlin(array(46, 47, 48, 49, 92), $sql_tabs['kategorie']['modul']).' and '.$sql_tabs['kategorie']['zusatz1'].'='.$db->str(''),
        $sql_tabs['kategorie']['rang'].' asc,'.$sql_tabs['kategorie']['bezeichnung']
    );
    while ($row = $db->zeile($res)) {
        if ($row[3]==46) {
            $alle_source[$row[1]]=$row[1];
        }
        if ($row[3]==47) {
            $kanal[$row[1]]=$row[1];
        }
        if ($row[3]==48) {
            $sparte[$row[1]]=$row[1];
        }
        if ($row[3]==49) {
			if (intval($row[2])>0) {
				$marke_hat_rang=true;
			}
            $marke[$row[1]]=$row[1];
        }
        if ($row[3]==92 && ($cfg_lead_absatzgruppe || $_SESSION['crm_version_float']>=61300)) {
            $alle_absatzgruppe[$row[1]]=$row[1];
        }
    }
    $res5=$db->select(
        $sql_tab['kampagne_lead'],
        'distinct '.$sql_tabs['kampagne_lead']['channel']
    );
    while ($row5=$db->zeile($res5)) {
        $kanal[$row5[0]]=$row5[0];
    }
    $kanal = cleanUpSelectArray($kanal, _IMPORT_KEINE_ZUORDNUNG_);

    $res5=$db->select(
        $sql_tab['kampagne_lead'],
        'distinct '.$sql_tabs['kampagne_lead']['type']
    );
    while ($row5=$db->zeile($res5)) {
        $sparte[$row5[0]]=$row5[0];
    }
    $sparte = cleanUpSelectArray($sparte);
    if (is_array($sparte))
    natcasesort($sparte);
    
    $res=$db->select(
		$sql_tab['kampagne_lead'],
		'distinct '.$sql_tabs['kampagne_lead']['source']
	);
	while ($row=$db->zeile($res)) {
		$alle_source[$row[0]]=$row[0];
	}
	$alle_source = cleanUpSelectArray($alle_source, _IMPORT_KEINE_ZUORDNUNG_);
    if ($cfg_lead_absatzgruppe || $_SESSION['crm_version_float']>=61300) {
        $res=$db->select(
           $sql_tab['kampagne_lead'],
           'distinct '.$sql_tabs['kampagne_lead']['absatzgruppe']
        );
        $alle_absatzgruppe=array(_JA_=>_JA_,_NEIN_=>_NEIN_);
        while ($row=$db->zeile($res)) {
            $alle_absatzgruppe[$row[0]]=$row[0];
        }
        unset($alle_absatzgruppe[-1]);
        unset($alle_absatzgruppe['']);
    }
	$res5=$db->select(
		$sql_tab['kampagne_lead'],
		'distinct '.$sql_tabs['kampagne_lead']['kfzmarke']
	);
	while ($row5=$db->zeile($res5)) {
        $marke[$row5[0]]=$row5[0];
    }
	if ($marke_hat_rang) {
		$marke2=array('' => _IMPORT_KEINE_ZUORDNUNG_);
		foreach ($marke as $msval) {
			if ($msval!='') {
				$marke2[$msval]=$msval;
			}
		}
	    $marke = $marke2;
	} else {
		$marke = cleanUpSelectArray($marke, _IMPORT_KEINE_ZUORDNUNG_);
	}
    $g=false;
    if (isset($postfeld['form_kunde_stdid'])) {
        $g=true;
    }
    
    $bdcPoolSearch=0;
    if (isset($_GET['bdcPoolSearch'])) {
        $bdcPoolSearch=$_GET['bdcPoolSearch'];
        
        
        $res = $db->select(
            $sql_tab['bdc_pool'], 
            array(
                $sql_tabs['bdc_pool']['bdc_pool_id'],//0
                $sql_tabs['bdc_pool']['pool_obj'],//1
                $sql_tabs['bdc_pool']['ersteller_id'],//2
                $sql_tabs['bdc_pool']['datum_eintrag'],//3
                $sql_tabs['bdc_pool']['betreuer_id'],//4
                $sql_tabs['bdc_pool']['datum_wvl'],//5
                $sql_tabs['bdc_pool']['status'],//6
                $sql_tabs['bdc_pool']['letzte_aenderung']//7
            ),
            $sql_tabs['bdc_pool']['bdc_pool_id'].'='.$db->dbzahl($_GET['bdcPoolSearch'])
        );
        if ($row = $db->zeile($res)) {
            $bdc_pool_obj=unserialize(base64_decode($row[1]));
            $beschreibung='';

            $beschreibung='<b>Betreff: </b>'.$bdc_pool_obj['betreff'].'<br><b>Beschreibung: </b>'.$bdc_pool_obj['beschreibung'];
            $beschreibung2='';
            
            if ($g) {} else {
            if (isset($bdc_pool_obj['firma']) && (!isset($postfeld['form_kunde_firma']) || $postfeld['form_kunde_firma']=='')) {
               $postfeld['form_kunde_anrede']='Firma';
             
               if (isset($bdc_pool_obj['firma']) && (!isset($postfeld['form_kunde_firma']) || $postfeld['form_kunde_firma']=='')) {
                     $postfeld['form_kunde_firma']=$bdc_pool_obj['firma'];
                  // unset($bdc_pool_obj['firma']);
               }
                if (isset($bdc_pool_obj['nachname']) && (!isset($postfeld['form_kunde_ap_bezeichnung']) || $postfeld['form_kunde_ap_bezeichnung']=='')) {
                  // $postfeld['form_kunde_ap_bezeichnung']=$bdc_pool_obj['nachname'];
                   //unset($bdc_pool_obj['nachname']);
                }
                if (isset($bdc_pool_obj['anrede']) && (!isset($postfeld['form_kunde_ap_anrede']) || $postfeld['form_kunde_ap_anrede']=='')) {
                   // $postfeld['form_kunde_ap_anrede']=$bdc_pool_obj['anrede'];
                   // unset($bdc_pool_obj['anrede']);
                }
                
            } else {
                if (isset($bdc_pool_obj['nachname']) && (!isset($postfeld['form_kunde_name']) || $postfeld['form_kunde_name']=='')) {
                    $postfeld['form_kunde_name']=$bdc_pool_obj['nachname'];
                    //unset($bdc_pool_obj['nachname']);
                }
                if (isset($bdc_pool_obj['anrede']) && (!isset($postfeld['form_kunde_anrede']) || $postfeld['form_kunde_anrede']=='')) {
                   $postfeld['form_kunde_anrede']=$bdc_pool_obj['anrede'];
                  // unset($bdc_pool_obj['anrede']);
                }
            }
            }
            
            
            foreach ($bdc_pool_obj as $key => $value) {
                if ($key=='bdc_flag' || $key=='betreff' || $key=='beschreibung' || $key=='undefined') {
                    continue;
                }
                $beschreibung2.=p4n_mb_string('ucwords',$key).': <i>'.$value.'</i><br>';
            }
            if ($beschreibung2!='') {
                $beschreibung.=''.substr($beschreibung2,0,-1).'';
            }
 
            
            
            

            $za=$form->selectinput('art',array('Anfrage'=>'Anfrage','Beschwerde'=>'Beschwerde','Lead'=>'Lead','Sonstiges'=>'Sonstiges'),$bdc_pool_obj['bdc_flag'],_BITTE_WAEHLEN_);

            $html.='
                <tr class="odd">
                    <td class="td">'.$za.'</td>
                    <td class="td">'.nl2br($beschreibung).'</td>
                    <td class="td">'.$benutzer_feld[$row[2]].'</td>
                    <td class="td">'.$row[3].'</td>
                    <td class="td">'.$form->selectinput('benutzer', $bens2_online, $row[4], _KEINE_AUSWAHL_).'</td>
                    <td class="td">'.$row[7].'</td>
                   <!-- <td class="td">'.$row[5].'</td>
                    <td class="td">'.$row[6].'</td>-->
                </tr>';
            /*  <td class="td">'.
                    link2('ausw�hlen','bdc.php?stid='.$bdc_pool_obj['stammdaten_id'].'&getBdcPoolData='.$row[0]).'<br>'.
                    link2(_LOESCHEN_, 'javascript:void(0);', '', '','style="color:#ea1f1f" onclick="RequestHelper.post(\'bdc.php\',\'removeFromBdcPool=\'+'.$row[0].',function(response) {P4nBoxHelper.closeall(\'selectBdcPoolAll\'); try { top.main.P4nBoxHelper.requestPost(\'bdc.php\',\'selectBdcPoolAll=1\',function(response) {},\'600px\',\'600px\',true,\'selectBdcPoolAll\'); } catch(e) {} });"')
                    '</td>'*/

            $html='<table class="moderntable table-ignore2 table-nohover">'.'<tr class="odd">
                <th class="th">Art</th>
                <th class="th">Beschreibung</th>
                <th class="th">Ersteller</th>
                <th class="th">erstellt am:</th>
                <th class="th">Betreuer</th>
                <th class="th">letzte �nderung</th>
                <!--<th class="th">Datum WVL</th>
                <th class="th">Status</th>-->
            </tr>'.$html.'</table>';

            $html=$form->start('bdcPoolSearchForm','bdc.php?options_menu=0&options_padding=0','POST').
            $form->hidden('bdc_pool_id',$_GET['bdcPoolSearch']).
            $form->hidden('bdcPoolSearch',$_GET['bdcPoolSearch']).
            $form->hidden('form_kunde_stdid',$postfeld['form_kunde_stdid']).
            $html.$form->submit('saveBdcPoolSearch',_SPEICHERN_).
            $form->submit2('','zur�ck zum Pool','onclick="try {  top.main.P4nBoxHelper.requestPost(\'bdc.php\',\'selectBdcPoolAll=1\',function(response) {  },\'600px\',\'600px\',true,\'selectBdcPoolAll\'); } catch(e) {}"').
            ($g ? $form->submit2('','im BDC �ffnen','onclick="top.main.linkToTab(\'bdc.php?stid='.$postfeld['form_kunde_stdid'].'&getBdcPoolData='.$_GET['bdcPoolSearch'].'\');"'):'').
            $form->ende();

            $inhalt= preg_replace('/\<\!--{tabs_start}--\>.*\<\!--{tabs_ende}--\>/Uis',$html,$inhalt);
             $inhalt=strReplaceInputs($inhalt,array('zusinf'=>''));
             $inhalt=strReplaceInputs($inhalt,array('einstellungen'=> 'Pool'));
        }
    }
    
    if (!$cfg_bdc_stbemerkung) {
        $inhalt= preg_replace('/\<\!cfg_bdc_stbemerkung1\>.*\<\!cfg_bdc_stbemerkung2\>/Uis','',$inhalt);
    }
    // anfrage, beschwerde, lead, sonstige, werkstattplaner
    $possible_tabs=array(0 => 1, 1 => 1, 2 => 1, 3 => 1, 4 => 1);
    if ($cfg_bdc_notbman) {
        $inhalt= preg_replace('/\<\!bman1>.*\<\!bman2>/Uis','',$inhalt);
        $inhalt= preg_replace('/\<\!anan1>.*\<\!anan2>/Uis','',$inhalt);
        unset($possible_tabs[0]);
        unset($possible_tabs[1]);
    }
    if (isset($rechte_['no_an_tab'])) {
        $inhalt= preg_replace('/\<\!anan1>.*\<\!anan2>/Uis','',$inhalt);
        unset($possible_tabs[0]);
    }
    if (isset($rechte_['no_bm_tab'])) {
        $inhalt= preg_replace('/\<\!bman1>.*\<\!bman2>/Uis','',$inhalt);
        unset($possible_tabs[1]);
    }
    if (isset($rechte_['no_lead_tab'])) {
        $inhalt= preg_replace('/\<\!leadan1>.*\<\!leadan2>/Uis','',$inhalt);
        unset($possible_tabs[2]);
    }
    if (!$cfg_workshop_planner) {
        $inhalt = preg_replace('/\<\!workshop_planner1>.*\<\!workshop_planner2>/Uis', '', $inhalt);
        unset($possible_tabs[4]);
    }
    
    $inhalt=strReplaceInputs($inhalt,array('stdid'=>$postfeld['form_kunde_stdid']));
   
    if ((isset($postfeld['form_kunde_sct'])&&$postfeld['form_kunde_sct']==1)) {
        $inhalt=strReplaceInputs($inhalt,array('korrespondenz_lang'=>'','live_korrespondenzen'=>''));
    } else {
        $inhalt=strReplaceInputs($inhalt,array('korrespondenz_lang'=>_KORRESPONDENZEN_,'live_korrespondenzen'=>$allek));
    }
    $first_tab=0;
    if (isset($_GET['goto'])) {
        $disabled_tabs_text = array_keys($possible_tabs);
        
		if ($_GET['goto']=='anfrage') {
            if ($pos = array_search(0, $disabled_tabs_text)) {
                $first_tab=$pos;
            }
		} elseif ($_GET['goto']=='beschwerde') {
            if ($pos = array_search(1, $disabled_tabs_text)) {
                $first_tab=$pos;
            }
		} elseif ($_GET['goto']=='lead') {
            if ($pos = array_search(2, $disabled_tabs_text)) {
                $first_tab=$pos;
            }
		}
	}
    $disabled='';
    $disabled2='';
    
    $sonstiges_tab = 3;
    if (isset($_GET['eva'])) {
        $cfg_bdc_notbman=true;
        //$inhalt=strReplaceInputs($inhalt,array('tabs/selected'=>0));
        if (isset($possible_tabs[3]) && count($possible_tabs) > 1) {
            $inhalt= preg_replace('/\<\!sonstiges1>.*\<\!sonstiges2>/Uis','',$inhalt);
        }
        //$inhalt=strReplaceInputs($inhalt,array('disabled'=>'[]'));
    }
    $disabled_tabs_text = array_keys($possible_tabs);
    if (($pos = array_search(3, $disabled_tabs_text)) !== false) {
        $sonstiges_tab=$pos;
        unset($disabled_tabs_text[$sonstiges_tab]);
    }
    if (!isset($postfeld['form_kunde_stdid'])) {
        if (isset($_GET['configure_required_fields']) && $_GET['configure_required_fields']==1) {
            $disabled_tabs_text=[]; // alle Reiter erlauben
            $disabled2=''; // alle Felder erlauben
        }
        else {
            $disabled2=' disabled="disabled"';
            $first_tab=$sonstiges_tab;
        }
        $inhalt=strReplaceInputs($inhalt,array('form_anfrage_cancel'=>'','form_lead_cancel'=>'','disabled'=>'['.implode(',', array_keys($disabled_tabs_text)).']'));
        $inhalt=strReplaceInputs($inhalt,array('zusinf'=>''));
        $keyup_ap='';
    } else {
        //$inhalt=strReplaceInputs($inhalt,array('tabs/selected'=>0));
        $disabled=' disabled="disabled"';
        $inhalt=strReplaceInputs($inhalt,array('disabled'=>'['.$sonstiges_tab.']'));
        if (!isset($_GET['ohnecc'])) {
            $inhalt=strReplaceInputs($inhalt,array('zusinf'=>$zusinf));
        } else {
            $inhalt=strReplaceInputs($inhalt,array('zusinf'=>''));
        }
        $keyup_ap='';
    }


    if (isset($_GET['configure_required_fields']) && $_GET['configure_required_fields']==1) {
        $inhalt= p4n_mb_string('str_replace', '{form_configure_required_fields_submit}', $form->submit2('test', _PFLICHTFELDER_SPEICHERN_, 'onclick="onSaveRequiredFieldsClick();"'), $inhalt);
        $additional_js = '<script>
            jq1112(document).ready(function() {
                jq1112(\'.remove-when-configure-required-fields\').remove();
                jq1112(\'th[id$="label"]\').each(function() {
                    var $th = jq1112(this);
                    bdcInitRequiredFiled($th);
                });
            });


            function bdcInitRequiredFiled($th, tryCount=0) {
                if (tryCount>=10) {
                    return;
                }
                
                if (typeof $th.attr(\'class\')!= typeof undefined && $th.attr(\'class\').indexOf(\'nopflicht\')==-1) {                    
                    var targetElementName = $th.attr(\'id\').replace(\'_label\', \'\');
                    var $td = $th.next(\'td\');
                    var $targetElement = $td.find(\'*[name="\'+targetElementName+\'"]\');
                    var elementType = $targetElement.prop(\'nodeName\');    
                    var $targetElementWrapper;
                                          
                    // some fields maybe not ready now (kampagne, kategorie) -> try again later
                    if (typeof elementType === \'undefined\') {
                        setTimeout(bdcInitRequiredFiled, 300, $th, tryCount+1);
                        return;
                    }
                    
                    switch (elementType) {
                        case \'SELECT\':
                            $targetElementWrapper = $targetElement.closest(\'.styled-select\');
                            break;

                        default:
                            $targetElementWrapper = $targetElement;
                    }

                    var $requiredSpan = $td.find(\'span.required\');
                    var checked = false;
                    if ($requiredSpan.length > 0) {
                        checked = true;
                        $requiredSpan.remove();
                    }

                    var checkbox = document.createElement(\'input\');
                    checkbox.setAttribute(\'type\', \'checkbox\');
                    checkbox.setAttribute(\'name\', targetElementName);
                    checkbox.setAttribute(\'class\', \'required-field-checkbox\');
                    if (checked) {
                        checkbox.setAttribute(\'checked\', \'checked\');
                    }

                    $targetElementWrapper.after(checkbox);
                }
            }
                            

            function onSaveRequiredFieldsClick() {
                var postString = \'\';
                jq1112(\'.required-field-checkbox\').each(function () {
                    var $checkbox = jq1112(this);
                    postString += \'&fields[\' + $checkbox.attr(\'name\') + \']=\' + (typeof $checkbox.attr(\'checked\') !== \'undefined\' ? 1 : 0);
                });

                P4nBoxHelper.startloading(true);
                RequestHelper.post(window.location.href, \'action=configure_required_fields\'+postString, function (response) {
                    P4nBoxHelper.stoploading();
                });
            }

        </script>';
        $inhalt= p4n_mb_string('str_replace', '{configure_required_fields_start}', $additional_js, $inhalt);
    }
    else {
        $inhalt= p4n_mb_string('str_replace', '{configure_required_fields_start}', '', $inhalt);
        $inhalt= p4n_mb_string('str_replace', '{form_configure_required_fields_submit}', '', $inhalt);
    }


    $inhalt=strReplaceInputs($inhalt,array('tabs/selected'=>$first_tab)); 
    
    $inhalt=strReplaceInputs($inhalt,array('suchekunde_millisek'=>$suchekunde_millisek));
    $form=new htmlform();
    $inhalt=strReplaceInputs($inhalt,array('bdc_alert'=>  addslashes($form->submit2('',  '&nbsp;'.strtoupper(_OK_).'&nbsp;','onclick="P4nBoxHelper.close(\'bdc_alert_window\');"'))));
    $p='form_kunde_';
    $form_kunde=new htmlform();
    
    if (intval($postfeld['form_kunde_standort'])<=0) {
        $postfeld['form_kunde_standort']=$_SESSION['user_standard_lagerort'];
    }
    
    $g2=false;
    if ($cfg_bdc_kundenaendern) {
        $disabled='';
        if ($g) {
            $g2=true;
        }
        $g=false;
    }
    
    $cfg_stammdaten_anredefix=true;
    $anredeausw=$form_kunde->textinput('form_kunde_anrede',$postfeld['form_kunde_anrede'], 0, $disabled.' class="bdcpool" data-bdcpool-name="anrede"');
    if ($cfg_stammdaten_anredefix) {
        $fixanreden=array(
            '' => '',
            _HERR_ => _HERR_,
            _FRAU_ => _FRAU_,
            _FIRMA_ => _FIRMA_
        );
        if (isset($postfeld['form_kunde_anrede']) && $postfeld['form_kunde_anrede']!='' and $postfeld['form_kunde_anrede']!='-1' and !isset($fixanreden[$postfeld['form_kunde_anrede']])) {
            $fixanreden[$row9[0]]=$row9[0];
        }
        $anredeausw=$form_kunde->selectinput('form_kunde_anrede', $fixanreden, $postfeld['form_kunde_anrede'], 0, $disabled.' '.($_SESSION['crm_version']>68?'style="display:none"':'').' class="bdcpool" data-bdcpool-name="anrede"');
        
        if ($_SESSION['crm_version']>68) {
            // $anredeausw='';
            $anredeausw.=$form_kunde->submit2('',_HERR_,$disabled.'style="width:auto;" id="anrede_herr" '.($postfeld['form_kunde_anrede']==_HERR_?'class="aktive"':''));
            $anredeausw.=$form_kunde->submit2('',_FRAU_,$disabled.'style="width:auto;" id="anrede_frau" '.($postfeld['form_kunde_anrede']==_FRAU_?'class="aktive"':''));
            $anredeausw.=$form_kunde->submit2('',_FIRMA_,$disabled.'style="width:auto;" id="anrede_firma" '.($postfeld['form_kunde_anrede']==_FIRMA_?'class="aktive"':''));
        }
    }
    if (isset($getfeld['bdc_posteingang']) && !isset($getfeld['stid'])) {
        $postfeld['form_kunde_email_privat']=Mailbox_Email::getEmailFromEmailString($_SESSION['bdc_posteingang_absender']);
    }
    $form_kunde_tpl=array(
        'form_kunde_start' => $form_kunde->start('fform', $phs.(isset($_GET['ohnecc'])?'?ohnecc=1':'').(isset($_GET['bdcPoolSearch'])?'?options_padding=0&options_menu=0':''), 'POST', false, 'id="form_kunde_suche" onSubmit="P4nBoxHelper.startloading(true)"'),
        'form_kunde_anrede' => (isset($_GET['bdcPoolSearch'])?$form->hidden('bdcPoolSearch',$_GET['bdcPoolSearch']):'').$anredeausw.
            ($g || $g2?$form_kunde->hidden('form_kunde_stdid', $postfeld['form_kunde_stdid'],' class="bdcpool" data-bdcpool-name="stammdaten_id"'):'').
            $form_kunde->hidden('form_kunde_sct', (isset($postfeld['form_kunde_sct'])&&$postfeld['form_kunde_sct']==1?1:'')).
            ($g?$form_kunde->hidden('form_kunde_anrede', $postfeld['form_kunde_anrede']):''),
        'form_kunde_titel' => ($_SESSION['crm_version']>68?'<span id="titel_" '.($postfeld['form_kunde_firma']!=''?' style="display:none"':'').'>&nbsp;('._TITEL_.':':'').$form_kunde->textinput('form_kunde_titel', $postfeld['form_kunde_titel'], 0, $disabled.($postfeld['form_kunde_firma']!=''?' style="display:none"':'').' class="bdcpool" data-bdcpool-name="titel"').($_SESSION['crm_version']>68?')</span>':'').
            ($g?$form_kunde->hidden('form_kunde_titel', $postfeld['form_kunde_titel']):''),
        'lang_anrede' => ($_SESSION['crm_version']>68?'':' / '._TITEL_),
        
        'form_kunde_titel_bemerkung'=>($cfg_bdc_stbemerkung?p4n_mb_string('ucfirst',p4n_mb_string('substr',$lang_db_f['stammdaten'][''], 0, 2)).'.-'.p4n_mb_string('ucfirst', $lang_db_f['stammdaten']['bemerkung']):''),
        'form_kunde_st_bemerkung'=>($cfg_bdc_stbemerkung? $form_kunde->textareainput('form_kunde_st_bemerkung', $postfeld['form_kunde_st_bemerkung'], 0, 2, $disabled.'style="height:107px;"'):''),
        
        
        'form_kunde_name' => $form_kunde->textinput('form_kunde_name', $postfeld['form_kunde_name'], 0, $disabled.($postfeld['form_kunde_firma']!=''?' style="display:none"':'').' class="bdcpool" data-bdcpool-name="name"').
            ($g?$form_kunde->hidden('form_kunde_name', $postfeld['form_kunde_name']):''),
        'form_kunde_vorname' => $form_kunde->textinput('form_kunde_vorname', $postfeld['form_kunde_vorname'], 0, $disabled.($postfeld['form_kunde_firma']!=''?' style="display:none"':'').' class="bdcpool" data-bdcpool-name="vorname"').
            ($g?$form_kunde->hidden('form_kunde_vorname', $postfeld['form_kunde_vorname']):''),
        'form_kunde_firma' => $form_kunde->textinput('form_kunde_firma', $postfeld['form_kunde_firma'], 0, $disabled.($postfeld['form_kunde_firma']!=''?'':' style="display:none"').' class="bdcpool" data-bdcpool-name="firma"').
            ($g?$form_kunde->hidden('form_kunde_firma', $postfeld['form_kunde_firma']):''),
        'form_kunde_name_lang' => ($postfeld['form_kunde_firma']!=''?_FIRMA_: ($_SESSION['crm_version']>68?($postfeld['form_kunde_anrede']==''?_NAME_.' / '._FIRMA_:_NAME_):_NAME_)),
        'form_kunde_vorname_lang' => ($postfeld['form_kunde_firma']!=''?_ANSPRECHPARTNER_:_VORNAME_),
        
        'form_kunde_ansprechpartner' => (isset($postfeld['form_kunde_ansprechpartner_id'])?$form_kunde->hidden('form_kunde_ansprechpartner_id', $postfeld['form_kunde_ansprechpartner_id'],' class="bdcpool" data-bdcpool-name="ansprechpartner_id"'):''),
        'ap_display' => (isset($postfeld['form_kunde_firma']) &&$postfeld['form_kunde_firma']!=''?'':'display:none;'),
        
        'form_kunde_plz' => $form_kunde->textinput('plz', $postfeld['plz'], 0, $disabled.' onKeyup="checkplz(this.name, this.value, \'parent.main.document.' . $form_kunde->fname . '.elements[\\\'ort\\\']\', \'parent.main.document.' . $form_kunde->fname . '.elements[\\\'land\\\']\');"').
            ($g?$form_kunde->hidden('plz', $postfeld['plz']):''),
        'form_kunde_stadt' => $form_kunde->textinput('ort', $postfeld['ort'], 0, $disabled).
            ($g?$form_kunde->hidden('ort', $postfeld['ort']):''),
        'form_kunde_adresse' => $form_kunde->textinput('adresse', $postfeld['adresse'], 0, $disabled).$form_kunde->hidden('land',$def_land1).$form_kunde->hidden('form_kunde_vaudixVersand','0').
            ($g?$form_kunde->hidden('adresse', $postfeld['adresse']):''),
       
        'form_kunde_telefon_privat' => $form_kunde->textinput('form_kunde_telefon_privat', $postfeld['form_kunde_telefon_privat'], 0, $disabled.($cfg_telefonnummer_input_just_numbers_validation?' data-validate-name="'._TELEFON_PRIVAT_.'" class="validate_phone" ':'')).
            ($g?$form_kunde->hidden('form_kunde_telefon_privat', $postfeld['form_kunde_telefon_privat']):'').(isset($getfeld['tenios'])?$form_kunde->hidden('tenios', $getfeld['tenios']):'').($getfeld['cti_fremd_id']!=''?$form_kunde->hidden('cti_fremd_id', $getfeld['cti_fremd_id']):'').($getfeld['startSetting']!=''?$form_kunde->hidden('startSetting', $getfeld['startSetting']):'').
        '('._KONTAKT_PRIVAT_ABK_.')',
        'form_kunde_mobil_privat' => $form_kunde->textinput('form_kunde_mobil_privat', $postfeld['form_kunde_mobil_privat'], 0, $disabled.($cfg_telefonnummer_input_just_numbers_validation?' data-validate-name="'._MOBILTELEFON_PRIVAT_.'" class="validate_phone" ':'')).
            ($g?$form_kunde->hidden('form_kunde_mobil_privat', $postfeld['form_kunde_mobil_privat']):'').
        '('._KONTAKT_PRIVAT_ABK_.')',
        'form_kunde_email_privat' => $form_kunde->textinput('form_kunde_email_privat', $postfeld['form_kunde_email_privat'], 0, $disabled.' data-validate-name="'._EMAIL_.' '._PRIVAT_.'" class="validate_email"').
            ($g?$form_kunde->hidden('form_kunde_email_privat', $postfeld['form_kunde_email_privat']):'').
        '('._KONTAKT_PRIVAT_ABK_.')',
        
        'avag_telefon_check_helper'=>($cfg_avag_telnr_check?' '.$telzus:''),
        'form_kunde_telefon_ges' => $form_kunde->textinput('form_kunde_telefon_ges', $postfeld['form_kunde_telefon_ges'], 0, $disabled.($cfg_telefonnummer_input_just_numbers_validation?' data-validate-name="'._TELEFON_GESCHAEFTLICH_.'" class="validate_phone" ':'')).
            ($g?$form_kunde->hidden('form_kunde_telefon_ges', $postfeld['form_kunde_telefon_ges']):'').
        '('._KONTAKT_GESCHAEFTLICH_ABK_.')',
            'form_kunde_mobil_ges' => $form_kunde->textinput('form_kunde_mobil_ges', $postfeld['form_kunde_mobil_ges'], 0, $disabled.($cfg_telefonnummer_input_just_numbers_validation?' data-validate-name="'._MOBILTELEFON_GESCHAEFTLICH_.'" class="validate_phone" ':'')).
        ($g?$form_kunde->hidden('form_kunde_mobil_ges', $postfeld['form_kunde_mobil_ges']):'').
        ($_SESSION['crm_version']>68?'<br>'.$form_kunde->textinput('form_kunde_t_alternativ', '', 0,'placeholder="'._ALTERNATIVE_.' '._KNTEL_.'"'.($cfg_telefonnummer_input_just_numbers_validation?' data-validate-name="'._ALTERNATIVE_.' '._KNTEL_.'" class="validate_phone" ':'')):''),
        '('._KONTAKT_GESCHAEFTLICH_ABK_.')',
            'form_kunde_email_ges' => $form_kunde->textinput('form_kunde_email_ges', $postfeld['form_kunde_email_ges'], 0, $disabled.' data-validate-name="'._EMAIL_.' '._GESCHAEFTLICH_.'" class="validate_email"').
        ($g?$form_kunde->hidden('form_kunde_email_ges', $postfeld['form_kunde_email_ges']):'').
        '('._KONTAKT_GESCHAEFTLICH_ABK_.')',
      
        'form_kunde_standort' => 
        ($g  || $g2?
            $form_kunde->selectinput('',$form_kunde_standort, $postfeld['form_kunde_standort'], _KEINE_AUSWAHL_, ' disabled="disabled" ')
            :
            $form_kunde->selectinput('form_kunde_standort', $form_kunde_standort, $postfeld['form_kunde_standort'], _KEINE_AUSWAHL_, $disabled)
        ).
        ($g  || $g2?
            $form_kunde->hidden('form_kunde_standort', $postfeld['form_kunde_standort'])
            :
            ''),
    
        'cfg_checkAdress' => ($cfg_check_adress_rueck?$form_kunde->hidden('cfg_checkAdress', true):''),
        'form_kunde_kennzeichen' => $form_kunde->textinput('form_kunde_kennzeichen', $postfeld['form_kunde_kennzeichen'], 0, ($_SESSION['crm_version']>68?'':oltext2(_NUR_.' '._SUCHE_)).' '.$disabled).
            ($g?$form_kunde->hidden('form_kunde_kennzeichen', $postfeld['form_kunde_kennzeichen']):''),
        'form_kunde_modell' => $form_kunde->textinput('form_kunde_modell', trim($postfeld['form_kunde_modell'].($cfg_cross? ' '.$postfeld['form_kunde_typ']:'')), 0, ($_SESSION['crm_version']>68?'':oltext2(_NUR_.' '._SUCHE_)).' '.$disabled).
            ($g?$form_kunde->hidden('form_kunde_modell', $postfeld['form_kunde_modell']):''),
        'form_kunde_erstzulassung' => $form_kunde->textinput('form_kunde_erstzulassung', $postfeld['form_kunde_erstzulassung'], 0, ($_SESSION['crm_version']>68?'':oltext2(_NUR_.' '._SUCHE_)).' '.$disabled).
            ($g?$form_kunde->hidden('form_kunde_erstzulassung', $postfeld['form_kunde_erstzulassung']):''),
        'form_kunde_kmstand' => $form_kunde->textinput('form_kunde_kmstand', $postfeld['form_kunde_kmstand'], 0, ($_SESSION['crm_version']>68?'':oltext2(_NUR_.' '._SUCHE_)).' '.$disabled).
            ($g?$form_kunde->hidden('form_kunde_kmstand', $postfeld['form_kunde_kmstand']):''),

        'form_kunde_zusatz'=>$form_kunde->hidden('eva', $_GET['eva']).$form_kunde->hidden('ohnecc', $_GET['ohnecc']).(isset($_GET['null_ign'])?$form_kunde->hidden('null_ign','1'):''),
        'form_kunde_suche' => $form_kunde->checkinput('dse_druck',false,'style="display:none;"').(isset($_GET['bdcPoolSearch']) && ($g || $g2)?$form_kunde->submit('neue_suche','neuen Kunden ausw�hlen'):'').(!$g && !$g2?$form_kunde->submit2('form_kunde_suche_submit',_SP_SUCHE_,'id="'.'form_kunde_suche_submit" disabled="disabled"'):($g2?$form_kunde->submit2('',_SUBMIT_STAMMDATEN_,' onclick="change_kunde();"').$form_kunde->hidden('form_kunde_submit_change','1'):'')).
        (((!isset($getfeld['apid']) && isset($getfeld['stid']) && intval($getfeld['stid'])>0 && $postfeld['form_kunde_firma']!='' && !(isset($_GET['getBdcPoolData'])) && !(isset($_GET['getBdcPoolData_removed'])) && !isset($getfeld['bdc_posteingang']) && !isset($getfeld['ignoreBdcSuche']))) || 
        ((!isset($getfeld['apid']) && isset($getfeld['stid']) && intval($getfeld['stid'])>0 && $postfeld['form_kunde_firma']!='' && !(isset($_GET['getBdcPoolData'])) && !(isset($_GET['getBdcPoolData_removed'])) && isset($getfeld['bdc_posteingang']) && $getfeld['form_kunde_ansprechpartner_id']==0))
        ?javas("bdc_suche(true);"):((isset($getfeld['suche']) && isset($getfeld['telefon_privat']) && $getfeld['telefon_privat']!='')?javas("bdc_suche();"):'')),
        'form_kunde_submit' => 
        $form_kunde->submit('form_kunde_submit','','style="display:none;" id="'.'form_kunde_submit" onclick="document.getElementById(\''.'form_kunde_suche_submit\').click(); return false;"').
        $form_kunde->submit('form_kunde_submit2','','style="display:none;" id="'.'form_kunde_submit2" onclick="document.getElementById(\''.'form_kunde_suche_submit\').click(); return false;"'),
        'form_kunde_submit2' => 
        addslashes($form_kunde->submit2('',_NEUKUNDE_ANLEGEN_,'id="neukunde_anlegen" onclick="check_neukunde_anlegen(); return false;"')).' '.
        (!$cfg_bdc_notbman  && !$cfg_bdc_keindummy ? addslashes($form_kunde->submit2('','BDC Dummy','id="sct_anlegen" onclick="check_sct_anlegen(); return false;"')).' ':'').
        addslashes($form_kunde->submit2('form_kunde_submit2',_ABBRECHEN_,'id="'.'form_kunde_submit3" onclick="P4nBoxHelper.close();"').'<span id="neukunde_anlegen_dse">'.($_SESSION['crm_version']>67 && false ? $form->checkinput('dse_druck_', $cfg_neuanlage_dsehaken_an) . ' ' . _DSE_DRUCK_ : '').'</span>'),
        'form_kunde_ende' => $form_kunde->ende(),
        'fahrgestell_display' => ($_SESSION['crm_version']>68 || $_SESSION['cfg_kunde']=='crm_vw_jacobs') ? '' : 'display:none;',
        'rowspan_fahrgestell' => ($_SESSION['crm_version']>68 || $_SESSION['cfg_kunde']=='crm_vw_jacobs') ? '1' : '2',
        'form_kunde_fahrgestell' => ($_SESSION['crm_version']>68 || $_SESSION['cfg_kunde']=='crm_vw_jacobs') ? $form_kunde->textinput('form_kunde_fahrgestell', $postfeld['form_kunde_fahrgestell'], 0, $disabled).($g?$form_kunde->hidden('form_kunde_fahrgestell', $postfeld['form_kunde_fahrgestell']):'') : '',
        
    );
    $form_kunde_tpl['form_kunde_Interessentennummer'] = $form_kunde->textinput('form_kunde_Interessentennummer', $postfeld['form_kunde_Interessentennummer'], 0, $disabled.' class="bdcpool" data-bdcpool-name="Interessentennummer"');
    if (isset($_GET['ohnecc'])) {
        if ((isset($getfeld['eva']) && intval($getfeld['stid'])>0) || !isset($getfeld['eva'])) {
            $form_kunde_tpl['form_kunde_suche']='';
            $form_kunde_tpl['form_kunde_submit']='';
            $form_kunde_tpl['form_kunde_submit2']='';
        }
    }
    $inhalt=strReplaceInputs($inhalt,$form_kunde_tpl);
    
    
    $zusatz_kundendaten='';
    $zusatz_kundendaten_arr=array(
        'form_kunde_stdid'=>$postfeld['form_kunde_stdid'],
        'form_kunde_sct'=>(isset($postfeld['form_kunde_sct'])&&$postfeld['form_kunde_sct']==1?1:''),
        'form_kunde_anrede'=>$postfeld['form_kunde_anrede'],
        'form_kunde_titel'=>$postfeld['form_kunde_titel'],
        'form_kunde_st_bemerkung'=>$postfeld['form_kunde_st_bemerkung'],
        'form_kunde_name'=>$postfeld['form_kunde_name'],
        'form_kunde_vorname'=>$postfeld['form_kunde_vorname'],
        'form_kunde_firma'=>$postfeld['form_kunde_firma'],
        'plz'=>$postfeld['plz'],
        'ort'=>$postfeld['ort'],
        'adresse'=>$postfeld['adresse'],
        'land'=>$def_land1,
        'form_kunde_telefon_privat'=>$postfeld['form_kunde_telefon_privat'],
        'form_kunde_mobil_privat'=>$postfeld['form_kunde_mobil_privat'],
        'form_kunde_email_privat'=>$postfeld['form_kunde_email_privat'],
        'form_kunde_telefon_ges'=>$postfeld['form_kunde_telefon_ges'],
        'form_kunde_mobil_ges'=>$postfeld['form_kunde_mobil_ges'],
        'form_kunde_email_ges'=>$postfeld['form_kunde_email_ges'],
        'form_kunde_standort'=>$postfeld['form_kunde_standort'],
        'form_kunde_kennzeichen'=>$postfeld['form_kunde_kennzeichen'],
        'form_kunde_modell'=>$postfeld['form_kunde_modell'],
        'form_kunde_erstzulassung'=>$postfeld['form_kunde_erstzulassung'],
        'form_kunde_kmstand'=>$postfeld['form_kunde_kmstand'],
        'eva'=>$_GET['eva'],
        'ohnecc'=>$_GET['ohnecc'],
        'form_kunde_fahrgestell'=>$postfeld['form_kunde_fahrgestell'],
        'dse_druck'=>''
    );
	
	
	if ($cfg_bdc_lagerort_stdlao and intval($_SESSION['user_standard_lagerort'])>0) {
		$postfeld['form_kunde_standort'] = $_SESSION['user_standard_lagerort'];
	}
	$js_ben_anfrage='';
	$js_ben_beschwerde='';
	$js_ben_lead='';
	$js_ben_sonstiges='';
	if ($cfg_bdc_lagerort_von_benutzerauswahl) {
		$js_ben_stdlao='if (typeof selstao != typeof undefined) { this.form.__BEN__.value=selstao; } ';//'this.form.__BEN__.value=\'-1\';';
		$res8=$db->select(
			$sql_tab['benutzer'],
	        array(
    	        $sql_tabs['benutzer']['benutzer_id'],
	            $sql_tabs['benutzer']['standard_lagerort']
        	),
	        $sql_tabs['benutzer']['gruppe'].'>=0'
	    );
	    while ($row8=$db->zeile($res8)) {
			if (intval($row8[1])>0) {
				$js_ben_stdlao.=' if (this.value==\''.$row8[0].'\') { this.form.__BEN__.value=\''.$row8[1].'\'; }';
			}
		}
		$js_ben_anfrage=' onChange="'.p4n_mb_string('str_replace', '__BEN__', 'form_anfrage_standort', $js_ben_stdlao).'" ';
		$js_ben_beschwerde=' onChange="'.p4n_mb_string('str_replace', '__BEN__', 'form_beschwerde_standort', $js_ben_stdlao).'" ';
		$js_ben_lead=' onChange="'.p4n_mb_string('str_replace', '__BEN__', 'form_lead_standort', $js_ben_stdlao).'" ';
		$js_ben_sonstiges=' onChange="'.p4n_mb_string('str_replace', '__BEN__', 'form_sonstiges_standort', $js_ben_stdlao).'" ';
		$def_ben_lao=0;
		if ($cfg_bdc_lagerort_stdlao and intval($_SESSION['user_standard_lagerort'])>0) {
			$def_ben_lao=$_SESSION['user_standard_lagerort'];
		}
		$postfeld['form_anfrage_standort']='';
		$postfeld['form_beschwerde_standort']='';
		$postfeld['form_lead_standort']='';
		$postfeld['form_sonstiges_standort']='';
	}
	
    if (isset($postfeld['form_kunde_ansprechpartner_id'])) {
        $zusatz_kundendaten_arr['form_kunde_ansprechpartner_id']=$postfeld['form_kunde_ansprechpartner_id'];
    }
    if (isset($getfeld['tenios'])) {
        $zusatz_kundendaten_arr['tenios']=$getfeld['tenios'];
    }
    if (isset($getfeld['cti_fremd_id'])) {
        $zusatz_kundendaten_arr['cti_fremd_id']=$getfeld['cti_fremd_id'];
    }

    

    $ap_g=false;
    $ap_disabled='';
    if (isset($postfeld['form_kunde_ansprechpartner_id']) && intval($postfeld['form_kunde_ansprechpartner_id'])>0) {
       $ap_disabled=' disabled="disabled"'; 
       $ap_g=true;
    }
    
   $g2=false;
    if ($cfg_bdc_kundenaendern) {
        $ap_disabled='';
        if ($ap_g) {
            $ap_g2=true;
        }
        $ap_g=false;
    }
    
    $anredeausw='';
    $titelausw='';
    if ($cfg_carlo_appserver and $cfg_carloimport_ansprechpartner_nas) {
        include_once('inc/xml_io.php');
        $ccodes = edsxml_read_codes($cfg_carlo_appserver_ip[$app_rs_mandid], $cfg_carlo_appserver_port[$app_rs_mandid], 'CarloCodes', 'ListEntries', array('Type' => 'Salutations'));
        if (count($ccodes) > 0) {
            $cc2 = array();
            while (list($key, $val) = @each($ccodes)) {
                $cc2[$key] = $key;
            }
            $anredeausw = $form_kunde->selectinput('form_kunde_ap_anrede', $cc2, $postfeld['form_kunde_ap_anrede'], false,$ap_disabled);
        }
    } elseif ($cfg_ap_anredeauswahl) {
        $cc2 = array(''=>'',_HERR_ => _HERR_, _FRAU_ => _FRAU_, _FIRMA_ => _FIRMA_);
        $anredeausw = $form_kunde->selectinput('form_kunde_ap_anrede', $cc2, $postfeld['form_kunde_ap_anrede'], false,$ap_disabled);
    } elseif ($_SESSION['cfg_kunde'] == 'carlo_opel_carebus') {
        $kkats21 = array('M.' => 'M.', 'Mme' => 'Mme', 'Mlle' => 'Mlle');
        $res2 = $db->select($sql_tab['stammdaten_ansprechpartner'], 'distinct ' . $sql_tabs['stammdaten_ansprechpartner']['anrede']);
        while ($row2 = $db->zeile($res2)) {
            $kkats21[$row2[0]] = $row2[0];
        }
        $anredeausw=$form_kunde->selectinput('form_kunde_ap_anrede', $kkats21, $postfeld['form_kunde_ap_anrede'], -1, oltext2(_ANREDE_).' '.$ap_disabled);
    } elseif ($_SESSION['cfg_kunde'] == 'carlo_opel_dello') {
        $alle_anr = array('' => '','Herr' => 'Herr', 'Frau' => 'Frau');
        $anredeausw=$form_kunde->selectinput('form_kunde_ap_anrede', $alle_anr,$postfeld['form_kunde_ap_anrede'],false,$ap_disabled);
        $alle_tit = array('' => 'ohne', 'Dr.' => 'Dr.', 'Professor' => 'Professor', 'Prof. Dr.' => 'Prof. Dr.');
        $titelausw=$form_kunde->selectinput('form_kunde_ap_titel', $alle_tit,$postfeld['form_kunde_ap_titel'],false,$ap_disabled);
    } else {
        $anredeausw=$form_kunde->textinput('form_kunde_ap_anrede', $postfeld['form_kunde_ap_anrede'], 8, oltext2(_ANREDE_).' '.$ap_disabled);
    }
    if ($titelausw=='') {
        $titelausw = $form_kunde->textinput('form_kunde_ap_titel', $postfeld['form_kunde_ap_titel'], 6, oltext2($lang['_TITEL_']).' '.$ap_disabled);
        if ($cfg_carlo_appserver and $cfg_carloimport_ansprechpartner_nas) {
            $alle_tit = array();
            $res4 = $db->select(
                    $sql_tab['crmcodes'], array(
                $sql_tabs['crmcodes']['crmcodes_id'],
                $sql_tabs['crmcodes']['code1'],
                $sql_tabs['crmcodes']['text1']
                    ), $sql_tabs['crmcodes']['art'] . '=' . $db->str('CARLO_TITEL')
            );
            while ($row4 = $db->zeile($res4)) {
                $alle_tit[$row4[1]] = $row4[2];
            }
            if (count($alle_tit) > 0) {
                $titelausw = $form_kunde->selectinput('form_kunde_ap_titel', $alle_tit, $postfeld['form_kunde_ap_titel'], _KEINE_AUSWAHL_,$ap_disabled);
            }
        }
    }
    
    
    
    
    
    $form_ap_tpl=array(
        'form_kunde_ap_change' => $form_kunde->selectinput('form_kunde_ap_change', $ap_feld2, $postfeld['form_kunde_ansprechpartner_id'], _KEINE_AUSWAHL_, 'onchange="bdc_reload_ap();"'),
        'form_kunde_ap_bezeichnung' => $form_kunde->textinput('form_kunde_ap_bezeichnung', $postfeld['form_kunde_ap_bezeichnung'], 12, ' id="ap_name"'.$ap_disabled).
        ($ap_g?$form_kunde->hidden('form_kunde_ap_bezeichnung', $postfeld['form_kunde_ap_bezeichnung']):''),
        'form_kunde_ap_telefon' => $form_kunde->textinput('form_kunde_ap_telefon', $postfeld['form_kunde_ap_telefon'], 11, $ap_disabled.($cfg_telefonnummer_input_just_numbers_validation?' data-validate-name="'.$lang['_AP-TELEFON_'].' '._ANSPRECHPARTNER_.'" class="validate_phone" ':'')).
        ($ap_g?$form_kunde->hidden('form_kunde_ap_telefon', $postfeld['form_kunde_ap_telefon']):''),
        'form_kunde_ap_mobil' => $form_kunde->textinput('form_kunde_ap_mobil', $postfeld['form_kunde_ap_mobil'], 11, $ap_disabled.($cfg_telefonnummer_input_just_numbers_validation?' data-validate-name="'.$lang['_AP-MOBIL_'].' '._ANSPRECHPARTNER_.'" class="validate_phone" ':'')).
        ($ap_g?$form_kunde->hidden('form_kunde_ap_mobil', $postfeld['form_kunde_ap_mobil']):''),
        'form_kunde_ap_email' => $form_kunde->textinput('form_kunde_ap_email', $postfeld['form_kunde_ap_email'], 11, $ap_disabled).
        ($ap_g?$form_kunde->hidden('form_kunde_ap_email', $postfeld['form_kunde_ap_email']):''),
        'form_kunde_ap_vorname' => $form_kunde->textinput('form_kunde_ap_vorname', $postfeld['form_kunde_ap_vorname'], 7, ' id="ap_vorname"'.$ap_disabled).
        ($ap_g?$form_kunde->hidden('form_kunde_ap_vorname', $postfeld['form_kunde_ap_vorname']):''),
        'form_kunde_ap_anrede' => $anredeausw.
        ($ap_g?$form_kunde->hidden('form_kunde_ap_anrede', $postfeld['form_kunde_ap_anrede']):''),
        'form_kunde_ap_titel' => $titelausw.
        ($ap_g?$form_kunde->hidden('form_kunde_ap_titel', $postfeld['form_kunde_ap_titel']):''),
    );
    $inhalt=strReplaceInputs($inhalt,$form_ap_tpl);
    
    $zusatz_kundendaten_arr['form_kunde_ap_bezeichnung']=$postfeld['form_kunde_ap_bezeichnung'];
    $zusatz_kundendaten_arr['form_kunde_ap_telefon']=$postfeld['form_kunde_ap_telefon'];
    $zusatz_kundendaten_arr['form_kunde_ap_mobil']=$postfeld['form_kunde_ap_mobil'];
    $zusatz_kundendaten_arr['form_kunde_ap_email']=$postfeld['form_kunde_ap_email'];
    $zusatz_kundendaten_arr['form_kunde_ap_vorname']=$postfeld['form_kunde_ap_vorname'];
    $zusatz_kundendaten_arr['form_kunde_ap_anrede']=$postfeld['form_kunde_ap_anrede'];
    $zusatz_kundendaten_arr['form_kunde_ap_titel']=$postfeld['form_kunde_ap_titel'];
    
    if ($cfg_bdc_nl) {
        $form_ap_tpl=array(
        'form_kunde_mittelname' => $form_kunde->textinput('form_kunde_mittelname', $postfeld['form_kunde_mittelname'], 0, $disabled.($postfeld['form_kunde_firma']!=''?' style="display:none"':'')).
            ($g?$form_kunde->hidden('form_kunde_mittelname', $postfeld['form_kunde_mittelname']):''),
        'form_kunde_rufname' => $form_kunde->textinput('form_kunde_rufname', $postfeld['form_kunde_rufname'], 0, $disabled.($postfeld['form_kunde_firma']!=''?' style="display:none"':'')).
            ($g?$form_kunde->hidden('form_kunde_rufname', $postfeld['form_kunde_rufname']):''),
        'form_kunde_ap_mittelname' => $form_kunde->textinput('form_kunde_ap_mittelname', $postfeld['form_kunde_ap_mittelname'], 7, ' id="ap_mittelname"'.$ap_disabled).
        ($ap_g?$form_kunde->hidden('form_kunde_ap_mittelname', $postfeld['form_kunde_ap_mittelname']):''),
            'form_kunde_ap_rufname' => $form_kunde->textinput('form_kunde_ap_rufname', $postfeld['form_kunde_ap_rufname'], 7, ' id="ap_rufname"'.$ap_disabled).
        ($ap_g?$form_kunde->hidden('form_kunde_ap_rufname', $postfeld['form_kunde_ap_rufname']):''),
    );
        $zusatz_kundendaten_arr['form_kunde_mittelname']=$postfeld['form_kunde_mittelname'];
        $zusatz_kundendaten_arr['form_kunde_rufname']=$postfeld['form_kunde_rufname'];
        $zusatz_kundendaten_arr['form_kunde_ap_mittelname']=$postfeld['form_kunde_ap_mittelname'];
        $zusatz_kundendaten_arr['form_kunde_ap_rufname']=$postfeld['form_kunde_ap_rufname'];
        $inhalt=strReplaceInputs($inhalt,$form_ap_tpl);
    }
    
    foreach ($zusatz_kundendaten_arr as $key_kundendaten => $value_kundendaten) {
        $zusatz_kundendaten.=$key_kundendaten.'='.$value_kundendaten.'#####';
    }
    
    $arten_anfrage = array();
    $res=$db->select(
        $sql_tab['kategorie'],
        $sql_tabs['kategorie']['bezeichnung'],
        $sql_tabs['kategorie']['modul'].'='.$db->dbzahl(50),
        $sql_tabs['kategorie']['rang'].' asc, '.$sql_tabs['kategorie']['kategorie_id'].' asc'
    );
    while ($row=$db->zeile($res)) {
        $arten_anfrage[$row[0]]=$row[0];
    }
    if (empty($arten_anfrage)) {
        $arten_anfrage = $arten;
    }
    
    
    $bdcBeschreibung='';
    $bdcBetreff='';
    $bdcDatei='';
    
    if ($_GET['bdc_posteingang']==1) {
        $_SESSION['bdc_posteingang']==0;
    }
    
    if ($_SESSION['bdc_posteingang']==1) {
        $_GET['bdc_posteingang']=1;
    }
    
    if ($_GET['bdc_posteingang']==1) {
        $_SESSION['bdc_posteingang']=($_SESSION['bdc_posteingang']==1?0:1);
        $bdcBeschreibung=base64_decode($_SESSION['bdc_posteingang_beschreibung']);//base64_decode($_GET['bdc_posteingang_beschreibung']);
        $bdcBetreff=base64_decode($_SESSION['bdc_posteingang_betreff']);//base64_decode($_GET['bdc_posteingang_betreff']);
        $bdcDatei=base64_decode($_SESSION['bdc_posteingang_dateien'][0]);//base64_decode($_GET['bdc_posteingang_dateien']);
        $bdcDateiName1=explode('/',$bdcDatei);
        $bdcDateiName1=$bdcDateiName1[count($bdcDateiName1)-1];
        $bdcDatei2=base64_decode($_SESSION['bdc_posteingang_dateien'][1]);
        $bdcDateiName2=explode('/',$bdcDatei2);
        $bdcDateiName2=$bdcDateiName2[count($bdcDateiName2)-1];
        $bdcDatei3=base64_decode($_SESSION['bdc_posteingang_dateien'][2]);
        $bdcDateiName3=explode('/',$bdcDatei3);
        $bdcDateiName3=$bdcDateiName3[count($bdcDateiName3)-1];
    }

    $in_kanal=false;
    $in_kat3=false;
    $p='form_anfrage_';
    $form_anfrage=new htmlform();
    $disabled3 = $benutzerzus3 = '';
    if (!empty($cfg_bm_ticketpool)) {
        $benutzerzus3 = ' | '._POOL_.': '.$form_anfrage->checkinput('form_anfrage_pool', ($benutzer_selected == -1 ? true : false), 'id="form_anfrage_pool"');
        if ($benutzer_selected == -1 && $disabled2 == '') {
            $disabled3 = ' disabled="disabled"';
        }
    }
    $form_anfrage_tpl=array(
        'form_anfrage_start' => $form_anfrage->start('form_anfrage', $phs.(isset($_GET['ohnecc'])?'?ohnecc=1':''), 'POST', true, 'id="'.'form_anfrage_start'.'"'),
        'form_anfrage_betreff' => $form_anfrage->textinput('form_anfrage_betreff', $bdcBetreff, 0, $disabled2.' class="bdcpool" data-bdcpool-name="betreff"').($_GET['bdc_posteingang']==1?$form_anfrage->hidden('is_bdc_mailbox_request','1'):''),
        'form_anfrage_beschreibung' => $form_anfrage->textareainput('form_anfrage_beschreibung', $bdcBeschreibung, 0, 2, 'style="height:107px;"'.$disabled2.' class="beschreibung bdcpool" data-bdcpool-name="beschreibung"'),
        'form_anfrage_kbau' => (!empty($alle_textbausteine) ? $form_anfrage->selectinput('form_anfrage_kbau', $alle_textbausteine, -99, false, 'onChange="einfuegen(this.form, this.form.elements[\''.'form_anfrage_beschreibung\'], this.form.elements[\''.'form_anfrage_kbau[]\'].value+\'\n\'); this.form.elements[\''.'form_anfrage_beschreibung\'].focus();"'.''.$disabled2, true, 6) : ''),
        'form_anfrage_art' => $form_anfrage->selectinput('form_anfrage_art', $arten_anfrage, '', _KEINE_AUSWAHL_, $disabled2.' class="bdcpool" data-bdcpool-name="art"'),
        'form_anfrage_kategorie1' => $form_anfrage->selectinput('form_anfrage_kategorie1', $kategorien, '', _KEINE_AUSWAHL_, $disabled2.' class="bdcpool" data-bdcpool-name="kategorie"'),
        'form_anfrage_kategorie2' => $form_anfrage->selectinput('form_anfrage_kategorie2', $kategorien2_anfrage, '', ($cfg_bdc_kategorie2_multiselect ? false : _KEINE_AUSWAHL_), $disabled2.' class="bdcpool" data-bdcpool-name="kategorie2"', boolval($cfg_bdc_kategorie2_multiselect)),
        'form_anfrage_datei1' => $form_anfrage->dateiinput('form_anfrage_datei1', '',0,$disabled2).($bdcDatei!='' && $_GET['bdc_posteingang']==1?$form_anfrage->checkinput('form_anfrage_datei1_bdcp_checkbox',true).$form_anfrage->hidden('form_anfrage_datei1_bdcp_path',$bdcDatei).' '.link2($bdcDateiName1,$bdcDatei, '', '', 'target="_blank"'):''),
        'form_anfrage_datei2' => $form_anfrage->dateiinput('form_anfrage_datei2', '', 0, $disabled2).($bdcDatei2!='' && $_GET['bdc_posteingang']==1?$form_anfrage->checkinput('form_anfrage_datei2_bdcp_checkbox',true).$form_anfrage->hidden('form_anfrage_datei2_bdcp_path',$bdcDatei2).' '.link2($bdcDateiName2,$bdcDatei2, '', '', 'target="_blank"'):''),
        'form_anfrage_datei3' => $form_anfrage->dateiinput('form_anfrage_datei3', '', 0, $disabled2).($bdcDatei3!='' && $_GET['bdc_posteingang']==1?$form_anfrage->checkinput('form_anfrage_datei3_bdcp_checkbox',true).$form_anfrage->hidden('form_anfrage_datei3_bdcp_path',$bdcDatei3).' '.link2($bdcDateiName3,$bdcDatei3, '', '', 'target="_blank"'):''),
        'form_anfrage_benutzer' => $form->hidden('form_anfrage_benutzer_hidden','').$form_anfrage->selectinput('form_anfrage_benutzer', $bens2_online, (isset($postfeld['form_kunde_sct']) && $postfeld['form_kunde_sct']==1?-1:$benutzer_selected), (isset($postfeld['form_kunde_sct']) && $postfeld['form_kunde_sct']==1?_KEINE_AUSWAHL_:_KEINE_AUSWAHL_), $js_ben_anfrage.$disabled2.$disabled3.' class="bdcpool" data-bdcpool-name="betreuer_id"').$benutzerzus3,
        'form_anfrage_email2' => $form_anfrage->selectinput('form_anfrage_email2', $bens2_online,-1,_KEINE_AUSWAHL_, $disabled2),
        'form_anfrage_email1' => $form_anfrage->selectinput('form_anfrage_email1', $bens2_online,-1,_KEINE_AUSWAHL_, $disabled2),
        'form_anfrage_email' => $form_anfrage->textinput('form_anfrage_email', '', 0, $disabled2.($cfg_stammdaten_lead?' placeholder="Freie Adresse"':'')),
        
        'form_anfrage_lang_fahrzeug' => (isset($postfeld['form_kunde_sct']) && $postfeld['form_kunde_sct']==1?
                _LAGERORT_:
                _FAHRZEUG_
        ),
        'form_anfrage_lang_rechnung' => (isset($postfeld['form_kunde_sct']) && $postfeld['form_kunde_sct']==1?'':_RECHNUNG_),
        
        
        'form_anfrage_fahrzeug' => (isset($postfeld['form_kunde_sct']) && $postfeld['form_kunde_sct']==1?
                $form_anfrage->selectinput('form_anfrage_standort', $form_kunde_standort, ($cfg_bdc_lagerort_von_benutzerauswahl?$def_ben_lao:$postfeld['form_kunde_standort']), _KEINE_AUSWAHL_, $disabled2.' class="bdcpool" data-bdcpool-name="standort"'):
                $form_anfrage->selectinput('form_anfrage_fahrzeug', $fahrzeuglink, $fahrzeuglink_selected, false, $disabled2.' class="bdcpool" data-bdcpool-name="fahrzeug"')),
        'form_anfrage_rechnung' => (isset($postfeld['form_kunde_sct']) && $postfeld['form_kunde_sct']==1?'':$form_anfrage->selectinput('form_anfrage_rechnung', $rechnungslink, $rechnungslink_selected, false, $disabled2.' class="bdcpool" data-bdcpool-name="rechnung"')),
        
        //'form_anfrage_status' => $form_anfrage->selectinput('form_anfrage_status', array(4 => _BM_STATUS4_),-1,_KEINE_AUSWAHL_, $disabled2),
        
        'form_anfrage_zusatz_kundendaten' => $form_anfrage->hidden('form_anfrage_zusatz_kundendaten', '','id="'.'form_anfrage_zusatz_kundendaten'.'"'),
          'form_anfrage_submit' => 
        $form_anfrage->submit('form_anfrage_submit',_BM_ART3_.' '._ERSTELLEN_,'id="'.'form_anfrage_submit'.'" style="display:none"').
        $form_anfrage->submit2('form_anfrage_submit2',_BM_ART3_.' '._ERSTELLEN_,'id="'.'form_anfrage_submit2'.'" onclick="return false;"'.$disabled2),
        'form_anfrage_submit2_value'=>_BM_ART3_.' '._ERSTELLEN_,
        'form_anfrage_submit2_value2'=>((($_SESSION['crm_version']>61 or $cfg_bdc_grund) and !$cfg_bdc_nl)?_FRAGEN_EINTRAGEN_:_BM_ART3_.' '._ERSTELLEN_),
        'meineid'=>$user_id,
        'meineid2'=>(isset($postfeld['form_kunde_sct']) && $postfeld['form_kunde_sct']==1?-1:$benutzer_selected),
        'form_anfrage_bdc_pool'=>
        ($cfg_bdc_pool?(($from_bdc_pool==true)?$form_anfrage->submit2('','zur�ck zum Pool','onclick="toBdcPool(\''.'form_anfrage_start'.'\','.$_GET['getBdcPoolData'].');"'):$form_anfrage->submit2('','zum Pool','onclick="toBdcPool(\''.'form_anfrage_start'.'\');"')).
        $form_anfrage->hidden('','Anfrage','class="bdcpool" data-bdcpool-name="bdc_flag"').
        $form_anfrage->hidden('','','class="bdcpool" data-bdcpool-name="datum_eintrag"').
        $form_anfrage->hidden('','','class="bdcpool" data-bdcpool-name="ersteller_id"').
        $form_anfrage->hidden('','','class="bdcpool pool_rest"'):'')
        ,
        'form_anfrage_cancel' => (($from_bdc_pool==true)?'':$form_anfrage->submit2('',_ABBRECHEN_,'class="cancel_btn"')),
        'form_anfrage_ende' => $form_anfrage->ende(),
    );
    
    $form70_anfrage=Template_Form::init('form_anfrage', $phs.(isset($_GET['ohnecc'])?'?ohnecc=1':''), 'POST', true, 'id="'.'form_anfrage_start'.'"')->setTarget("form_target");
    
    $submit_anfrage=new Template_Submit('form_anfrage_submit',_BM_ART3_.' '._ERSTELLEN_,'id="'.'form_anfrage_submit'.'"');
    
    $cols_anfrage=$cols_anfrage_details=$cols_anfrage_anlagen=$cols_hidden_anfrage=array();
    $cols_hidden_anfrage[]=new Template_HiddenInput('form_anfrage_zusatz_kundendaten', $zusatz_kundendaten,'id="'.'form_anfrage_zusatz_kundendaten'.'"');
    $cols_hidden_anfrage[]=new Template_HiddenInput('form_anfrage_benutzer_hidden','');

    
    $cols_anfrage[0][0]=new Template_Title('Inhalt der Anfrage',5);
    $cols_anfrage[1][0]=new Template_GridTableCol(12,8,9,Template_TextInput::init(_BETREFF_, 'form_anfrage_betreff', $bdcBetreff, 0, ' class="bdcpool" data-bdcpool-name="betreff"')/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_betreff'])?true:false)*/);
    $cols_anfrage[2][0]=new Template_GridTableCol(12,8,9,Template_TextArea::init(_BESCHREIBUNG_, 'form_anfrage_beschreibung', $bdcBeschreibung, 0, 0, 'style="min-height:200px;"'.' class="beschreibung bdcpool" data-bdcpool-name="beschreibung"')/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_beschreibung'])?true:false)*/);
    //$cols_anfrage[2][1]=new Template_GridTableCol(12,4,3,(!empty($alle_textbausteine) ? Template_SelectInput::init(' ','form_anfrage_kbau', $alle_textbausteine, -99, false, 'onChange="einfuegen(this.form, this.form.elements[\''.'form_anfrage_beschreibung\'], this.form.elements[\''.'form_anfrage_kbau[]\'].value+\'\n\'); this.form.elements[\''.'form_anfrage_beschreibung\'].focus();"', true, 6)/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_kbau'])?true:false)*/ : ''));
    

    $links_bs70=array();
    while (list($keys, $vals)=@each($alle_textbausteine)) {
        $xir++;
        if (count($alle_textbausteine)>5) {
            $links_bs70[str_replace(array('"', "'", "\r\n", "\n"), array('', '', "\n", "\n"), $vals)."\n"]=$xir.'. '.$keys;
        } else {
            $links_bs70[]=Template_Button::init('', $xir.'. '.$keys,'onClick="einfuegen(this.form, this.form.elements[\''.'form_anfrage_beschreibung\'], \''.str_replace(array('"', "'", "\r\n", "\n"), array('', '', '\\n', '\\n'), $vals).'\n\'); this.form.elements[\''.'form_anfrage_beschreibung\'].focus();"','','','','xs')->addCustomClass("w100");
        }
    }
    if (count($alle_textbausteine)>5) {
        $links_bs70=new Template_SelectInput('','',$links_bs70,-1,_KEINE_AUSWAHL_,'onchange="einfuegen(this.form, this.form.elements[\'form_anfrage_beschreibung\'],this.value); this.form.elements[\'form_anfrage_beschreibung\'].focus();"');
    }
    $links_bs70_ges=Template_ElementList::init(
        array(
            new Template_ElementList($links_bs70,'','vertical small'),
    ),'','vertical mt-22');
    $cols_anfrage[2][1]=new Template_GridTableCol(12,4,3,(!empty($alle_textbausteine) ? $links_bs70_ges/*->setRequired(!empty($pflicht_lead_array['form_lead_kbau'])?true:false)*/ : ''));
    
    
    
    
    $cols_anfrage[3][0]=Template_SelectInput::init(_FAHRZEUG_,'form_anfrage_fahrzeug', $fahrzeuglink, $fahrzeuglink_selected, false, ' class="bdcpool" data-bdcpool-name="fahrzeug"')/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_fahrzeug'])?true:false)*/;
    $cols_anfrage[3][1]=Template_SelectInput::init(_RECHNUNG_,'form_anfrage_rechnung', $rechnungslink, $rechnungslink_selected, false, ' class="bdcpool" data-bdcpool-name="rechnung"')/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_rechnung'])?true:false)*/;
    $cols_anfrage[4][0]=Template_SelectInput::init(_KORRESPONDENZEN_,'kbezug', $allek, -1, _KEINE_AUSWAHL_)/*->setRequired(!empty($pflicht_anfragen_array['kbezug'])?true:false)*/;    
    $cols_anfrage[4][1]='&nbsp;';
    $cols_anfrage[5][0]=Template_Title::init('Anfrage qualifizieren',5)->addCustomClass('mt-24');
    
    $cols_anfrage[6][0]=Template_SelectInput::init(_ART_,'form_anfrage_art', $arten_anfrage, (!empty($teniosData) && $_SESSION['design_70']?$teniosData['arten_anfrage']:''), _KEINE_AUSWAHL_, ' class="bdcpool" data-bdcpool-name="art"')/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_art'])?true:false)*/;
    $cols_anfrage[7][0]=Template_SelectInput::init(_KATEGORIE_,'form_anfrage_kategorie1', $kategorien, (!empty($teniosData) && $_SESSION['design_70']?$teniosData['kategorie']:''), _KEINE_AUSWAHL_, ' class="bdcpool" data-bdcpool-name="kategorie"')/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_kategorie1'])?true:false)*/;
    $cols_anfrage[8][0]=Template_SelectInput::init(_KATEGORIE_.' 2','form_anfrage_kategorie2', $kategorien2_anfrage, (!empty($teniosData) && $_SESSION['design_70']?$teniosData['kategorie2']:''), ($cfg_bdc_kategorie2_multiselect ? false : _KEINE_AUSWAHL_), ' class="bdcpool" data-bdcpool-name="kategorie2"', boolval($cfg_bdc_kategorie2_multiselect))/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_kategorie2'])?true:false)*/;
    if (is_array($ap_feld2) && count($ap_feld2)>0) {
        $cols_anfrage[9][0]=Template_SelectInput::init(_ANSPRECHPARTNER_,'form_kunde_ansprechpartner_id', $ap_feld2, $postfeld['form_kunde_ansprechpartner_id'], _KEINE_AUSWAHL_/*,((is_array($ap_feld2) && count($ap_feld2)>0)?'':'disabled="disabled"')*/);
        $cols_anfrage[9][1]='&nbsp;';
    }
    
    $cols_anfrage[10][0]=Template_Title::init('Anfrage zuweisen',5)->addCustomClass('mt-24');
    
    $cols_anfrage[11][0]=Template_SelectInput::init(_BENUTZER_,'form_anfrage_benutzer', $bens2_online, (isset($postfeld['form_kunde_sct']) && $postfeld['form_kunde_sct']==1?-1:$benutzer_selected), (isset($postfeld['form_kunde_sct']) && $postfeld['form_kunde_sct']==1?_KEINE_AUSWAHL_:_KEINE_AUSWAHL_), $js_ben_anfrage.' class="bdcpool" data-bdcpool-name="betreuer_id"')->setRequired(true);
    
    $cols_temp[0][0]=Template_SelectInput::init(_INFOPEREMAILAN_,'form_anfrage_email1', $bens2_online,-1,_KEINE_AUSWAHL_)/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_email1'])?true:false)*/;
    $cols_temp[1][0]=Template_SelectInput::init(_INFOPEREMAILAN_.' 2','form_anfrage_email2', $bens2_online,-1,_KEINE_AUSWAHL_)/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_email2'])?true:false)*/;
    $cols_temp[2][0]=Template_TextInput::init(_INFOPEREMAILAN_.' - Freitext','form_anfrage_email', '', 0,($cfg_stammdaten_lead?' placeholder="Freie Adresse"':''))/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_email'])?true:false)*/;
    $cols_anfrage[11][1]=new Template_GridTable($cols_temp);
    
    /*$cols_files=array();
    //$cols_files[]=Template_FileInput::init(_DATEI_.' 1','form_anfrage_datei1', '', 0)/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_datei1'])?true:false)*/;
    //$cols_files[]=Template_FileInput::init(_DATEI_.' 2','form_anfrage_datei2', '', 0)/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_datei2'])?true:false)*/;
    //$cols_files[]=Template_FileInput::init(_DATEI_.' 3','form_anfrage_datei3', '', 0)/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_datei3'])?true:false)*/;
    
    
    
    //$cols_anfrage_anhang=new Template_ElementList($cols_files,'','vertical');*/
    $cols_anfrage_anhang=Template_FileInput::init('','form_anfrage_datei[]', '', '', '',true,3)->initFileList('','datei',array(),array('form_anfrage_datei1','form_anfrage_datei2','form_anfrage_datei3'),'');
    
    
    if (isset($_GET['ohnecc'])) {
        $form_anfrage_tpl['form_anfrage_cancel']=$form_anfrage->submit2('',_ABBRECHEN_,'onclick="parent.P4nBoxHelper.closeall();"');
    }
    if ((($_SESSION['crm_version']>61 or $cfg_bdc_grund) and !$cfg_bdc_nl) || $_SESSION['design_70']) {
        $form_anfrage_tpl['form_anfrage_standort_lang']=(isset($postfeld['form_kunde_sct']) && $postfeld['form_kunde_sct']==1?'':_LAGERORT_);
        $form_anfrage_tpl['form_anfrage_standort']=(isset($postfeld['form_kunde_sct']) && $postfeld['form_kunde_sct']==1?'':$form_anfrage->selectinput('form_anfrage_standort', $form_kunde_standort, ($cfg_bdc_lagerort_von_benutzerauswahl?$def_ben_lao:$postfeld['form_kunde_standort']), _KEINE_AUSWAHL_, $disabled2.' class="bdcpool" data-bdcpool-name="standort"'));
        if (isset($postfeld['form_kunde_sct']) && $postfeld['form_kunde_sct']==1) {} else {
            $cols_anfrage[6][1]=Template_SelectInput::init(_BETRIEB_,'form_anfrage_standort', $form_kunde_standort, ((!empty($teniosData) && isset($teniosData['bdc_location']) && $_SESSION['design_70'])?$teniosData['bdc_location']:($cfg_bdc_lagerort_von_benutzerauswahl?$def_ben_lao:$postfeld['form_kunde_standort'])), _KEINE_AUSWAHL_, ' class="bdcpool" data-bdcpool-name="standort"')/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_standort'])?true:false)*/;
        }
        $form_anfrage_tpl['form_anfrage_grund']=$form_anfrage->selectinput('form_anfrage_grund', $alle_bdc_gruende, $grund_selected, _KEINE_AUSWAHL_,$disabled2.' class="bdcpool" data-bdcpool-name="grund"');
        $cols_anfrage_details[0][0]=Template_SelectInput::init('BDC '._GRUND_,'form_anfrage_grund', $alle_bdc_gruende, $grund_selected, _KEINE_AUSWAHL_,' class="bdcpool" data-bdcpool-name="grund"')/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_grund'])?true:false)*/;
        $inhalt= preg_replace('/\<\!cfg_not_bdc_grund_zusatz1\>.*\<\!cfg_not_bdc_grund_zusatz2\>/Uis','',$inhalt);
    }
    if (($cfg_bdc_kanal || $_SESSION['design_70']) && !empty($bdc_kanaele)) {
        $in_kanal=true;
        $form_anfrage_tpl['form_anfrage_bdc_kanal']=$form_anfrage->selectinput('form_anfrage_bdc_kanal', $bdc_kanaele, $bdc_kanal_selected, _KEINE_AUSWAHL_, $disabled2);
        $cols_anfrage_details[1][0]=Template_SelectInput::init('BDC '._KANAL_,'form_anfrage_bdc_kanal', $bdc_kanaele, $bdc_kanal_selected, _KEINE_AUSWAHL_)/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_bdc_kanal'])?true:false)*/;
    } else {
        $inhalt= preg_replace('/\<\!bdc_kanal1\>.*\<\!bdc_kanal2\>/Uis','',$inhalt);
    }
    
    if ($cfg_bdc_nl) {
        $form_anfrage_tpl['form_anfrage_status']=$form_anfrage->selectinput('form_anfrage_status', $statusfeld, 2,false,$disabled2.' class="bdcpool" data-bdcpool-name="status"');
    } else {
        $form_anfrage_tpl['form_anfrage_status']=$form_anfrage->selectinput('form_anfrage_status', array(4 => _BM_STATUS4_),-1,_KEINE_AUSWAHL_, $disabled2.' class="bdcpool" data-bdcpool-name="status"');
        $cols_anfrage[8][1]=Template_SelectInput::init(_STATUS_,'form_anfrage_status', array(4 => _BM_STATUS4_),(!empty($teniosData) && $_SESSION['design_70']?$teniosData['status']:-1),_KEINE_AUSWAHL_, ' class="bdcpool" data-bdcpool-name="status"')/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_status'])?true:false)*/;
    }
    $form_anfrage_tpl['form_anfrage_fahrzeugsuche']='';
    if ($recht_kfz_schnellsuche) {
        if ($cfg_bdc_fahrzeugsuche || $cfg_leadmanagement_2020) {
            $form_anfrage_tpl['form_anfrage_fahrzeugsuche']=link2('<span border="0" alt="" class="icon icon-search">&nbsp;</span>','javascript:void(0);','','',$disabled2.'onclick="kfz_schnellsuche(\''.'form_anfrage_fahrzeug\');"');
        }
    }
    $bw = empty($bm_kategorien5) ? _BMKATEGORIE5_.' '._NICHT_GEFUNDEN_ : false;
    $form_anfrage_tpl['form_anfrage_kategorie5'] = $form_anfrage->selectinput('form_anfrage_kategorie5', $bm_kategorien5, '', $bw, $disabled2.' class="bdcpool" data-bdcpool-name="kategorie5"');
    $cols_anfrage[7][1]=Template_SelectInput::init(_BMKATEGORIE5_,'form_anfrage_kategorie5', $bm_kategorien5, (!empty($teniosData) && $_SESSION['design_70']?$teniosData['kategorien5']:''), $bw, ' class="bdcpool" data-bdcpool-name="kategorie5"')/*->setRequired(!empty($pflicht_anfragen_array['form_anfrage_kategorie5'])?true:false)*/;

    $bw = empty($bm_kfzmarken) ? _MARKEN_.' '._NICHT_GEFUNDEN_ : _KEINE_AUSWAHL_;
    $form_anfrage_tpl['form_anfrage_kfzmarke'] = $form_anfrage->selectinput('form_anfrage_kfzmarke', $bm_kfzmarken, -1, $bw, $disabled2.' class="bdcpool" data-bdcpool-name="kfzmarke"');
    // todo: design V7
    $in_kat3 = true;

    if ($in_kanal && $in_kat3) {
        $inhalt= preg_replace('/\<\!bdc_kanal_1\>.*\<\!bdc_kanal_2\>/Uis','',$inhalt);
        $inhalt= preg_replace('/\<\!bdc_inkat3_1\>.*\<\!bdc_inkat3_2\>/Uis','',$inhalt);
        $inhalt= preg_replace('/\<\!bdc_notkanal_notkat3_1\>.*\<\!bdc_notkanal_notkat3_2\>/Uis','',$inhalt);
    } else {
        if ($in_kanal && !$in_kat3) {
            $inhalt= preg_replace('/\<\!bdc_kanal_kat3_1\>.*\<\!bdc_kanal_kat3_2\>/Uis','',$inhalt);
            $inhalt= preg_replace('/\<\!bdc_inkat3_1\>.*\<\!bdc_inkat3_2\>/Uis','',$inhalt);
            $inhalt= preg_replace('/\<\!bdc_notkanal_notkat3_1\>.*\<\!bdc_notkanal_notkat3_2\>/Uis','',$inhalt);
        } else
        if (!$in_kanal && $in_kat3) {
            $inhalt= preg_replace('/\<\!bdc_kanal_kat3_1\>.*\<\!bdc_kanal_kat3_2\>/Uis','',$inhalt);
            $inhalt= preg_replace('/\<\!bdc_kanal_1\>.*\<\!bdc_kanal_2\>/Uis','',$inhalt);
            $inhalt= preg_replace('/\<\!bdc_notkanal_notkat3_1\>.*\<\!bdc_notkanal_notkat3_2\>/Uis','',$inhalt);
        } else {
            $inhalt= preg_replace('/\<\!bdc_kanal_kat3_1\>.*\<\!bdc_kanal_kat3_2\>/Uis','',$inhalt);
            $inhalt= preg_replace('/\<\!bdc_kanal_1\>.*\<\!bdc_kanal_2\>/Uis','',$inhalt);
            $inhalt= preg_replace('/\<\!bdc_inkat3_1\>.*\<\!bdc_inkat3_2\>/Uis','',$inhalt);
        }
    }
    
    if (isset($bdc_einstellungen['moredetails']) && $bdc_einstellungen['moredetails']==1) {
        $form_anfrage_tpl['form_anfrage_moredetails']=javas('jq1112(document).ready(function ($) { $("#'.'form_anfrage_moredetails").trigger("click"); });');
    } else {
        $form_anfrage_tpl['form_anfrage_moredetails']='';
    }
    
    $inhalt=strReplaceInputs($inhalt, $form_anfrage_tpl, $pflicht_anfragen_array);
    
 
    $alle_mand=rmandanten(true, true);
    $p='form_beschwerde_';
    $form_beschwerde=new htmlform();
    $form_kunde_standort_bm = $postfeld['form_kunde_standort'];
    if ($def_bmmand>0) {
        $form_kunde_standort_bm = $def_bmmand;
    }
	if ($cfg_bdc_lagerort_stdlao and intval($_SESSION['user_standard_lagerort'])>0) {
		$form_kunde_standort_bm = $_SESSION['user_standard_lagerort'];
	}
	$benutzerzus2='';
	if ($cfg_bm_bearbeiter2) {
		$benutzerzus2=' | 2.: '.$form_beschwerde->selectinput('form_beschwerde_betreuerzwei', $bens2_online, -1, _KEINE_AUSWAHL_,$disabled2).'';
	}
    $disabled3 = '';
    if (!empty($cfg_bm_ticketpool)) {
       $benutzerzus2 .= ' | '._POOL_.': '.$form_beschwerde->checkinput('form_beschwerde_pool', ($benutzer_selected == -1 ? true : false), 'id="form_beschwerde_pool"');
        if ($benutzer_selected == -1 && $disabled2 == '') {
            $disabled3 = ' disabled="disabled"';
        }
    }
    $form_beschwerde_tpl=array(
        'form_beschwerde_start' => $form_beschwerde->start('form_beschwerde', $phs.(isset($_GET['ohnecc'])?'?ohnecc=1':''), 'POST', true, 'id="'.'form_beschwerde_start'.'"'),
        'form_beschwerde_betreff' => $form_beschwerde->textinput('form_beschwerde_betreff', $bdcBetreff, 0,$disabled2.' class="bdcpool" data-bdcpool-name="betreff"').($_GET['bdc_posteingang']==1?$form_beschwerde->hidden('is_bdc_mailbox_request','1'):''),
        'form_beschwerde_beschreibung' => $form_beschwerde->textareainput('form_beschwerde_beschreibung', $bdcBeschreibung, 0, 2, $disabled2.'style="height:107px;"'.' class="bdcpool" data-bdcpool-name="beschreibung"'),
        'form_beschwerde_kbau' => (!empty($alle_textbausteine_bm) ? $form_beschwerde->selectinput('form_beschwerde_kbau', $alle_textbausteine_bm, -99, false, $disabled2.'onChange="einfuegen(this.form, this.form.elements[\''.'form_beschwerde_beschreibung\'], this.form.elements[\''.'form_beschwerde_kbau[]\'].value+\'\n\'); this.form.elements[\''.'form_beschwerde_beschreibung\'].focus();"'.''.$disabled2, true, 6) : ''),
        'form_beschwerde_art' => $form_beschwerde->selectinput('form_beschwerde_art', $arten, '', _KEINE_AUSWAHL_,$disabled2.' class="bdcpool" data-bdcpool-name="art"'),
        'form_beschwerde_kategorie1' => $form_beschwerde->selectinput('form_beschwerde_kategorie1', $kategorien, '', _KEINE_AUSWAHL_,$disabled2.' class="bdcpool" data-bdcpool-name="kategorie"'),
        'form_beschwerde_kategorie2' => $form_beschwerde->selectinput('form_beschwerde_kategorie2', $kategorien2_bechwerde, '', ($cfg_bdc_kategorie2_multiselect ? false : _KEINE_AUSWAHL_),$disabled2.' class="bdcpool" data-bdcpool-name="kategorie2"', boolval($cfg_bdc_kategorie2_multiselect)),
        'form_beschwerde_datei1' => $form_beschwerde->dateiinput('form_beschwerde_datei1', '', 0).($bdcDatei!='' && $_GET['bdc_posteingang']==1?$form_beschwerde->checkinput('form_beschwerde_datei1_bdcp_checkbox',true,$disabled2).$form_beschwerde->hidden('form_beschwerde_datei1_bdcp_path',$bdcDatei).' '.link2($bdcDateiName1,$bdcDatei, '', '', 'target="_blank"'):''),
        'form_beschwerde_datei2' => $form_beschwerde->dateiinput('form_beschwerde_datei2', '', 0).($bdcDatei2!='' && $_GET['bdc_posteingang']==1?$form_beschwerde->checkinput('form_beschwerde_datei2_bdcp_checkbox',true,$disabled2).$form_beschwerde->hidden('form_beschwerde_datei2_bdcp_path',$bdcDatei2).' '.link2($bdcDateiName2,$bdcDatei2, '', '', 'target="_blank"'):''),
        'form_beschwerde_datei3' => $form_beschwerde->dateiinput('form_beschwerde_datei3', '', 0).($bdcDatei3!='' && $_GET['bdc_posteingang']==1?$form_beschwerde->checkinput('form_beschwerde_datei3_bdcp_checkbox',true,$disabled2).$form_beschwerde->hidden('form_beschwerde_datei3_bdcp_path',$bdcDatei3).' '.link2($bdcDateiName3,$bdcDatei3, '', '', 'target="_blank"'):''),
        'form_beschwerde_benutzer' => $form_beschwerde->selectinput('form_beschwerde_benutzer', $bens2_online, $benutzer_selected, _KEINE_AUSWAHL_, $js_ben_beschwerde.$disabled2.$disabled3.' class="bdcpool" data-bdcpool-name="betreuer_id"').$benutzerzus2,
        'form_beschwerde_email2' => $form_beschwerde->selectinput('form_beschwerde_email2', $bens2_online,-1,_KEINE_AUSWAHL_,$disabled2),
        'form_beschwerde_email1' => $form_beschwerde->selectinput('form_beschwerde_email1', $bens2_online,-1,_KEINE_AUSWAHL_,$disabled2),
        'form_beschwerde_email' => $form_beschwerde->textinput('form_beschwerde_email', '', 0,$disabled2.($cfg_stammdaten_lead?' placeholder="Freie Adresse"':'')),
        'form_beschwerde_zielzeit' => $form_beschwerde->datuminput('form_beschwerde_zielzeit_datum', adodb_date('d.m.Y', $zielz), $disabled2).$form_beschwerde->zeitinput('form_beschwerde_zielzeit_zeit', adodb_date('H', $zielz), adodb_date('i', $zielz),$disabled2),
        'form_beschwerde_fahrzeug' => $form_beschwerde->selectinput('form_beschwerde_fahrzeug', $fahrzeuglink, $fahrzeuglink_selected, _KEINE_AUSWAHL_,$disabled2.' class="bdcpool" data-bdcpool-name="fahrzeug"'),
        'form_beschwerde_rechnung' => $form_beschwerde->selectinput('form_beschwerde_rechnung', $rechnungslink, $rechnungslink_selected, false,$disabled2.' onChange="'.$js_auf.'" '.' class="bdcpool" data-bdcpool-name="rechnung"'),
        'form_beschwerde_mandant' => $form_beschwerde->selectinput('form_beschwerde_standort', $form_kunde_standort, ($cfg_bdc_lagerort_von_benutzerauswahl?$def_ben_lao:$form_kunde_standort_bm), _KEINE_AUSWAHL_, $disabled2),
        //'form_beschwerde_status' => $form_beschwerde->selectinput('form_beschwerde_status', array(4 => _BM_STATUS4_),-1,_KEINE_AUSWAHL_, $disabled2),
        'form_beschwerde_zusatz_kundendaten' => $form_beschwerde->hidden('form_beschwerde_zusatz_kundendaten', '','id="'.'form_beschwerde_zusatz_kundendaten'.'"'),
        'form_beschwerde_submit' => 
            $form_beschwerde->submit('form_beschwerde_submit',_BESCHWERDE_.' '._ERSTELLEN_,$disabled2.'id="'.'form_beschwerde_submit'.'" style="display:none"').
            $form_beschwerde->submit2('form_beschwerde_submit2',_BESCHWERDE_.' '._ERSTELLEN_,$disabled2.'id="'.'form_beschwerde_submit2'.'" onclick="return false;"'),
        'form_beschwerde_bdc_pool'=>
        ($cfg_bdc_pool?(($from_bdc_pool==true)?$form_beschwerde->submit2('','zur�ck zum Pool','onclick="toBdcPool(\''.'form_beschwerde_start'.'\','.$_GET['getBdcPoolData'].');"'):$form_beschwerde->submit2('','zum Pool','onclick="toBdcPool(\''.'form_beschwerde_start'.'\');"')).
        $form_beschwerde->hidden('','Beschwerde','class="bdcpool" data-bdcpool-name="bdc_flag"').
        $form_beschwerde->hidden('','','class="bdcpool" data-bdcpool-name="datum_eintrag"').
        $form_beschwerde->hidden('','','class="bdcpool" data-bdcpool-name="ersteller_id"').
        $form_beschwerde->hidden('','','class="bdcpool pool_rest"'):'')
        ,
        'form_beschwerde_cancel' => (($from_bdc_pool==true)?'':$form_beschwerde->submit2('',_ABBRECHEN_,'class="cancel_btn"')),
        'form_beschwerde_ende' => $form_beschwerde->ende(),
    );
    
    
    $form70_beschwerde=Template_Form::init('form_beschwerde', $phs.(isset($_GET['ohnecc'])?'?ohnecc=1':''), 'POST', true, 'id="'.'form_beschwerde_start'.'"')->setTarget("form_target");
    $submit_beschwerde=new Template_Submit('form_beschwerde_submit',_BESCHWERDE_.' '._ERSTELLEN_,'id="'.'form_beschwerde_submit'.'"');
    $cancel_beschwerde=new Template_Button('',_ABBRECHEN_,'class="cancel_btn"');
    
    $cols_beschwerde=$cols_beschwerde_details=$cols_beschwerde_anlagen=$cols_hidden_beschwerde=array();
    
    $cols_hidden_beschwerde[]=new Template_HiddenInput('form_beschwerde_zusatz_kundendaten', $zusatz_kundendaten,'id="'.'form_beschwerde_zusatz_kundendaten'.'"');
    
    $cols_beschwerde[0][0]=new Template_Title('Inhalt der Beschwerde',5);
    $cols_beschwerde[1][0]=new Template_GridTableCol(12,8,9,array(Template_TextInput::init(_BETREFF_, 'form_beschwerde_betreff', $bdcBetreff, 0,' class="bdcpool" data-bdcpool-name="betreff"')/*->setRequired(!empty($pflicht_bm_array['form_beschwerde_betreff'])?true:false)*/));
    $cols_beschwerde[2][0]=new Template_GridTableCol(12,8,9,Template_TextArea::init(_BESCHREIBUNG_, 'form_beschwerde_beschreibung', $bdcBeschreibung, 0, 0, 'style="min-height:200px;"'.' class="bdcpool" data-bdcpool-name="beschreibung"')/*->setRequired(!empty($pflicht_bm_array['form_beschwerde_beschreibung'])?true:false)*/);
   // $cols_beschwerde[2][1]=new Template_GridTableCol(12,4,3,(!empty($alle_textbausteine_bm) ? Template_SelectInput::init(' ','form_beschwerde_kbau', $alle_textbausteine_bm, -99, false, 'onChange="einfuegen(this.form, this.form.elements[\''.'form_beschwerde_beschreibung\'], this.form.elements[\''.'form_beschwerde_kbau[]\'].value+\'\n\'); this.form.elements[\''.'form_beschwerde_beschreibung\'].focus();"', true, 6)/*->setRequired(!empty($pflicht_bm_array['form_beschwerde_kbau'])?true:false)*/ : ''));
    
    $links_bs70=array();
    while (list($keys, $vals)=@each($alle_textbausteine_bm)) {
        $xir++;
        if (count($alle_textbausteine_bm)>5) {
            $links_bs70[str_replace(array('"', "'", "\r\n", "\n"), array('', '', "\n", "\n"), $vals)."\n"]=$xir.'. '.$keys;
        } else {
            $links_bs70[]=Template_Button::init('', $xir.'. '.$keys,'onClick="einfuegen(this.form, this.form.elements[\''.'form_beschwerde_beschreibung\'], \''.str_replace(array('"', "'", "\r\n", "\n"), array('', '', '\\n', '\\n'), $vals).'\n\'); this.form.elements[\''.'form_beschwerde_beschreibung\'].focus();"','','','','xs')->addCustomClass("w100");
        }
    }
    if (count($alle_textbausteine_bm)>5) {
        $links_bs70=new Template_SelectInput('','',$links_bs70,-1,_KEINE_AUSWAHL_,'onchange="einfuegen(this.form, this.form.elements[\'form_beschwerde_beschreibung\'],this.value); this.form.elements[\'form_beschwerde_beschreibung\'].focus();"');
    }
    $links_bs70_ges=Template_ElementList::init(
        array(
            new Template_ElementList($links_bs70,'','vertical small'),
    ),'','vertical mt-22');
    $cols_beschwerde[2][1]=new Template_GridTableCol(12,4,3,(!empty($alle_textbausteine_bm) ? $links_bs70_ges/*->setRequired(!empty($pflicht_lead_array['form_lead_kbau'])?true:false)*/ : ''));
    
    $teamsTooltip = new Template_Tooltip(
        '',
        Template_IconButton::init('', '', '', 'mdi-microsoft-teams', '', '', 'xs')
            ->setRequest('GET', '_blank', '', '')
            ->addCustomClass('teams_tooltip_btn')
    );
    $teamsTooltip->addCustomClass('teams_tooltip');
    $teamsTooltip->addCustomClass('d-none');
    $teamsTooltip->addCustomClass('mt-22');
    
    $docTooltip = new Template_Tooltip('', new Template_Icon('mdi-book-open'));
    $docTooltip->addCustomClass('doc_tooltip');
    $docTooltip->addCustomClass('d-none');
    $docTooltip->addCustomClass('mt-22');
    
    $productTooltip = new Template_Tooltip('', new Template_Icon('mdi-badge-account-outline'));
    $productTooltip->addCustomClass('product_tooltip');
    $productTooltip->addCustomClass('d-none');
    $productTooltip->addCustomClass('mt-22');
    
    $formsTooltip = new Template_Tooltip(
        'Service-Leitfaden',
        (new Template_IconButton('', '', '', 'mdi-toolbox-outline', '', '', 'xs'))
            ->setRequest(
                'GET',
                $modal_utility_level_2_content,
                'bdc.php',
                '',
                $modal_utility_level_2
            )
            ->addCustomClass('form_tooltip_btn')
    );
    $formsTooltip->addCustomClass('form_tooltip');
    $formsTooltip->addCustomClass('d-none');
    $formsTooltip->addCustomClass('mt-22');
    
    $productSelect = new Template_SelectInput(
        _FAHRZEUG_,
        'form_beschwerde_fahrzeug',
        $fahrzeuglink,
        $fahrzeuglink_selected,
        _KEINE_AUSWAHL_,
        ' class="bdcpool" data-bdcpool-name="fahrzeug"'
    );
    if ($_SESSION['cfg_kunde'] === 'portal') {
        if ((is_array($fahrzeuglink) && in_array($fahrzeuglink_selected, $fahrzeuglink)) || $fahrzeuglink_selected === -1) {
            $productSelect->onDocReady('initProductUserInfoTooltip(this); initProductTeamsLinkTooltip(this); initProductFormLinks(this);');
        }
        $productSelect->setAttribute('onchange', 'initProductUserInfoTooltip(this); initProductTeamsLinkTooltip(this); initProductFormLinks(this);');
    }
    
    $cols_beschwerde[3][0] = new Template_ElementList(
        array(
            $productSelect,
            $teamsTooltip,
            $docTooltip,
            $productTooltip,
            $formsTooltip
        ), '', 'horizontal'
    );
    $cols_beschwerde[3][0]->setAttribute('style', 'flex-wrap: wrap !important');
    
    $cols_beschwerde[3][1]=Template_SelectInput::init(_RECHNUNG_,'form_beschwerde_rechnung', $rechnungslink, $rechnungslink_selected, false,' onChange="'.$js_auf.'" '.' class="bdcpool" data-bdcpool-name="rechnung"')/*->setRequired(!empty($pflicht_bm_array['form_beschwerde_rechnung'])?true:false)*/;
    $cols_beschwerde[4][0]=Template_SelectInput::init(_KORRESPONDENZEN_,'kbezug', $allek, -1, _KEINE_AUSWAHL_)/*->setRequired(!empty($pflicht_bm_array['kbezug'])?true:false)*/;    
    $cols_beschwerde[4][1]='&nbsp;';
    $cols_beschwerde[5][0]=Template_Title::init('Beschwerde qualifizieren',5)->addCustomClass('mt-24');
    
    $cols_beschwerde[6][0]=Template_SelectInput::init(_ART_,'form_beschwerde_art', $arten, (!empty($teniosData) && $_SESSION['design_70']?$teniosData['arten']:''), _KEINE_AUSWAHL_,' class="bdcpool" data-bdcpool-name="art"')/*->setRequired(!empty($pflicht_bm_array['form_beschwerde_art'])?true:false)*/;
    $cols_beschwerde[6][1]=Template_SelectInput::init(_BETRIEB_,'form_beschwerde_standort',$form_kunde_standort, (!empty($teniosData) && isset($teniosData['bdc_location']) && $_SESSION['design_70']?$teniosData['bdc_location']:($cfg_bdc_lagerort_von_benutzerauswahl?$def_ben_lao:$form_kunde_standort_bm)), _KEINE_AUSWAHL_)/*->setRequired(!empty($pflicht_bm_array['form_beschwerde_standort'])?true:false)*/;
    $cols_beschwerde[7][0]=Template_SelectInput::init(_KATEGORIE_,'form_beschwerde_kategorie1', $kategorien, (!empty($teniosData) && $_SESSION['design_70']?$teniosData['kategorie']:''), _KEINE_AUSWAHL_,' class="bdcpool" data-bdcpool-name="kategorie"')/*->setRequired(!empty($pflicht_bm_array['form_beschwerde_kategorie1'])?true:false)*/;
    $cols_beschwerde[8][0]=Template_SelectInput::init(_KATEGORIE_.' 2','form_beschwerde_kategorie2', $kategorien2_bechwerde, (!empty($teniosData) && $_SESSION['design_70']?$teniosData['kategorie2']:''), ($cfg_bdc_kategorie2_multiselect ? false : _KEINE_AUSWAHL_),' class="bdcpool" data-bdcpool-name="kategorie2"', boolval($cfg_bdc_kategorie2_multiselect))/*->setRequired(!empty($pflicht_bm_array['form_beschwerde_kategorie2'])?true:false)*/;
    if (is_array($ap_feld2) && count($ap_feld2)>0) {
        $cols_beschwerde[9][0]=Template_SelectInput::init(_ANSPRECHPARTNER_,'form_kunde_ansprechpartner_id', $ap_feld2, -1000, _KEINE_AUSWAHL_/*,((is_array($ap_feld2) && count($ap_feld2)>0)?'':'disabled="disabled"')*/);
        $cols_beschwerde[9][1]='&nbsp;';
    }
    
    $cols_beschwerde[10][0] = new Template_Divider();
    
    $actionTypeInput = new Template_ElementList(
        array(
            new Template_RadioButton(
                _AKTION_.'/'._ANTWORT_,
                'ticket_action_type',
                'action',
                -99,
                '',
                '',
                '',
                'multi-radiobtn'
            ),
            new Template_RadioButton(
                _ANWEISUNG_,
                'ticket_action_type',
                'instruction',
                -99,
                '',
                '',
                '',
                'multi-radiobtn'
            ),
            new Template_RadioButton(
                _MASSNAHME_,
                'ticket_action_type',
                'measure',
                -99,
                '',
                '',
                '',
                'multi-radiobtn'
            )
        ), '', 'horizontal list-multi-radiobtn'
    );
    $actionTypeInput->onChange('
        const radioInputs = jq1112(this).find(\'.multi-radiobtn input\');
        let hasSelectedType = false;
        radioInputs.each((i) => {
            if (radioInputs[i].checked) {
                hasSelectedType = true;
                return false;
            }
        });
        
        const actionDescriptionEl = document.getElementById(\'ticket_action_description\');
        if (hasSelectedType) {
            actionDescriptionEl.removeAttribute(\'disabled\');
        } else {
            actionDescriptionEl.setAttribute(\'disabled\', \'disabled\');
        }
    ');
    $actionTypeEl = new Template_Label(
        _AKTIONS_ART_,
        $actionTypeInput,
        'multi-radiobtn'
    );
  
    $actionDescriptionInput = new Template_TextArea(
        [
            'Aktionsbeschreibung',
            new Template_Tooltip(
                'Bitte w�hlen Sie zuerst eine Aktionsart aus, bevor Sie eine Beschreibung eingeben k�nnen.',
                new Template_Icon('info', '', 'xs')
            )
        ],
        'ticket_action_description'
    );
    $actionDescriptionInput->onDocReady('document.getElementById(\'ticket_action_description\').setAttribute(\'disabled\', \'disabled\')');
    $actionDescriptionInput->setAttribute('id', 'ticket_action_description');
    $actionDescriptionInput->setAttribute('style', 'min-height: 100px');
    
    $workingTimeEl = new Template_ElementList(
        [
            new Template_NumberInput(
                _ARBEITSZEIT_MINUTEN_,
                'ticket_working_time'
            ),
            Template_Default::fakeInput(
                _ARBEITSZEIT_.' '._GESAMT_,
                zahl_seconds(0, ' ')
            )
        ], '', 'horizontal'
    );
    
    $cols_beschwerde[11][0] = new Template_GridTableCol(
        12, 12, 12,
        Template_Default::Collpasiles(
            false,
            _AKTIVITAETEN_,
            null,
            new Template_ElementList(
                [
                    $actionTypeEl,
                    $actionDescriptionInput,
                    $workingTimeEl
                ], '', 'vertical'
            )
        )
    );
    
    $cols_beschwerde[12][0] = Template_Title::init('Beschwerde zuweisen', 5)->addCustomClass('mt-24');
    
    //$cols_beschwerde[10][0]=Template_SelectInput::init(_BENUTZER_,'form_beschwerde_benutzer', $bens2_online, $benutzer_selected, _KEINE_AUSWAHL_, $js_ben_beschwerde.' class="bdcpool" data-bdcpool-name="betreuer_id"')->setRequired(true);
    
    $cols_temp = array();
    // region D70 Sales feedback (Punkt 52)
    if (isset($_SESSION['design_70']) && $bdcSettings['numbers'][$_GET['startSetting']]['bdc_supervisor'] === 'currentUser') {
        $benutzer_selected = $_SESSION['user_id'];
    }
    // endregion
    $cols_temp[0][0] = Template_SelectInput::init(_BENUTZER_, 'form_beschwerde_benutzer', $bens2_online, $benutzer_selected, _KEINE_AUSWAHL_, $js_ben_beschwerde.' class="bdcpool" data-bdcpool-name="betreuer_id"')->setRequired(true);
    $cols_temp[1][0] = '';
    $cols_beschwerde[13][0] = new Template_GridTable($cols_temp);
    
    $cols_temp = array();
    $cols_temp[0][0] = Template_SelectInput::init(_INFOPEREMAILAN_, 'form_beschwerde_email1', $bens2_online, -1, _KEINE_AUSWAHL_);
    /*->setRequired(!empty($pflicht_bm_array['form_beschwerde_email1'])?true:false)*/
    $cols_temp[1][0] = Template_SelectInput::init(_INFOPEREMAILAN_.' 2', 'form_beschwerde_email2', $bens2_online, -1, _KEINE_AUSWAHL_);
    /*->setRequired(!empty($pflicht_bm_array['form_beschwerde_email2'])?true:false)*/
    $cols_temp[2][0] = Template_TextInput::init(_INFOPEREMAILAN_.' - Freitext', 'form_beschwerde_email', '', 0, ($cfg_stammdaten_lead ? ' placeholder="Freie Adresse"' : ''));
    /*->setRequired(!empty($pflicht_bm_array['form_beschwerde_email'])?true:false)*/
    $cols_beschwerde[13][1] = new Template_GridTable($cols_temp);
    
    //$cols_files=array();
    //$cols_files[]=Template_FileInput::init(_DATEI_.' 1','form_beschwerde_datei1', '', 0)/*->setRequired(!empty($pflicht_bm_array['form_beschwerde_datei1'])?true:false)*/;
    //$cols_files[]=Template_FileInput::init(_DATEI_.' 2','form_beschwerde_datei2', '', 0)/*->setRequired(!empty($pflicht_bm_array['form_beschwerde_datei2'])?true:false)*/;
    //$cols_files[]=Template_FileInput::init(_DATEI_.' 3','form_beschwerde_datei3', '', 0)/*->setRequired(!empty($pflicht_bm_array['form_beschwerde_datei3'])?true:false)*/;
    //$cols_beschwerde_anhang=new Template_ElementList($cols_files,'','vertical');
    $cols_beschwerde_anhang=Template_FileInput::init('','form_beschwerde_datei[]', '', '', '',true,3)->initFileList('','datei',array(),array('form_beschwerde_datei1','form_beschwerde_datei2','form_beschwerde_datei3'),'');
    
    
    
    
	if (isset($_GET['ohnecc'])) {
        $form_beschwerde_tpl['form_beschwerde_cancel']=$form_beschwerde->submit2('',_ABBRECHEN_,'onclick="parent.P4nBoxHelper.closeall();"');
    }
    if ((($_SESSION['crm_version']>61 or $cfg_bdc_grund) and !$cfg_bdc_nl) || $_SESSION['design_70']) {
        $form_beschwerde_tpl['form_beschwerde_grund']=$form_beschwerde->selectinput('form_beschwerde_grund', $alle_bdc_gruende, $grund_selected, _KEINE_AUSWAHL_, $disabled2);
        $inhalt = preg_replace('/\<\!cfg_not_bdc_grund_zusatz1\>.*\<\!cfg_not_bdc_grund_zusatz2\>/Uis','',$inhalt);
        
        $cols_beschwerde_details[0][0] = new Template_SelectInput(
            'BDC '._GRUND_,
            'form_beschwerde_grund',
            $alle_bdc_gruende,
            $grund_selected,
            _KEINE_AUSWAHL_
        );
    }
    if (($cfg_bdc_kanal || $_SESSION['design_70']) && !empty($bdc_kanaele)) {
        $form_beschwerde_tpl['form_beschwerde_bdc_kanal']=$form_beschwerde->selectinput('form_beschwerde_bdc_kanal', $bdc_kanaele, $bdc_kanal_selected, _KEINE_AUSWAHL_, $disabled2);
        $cols_beschwerde_details[1][0] = new Template_SelectInput(
            'BDC '._KANAL_,
            'form_beschwerde_bdc_kanal',
            $bdc_kanaele,
            $bdc_kanal_selected,
            _KEINE_AUSWAHL_
        );
    } else {
        $inhalt= preg_replace('/\<\!bdc_kanal1\>.*\<\!bdc_kanal2\>/Uis','',$inhalt);
    }
    
    if ($cfg_bdc_nl) {
        $form_beschwerde_tpl['form_beschwerde_status']=$form_beschwerde->selectinput('form_beschwerde_status', $statusfeld, 2,false,$disabled2);
    } else {
        $form_beschwerde_tpl['form_beschwerde_status']=$form_beschwerde->selectinput('form_beschwerde_status', array(4 => _BM_STATUS4_),-1,_KEINE_AUSWAHL_, $disabled2);
        $cols_beschwerde[8][1]=Template_SelectInput::init(_STATUS_,'form_beschwerde_status', array(4 => _BM_STATUS4_),(!empty($teniosData) && $_SESSION['design_70']?$teniosData['status']:-1),_KEINE_AUSWAHL_)/*->setRequired(!empty($pflicht_bm_array['form_beschwerde_status'])?true:false)*/;
    }
    $form_beschwerde_tpl['form_beschwerde_fahrzeugsuche']='';
    if ($recht_kfz_schnellsuche) {
        if ($cfg_bdc_fahrzeugsuche || $cfg_leadmanagement_2020) {
            $form_beschwerde_tpl['form_beschwerde_fahrzeugsuche']=link2('<span border="0" alt="" class="icon icon-search">&nbsp;</span>','javascript:void(0);','','','onclick="kfz_schnellsuche(\''.'form_beschwerde_fahrzeug\');"');
        }
    }

    $bw = empty($bm_kategorien5) ? _BMKATEGORIE5_.' '._NICHT_GEFUNDEN_ : false;
    $form_beschwerde_tpl['form_beschwerde_kategorie5'] = $form_beschwerde->selectinput('form_beschwerde_kategorie5', $bm_kategorien5, '', $bw,$disabled2.' class="bdcpool" data-bdcpool-name="kategorie5"');
    $cols_beschwerde[7][1]=Template_SelectInput::init(_BMKATEGORIE5_,'form_beschwerde_kategorie5', $bm_kategorien5, (!empty($teniosData) && $_SESSION['design_70']?$teniosData['kategorien5']:''), $bw,' class="bdcpool" data-bdcpool-name="kategorie5"')/*->setRequired(!empty($pflicht_bm_array['form_beschwerde_kategorie5'])?true:false)*/;

    $bw = empty($bm_kfzmarken) ? _MARKEN_.' '._NICHT_GEFUNDEN_ : _KEINE_AUSWAHL_;
    $form_beschwerde_tpl['form_beschwerde_kfzmarke'] = $form_beschwerde->selectinput('form_beschwerde_kfzmarke', $bm_kfzmarken, -1, $bw, $disabled2.' class="bdcpool" data-bdcpool-name="kfzmarke"');
    // todo: design V7

    if (isset($bdc_einstellungen['moredetails']) && $bdc_einstellungen['moredetails']==1) {
        $form_beschwerde_tpl['form_beschwerde_moredetails']=javas('jq1112(document).ready(function ($) { $("#'.'form_beschwerde_moredetails").trigger("click"); });');
    } else {
        $form_beschwerde_tpl['form_beschwerde_moredetails']='';
    }
    $inhalt=strReplaceInputs($inhalt, $form_beschwerde_tpl, $pflicht_bm_array);
    
    
    
    $p='form_lead_';
    $form_lead=new htmlform();
    
    
    if ($cfg_stammdaten_lead) {
        $res_kamp=$db->select(
            $sql_tab['kampagne'],
            array(
                $sql_tabs['kampagne']['kampagne_id'],
            ),
            $sql_tabs['kampagne']['bezeichnung'].'='.$db->str('BDC-Lead')
        );
        if ($row_kamp=$db->zeile($res_kamp)) {
            $selected_kamp=$row_kamp[0];
        }
    }
    $selected_kamp=((!empty($teniosData) and isset($teniosData['campaign_id']))?$teniosData['campaign_id']:$selected_kamp);

    if (!function_exists('kampagnen_select_js')) {
        //start
        $kats_js4=array();
        $k_kamp=kampagnen_select('form_lead_kampagne', true, $selected_kamp, false, 0, '', $js_kamp2.$disabled2.($cfg_select_suche?' class="select-js" ':''), 'bdc_leads');
        $js_k1='';
        @reset($kats_js4);
        while (list($kakey, $kaval)=@each($kats_js4)) {
            while (list($kakey2, $kaval2)=@each($kaval)) {
                $swert=p4n_mb_string('str_replace', array('"', "'"), '\\\'', '<span class=\'styled-select\'>'.'<select name=\''.'form_lead_kategorie'.'\'>'.$kaval2.'</select></span>');
                $js_k1.='if (this.options[this.selectedIndex].value==\''.$kakey.'\') { document.getElementById(\'kkatid\').innerHTML=\''.$swert.'\'; '.$js_kamp2.' return true; } ';
            }

        }
        $swert=p4n_mb_string('str_replace','"', '\'',$form_lead->selectinput('form_lead_kategorie', $kkats2, '', _BITTE_WAEHLEN_));
        $swert=p4n_mb_string('str_replace',array('"', "'"), '\\\'',$swert);
        $js_k1.=' document.getElementById(\'kkatid\').innerHTML=\''.$swert.'\';';
        $js_k1=' onChange="'.$js_k1.' '.$js_kamp2.'" ';


        $k_kamp=str_replace('{mitkats}', $js_k1, $k_kamp);
        $k_kamp=str_replace('{mitkats_onload}', '', $k_kamp);
        
        $k_kat= '<div id="kkatid">'.$form_lead->selectinput('form_lead_kategorie', $kkats2, '', _BITTE_WAEHLEN_,$disabled2).'</div>';
    } else {
        //$kamp_name='',$kat_name='',$kerg_name='', $def_kamp=-99,$def_kat='',$def_erg=-1,$mitinfo='', $php_file='', $callbacks=array()
        $pflicht=array();
        if (!empty($pflicht_lead_array['form_lead_kampagne'])) {
            $pflicht[]='form_lead_kampagne';
        }
        if (!empty($pflicht_lead_array['form_lead_kategorie'])) {
            $pflicht[]='form_lead_kategorie';
        }
        list($k_kamp,$k_kat,$kkejs)=kampagnen_select_js('form_lead_kampagne','form_lead_kategorie','',$selected_kamp,'',-1,'', 'bdc_leads',array(),$pflicht);
    }
    
    
    if ($_GET['bdc_posteingang']==1) {
        $postfeld['form_lead_beschreibung']=base64_decode($_SESSION['bdc_posteingang_beschreibung']);
        $postfeld['form_lead_betreff']=base64_decode($_SESSION['bdc_posteingang_betreff']);
    }
    $disabled3='';
    if (($cfg_stammdaten_lead or $cfg_bdc_leadbetreff) && $benutzer_selected==-1 && $disabled2=='') {
        $disabled3='disabled="disabled"';
    }
    $zus_leadben_eva='';
    $addJSCheckEva='';
    if ($leadzuordnung_eva_mahag_alle && count($bens2_online_lead_eva)>0) {
        $addJSCheckEva='if (typeof document.getElementById(\'form_lead_benutzer_eva\') != typeof undefined) { if ($(\'#form_lead_eva\').prop(\'checked\') && $(\'#form_lead_betreuer_eva\').val()==-1) { alert(\'Bitte EVA-Benutzer ausw�hlen.\'); return false;  } } ';
        $def_evaben=-1;
        if (!empty($teniosData) && isset($bens2_online_lead_eva[$teniosBetreuer])) {
            $def_evaben=$teniosBetreuer;
        } elseif (intval($merke_evaselbst)>0 && isset($bens2_online_lead_eva[$merke_evaselbst])) {
            $def_evaben=$merke_evaselbst;
        }
        $zus_leadben_eva=$form_lead->selectinput('form_lead_benutzer_eva', $bens2_online_lead_eva, $def_evaben, _KEINE_AUSWAHL_, 'style="display: none" '.$js_ben_lead.' class="bdcpool" data-bdcpool-name="betreuer_id_eva" id="form_lead_betreuer_eva"');
    }
    $form_lead_tpl=array(
        'form_lead_start' => $form_lead->start('form_lead', $phs.(isset($_GET['ohnecc'])?'?ohnecc=1':''), 'POST',true,'id="'.'form_lead_start'.'"'),
        'form_lead_betreff' => $form_lead->textinput('form_lead_betreff', (($cfg_stammdaten_lead or $cfg_bdc_leadbetreff)?'Lead aus BDC':'').$postfeld['form_lead_betreff'], 0, $disabled2.' class="bdcpool" data-bdcpool-name="betreff"').($_GET['bdc_posteingang']==1?$form_lead->hidden('is_bdc_mailbox_request','1'):''),
        'form_lead_beschreibung' => $form_lead->textareainput('form_lead_beschreibung', $postfeld['form_lead_beschreibung'], 0, 2, 'style="height:107px;" '.$disabled2.' class="bdcpool" data-bdcpool-name="beschreibung"'),
        'form_lead_kbau' => (!empty($alle_textbausteine_lead) ? $form_lead->selectinput('form_lead_kbau', $alle_textbausteine_lead, -99, false, $disabled2.'onChange="einfuegen(this.form, this.form.elements[\''.'form_lead_beschreibung\'], this.form.elements[\''.'form_lead_kbau[]\'].value+\'\n\'); this.form.elements[\''.'form_lead_beschreibung\'].focus();"'.''.$disabled2, true, 6) : ''),
        'form_lead_kampagne' => ($k_kamp).($_GET['cti_fremd_id']!=''?$form_kunde->hidden('cti_fremd_id', $_GET['cti_fremd_id']):''),
        'form_lead_benutzer' => $form_lead->selectinput('form_lead_benutzer', $bens2_online_lead, (!empty($teniosData)?$teniosBetreuer:$benutzer_selected), _KEINE_AUSWAHL_,(!empty($teniosData)?'':$disabled2.$disabled3).$js_ben_lead.' class="bdcpool" data-bdcpool-name="betreuer_id" id="form_lead_betreuer"').$zus_leadben_eva,
        'form_lead_leadpool' => $form_lead->checkinput('form_lead_leadpool', (!empty($teniosData)?$teniosLeadpool:(($cfg_stammdaten_lead or $cfg_bdc_leadbetreff)?($benutzer_selected==-1?true:false):false)),'id="form_lead_leadpool" '.$disabled2),
        'form_lead_email2' => $form_anfrage->selectinput('form_lead_email2', $bens2_online_lead,-1,_KEINE_AUSWAHL_,$disabled2),
        'form_lead_email1' => $form_anfrage->selectinput('form_lead_email1', $bens2_online_lead,-1,_KEINE_AUSWAHL_,$disabled2),
        'form_lead_emailan' => $form_lead->textinput('form_lead_emailan', '', 0,$disabled2.($cfg_stammdaten_lead?' placeholder="Freie Adresse"':'')),
        'form_lead_kategorie' => ($k_kat),
        'form_lead_zusatz_kundendaten' => $form_lead->hidden('form_lead_zusatz_kundendaten', '','id="'.'form_lead_zusatz_kundendaten'.'"'.$disabled2),
        'form_lead_submit' => $form_lead->submit('form_lead_submit',_LEAD_.' '._ERSTELLEN_,'id="'.'form_lead_submit'.'" style="display:none"').
        $form_lead->submit2('form_lead_submit2',_LEAD_.' '._ERSTELLEN_,'id="'.'form_lead_submit2'.'" onclick="return false;"'.$disabled2),
        'form_lead_bdc_pool'=>
        ($cfg_bdc_pool?(($from_bdc_pool==true)?$form_lead->submit2('','zur�ck zum Pool','onclick="toBdcPool(\''.'form_lead_start'.'\','.$_GET['getBdcPoolData'].');"'):$form_lead->submit2('','zum Pool','onclick="toBdcPool(\''.'form_lead_start'.'\');"')).
        $form_lead->hidden('','Lead','class="bdcpool" data-bdcpool-name="bdc_flag"').
        $form_lead->hidden('','','class="bdcpool" data-bdcpool-name="datum_eintrag"').
        $form_lead->hidden('','','class="bdcpool" data-bdcpool-name="ersteller_id"').
        $form_lead->hidden('','','class="bdcpool pool_rest"'):'')
        ,
        'form_lead_cancel' => (($from_bdc_pool==true)?'':$form_lead->submit2('',_ABBRECHEN_,'class="cancel_btn"')),
        'form_lead_ende' => /*(function_exists('cacheselect')?javas($cache_js):'')*/$kkejs.$form_lead->ende(),
        'form_lead_lang_fahrzeug' => _FAHRZEUG_
    );
    
    $form70_lead=Template_Form::init('form_lead', $phs.(isset($_GET['ohnecc'])?'?ohnecc=1':''), 'POST',true,'id="'.'form_lead_start'.'"')->setTarget("form_target");
    
    $submit_lead=new Template_Submit('form_lead_submit',_LEAD_.' '._ERSTELLEN_,'id="'.'form_lead_submit'.'"');
    
    $cols_lead=$cols_lead_details=$cols_anlagen=$cols_hidden_lead=array();
    
    $cols_hidden_lead[]=new Template_HiddenInput('form_lead_zusatz_kundendaten', $zusatz_kundendaten,'id="'.'form_lead_zusatz_kundendaten'.'"'.$disabled2);
    
    $cols_lead[0][0]=new Template_Title('Inhalt der Leadanfrage',5);
    $cols_lead[1][0]=new Template_GridTableCol(12,8,9,Template_TextInput::init(_BETREFF_, 'form_lead_betreff', (($cfg_stammdaten_lead or $cfg_bdc_leadbetreff)?'Lead aus BDC':'').$postfeld['form_lead_betreff'], 0, ' class="bdcpool" data-bdcpool-name="betreff"')/*->setRequired(!empty($pflicht_lead_array['form_lead_betreff'])?true:false)*/);

    $cols_lead[2][0]=new Template_GridTableCol(12,8,9,Template_TextArea::init(_BESCHREIBUNG_, 'form_lead_beschreibung', $postfeld['form_lead_beschreibung'], 0, 3, ' class="bdcpool" data-bdcpool-name="beschreibung"')->setAttribute('style','min-height:180px;')/*->setRequired(!empty($pflicht_lead_array['form_lead_beschreibung'])?true:false)*/);
    
    $links_bs70=array();
    while (list($keys, $vals)=@each($alle_textbausteine_lead)) {
        $xir++;
        if (count($alle_textbausteine_lead)>5) {
            $links_bs70[str_replace(array('"', "'", "\r\n", "\n"), array('', '', "\n", "\n"), $vals)."\n"]=$xir.'. '.$keys;
        } else {
            $textBlockBtn = new Template_Button('', $xir.'. '.$keys, 'onClick="einfuegen(this.form, this.form.elements[\''.'form_lead_beschreibung\'], \''.str_replace(array('"', "'", "\r\n", "\n"), array('', '', '\\n', '\\n'), $vals).'\n\'); this.form.elements[\''.'form_lead_beschreibung\'].focus();"', '', '', '', 'xs');
            $textBlockBtn->addCustomClass('w100');
            $textBlockBtn->setAttribute('style', 'text-align: left');
            $textBlockTooltip = new Template_Tooltip($keys, $textBlockBtn);
            $textBlockTooltip->setAttribute('style', 'width: 100% !important');
            $links_bs70[] = $textBlockTooltip;
        }
    }
    if (count($alle_textbausteine_lead)>5) {
        $links_bs70=new Template_SelectInput('','',$links_bs70,-1,_KEINE_AUSWAHL_,'onchange="einfuegen(this.form, this.form.elements[\'form_lead_beschreibung\'],this.value); this.form.elements[\'form_lead_beschreibung\'].focus();"');
    }
    $links_bs70_ges=Template_ElementList::init(
        array(
            new Template_ElementList($links_bs70,'','vertical small'),
    ),'','vertical mt-22');
    $cols_lead[2][1]=new Template_GridTableCol(12,4,3,(!empty($alle_textbausteine_lead) ? $links_bs70_ges/*->setRequired(!empty($pflicht_lead_array['form_lead_kbau'])?true:false)*/ : ''));
    
    $cols_lead[4][0]=Template_Title::init('Lead qualifizieren',5)->addCustomClass('mt-24');
    
    // D70 - AVAG - Kampagne / Kategorie Inputs ausblenden.
    $cols_lead[5][1]=new Template_GridTableCol(12,3,3,$k_kamp);
    if ($cfg_avag_de) {
        $cols_lead[5][1]->addCustomClass('d-none');
    }
    $cols_lead[5][2]=new Template_GridTableCol(12,3,3,$k_kat);
    if ($cfg_avag_de) {
        $cols_lead[5][2]->addCustomClass('d-none');
    }
    
    $cols_lead[10][0] = new Template_GridTableCol(
        12, 12, 12,
        Template_Title::init('Lead zuweisen', 5)->addCustomClass('mt-24')
    );
    if ($cfg_avag_de) {
        $cols_lead[10][0]->addCustomClass('d-none');
    }
    
    $cols_lead[11][0] = new Template_GridTableCol(
        12, 6, 6,
        array(
            Template_Switch::init(
                _LEADPOOL_,
                'form_lead_leadpool',
                (!empty($teniosData) ? $teniosLeadpool : (($cfg_stammdaten_lead or $cfg_bdc_leadbetreff) ? ($benutzer_selected == -1 ? true : false) : false)),
                'id="form_lead_leadpool" onclick=" if (this.checked) { $(\'#form_lead_betreuer\').parent().css(\'display\',\'none\'); } else { $(\'#form_lead_betreuer\').parent().css(\'display\',\'\'); } " '
            )->setRequired(true),
            javas('if ($("#form_lead_leadpool")[0].checked) { $("#form_lead_betreuer").parent().css("display","none"); } else { $("#form_lead_betreuer").parent().css("display",""); }')
        )
    );
    if ($cfg_avag_de) {
        $cols_lead[11][0]->addCustomClass('d-none');
    }
    
    $cols_lead[11][1]=Template_SelectInput::init(_INFOPEREMAILAN_,'form_lead_email1', $bens2_online_lead,-1,_KEINE_AUSWAHL_)/*->setRequired(!empty($pflicht_lead_array['form_lead_email1'])?true:false)*/;

    $cols_lead[12][1]=Template_SelectInput::init(_INFOPEREMAILAN_.' 2','form_lead_email2', $bens2_online_lead,-1,_KEINE_AUSWAHL_)/*->setRequired(!empty($pflicht_lead_array['form_lead_email2'])?true:false)*/;
    
    if (isset($_SESSION['design_70']) && $leadDefaultUser) {
        $benutzer_selected = $_SESSION['user_id'];
    }
    
    $cols_lead[13][0] = new Template_ElementList(
        array(
            Template_SelectInput::init(
                _BENUTZER_,
                'form_lead_benutzer',
                $bens2_online_lead,
                (!empty($teniosData) ? $teniosBetreuer : $benutzer_selected),
                _KEINE_AUSWAHL_,
                $js_ben_lead.' class="bdcpool" data-bdcpool-name="betreuer_id" id="form_lead_betreuer" '
            )->setRequired(true)
        ), '', 'horizontal nowrap'
    );
    if ($cfg_avag_de) {
        $cols_lead[13][0]->addCustomClass('d-none');
    }
    $cols_lead[13][1]=Template_TextInput::init(_INFOPEREMAILAN_.' - Freitext','form_lead_emailan', '', 0,($cfg_stammdaten_lead?' placeholder="Freie Adresse"':''))/*->setRequired(!empty($pflicht_lead_array['form_lead_emailan'])?true:false)*/;
    
    
    if ($_SESSION['crm_version']>67) {
        $inhalt= p4n_mb_string('str_replace',array('<!bdc_lead_dateien1>','<!bdc_lead_dateien2>'),'',$inhalt);  
        $form_lead_tpl['form_lead_datei1']=$form_lead->dateiinput('form_lead_datei1', '', 0, $disabled2).($bdcDatei!='' && $_GET['bdc_posteingang']==1?$form_lead->checkinput('form_lead_datei1_bdcp_checkbox',true).$form_lead->hidden('form_lead_datei1_bdcp_path',$bdcDatei).' '.link2($bdcDateiName1,$bdcDatei, '', '', 'target="_blank"'):'');
        $form_lead_tpl['form_lead_datei2']=$form_lead->dateiinput('form_lead_datei2', '', 0, $disabled2).($bdcDatei2!='' && $_GET['bdc_posteingang']==1?$form_lead->checkinput('form_lead_datei2_bdcp_checkbox',true).$form_lead->hidden('form_lead_datei2_bdcp_path',$bdcDatei2).' '.link2($bdcDateiName2,$bdcDatei2, '', '', 'target="_blank"'):'');
        $form_lead_tpl['form_lead_datei3']=$form_lead->dateiinput('form_lead_datei3', '', 0, $disabled2).($bdcDatei3!='' && $_GET['bdc_posteingang']==1?$form_lead->checkinput('form_lead_datei3_bdcp_checkbox',true).$form_lead->hidden('form_lead_datei3_bdcp_path',$bdcDatei3).' '.link2($bdcDateiName3,$bdcDatei3, '', '', 'target="_blank"'):'');
    
       // $cols_files=array();
       // $cols_files[]=Template_FileInput::init(_DATEI_.' 1','form_lead_datei1', '', 0)/*->setRequired(!empty($pflicht_lead_array['form_lead_datei1'])?true:false)*/;
        //$cols_files[]=Template_FileInput::init(_DATEI_.' 2','form_lead_datei2', '', 0)/*->setRequired(!empty($pflicht_lead_array['form_lead_datei2'])?true:false)*/;
        //$cols_files[]=Template_FileInput::init(_DATEI_.' 3','form_lead_datei3', '', 0)/*->setRequired(!empty($pflicht_lead_array['form_lead_datei3'])?true:false)*/;
       // $cols_lead_anhang=new Template_ElementList($cols_files,'','vertical');
        
        $cols_lead_anhang=Template_FileInput::init('','form_lead_datei[]', '', '', '',true,3)->initFileList('','datei',array(),array('form_lead_datei1','form_lead_datei2','form_lead_datei3'),'');
    
        
    } else {
        $inhalt= preg_replace('/\<\!bdc_lead_dateien1\>.*\<\!bdc_lead_dateien2\>/Uis','',$inhalt);
    }
    
    if (isset($_GET['ohnecc'])) {
        $form_lead_tpl['form_lead_cancel']=$form_lead->submit2('',_ABBRECHEN_,'onclick="parent.P4nBoxHelper.closeall();"');
    }
    if ((($_SESSION['crm_version']>61 or $cfg_bdc_grund) and !$cfg_bdc_nl) || $_SESSION['design_70']) {
        $form_kunde_standort_lead_def = $postfeld['form_kunde_standort'];
        if ($form_kunde_standort_lead_def < 0 && $cfg_stammdaten_lead) {
            $form_kunde_standort_lead_def = $_SESSION['user_standard_lagerort'];
        }
		if ($cfg_bdc_lagerort_stdlao and intval($_SESSION['user_standard_lagerort'])>0) {
			$form_kunde_standort_lead_def = $_SESSION['user_standard_lagerort'];
		}
        $form_lead_tpl['form_lead_standort']=$form_lead->selectinput('form_lead_standort', $form_kunde_standort_lead, ((!empty($teniosData) and isset($teniosData['bdc_location']))?$teniosData['bdc_location']:($cfg_bdc_lagerort_von_benutzerauswahl?$def_ben_lao:$form_kunde_standort_lead_def)), _KEINE_AUSWAHL_, 'onChange="selstao=\'\'; selstao=this.value;" '.$disabled2.' class="bdcpool" data-bdcpool-name="standort"');
        $cols_lead[5][0]=new Template_GridTableCol(12,6,6,Template_SelectInput::init(_LAGERORT_,'form_lead_standort', $form_kunde_standort_lead, ((!empty($teniosData) and isset($teniosData['bdc_location']))?$teniosData['bdc_location']:($cfg_bdc_lagerort_von_benutzerauswahl?$def_ben_lao:$form_kunde_standort_lead_def)), _KEINE_AUSWAHL_, 'onChange="selstao=\'\'; selstao=this.value;" '.' class="bdcpool" data-bdcpool-name="standort"')/*->setRequired(!empty($pflicht_lead_array['form_lead_standort'])?true:false)*/);
    }
	if (is_array($cols_lead[5])) {
    	ksort($cols_lead[5]);
	}
    
    if (($_SESSION['crm_version']>61 or $cfg_bdc_grund || $cfg_bdc_nl) || $_SESSION['design_70']) {
         $form_lead_tpl['form_lead_grund']=$form_lead->selectinput('form_lead_grund', $alle_bdc_gruende, ((!empty($teniosData) and isset($teniosData['bdc_reason']))?$teniosData['bdc_reason']:($cfg_stammdaten_lead && !empty($grund_selected_lead)?$grund_selected_lead:$grund_selected)), _KEINE_AUSWAHL_,$disabled2.' class="bdcpool" data-bdcpool-name="grund"');
         $cols_lead_details[0][0]=new Template_GridTableCol(12,6,6,Template_SelectInput::init('BDC '._GRUND_,'form_lead_grund', $alle_bdc_gruende, ((!empty($teniosData) and isset($teniosData['bdc_reason']))?$teniosData['bdc_reason']:($cfg_stammdaten_lead && !empty($grund_selected_lead)?$grund_selected_lead:$grund_selected)), _KEINE_AUSWAHL_,' class="bdcpool" data-bdcpool-name="grund"')/*->setRequired(!empty($pflicht_lead_array['form_lead_grund'])?true:false)*/);
    }
    $bdc_lead_source_standard='BDC';
    if (isset($cfg_leadsource_standard)) {
        $bdc_lead_source_standard=$cfg_leadsource_standard;
    }
    $form_lead_tpl['form_lead_fahrzeugsuche']='';
    if ((isset($bdc_einstellungen['lead_art']) && $bdc_einstellungen['lead_art']==1) || $_SESSION['design_70']) {
        $form_lead_tpl['form_lead_sparte'] = $form_lead->selectinput('form_lead_sparte', $sparte, ((!empty($teniosData) and isset($teniosData['bdc_sparte']))?$teniosData['bdc_sparte']:$getfeld['sparte']), _KEINE_AUSWAHL_);
        $cols_lead[6][0]=new Template_GridTableCol(12,6,6,Template_SelectInput::init(($cfg_nutzensparte ? _SPARTE_ : _ART_),'form_lead_sparte', $sparte, ((!empty($teniosData) and isset($teniosData['bdc_sparte']))?$teniosData['bdc_sparte']:$getfeld['sparte']), _KEINE_AUSWAHL_)/*->setRequired(!empty($pflicht_lead_array['form_lead_sparte'])?true:false)*/);
    } else {
        $inhalt= preg_replace('/\<\!bdc_lead_art1\>.*\<\!bdc_lead_art2\>/Uis','',$inhalt);
    }
    $inhalt= p4n_mb_string('str_replace',array('<!bdc_lead_art1>','<!bdc_lead_art2>'),'',$inhalt); 
    if ((isset($bdc_einstellungen['lead_kanal']) && $bdc_einstellungen['lead_kanal']==1) || $_SESSION['design_70']) {
		$def_lead_kanal='';
		if (isset($bdc_einstellungen['lead_kanal_def']) and $bdc_einstellungen['lead_kanal_def']!='') {
			$def_lead_kanal=$bdc_einstellungen['lead_kanal_def'];
		}
        $form_lead_tpl['form_lead_kanal'] = $form_lead->selectinput('form_lead_kanal', $kanal, ((!empty($teniosData) and isset($teniosData['bdc_channel']))?$teniosData['bdc_channel']:$def_lead_kanal), false,' class="bdcpool" data-bdcpool-name="kanal"');
        $cols_lead[7][1]=new Template_GridTableCol(12,6,6,Template_SelectInput::init(_KANAL_,'form_lead_kanal', $kanal, ((!empty($teniosData) and isset($teniosData['bdc_channel']))?$teniosData['bdc_channel']:$def_lead_kanal), false,' class="bdcpool" data-bdcpool-name="kanal"')/*->setRequired(!empty($pflicht_lead_array['form_lead_kanal'])?true:false)*/);
    } else {
        $inhalt= preg_replace('/\<\!bdc_lead_kanal1\>.*\<\!bdc_lead_kanal2\>/Uis','',$inhalt);
    }
    $inhalt= p4n_mb_string('str_replace',array('<!bdc_lead_kanal1>','<!bdc_lead_kanal2>'),'',$inhalt); 
    if ((isset($bdc_einstellungen['lead_quelle']) && $bdc_einstellungen['lead_quelle']==1) || $_SESSION['design_70']) {
        $form_lead_tpl['form_lead_alle_source'] = $form_lead->selectinput('form_lead_alle_source', $alle_source, ((!empty($teniosData) and isset($teniosData['bdc_source'])) ? $teniosData['bdc_source'] : $bdc_lead_source_standard), false, ' class="bdcpool" data-bdcpool-name="source" ');
        $cols_lead[6][1]=new Template_GridTableCol(12,6,6,Template_SelectInput::init(_QUELLE_,'form_lead_alle_source', $alle_source, ((!empty($teniosData) and isset($teniosData['bdc_source']))?$teniosData['bdc_source']:$bdc_lead_source_standard), false,' class="bdcpool" data-bdcpool-name="source"')/*->setRequired(!empty($pflicht_lead_array['form_lead_alle_source'])?true:false)*/);
    } else {
        $inhalt= preg_replace('/\<\!bdc_lead_quelle1\>.*\<\!bdc_lead_quelle2\>/Uis','',$inhalt);
    }
    $inhalt= p4n_mb_string('str_replace',array('<!bdc_lead_quelle1>','<!bdc_lead_quelle2>'),'',$inhalt); 
    if ((isset($bdc_einstellungen['lead_marke']) && $bdc_einstellungen['lead_marke']==1) || $_SESSION['design_70']) {
        $form_lead_tpl['form_lead_marke'] = $form_lead->selectinput('form_lead_marke', $marke, ((!empty($teniosData) and isset($teniosData['bdc_brand']))?$teniosData['bdc_brand']:''), false,' class="bdcpool" data-bdcpool-name="marke"');
        $cols_lead[7][0]=new Template_GridTableCol(12,6,6,Template_SelectInput::init(_MARKEN_,'form_lead_marke', $marke, ((!empty($teniosData) and isset($teniosData['bdc_brand']))?$teniosData['bdc_brand']:''), false,' class="bdcpool" data-bdcpool-name="marke"')/*->setRequired(!empty($pflicht_lead_array['form_lead_marke'])?true:false)*/);
    } else {
        $inhalt= preg_replace('/\<\!bdc_lead_marke1\>.*\<\!bdc_lead_marke2\>/Uis','',$inhalt);
    }
    if (($cfg_lead_absatzgruppe || $_SESSION['crm_version_float']>=61300) && (isset($bdc_einstellungen['lead_absatzgruppe']) && $bdc_einstellungen['lead_absatzgruppe']==1)) {// || $_SESSION['design_70'] todo
        $form_lead_tpl['form_lead_absatzgruppe'] = $form_lead->selectinput('form_lead_absatzgruppe', $alle_absatzgruppe, '', _KEINE_AUSWAHL_,' class="bdcpool" data-bdcpool-name="absatzgruppe"');
        $cols_lead[8][1]=new Template_GridTableCol(12,6,6,Template_SelectInput::init(_LEAD_.' '._ABSATZGRUPPE_,'form_lead_absatzgruppe', $alle_absatzgruppe, '', _KEINE_AUSWAHL_,' class="bdcpool" data-bdcpool-name="absatzgruppe"')/*->setRequired(!empty($pflicht_lead_array['form_lead_alle_source'])?true:false)*/);
    } else {
        $inhalt= preg_replace('/\<\!bdc_lead_absatzgruppe1\>.*\<\!bdc_lead_absatzgruppe2\>/Uis','',$inhalt);
        if (is_array($ap_feld2) && count($ap_feld2)>0) {
            $cols_lead[8][1]='&nbsp;';
        }
    }
	if (is_array($cols_lead[7])) {
	    ksort($cols_lead[7]);
	}
    
    if (is_array($ap_feld2) && count($ap_feld2)>0) {
        $cols_lead[8][0] = new Template_GridTableCol(
            12, 6, 6,
            new Template_SelectInput(
                _ANSPRECHPARTNER_,
                'form_kunde_ansprechpartner_id',
                $ap_feld2,
                $postfeld['form_kunde_ansprechpartner_id'],
                _KEINE_AUSWAHL_
            )
        );
        // D70 - AVAG - AP Input ausblenden.
        if ($cfg_avag_de) {
            $cols_lead[8][0]->addCustomClass('d-none');
        }
    }
    
    //$cols_lead[9][1]='&nbsp;';
    if (is_array($cols_lead[8])) {
	    ksort($cols_lead[8]);
	}
    
    $fahrzeugfeld_counter=0;
    $inhalt= p4n_mb_string('str_replace',array('<!bdc_lead_marke1>','<!bdc_lead_marke2>'),'',$inhalt); 
    if ((isset($bdc_einstellungen['lead_fahrzeug']) && $bdc_einstellungen['lead_fahrzeug']==1) || $_SESSION['design_70']) {
		$fahrzeuglink2=$fahrzeuglink;
		if ($cfg_lead_fahrzeugbesitz) {
			$fahrzeuglink2=array('-1' => '');
		}
        $form_lead_tpl['form_lead_fahrzeug'] = $form_lead->selectinput('form_lead_fahrzeug', $fahrzeuglink2, $fahrzeuglink_selected, false,' class="bdcpool" data-bdcpool-name="fahrzeug"');
        $carDefault = $fahrzeuglink_selected;
        if ($cfg_avag_de && !empty($rememberedCarId)) {
            $carDefault = $rememberedCarId;
        }
        $cols_lead[3][0] = new Template_GridTableCol(12, 6, 6, Template_SelectInput::init(_FAHRZEUG_, 'form_lead_fahrzeug', $fahrzeuglink, $carDefault, false, ' class="bdcpool" data-bdcpool-name="fahrzeug"'));
        $fahrzeugfeld_counter++;
        if ($recht_kfz_schnellsuche) {
            if ($cfg_bdc_fahrzeugsuche || $cfg_leadmanagement_2020) {
                $form_lead_tpl['form_lead_fahrzeugsuche']=link2('<span border="0" alt="" class="icon icon-search">&nbsp;</span>','javascript:void(0);','','','onclick="kfz_schnellsuche(\''.'form_lead_fahrzeug\');"');
            }
        }
    } else {
        $inhalt= preg_replace('/\<\!bdc_lead_fahrzeug1\>.*\<\!bdc_lead_fahrzeug2\>/Uis','',$inhalt);
    }
    $inhalt=p4n_mb_string('str_replace',array('<!bdc_lead_fahrzeug1>','<!bdc_lead_fahrzeug2>'),'',$inhalt);
    
	if ($cfg_lead_fahrzeugbesitz) {
		$form_lead_tpl['form_lead_fahrzeug2'] = $form_lead->selectinput('form_lead_fahrzeug2', $fahrzeuglink, $fahrzeuglink_selected, false,' class="bdcpool" data-bdcpool-name="fahrzeug"');
        $cols_lead[3][1]=new Template_GridTableCol(12,6,6,Template_SelectInput::init(_FAHRZEUG_.' '._IM_BESITZ_,'form_lead_fahrzeug2', $fahrzeuglink, $fahrzeuglink_selected, false,' class="bdcpool" data-bdcpool-name="fahrzeug"'));
        $fahrzeugfeld_counter++;
	} else {
        $inhalt= preg_replace('/\<\!bdc_lead_besitzfahrzeug1\>.*\<\!bdc_lead_besitzfahrzeug2\>/Uis','',$inhalt);
    }
    $inhalt=p4n_mb_string('str_replace',array('<!bdc_lead_besitzfahrzeug1>','<!bdc_lead_besitzfahrzeug2>'),'',$inhalt); 
    $addJSCheckVehicle='';
    if ($fahrzeugfeld_counter==2) {
        $addJSCheckVehicle='var $fahrzeug1 = $("#form_lead_start select[name=\'form_lead_fahrzeug\']"); var $fahrzeug2 = $("#form_lead_start select[name=\'form_lead_fahrzeug2\']"); if ($fahrzeug1.val() == "-1" && $fahrzeug2.val() != "-1" ) { if (!confirm("Wenn Sie ein Fahrzeug im Besitz w�hlen und kein Fahrzeug aus dem Bestand des AH, wird das Fahrzeug im Besitz automatisiert als Fahrzeuginteresse gesetzt. Entfernen Sie ggf. das Fahrzeug im Besitz. (OK = weiter, Abbrechen = Korrektur)")) { return false; } } ';
    }
    
    if (($cfg_bdc_kanal || $_SESSION['design_70']) && !empty($bdc_kanaele)) {
        $form_lead_tpl['form_lead_bdc_kanal']=$form_lead->selectinput('form_lead_bdc_kanal', $bdc_kanaele, $bdc_kanal_selected, _KEINE_AUSWAHL_);
        $cols_lead_details[1][0]=new Template_GridTableCol(12,6,6,Template_SelectInput::init('BDC '._KANAL_,'form_lead_bdc_kanal', $bdc_kanaele, $bdc_kanal_selected, _KEINE_AUSWAHL_)/*->setRequired(!empty($pflicht_lead_array['form_lead_bdc_kanal'])?true:false)*/);
    } else {
        $inhalt= preg_replace('/\<\!bdc_kanal1\>.*\<\!bdc_kanal2\>/Uis','',$inhalt);
    }
    $inhalt=str_replace('{art_sparte}', ($cfg_nutzensparte ? _SPARTE_ : _ART_), $inhalt);
    
    $cols_lead[12][0] = new Template_GridTableCol(12, 6, 6, new Template_Text('&nbsp;'));
    if ($cfg_avag_de) {
        $cols_lead[12][0]->addCustomClass('d-none');
    }
    if (isset($_GET['eva']) || $leadzuordnung_eva_mahag_alle) {
        $inhalt= preg_replace('/\<\!noteva1\>.*\<\!noteva2\>/Uis','',$inhalt);
        $form_lead_tpl['form_lead_eva'] = $form_lead->checkinput('form_lead_eva', isset($_GET['eva']),'onClick="'
        . 'if (typeof document.getElementById(\'form_lead_leadpool\') != typeof undefined) { 
            if (typeof document.getElementById(\'form_lead_benutzer_eva\') != typeof undefined) {
                
            } else if ($(\'#form_lead_betreuer\').val()==-1) { '
                . 'this.checked=false; return false; '
            . '} '    
            . 'if ($(\'#form_lead_leadpool\').prop(\'checked\')) { '
                . '$(\'#form_lead_leadpool\').click(); '
            . '} '
            . 'var checked=this.checked; '
            . 'if (checked) { '
                . 'document.getElementById(\'form_lead_leadpool\').disabled=\'disabled\'; 
                
                document.getElementById(\'form_lead_betreuer_eva\').style=\'\';
                document.getElementById(\'form_lead_betreuer\').style=\'display: none\';
                '
            . '} else { '
                . 'document.getElementById(\'form_lead_leadpool\').disabled=\'\'; 
                document.getElementById(\'form_lead_betreuer_eva\').style=\'display: none\';
                document.getElementById(\'form_lead_betreuer\').style=\'\';
                '
            . '} '
            . 'document.getElementById(\'form_lead_leadpool\').checked=\'\'; '
        . '}" '
        . 'id="'.'form_lead_eva" '.$disabled2);
        $cols_lead[12][0]=new Template_Switch('Eva Export','form_lead_eva', isset($_GET['eva']),'onClick="'
        . 'if (typeof document.getElementById(\'form_lead_leadpool\') != typeof undefined) { '
            . 'if (typeof document.getElementById(\'form_lead_benutzer_eva\') != typeof undefined) {
                
            } else if ($(\'#form_lead_betreuer\').val()==-1) { '
                . 'this.checked=false; return false; '
            . '} '    
            . 'if ($(\'#form_lead_leadpool\').prop(\'checked\')) { '
                . '$(\'#form_lead_leadpool\').click(); '
            . '} '
            . 'var checked=this.checked; '
            . 'if (checked) { '
                . 'document.getElementById(\'form_lead_leadpool\').disabled=\'disabled\';
                document.getElementById(\'form_lead_betreuer_eva\').style=\'\';
                document.getElementById(\'form_lead_betreuer\').style=\'display: none\';
                '
            . '} else { '
                . 'document.getElementById(\'form_lead_leadpool\').disabled=\'\';
                document.getElementById(\'form_lead_betreuer_eva\').style=\'display: none\';
                document.getElementById(\'form_lead_betreuer\').style=\'\';
                '
            . '} '
            . 'document.getElementById(\'form_lead_leadpool\').checked=\'\'; '
        . '}" '
        . 'id="'.'form_lead_eva" '.$disabled2);
    } else {
        $inhalt= preg_replace('/\<\!eva1\>.*\<\!eva2\>/Uis','',$inhalt);
    }
    $inhalt= p4n_mb_string('str_replace',array('<!noteva1>','<!noteva2>','<!eva1>','<!eva2>'),'',$inhalt);
	if (is_array($cols_lead[12])) {
    	ksort($cols_lead[12]);
	}
    
    if (!is_array($cfg_bdc_bevorzugter_kontakt1) || count($cfg_bdc_bevorzugter_kontakt1)<=0) {
        $cfg_bdc_bevorzugter_kontakt1= array(_BRIEF_, _EMAIL_, _SMS_, _FAX_);
    }
    if (!is_array($cfg_bdc_bevorzugter_kontakt2) || count($cfg_bdc_bevorzugter_kontakt2)<=0) {
        $cfg_bdc_bevorzugter_kontakt2= array(_TELEFON2_ . ' ' . _PRIVAT_, _MOBILFON_ . ' ' . _PRIVAT_, _TELEFON2_ . ' ' . _GESCHAEFTLICH_, _MOBILFON_ . ' ' . _GESCHAEFTLICH_);
    }
    
    $temp=$cfg_bdc_bevorzugter_kontakt1;
    $cfg_bdc_bevorzugter_kontakt1=array();
    if (is_array($temp) && count($temp)>0) {
        foreach ($temp as $val) {
            $cfg_bdc_bevorzugter_kontakt1[$val]=$val;
        }
    }
    $temp=$cfg_bdc_bevorzugter_kontakt2;
    $cfg_bdc_bevorzugter_kontakt2=array();
    if (is_array($temp) && count($temp)>0) {
        foreach ($temp as $val) {
            $cfg_bdc_bevorzugter_kontakt2[$val]=$val;
        }
    }
    $temp=array();
    
    if ($cfg_bdc_nl) {
        $inhalt= preg_replace('/\<\!not\_bdc\_nl1\>.*\<\!not\_bdc\_nl2\>/Uis','',$inhalt);
        $form_lead_tpl['cfg_bdc_nl']='1';
        $form_lead_tpl['lang_keine_auswahl']=_KEINE_AUSWAHL_;
        
        $form_lead_tpl['form_lead_kfzkategorie']=$form_lead->selectinput('form_lead_kfzkategorie', $fahrzeugkategorie, -1, _KEINE_AUSWAHL_,'onchange="bdc_kfzkat('.$js_kat.', this.value); bdc_neugebraucht_func('.$js_kat2.', this.value)"'.$disabled2);
       
        $form_lead_tpl['form_lead_kfzmodell']=$form_lead->selectinput('form_lead_kfzmodell', array(), -1, _KEINE_AUSWAHL_,'id="bdc_kfzmodell"'.$disabled2);
        $form_lead_tpl['form_lead_kfznwgw']=$form_lead->selectinput('form_lead_kfznwgw', array(), -1, _KEINE_AUSWAHL_,'id="bdc_neugebraucht"'.$disabled2);
        
        $form_lead_tpl['form_lead_datum']=$form_lead->datuminput('form_lead_datum', date('d.m.Y'),$disabled2);
        $form_lead_tpl['form_lead_abteilung']=$form_lead->selectinput('form_lead_abteilung', $alle_abteilungen,-99,false,$disabled2);
        $form_lead_tpl['form_lead_anrufquelle']=$form_lead->selectinput('form_lead_anrufquelle', $arten,-99,false,$disabled2);
        $form_lead_tpl['form_lead_prioritaet']=$form_lead->selectinput('form_lead_prioritaet', $priority_bez, $priority_auswahl,false,$disabled2);
        $form_lead_tpl['form_lead_status']=$form_lead->selectinput('form_lead_status', $status_bez_lead, 2,false,$disabled2);
        $form_lead_tpl['form_lead_wvldatum']=$form_lead->datuminput('form_lead_wvldatum', '',$disabled2);
        $form_lead_tpl['form_lead_bevorzugterkontakt1']=$form_lead->selectinput('form_lead_bevorzugterkontakt1', $cfg_bdc_bevorzugter_kontakt1, -1, false, $disabled2, true, 3);
        $form_lead_tpl['form_lead_bevorzugtekontaktzeit1']=$form_lead->selectinput('form_lead_bevorzugtekontaktzeit1', $lalbevorzugtekontaktzeit1, -1,false,$disabled2);
        $form_lead_tpl['form_lead_wunschdatum1']=$form_lead->textinput('form_lead_wunschdatum1', '', 20,$disabled2);
        $form_lead_tpl['form_lead_bemerkung']=$form_lead->textareainput('form_lead_bemerkung', '', 0, 2,$disabled2);
        $form_lead_tpl['form_lead_bevorzugterkontakt2']=$form_lead->selectinput('form_lead_bevorzugterkontakt2', $cfg_bdc_bevorzugter_kontakt2, -1, false, $disabled2, true, 3);
        $form_lead_tpl['form_lead_bevorzugtekontaktzeit2']=$form_lead->selectinput('form_lead_bevorzugtekontaktzeit2', $lalbevorzugtekontaktzeit2, -1,false,$disabled2);
    } else {
        $form_lead_tpl['cfg_bdc_nl']='';
        $inhalt= preg_replace('/\<\!bdc\_nl1\>.*\<\!bdc\_nl2\>/Uis','',$inhalt);
    }
    
    if (isset($bdc_einstellungen['moredetails']) && $bdc_einstellungen['moredetails']==1) {
        $form_lead_tpl['form_lead_moredetails']=javas('jq1112(document).ready(function ($) { $("#'.'form_lead_moredetails").trigger("click"); });');
    } else {
        $form_lead_tpl['form_lead_moredetails']='';
    }
    $inhalt=strReplaceInputs($inhalt, $form_lead_tpl, $pflicht_lead_array);
    
    if (($_SESSION['crm_version']>61 or $cfg_bdc_grund) and !$cfg_bdc_nl) {
        //$inhalt=strReplaceInputs($inhalt,array('cfg_bdc_grund'=>'1'));
        
        $cols_sonstiges=$cols_sonstiges_details=$cols_hidden_sonstiges=array();
        
        $p='form_sonstiges_';
        $form_sonstiges=new htmlform();
        $form_sonstiges_tpl=array(
            'form_sonstiges_start' => $form_sonstiges->start('form_sonstiges', $phs.(isset($_GET['ohnecc'])?'?ohnecc=1':''), 'POST',false,'id="'.'form_sonstiges_start'.'"'),
            'form_sonstiges_grund'=>$form_sonstiges->selectinput('form_sonstiges_grund', $alle_bdc_gruende, $grund_selected, _KEINE_AUSWAHL_),
            'form_sonstiges_standort' => $form_lead->selectinput('form_sonstiges_standort', $form_kunde_standort, ($cfg_bdc_lagerort_von_benutzerauswahl?$def_ben_lao:$postfeld['form_kunde_standort']), _KEINE_AUSWAHL_),
            'form_sonstiges_zusatz_kundendaten' => $form_sonstiges->hidden('form_sonstiges_zusatz_kundendaten', '','id="'.'form_sonstiges_zusatz_kundendaten'.'"'),
            'form_sonstiges_submit' => $form_sonstiges->submit('form_sonstiges_submit',_SPEICHERN_,'id="'.'form_sonstiges_submit'.'" style="display:none"').
            $form_sonstiges->submit2('form_sonstiges_submit2',_SPEICHERN_,'id="'.'form_sonstiges_submit2'.'" onclick="return false;"'),
            'form_sonstiges_cancel' => $form_sonstiges->submit2('',_ABBRECHEN_,'class="cancel_btn"'),
            'form_sonstiges_ende' => $form_sonstiges->ende(),
        );
        if ($cfg_bdc_kanal && !empty($bdc_kanaele)) {
            $form_sonstiges_tpl['form_sonstiges_bdc_kanal']=$form_sonstiges->selectinput('form_sonstiges_bdc_kanal', $bdc_kanaele, $bdc_kanal_selected, _KEINE_AUSWAHL_);
            $cols_sonstiges_details[1][0]=Template_SelectInput::init('BDC '._KANAL_,'form_sonstiges_bdc_kanal', $bdc_kanaele, $bdc_kanal_selected, _KEINE_AUSWAHL_);
        } else {
            $inhalt= preg_replace('/\<\!bdc_kanal1\>.*\<\!bdc_kanal2\>/Uis','',$inhalt);
        }
        $inhalt=strReplaceInputs($inhalt,$form_sonstiges_tpl, $pflicht_sonstiges_array);
        
        $cols_sonstiges_details[0][0]=Template_SelectInput::init('BDC '._GRUND_,'form_sonstiges_grund', $alle_bdc_gruende, $grund_selected, _KEINE_AUSWAHL_)/*->setRequired(!empty($pflicht_bm_array['form_beschwerde_grund'])?true:false)*/;
        ksort($cols_sonstiges_details);
        $form70_sonstiges=Template_Form::init('form_sonstiges', $phs.(isset($_GET['ohnecc'])?'?ohnecc=1':''), 'POST', false, 'id="'.'form_sonstiges_start'.'"')->setTarget("form_target");
        $submit_sonstiges=new Template_Submit('form_sonstiges_submit',_SPEICHERN_,'id="'.'form_sonstiges_submit'.'"');
        $cancel_sonstiges=new Template_Button('',_ABBRECHEN_,'class="cancel_btn"');

        

        $cols_hidden_sonstiges[]=new Template_HiddenInput('form_sonstiges_zusatz_kundendaten', $zusatz_kundendaten,'id="'.'form_sonstiges_zusatz_kundendaten'.'"');

        $cols_sonstiges[0][0]=Template_Title::init('Anfrage qualifizieren',5);
        $cols_sonstiges[1][0]=Template_SelectInput::init(_LAGERORT_,'form_sonstiges_standort', $form_kunde_standort, ($cfg_bdc_lagerort_von_benutzerauswahl?$def_ben_lao:$postfeld['form_kunde_standort']), _KEINE_AUSWAHL_);
        if (is_array($ap_feld2) && count($ap_feld2)>0) {
            $cols_sonstiges[1][1]=Template_SelectInput::init(_ANSPRECHPARTNER_,'form_kunde_ansprechpartner_id', $ap_feld2, $postfeld['form_kunde_ansprechpartner_id'], _KEINE_AUSWAHL_/*,((is_array($ap_feld2) && count($ap_feld2)>0)?'':'disabled="disabled"')*/);
        }
    } else {
        //$inhalt=strReplaceInputs($inhalt,array('cfg_bdc_grund'=>'0'));
        $inhalt= preg_replace('/\<\!cfg_bdc_grund_zusatz1\>.*\<\!cfg_bdc_grund_zusatz2\>/Uis','',$inhalt);
    }
    $inhalt=strReplaceInputs($inhalt,array('leadanlegen_pflicht'=>$addJSCheckVehicle.$addJSCheckEva.js_pflichtfeld_replace($pflicht_lead_array)));
    $inhalt=strReplaceInputs($inhalt,array('anfragenanlegen_pflicht'=>js_pflichtfeld_replace($pflicht_anfragen_array)));
    $inhalt=strReplaceInputs($inhalt,array('bmanlegen_pflicht'=>js_pflichtfeld_replace($pflicht_bm_array)));
    $inhalt=strReplaceInputs($inhalt,array('sonstigesanlegen_pflicht'=>js_pflichtfeld_replace($pflicht_sonstiges_array)));
    $handbuch = '<span class="handbuch" style="display:none;">'.link2('', 'handbuch_suche.php?source='.basename($phs), 'overlib.gif', '', 'target="_blank"').'</span>';
    
    if (!empty($bdcSettings) && isset($bdcSettings['numbers'])) {
        foreach ($bdcSettings['numbers'] as $number => $settings) {
            if (isset($rechte_['bdc_settings'.$number])) {
                $settings_new = array();
                if ($settings['bdc_brand']!='') {
                    $settings_new[] = $settings['bdc_brand'];
                }
                if ($settings['bdc_sparte']!='') {
                    $settings_new[] = $settings['bdc_sparte'];
                }
                if ($settings['bdc_source']!='') {
                    $settings_new[] = $settings['bdc_source'];
                }
                if ($settings['bdc_channel']!='') {
                    $settings_new[] = $settings['bdc_channel'];
                }
                $name =(($cfg_bdc_kurz_link_name || $_SESSION['crm_version_float']>=61000) && $settings['name']?$settings['name']: _SHORTLINK_.': '.$number);
                $title = $name;
                if (!empty($settings_new)) {
                    $title = implode(' / ', $settings_new);
                }
                $stid_link = 0;
                if ($postfeld['form_kunde_stdid']>0) {
                    $stid_link = $postfeld['form_kunde_stdid'];
                } elseif ($getfeld['stid'] > 0) {
                    $stid_link = $getfeld['stid'];
                }
                if ($postfeld['form_kunde_ansprechpartner_id']>0) {
                    $_SESSION['bdcSelectedAp']=$postfeld['form_kunde_ansprechpartner_id'];
//                    $stid_link.='&form_kunde_ansprechpartner_id='.$postfeld['form_kunde_ansprechpartner_id'];
                }
                if ($_GET['startSetting'] == $number) {
                    $bdc_settings_links[] = $name;
                } else {
                   $bdc_settings_links[] = link2($name, '?startSetting='.$number.'&stid='.$stid_link.($extraLinkData!=''?'&extraLinkData='.$extraLinkData:''), '', '', 'title="'.$title.'"');
                }
            }
        }
    }
    if (!empty($bdc_settings_links)) {
        $handbuch = ' / <span>'.implode(' | ', $bdc_settings_links).'</span>'.$handbuch;
    }
    if (array_key_exists('bdc_einstellungen', $rechte_) && !isset($_GET['ohnecc'])) {
        $inhalt=strReplaceInputs($inhalt,array('einstellungen'=> ' / '.link2(_EINSTELLUNGEN_,$phs.'?bdc_einstellungen=1').$handbuch));
        $bdc_einstellungen_btn = Template_IconButton::init('', '', '', 'settings', '', '', 'md', 'transparent-blue')
            ->setRequest(
                'GET',
                'modal_settings_inhalt',
                'bdc.php',
                'bdc_einstellungen=1&bdc_tab_settings=1'
            );
    } else {
        $inhalt=strReplaceInputs($inhalt,array('einstellungen'=> $handbuch));
    }
    
    
    
    if ($_SESSION['design_70']) {
        Modern_Helper_Request::requestStart();
        
        echo Template_Script::init('bdc')->getHtml();

        
        $line1=$postfeld['form_kunde_anrede'].' '.$postfeld['form_kunde_titel'].' '.$postfeld['form_kunde_vorname'].' '.$postfeld['form_kunde_name'];
        if ($postfeld['form_kunde_firma']!='') {
           $line1=_FIRMA_.': '.$postfeld['form_kunde_firma'].($postfeld['form_kunde_ap_bezeichnung']!=''?' ('.$postfeld['form_kunde_ap_bezeichnung'].', '.$postfeld['form_kunde_ap_vorname'].')':'');
        }

        $kundenakte=Template_Module::Kundenakte($postfeld['form_kunde_stdid'],$postfeld['form_kunde_ansprechpartner_id']);
        if ($kundenakte!=null)
        $inner=$kundenakte->addCustomClass('mt-16 mb-16');
        $inner=new Template_ElementList($inner);

        $contentHeader = Template_Default::ModalHeaderCollapsileSubText(array(Template_Title::init('Kundenanliegen erfassen',1)),null,$bdc_einstellungen_btn,$line1,$inner, false, true, false);
        
        $bdc_einstellungen_beschwerde_btn=Template_IconButton::init('','','','settings','','','md','transparent-blue')->setRequest($art='GET','modal_settings_inhalt',$url='bdc.php',$werte='bdc_einstellungen=1&bdc_tab_settings=4');
        if (!$cfg_avag_de) {
            $bdc_einstellungen_lead_btn=Template_IconButton::init('','','','settings','','','md','transparent-blue')->setRequest($art='GET','modal_settings_inhalt',$url='bdc.php',$werte='bdc_einstellungen=1&bdc_tab_settings=2');
        }
        $bdc_einstellungen_anfrage_btn=Template_IconButton::init('','','','settings','','','md','transparent-blue')->setRequest($art='GET','modal_settings_inhalt',$url='bdc.php',$werte='bdc_einstellungen=1&bdc_tab_settings=3');
        if (($_SESSION['crm_version']>61 or $cfg_bdc_grund) and !$cfg_bdc_nl) {
            $bdc_einstellungen_sonstiges_btn=Template_IconButton::init('','','','settings','','','md','transparent-blue')->setRequest($art='GET','modal_settings_inhalt',$url='bdc.php',$werte='bdc_einstellungen=1&bdc_tab_settings=5');
        }
        $modal_settings_inhalt = Template_ElementList::init('', 'modal_settings_inhalt');
        $modal_settings = new Template_Modal('modal_settings', array($bdc_einstellungen_btn,$bdc_einstellungen_lead_btn,$bdc_einstellungen_anfrage_btn,$bdc_einstellungen_beschwerde_btn,$bdc_einstellungen_sonstiges_btn), $modal_settings_inhalt,$footer=null,$other='',$modal=false, $header=false,null,true);
        $modal_settings->setRight();
        
        $contentHeader_lead = Template_Default::ModalHeaderCollapsileSubText(
            [new Template_Title(_LEAD_.' '._ERFASSEN_, 1)],
            null,
            $bdc_einstellungen_lead_btn,
            $line1,
            $inner,
            false,
            true,
            false
        );

        $form70_lead->addElement($cols_hidden_lead);
        
        $card=Template_Default::Card('Neues Lead',null,array(Template_GridTable::init($cols_lead)));
        $form70_lead->addElement($card);
        
        $cols_lead_details=Template_GridTable::init($cols_lead_details);
        /*$triggerbtn_lead_details=Template_IconButton::init('','','','expand_more',$href='',$abfrage='', $sizeClass = 'sm');
        $collapsile_lead_details=new Template_Collapsiles(Template_Default::Card(_DETAILS_,$triggerbtn_lead_details,$cols_lead_details),false);
        $collapsile_lead_details->setTrigger($triggerbtn_lead_details);
        $collapsile_lead_details->setBody($cols_lead_details);*/
        
        $collapsile_lead_details=Template_Default::CollapsilesCard(false,_DETAILS_,null,$cols_lead_details);
        $collapsile_lead_details->addCustomClass('bdc_lead_details_collapsile');
        
        $form70_lead->addElement($collapsile_lead_details);
        
        /*$triggerbtn_lead_anhang=Template_IconButton::init('','','','expand_more',$href='',$abfrage='', $sizeClass = 'sm');
        $collapsile_anhang=new Template_Collapsiles(Template_Default::Card(_DATEIEN_,$triggerbtn_lead_anhang,$cols_lead_anhang),false);
        $collapsile_anhang->setTrigger($triggerbtn_lead_anhang);
        $collapsile_anhang->setBody($cols_lead_anhang);*/
        
        //$collapsile_anhang=Template_Default::CollapsilesCard(false,_DATEIEN_,null,$cols_lead_anhang);
        
        $form70_lead->addElement($cols_lead_anhang);
        $form70_lead->addElement(Template_Default::ModalFooter($submit_lead));
        
        if ($cfg_avag_de && !empty($rememberedCarId)) {
            $form70_lead->addElement(new Template_HiddenInput('remembered_car_id', $rememberedCarId));
        }
        
        $form70_lead->requiredOr(array('#form_lead_leadpool','#form_lead_betreuer'));
        if (isset($_GET['bdc_tab_settings2'])) {
            Modern_Helper_Request::requestStart();
            
            $form70_lead->findAndDisable($form70_lead);
            echo Template_Module::FormSettings($form70_lead,$vorauswahl=true,$sichtbarkeit=true,$pflicht=true,false,$modal=false,$modal_title='',null,array('checkFormChange'=>true,'ausschluss'=>array('form_lead_leadpool','form_lead_benutzer')))->getHtml();
            exit;
        }
        if (isset($_GET['schnellauswahl']) && $_GET['schnellauswahl']=='lead') {
            Modern_Helper_Request::requestStart();
            echo $contentHeader_lead->getHtml();
            if (isset($_GET['startSetting'])) {
                $form70_lead->loadSettings = true;
                $form70_lead->settingsConfig = [
                    'ignore' => [
                        'default' => true,
                        'visibility' => false,
                        'required' => true,
                        'readonly' => true
                    ]
                ];
            } else {
                $form70_lead->loadSettings = true;
            }
            
            echo $form70_lead->getHtml();
            echo $modal_settings->getHtml();
            
            // D70 - AVAG - Hide empty rows, will be refactored with new form settings for campaign / category / AP.
            if ($cfg_avag_de) {
                echo javas('avag_leadFormHideEmptyElements();');
            }
            exit;
        }
        
        $contentHeader_anfrage = Template_Default::ModalHeaderCollapsileSubText(
            [new Template_Title(_ANFRAGE_.' '._ERFASSEN_, 1)],
            null,
            $bdc_einstellungen_anfrage_btn,
            $line1,
            $inner,
            false,
            true,
            false
        );
        $form70_anfrage->addElement($cols_hidden_anfrage);
        
        $card=Template_Default::Card('Neue Anfrage',null,array(Template_GridTable::init($cols_anfrage)));
        $form70_anfrage->addElement($card);
        
        $cols_anfrage_details=Template_GridTable::init($cols_anfrage_details);
        /*
        $triggerbtn_anfrage_details=Template_IconButton::init('','','','expand_more',$href='',$abfrage='', $sizeClass = 'sm');
        $collapsile_anfrage_details=new Template_Collapsiles(Template_Default::Card(_DETAILS_,$triggerbtn_anfrage_details,$cols_anfrage_details),false);
        $collapsile_anfrage_details->setTrigger($triggerbtn_anfrage_details);
        $collapsile_anfrage_details->setBody($cols_anfrage_details);*/
        
        $collapsile_anfrage_details=Template_Default::CollapsilesCard(false,_DETAILS_,null,$cols_anfrage_details);
        
        $form70_anfrage->addElement($collapsile_anfrage_details);
        
        /*$triggerbtn_anfrage_anhang=Template_IconButton::init('','','','expand_more',$href='',$abfrage='', $sizeClass = 'sm');
        $collapsile_anhang=new Template_Collapsiles(Template_Default::Card(_DATEIEN_,$triggerbtn_anfrage_anhang,$cols_anfrage_anhang),false);
        $collapsile_anhang->setTrigger($triggerbtn_anfrage_anhang);
        $collapsile_anhang->setBody($cols_anfrage_anhang);*/
        
        //$cols_anfrage_anhang=Template_Default::CollapsilesCard(false,_DATEIEN_,null,$cols_anfrage_anhang);
        
        $form70_anfrage->addElement($cols_anfrage_anhang);
        $form70_anfrage->addElement(Template_Default::ModalFooter($submit_anfrage));

        
        if (isset($_GET['bdc_tab_settings3'])) {
            Modern_Helper_Request::requestStart();
            echo Template_Module::FormSettings($form70_anfrage,$vorauswahl=true,$sichtbarkeit=array('form_anfrage_benutzer'=>true),$pflicht=array('form_anfrage_benutzer'=>true),false,$modal=false,$modal_title='',null,array('checkFormChange'=>true))->getHtml();
            exit;
        }
        if (isset($_GET['schnellauswahl']) && $_GET['schnellauswahl']=='anfrage') {
            Modern_Helper_Request::requestStart();
            echo $contentHeader_anfrage->getHtml();
            if (isset($_GET['startSetting'])) {
                $form70_anfrage->loadSettings = false;
            } else {
                $form70_anfrage->loadSettings = true;
            }
            echo $form70_anfrage->getHtml();
            echo $modal_settings->getHtml();
            exit;
        }
        
        
        


        $form70_beschwerde->addElement($cols_hidden_beschwerde);
        
        $card=Template_Default::Card('Neue Beschwerde',null,array(Template_GridTable::init($cols_beschwerde)));
        $form70_beschwerde->addElement($card);
        
        $cols_beschwerde_details=Template_GridTable::init($cols_beschwerde_details);
        /*$triggerbtn_beschwerde_details=Template_IconButton::init('','','','expand_more',$href='',$abfrage='', $sizeClass = 'sm');
        $collapsile_beschwerde_details=new Template_Collapsiles(Template_Default::Card(_DETAILS_,$triggerbtn_beschwerde_details,$cols_beschwerde_details),false);
        $collapsile_beschwerde_details->setTrigger($triggerbtn_beschwerde_details);
        $collapsile_beschwerde_details->setBody($cols_beschwerde_details);*/
        
        $collapsile_beschwerde_details=Template_Default::CollapsilesCard(false,_DETAILS_,null,$cols_beschwerde_details);
        
 
        $form70_beschwerde->addElement($collapsile_beschwerde_details);
        
        /*$triggerbtn_beschwerde_anhang=Template_IconButton::init('','','','expand_more',$href='',$abfrage='', $sizeClass = 'sm');
        $collapsile_anhang=new Template_Collapsiles(Template_Default::Card(_DATEIEN_,$triggerbtn_beschwerde_anhang,$cols_beschwerde_anhang),false);
        $collapsile_anhang->setTrigger($triggerbtn_beschwerde_anhang);
        $collapsile_anhang->setBody($cols_beschwerde_anhang);*/
        
        //$collapsile_anhang=Template_Default::CollapsilesCard(false,_DATEIEN_,null,$cols_beschwerde_anhang);
        
        $form70_beschwerde->addElement($cols_beschwerde_anhang);
        $form70_beschwerde->addElement(Template_Default::ModalFooter($submit_beschwerde));
        
        $contentHeader_beschwerde = Template_Default::ModalHeaderCollapsileSubText(
            [new Template_Title(_BESCHWERDE_.' '._ERFASSEN_, 1)],
            null,
            $bdc_einstellungen_beschwerde_btn,
            $line1,
            $inner,
            false,
            true,
            false
        );
        
        if (isset($_GET['bdc_tab_settings4'])) {
            Modern_Helper_Request::requestStart();
            echo Template_Module::FormSettings($form70_beschwerde,$vorauswahl=true,$sichtbarkeit=array('form_beschwerde_benutzer'=>true),$pflicht=array('form_beschwerde_benutzer'=>true),false,$modal=false,$modal_title='',null,array('checkFormChange'=>true))->getHtml();
            exit;
        }
        
        if (isset($_GET['schnellauswahl']) && $_GET['schnellauswahl'] === 'beschwerde') {
            Modern_Helper_Request::requestStart();
            echo $contentHeader_beschwerde->getHtml();
            if (isset($_GET['startSetting'])) {
                // Load form settings (mainly for required fields) but ignore defaults.
                $form70_beschwerde->loadSettings = true;
                $form70_beschwerde->settingsConfig = [
                    'ignore' => [
                        'default' => true,
                        'visibility' => false,
                        'required' => false,
                        'readonly' => false
                    ]
                ];
            } else {
                $form70_beschwerde->loadSettings = true;
            }
            echo $form70_beschwerde->getHtml();
            echo $modal_settings->getHtml();
            exit;
        }
        
        
        if (($_SESSION['crm_version']>61 or $cfg_bdc_grund) and !$cfg_bdc_nl) {
            
        
            $form70_sonstiges->addElement($cols_hidden_sonstiges);
 
            $card=Template_Default::Card('Sonstiges',null,array(Template_GridTable::init($cols_sonstiges)));
            $form70_sonstiges->addElement($card);
 
            $cols_sonstiges_details=Template_GridTable::init($cols_sonstiges_details);
            /*$triggerbtn_sonstiges_details=Template_IconButton::init('','','','expand_more',$href='',$abfrage='', $sizeClass = 'sm');
            $collapsile_sonstiges_details=new Template_Collapsiles(Template_Default::Card(_DETAILS_,$triggerbtn_sonstiges_details,$cols_sonstiges_details),false);
            $collapsile_sonstiges_details->setTrigger($triggerbtn_sonstiges_details);
            $collapsile_sonstiges_details->setBody($cols_sonstiges_details);*/

            $collapsile_sonstiges_details=Template_Default::Card(_DETAILS_,null,$cols_sonstiges_details);


            $form70_sonstiges->addElement($collapsile_sonstiges_details);

            /*$triggerbtn_sonstiges_anhang=Template_IconButton::init('','','','expand_more',$href='',$abfrage='', $sizeClass = 'sm');
            $collapsile_anhang=new Template_Collapsiles(Template_Default::Card(_DATEIEN_,$triggerbtn_sonstiges_anhang,$cols_sonstiges_anhang),false);
            $collapsile_anhang->setTrigger($triggerbtn_sonstiges_anhang);
            $collapsile_anhang->setBody($cols_sonstiges_anhang);*/

            //$collapsile_anhang=Template_Default::CollapsilesCard(false,_DATEIEN_,null,$cols_sonstiges_anhang);

        
            $form70_sonstiges->addElement(Template_Default::ModalFooter($submit_sonstiges));



           // $line1=$postfeld['form_kunde_anrede'].' '.$postfeld['form_kunde_titel'].' '.$postfeld['form_kunde_vorname'].' '.$postfeld['form_kunde_name'].($postfeld['form_kunde_ap_bezeichnung']!=''?' ('.$postfeld['form_kunde_ap_bezeichnung'].', '.$postfeld['form_kunde_ap_vorname'].')':'');
            $contentHeader_sonstiges= Template_Default::ModalHeaderCollapsileSubText(array(Template_Title::init('Anliegen erfassen',1)),null,$bdc_einstellungen_sonstiges_btn,$line1,$inner);

            if (isset($_GET['bdc_tab_settings5'])) {
                Modern_Helper_Request::requestStart();
                echo Template_Module::FormSettings($form70_sonstiges,true,true,true,false,$modal=false,$modal_title='',null,array('checkFormChange'=>true))->getHtml();
                exit;
            }
            if (isset($_GET['schnellauswahl']) && $_GET['schnellauswahl']=='sonstiges') {
                Modern_Helper_Request::requestStart();
                echo $contentHeader_sonstiges->getHtml();
                echo $form70_sonstiges->getHtml();
                echo $modal_settings->getHtml();
                exit;
            }
        }
        
        echo $contentHeader->getHtml();
        
        $settings = $bdcDataSetter->createViewCards($_REQUEST, $_SESSION['design_70']);
        
        $unfinishedInstructions = $unfinishedTickets = $unfinishedLeads = [];
        if (!empty($_GET['stid'])) {
            $ticketFields = [
                'troubleticket_id',
                'benutzer_id',
                'datum',
                'betreff',
                'status',
                'datum_status0',
                'datum_status1',
                'datum_status2',
                'datum_status3',
                'datum_status4',
                'beschwerdezeit',
                'art2'
            ];
            
            $unfinishedInstructions = (new Troubleticket_Data())
                ->getByConditions(
                    [
                        'art2' => 'Anfrage',
                        'status' => ['!=' => 4],
                        'stammdaten_id' => $_GET['stid']
                    ],
                    'datum',
                    'DESC',
                    'AND',
                    $ticketFields
                );
            $unfinishedTickets = (new Troubleticket_Data())
                ->getByConditions(
                    [
                        'art2' => ['!=' => 'Anfrage'],
                        'status' => ['!=' => 4],
                        'stammdaten_id' => $_GET['stid']
                    ],
                    'datum',
                    'DESC',
                    'AND',
                    $ticketFields
                );
            $unfinishedLeads = (new Lead_Data())
                ->getByConditions(
                    [
                        'status' => ['!=' => 5],
                        'stammdaten_id' => $_GET['stid']
                    ],
                    '',
                    '',
                    'AND',
                    [
                        'kampagne_lead_id',
                        'additionaldata',
                        'erfassungsdatum'
                    ]
                );
            
            $customer = new Customer_Data($_GET['stid']);
            $customer->load(['mandant']);
            $clientId = $customer['mandant'];
            
            $ticketStatusList = Troubleticket_Data::getStatusList();
            
            $leadCategoryList = Plugin_System_LeadTracker::getLeadCategoryList();
        }
        
        // region Leads collapsile.
        $newLeadBtn = new Template_IconTextButton('', ucfirst(_NEUES_).' '._LEAD_, '', 'add', '', '', 'xs', 'white', 'quadratic');
        $newLeadBtn->setRequest(
            'GET',
            'modal_lead_inhalt',
            'bdc.php',
            'schnellauswahl=lead&stid='.$_GET['stid']
        );
        // D70 - AVAG - Hide new lead btn in bdc, will be refactored.
        if ($cfg_avag_de) {
            $newLeadBtn->addCustomClass('d-none');
        }
        $newLeadBtn->setAttribute('style', 'width: 160px');
        
        $modal_lead_inhalt = new Template_ElementList('', 'modal_lead_inhalt');
        $modal_lead = new Template_Modal('modal_lead', $newLeadBtn, array($modal_lead_inhalt));
        $modal_lead->setRight();
        
        $cols = $settings[0];
        $cols->addCustomClass('mt-8');
        $cols = new Template_Elementlist($cols);
        
        $unfinishedLeadsCount = count($unfinishedLeads);
        if ($unfinishedLeadsCount) {
            $tooltipContent = '';
            foreach ($unfinishedLeads as $lead) {
                $subject = Lead_Data::getAdditionalDataValueForKey(_BETREFF_, $lead['additionaldata']);
                $leadStage = Lead_Helper::getLeadStageById($lead['kampagne_lead_id']);
                $_ = [
                    $db->unixdatetime($lead['erfassungsdatum']),
                    ': ',
                    $subject,
                    ' - ',
                    $clientId,
                    '-',
                    $lead['kampagne_lead_id'],
                    ' ('.($leadCategoryList[$leadStage] ?: '-').')',
                    '<br>'
                ];
                $tooltipContent .= implode('', $_);
            }
            $unfinishedLeadsContent = new Template_Tooltip(
                $tooltipContent,
                new Template_ElementList(
                    [
                        new Template_Icon('mdi-eye-outline'),
                        Template_Text::init($unfinishedLeadsCount.' '._OFFENE_.' '._LEADS_, -1, ['bold'])
                            ->setAttribute('class', 'color-white')
                    ], '', 'd-flex align-items-center'
                )
            );
        } else {
            $unfinishedLeadsContent = Template_ElementList::init(
                [
                    new Template_Icon('mdi-eye-off-outline'),
                    Template_Text::init(_KEINE_.' '._OFFENEN_.' '._LEADS_, -1, ['bold'])
                        ->setAttribute('class', 'color-white')
                ], '', 'd-flex align-items-center'
            );
        }
        $unfinishedLeadsContent->setAttribute('style', 'gap: 8px; padding-left: 10px');
        
        $leadsBtn = new Template_IconTextButton(
            '',
            $unfinishedLeadsContent->getHtml(),
            '',
            '',
            '',
            '',
            'xs',
            'blue',
            'quadratic'
        );
        if ($unfinishedLeadsCount) {
            $leadsBtn->setRequest(
                'GET',
                '_tab',
                'stammdaten_main.php',
                ['nav=lead&id='.$_GET['stid'].'&remember_get_params=1']
            );
        }
        
        $collapsile2 = Template_Default::CollapsilesCard(
            ($_GET['schnellauswahl2'] == 'lead' ? true : false),
            ucfirst(_NEUES_).' '._LEAD_.' '._ERSTELLEN_,
            new Template_ElementList(
                [
                    $leadsBtn,
                    $newLeadBtn
                ], '', 'horizontal'
            ),
            $cols,
            array('transparent')
        );
        echo $collapsile2->getHtml();
        // endregion
        
        // region Instructions collapsile.
        $newInstructionBtn = new Template_IconTextButton('', ucfirst(_NEUE_).' '._ANFRAGE_, '', 'add', '', '', 'xs', 'white', 'quadratic');
        $newInstructionBtn->setRequest(
            'GET',
            'modal_anfrage_inhalt',
            'bdc.php',
            'schnellauswahl=anfrage&stid='.$_GET['stid']
        );
        $newInstructionBtn->setAttribute('style', 'width: 160px');
        
        $modal_anfrage_inhalt = new Template_ElementList('', 'modal_anfrage_inhalt');
        $modal_anfrage = new Template_Modal('modal_anfrage', $newInstructionBtn, array($modal_anfrage_inhalt));
        $modal_anfrage->setRight();
        
        $cols = $settings[1];
        $cols->addCustomClass('mt-8');
        $cols = new Template_Elementlist($cols);
        
        $unfinishedInstructionsCount = count($unfinishedInstructions);
        if ($unfinishedInstructionsCount) {
            $tooltipContent = '';
            foreach ($unfinishedInstructions as $instruction) {
                $_ = [
                    $db->unixdatetime($instruction['beschwerdezeit'] ?: $instruction['datum']),
                    ': ',
                    $instruction['betreff'],
                    ' - ',
                    $clientId,
                    '-',
                    $instruction['troubleticket_id'],
                    ' ('.$ticketStatusList[$instruction['status']].')',
                    '<br>'
                ];
                $tooltipContent .= implode('', $_);
            }
            
            $unfinishedInstructionsContent = new Template_Tooltip(
                $tooltipContent,
                new Template_ElementList(
                    [
                        new Template_Icon('mdi-eye-outline'),
                        Template_Text::init($unfinishedInstructionsCount.' '._OFFENE_.' '._ANFRAGEN_, -1, ['bold'])
                            ->setAttribute('class', 'color-white')
                    ], '', 'd-flex align-items-center'
                )
            );
        } else {
            $unfinishedInstructionsContent = Template_ElementList::init(
                [
                    new Template_Icon('mdi-eye-off-outline'),
                    Template_Text::init(_KEINE_.' '._OFFENEN_.' '._ANFRAGEN_, -1, ['bold'])
                        ->setAttribute('class', 'color-white')
                ], '', 'd-flex align-items-center'
            );
        }
        $unfinishedInstructionsContent->setAttribute('style', 'gap: 8px; padding-left: 10px');
        
        $instructionsBtn = new Template_IconTextButton(
            '',
            $unfinishedInstructionsContent->getHtml(),
            '',
            '',
            '',
            '',
            'xs',
            'blue',
            'quadratic'
        );
        if ($unfinishedInstructionsCount) {
            $instructionsBtn->setRequest(
                'GET',
                '_tab',
                'stammdaten_main.php',
                ['nav=BM&id='.$_GET['stid'].'&filter=1,2,3&filter_bm_an=Anfrage&remember_get_params=1']
            );
        }
        if (p4n_mb_string('strpos', $_SESSION['rechte_reiter'], 'nav=BM') !== false) {
            $collapsile2 = Template_Default::CollapsilesCard(
                ($_GET['schnellauswahl2'] == 'anfrage' ? true : false),
                ucfirst(_NEUE_).' '._ANFRAGE_.' '._ERSTELLEN_,
                new Template_ElementList(
                    [
                        $instructionsBtn,
                        $newInstructionBtn
                    ], '', 'horizontal'
                ),
                $cols,
                array('transparent')
            );
            echo $collapsile2->getHtml();
        }
        // endregion
        
        // region Tickets collapsile.
        $newTicketBtn = new Template_IconTextButton('', ucfirst(_NEUE_).' '._BESCHWERDE_, '', 'add', '', '', 'xs', 'white', 'quadratic');
        $newTicketBtn->setRequest(
            'GET',
            'modal_beschwerde_inhalt',
            'bdc.php',
            'schnellauswahl=beschwerde&stid='.$_GET['stid']
        );
        $newTicketBtn->setAttribute('style', 'width: 160px');
        
        $modal_beschwerde_inhalt = new Template_ElementList('', 'modal_beschwerde_inhalt');
        $modal_beschwerde = new Template_Modal('modal_beschwerde', $newTicketBtn, array($modal_beschwerde_inhalt));
        $modal_beschwerde->setRight();
        
        $cols = $settings[2];
        $cols->addCustomClass('mt-8');
        $cols = new Template_Elementlist($cols);
        
        $unfinishedTicketsCount = count($unfinishedTickets);
        if ($unfinishedTicketsCount) {
            $tooltipContent = '';
            foreach ($unfinishedTickets as $ticket) {
                $_ = [
                    $db->unixdatetime($ticket['beschwerdezeit'] ?: $ticket['datum']),
                    ': ',
                    $ticket['betreff'],
                    ' - ',
                    $clientId,
                    '-',
                    $ticket['troubleticket_id'],
                    ' ('.$ticketStatusList[$ticket['status']].')',
                    '<br>'
                ];
                $tooltipContent .= implode('', $_);
            }
            
            $unfinishedTicketsContent = new Template_Tooltip(
                $tooltipContent,
                new Template_ElementList(
                    [
                        new Template_Icon('mdi-eye-outline'),
                        Template_Text::init($unfinishedTicketsCount.' '._OFFENE_.' '._BESCHWERDEN_, -1, ['bold'])
                            ->setAttribute('class', 'color-white')
                    ], '', 'd-flex align-items-center'
                )
            );
        } else {
            $unfinishedTicketsContent = Template_ElementList::init(
                [
                    new Template_Icon('mdi-eye-off-outline'),
                    Template_Text::init(_KEINE_.' '._OFFENEN_.' '._BESCHWERDEN_, -1, ['bold'])
                        ->setAttribute('class', 'color-white')
                ], '', 'd-flex align-items-center'
            );
        }
        $unfinishedTicketsContent->setAttribute('style', 'gap: 8px; padding-left: 10px');
        
        $ticketsBtn = new Template_IconTextButton(
            '',
            $unfinishedTicketsContent->getHtml(),
            '',
            '',
            '',
            '',
            'xs',
            'blue',
            'quadratic'
        );
        if ($unfinishedTicketsCount) {
            $ticketsBtn->setRequest(
                'GET',
                '_tab',
                'stammdaten_main.php',
                ['nav=BM&id='.$_GET['stid'].'&filter=1,2,3&filter_bm_an=Beschwerde&remember_get_params=1']
            );
        }
        if (p4n_mb_string('strpos', $_SESSION['rechte_reiter'], 'nav=BM') !== false) {
            $collapsile2 = Template_Default::CollapsilesCard(
                ($_GET['schnellauswahl2'] == 'beschwerde' ? true : false),
                ucfirst(_NEUE_).' '._BESCHWERDE_.' '._ERSTELLEN_,
                new Template_ElementList(
                    [
                        $ticketsBtn,
                        $newTicketBtn
                    ], '', 'horizontal'
                ),
                $cols,
                array('transparent')
            );
            echo $collapsile2->getHtml();
        }
        // endregion
        
        
        $nur_includen=true;
        include_once('serviceannahme.php');
        unset($nur_includen);
        
        $feld_temp['kname']='';
        $feld_temp['bdc']=1;
        $test_dummy=sc_eintrag_neu($feld_temp);
        
      //  echo $test_dummy;exit;
        if ($test_dummy==$postfeld['form_kunde_stdid']) {
            $neu= Template_IconTextButton::init($name = '', $value = 'Neues Sonstiges', $other = '', $image = 'add',$href='',$abfrage='', $sizeClass = 'xs', $colorClass = 'blue', $formClass='quadratic', $vertical = false);
            $neu->setRequest($art='GET','modal_sonstiges_inhalt',$url='bdc.php',$werte='schnellauswahl=sonstiges&stid='.$_GET['stid']);
            $modal_sonstiges_inhalt = new Template_ElementList('', 'modal_sonstiges_inhalt');
            $modal_sonstiges = new Template_Modal('modal_sonstiges', $neu, array($modal_sonstiges_inhalt),$footer=null,$other='',$modal=false, $header=false);
            $modal_sonstiges->setRight();

            $collapsile2=Template_Default::Card('Sonstiges', $neu, '',array('transparent'));
            echo $collapsile2->getHtml();
            echo $modal_sonstiges->getHtml();
        }
        
        echo $modal_lead->getHtml();
        echo $modal_anfrage->getHtml();
        echo $modal_beschwerde->getHtml();
        echo $modal_settings->getHtml();
        if ($_SESSION['cfg_kunde'] === 'portal') {
            echo $modal_utility->getHtml();
            echo $modal_utility_level_2->getHtml();
        }
        
        if (isset($_GET['bdc_ziel'])) {
            $_SESSION['bdc_ziel']=$_GET['bdc_ziel'];
        } else {
            unset($_SESSION['bdc_ziel']);
        }
        
        echo Template_ElementList::init('','form_target')->getHtml();
        
        exit;
    }

    echo $inhalt;
}

function js_pflichtfeld_replace($pflicht_array) {
    $js_pflicht='';
    if (!empty($pflicht_array)) {
        foreach ($pflicht_array as $pflicht_key => $pflicht_val) {
            $js_pflicht .= '
            var $'.$pflicht_key.' = $("[name=\''.$pflicht_key.'\']");
            var $label = $("#'.$pflicht_key.'_label");
            if (';
            $bedingungen=array();
            foreach ($pflicht_val as $pflicht_val_bedingung) {
                $bedingungen[]='$'.$pflicht_key.'.val() == "'.$pflicht_val_bedingung.'"';
            }
            $js_pflicht.=implode(' || ', $bedingungen);
            $js_pflicht.=') {
                message += $label.text()+"<br>";
                focus_red($'.$pflicht_key.');
           }';
        }
    }
    return $js_pflicht;
}
if ($_GET['bdc_posteingang']) {
    echo javas ('window.onload = function(){
	bdc_reload_ap();
}');
}


// Javascript f�r Kommunikation mit BDC Posteingang
// BDC Posteingang soll mitgeteilt werden, dass BDC erstellt wurde
if (isset($_POST['form_beschwerde_submit']) || isset($_POST['form_anfrage_submit']) || isset($_POST['form_lead_submit'])) {
    $script = "
        if (typeof window.parent.p4n_vars === 'undefined') {
            window.parent.p4n_vars = {};
        }    
        window.parent.p4n_vars.bdcSuccess = true;
    ";
    echo javas($script);
}


fuss();




function schreibe_stid_bdc($gr = '') {
    global $lang, $db, $sql_tab, $sql_tabs, $form, $min_nra, $cfg_kfz, $cfg_import_nrkreis_int, $mandid, $cfg_import_nrkreis, $cfg_catch_whole, $carlo_tw, $carlo_hk, $cfg_skoda_vap, $cfg_skoda_vap_gruppe, $cfg_skoda_vap_gruppe_nra, $ist_skoda_vap, $cfg_kunde_mandlao;
    $grbez = '';
	
	if ($ist_skoda_vap) {
		$gr=$cfg_skoda_vap_gruppe;
		$min_nra=array($cfg_skoda_vap_gruppe => $cfg_skoda_vap_gruppe_nra);
		$cfg_min_nra=array($cfg_skoda_vap_gruppe => $cfg_skoda_vap_gruppe_nra);
		$res=$db->select(
			$sql_tab['stammdaten_gruppe'],
			$sql_tabs['stammdaten_gruppe']['gruppe_id'],
			$sql_tabs['stammdaten_gruppe']['bezeichnung'].'='.$db->str($gr)
	    );
    	if ($db->anzahl($res)==0) {
			$rang=10;
			$res=$db->select(
				$sql_tab['stammdaten_gruppe'],
				'MAX('.$sql_tabs['stammdaten_gruppe']['rang'].')+1'
		    );
			if ($row=$db->zeile($res)) {
				$rang=$row[0];
			}
			$db->insert(
				$sql_tab['stammdaten_gruppe'],
				array(
					$sql_tabs['stammdaten_gruppe']['art'] => $db->str('Skoda'),
					$sql_tabs['stammdaten_gruppe']['rang'] => $db->dbzahl($rang),
					$sql_tabs['stammdaten_gruppe']['privat'] => $db->dblogic(false),
					$sql_tabs['stammdaten_gruppe']['aktiv'] => $db->dblogic(true),
					$sql_tabs['stammdaten_gruppe']['bezeichnung'] => $db->str($gr)
				)
			);
		}
	}
	
    if ($gr == '') {
        $where = $sql_tabs['stammdaten_gruppe']['bezeichnung'] . '=' . $db->str('CRM Interessenten') . ' or ' .
                $sql_tabs['stammdaten_gruppe']['bezeichnung'] . '=' . $db->str('Interessenten CRM') . ' or ' .
                $sql_tabs['stammdaten_gruppe']['bezeichnung'] . '=' . $db->str('Interessenten SMT') . ' or ' .
                $sql_tabs['stammdaten_gruppe']['bezeichnung'] . '=' . $db->str('SMT Interessenten') . ' or ' .
                $sql_tabs['stammdaten_gruppe']['bezeichnung'] . '=' . $db->str('SMT') . ' or ' .
                $sql_tabs['stammdaten_gruppe']['bezeichnung'] . '=' . $db->str('CRM '._INTERESSENTEN_) . ' or ' .
                $sql_tabs['stammdaten_gruppe']['bezeichnung'] . '=' . $db->str('CRM');
    } else {
        $where = $sql_tabs['stammdaten_gruppe']['bezeichnung'] . '=' . $db->str($gr);
    }
    $nk_gr = 1;
    $res = $db->select(
            $sql_tab['stammdaten_gruppe'], array(
        $sql_tabs['stammdaten_gruppe']['bezeichnung'],
        $sql_tabs['stammdaten_gruppe']['gruppe_id']
            ), $where, $sql_tabs['stammdaten_gruppe']['bezeichnung']
    );
    if ($row = $db->zeile($res)) {
        $grbez = $row[0];
        $nk_gr = $row[1];
    } else {
        $rangneu = dbout($sql_tab['stammdaten_gruppe'], 'MAX(' . $sql_tabs['stammdaten_gruppe']['rang'] . ')+1', '');
        if ($gr == '') {
            $gr = 'CRM '._INTERESSENTEN_;
        }
        $db->insert(
                $sql_tab['stammdaten_gruppe'], array(
            $sql_tabs['stammdaten_gruppe']['bezeichnung'] => $db->str($gr),
            $sql_tabs['stammdaten_gruppe']['rang'] => $db->dbzahl($rangneu),
            $sql_tabs['stammdaten_gruppe']['privat'] => $db->dbzahl(0),
            $sql_tabs['stammdaten_gruppe']['aktiv'] => $db->dbzahl(1),
        ));
        // FIXME: Pretty sure this can be done by firstly: using lookupName and secondly: Using last insert id.
        $res = $db->select(
                $sql_tab['stammdaten_gruppe'], array(
            $sql_tabs['stammdaten_gruppe']['bezeichnung'],
            $sql_tabs['stammdaten_gruppe']['gruppe_id']
                ), $where, $sql_tabs['stammdaten_gruppe']['bezeichnung']
        );
        if ($row = $db->zeile($res)) {
            $grbez = $row[0];
            $nk_gr = $row[1];
    }
    }

    $ist_letztekundenid_update = false;
    $letzte_ku_nr = 0;
    if ($cfg_catch_whole) {
        $min_nra[$grbez] = '1-19000000';
    } else {
    $res4 = $db->select(
            $sql_tab['einstellungen'], $sql_tabs['einstellungen']['wert'], $sql_tabs['einstellungen']['modul'] . '=' . $db->str('letztekundenid_' . $mandid)
    );
    if ($row4 = $db->zeile($res4)) {
        $ist_letztekundenid_update = true;
        $letzte_ku_nr = intval($row4[0]) + 1;
    }

    if (isset($cfg_import_nrkreis_int[$mandid])) {
        $min_nra[$grbez] = $cfg_import_nrkreis_int[$mandid][0] . '-' . $cfg_import_nrkreis_int[$mandid][1];
    }
    }
	
	if ($_SESSION['cfg_kunde']=='wegcarlo_opel_dello') {
		if ($letzte_ku_nr!=0) {
			if ($letzte_ku_nr<750000) {
				$min_nra=array('CRM Interessenten' => '750000-799999');
				$cfg_min_nra=array('CRM Interessenten' => '750000-799999');
			}
		}
	}
	
	if ($_SESSION['cfg_kunde']=='carlo_opel_dello' and ($mandid==5 or $mandid==105)) {
		$min_nra=array($grbez => '2000000-2100000');
	}
	
    if ($_SESSION['cfg_kunde'] == 'kunde_continua') {
        $res = $db->select(
                $sql_tab['stammdaten'], 'max(' . $sql_tabs['stammdaten']['id'] . ')+1', $sql_tabs['stammdaten']['id'] . '<1000000'
        );
        $row = $db->zeile($res);
        $neu_kid = intval($row[0]);
    } elseif (isset($min_nra[$grbez]) or $cfg_kfz) {
        if (!isset($min_nra[$grbez])) {
            if ($_SESSION['cfg_kunde'] == 'ba') {
                $minmax = array(900000, 999998);
            } else {
                $minmax = array(1000000, 9999999);
            }
        } else {
            $minmax = explode('-', $min_nra[$grbez]);
        }
        if ($carlo_tw || $carlo_hk) {
            $result = $db->select(//Hole alle IDs zwischen min und max sortiert
                $sql_tab['stammdaten'],
                $sql_tabs['stammdaten']['id'],
                $sql_tabs['stammdaten']['id'].'>='.$db->dbzahl($minmax[0]).' and '.
                $sql_tabs['stammdaten']['id'].'<='.$db->dbzahl($minmax[1]),
                $sql_tabs['stammdaten']['id'].' asc'
            );
            $pruefwert = $minmax[0];
            $neu_kid = 0;
            while ($row = $db->zeile($result)) {
                if ($row[0] > $pruefwert) {
                    $differenz = $row[0] - $pruefwert; //wenn 7 - 5 -> 2 if > 1 dann sind noch 1 platz
                    if ($differenz > 1) {
                        $neu_kid = ($pruefwert + 1);
                        break;
                    } else {
                        $pruefwert++;
                    }
                }
            }
        } else {
            $neu_kid = 0;
            $templogchanges = $_SESSION['log_changes'];
            if ($templogchanges) {
                $_SESSION['log_changes'] = false;
            }
            $db->insert(
                    $sql_tab['stammdaten'], array(
                $sql_tabs['stammdaten']['name'] => $db->str('FDummy')
                    )
            );
            $neu_kid = intval($db->insertid());
            $db->delete(
                    $sql_tab['stammdaten'], $sql_tabs['stammdaten']['id'] . '=' . $db->dbzahl($neu_kid)
            );
            if ($templogchanges) {
                $_SESSION['log_changes'] = true;
            }
        }
        if ($neu_kid < $minmax[0] or $neu_kid > $minmax[1] or $neu_kid <= 0) {

            $groe_id = 0;
            $res = $db->select(
                    $sql_tab['stammdaten'], 'max(' . $sql_tabs['stammdaten']['alte_id'] . ')+1'
            );
            if ($row = $db->zeile($res)) {
                $groe_id = intval($row[0]);
                $res2 = $db->select(
                        $sql_tab['stammdaten'], $sql_tabs['stammdaten']['id'], $sql_tabs['stammdaten']['id'] . '=' . $db->dbzahl($groe_id)
                );
                if ($row2 = $db->zeile($res2)) {
                    $res = $db->select(
                            $sql_tab['stammdaten'], 'max(' . $sql_tabs['stammdaten']['id'] . ')+1'
                    );
                    if ($row = $db->zeile($res)) {
                        $groe_id = intval($row[0]);
                    }
                }
            }

            $alt_suche = false;
            if (1 == 2 and $_SESSION['cfg_kunde'] == 'carlo_opel_dinnebier') {
                $alt_suche = true;
                $alle_belegten = array();
                $res = $db->select(
                        $sql_tab['stammdaten'], $sql_tabs['stammdaten']['id'], $sql_tabs['stammdaten']['id'] . ' between ' . $minmax[0] . ' and ' . $minmax[1], $sql_tabs['stammdaten']['id']
                );
                while ($row = $db->zeile($res)) {
                    $alle_belegten[intval($row[0])] = 1;
                }
                for ($i = $minmax[0]; $i < $minmax[1]; $i++) {
                    if (!isset($alle_belegten[$i])) {
                        $neu_kid = $i;
                        break;
                    }
                }
            }
            $alle_ausschluss = array();
            if ($_SESSION['cfg_kunde'] == 'carlo_opel_dinnebier') {
                $res = $db->select(
                        $sql_tab['stammdaten'], $sql_tabs['stammdaten']['fremdnummer'], $sql_tabs['stammdaten']['mandant'] . '=' . $db->dbzahl($mandid) . ' and ' . $sql_tabs['stammdaten']['fremdnummer'] . '!=' . $db->str('')
                );
                while ($row = $db->zeile($res)) {
                    $neuid_mm = $minmax[0] + intval(p4n_mb_string('substr', $row[0], -5));
                    if (p4n_mb_string('strlen', $row[0]) < 5) {
                        $neuid_mm = $minmax[0] + intval($row[0]);
                    }
                    $alle_ausschluss[$neuid_mm] = 1;
                }
            }
            if (!$alt_suche) {
                $res = $db->select(
                        $sql_tab['stammdaten'], 'max(' . $sql_tabs['stammdaten']['id'] . ')+1', $sql_tabs['stammdaten']['id'] . ' between ' . $minmax[0] . ' and ' . $minmax[1]
                );
                if ($row = $db->zeile($res)) {
                    $neu_kid = intval($row[0]);
                    if ($neu_kid < intval($minmax[0])) {
                        $neu_kid = $minmax[0];
                    }
					if ($letzte_ku_nr>0 and $letzte_ku_nr>=$minmax[0] and $letzte_ku_nr<=$minmax[1]) {
						$res=$db->select(
	                        $sql_tab['stammdaten'],
							$sql_tabs['stammdaten']['id'],
							$sql_tabs['stammdaten']['id'].'='.$db->dbzahl($letzte_ku_nr)
    		            );
            		    if ($db->anzahl($res)==0) {
							$neu_kid = $letzte_ku_nr;
						}
					}
                } else {
                    $neu_kid = $minmax[0];
                }
            }
            if ($_SESSION['cfg_kunde'] == 'carlo_opel_dinnebier') {
                $xi = 1;
                while ($xi < ($minmax[1] - $minmax[0]) and isset($alle_ausschluss[$neu_kid])) {
                    $xi++;
                    $res = $db->select(
                            $sql_tab['stammdaten'], 'max(' . $sql_tabs['stammdaten']['id'] . ')+' . $xi, $sql_tabs['stammdaten']['id'] . ' between ' . $minmax[0] . ' and ' . $minmax[1]
                    );
                    if ($row = $db->zeile($res)) {
                        $neu_kid = intval($row[0]);
                    }
                }
            }
            if (!isset($cfg_import_nrkreis_int[$mandid]) and $neu_kid < $groe_id and ! isset($min_nra[$grbez])) {
                $neu_kid = $groe_id;
            }
            if ($_SESSION['cfg_kunde'] == 'carlo_opel_dinnebier') {
                
            } elseif (isset($cfg_import_nrkreis_int[$mandid]) and $neu_kid < $letzte_ku_nr) {
                $neu_kid = intval($letzte_ku_nr);
            }
        }
        $neukid_drin = true;

        if ($neu_kid <= 0) {
            if (!isset($min_nra[$grbez])) {
                die('Kein Kunde mehr frei.');
            } else {
                die('Kein Kunde mehr in der Gruppe ' . $grbez . ' (' . $min_nra[$grbez] . ') frei.');
            }
        }
        if (!$neukid_drin) {
            if ($neu_kid <= 0) {
                $neu_kid = intval($minmax[0]);
            } elseif ($neu_kid <= intval($minmax[1])) {
                $neu_kid = intval($row[0]);
            } else {
                if (!isset($min_nra[$grbez])) {
                    die('Kein Kunde mehr frei.');
                } else {
                    die('Kein Kunde mehr in der Gruppe ' . $grbez . ' (' . $min_nra[$grbez] . ') frei.');
                }
            }
        }
    } else {
        $res = $db->select(
                $sql_tab['stammdaten'], 'max(' . $sql_tabs['stammdaten']['id'] . ')+1'
        );
        //vpnr
        $row = $db->zeile($res);
        $neu_kid = intval($row[0]);
    }

    $db->insert(
            $sql_tab['stammdaten'], array(
        $sql_tabs['stammdaten']['id'] => $db->dbzahl($neu_kid),
        $sql_tabs['stammdaten'][$cfg_kunde_mandlao ? 'vpb' :  'mandant'] => $db->dbzahl($mandid),
        $sql_tabs['stammdaten']['vorname'] => $db->str(''),
        $sql_tabs['stammdaten']['name'] => $db->str(_NEUEINTRAG_),
        $sql_tabs['stammdaten']['betreuer'] => $db->dbzahl($user_id),
        $sql_tabs['stammdaten']['anzeigename'] => $db->str(_NEUEINTRAG_),
        $sql_tabs['stammdaten']['meinvp'] => $db->dbzahl($vpnr),
        $sql_tabs['stammdaten']['erstellt_benutzer'] => $db->dbzahl($user_id),
        $sql_tabs['stammdaten']['erstellt_datum'] => $db->dbtimestamp(time()),
        $sql_tabs['stammdaten']['syncml_letzte_aenderung'] => $db->dbtimestamp(time()),
        $sql_tabs['stammdaten']['syncml_id'] => $db->str('-' . $neu_kid),
        $sql_tabs['stammdaten']['syncml_status'] => $db->str('N')
            //vpnr
            )
    );
    $_SESSION['stammdaten_id'] = $neu_kid; //$db->insertid();
    $m_stid = $neu_kid;
    $db->insert(
            $sql_tab['stammdaten_gruppe_zuordnung'], array(
        $sql_tabs['stammdaten_gruppe_zuordnung']['gruppe_id'] => $db->dbzahl($nk_gr),
        $sql_tabs['stammdaten_gruppe_zuordnung']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id'])
            )
    );
    
    //korrespondenz formular erstellen
    if (false) {//warte auf feedback
        $kamp_idneu=0;
        $resFormular = $db->select(
                $sql_tab['formular'], array(
            $sql_tabs['formular']['bezeichnung'],
            $sql_tabs['formular']['vorlage']
                ), $sql_tabs['formular']['formular_id'] . '=' . $db->dbzahl(1)
        );
        $rowFormular = $db->zeile($resFormular);
        $bez_f = $rowFormular[0];
        $kfeldF = array(
            $sql_tabs['korrespondenz']['datum'] => $db->dbtimestamp(time()),
            $sql_tabs['korrespondenz']['wvl_datum1'] => 0,
            $sql_tabs['korrespondenz']['wvl_datum2'] => 0,
            $sql_tabs['korrespondenz']['stammdaten_id'] => $db->dbzahl($_SESSION['stammdaten_id']),
            $sql_tabs['korrespondenz']['ersteller_id'] => $db->dbzahl($_SESSION['user_id']),
            $sql_tabs['korrespondenz']['betreuer_id'] => $db->dbzahl($_SESSION['user_id']),
            $sql_tabs['korrespondenz']['eingang'] => 0,
            $sql_tabs['korrespondenz']['art'] => $db->dbzahl(14),
            $sql_tabs['korrespondenz']['kategorie'] => $db->str(_FORMULARE_),
            $sql_tabs['korrespondenz']['erledigt'] => $db->dblogic(true),
            $sql_tabs['korrespondenz']['parent_id'] => 0,
            $sql_tabs['korrespondenz']['doclink'] => $db->str(''),
            $sql_tabs['korrespondenz']['betreff'] => $db->str($bez_f),
            $sql_tabs['korrespondenz']['beschreibung'] => $db->str(''),
            $sql_tabs['korrespondenz']['produktzuordnung_id'] => $db->dbzahl(0),
            $sql_tabs['korrespondenz']['papierkorb'] => 0,
            $sql_tabs['korrespondenz']['kalender_id'] => 0,
            $sql_tabs['korrespondenz']['prioritaet'] => 0,
            $sql_tabs['korrespondenz']['negativ'] => 0,
            $sql_tabs['korrespondenz']['leitfaden_id'] => $db->dbzahl(0),
            $sql_tabs['korrespondenz']['kampagne_id'] => $db->dbzahl($kamp_idneu),
            $sql_tabs['korrespondenz']['formular_nr'] => $db->dbzahl(0),
            $sql_tabs['korrespondenz']['formular_id'] => $db->dbzahl(0),
            $sql_tabs['korrespondenz']['ergebnis_datum'] => $db->dbtimestamp(time()),
            $sql_tabs['korrespondenz']['ergebnis_text'] => $db->str(_FORMULAR_),
            $sql_tabs['korrespondenz']['ergebnis_kategorie'] => $db->str(_FORMULAR_),
            $sql_tabs['korrespondenz']['ergebnis_benutzer_id'] => $db->dbzahl($_SESSION['user_id'])
        );
        $db->insert(
                $sql_tab['korrespondenz'], $kfeldF
        );
    }   
    $res4 = $db->select(
            $sql_tab['einstellungen'], $sql_tabs['einstellungen']['wert'], $sql_tabs['einstellungen']['modul'] . '=' . $db->str('letztekundenid_' . $mandid)
    );
    if ($row4 = $db->zeile($res4)) {
        $db->update(
                $sql_tab['einstellungen'], array(
            $sql_tabs['einstellungen']['wert'] => $db->str($neu_kid)
                ), $sql_tabs['einstellungen']['modul'] . '=' . $db->str('letztekundenid_' . $mandid)
        );
    } else {
        $db->insert(
                $sql_tab['einstellungen'], array(
            $sql_tabs['einstellungen']['modul'] => $db->str('letztekundenid_' . $mandid),
            $sql_tabs['einstellungen']['wert'] => $db->str($neu_kid)
                )
        );
    }

    return $neu_kid;
}

function checkBdcPosteingangFileCheckbox($files,$post,$field) {
    if (isset($post[$field.'_bdcp_checkbox'])) {
        $dateiName=explode('/',$post[$field.'_bdcp_path']);
        $dateiName=$dateiName[count($dateiName)-1];
        $files[$field]['name']=$dateiName;
        $files[$field]['error']=0;
        $files[$field]['size']=99;
        $files[$field]['tmp_name']=$post[$field.'_bdcp_path'];
        $files[$field]['force_copy']=1;
    }
    return $files;
}
function updateCurrentCustomer($id,$felder) {
    global $sql_tab,$sql_tabs,$db;
    if($id>0){
        $db->update(
            $sql_tab['stammdaten'],$felder, $sql_tabs['stammdaten']['id'] . '=' . $db->dbzahl($id)
        );
    }
}

function getBdcEinstellungen() {
    global $db, $sql_tab, $sql_tabs;
    $bdc_einstellungen=array();
    $res=$db->select(
        $sql_tab['einstellungen'],
        $sql_tabs['einstellungen']['wert'],
        $sql_tabs['einstellungen']['modul'].'='.$db->str('bdc_einstellungen')
    );
    if ($row=$db->zeile($res)) {
        if ($row[0]!='') {
            $bdc_einstellungen=unserialize($row[0]);
        }
    }
    if (!array_key_exists('neuanlage_pflicht', $bdc_einstellungen)) {
        $bdc_einstellungen['neuanlage_pflicht']['anrede']=false;
        $bdc_einstellungen['neuanlage_pflicht']['vorname']=true;
        $bdc_einstellungen['neuanlage_pflicht']['name']=true;
        $bdc_einstellungen['neuanlage_pflicht']['firma']=true;
    }
    if (!array_key_exists('lead_art', $bdc_einstellungen)) {
        $bdc_einstellungen['lead_art']=1;
    }
    if (!array_key_exists('lead_kanal', $bdc_einstellungen)) {
        $bdc_einstellungen['lead_kanal']=1;
    }    
    if (!array_key_exists('lead_quelle', $bdc_einstellungen)) {
        $bdc_einstellungen['lead_quelle']=1;
    }    
    if (!array_key_exists('lead_marke', $bdc_einstellungen)) {
        $bdc_einstellungen['lead_marke']=1;
    }    
    if (!array_key_exists('lead_fahrzeug', $bdc_einstellungen)) {
        $bdc_einstellungen['lead_fahrzeug']=1;
    }
    if (!array_key_exists('lead_absatzgruppe', $bdc_einstellungen)) {
        $bdc_einstellungen['lead_absatzgruppe']=1;
    }  
    return $bdc_einstellungen;
}

function checkZielZeit($zielz, $bmtage1, $user_id) {
    global $alle_ben_feiertage;
    $alle_ben_feiertage=array();
    $alle_ben_termine=array();
    $alle_ben_termine[$user_id] = feiertage_jebenutzeralle($user_id);
    if ($_SESSION['crm_version']>64) {
        if (count($alle_ben_feiertage[$user_id])>0) {
            while (adodb_date('w', $zielz)==0 or adodb_date('w', $zielz)==6 or isset($alle_ben_feiertage[$user_id][adodb_date('d.m.Y', $zielz)])) {
                $zielz+=24*60*60;
            }
        } else {
            while (adodb_date('w', $zielz)==0 or adodb_date('w', $zielz)==6) {
                $zielz+=24*60*60;
            }
        }
    } else {
        if (count($alle_ben_feiertage[$user_id])>0) {
            $kp_tag=time();
            $iz1=1;
            while ($iz1<=$bmtage1) {
                while (adodb_date('w', $kp_tag)==0 or adodb_date('w', $kp_tag)==6 or isset($alle_ben_feiertage[$user_id][adodb_date('d.m.Y', $kp_tag)])) {
                    $kp_tag+=24*60*60;
                }
                $iz1++;
                $kp_tag+=24*60*60;
            }
            while (adodb_date('w', $kp_tag)==0 or adodb_date('w', $kp_tag)==6 or isset($alle_ben_feiertage[$user_id][adodb_date('d.m.Y', $kp_tag)])) {
                $kp_tag+=24*60*60;
            }
            $zielz=$kp_tag;
        } else {
            $kp_tag=time();
            $iz1=1;
            while ($iz1<=$bmtage1) {
                while (adodb_date('w', $kp_tag)==0 or adodb_date('w', $kp_tag)==6) {
                    $kp_tag+=24*60*60;
                }
                $iz1++;
                $kp_tag+=24*60*60;
            }
            while (adodb_date('w', $kp_tag)==0 or adodb_date('w', $kp_tag)==6) {
                $kp_tag+=24*60*60;
            }
            $zielz=$kp_tag;
        }
    }
    return $zielz;
}

function getKundemitZf($zFName, $zfWert, $idsListe=array()) {
    global $sql_tab, $sql_tabs, $db;
    $zFeld='';
    $res = $db->select(
        $sql_tab['stammdaten_zusatz'],
        array(
            $sql_tabs['stammdaten_zusatz']['zusatz_id']
        ),
        $sql_tabs['stammdaten_zusatz']['bezeichnung'].' like '.$db->str($zFName)
    );
   
    if ($row = $db->zeile($res)){
        $zFeld=$row['zusatz_id'];
    }
    if ($zFeld=='') {
        return $idsListe;
    }
    $res = $db->select(
        array($sql_tab['zusatzfelder']),
        array(
            $sql_tabs['zusatzfelder']['stammdaten_id']
        ),
        $sql_tab['zusatzfelder'].'.zf_'.$zFeld.' like '.$db->str('%'.$zfWert.'%')
    );
    while ($row = $db->zeile($res)) {
        $idsListe[$row['stammdaten_id']] = $row['stammdaten_id'];
    }
    return $idsListe;
}

exit;