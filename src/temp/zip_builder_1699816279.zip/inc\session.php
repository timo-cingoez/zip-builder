<?php
if (version_compare(phpversion(), '7.1.0', '>')) {
    if (!function_exists('php_error_greater_7')) {
        function php_error_greater_7( $num, $str, $file, $line, $context = null ) {
            return true;
        }
    }
    set_error_handler("php_error_greater_7");
}
if (trim($_SERVER['REQUEST_URI'], '/')!='') {
    $temp_path = str_replace(array('\\', '/'), '', dirname($_SERVER['REQUEST_URI']));
    if ($temp_path=='') {
        $temp_path = str_replace(basename(__FILE__), '', $_SERVER['REQUEST_URI']);
    }
    $server_path = str_replace(array('\\', '/'), '', $temp_path);
    if ($server_path!='') {
        @session_set_cookie_params(0, '/'.$server_path.'/', null, false, true);
    }
}
session_start();
ob_start();
//ob_end_clean();
if ($_SESSION['sprache'] == 'lang_rus.php') {
    if ($_SESSION['db_utf8']) {
        $encoding = 'UTF-8';
    } else {
        $encoding = 'Windows-1251';
    }
    header('Content-Type: text/html; charset='.$encoding); // koi8-r
    $_SESSION['encoding']=$encoding;
} elseif ($_SESSION['sprache'] == 'lang_kr.php') {
    header('Content-Type: text/html; charset=Windows-1250');
    $_SESSION['encoding']='windows-1250';
} elseif ($_SESSION['db_utf8'] or is_file('inc/_gr.php') or is_file('inc/_pl.php')) {
    header('Content-Type: text/html; charset=UTF-8');
    $_SESSION['encoding']='utf-8';
} else {
    header('Content-Type: text/html; charset=ISO-8859-1');
    $_SESSION['encoding']='ISO-8859-1';
}
if (isset($_GET['cfg_altes_design']) && $_GET['cfg_altes_design']==1) {
    $_SESSION['cfg_altes_design']=true;
}
if (isset($_GET['cfg_altes_design']) && $_GET['cfg_altes_design']==0) {
    $_SESSION['cfg_altes_design']=false;
}

$tsessts1=microtime();
//ob_start();
//@session_start();
//echo 'ids: '.$_SESSION['crm_l_id'].'<br>';
//$_SESSION['ajx']=1;
if ($_SESSION['cfg_security_level'] == 9 || $_SESSION['cfg_security_level'] == 4 || $_SESSION['cfg_security_level'] == 1 || $_SESSION['cfg_security_level'] == 6) {
    $url = $_SERVER['REQUEST_URI'];
    preg_match('/(.*)(\.php\?)(.*)/i', $_SERVER['REQUEST_URI'], $treffer);
    if (count($treffer) > 0) {
        $get = '';
        if (is_array($_SERVER['argv']) && count($_SERVER['argv']) > 0) {
            foreach ($_SERVER['argv'] as $argv) {
                $get.=$argv . '&';
            }
        }
        $get = substr($get, 0, -1);
        $url = $_SERVER['SCRIPT_NAME'] . '?' . $get;
    } else {
        preg_match('/(.*)(\.php)/i', $_SERVER['REQUEST_URI'], $treffer);
        if (count($treffer) > 0) {
            $url = $treffer[0];
        }
    }
    $_SERVER['REQUEST_URI'] = $url;
    $_SERVER['PHP_SELF'] = $_SERVER['SCRIPT_NAME'];
}
$phs = $_SERVER["PHP_SELF"];

//$_POST=getpost($_POST);
//$_GET=getpost($_GET);

$glob_sql_tab_stids = array();

$nicht_erlaubte_dateiendungen = array('asp', 'bat', 'chm', 'cmd', 'com', 'cpl', 'crt', 'exe', 'hlp', 'inf', '.js', 'jse', 'lnk', 'pif', 'hp3', 'hp4', 'hp5', 'php', 'reg', 'url', '.vb', 'vbe', 'vbs', 'wsc', 'wsf', 'wsh');
$erlaubte_dateiendungen = null;
if (intval($_SESSION['cfg_security_level']) > 0) {
    $erlaubte_dateiendungen = array('.csv', '.xls', 'xlsx', '.rtf', '.doc', 'docx', '.pdf', '.ppt', 'pptx', '.jpg', 'jpeg', '.gif', '.png', '.tif', 'tiff', '.txt','.p4n', '.msg', '.zip');
}
if (!empty($cfg_dateiendung_whitelist)) {
    $erlaubte_dateiendungen = $cfg_dateiendung_whitelist;
    if ($_SESSION['user_id']==1) {
        $erlaubte_dateiendungen[] = '.zip';
    }
}
$lang_nodefine = true;
if (!$noauth) {
    $url_sec = preg_replace('/[^\/]*\.php.*/', '', $_SERVER["REQUEST_URI"]);
    if (!isset($_SESSION['crm_sec_pfad'])) {
        $_SESSION['crm_sec_pfad'] = $url_sec;
    } elseif ($_SESSION['crm_sec_pfad'] != $url_sec) {
        include_once("inc/output.php");
        include_once("inc/auth.php");
        $auth = new auth();
        $auth->logout();
//		echo '<script language="">window.open("index.php?ende=1","_top")</script>';
        die();
    }
}

if (isset($_SESSION['sprache'])) {
    if (substr($_SESSION['sprache'], 0, 4) == 'lang') {
        if ($_SESSION['db_utf8'] and is_file("inc/" . str_replace('.php', '_utf8.php', $_SESSION['sprache']))) {
            include_once("inc/" . str_replace('.php', '_utf8.php', $_SESSION['sprache']));
        } else {
            include_once("inc/" . $_SESSION['sprache']);
        }
    } else {
        if (!$noauth) {
            include_once("inc/output.php");
            include_once("inc/auth.php");
            $auth = new auth();
            $auth->logout();
            die();
        }
//			echo '<script language="">window.open("index.php?ende=1","_top")</script>';
    }
} else {
    if ($_SESSION['cfg_kunde'] == 'carlo_vdk') {
        include_once("inc/lang_nl.php");
    } else {
        include_once("inc/lang_de.php");
    }
}

if (isset($_POST['multi_inc_kunde'])) {
    $_SESSION['cfg_kunde_multi'] = $_POST['multi_inc_kunde'];
}
$temp_lang_db_f = (!empty($lang_db_f['kampagne_lead']) ? $lang_db_f['kampagne_lead'] : array());
include_once("inc/typen.inc.php");
if (!empty($lang_db_f['kampagne_lead']) && count($temp_lang_db_f)!=count($lang_db_f['kampagne_lead'])) {
    $lang_db_f['kampagne_lead'] = $temp_lang_db_f;
}

include_once("inc/db.inc.php");
if ($_SESSION['crm_version']>61) {
    $cfg_filter_keinehilfstabelle=true;
}
if ($_SESSION['crm_version']>65) {
	$cfg_dubl_dse=true;
}

// 6.9
if ($_SESSION['crm_version']>=69) {
	$cfg_liste_keinlistenklick=true;
}
// 6.10
if ($_SESSION['crm_version_float']>=61000) {
	$cfg_liste_keinlistenklick=true;
	$cfg_dragdrop_email=true;
	$cfg_kampaus_mitkampinfo=false;
	$cfg_startseite_keinergebnis_bdclink=true;
	$cfg_lead_dashboard_uebersicht=true;
	$cfg_dse_tablet_je_mandant_betreuer=true;
	$cfg_textbausteine_gruppe=true;
	$cfg_show_bounces=true;
}
if ($_SESSION['crm_version_float']>=61004) {
	$cfg_kfz_zf=true;
}
// 6.12
if ($_SESSION['crm_version_float']>=61200) {
	$cfg_lead_settings_change=true;
   // if (!$_SESSION['design_70'])
	$cfg_tinymce=true;
	$cfg_startportal_suche_lead=true;
	$cfg_leadreiter_email_verlauf=true;
	$cfg_leaddashboard_rolle_stdlao=true;
	$cfg_bm_an_zielzeit=true;
	
	$cfg_bdc_lagerort_von_benutzerauswahl=true;
	$cfg_bdc_lagerort_stdlao=true;
}
if ($_SESSION['crm_version_float']>=61202) {
	$cfg_send_files2dir=true;           //legt im Ordner "dokumente_korrespondenz" einen Unterordner "mailabruf_anhang" an
	$cfg_load_mailbody_images=true;         //in E-Mails eingebettete Bilder werden als Anhang zur Korrespondenz gespeichert
}
// 6.13
if ($_SESSION['crm_version_float']>=61300) {
	$cfg_leadclose_oppschliessen=true;
	$cfg_masterkampagne_sparte=true;
	$cfg_makro_leaderstellen_echtebenutzer=true;
	$cfg_leadreiter_ap=true;
}
if (is_file('kundeninc.php')) {
	include('kundeninc.php');
}
if ($cfg_toyota_toca) {
    $cfg_messenger=true;
    $cfg_emobilio=true;
    $cfg_login_pinnwand=true;
    $cfg_customer_interfaces=true;
    $cfg_infos_pinnwand=true;
}
if ($cfg_kfzsuche_kalkulation) {
	$lang['_NLPROFITCALC_'] = 'Kalkulation';
	$lang['_ADDCOST_'] = 'Extra Kosten';
	$opp_felder_nachkalk=array(
		'upe_brutto' => 'UPE Brutto',
		'upe_netto' => 'UPE Netto',
		'levy_marge' => 'Abzug Prozent',
		'upe_levyabzug' => 'Abzug',
		'levy_zielerreichung' => 'Zielerreichung',
		'levy_modellbonus' => 'Modellbonus',
		'levy_auditbonus' => 'Auditbonus',
		'levy_ertrag1' => 'Zwischensumme 1',
		'levy_eigenleistungen_topco' => 'Aufwand lt. DMS',
		'levy_topsafe7' => 'Vertriebskosten pauschal',
		'levy_ertrag2' => 'Zwischensumme 2',
		'vertrag5_vkhbez1' => 'Verkaufshilfe 1 Bezeichnung',
		'vertrag5_vkh1' => 'Verkaufshilfe 1',
		'vertrag5_vkhbez2' => 'Verkaufshilfe 2 Bezeichnung',
		'vertrag5_vkh2' => 'Verkaufshilfe 2',
		'vertrag5_vkhbez3' => 'Verkaufshilfe 3 Bezeichnung',
		'vertrag5_vkh3' => 'Verkaufshilfe 3',
		'vertrag5_vkhbez4' => 'Verkaufshilfe 4 Bezeichnung',
		'vertrag5_vkh4' => 'Verkaufshilfe 4',
		'vertrag5_vkhbez5' => 'Verkaufshilfe 5 Bezeichnung',
		'vertrag5_vkh5' => 'Verkaufshilfe 5',
		'vertrag5_vkhbez6' => 'Beteiligung Bezeichnung',
		'vertrag5_vkh6' => 'Beteiligung',
		'levy_ertrag3' => 'Zwischensumme 3',
		'levy_f1' => 'Transportkosten',
		'levy_f2' => 'Fahrzeugbrief Zulassungskosten',
		'levy_ertrag4' => 'Ertrag',
		'levy_inz_preis' => 'Inzahlungnahme Ankauf',
		'levy_inz_preis_echt' => 'Inzahlungnahme Verkauf'
	);
	$temp=$prefix.'opportunity';
	$opp_felder_nachkalk_text=array('vertrag5_vkhbez1' => 1, 'vertrag5_vkhbez2' => 1, 'vertrag5_vkhbez3' => 1, 'vertrag5_vkhbez4' => 1, 'vertrag5_vkhbez5' => 1, 'vertrag5_vkhbez6' => 1);
	foreach ($opp_felder_nachkalk as $keylev => $vallev) {
		$sql_tabs['opportunity']['nachkalk_'.$keylev]			=$temp.'.nachkalk_'.$keylev;
		$sql_meta['opportunity']['nachkalk_'.$keylev]			=array('F');
		if (isset($opp_felder_levy_text[$keylev])) {
			$sql_meta['opportunity']['nachkalk_'.$keylev]			=array('C');
		}
		$lang_db_f['opportunity']['nachkalk_'.$keylev]=$vallev;
	}
}
if ($cfg_kfzsuche_pf_2022) {
	$cfg_kfzsuche_keinneukunde=true;
	$cfg_kfzsuche_verkauftbutton=true;
	$cfg_kfzsuche_verkaufthaken=true;
	$cfg_kfzsuche_reservierung_keindatum=true;
	$cfg_kfzsuche_reservierung_stunden_fix=true;
	$cfg_kfzsuche_reservierung_stunden=48;
	$cfg_kfzsuche_eigreserv_pf=true;
	$cfg_kfzsuche_reservierung_frei_kundensuche=true;
	$cfg_kfzsuche_reservierung_pflicht_name=true;
	$cfg_kfzsuche_reservierung_pflicht_tel=true;
	$cfg_kfzsuche_reserv_nureine_kfzkunde=true;
	$cfg_kfzsuche_pfbalken=true;
	$cfg_kfzsuche_pfkzliste=true;
	$cfg_kfzsuche_interne_fahrt=true;
	$cfg_kfzsuche_pfcheck_verbot=true;
	$cfg_kfzsuche_pf_kmstand=true;
	$cfg_kfzsuche_pf_freikm=50;
	$cfg_internerfahrer_pfakv_email=true;
	
	$cfg_kfzsuche_kennzeichen=true;
	$cfg_kfzsuche_pf_bedingungen=true;
	$cfg_kfzsuche_pfbalken_tage=30;
	$cfg_kfzsuche_pfkal_farbzeilen=true;
	$cfg_kfzsuche_pfkal_woche_scrollen=true;
	$cfg_kfzsuche_kennzeichen_wie_startportal=true;
	$cfg_internerfahrer=true;
	
	if (is_file('kundeninc.php')) {
		include('kundeninc.php');
	}
}

if ($cfg_leadmanagement_2020 and $_SESSION['crm_version_float']>=61000) {
	$cfg_leads_at_pim=true;
	$cfg_leadpimvkl_stdphase_inbearbeitung=true;
	$cfg_lead_fahrzeugbesitz=true;
}

if ($cfg_toyota_fin_import) {
    $lang_db_f['produktzuordnung']['finanzierung']='Beschaffungsart';
    $lang_db_f['produktzuordnung']['leasing_restwert']='Restwert/Ballonrate';
}
if ($cfg_mboe_vorlagen) {
    $lang_db_f['produktzuordnung']['differenzbesteuerung']='Differenzbesteuerung';
}

if ($cfg_design70_hybrid && $cfg_design70_hybrid==true) {
    $is_design=false;
    if (is_array($design_70_menuepunkt)) {
        foreach ($design_70_menuepunkt as $menuepunkt) {
            if (preg_match('/^'.$menuepunkt.'/Uis', basename($_SERVER['REQUEST_URI']))) {
                $is_design=true;
            }
        }
    }

    if (isset($_POST['erzwinge_design70'])) {
        $_GET['erzwinge_design70']='1';
    }


    if ((isset($_GET['erzwinge_design70']) || $is_design)) {
        $_SESSION['design_70']=true;
        if (!isset($_GET['frameset_start']) && 
            !preg_match('/start\.php/Uis',basename($_SERVER['REQUEST_URI'])) && 
            !preg_match('/cti\.php/Uis',basename($_SERVER['REQUEST_URI']))) {
            $_GET['erzwinge_design70']=1;
        }
    } else {
        unset($_SESSION['design_70']);
    }


    if (isset($_SESSION['old_design']) && 
            !preg_match('/start\.php/Uis',basename($_SERVER['REQUEST_URI'])) &&
            !preg_match('/cti\.php/Uis',basename($_SERVER['REQUEST_URI'])) && 
            !isset($_GET['frameset_start']) 
            && !isset($_GET['erzwinge_design70_2'])
            )
            {
        unset($_GET['erzwinge_design70']);
        unset($_POST['erzwinge_design70']);
        unset($_SESSION['design_70']);
    } 
} else if (is_file('design_70.txt') || isset($_SESSION['design_70'])) {
	$_SESSION['design_70']=true;
} else {
    unset($_SESSION['design_70']);
}


if ($cfg_probefahrt_minuten>0) {
    $_SESSION['kalender_probefahrt_minuten']=$cfg_probefahrt_minuten;
}
$_SESSION['newsletter_anonymisieren']=false;
if ($cfg_newsletter_anonymisieren) {
    $_SESSION['newsletter_anonymisieren']=true;
}
if (!$noout) {
    include_once("inc/output.php");
}
if (is_file('inc/utilities.php')) {
    include_once ('inc/utilities.php');
}

//	include_once("inc/output_core.php");
//	include_once("inc/output_html.php");
//	include_once("inc/output_crm.php");

if (!isset($_SESSION['sprache'])) {
    if ($cfg_kfzsuche_italien) {
        include_once("inc/lang_it.php");
        //	$_SESSION['stil']='style_blau.css';
    } elseif ($cfg_kfzsuche_holland) {
        include_once("inc/lang_nl.php");
        $_SESSION['stil'] = 'style_blau.css';
    } elseif ($cfg_ws_avag_kroatien) {
        include_once("inc/lang_kr.php");
        $_SESSION['sprache'] = 'lang_kr.php';
        $db = new PDB;
    } elseif ($cfg_chin) {
        include_once("inc/lang_cn_utf8.php");
        $_SESSION['sprache'] = 'lang_cn.php';
        $_SESSION['db_utf8'] = true;
        $db = new PDB;
    } elseif ($cfg_greek) {
        include_once("inc/lang_gr_utf8.php");
        $_SESSION['sprache'] = 'lang_gr.php';
        $_SESSION['db_utf8'] = true;
        $db = new PDB;
    } elseif ($cfg_neuanlage_standardland == 'Singapore') {
        include_once("inc/lang_eng_utf8.php");
        $_SESSION['sprache'] = 'lang_eng.php';
        $_SESSION['db_utf8'] = true;
        $db = new PDB;
    } elseif ($cfg_kfzsuche_norway) {
        include_once("inc/lang_no.php");
        $_SESSION['stil'] = 'style_blau.css';
    } elseif ($cfg_poland) {
        include_once("inc/lang_pl_utf8.php");
        $_SESSION['sprache'] = 'lang_pl.php';
        $_SESSION['db_utf8'] = true;
        $db = new PDB;
        $_SESSION['stil'] = 'style_blau.css';
    }
}

if ($cfg_db_utf8 and ! isset($_GET['logout'])) {
    $_SESSION['db_utf8'] = true;
}
if ($cfg_oracle and ! isset($_GET['logout'])) {
    $_SESSION['db_oracle'] = true;
}

if ($cfg_def_land == '�sterreich' and substr($_SESSION['cfg_kunde'], 0, strlen('carlo_opel_at_bmw_'))!='carlo_opel_at_bmw_' and $_SESSION['cfg_kunde']!='carlo_opel_eigenthaler') {
    $cfg_kfz_finanzierung_gmac = true;
    $cfg_kfz_finanzierung_gmac_ns = 'aiscat';
    $cfg_kfz_finanzierung_gmac_ns2 = 'domat';
    $cfg_kfz_finanzierung_gmac_wsurl = 'https://gmac-dms.request.at.afbag.net/AISCompleteServiceAT/AISCompleteAT';
    $cfg_kfz_finanzierung_gmac_posturl = 'https://www.gmacbank.at.afbag.net/callGMAGMAC.asp';
}

if ($cfg_kfz_finanzierung_gmac and $_SESSION['crm_version']>65 and !$cfg_kfzsuche_holland and !$cfg_ws_avag_kroatien and !$cfg_greek and !$cfg_kfzsuche_italien) {
	if ($cfg_def_land=='�sterreich' or $cfg_kfzsuche_austria) {
		// AT sp�ter
		$cfg_kfz_finanzierung_gmac2=true;
		$cfg_kfz_finanzierung_gmac2_posturl='https://proposalsubmit.calms.opel-leasing.at/OvfProposalLoader/login.xhtml';
		//https://proposalsubmit.calmspp.opel-leasing.at/OvfProposalLoader/load/9ba8fe
		$cfg_kfz_finanzierung_gmac2_wsurl='https://proposalstatus.calms.opel-leasing.at/services/dgi/atgetapplication/v1/';
	} else {
		$cfg_kfz_finanzierung_gmac2=true;
		$cfg_kfz_finanzierung_gmac2_posturl='https://proposalsubmit.calms.opelbank.de/OvfProposalLoader/load/f7eb60';
		$cfg_kfz_finanzierung_gmac2_wsurl='https://proposalstatus.calms.opelbank.de/services/dgi/degetapplication/v1/';
		$cfg_kfz_finanzierung_gmac3=true;
		$cfg_kfz_finanzierung_gmac3_posturl='https://fsl.opelbank.de/GMFDE_PR/ovalink/quote';
		$cfg_kfz_finanzierung_gmac3_wsurl='https://proposalstatus.calmspp.opelbank.de/services/dgi/degetapplication/v1/';
	}
}
if ($cfg_cc_tlfcache === null) {
    $cfg_cc_tlfcache = true;
}
$_SESSION['lead_art_sparte']=false;
if ($cfg_betatest or $_SESSION['cfg_kunde']=='carlo_opel_prof4net') {
	$_SESSION['lead_art_sparte']=true;
}

if (preg_match('/Windows CE/i', $_SERVER["HTTP_USER_AGENT"]) or preg_match('/symbian/i', $_SERVER["HTTP_USER_AGENT"])) {
    $_SESSION['device'] = 'pda';
} else {
    $_SESSION['device'] = '';
}
if ($_SESSION['crm_version']>63 && file_exists('inc/Rights/MenuPoint.php') && isset($sql_tabs['benutzer_rolle']['besonderes_recht'])) {
    if (property_exists('Rights_MenuPoint', 'hideFromMenu') && in_array($menuRights->menueFile,Rights_MenuPoint::$hideFromMenu)) {
        $noauth=true;
    }
}
if (!$noauth) {
    include_once("inc/auth.php");
}
if ($_SESSION['crm_version']>63) {
    if (!empty($cfg_benutzer_sprache)) {
        $sprachzuordnung=array(
            'lang_de.php' => 'DE',
            'lang_eng.php' => 'GB',
            'lang_nl.php' => 'NL',
            'lang_rus.php' => 'RU',
            'lang_pl.php' => 'PL',
            'lang_kr.php' => 'HR',
            'lang_it.php' => 'IT',
            'lang_cn.php' => 'CN',
            'lang_no.php' => 'NO',
        );
        $sprach_korrektur = array(
            'chinese' => $lang['_LANG_CN_'],
            'norwege' => $lang['_LANG_NO_']
        );
        foreach ($cfg_benutzer_sprache as $sprachdatei => $sprache) {
            $sprache_neu = $sprache;
            if (isset($sprach_korrektur[$sprache])) {
                $sprache_neu = $sprach_korrektur[$sprache];
            }
            $cfg_benutzer_sprache[$sprachdatei] = $sprache_neu.' ('.$sprachzuordnung[$sprachdatei].')';
        }
    }
}
$kln1 = 'kalender.php';
if ($_SESSION['cfg_kunde'] != 'carlo_kurlaender') {
    $kln1 = 'kalender_neu.php';
}
$cfg_mailversand_editor = true;
$cfg_kategorie_ausschluss=true;
$cfg_akv_checkmodell=true;
$cfg_kfzzuordnung_bild=true;              
$cfg_kfzsuche_limitauswahl=true;
$cfg_suche_kennzeichenmehr=true;
$cfg_startseite_haken_eigene=true;
$cfg_serviceannahme_ohnesuchean=true;
$cfg_benutzer_id5aendern=true;
$cfg_kfzsuche_infotexte=true;
$cfg_telefon_pflichtwahl=true;
$cfg_tempfilter_nav=true;//Navigation in Kunden bei temp. Filter
$cfg_olmws=true;
if (!isset($cfg_anzahl_datensaetze_max)) {
    $cfg_anzahl_datensaetze_max=1;
}

if ($cfg_kfzsuche_holland) {
    $cfg_angeboteladen_abfrage=true;
}

if (isset($cfg_min_nra) and ! isset($min_nra)) {
    $min_nra = $cfg_min_nra;
}

if ($cfg_kfz and is_array($lang_kfz)) {
    foreach ($lang_kfz as $keylang => $vallang) {
        $lang[$keylang] = $vallang;
    }
}
if ($cfg_kfz and is_array($lang_db_f_kfz)) {
    foreach ($lang_db_f_kfz as $keylang => $vallang) {
        if (!empty($vallang)) {
            foreach ($vallang as $keylang2 => $vallang2) {
                $lang_db_f[$keylang][$keylang2] = $vallang2;
            }
        }
    }
}
if (is_file('kundeninc.php')) {
	include('kundeninc.php');
}
if (($_SESSION['crm_version']>66 && !$cfg_alteplanung)) {
    $cfg_neueplanung2=true;
}
$cfg_db_subselects=false;//TT: 11.09.2018 macht Fehler bei max() as max___ wenn im Subselect 
if ($cfg_modern) {
    $cfg_neustyle=false;
}

$ist_vgrd=boolval($cfg_vgrd);
if ($_SESSION['cfg_kunde']=='crm_vw_hamburg' or $_SESSION['cfg_kunde']=='crm_audi_hamburg' or $_SESSION['cfg_kunde']=='carlo_vw_audihannover' or $_SESSION['cfg_kunde']=='crm_vw_hannover' or $_SESSION['cfg_kunde']=='carlo_vw_t4net_ab' or $_SESSION['cfg_kunde']=='crm_audi_berlin' or $_SESSION['cfg_kunde']=='carlo_vw_ba' or $_SESSION['cfg_kunde']=='crm_vw_asbberlin' or $_SESSION['cfg_kunde']=='crm_vw_chemnitz' or $_SESSION['cfg_kunde']=='kunde_kfz_leipzig' or $_SESSION['cfg_kunde']=='crm_audi_leipzig' or $_SESSION['cfg_kunde']=='crm_vw_frankfurt' or $_SESSION['cfg_kunde']=='crm_audi_frankfurt' or $_SESSION['cfg_kunde']=='crm_vw_rhein' or $_SESSION['cfg_kunde']=='crm_vw_stuttgart' or $_SESSION['cfg_kunde']=='crm_audi_stuttgart' or $_SESSION['cfg_kunde']=='carlo_vw_mahag' or $_SESSION['cfg_kunde']=='crm_vw_ulm' or $_SESSION['cfg_kunde']=='crm_vw_schwaba' or $_SESSION['cfg_kunde']=='crm_vw_vgrhh' or $_SESSION['cfg_kunde']=='crm_vw_vgrb' or $_SESSION['cfg_kunde']=='crm_vw_pia' or $_SESSION['cfg_kunde']=='carlo_vw_vgrd' or $_SESSION['cfg_kunde']=='crm_vw_hannover_release' or $_SESSION['cfg_kunde']=='crm_vw_vgrdd') {
    $ist_vgrd=true;
}
	$cross_templ=false;
	if ($cfg_cross) {
		if (is_file('inc/'.$_SESSION['cfg_kunde'].'/stammdaten_uebersicht_cross.html')) {
			$cross_templ=true;
		}
	}
	if ($cross_templ or $_SESSION['cfg_kunde']=='crm_vw_voets') {
		$cfg_filter_vehcust=true;
		$lang_db_f['produktzuordnung_kunde']['']='Fahrzeugkunde';
		$lang_db_f['produktzuordnung_kunde']['art']='Art';
		$lang_db_f['produktzuordnung_kunde']['nummer1']='Nummer';
		$lang_db_f['produktzuordnung_kunde']['beginn']='Beginn';
		$lang_db_f['produktzuordnung_kunde']['ende']='Ende';
		$lang_db_f['produktzuordnung_kunde']['stammdaten_id']='Kunde';
		$lang_db_f['stammdaten']['blacklist3']='C - DSE CRM';
		$lang_db_f['stammdaten']['blacklist3_details']='C - DSE CRM Details';
		$lang_db_f['stammdaten']['blacklist3_datum']='C - DSE CRM seit';
		$lang_db_f['stammdaten']['cc_protokoll']='CC Protokoll';
		$lang_db_f['stammdaten']['Telefon_3']='EVA - Telefon';
		$lang_db_f['stammdaten']['Fax_3']='EVA - Fax';
		$lang_db_f['stammdaten']['Mobilfon_3']='EVA - Mobiltelefon';
		$lang_db_f['stammdaten']['EMail_3']='EVA - E-Mail';
		$lang_db_f['stammdaten']['betreuer2']='EVA - Betreuer';
		$lang_db_f['stammdaten']['mwst']='C - L�schkennzeichen';
		$lang_db_f['stammdaten']['externe_id']='C - UCID';
		$lang_db_f['auftrag']['art']='Auftragsart';
		$lang_db_f['auftrag']['unt']='Rechnungsanteil';
		$lang_db_f['auftrag']['vp']='Betrieb';
		$lang_db_f['auftrag']['lagerort_text']='Betrieb Text';
		$lang_db_f['auftrag']['vpb']='Serviceberater';
		$lang_db_f['auftrag']['zusatz1']='Auftragstyp';
		$lang_db_f['auftrag']['auftrag_text']='Rechnungstext';
		$lang_db_f['auftrag']['huau']='CRM HU/AU-Rechnung';
		$lang_db_f['auftrag']['zusatz2']='CRM Zusatzfeld 2';
		$lang_db_f['auftrag']['zusatz3']='CRM Zusatzfeld 3';
		$lang_db_f['auftrag']['zusatz4']='CRM Quelldatei';
		$lang_db_f['produktzuordnung']['modelgroup']='L�schkennzeichen';
		$lang_db_f['produktzuordnung']['haendlerstatus']='Kommissionsnummer';
		$lang_db_f['produktzuordnung']['typ_modell']='Modellcode';
		$lang_db_f['produktzuordnung']['typ']='Modellbezeichnung';
		$lang_db_f['produktzuordnung']['datum_uebernahme']='Zulassung';
		$lang_db_f['produktzuordnung']['liefer_datum']='Auslieferungsdatum';
		$lang_db_f['produktzuordnung']['baujahr']='Baujahr';
		$lang_db_f['produktzuordnung']['datum_tuev']='N�chste HU/AU';
		$lang_db_f['produktzuordnung']['datum_asu']='Letzte HU/AU im Haus';
		$lang_db_f['produktzuordnung']['kennbuchstabe_getriebe']='Getriebe';
		$lang_db_f['produktzuordnung']['kennbuchstabe_motor']='Motorart';
		$lang_db_f['produktzuordnung']['kraftstoff']='Treibstoff';
		$lang_db_f['produktzuordnung']['bauart']='Karosserie';
		$lang_db_f['produktzuordnung']['garantie_ende']='Herst. Garantiedatum';
		$lang_db_f['produktzuordnung']['unfalltext']='Unfallschadenbeschreibung';
		$lang_db_f['produktzuordnung']['packagecode']='M�ngeltext';
		$lang_db_f['produktzuordnung']['notizen']='Var. Fzg. Info';
		$lang_db_f['produktzuordnung']['marktsegmentcode']='Int. Fzg.art';
		$lang_db_f['produktzuordnung']['finanzierung']='HIS Finanzierungsart';
        if ($ist_vgrd) {
            $lang_db_f['produktzuordnung']['finanzierung']='EVA Finanzierungsart';
            $lang_db_f['produktzuordnung']['text_3']='Arbeitsbereich';
            $lang_db_f['produktzuordnung']['datum_1']='Datum KV (Vorlauf)';
			$lang_db_f['produktzuordnung']['kommentar']='Ausstattungsmerkmale';
        } else {
    		$lang_db_f['produktzuordnung']['datum_leasing']='HIS Auslaufdatum/letzte Rate';
    		$lang_db_f['produktzuordnung']['leasing_sz']='HIS Anzahlung';
	    	$lang_db_f['produktzuordnung']['leasing_raten']='HIS Laufzeit (Monate)';
		    $lang_db_f['produktzuordnung']['leasing_restwert']='HIS Restrate';
    		$lang_db_f['produktzuordnung']['leasing_kosten']='HIS Rate pro Monat';
    		$lang_db_f['produktzuordnung']['kommentar']='HIS Zusatzinfos';
	    	$lang_db_f['produktzuordnung']['zusatz3']='HIS Leasing ZP Vertragsbeginn';
    	    $lang_db_f['produktzuordnung']['janein_2']='HIS SMV';
//	    	$lang_db_f['produktzuordnung']['']='HIS Vers. Zusatzprodukte';
    		$lang_db_f['produktzuordnung']['text_2']='HIS Vers. VA';
	    	$lang_db_f['produktzuordnung']['text_3']='HIS Vers. Nummer';
    		$lang_db_f['produktzuordnung']['datum_1']='HIS Vers. Stornodatum';
		}
//		$lang_db_f['produktzuordnung']['']='HIS Leasing Zusatzprodukte';
		$lang_db_f['produktzuordnung']['hubraum']='Hubraum';
		$lang_db_f['produktzuordnung']['bereifung']='Bereifung';
		$lang_db_f['produktzuordnung']['zusatz1']='Zusatzfeld 1';
		$lang_db_f['produktzuordnung']['zusatz2']='Zusatzfeld 2';
		$lang_db_f['produktzuordnung']['dispotext']='Ausstattung';
		$lang_db_f['produktzuordnung']['hersteller']='Fahrzeug ID';
		$lang_db_f['produktzuordnung']['datum_uvv']='UVV Datum';
		$lang_db_f['produktzuordnung']['schadstoffklasse']='Schadstoffklasse';
		$lang_db_f['produktzuordnung']['produktbuchungsgruppe']='Cross Betrieb';
		$lang_db_f['stammdaten_mandant']['']='Mandantenzuordnung';
		$lang_db_f['stammdaten_mandant']['mandant_id']='Mandant';
		$lang_db_f['stammdaten_mandant']['lagerort_id']='Betrieb';
		$lang_db_f['stammdaten_mandant']['nummer1']='Kontonummer';
		$lang_db_f['stammdaten_mandant']['nummer2']='Abnehmer NW';
		$lang_db_f['stammdaten_mandant']['nummer3']='Abnehmer GW';
		$lang_db_f['stammdaten_mandant']['nummer4']='Abnehmer WS';
		$lang_db_f['korrespondenz']['datenaenderung_firma']='Auftragsherkunft';
	}
	
if ($lang_nodefine) {
    if (!empty($lang)) {
        foreach ($lang as $key => $val) {
            if (!defined($key)) {
                @define($key,$val);
            }
        }
    }
}

$istavag=false;
if (!$s4c_neu and substr($_SESSION['cfg_kunde'], 0, 15)=='carlo_opel_avag') {
    $istavag=true;
}
if ($istavag) {
    $cfg_bm_extrafelder=true;
    $lang['_BMART_']='Art';
    define('_BMART_', 'Art');
    $lang['_BMKATEGORIE5_']='Abteilung';
    define('_BMKATEGORIE5_', 'Abteilung');
    $lang['_KATEGORIEDETAILS_']='Details';
    define('_KATEGORIEDETAILS_', 'Details');
}
if (!isset($lang['_BMART_'])) {
    $lang['_BMART_']=$lang['_ART_'];
    define('_BMART_', $lang['_ART_']);
}
if (!isset($lang['_BMKATEGORIE_'])) {
    $lang['_BMKATEGORIE_']=$lang['_KATEGORIE_'];
    define('_BMKATEGORIE_', $lang['_KATEGORIE_']);
}
if (!isset($lang['_BMKATEGORIE5_'])) {
    $lang['_BMKATEGORIE5_']=(!$istavag && $lang['_KATEGORIE_']!=$lang['_BMKATEGORIE_'] ? $lang['_KATEGORIE_'] : $lang['_ABTEILUNG_']);
    define('_BMKATEGORIE5_', (!$istavag && $lang['_KATEGORIE_']!=$lang['_BMKATEGORIE_'] ? $lang['_KATEGORIE_'] : $lang['_ABTEILUNG_']));
}
if (!isset($lang['_KATEGORIEDETAILS_'])) {
    $lang['_KATEGORIEDETAILS_']=$lang['_KATEGORIE_'];
    define('_KATEGORIEDETAILS_', $lang['_KATEGORIE_']);
}
if (!isset($lang['_BA_VERTEILUNG_NACH_KATEGORIE_2_'])) {
    $lang['_BA_VERTEILUNG_NACH_KATEGORIE_2_']=$lang['_BA_VERTEILUNG_NACH_KATEGORIE_'];
    define('_BA_VERTEILUNG_NACH_KATEGORIE_2_', $lang['_BA_VERTEILUNG_NACH_KATEGORIE_']);
}
if (!isset($lang['_BMKATEGORIE2_'])) {
    $lang['_BMKATEGORIE2_']=$lang['_KATEGORIE_'].' 2';
    define('_BMKATEGORIE2_', $lang['_KATEGORIE_'].' 2');
}

if (is_array($cfg_allesuchfelder)) {//$cfg_allesuchfelder=array('ort' => 1, 'adresse' => 1, 'kontakt' => 1, 'adresse_nur' => 0, 'kontakt_nur' => 0, 'ort_nur' => 0);
    if (!empty($cfg_allesuchfelder)) {
        foreach ($cfg_allesuchfelder as $art_suche => $art_wert) {
            if (!isset($_SESSION['suche_'.$art_suche]) && $art_wert > 0) {
                $_SESSION['suche_'.$art_suche]=intval($art_wert);
            }
        }
    }
} elseif ($cfg_allesuchfelder==true) {
    if (!isset($_SESSION['suche_ort'])) {
        $_SESSION['suche_ort'] = 1;
        $_SESSION['suche_adresse'] = 1;
        $_SESSION['suche_kontakt'] = 1;
    }
}

// 5.4:
$cfg_gme_new = true;
$cfg_gmekonf_check = true;   // beim GME Konfigurator die Baubarkeit pr�fen
if ($cfg_kfzsuche_norway or $cfg_gmekonf_keincheck) {
	$cfg_gmekonf_check = false;
}

// 5.5:
if (($_SESSION['cfg_kunde']=='carlo_kurlaender' or $_SESSION['cfg_kunde']=='carlo_vw_sundk' or substr($_SESSION['cfg_kunde'], 0, 11)=='carlo_opel_') and !$cfg_kfzsuche_austria and !$cfg_kfzsuche_italien and !$cfg_ws_avag_kroatien and !$cfg_greek and !$cfg_kfzsuche_holland and $_SESSION['cfg_kunde']!='carlo_opel_tamsen' and $_SESSION['cfg_kunde']!='carlo_opel_kochautomobile') {
	$cfg_ovkh=true;							// Opel Verkaufshilfen
}

// 6.0
if (!$cfg_kfzsuche_holland) {
	$cfg_pim_otherusers=true;
}
if (!isset($cfg_angeboteladen_limit)) {
	$cfg_angeboteladen_limit=10;
}
if ($cfg_ws_avag_kroatien) {
	$cfg_kfzsuche_ausstohnepreis=true; // bei Bestands-KFZ auch Ausst. mit 0 � anzeigen, wenn nicht Serienausst.
}

// 6.3
if ($_SESSION['crm_version']>62) {
	$cfg_ofdb=true;
}

//$_SESSION['cfg_kunde']=='carlo_opel_eisner_kaernten' or $_SESSION['cfg_kunde']=='carlo_opel_eisner' or
if (substr($_SESSION['cfg_kunde'], 0, 14)=='carlo_opel_at_' or $_SESSION['cfg_kunde']=='carlo_opel_auer' or $_SESSION['cfg_kunde']=='carlo_opel_autohof' or $_SESSION['cfg_kunde']=='carlo_opel_bidmon' or $_SESSION['cfg_kunde']=='carlo_opel_brandtner' or $_SESSION['cfg_kunde']=='carlo_opel_draskovich' or $_SESSION['cfg_kunde']=='carlo_opel_eigenthaler' or $_SESSION['cfg_kunde']=='carlo_opel_fior' or $_SESSION['cfg_kunde']=='carlo_opel_gerster' or $_SESSION['cfg_kunde']=='carlo_opel_hausenberger' or $_SESSION['cfg_kunde']=='carlo_opel_linser' or $_SESSION['cfg_kunde']=='carlo_opel_mayr' or $_SESSION['cfg_kunde']=='carlo_opel_oellinger' or $_SESSION['cfg_kunde']=='carlo_opel_pfleger' or $_SESSION['cfg_kunde']=='carlo_opel_puerstinger' or $_SESSION['cfg_kunde']=='carlo_opel_salis' or $_SESSION['cfg_kunde']=='carlo_opel_sparer' or $_SESSION['cfg_kunde']=='carlo_opel_zezula') {
	if ($_SESSION['cfg_kunde']!='carlo_opel_at_bmw_frey' and $_SESSION['cfg_kunde']!='carlo_opel_at_partsch') {
		$cfg_neuanlage_dsehaken=true;
	}
//	$cfg_neuanlage_dsehaken_an=true;
}

if ($cfg_kfzsuche_italien) {
    $cfg_neuanlage_dsehaken = true;    // in KV-Neukundenanlage und Neuanlage Int. Haken einblenden f�r �ffnen der DSE, danach in Stammdaten/Blacklist3 springen
    $cfg_neuanlage_dsehaken_an = false;   // DSE-Haken standardm��ig anhaken
    $cfg_kfzsuche_akv_width = 1000; // width in pixel for offer/sales
    $cfg_kfzsuche_akv_h = 600;
    $cfg_kfzsuche_customerbutton = true; // empty fields button for customer data
    $cfg_konfigurator_sofortneu = true;  // sofort neue Konf. starten bei Aufruf
    $cfg_kfzsuche_wvlangebot_eins = true;  // kein WVL-Datum eintragen bei Angeboten, wenn der Kunde noch ein offenes hat
}

if ($cfg_newsletter_ftp) {
    include('newsletterbaukasten/2.0/newsletter_ftp.php');
}
if ($cfg_newsletter_timer || $_SESSION['crm_version']>67) {
    include('newsletterbaukasten/2.0/newsletter_timer.php');
}
if ($cfg_newsletter_pdf) {
    include('newsletterbaukasten/2.0/newsletter_pdf.php');
}
$postfeld_session = $_POST;
if (!isset($_GET['konf']) and ! isset($_GET['ajax']) and ! isset($postfeld_session['ajax']) and $_SESSION['device'] == '' and $cfg_nav_historie and strpos($phs, 'status.php') === false and strpos($phs, 'hilfe.php') === false and strpos($phs, 'sofortnachricht.php') === false and strpos($phs, 'wvl.php') === false and strpos($phs, 'swb.php') === false and strpos($phs, 'cti.php') === false and strpos($phs, 'logout.php') === false and strpos($phs, 'stammdaten_suche.php') === false and strpos($phs, 'start_pda.php') === false and strpos($phs, 'start.php') === false and strpos($phs, 'index.php') === false and ! (strpos($phs, 'kalender.php') and $_GET['wahl'] == 1) and strpos($phs, 'stammdaten_suche_blz.php') === false and strpos($phs, 'stammdaten_suche_dublette.php') === false and strpos($phs, 'stammdaten_suche_name.php') === false and strpos($phs, 'stammdaten_suche_plz.php') === false and strpos($phs, 'stammdaten_suche_telefon.php') === false and strpos($phs, 'stammdaten_suche_vp.php') === false and strpos($phs, 'stammdaten_suchfelder.php') === false and strpos($phs, 'bankdaten_pruefen.php') === false and strpos($phs, 'stammdaten_gruppenfilter.php') === false and strpos($phs, 'stammdaten_liste_zb.php') === false and strpos($phs, 'stammdaten_liste_update.php') === false and strpos($phs, 'admin_filter2.php') === false and strpos($phs, 'wps_termin.php') === false and strpos($phs, 'kfz_suche_kennzeichen.php') === false and strpos($phs, 'kfz_suche_kunde.php') === false and strpos($phs, 'testabruf_konsole.php') === false and strpos($phs, 'kfz_suche_fgnr.php') === false and ! isset($_GET['kurzk'])) {

    if ($_SESSION['user_id']>0 && $_SESSION['passwort_reset']>0 && basename($_SERVER['PHP_SELF'])!='benutzer_passwort.php') {
        wechsel('benutzer_passwort.php');
        exit;
    }
    if (isset($_GET['crm_sti_nr'])) {
        $sti_nr = intval($_GET['crm_sti_nr']);
    } else {
        $sti_nr = 0;

        $sti_qs = '';
        if ($_SERVER["QUERY_STRING"] != '') {
            $sti_qs = '?' . $_SERVER["QUERY_STRING"];
        }

        if (substr($phs, -strlen('stammdaten_main.php')) == 'stammdaten_main.php') {
            $sti_qs = '';
            if (intval($_SESSION['stammdaten_id']) > 0) {
                $sti_qs = '?id=' . $_SESSION['stammdaten_id'];
            }
        }
        if (substr($phs, -strlen('stammdaten_liste.php')) == 'stammdaten_liste.php') {
            $sti_qs = '';
        }
        if (isset($_SESSION['crm_verlauf'])) {
            if ($_SESSION['crm_verlauf'][0] != $phs . $sti_qs) {
                $sti_anz = count($_SESSION['crm_verlauf']);
                for ($sti = $sti_anz; $sti > 0; $sti--) {
                    $_SESSION['crm_verlauf'][$sti] = $_SESSION['crm_verlauf'][$sti - 1];
                }
                unset($_SESSION['crm_verlauf'][10]);
            }
        } else {
            $_SESSION['crm_verlauf'] = array();
        }
        $_SESSION['crm_verlauf'][0] = $phs . $sti_qs;
    }
//		echo '<pre>';
//		print_r($_SESSION['crm_verlauf']);
//		echo '</pre>';

    if (count($_SESSION['crm_verlauf']) > 1) {
        $sti_t = 0;
        $sti_te = '';
        if ($sti_nr < (count($_SESSION['crm_verlauf']) - 1)) {
            $sti_nr2 = $sti_nr + 1;
            $sti_te.=link2('', $_SESSION['crm_verlauf'][$sti_nr2] . (strpos($_SESSION['crm_verlauf'][$sti_nr2], '?') === false ? '?crm_sti_nr=' . $sti_nr2 : '&crm_sti_nr=' . $sti_nr2), 'nav_1.gif');
            $sti_t++;
        }
        if ($sti_nr >= 1) {
            $sti_nr2 = $sti_nr - 1;
            $sti_te.=link2('', $_SESSION['crm_verlauf'][$sti_nr2] . (strpos($_SESSION['crm_verlauf'][$sti_nr2], '?') === false ? '?crm_sti_nr=' . $sti_nr2 : '&crm_sti_nr=' . $sti_nr2), 'nav_2.gif');
            $sti_t++;
        }
        if ($sti_t > 0) {
            if (!$cfg_modern) {
            echo '<div style="opacity:0.5; filter:alpha(opacity=50); position:absolute; top:' . ($_SESSION['ajx'] == 1 ? '30' : '2') . 'px; right:20px;
width:' . ($sti_t == 1 ? 22 : 44) . 'px; height:20px; background-color:#EEEEEE; color:#660000;">';
            echo $sti_te;
            echo '</div>';
        }
    }
}
}

if ($cfg_wvl_popup == true) {
    $_SESSION['cfg_wvl_popup'] = 1;
}

if ($_SESSION['crm_version']>64 or $_SESSION['user_id']==1) {
	$res=$db->select(
		$sql_tab['einstellungen'],
		$sql_tabs['einstellungen']['wert'],
		$sql_tabs['einstellungen']['modul'].'='.$db->str('perf_values')
	);
	if ($row=$db->zeile($res)) {
		$xpl1=explode(';', $row[0]);
		if ($xpl1[0]=='1') {
			$cfg_ignoriere_gruppenzuordnung=true;
		} elseif ($xpl1[0]=='0') {
			$cfg_ignoriere_gruppenzuordnung=false;
		}
		if ($xpl1[1]=='1') {
			$_SESSION['benutzer_mandant']='-1';
		}
	}
}

if ($_SESSION['crm_version']>65) {
	$ustabw=0;
	$res4=$db->select(
            $sql_tab['einstellungen'],
            $sql_tabs['einstellungen']['wert'],
            $sql_tabs['einstellungen']['modul'].'='.$db->str('KFZSuche_Steuer')
    );
    if ($row4=$db->zeile($res4)) {
            $ustabw=intval($row4[0]);
			if (intval($ustabw)>0) {
				$cfg_mwst=intval($ustabw)/100;
				$cfg_mwstn=$cfg_mwst;
			}
    }
}

//	echo '$PHS: '.$phs.'<br>$REQUEST_URI: '.$_SERVER["REQUEST_URI"].'<br>';
// Recht checken:
if ((!preg_match("/stammdaten_main\.php/", $phs) and !preg_match("/stammdaten_change\.php/", $phs) and !isset($_GET['einsp2']) and !isset($_GET['einspielen'])) &&
    (($_SESSION['design_70'] && !preg_match("/stammdaten_uebersicht\.php/", $phs) && !preg_match("/stammdaten_lead\.php/", $phs)) || !$_SESSION['design_70']))
    {
    if (!$noauth && preg_match('/.*\/([^\.]*\.php.*)/i', $_SERVER["REQUEST_URI"], $match)) {
        $dat_rechte=array();
        if ($_SESSION['user_id']>0) {
            $dat_rechte = array(
                'lead_dashboard.php' => 1,
                'login_extern.php' => 1, 
                'sec_download.php' => 1,
                'auftraege.php' => 1, 
                'auftraege_kfz.php' => 1, 
                'swb.php' => 1, 
                'cti.php' => 1, 
                'ilink.php' => 1, 
                'dubletten_zusammenfuehren.php' => 1, 
                'logout.php' => 1, 
                'menu.php' => 1, 
                'sofortnachricht.php' => 1, 
                'stammdaten_suche.php' => 1, 
                'stammdaten_suche_dublette.php' => 1, 
                'stammdaten_suche_name.php' => 1, 
                'stammdaten_suche_plz.php' => 1, 
                'stammdaten_suche_telefon.php' => 1, 
                'stammdaten_suche_vp.php' => 1, 
                'stammdaten_suchfelder.php' => 1, 
                'stammdaten_gruppenfilter.php' => 1, 
                'start.php' => 1, 
                'start_pda.php' => 1, 
                'telefonreport.php' => 1, 
                'stammdaten_liste.php' => 1,
                'telefonreport_auswertung.php' => 1, 
                'vcal_export.php' => 1, 
                'vornamen_anrede.php' => 1, 
                'index.php' => 1, 
                'status.php' => 1, 
                'admin_benutzergruppen.php' => 1, 
                'stammdaten.php' => 1, 
                'fruehwarn.php' => 1, 
                'fruehwarn2.php' => 1, 
                'hilfe.php' => 1, 
                'admin_hilfetexte.php' => 1, 
                'produktzuordnung.php' => 1,
                'korrespondenz.php' => 1, 
                'besitzerkfz_doppelt.php' => 1, 
                'setup.php' => 1, 
                'install.php' => 1, 
                'huau2.php' => 1, 
                'checkliste.php' => 1, 
                'leitfaden.php' => 1, 
                'abckunden_liste.php' => 1, 
                'fdl_vp_overhead.php' => 1, 
                'beschwerden.php' => 1, 
                'kfz_fahrzeughistorie.php' => 1,
                'statistik_kfz.php' => 1, 
                'statistik_berlin.php' => 1, 
                'wvl.php' => 1, 
                'stammdaten_suche_blz.php' => 1, 
                'leitfaden_boesche.php' => 1,
                'stammdaten_suche2.php' => 1, 
                'provabrechnung.php' => 1, 
                'stammdaten_liste_zb.php' => 1, 
                'stammdaten_liste_update.php' => 1, 
                'stammdaten_suche_nameundap.php' => 1, 
                'stammdaten_liste_msort.php' => 1, 
                'leitfaden_boesche2.php' => 1, 
                'bankdaten_pruefen.php' => 1, 
                'kfz_suche_kennzeichen.php' => 1, 
                'kfz_suche_kunde.php' => 1, 
                'anrufen_msgserver.php' => 1, 
                'leitfaden_bauer.php' => 1, 
                'wps_termin.php' => 1, 
                'stammdaten_suche_artikel.php' => 1, 
                'stammdaten_suche_nameundap2.php' => 1, 
                'kfz_suche_fgnr.php' => 1, 
                'stammdaten_suche_name2.php' => 1, 
                'stammdaten_suche_name3.php' => 1, 
                'kalender_neu.php' => 1, 
                'kalender.php' => 1, 
                'stammdaten_suche_ma.php' => 1, 
                'mail_formular.php' => 1, 
                'gruppen_todo.php' => 1, 
                'testabruf_konsole.php' => 1, 
                'tabs.php' => 1, 
                'kfz_suche.php' => 1,
				'kfzsuche.php' => 1
            );
        
        }
        $datei = $match[1];
        $datei = str_replace(stristr($datei, '&crm_sti_nr'), '', $datei);//TT: 04.01.2016 entferne R�cklink, da der Men�punkt &crm_sti_nr=2 zB nicht als Recht angelegt wurde
        $datei = str_replace(stristr($datei, '&refreshtab=1'), '', $datei);//TT: 04.01.2016 entferne R�cklink, da der Men�punkt &crm_sti_nr=2 zB nicht als Recht angelegt wurde
        $datei2 = str_replace(stristr($datei, '.php'), '.php', $datei);
//			echo 'datei1: '.$datei.'<br>Datei 2: '.$datei2.'<br>';
        if (!empty($dat_rechte) && !isset($dat_rechte[strtolower($datei2)])) {
            $c_abbruch = false;
            $res = $db->select(
                    $sql_tab['benutzer_menue_rechte'],
					$sql_tabs['benutzer_menue_rechte']['recht'],
					$sql_tabs['benutzer_menue_rechte']['link'] . '=' . $db->str($datei) . ' and ' .
						$sql_tabs['benutzer_menue_rechte']['recht'].'='.$db->dblogic(true).' and '.
                    	$sql_tabs['benutzer_menue_rechte']['benutzer_id'] . '=' . $db->dbzahl($_SESSION['user_id'])
            );
            // kein Eintrag in der DB -> nochmal ohne Endung (?x=...) pr�fen
            if ($db->anzahl($res) == 0) {
                $c_recht = dbout(
                        $sql_tab['benutzer_menue_rechte'],
						$sql_tabs['benutzer_menue_rechte']['recht'],
						$sql_tabs['benutzer_menue_rechte']['link'] . '=' . $db->str($datei2) . ' and ' .
							$sql_tabs['benutzer_menue_rechte']['recht'].'='.$db->dblogic(true).' and '.
	                        $sql_tabs['benutzer_menue_rechte']['benutzer_id'] . '=' . $db->dbzahl($_SESSION['user_id'])
                );
                if ($c_recht != '1') {
                    $c_abbruch = true;
                }
            } else {
                $row = $db->zeile($res);
                if ($row[0] == '0') {
                    $c_abbruch = true;
                }
            }
            if ($_SESSION['cfg_kunde']=='carlo_opel_prof4net' && $_SESSION['user_id']==1) {
                $c_abbruch=false;
            }
            if ($c_abbruch) {
                kopf();
                echo _KEINRECHT_DATEI_;
                fuss();
                die();
            }
        }
    }
}

$cfg_leserecht = false;
if (isset($_SESSION['user_gruppe'])) {
    if ($_SESSION['user_gruppe'] == 0) {
        $cfg_leserecht = true;
    }
}

if (!$_SESSION['karte']) {
    $_SESSION['karte'] = 'Uebersicht';
}
if ($_GET['nav']) {
    if ($_GET['nav'] != $_SESSION['karte'] and ! isset($_GET['change'])) {
        $_SESSION['karte'] = $_GET['nav'];
    }
}

$sqlbenwhere2 = '';
$target_extcrm = '';
if (isset($_GET['extcrmziel'])) {
    $daten1 = base64_decode($_GET['extcrmziel']);
    $xpl1ext = explode('___', $daten1);
    $target_extcrm = $xpl1ext[2];
    
    $direkt_einloggen = false;
    
    if (!(isset($_GET['bdcal']) && $_GET['bdcal']!='')) {
        $direkt_einloggen = true;
    }
    if (isset($_GET['bdcuid']) && $_GET['bdcuid']!='') {
        if (base64_decode($_GET['bdcuid'])==$xpl1ext[0]) {
            $direkt_einloggen = true;
        }
    }
    if ($direkt_einloggen) {
        $postfeld_session['user'] = $xpl1ext[0];
        $postfeld_session['password'] = $xpl1ext[1];
        $sqlbenwhere2 = $sql_tabs['benutzer']['benutzer_id'] . "=" . $db->dbzahl($postfeld_session['user']) . " and " . $sql_tabs['benutzer']['passwort'] . "=" . $db->str($postfeld_session['password']);
    }
}
if (isset($_GET['extcrmziel2'])) {
    $daten1 = base64_decode($_GET['extcrmziel2']);
    $_SESSION['extcrmz2'] = $daten1;
	$target_extcrm=$daten1;
}



if (!$_SESSION['user_id']) {
    if (!isset($postfeld_session['query_string']) && isset($_SERVER['REMOTE_USER']) && !isset($_GET['logout']) && !isset($postfeld_session['user'])) {
        $postfeld_session['query_string']=base64_encode(json_encode($_SERVER));
    }
    if (isset($postfeld_session['query_string']) && $postfeld_session['query_string']!='') {
        $server_var = json_decode(base64_decode($postfeld_session['query_string']), true);
        $pfad = basename($server_var);
        if ($pfad!='' && preg_match('/\.php/', $pfad)) {
            if (!preg_match('/index\.php/', $pfad) && !preg_match('/start\.php/', $pfad) && !preg_match('/logout\.php/', $pfad)) {
                $_SESSION['extcrmz2'] = $pfad;
                $target_extcrm=$pfad;
            }
        }
    }
    function security_ordner_ebene_1($folder,$ebene) {
    $path = '';
        if ($ebene<1) {
            if ($handle = opendir($path.$folder."/")) {
                while (false !== ($file = readdir($handle))) {
                    if ($file != "." && $file != ".." && $file!=".git") {
                        if(is_dir($path.$folder."/".$file)) {
                            $ebene++;
                            security_ordner_ebene_1($folder."/".$file,$ebene);
                            if (!file_exists($folder.'/'.$file.'/'.'index.html') && !file_exists($folder.'/'.$file.'/'.'index.php')) {
                                $myfile = fopen($folder.'/'.$file.'/'.'index.html', "w+") or die("Unable to open file!");
                                fwrite($myfile, '');
                                fclose($myfile);
                            }
                        }
                    }
                }
                closedir($handle);
            }   
        }
    }
//    security_ordner_ebene_1('.',0); 
// rausgenommen mit 6.13, ist nun in Nachberechnung
}
$session_reload = (isset($_SESSION['version_reload']) && $_SESSION['version_reload']==true && $_SESSION['user_id']>0);
if ($session_reload || (!$noauth && !$_SESSION['user_id'])) {
    if (!$session_reload) {
        if ($cfg_modern) {
            if (!false) {//TT: Stepahn kannst du hier bitte bei DB Fehlern nichts machen? Datenbank ausschalten, dann sieht man keinen Fehler
                Modern_Helper_Request::requestStart();
            }
            echo Modern_Template_StructureDoctype::getInstance()->getHtml();
            echo '<html><head>';
            echo Modern_Template_StructureMeta::getInstance()->getHtml();
            echo Modern_Template_StructureCss::getInstance(true)->getHtml();
            echo Modern_Template_StructureJs::getInstance('content')->getHtml();
            if ($_SESSION['design_70']) {
            echo Template_Config_Js::getContentJs();
            echo Template_Config_Css::getContentCss();
            }
            echo '</head><body><div style="width:auto;margin-left:auto;margin-right:auto;text-align:center">';
            $kopf_ja=true;
        }
        if (class_exists('xss')) {
            $postfeld_session['password'] = xss::decodeString($postfeld_session['password']);
        }
    }
    
    $passwort_policy_check=$cfg_password_policy;
    if ($session_reload) {
        $result_benutzer = $db->select(
            $sql_tab['benutzer'],
            array(
                $sql_tabs['benutzer']['login'],
                $sql_tabs['benutzer']['passwort']
            ),
            $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id'])
        );
        if ($row_benutzer = $db->zeile($result_benutzer)) {
            $passwort_post = $row_benutzer[1];
            $passwort_post_md5 = $row_benutzer[1];
            $user_post = $row_benutzer[0];
        }
        $postfeld_session['user'] = '1';
        $postfeld_session['password'] = '1';
        $_SESSION['version_reload']=false;
        $passwort_policy_check=false;
    } elseif (isset($_SESSION['login_extern_array']) && !empty($_SESSION['login_extern_array'])) {
        $passwort_post = $_SESSION['login_extern_array']['pass'];
        $passwort_post_md5 = $_SESSION['login_extern_array']['pass'];
        $user_post = $_SESSION['login_extern_array']['user'];
        $postfeld_session['user'] = '1';
        $postfeld_session['password'] = '1';
        unset($_SESSION['login_extern_array']);
        $passwort_policy_check=false;
    } elseif (!empty($postfeld_session)) {

//		if ($cfg_two_factor && isset($postfeld_session['insert']['token']) && !empty($postfeld_session['insert']['token'])) {
//			$twoFa = new TwoFactorAuthentication(entschluesseleWert($postfeld_session['userId']));
//			$deviceContainer = $twoFa->getDeviceContainer();
//
//			if ($twoFa->getCode($deviceContainer) == $postfeld_session['insert']['token']) {
//				$postfeld_session['user'] = entschluesseleWert($postfeld_session['user']);
//				$postfeld_session['password'] = entschluesseleWert($postfeld_session['password']);
//			}
//		}

		$passwort_post = hash('sha512', $postfeld_session['password']);
        $passwort_post_md5 = md5($postfeld_session['password']);
        $user_post = $postfeld_session['user'];
        $referenz = str_replace('=', '', base64_encode(substr(time(), 0, 2).substr(time(), 4, 2)));
        $explode_login = explode('___', $user_post);
        if (count($explode_login)>1 && $explode_login[0]=='admin') {
            $result_benutzer = $db->select(
                $sql_tab['benutzer'],
                array(
                    $sql_tabs['benutzer']['benutzer_id'],
                    $sql_tabs['benutzer']['name'],
                    $sql_tabs['benutzer']['vorname']
                ),
                $sql_tabs['benutzer']['benutzer_id'].'='.$db->dbzahl(1).' and ('.
                $sql_tabs['benutzer']['passwort'].'='.$db->str($passwort_post).' or '.
                $sql_tabs['benutzer']['passwort'].'='.$db->str($passwort_post_md5).')'
            );
            $gefunden=false;
            $temp_name=array();
            if ($row_benutzer = $db->zeile($result_benutzer)) {
                $user_post=$explode_login[1];
                $temp_name=$row_benutzer;
                $gefunden=true;
            }
            if ($gefunden) {
                $result_benutzer2 = $db->select(
                    $sql_tab['benutzer'],
                    array(
                        $sql_tabs['benutzer']['passwort'],
                    ),
                    $sql_tabs['benutzer']['login'].'='.$db->str($user_post)
                );
                if ($row_benutzer2 = $db->zeile($result_benutzer2)) {
                    $passwort_post = $row_benutzer2[0];
                    $passwort_post_md5 = $row_benutzer2[0];
                    $passwort_policy_check=false;
                    $_SESSION['phantom_login']=true;
                    $_SESSION['mitarbeiter_name'] = $temp_name[2] . ' ' . $temp_name[1];
                    $_SESSION['mitarbeiter_name2'] = $temp_name[1] . ', ' . $temp_name[2];
                }
            }
        }
        
    }
    $sqlbenwhere1 = $sql_tabs['benutzer']['login'] . "=" . $db->str($user_post) . " and (" . $sql_tabs['benutzer']['passwort'] . "=" . $db->str($passwort_post) . " or " . $sql_tabs['benutzer']['passwort'] . "=" . $db->str($passwort_post_md5) . ")";
    if (isset($_SERVER['REMOTE_USER']) and ! isset($_GET['logout']) and ! isset($postfeld_session['user'])) {
        $wlo1 = trim($_SERVER['REMOTE_USER']);
        if ($wlo1 != '') {
            $cred = explode('\\', $_SERVER['REMOTE_USER']);
            if (count($cred) == 1) {
                $wind1 = trim($cred[0]);
            } else {
                $wind1 = trim($cred[1]);
            }
            if ($wind1 != '') {
                $res = $db->select(
                        $sql_tab['benutzer'], $sql_tabs['benutzer']['benutzer_id'], $sql_tabs['benutzer']['login'] . ' like ' . $db->str($wind1) . ' or ' . $sql_tabs['benutzer']['login'] . ' like ' . $db->str($wlo1) . ' or ' . $sql_tabs['benutzer']['login'] . ' like ' . str_replace("\\", "\\\\", $db->str($wlo1))
                );
                if ($row = $db->zeile($res)) {
                    $sqlbenwhere1 = $sql_tabs['benutzer']['benutzer_id'] . "=" . $db->dbzahl($row[0]);
                    $postfeld_session['user'] = '1';
                    $postfeld_session['password'] = '1';
                }
            }
        }
        $passwort_policy_check=false;
    }

    if (isset($_SERVER['HTTP_IV_USER']) and ($_SERVER['REMOTE_ADDR']=='10.167.32.47' or $_SERVER['REMOTE_ADDR']=='10.167.32.31' or $_SERVER['REMOTE_ADDR']=='10.167.32.33' or $_SERVER['REMOTE_ADDR']=='10.167.32.48' or $_SERVER['REMOTE_ADDR']=='10.167.32.49' or $_SERVER['REMOTE_ADDR']=='10.167.32.21' or $_SERVER['REMOTE_ADDR']=='10.167.32.22' or $_SERVER['REMOTE_ADDR']=='10.167.32.32' or $_SERVER['REMOTE_ADDR']=='10.167.32.34' or $_SERVER['REMOTE_ADDR']=='194.114.64.99' or $_SERVER['REMOTE_ADDR']=='194.114.64.96' or $_SERVER['REMOTE_ADDR']=='194.114.41.86' or $_SERVER['REMOTE_ADDR']=='194.114.41.69' or $_SERVER['REMOTE_ADDR']=='10.167.8.118' or $_SERVER['REMOTE_ADDR']=='10.167.8.68' or $_SERVER['REMOTE_ADDR']=='10.167.8.69') and !isset($_GET['logout']) and !isset($postfeld_session['user'])) {
        $wlo1=trim($_SERVER['HTTP_IV_USER']);
        if ($wlo1!='') {
            $res=$db->select(
                    $sql_tab['benutzer'],
                    $sql_tabs['benutzer']['benutzer_id'],
                    $sql_tabs['benutzer']['login'].' like '.$db->str($wlo1)
            );
            if ($row=$db->zeile($res)) {
                    $sqlbenwhere1=$sql_tabs['benutzer']['benutzer_id']."=".$db->dbzahl($row[0]);
                    $postfeld_session['user']='1';
                    $postfeld_session['password']='1';
            }
        }
        $passwort_policy_check=false;
    }
	
    if ($sqlbenwhere2 != '') {
        $sqlbenwhere1 = $sqlbenwhere2;
    }

    if ($postfeld_session['user'] != '' and $postfeld_session['password'] != '') {

        $ist_opos = false;
        if ($cfg_opos_stidaufruf) {
            $res = $db->select(
                    $sql_tab['benutzer'], $sql_tabs['benutzer']['benutzer_id'], $sql_tabs['benutzer']['login'] . "=" . $db->str($postfeld_session['user']) . " and (" . $sql_tabs['benutzer']['passwort'] . "=" . $db->str(hash('sha512', $postfeld_session['password'])) . " or " . $sql_tabs['benutzer']['passwort'] . "=" . $db->str(md5($postfeld_session['password'])) . ")"
            );
            if ($row = $db->zeile($res)) {
                $res2 = $db->select(
                        $sql_tab['benutzer_gruppe'], $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'], $sql_tabs['benutzer_gruppe']['bezeichnung'] . '=' . $db->str('OPOS')
                );
                if ($row2 = $db->zeile($res2)) {
                    $res8 = $db->select(
                            $sql_tab['benutzer_gruppe_zuordnung'], $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'], $sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'] . '=' . $db->dbzahl($row2[0]) . ' and ' .
                            $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'] . '=' . $db->dbzahl($row[0])
                    );
                    if ($db->anzahl($res8) > 0) {
                        $ist_opos = true;
                    }
                }
            }
        }
		if (!isset($_SESSION['phantom_login']) && $postfeld_session['user']!='admin' && $postfeld_session['user']!='mcsadmin') {//Bei Login Admin keine Lizenzpr�fung...
            /*Falls kein Admin, dann muss alter Wert aus Useronline, sonst k�nnte es voll werden*/
            $result = $db->select(
                    $sql_tab['benutzer'],
                    $sql_tabs['benutzer']['benutzer_id'],
                    $sql_tabs['benutzer']['login'].'='.$db->str($postfeld_session['user'])
            );
            while ($row = $db->zeile($result)) {
                $db->delete($sql_tab['useronline'], $sql_tabs['useronline']['benutzer_id'].'='.$db->dbzahl($row[0]));
            }
            if (isset($cfg_no_password_policy[$postfeld_session['user']])) {
                $passwort_policy_check=false;
            }
            
            check_lizenz();
        } else {
            $passwort_policy_check=false;
        }
		
		if (function_exists('ldap_connect') && $postfeld_session['user'] != 'admin') {
			$sql_ben1=$postfeld_session['user'];
			if ($ist_vgrd) {
				$alle_vgrd_ben=array(
                    'Jens.Girbert.ext',
                    'Oliver.Heinke.ext',
                    'Georg.Schober.ext',
                    'Bernd.Mrowietz.ext',
                    'Ilias.Bouhlou.ext',
                    'Mike.Voigt.ext',
                    'Victoria.Sievert.ext',
                    'Sebastian.Niedack.ext',
                    'Sven.Marquardt.ext',
                    'Sebastian.Klawohn.ext',
                    'Katrin.Goepel.ext',
                    'Bjoern.Keding.ext',
                    'Stephan.Kimmich.ext',
                    'Grigory.Hotin.ext',
                    'Nicolas.Herscheid.ext',
                    'David.Bruchhold.ext',
                    'Matthias.Kawalek.ext',
                    'Thilo.Klemm.ext',
                    'Muwafaq.Saeed.ext',
                    'Joerg.Teschauer.ext',
                    'Luca.Biesmeijer.ext',
                    'Phillip.Krummrey.ext',
                    'Brian.Beyer.ext',
                    'Philipp.Kahl.ext',
                    'Volker.Kochanski.ext',
                    'Timo.Cingoez.ext',
                    'Janina.Dschuck.ext',
                    'Florian.Kliewe.ext'
				);
				foreach ($alle_vgrd_ben as $vgrdben) {
					if (preg_match('/'.$vgrdben.'/i', $postfeld_session['user'])) {
						$sql_ben1='admin';
					}
				}
			}
			$ldap_serverip='';
			$ldap_domain='';
			$ldap_datenueber=false;
			$ldap_ssl=false;
			$ldap_ohnedomain=false;
			$res=$db->select(
                $sql_tab['benutzer'],
				array(
					$sql_tabs['benutzer']['login_ldap'],
					$sql_tabs['benutzer']['benutzer_id']
				),
				$sql_tabs['benutzer']['login']."=".$db->str($sql_ben1)
			);
			if ($row=$db->zeile($res)) {
				if ($row[0]!='') {
					$xpl1=explode(';', $row[0]);
					$ldnr=intval($xpl1[0]);
					$ldap_daten=array();
					$res5=$db->select(
						$sql_tab['einstellungen'],
						$sql_tabs['einstellungen']['wert'],
						$sql_tabs['einstellungen']['modul'].'='.$db->str('LDAP')
					);
					if ($row5=$db->zeile($res5)) {
						$trz='-#-#-#-#-';
						$ldap_daten=explode($trz, $row5[0]);
						$zil=1;
						while (list($keyp, $valp)=@each($ldap_daten)) {
							$xpl2=explode('###', $valp);
							if ($xpl2[2]=='1' and $ldnr==$zil) {
								$ldap_serverip=trim($xpl2[1]);
								$ldap_domain=trim($xpl2[3]);
								if ($xpl2[4]=='1') {
									$ldap_datenueber=true;
								}
								if ($xpl2[5]=='1') {
									$ldap_ssl=true;
								}
								if ($xpl2[6]=='1') {
									$ldap_ohnedomain=true;
								}
							}
							$zil++;
						}
					}
					if ($ldap_serverip=='') {
						$ldap_serverip=trim($xpl1[1]);
					}
				} elseif ($sql_ben1=='admin') {
                    $res2=$db->select(
                        $sql_tab['benutzer'],
		        		array(
        					$sql_tabs['benutzer']['login_ldap']
        				),
        				$sql_tabs['benutzer']['login_ldap'].'!='.$db->str(''),
                        $sql_tabs['benutzer']['benutzer_id'].' desc'
		        	);
        			if ($row2=$db->zeile($res2)) {
                        $xpl1=explode(';', $row2[0]);
					    $ldnr=intval($xpl1[0]);
    					$ldap_daten=array();
	    				$res5=$db->select(
		    				$sql_tab['einstellungen'],
			    			$sql_tabs['einstellungen']['wert'],
				    		$sql_tabs['einstellungen']['modul'].'='.$db->str('LDAP')
					    );
    					if ($row5=$db->zeile($res5)) {
	    					$trz='-#-#-#-#-';
		    				$ldap_daten=explode($trz, $row5[0]);
			    			$zil=1;
				    		while (list($keyp, $valp)=@each($ldap_daten)) {
					    		$xpl2=explode('###', $valp);
    							if ($xpl2[2]=='1' and $ldnr==$zil) {
	    							$ldap_serverip=trim($xpl2[1]);
		    						$ldap_domain=trim($xpl2[3]);
			    					if ($xpl2[4]=='1') {
				    					$ldap_datenueber=true;
					    			}
						    		if ($xpl2[5]=='1') {
    									$ldap_ssl=true;
	    							}
		    						if ($xpl2[6]=='1') {
			    						$ldap_ohnedomain=true;
				    				}
					    		}
						    	$zil++;
    						}
	    				}
		    			if ($ldap_serverip=='') {
			    			$ldap_serverip=trim($xpl1[1]);
				    	}
                    }
                }
			}
			if ($ldap_serverip!='') {
				$ds=ldap_connect(($ldap_ssl?'ldaps://':'').$ldap_serverip);
				ldap_set_option($ds, LDAP_OPT_REFERRALS, 0);
				ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION, 3);
				$ldap_login_user=$postfeld_session['user'];
				$ldap_login_pw=$postfeld_session['password'];
				if (isset($cfg_ldap_login_admin)) {
					if ($cfg_ldap_login_admin!='') {
						$xpl_ldap=explode(':', $cfg_ldap_login_admin);
						$ldap_login_user=$xpl_ldap[0];
						$ldap_login_pw=$xpl_ldap[1];
					}
				}
				if ($ldap_ohnedomain) {
					$r=@ldap_bind($ds, p4n_mb_string('utf8_encode', $ldap_login_user), p4n_mb_string('utf8_encode', $ldap_login_pw));
				} else {
	                $r=@ldap_bind($ds, p4n_mb_string('utf8_encode', $ldap_domain.'\\'.$ldap_login_user), p4n_mb_string('utf8_encode', $ldap_login_pw));
				}
				if (isset($cfg_ldap_login_admin)) {
					if ($cfg_ldap_login_admin!='') {
						 $r=ldap_compare($ds, 'cn='.p4n_mb_string('utf8_encode', $ldap_domain.'\\'.$postfeld_session['user'])."", 'userPassword', $postfeld_session['password']);
					}
				}
                if ($_SESSION['cfg_kunde'] == 'crm_sensus') {
                    $sqlbenwhere1='1=2';
				}
				if ($r==1) {
                    $_SESSION['ldap']['user'] = base64_encode(p4n_mb_string('utf8_encode', $postfeld_session['user']));
                    $_SESSION['ldap']['password'] = base64_encode(p4n_mb_string('utf8_encode', $postfeld_session['password']));
					$sqlbenwhere1=$sql_tabs['benutzer']['benutzer_id']."=".$db->dbzahl($row[1]);
					if ($ldap_datenueber) {
						$ld_sr=@ldap_search($ds,"DC=avag,DC=holding", "(&(objectClass=user)(objectCategory=person)(samaccountname=".$postfeld_session['user']."))");
						$ld_info=ldap_get_entries($ds, $ld_sr);
						if (isset($ld_info[0]["sn"][0])) {
							$sqlt_up=array();
							if (isset($ld_info[0]["givenname"][0])) {
								$sqlt_up[$sql_tabs['benutzer']['vorname']]=$db->str(utf8_decode($ld_info[0]["givenname"][0]));
							}
							if (isset($ld_info[0]["sn"][0])) {
								$sqlt_up[$sql_tabs['benutzer']['name']]=$db->str(utf8_decode($ld_info[0]["sn"][0]));
							}
							
							$sqlt_up[$sql_tabs['benutzer']['email']]=$db->str('');
							for ($ldi=0; $ldi<10; $ldi++) {
								if (isset($ld_info[0]["proxyaddresses"][$ldi])) {
									if (substr($ld_info[0]["proxyaddresses"][$ldi], 0, 5)=='SMTP:') {
										$mailpa=$ld_info[0]["proxyaddresses"][$ldi];
										$mailpa=str_replace('SMTP:', '', $mailpa);
										$sqlt_up[$sql_tabs['benutzer']['email']]=$db->str(utf8_decode($mailpa));
									}
								}
							}
							if (isset($ld_info[0]["facsimiletelephonenumber"][0])) {
								$sqlt_up[$sql_tabs['benutzer']['fax']]=$db->str($ld_info[0]["facsimiletelephonenumber"][0]);
							} else {
								$sqlt_up[$sql_tabs['benutzer']['fax']]=$db->str('');
							}
							if (isset($ld_info[0]["telephonenumber"][0])) {
								$sqlt_up[$sql_tabs['benutzer']['telefon']]=$db->str($ld_info[0]["telephonenumber"][0]);
							} else {
								$sqlt_up[$sql_tabs['benutzer']['telefon']]=$db->str('');
							}
							if (isset($ld_info[0]["department"][0])) {
//								$sqlt_up[$sql_tabs['benutzer']['abteilung']]=$db->str($ld_info[0]["department"][0]);
							}
							if (isset($ld_info[0]["mobile"][0])) {
								$sqlt_up[$sql_tabs['benutzer']['mobilfon']]=$db->str($ld_info[0]["mobile"][0]);
							} else {
								$sqlt_up[$sql_tabs['benutzer']['mobilfon']]=$db->str('');
							}
							if (count($sqlt_up)>0) {
								$db->update(
					                $sql_tab['benutzer'],
									$sqlt_up,
									$sql_tabs['benutzer']['benutzer_id']."=".$db->dbzahl($row[1])
								);
							}
						}
					}
				} else {
					$sqlbenwhere1=$sql_tabs['benutzer']['benutzer_id']."=".$db->dbzahl(-99999);
				}
                $passwort_policy_check=false;
			}
		}
        $sqlt_b = array(
            $sql_tabs['benutzer']['benutzer_id'],
            $sql_tabs['benutzer']['gruppe'],
            $sql_tabs['benutzer']['vorname'],
            $sql_tabs['benutzer']['name'],
            $sql_tabs['benutzer']['email'],
            $sql_tabs['benutzer']['hash'],
            $sql_tabs['benutzer']['recht_suche'],
            $sql_tabs['benutzer']['recht_filter'],
            $sql_tabs['benutzer']['recht_gruppenfilter'],
            $sql_tabs['benutzer']['recht_nav'],
            $sql_tabs['benutzer']['stil'],
            $sql_tabs['benutzer']['startseite'],
            $sql_tabs['benutzer']['sprache'],
            $sql_tabs['benutzer']['cti'],
            $sql_tabs['benutzer']['signatur'],
            $sql_tabs['benutzer']['dokpfad'],
            $sql_tabs['benutzer']['korrespondenz_anzahl'],
            $sql_tabs['benutzer']['cti_line'],
            $sql_tabs['benutzer']['cti_sofortaufruf'],
            $sql_tabs['benutzer']['kalender_woche_startzeit'],
            $sql_tabs['benutzer']['kalender_woche_endzeit'],
            $sql_tabs['benutzer']['kalender_woche_schritt'],
            $sql_tabs['benutzer']['cti_letzteziffern'],
            $sql_tabs['benutzer']['cti_vorwahl'],
            $sql_tabs['benutzer']['telrep'],
            $sql_tabs['benutzer']['standard_filter'],
            $sql_tabs['benutzer']['standard_gruppenfilter'],
            $sql_tabs['benutzer']['recht_listefeldupdate'],
            $sql_tabs['benutzer']['isdn_speed'],
            $sql_tabs['benutzer']['liste_anzahl'],
            $sql_tabs['benutzer']['zusatzflag'],
            $sql_tabs['benutzer']['telefon'],
            $sql_tabs['benutzer']['nur_betreuer'],
            $sql_tabs['benutzer']['kalender_std_dauer'],
            $sql_tabs['benutzer']['zusatzdaten'],
            $sql_tabs['benutzer']['kalender_std_ansicht'],
            $sql_tabs['benutzer']['recht_liste2'],
            $sql_tabs['benutzer']['login'],
            $sql_tabs['benutzer']['cc_rrw'],
            $sql_tabs['benutzer']['ol_zeit'],
            $sql_tabs['benutzer']['fax'],
            $sql_tabs['benutzer']['mobilfon'],
            $sql_tabs['benutzer']['kalender_erinnerung'],
            $sql_tabs['benutzer']['keine_favoriten'],
            $sql_tabs['benutzer']['mail_daten'],
            $sql_tabs['benutzer']['standard_lagerort'],//45
            $sql_tabs['benutzer']['checkbox_daten'],
            $sql_tabs['benutzer']['recht_marke'],
            $sql_tabs['benutzer']['nur_kfzbetreuer'],
            $sql_tabs['benutzer']['social_media_daten'],
            $sql_tabs['benutzer']['sipgate']//50
        );
        if (isset($sql_tabs['benutzer']['cti_timeout'])) {
            $sqlt_b[] = $sql_tabs['benutzer']['cti_timeout'];
        }
        if (isset($sql_tabs['benutzer']['standard_mandant'])) {
            $sqlt_b[] = $sql_tabs['benutzer']['standard_mandant'];
        }
        $sqlt_b[] = $sql_tabs['benutzer']['benutzer_rolle_id'];
        if (isset($sql_tabs['benutzer']['besonderes_recht'])) {
            $sqlt_b[] = $sql_tabs['benutzer']['besonderes_recht'];
        }
        $sqlt_b[] = $sql_tabs['benutzer']['syncml_user4'];
        if (isset($sql_tabs['benutzer']['neuesdesign'])) {
            $sqlt_b[] = $sql_tabs['benutzer']['neuesdesign'];
        }
        $res = $db->select(
                $sql_tab['benutzer'], 
                $sqlt_b,
                $sqlbenwhere1.' and '.$sql_tabs['benutzer']['benutzer_id'].'!=-100'
        );
        //echo $db->last_sql().'<br>';
        if ($row = $db->zeile($res)) {

//			if (!empty($cfg_two_factor)) {
//				$twoFa = new TwoFactorAuthentication($row[0]);
//				$deviceContainer = $twoFa->getDeviceContainer();
//				if (!empty($deviceContainer)) {
//					// Daten vorbereiten
//					$_SESSION['2fa'] = $row[0]; // benutzer_id
//				}
//
//				if ($postfeld_session['insert']['token'] == '') {
//					if (isset($_SESSION['2fa'])) {
//						$authTwo = new auth();
//						echo $authTwo->twoFactorLoginScreen('index.php', $row[0], $row[37], $postfeld_session['password']);
//						exit();
//					}
//				}
//			}
			
			$recht_marke=$row[46];
			if ($sql_tabs['benutzer']['checkbox_daten'] != '') {
			 	$recht_marke=$row[47];
			}
			$recht_nurkfzbetr=$row[47];
			if ($sql_tabs['benutzer']['checkbox_daten'] != '') {
			 	$recht_nurkfzbetr=$row[48];
			}
            
            if ($cfg_sipgate) {
				if ($row[50]!='') {
					$xpl=explode('_', $row[50]);
					$_SESSION['sipgate']['user']=$xpl[0];
					$_SESSION['sipgate']['device']=$xpl[1];
				}
			}
            $_SESSION['catch_cti_timeout']=intval($row[51]);
            if (!isset($_SESSION['phantom_login'])) {
                if ($_SESSION['crm_version']>61) {
                    $db->delete(
                        $sql_tab['filter_weg_multi'],
                        $sql_tabs['filter_weg_multi']['filter_id'].'='.$db->dbzahl(0).' and '.
                        $sql_tabs['filter_weg_multi']['benutzer_id'].'='.$db->dbzahl($row[0])
                    );
                }
            
                $db->delete(
                        $sql_tab['useronline'], $sql_tabs['useronline']['benutzer_id'] . '=' . $db->dbzahl($row[0])
                );
                $sql_insert = array(
                    $sql_tabs['useronline']['benutzer_id'] => $db->dbzahl($row[0]),
                    $sql_tabs['useronline']['datum'] => $db->dbtimestamp(time()),
                    $sql_tabs['useronline']['ip_adresse'] => $db->str($_SERVER["REMOTE_ADDR"])
                );
                $sql_insert[$sql_tabs['useronline']['session']] = $db->str(session_id());
                $db->insert(
                        $sql_tab['useronline'],
                        $sql_insert
                );
                if ($cfg_userlog) {
                    $res = $db->insert(
                            $sql_tab['userlog'], array(
                        $sql_tabs['userlog']['user_id'] => $db->dbzahl($row[0]),
                        $sql_tabs['userlog']['user_name'] => $db->str($row[2] . ' ' . $row[3]),
                        $sql_tabs['userlog']['aktion'] => $db->str('Login'),
                        $sql_tabs['userlog']['datum'] => $db->dbtimestamp(time())
                            )
                    );
                }
                if ($_SESSION['crm_version'] > 68 || !empty($cfg_leadautozuordnung_firstlogin)) {
                    $refRep = new Interface_RefRepository('FIRST_LOGIN_'.date('Y_m_d'));
                    $ref = $refRep->getRefForUser($row[0]);
                    if ($ref['extern_id'] == '') {
                        $ref['extern_id'] = 'OK';
                        $ref->save();
                    }
                }
            }
            if (array_key_exists('social_media_daten', $row)) {
                $social_media_row=$row['social_media_daten'];
                if ($social_media_row!='') {
                    $social_media_split = unserialize($social_media_row);
                }
                /* Widget Leiste */
                $widget_leiste_aktiv=false;
                if (isset($social_media_split['widget_leiste']) && $social_media_split['widget_leiste'] > 0) {
                    $widget_leiste_aktiv=true;
                }
                
                /* Desktop Notification */
                $desktop_notification_aktiv=false;
                if (isset($social_media_split['desktop_notification']) && $social_media_split['desktop_notification'] > 0) {
                    $desktop_notification_aktiv=true;
                }
                
                /* Menu Suche */
                $widget_menusuche_aktiv=false;
                if (isset($social_media_split['widget_menusuche']) && $social_media_split['widget_menusuche'] > 0) {
                    $widget_menusuche_aktiv=true;
                }
                
                /* WVL */
                $widget_wvl_aktiv=false;
                if (isset($social_media_split['widget_wvl']) && $social_media_split['widget_wvl'] > 0) {
                    $widget_wvl_aktiv=true;
                }
                $widget_wvl_anzeige=0;
                if (isset($social_media_split['widget_wvl_anzeige']) && $social_media_split['widget_wvl_anzeige'] > 0) {
                    $widget_wvl_anzeige=$social_media_split['widget_wvl_anzeige'];
                }
                
                /* BM */
                $widget_bm_aktiv=false;
                if (isset($social_media_split['widget_bm']) && $social_media_split['widget_bm'] > 0) {
                    $widget_bm_aktiv=true;
                }
                $widget_bm_anzeige=0;
                if (isset($social_media_split['widget_bm_anzeige']) && $social_media_split['widget_bm_anzeige'] > 0) {
                    $widget_bm_anzeige=$social_media_split['widget_bm_anzeige'];
                }
                
                /* Sofortnachricht */
                $widget_sn_aktiv=false;
                if (isset($social_media_split['widget_sn']) && $social_media_split['widget_sn'] > 0) {
                    $widget_sn_aktiv=true;
                }
                $widget_sn_anzeige=0;
                if (isset($social_media_split['widget_sn_anzeige']) && $social_media_split['widget_sn_anzeige'] > 0) {
                    $widget_sn_anzeige=$social_media_split['widget_sn_anzeige'];
                }
                
                /* TABS */
                $widget_tabs_aktiv=($_SESSION['crm_version']<=60); // Kleiner 61 ist Standard True -> nicht aktiv da !$widget_tabs_aktiv f�r > 60 wird es als standard false sein
                if ($_SESSION['crm_version']>60 && isset($social_media_split['widget_tabs']) && $social_media_split['widget_tabs'] > 0) {
                    $widget_tabs_aktiv=true;
                }
                if ($_SESSION['crm_version']>67) {//immer aktiv ab 6.8
                    $widget_tabs_aktiv=false;
                }
                $_SESSION['twitter_worte'] = $twitter_suchen;
                $_SESSION['twitter_anzeige'] = intval($twitter_anzeige);
                $_SESSION['widget_leiste']=$widget_leiste_aktiv;
                $_SESSION['desktop_notification']=$desktop_notification_aktiv;
                $_SESSION['twitter_aktiv']=false;
                $_SESSION['widget_menusuche']=$widget_menusuche_aktiv;
                $_SESSION['widget_wvl']=$widget_wvl_aktiv;
                $_SESSION['widget_wvl_anzeige']=$widget_wvl_anzeige;
                $_SESSION['widget_bm']=$widget_bm_aktiv;
                $_SESSION['widget_bm_anzeige']=$widget_bm_anzeige;
                $_SESSION['widget_sn']=$widget_sn_aktiv;
                $_SESSION['widget_sn_anzeige']=$widget_sn_anzeige;
                $_SESSION['widget_tabs']=!$widget_tabs_aktiv;
                //$_SESSION['widget_tabsrestore']=$widget_tabsrestore_aktiv;
            }
            
            
            $_SESSION['user_ip'] = $_SERVER["REMOTE_ADDR"];
            $_SESSION['user_role'] = $row['benutzer_rolle_id'];
            $_SESSION['user_role_rights']=array();
            $_SESSION['user_rights']=array();
            if (isset($sql_tabs['benutzer_rolle']['besonderes_recht'])) {
                $res_r = $db->select(
                    $sql_tab['benutzer_rolle'],
                    $sql_tabs['benutzer_rolle']['besonderes_recht'].' as rights',
                    $sql_tabs['benutzer_rolle']['benutzer_rolle_id'].'='.$db->dbzahl($_SESSION['user_role'])
                );
                if ($row_r = $db->zeile($res_r)) {
                    if ($row_r['rights']!='') {
                        $rights_from_role = unserialize($row_r['rights']);
                        if (!empty($rights_from_role)) {
                            $_SESSION['user_role_rights']=$rights_from_role;
                            if ($rights_from_role['design'] && $db->dblogic($rights_from_role['design'])) {
                                $_SESSION['design_70']=true;
                                $cfg_design70_hybrid=false;
                                unset($_GET['erzwinge_design70']);
                                unset($_POST['erzwinge_design70']);
                            }
                        }
                    }
                }
            }
            
            $_SESSION['user_id'] = $row[0];
            
            // Personal settings of the user has higher priority than the role.
            // This requires user_id === 1 and $cfg_design70_btn to enable D70.
            if (
                isset($sql_tabs['benutzer']['neuesdesign']) &&
                !isset($_POST['neuesdesign']) &&
                !isset($_POST['neuesdesign_alt']) &&
                !is_null($row['neuesdesign'])
            ) {
                if ($db->dblogic($row['neuesdesign'])) {
                    $_SESSION['design_70'] = true;
                    $cfg_design70_hybrid = false;
                    unset($_GET['erzwinge_design70']);
                    unset($_POST['erzwinge_design70']);
                } else {
                    $cfg_design70_hybrid = false;
                    unset($_SESSION['design_70']);
                    unset($_GET['erzwinge_design70']);
                    unset($_POST['erzwinge_design70']);
                }
            }

            if ($cfg_design70_hybrid) {
                $_SESSION['twitter_worte'] = false;
                $_SESSION['twitter_anzeige'] = false;
                $_SESSION['widget_leiste']=false;
                $_SESSION['desktop_notification']=$desktop_notification_aktiv;
                $_SESSION['twitter_aktiv']=false;
                $_SESSION['widget_menusuche']=false;
                $_SESSION['widget_wvl']=false;
                $_SESSION['widget_wvl_anzeige']=false;
                $_SESSION['widget_bm']=false;
                $_SESSION['widget_bm_anzeige']=false;
                $_SESSION['widget_sn']=false;
                $_SESSION['widget_sn_anzeige']=false;
                $_SESSION['widget_tabs']=false;
            }
            
            if (isset($row['besonderes_recht'])) {
                if ($row['besonderes_recht']!='') {
                    $_SESSION['user_rights']=unserialize($row['besonderes_recht']);
                }
            }
            $_SESSION['user_email'] = $row[4];
//				$_SESSION['stammdaten_id']=$f2;
            $_SESSION['user_gruppe'] = (int) $row[1];
            if (!$_SESSION['phantom_login']) {
                $_SESSION['mitarbeiter_name'] = $row[2] . ' ' . $row[3];
                $_SESSION['mitarbeiter_name2'] = $row[3] . ', ' . $row[2];
            }
//				$_SESSION['mandant']=$_POST['mandant'];
            $_SESSION['hash'] = $row[0] . $row[5] . '_' . $row[12];
            $_SESSION['suche_name'] = 1;
            $_SESSION['recht_s'] = (int) $row[6];
            $_SESSION['recht_f'] = (int) $row[7];
            $_SESSION['recht_g'] = (int) $row[8];
            $_SESSION['recht_n'] = (int) $row[9];
            $_SESSION['stil'] = $row[10];
            if ($_SESSION['design_70']) {
                $_SESSION['stil'] = 'style_blau.css';
            }
            $_SESSION['startseite'] = $row[11];
            $_SESSION['sprache'] = $row[12];
            $_SESSION['cti'] = $row[13];
            $_SESSION['user_signatur'] = $row[14];
            $_SESSION['kdokpfad'] = $row[15];
            $_SESSION['kor_anzahl'] = $row[16];
            $_SESSION['cti_line'] = $row[17];
            $_SESSION['syncml_user4'] = $row['syncml_user4'];
            $_SESSION['cti_sofort'] = $row[18];
            $_SESSION['isdn'] = $row[28];
            $_SESSION['zusatzflag'] = $row[30];
            $_SESSION['benutzer_tel'] = $row[31];
            $_SESSION['nur_betreuer'] = $row[32];
            $_SESSION['kal_std'] = intval($row[33]);
            if ($_SESSION['kal_std'] <= 0) {
                $_SESSION['kal_std'] = 60;
            }
            $_SESSION['user_zusatzdaten'] = intval($row[34]);
            $_SESSION['kal_std_ansicht'] = trim($row[35]);
            if ($_SESSION['kal_std_ansicht'] != '') {
                $cfg_kalender_standardansicht = $_SESSION['kal_std_ansicht'];
            }
            $_SESSION['recht_liste2'] = trim($row[36]);

            $user_login_name = $row[37];
            $_SESSION['user_login'] = $row[37];
            $_SESSION['cc_rrw'] = $row[38];
            $_SESSION['ol_zeit'] = $row[39];
            $_SESSION['benutzer_fax'] = $row[40];
            $_SESSION['benutzer_mob'] = $row[41];
            $_SESSION['kal_erinnerung'] = $row[42];
            $_SESSION['keine_favoriten'] = ($carlo_tw);
            if ($row[43] == '1') {
                $_SESSION['keine_favoriten'] = true;
            }
            if ($row[44] != '') {
                $_SESSION['abw_maildaten'] = $row[44];
            }
            $_SESSION['user_standard_lagerort'] = -1;
            if (intval($row[45]) > 0) {
                $_SESSION['user_standard_lagerort'] = $row[45];
            }
            $_SESSION['checkbox_daten']=array();
            if ($row[46]!='') {
                $_SESSION['checkbox_daten'] = explode(';', $row[46]);
            }
            $_SESSION['liste_anzahl_ps'] = intval($row[29]);

            if ($row[19] == '') {
                $row[19] = 8;
            }
            $_SESSION['kalender_woche_startzeit'] = $row[19];
            if ($row[20] == '') {
                $row[20] = 22;
            }
            $_SESSION['kalender_woche_endzeit'] = $row[20];
            if ($row[21] == '') {
                $row[21] = 60;
            }
            $_SESSION['kalender_woche_schritt'] = $row[21];
            if (intval($_SESSION['kalender_woche_schritt']) == 0) {
                $_SESSION['kalender_woche_schritt'] = 60;
            }

            $_SESSION['cti_lz'] = $row[22];
            $_SESSION['cti_vw'] = $row[23];

            if ($_SESSION['cfg_kunde'] == 'callcenter') {
                //	$_SESSION['cfg_filtercache']=intval($row[24]);
                $_SESSION['cfg_ctiautotel'] = intval($row[24]);
            }

            $sfilt = $row[25];
            $gfilt = trim($row[26]);
            $_SESSION['recht_lfu'] = (int) $row[27];

            // Mandanten:
            $_SESSION['benutzer_mandant'] = '';
            $ses_m_erstmid = 0;
            $res = $db->select(
                    $sql_tab['mandant'], 
                    array(
                        $sql_tabs['mandant']['mandant_id'],
                        $sql_tabs['mandant']['parent_id']
                    )
            );
            $_SESSION['nochschneller_telefonsuche'] = false;
            if (($cfg_telefon_nochschneller || $cfg_websocket_url!='') && isset($sql_tab['stammdaten_telefon_suche'])) {
                $result_stammdaten_telefon_suche = $db->select(
                    $sql_tab['stammdaten_telefon_suche'],
                    'count('.$sql_tabs['stammdaten_telefon_suche']['suche_id'].') as num'
                );
                if ($row_stammdaten_telefon_suche = $db->zeile($result_stammdaten_telefon_suche)) {
                    $_SESSION['nochschneller_telefonsuche']=($row_stammdaten_telefon_suche['num']>0);
                }
            }
            $_SESSION['nochschneller_textsuche'] = false;
            if ($cfg_suche_nochschneller && isset($sql_tab['stammdaten_text_suche'])) {
                $result_stammdaten_telefon_suche = $db->select(
                    $sql_tab['stammdaten_text_suche'],
                    'count('.$sql_tabs['stammdaten_text_suche']['suche_id'].') as num'
                );
                if ($row_stammdaten_telefon_suche = $db->zeile($result_stammdaten_telefon_suche)) {
                    $_SESSION['nochschneller_textsuche']=($row_stammdaten_telefon_suche['num']>0);
                }
            }
            
            $mand_anz = $db->anzahl($res);
            $_SESSION['user_standard_lagerort_mandant'] = $row['standard_mandant'] > 0 ? $row['standard_mandant'] : -1;
            while ($row = $db->zeile($res)) {
                if (intval($row[1]) == 0 and $ses_m_erstmid == 0) {
                    $ses_m_erstmid = $row[0];
                }
                if (intval($_SESSION['user_standard_lagerort']) > 0 && $row[0] == $_SESSION['user_standard_lagerort']) {
                    $_SESSION['user_standard_lagerort_mandant'] = $row[1];
                }
            }
            $res = $db->select(
                    $sql_tab['benutzer_mandant'], $sql_tabs['benutzer_mandant']['mandant_id'], $sql_tabs['benutzer_mandant']['benutzer_id']
                    . '=' . $db->dbzahl($_SESSION['user_id'])
            );
            $delete=false;
            $_SESSION['benutzer_mandant']='';
            if ($db->anzahl($res) == $mand_anz) {
                $_SESSION['benutzer_mandant'] = '-1';
                if ($row = $db->zeile($res)) {
                    $_SESSION['mandant'] = $ses_m_erstmid; //$row[0];
                }
            } else {
                while ($row = $db->zeile($res)) {
                    if ($row[0]==0) {
                        $delete=true;
                        continue;
                    }
                    if (!isset($_SESSION['mandant'])) {
                        if ($ses_m_erstmid == $row[0]) {
                            $_SESSION['mandant'] = $row[0];
                        }
                    }
                    $_SESSION['benutzer_mandant'].=$row[0] . ',';
                }
                $_SESSION['benutzer_mandant'] = substr($_SESSION['benutzer_mandant'], 0, -1);
            }
            if ($delete) {
                $db->delete(
                    $sql_tab['benutzer_mandant'],
                    $sql_tabs['benutzer_mandant']['mandant_id'].'='.$db->dbzahl(0)
                );
            }
            if ($_SESSION['benutzer_mandant'] == '') {
                $_SESSION['benutzer_mandant'] = '-2';
            }
			
			unset($_SESSION['benutzer_ownlocation']);
			$res = $db->select(
                    $sql_tab['benutzer_mandant_auswertung'], $sql_tabs['benutzer_mandant_auswertung']['mandant_id'], $sql_tabs['benutzer_mandant_auswertung']['benutzer_id']
                    . '=' . $db->dbzahl($_SESSION['user_id'])
            );
            $_SESSION['benutzer_mandant_auswertung']='';
            if ($db->anzahl($res) == $mand_anz) {
                $_SESSION['benutzer_mandant_auswertung'] = '-1';
            } else {
                while ($row = $db->zeile($res)) {
                    $_SESSION['benutzer_mandant_auswertung'].=$row[0] . ',';
                }
                $_SESSION['benutzer_mandant_auswertung'] = substr($_SESSION['benutzer_mandant_auswertung'], 0, -1);
            }
            if ($_SESSION['benutzer_mandant_auswertung'] == '') {
                $_SESSION['benutzer_mandant_auswertung'] = '-2';
            }
            if ($_SESSION['crm_version']>67) {
                $_SESSION['benutzer_mandant_lead']='';
                $res = $db->select(
                    $sql_tab['benutzer_mandant_lead'], $sql_tabs['benutzer_mandant_lead']['mandant_id'], $sql_tabs['benutzer_mandant_lead']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id'])
                );
                if ($db->anzahl($res) == $mand_anz) {
                    $_SESSION['benutzer_mandant_lead'] = '-1';
                } else {
                    while ($row = $db->zeile($res)) {
                        $_SESSION['benutzer_mandant_lead'].=$row[0] . ',';
                    }
                    $_SESSION['benutzer_mandant_lead'] = substr($_SESSION['benutzer_mandant_lead'], 0, -1);
                }
                if ($_SESSION['benutzer_mandant_lead'] == '') {
                    $_SESSION['benutzer_mandant_lead'] = '-2';
                }
            }
			$grp_ownl='';
			$grp_dbk='';
			/*$res=$db->select(
				 $sql_tab['benutzer_gruppe'],
				 $sql_tabs['benutzer_gruppe']['gruppe_id'],
				 $sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('ownlocation')
			);
			if ($row=$db->zeile($res)) {
				$grp_ownl=$row[0];
			}*/
            $gruppen_crm = array();
            $res=$db->select(
                $sql_tab['benutzer_gruppe'],
                array(
                    $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'],
                    $sql_tabs['benutzer_gruppe']['bezeichnung']
                )
            );
            while ($row_gruppen = $db->zeile($res)) {
                if ($row_gruppen[1] == 'ownlocation') {
                    $grp_ownl=$row_gruppen[0];
                }
                $gruppen_crm[$row_gruppen[0]] = $row_gruppen[1];
				if ($row_gruppen[1]=='Datenbankkopie') {
					 $grp_dbk=$row_gruppen[0];
				}
            }
			
            if (!isset($_SESSION['mandant'])) {
                $_SESSION['mandant'] = '1';
            }

            if (isset($postfeld_session['mandant'])) {
                $_SESSION['mandant'] = $postfeld_session['mandant'];
            }
			
			$_SESSION['nur_kfzbetreuer']=0;
			$_SESSION['rechte_kfzbetreuer_sql']='';
			$_SESSION['rechte_kfzbetreuer_sql2']='';
			if ($cfg_recht_kfzbetreuer) {
				if ($recht_nurkfzbetr=='1') {
					$_SESSION['nur_kfzbetreuer']=1;
					if ($cfg_kfzbetreuer_zusatztext1) {
						$_SESSION['rechte_kfzbetreuer_sql']=$sql_tabs['stammdaten']['zusatztext1'].' like '.$db->str('%,'.$_SESSION['user_id'].',%');
					} else {
						$_SESSION['rechte_kfzbetreuer_sql']='('.$sql_tabs['stammdaten']['id'].' not in (select stammdaten_id from '.$sql_tab['produktzuordnung'].') or '.$sql_tabs['stammdaten']['id'].' in (select '.$sql_tabs['produktzuordnung']['stammdaten_id'].' from '.$sql_tab['produktzuordnung'].' where '.$sql_tabs['produktzuordnung']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id']).'))';
					}
					$_SESSION['rechte_kfzbetreuer_sql2']=$sql_tabs['produktzuordnung']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id']);
				}
			}
			$_SESSION['kal_kategorie']=array();
            if ($_SESSION['crm_version']>63) {
                $result_kategorie = $db->select(
                    $sql_tab['kategorie'],
                    array(
                        $sql_tabs['kategorie']['bezeichnung'],
                        $sql_tabs['kategorie']['rang']
                    ),
                    $sql_tabs['kategorie']['modul'].'='.$db->dbzahl(8)
                );
                while ($row_kategorie = $db->zeile($result_kategorie)) {
                    $_SESSION['kal_kategorie'][$row_kategorie[0]]=intval($row_kategorie[1]);
                }
            }
			$_SESSION['nur_rechte_marke']=0;
			if ($cfg_recht_kfzmarke) {
				$_SESSION['rechte_marke']='';
				$_SESSION['rechte_marke_sql']='';
				if ($recht_marke!='') {
					$_SESSION['nur_rechte_marke']=1;
					$sql_wh_temp='';
					$sql_wh_temp_sum=0;
					//$sql_wh_tempz='';
					$sql_wh_temp1='';
					$sql_wh_temp2='';
					$xpl1=explode(';', $recht_marke);
                    $alle_abteilung_marken = System_BrandPartitioning::instance()->getBrandCombinationByKey();
                    $alle_abteilung_zuordnung = array();
					while (list($keym, $valm)=@each($xpl1)) {
						if ($valm!='') {
							$sql_wh_temp.=$db->str($valm).',';
							if (isset($alle_abteilung_marken[$valm])) {
								@reset($alle_abteilung_marken);
								while (list($keym2, $valm2)=@each($alle_abteilung_marken)) {
									if (preg_match('/'.$valm.'/i', $keym2)) {
					//					$sql_wh_tempz.=$valm2.',';
                                        $alle_abteilung_zuordnung[$valm2] = $valm2;
									}
								}
								$sql_wh_temp_sum+=$alle_abteilung_marken[$valm];
							}
						}
					}
					if (count($alle_abteilung_zuordnung)>0) {
                        $alle_abteilung_zuordnung[0] = 0;
                        @asort($alle_abteilung_zuordnung);
//					if ($sql_wh_temp!='') {
						//$sql_wh_temp1='('.$sql_tabs['stammdaten']['id'].' not in (select stammdaten_id from '.$sql_tab['produktzuordnung'].') or '.$sql_tabs['stammdaten']['id'].' in (select '.$sql_tabs['produktzuordnung']['stammdaten_id'].' from '.$sql_tab['produktzuordnung'].' where '.$sql_tabs['produktzuordnung']['markencode'].' in ('.substr($sql_wh_temp, 0, -1).')))';
						//$sql_wh_tempz=substr($sql_wh_tempz, 0, -1);
						//if ($sql_wh_tempz!='') {
						$sql_wh_temp1=$sql_tabs['stammdaten']['abteilung'].' in ('.implode(',',$alle_abteilung_zuordnung).')';
						$sql_wh_temp2=$sql_tabs['produktzuordnung']['markencode'].' in ('.substr($sql_wh_temp, 0, -1).')';
						//}
						$_SESSION['rechte_marke']=$recht_marke;
						$_SESSION['rechte_marke_sql']=$sql_wh_temp1;
						$_SESSION['rechte_marke_sql2']=$sql_wh_temp2;
					} else {
						$_SESSION['nur_rechte_marke']=0;
					}
				}
			}
			
            // Karteirechte:
            $res = $db->select(
                    $sql_tab['benutzer_rechte'], array(
                $sql_tabs['benutzer_rechte']['reiter'],
                $sql_tabs['benutzer_rechte']['leserecht']
                    ), $sql_tabs['benutzer_rechte']['benutzer_id'] . '=' . $db->dbzahl($_SESSION['user_id'])
            );
            while ($row = $db->zeile($res)) {
                if ($_SESSION['crm_version']>61 && !$cfg_bm) {
                    if ($row[0]=='stammdaten_main.php?nav=BM') {
                        continue;//Tempor�r kein Recht auf BM bis zum n�chsten Login
                    }
                }
                $_SESSION['rechte_reiter'].=$row[0];
                if ($row[1] == '1') {
                    $_SESSION['rechte_reiter_nurlese'].=$row[0];
                }
            }
            // Gruppenrechte:
            $allGroups = $allowedGroups = array();
            $res = $db->select(
                $sql_tab['stammdaten_gruppe'],
                $sql_tabs['stammdaten_gruppe']['gruppe_id']
            );
            while ($row = $db->zeile($res)) {
                $allGroups[$row[0]] = 1;
            }
            $res = $db->select(
                $sql_tab['benutzer_rechte_gruppen'],
                $sql_tabs['benutzer_rechte_gruppen']['gruppe_id'],
                $sql_tabs['benutzer_rechte_gruppen']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id']),
                $sql_tabs['benutzer_rechte_gruppen']['gruppe_id']
            );
            while ($row = $db->zeile($res)) {
                if (isset($allGroups[$row[0]])) {
                    $allowedGroups[$row[0]] = $row[0];
                }
            }
            $_SESSION['rechte_gruppen'] = implode(',', $allowedGroups);
            if ($_SESSION['rechte_gruppen'] == '') {
                $_SESSION['rechte_gruppen'] = '-1';
            }
            // wieviel Gruppen gibt es?
            $_SESSION['rechte_gruppen_alle'] = false;
            if (count($allGroups) ===  count($allowedGroups)) {
                $_SESSION['rechte_gruppen_alle'] = true;
            }
            // Gruppenrechte 2:
            $res = $db->select(
                $sql_tab['benutzer_gruppe_zuordnung'],
                $sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'],
                $sql_tabs['benutzer_gruppe_zuordnung']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id'])
            );
            $_SESSION['benutzer_bgruppen_namen'] = array();
            while ($row = $db->zeile($res)) {
				if ($grp_ownl!='' and $grp_ownl==$row[0]) {
					$_SESSION['benutzer_ownlocation']=1;
				}
                $_SESSION['rechte_bgruppen'].=$row[0] . ',';
                $_SESSION['benutzer_bgruppen_namen'][$row[0]] = $gruppen_crm[$row[0]];
				if ($grp_dbk!='' and $grp_dbk==$row[0]) {
					$_SESSION['benutzer_dbkopie']=1;
					$db_host=$cfg_benutzergruppe_db_host;
					$db_database=$cfg_benutzergruppe_db_database;
					$db2=new PDB;
					$db2->delete(
        	            $sql_tab['useronline'], $sql_tabs['useronline']['benutzer_id'] . '=' . $db->dbzahl($_SESSION['user_id'])
		            );
            		$sql_insert = array(
		                $sql_tabs['useronline']['benutzer_id'] => $db->dbzahl($_SESSION['user_id']),
        		        $sql_tabs['useronline']['datum'] => $db->dbtimestamp(time()),
		                $sql_tabs['useronline']['ip_adresse'] => $db->str($_SERVER["REMOTE_ADDR"])
		            );
		            $sql_insert[$sql_tabs['useronline']['session']] = $db->str(session_id());
		            $db2->insert(
	                    $sql_tab['useronline'],
    	                $sql_insert
        		    );
				}
            }
            $_SESSION['rechte_bgruppen'] = substr($_SESSION['rechte_bgruppen'], 0, -1);
            if ($_SESSION['rechte_bgruppen'] == '') {
                $_SESSION['rechte_bgruppen'] = '-1';
            }

            $cti_lines_arr=array();
            if ($_SESSION['cti_line']!='') {
                $cti_lines_arr=explode(';', trim($_SESSION['cti_line']));
            }
            // Fuer Mike vorbereitet
            if (!empty($cfg_tenios)) {
                // init titles
                $extNumbersTitles = array();
                $res = $db->select(
                    $sql_tab['einstellungen'],
                    $sql_tabs['einstellungen']['wert'],
                    $sql_tabs['einstellungen']['modul'].'='.$db->str('Tenios_Ext_Numbers')
                );
                if ($row = $db->zeile($res)) {
                    $arr = unserialize($row[0]);
                    if (is_array($arr)) {
                        $extNumbersTitles = $arr;
                    }
                }
                // init assignment
                $teniosNumbers = array();
                $res_tenios = $db->select(
                    $sql_tab['einstellungen'],
                    $sql_tabs['einstellungen']['wert'],
                    $sql_tabs['einstellungen']['modul'].'='.$db->str('Tenios')
                );
                if ($row_tenios = $db->zeile($res_tenios)) {
                    $arr = unserialize($row_tenios[0]);
                    if (is_array($arr)) {
                        $tenios = $arr;
                        if (isset($tenios['external_numbers'])) {
                            $externalNumbers = $tenios['external_numbers'];
                            if (!empty($externalNumbers[$_SESSION['user_id']])) {
                                //array_unshift($teniosNumbers, $externalNumbers[$_SESSION['user_id']]);
                                $nr = $externalNumbers[$_SESSION['user_id']];
                                $teniosNumbers[$externalNumbers[$_SESSION['user_id']]] = isset($extNumbersTitles[$nr]) ? $extNumbersTitles[$nr].' ('.$nr.')' : $nr;
                            }
                            if (is_array($_SESSION['benutzer_bgruppen_namen']) && in_array('RR-Nummer', $_SESSION['benutzer_bgruppen_namen'])) {
                                foreach ($externalNumbers as $nr) {
                                    /*if (!in_array($nr, $teniosNumbers)) {
                                        $teniosNumbers[] = $nr;
                                    }*/
                                    if (!isset($teniosNumbers[$nr])) {
                                        $teniosNumbers[$nr] = isset($extNumbersTitles[$nr]) ? $extNumbersTitles[$nr].' ('.$nr.')' : $nr;
                                    }
                                }
                            }
                        }
                    }
                }
                /*if (!empty($teniosNumbers)) {
                    $_SESSION['cti_calling_nr'] = implode(';', $teniosNumbers);
                } else {
                    $_SESSION['cti_calling_nr'] = @$cfg_tenios_external_number;
                }*/
                if (empty($teniosNumbers) && !empty($cfg_tenios_external_number)) {
                    $teniosNumbers[$cfg_tenios_external_number] = $cfg_tenios_external_number;
                }
                $_SESSION['cti_calling_nr'] = $teniosNumbers;
            }
            if ($cfg_phone_proxy) {
                $cti_line_phone_proxies = array();
                $refRep = new Interface_RefRepository('ws_phone_proxy');
                if (($json = $refRep->getExternUserId($_SESSION['user_id'])) !== null) {
                    $cti_line_phone_proxies = json_decode($json, true);
                }
                if ($cti_line_phone_proxies['cti_line']!='') {
                    $cti_lines_arr[] = 'p4nbase64'.base64_encode($cti_line_phone_proxies['cti_line']);
                }
            }
            if ($cfg_messengerpeople) {
                $additionalSettings = MessengerPeople::getAdditionalSettings($_SESSION['user_id']);
                if ($additionalSettings['active']) {
                    //or $additionalSettings['username']
                    $cti_lines_arr[] = MessengerPeople::CONFIG_MODULE;
                }
            }
            if (!empty($cti_lines_arr)) {
                $_SESSION['cti_line'] = implode(';', $cti_lines_arr);
            }

            // Standardfilter:
            if ($sfilt != '') {
                $res2 = $db->select(
                        $sql_tab['filter'], array(
                    $sql_tabs['filter']['filter_id'],
                    $sql_tabs['filter']['gruppen']
                        ), $sql_tabs['filter']['filter_id'] . '=' . $db->dbzahl($sfilt)
                );
                if ($db->anzahl($res2) > 0) {
                    $row2 = $db->zeile($res2);
                    $_SESSION['filteraktiv'] = intval($sfilt);
                    if ($row2[1] != '' and $row2[1] != '-1') {
                        $gfilt = $row2[1];
                    }
                } else {
                    unset($_SESSION['filteraktiv']);
                }
            }
            if ($gfilt != '') {
                $_SESSION['gruppeaktiv'] = $gfilt;
            }
            if ($sfilt != '' or $gfilt != '') {
                if ($cfg_filter_cache) {
                    $ffeld = filter_ergebnis();
                    $ku_anz = get_filter_ids($ffeld[0]);
                    $lstid = explode(',', $_SESSION['crm_l_id']);
                    if (count($lstid) > 0 and trim($_SESSION['crm_l_id']) != '') {
                        $_SESSION['stammdaten_id'] = $lstid[0];
                        $_SESSION['anzahl_saetze'] = count($lstid);
                    } else {
                        $_SESSION['anzahl_saetze'] = 0;
                    }
                    $_SESSION['anzahl_saetze2'] = $ku_anz;
                    if ($_SESSION['anzahl_saetze2'] == 0) {
                        $_SESSION['anzahl_saetze2'] = $_SESSION['anzahl_saetze'];
                    }
                } else {
                    $ffeld = filter_ergebnis();
                    if (!$cfg_speed) {
                        if (preg_match('/select (.*) from/i', $ffeld[0], $m9)) {
                            $f22_1 = '';
                            $f22_2 = explode(',', $m9[1]);
                            while (list($key, $val) = @each($f22_2)) {
                                $val = trim($val);
                                if (stristr($val, 'as max___')!==false or stristr($val, 'as min___')!==false or stristr($val, 'as cou___')!==false or stristr($val, 'as sum___')!==false or p4n_mb_string('substr',$val,0,4)=='sum(' or p4n_mb_string('substr',$val,0,4)=='min(' or p4n_mb_string('substr',$val,0,4)=='max(' or p4n_mb_string('substr',$val,0,6)=='count(' or p4n_mb_string('substr',$val,0,4)=='avg(') {
                                    $f22_1.=',' . $val;
                                }
                            }
                            $sm_sql_2 = str_replace($m9[1], 'distinct ' . $prefix . 'stammdaten.stammdaten_id' . $f22_1, $ffeld[0]);
                            $result = $db->select2($sm_sql_2);
                            $_SESSION['anzahl_saetze2'] = $db->anzahl($result);
                        } else {
                            $_SESSION['anzahl_saetze2'] = 0;
                        }
                    } else {
                        $_SESSION['anzahl_saetze2'] = 0;
                    }
                    $result = $db->select2($ffeld[0]);
                    $_SESSION['anzahl_saetze'] = $db->anzahl($result);
                    if ($_SESSION['anzahl_saetze2'] == 0) {
                        $_SESSION['anzahl_saetze2'] = $_SESSION['anzahl_saetze'];
                    }
                    if ($zeile = $db->zeile($result)) {
                        $_SESSION['stammdaten_id'] = $zeile[0];
                    }
                }
            }
			
			$_SESSION['version_mysql']=0;
			if ($db->treiber=='mysql') {
				$res=$db->select2('select VERSION() as versinfo');
				if ($row=$db->zeile($res)) {
					if ($row['versinfo']!='') {
							if (preg_match('/(\d+)\.(\d+)\.(\d+)/', $row['versinfo'], $matcv)) {
								if (strlen($matcv[1])==1) {
									$matcv[1]='0'.$matcv[1];
								}
								if (strlen($matcv[2])==1) {
									$matcv[2]='0'.$matcv[2];
								}
								if (strlen($matcv[3])==1) {
									$matcv[3]='0'.$matcv[3];
								}
								$versmdb=$matcv[1].$matcv[2].$matcv[3];
								$_SESSION['version_mysql']=intval($versmdb);
							}
					}
				}
			}
			
            // MAG News:
            if ($_SESSION['cfg_kunde'] == 'carlo_opel_magmetz') {
                include_once('inc/' . $_SESSION['cfg_kunde'] . '/send_ids_inc.php');
            }
            if ($cfg_kfzsuche_holland) {
                $ist_benz = false;
                if (is_array($plugin_list) && in_array('Plugin_Benz_ComExtension', $plugin_list)) {
                    $ist_benz = true;
                    if ($_SESSION['rechte_bgruppen'] != '') {
                        $result = $db->select(
                            array(
                                $sql_tab['benutzer_gruppe'],
                                $sql_tab['benutzer_gruppe_zuordnung']
                            ),
                            array(
                                $sql_tabs['benutzer_gruppe']['rang'],
                            ),
                            $sql_tabs['benutzer_gruppe']['benutzer_gruppe_id'].'='.$sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'].' and '.
                            $sql_tabs['benutzer_gruppe']['bezeichnung'].'='.$db->str('Mercedes Benz').' and '.
                            $db->dbzahlin($_SESSION['rechte_bgruppen'], $sql_tabs['benutzer_gruppe_zuordnung']['gruppe_id'])
                        );
                        if ($row = $db->zeile($result)) {
                            $ist_benz = true;
                        } else {
                            $ist_benz = false;
                        }
                    }
                }
                $_SESSION['user_benz'] = $ist_benz;
            }
            $_SESSION['login_anzahl_falsch'] = 0;

            if ($_SESSION['cfg_kunde'] == 'cc_complan') {
                $res = $db->select(
                        $sql_tab['telefonleitfaden'], $sql_tabs['telefonleitfaden']['telefonleitfaden_id'], $sql_tabs['telefonleitfaden']['anruf'] . '=1'
                );
                if ($row = $db->zeile($res)) {
                    $_SESSION['tlf_anruf'] = $row[0];
                }
            }
            if ($target_extcrm != '') {
                $_SESSION['startseite'] = $target_extcrm;
            }
            if (isset($_SESSION['extcrmz2'])) {
                if ($_SESSION['extcrmz2'] != '') {
                    $_SESSION['startseite'] = $_SESSION['extcrmz2'];
                }
            }
            if (file_exists($cfg_basedir.'inc/lib_kalender_neu.php')) {
                include_once($cfg_basedir.'inc/lib_feiertag.php');
                include_once($cfg_basedir.'inc/lib_kalender_neu.php');
                $feiertage = array();
                $kalender_temp = array();
                $benutzerid = $_SESSION['user_id'];
                $kalender_temp[]['id'] = $benutzerid;
                global $ohneTermine;
                $ohneTermine=true;//Sucht Feiertage ohne Termine raus
                $feiertage_temp = getTageVonBenutzer(mktime(0, 0, 0, 1, 1, date("Y")), mktime(0, 0, 0, 12, 31, date("Y")), $kalender_temp);
                $ohneTermine=false;
                if (is_array($feiertage_temp) && $feiertage_temp[$benutzerid]) {
                    foreach ($feiertage_temp[$benutzerid] as $arbeits_feiertag) {
                        if ($arbeits_feiertag['feiertag']['feiertag_gesetzlich'] == 1) {
                            $feiertage[$arbeits_feiertag['label']] = p4n_mb_string('utf8_encode', $arbeits_feiertag['feiertag']['name']);
                        }
                    }
                    $_SESSION['global_feiertage']=json_encode($feiertage);
                }
            }
            if ($passwort_policy_check) {
                $adminBenutzerPasswort =  new MVC_AdminBenutzerPasswort_Model();
                $alle_richtlinien = $adminBenutzerPasswort->settingsSectionData();
                $alle_richtlinien_settings = $alle_richtlinien['settings'];
                $result_pass = $db->select(
                    $sql_tab['benutzer_passwort'],
                    $sql_tabs['benutzer_passwort']['datum'],
                    $sql_tabs['benutzer_passwort']['benutzer_id'].'='.$db->dbzahl($_SESSION['user_id']),
                    $sql_tabs['benutzer_passwort']['datum'].' desc',
                    '',
                    false,
                    1
                );
                if ($row_pass = $db->zeile($result_pass)) {
                    if ($alle_richtlinien_settings['pw_renew_amount']>0) {
                        $datum_timestamp = $db->unixdate_ts($row_pass[0]);
                        $last_change_in_days = intval((time() - $datum_timestamp)/(24*3600));
                        if ($last_change_in_days > 0 && $last_change_in_days>=$alle_richtlinien_settings['pw_renew_amount']) {
                            $_SESSION['passwort_reset']=$last_change_in_days;
                        }
                    }
                } else {
                    $_SESSION['passwort_reset']=1;
                    /*
                    $db->insert(
                        $sql_tab['benutzer_passwort'],
                        array(
                            $sql_tabs['benutzer_passwort']['benutzer_id'] => $db->dbzahl($_SESSION['user_id']),
                            $sql_tabs['benutzer_passwort']['pass_hash'] => $db->str($passwort_post),
                            $sql_tabs['benutzer_passwort']['datum'] => $db->dbtimestamp(time())
                        )
                    );*/
                }
            }
            if (!$session_reload) {
                if ($_SESSION['device'] != '') {
                    wechsel("start_" . $_SESSION['device'] . ".php");
                } else {
                    if ($_SESSION['ajx'] == 1) {
                        wechsel($_SESSION['startseite'], true);
                    } else {
                        wechsel("start.php");
                    }
                }
            }
            
            //echo 'Anmeldung erfolgreich: '.$_SESSION['user_id'];
        } else {
            $login_meldung = _LOGIN_FALSCH_;
            if (!isset($_SESSION['login_anzahl_falsch'])) {
                $_SESSION['login_anzahl_falsch'] = 0;
                $_SESSION['login_anzahl_falsch2'] = time();
            }
            $_SESSION['login_anzahl_falsch'] ++;
        }
    }
    if (!$session_reload) {
        $auth = new auth();

        //BK Hier stand davor nur kopf() ohne eine weitere Sache
        if ($_GET['pause'] == '1') {
            $cfg_body_zusaetze = ' style="background-color:#FF3030"';
        }
        if ($_SESSION['device'] == 'pda') {
            kopf_pda();
        } else {
            if (!$cfg_modern) {
                kopf();
            }
        }

        if (!isset($_GET['ende'])) {
            echo '<script language="JavaScript">if (top!=this) window.open("index.php?ende=1","_top")</script>';
        }
        if ($cfg_neustyle) {
            echo '<!stc1><!shd1>' . css_kopf('<center>Login</center>') . $auth->loginscreen('index.php') . '<!shd2>';
        } else {
            $url_anhang = array();
            if (isset($_GET['extcrmziel']) && $_GET['extcrmziel']!='') {
                foreach ($_GET as $get_key => $get_value) {
                    $url_anhang[] = $get_key.'='.$get_value;
                }
            }
//			if (!empty($cfg_two_factor)) {
//				if ($postfeld_session['insert']['token'] == '') {
//					if ($_SESSION['2fa'] !== '') {
//						unset($_SESSION['2fa']);
//					}
//				}
//			}
            $auth_html= $auth->loginscreen('index.php'.(!empty($url_anhang)?'?'.implode('&',$url_anhang):''));
            if (!$_SESSION['design_70']) {
                echo $auth_html;
            }          
        }
        if ($_SERVER['SERVER_ADMIN'] == 'admin@prof4.net' || $_SERVER['SERVER_NAME'] == '127.0.0.1' || $_SERVER['SERVER_NAME'] == 'localhost') {//Falls wir auf dem Server sind oder wir bei uns lokal testen, sehen wir, ob jemand eingeloggt ist
            $res2 = $db->select(
                    array(
                $sql_tab['useronline'],
                $sql_tab['benutzer']
                    ), array(
                $sql_tabs['benutzer']['login'],
                $sql_tabs['benutzer']['name'],
                $sql_tabs['benutzer']['vorname'],
                $sql_tabs['useronline']['datum']
                    ), $sql_tabs['benutzer']['benutzer_id'] . '=' . $sql_tabs['useronline']['benutzer_id']
            );       
            $useronline = 0;
            $useronline_users = '';
            $stundenlimit=2;
            if (isset($cfg_lizenzcheck_stundeninaktiv)) {
                if ($cfg_lizenzcheck_stundeninaktiv>0) {//Somit auch 0.5 moeglich
                    $stundenlimit=$cfg_lizenzcheck_stundeninaktiv;
                }
            }
            while ($row2 = $db->zeile($res2)) {
                if ($db->unixdate_ts($row2[3])>(time()-($stundenlimit*60*60))) {
                    $useronline = true;
                    $useronline_users .= substr($row2[3], 11).': '.$row2[1] . ', ' . $row2[2] . ' (' . $row2[0] . ')' . '<br>';
                }
            }
            if ($useronline) {
                if (!$_SESSION['design_70']) {
                    echo $lang['_PIM-USERONLINE_'] . ': <br>';
                    echo $useronline_users;
                }
                $auth_html= p4n_mb_string('str_replace', '{useronline}',$lang['_PIM-USERONLINE_'].': '.$useronline_users,$auth_html);
            } else {
                if (!$_SESSION['design_70']) {
                    echo _PIM_KEINUSERONLINE_ . '<br>';
                }
                $auth_html= p4n_mb_string('str_replace', '{useronline}',_PIM_KEINUSERONLINE_,$auth_html);
            }
        } else {
            $auth_html= p4n_mb_string('str_replace', '{useronline}','',$auth_html);
        }
       
        if ($cfg_login_pinnwand) {
            $pw_nur_alle = true;
            if ($_SESSION['design_70']) {
                $logn_pinnwand=true;
                include('pinnwand.php');
                $auth_html= p4n_mb_string('str_replace', '{cfg_login_pinnwand}',$logn_pinnwand,$auth_html);
            } else {
                if (!$cfg_neustyle && !$cfg_modern) {
                    echo '<br><br>';
                }
                if ($cfg_modern) {
                    echo '<br>';
                }
                echo '<!shd1><center>';
                include('pinnwand.php');
                echo '</center><!shd2>';
            }
        }
        if ($_SESSION['design_70']) {
            echo '<div name="main">'.$auth_html.'</div>';
            echo javas('
                jq1112(window).load(function ($) {
                    window_load();
                });
                jq1112(document).ready(function ($) {
                    document_ready();
                });
            ');
        }
        echo '<!stc2>';

        if ($_GET['ende'] == '1') {
            echo '<br><center><font color=red>'._LOGOUT_TIMEOUT_.'</font></center>';
            $auth = new auth();
            $auth->logout();
        }
        //fuss();
        die();
    } else {
        menue_refresh();
        kopf();
    }
} elseif ($_SESSION['device'] == 'pda') {
    // nix
    kopf_pda();
    $mess = new message(_MESSAGE_INIT_, true);
} elseif ($_GET['logout'] or preg_match("/logout\.php/", $_SERVER["PHP_SELF"])) {
//    $auth = new auth();
//    $auth->logout();
} elseif ($_GET['wort'] or preg_match("/stammdaten_gruppenfilter\.php/", $_SERVER["PHP_SELF"])) {
    if (isset($_GET['ajax']) or isset($postfeld_session['ajax'])) {
        // kein Men�
    } else {
        kopf();
    }
} elseif (preg_match("/status\.php/", $_SERVER["PHP_SELF"]) or preg_match("/stammdaten_change\.php/", $_SERVER["PHP_SELF"])) {
    kopf();
//		fuss();
} elseif (preg_match("/setup\.php/", $_SERVER["PHP_SELF"])) {
    if ($_SESSION['user_gruppe'] < 2) {
        die(_KEINRECHT_DATEI_);
    }
} elseif (preg_match("/index\.php/", $_SERVER["PHP_SELF"])) {
    if ($target_extcrm != '') {
        $_SESSION['startseite'] = $target_extcrm;
    }
    if (isset($_SESSION['design_70'])) {
        $_SESSION['external_request_url'] = $target_extcrm;
    }
    wechsel('start.php');
} else {
    if (isset($_SESSION['user_ip'])) {
        include_once("inc/auth.php");
        $auth=new auth();
        $version = str_replace('.', '', $auth->getVersion());
        $res2_tabs = array(
            $sql_tabs['useronline']['datum'],
            $sql_tabs['useronline']['ip_adresse']
        );
        $erlaubt=true;
        if ($version>=56) {
            $res2_tabs[] = $sql_tabs['useronline']['session'];
            $erlaubt=false;
        }
        $res2 = $db->select(
            $sql_tab['useronline'], 
            $res2_tabs, 
            $sql_tabs['useronline']['benutzer_id'] . '=' . $db->dbzahl($_SESSION['user_id'])
        );
        if ($row2=$db->zeile($res2)) {
            $erlaubt=true;
            if ($version >= 56) {
                if ($row2[2] == '' || ($row2[2] != '' && $row2[2]!=session_id())) {
                    $erlaubt = false;
                }
            } else {
                if ($_SESSION['user_ip']!=$row2[1]) {
                    $erlaubt = false;
                }
            }
        }
        if (!$erlaubt && $_SESSION['user_id'] != '1' && !isset($_SESSION['phantom_login'])) {
            if ($fpl=fopen('log/logout.txt', 'a')) {
                fwrite($fpl, date('d.m.Y H:i:s', time()).': User-ID='.$_SESSION['user_id'].', IP aktuell/vorhanden: '.$row2[1].'/'.$_SESSION['user_ip'].', Browser: '.$_SERVER['HTTP_USER_AGENT']."\r\n");
                fclose($fpl);
            }
            include_once("inc/output.php");
            $auth->logout();
            die();
        }
    }
    
    if (!$noauth && $_SESSION['keine_favoriten'] === false) {
        if (!isset($temp_keine_fav)) {
            if (!isset($_GET['options_menu']) || $_GET['options_menu']!='0') {
                include_once('favoriten.php');
            }
        }
    }

    if (!$cfg_messenger) {
        srand((double) microtime() * 1000000);
        if (rand(1, 6) == 3) {
            $res = $db->update(
                    $sql_tab['useronline'], array(
                $sql_tabs['useronline']['datum'] => $db->dbtimestamp(time())
                    ), $sql_tabs['useronline']['benutzer_id'] . '=' . $db->dbzahl($_GET['uid'])
            );
        }
    }
    if (isset($_GET['ajax']) or isset($postfeld_session['ajax'])) {
        // kein Men�
    } else {
        if (!$startseite)
        kopf();
            if (!isset($_GET['noreload'])) menue();
    }
    navbar();
    if ($_SESSION['karte'] == 'Korrespondenz' or $_SESSION['karte'] == 'Zusatzdaten')
        $mess = new message(_MESSAGE_INIT_, true);
    elseif ($_GET['nav'] == 'Korrespondenz' or $_GET['nav'] == 'Zusatzdaten' or preg_match("/korrespondenz\.php/", $_SERVER["PHP_SELF"]) or preg_match("/zusatzdaten\.php/", $_SERVER["PHP_SELF"]) or preg_match("/admin_benutzer\.php/", $_SERVER["PHP_SELF"]) or preg_match("/pim\.php/", $_SERVER["PHP_SELF"]))
        $mess = new message(_MESSAGE_INIT_, true);
    elseif ($_GET['nav'] == 'Uebersicht')
        $dummy = 1;
    else
        $mess = new message(_MESSAGE_INIT_);
}
echo js_korrespondenz();
if ($cfg_cti) {
    echo anruf_cti();
}
if (!function_exists('p4n_is_utf8')) {
function p4n_is_utf8($str) {
    $strlen = strlen($str);
    for ($i = 0; $i < $strlen; $i++) {
        $ord = ord($str[$i]);
        if ($ord < 0x80)
            continue; // 0bbbbbbb
        elseif (($ord & 0xE0) === 0xC0 && $ord > 0xC1)
            $n = 1; // 110bbbbb (exkl C0-C1)
        elseif (($ord & 0xF0) === 0xE0)
            $n = 2; // 1110bbbb
        elseif (($ord & 0xF8) === 0xF0 && $ord < 0xF5)
            $n = 3; // 11110bbb (exkl F5-FF)
        else
            return false; // ung�ltiges UTF-8-Zeichen
        for ($c = 0; $c < $n; $c++) // $n Folgebytes? // 10bbbbbb
            if (++$i === $strlen || (ord($str[$i]) & 0xC0) !== 0x80)
                return false; // ung�ltiges UTF-8-Zeichen
    }
    return true; // kein ung�ltiges UTF-8-Zeichen gefunden
}
}

if (!function_exists('unescape3')) {
function unescape3($source, $iconv_to = 'UTF-8') {
    $decodedStr = '';
    $pos = 0;
    $len = strlen($source);
    while ($pos < $len) {
        $charAt = substr($source, $pos, 1);
        if ($charAt == '%') {
            $pos++;
            $charAt = substr($source, $pos, 1);
            if ($charAt == 'u') {
                // we got a unicode character
                $pos++;
                $unicodeHexVal = substr($source, $pos, 4);
                $unicode = hexdec($unicodeHexVal);
                $decodedStr .= code2utf($unicode);
                $pos += 4;
            } elseif (1 == 2) {
                // we have an escaped ascii character
                $hexVal = substr($source, $pos, 2);
                $decodedStr .= chr(hexdec($hexVal));
                $pos += 2;
            } else {
                $decodedStr .= '%';
            }
        } else {
            $decodedStr .= $charAt;
            $pos++;
        }
    }

    if ($iconv_to != "UTF-8") {
        $decodedStr = iconv("UTF-8", $iconv_to, $decodedStr);
    }

    return $decodedStr;
}
}

if (!function_exists('code2utf')) {
function code2utf($num) {
    if ($num < 128)
        return chr($num);
    if ($num < 2048)
        return chr(($num >> 6) + 192) . chr(($num & 63) + 128);
    if ($num < 65536)
        return chr(($num >> 12) + 224) . chr((($num >> 6) & 63) + 128) . chr(($num & 63) + 128);
    if ($num < 2097152)
        return chr(($num >> 18) + 240) . chr((($num >> 12) & 63) + 128) . chr((($num >> 6) & 63) + 128) . chr(($num & 63) + 128);
    return '';
}
}

if (!function_exists('parse')) {
function parse($buffer) {
    if (preg_match_all('/src="(temp\/.*)"/Ui', $buffer, $ma)) {
	    while (list($key1, $val1) = @each($ma[1])) {
		$val2 = preg_replace('/[\?](.*)/i', '', $val1);
        $buffer = p4n_mb_string('str_replace', $val1, 'sec_download.php?out=' . urlencode($val2), $buffer);
	    }
	}
    return $buffer;
}
}

if (!$cfg_modern && ($_SESSION['cfg_security_level'] == 9 || $_SESSION['cfg_security_level'] == 5 || $_SESSION['cfg_security_level'] == 6 || $_SESSION['cfg_security_level'] == 8)) {
	ob_start("parse");
}
if ($_SESSION['cfg_kunde']=='crm_vw_catch_wob') {
    $phs='';
}
$ist_vgrd=boolval($cfg_vgrd);
if ($_SESSION['cfg_kunde']=='crm_vw_hamburg' or $_SESSION['cfg_kunde']=='crm_audi_hamburg' or $_SESSION['cfg_kunde']=='carlo_vw_audihannover' or $_SESSION['cfg_kunde']=='crm_vw_hannover' or $_SESSION['cfg_kunde']=='carlo_vw_t4net_ab' or $_SESSION['cfg_kunde']=='crm_audi_berlin' or $_SESSION['cfg_kunde']=='carlo_vw_ba' or $_SESSION['cfg_kunde']=='crm_vw_asbberlin' or $_SESSION['cfg_kunde']=='crm_vw_chemnitz' or $_SESSION['cfg_kunde']=='kunde_kfz_leipzig' or $_SESSION['cfg_kunde']=='crm_audi_leipzig' or $_SESSION['cfg_kunde']=='crm_vw_frankfurt' or $_SESSION['cfg_kunde']=='crm_audi_frankfurt' or $_SESSION['cfg_kunde']=='crm_vw_rhein' or $_SESSION['cfg_kunde']=='crm_vw_stuttgart' or $_SESSION['cfg_kunde']=='crm_audi_stuttgart' or $_SESSION['cfg_kunde']=='carlo_vw_mahag' or $_SESSION['cfg_kunde']=='crm_vw_ulm' or $_SESSION['cfg_kunde']=='crm_vw_schwaba' or $_SESSION['cfg_kunde']=='crm_vw_vgrhh' or $_SESSION['cfg_kunde']=='crm_vw_vgrb' or $_SESSION['cfg_kunde']=='crm_vw_hannover_release') {
    $ist_vgrd=true;
}
if ($ist_vgrd) {
    $lang_db_f['kampagne_lead']['etcc_cmp'] = 'etcc_Kampagne'; // vorher etcc_Kampagnenname
    $lang_db_f['kampagne_lead']['etcc_med'] = 'etcc_Medium';
    $lang_db_f['kampagne_lead']['etcc_par'] = 'etcc_Partner';   // vorher etcc_Quelle
    $lang_db_f['kampagne_lead']['etcc_var'] = 'etcc_Variante';  // vorher etcc_Anzeigentyp
    $lang_db_f['kampagne_lead']['etcc_tar'] = 'etcc_Sparte';
    $lang_db_f['kampagne_lead']['etcc_ori'] = 'etcc_Herkunft';
    $lang_db_f['kampagne_lead']['etcc_ctv'] = 'etcc_Anzeige';
    $lang_db_f['kampagne_lead']['etcc_mty'] = 'etcc_Matchtype';
    $lang_db_f['kampagne_lead']['etcc_plc'] = 'etcc_Platzierung';
    $lang_db_f['kampagne_lead']['etcc_grp'] = 'etcc_Gruppe';
    $lang_db_f['kampagne_lead']['etcc_adv'] = 'etcc_Werbetreibender';   // raus
    $lang_db_f['kampagne_lead']['etcc_acy'] = 'etcc_Agentur';           // raus
    
    $lang_db_f['kampagne_lead']['etcc_et_cmp_seg3'] = 'etcc_Sparte';
    $lang_db_f['kampagne_lead']['etcc_et_cmp_seg5'] = 'etcc_Platzierung';
    $lang_db_f['kampagne_lead']['etcc_et_cmp_seg1'] = 'etcc_Advertiser';
    $lang_db_f['kampagne_lead']['etcc_et_cmp_seg2'] = 'etcc_Agency';
    $lang_db_f['kampagne_lead']['etcc_et_cmp_seg4'] = 'etcc_Variante';
//https://www.held-stroehle.de/?etcc_cmp=Kampagne&etcc_med=Medium&etcc_par=Partner&etcc_ctv=Anzeige&et_cmp_seg3=Sparte&et_cmp_seg4=Variante&et_cmp_seg5=Platzierung&etcc_mty=Matchtype&etcc_grp=Gruppe&et_cmp_seg1=Advertiser&et_cmp_seg2=Agency&etcc_ori=Herkunft
}
if (!empty($cfg_ecaros_api)) {
    $lang_db_f['produktzuordnung']['naechste_insp'] = $lang['_NAECHSTE_INSPEKTION_'];
}
if (!empty($cfg_toyota_toca)) {
    $cfg_rechtsform_liste = array(
        84    => 'OHG',
        85    => 'KG',
        86    => 'GmbH',
        87    => 'AG',
        88    => 'GmbH &amp; Co. KG',
        89    => 'e.V.',
        90    => 'Stiftung',
        92    => 'e.G.',
        93    => 'Institut ohne Erwerbscharakter',
        94    => 'Kommune, Land, Staat',
        95    => 'kirchliche Einrichtung',
        96    => 'GbR (BGB)',
        97    => 'KGaA',
        466   => 'GmbH i.G.',
        3755  => 'eingetragener Kaufmann',
        3756  => 'Einzelfirma',
        5599  => 'PartnG',
        10824 => 'UG',
        11370 => 'UG &amp; Co. KG',
        12401 => 'SE',
        15844 => 'Landwirtschaftlicher Betrieb',
        15845 => 'Partnergesellschaft mit beschr�nkter Berufshaftung',
        15847 => 'SE &amp; Co. KG',
        15848 => 'SE &amp; Co. KGaA',
        15849 => 'Stiftung &amp; Co. KG',
        15850 => 'Stiftung &amp; Co. KGaA',
        17344 => 'COMMERCIAL'
    );
    
    $cfg_messenger=true;
    $cfg_emobilio=true;
    $cfg_login_pinnwand=true;
    $cfg_customer_interfaces=true;
    $cfg_infos_pinnwand=true;
}
?>